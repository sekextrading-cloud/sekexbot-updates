"""Robinhood Agentic Trading (MCP) client for the Robinhood tab.

Robinhood's official MCP server (https://agent.robinhood.com/mcp/trading) lets an app read your accounts and place
trades ONLY in a dedicated "agentic" account (Robinhood enforces that, not this code). Sign-in is standard MCP OAuth:
dynamic client registration + PKCE (S256), no client secret. Tokens are stored in data/robinhood.json (owner-only).

Nothing here trades by itself. Tools are discovered at runtime (tools/list). A tool counts as READ-ONLY only when the
server marks it readOnly or its name is plainly a lookup; everything else is treated as a WRITE and the server code
(server.py) makes it need the Live PIN plus an explicit confirmation."""
from __future__ import annotations

import base64
import hashlib
import json
import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .config import DATA_DIR

MCP_URL = os.environ.get("SEKEX_RH_MCP", "https://agent.robinhood.com/mcp/trading")
FILE = DATA_DIR / "robinhood.json"
PROTO = "2025-06-18"
READ_NAME = re.compile(r"^(get|list|search|find|read|view|fetch|show|lookup|quote|preview|describe|check|status)", re.I)
WRITE_NAME = re.compile(r"(place|submit|create|cancel|replace|modify|amend|execute|trade|buy|sell|order|transfer|withdraw|deposit|close|liquidate|rebalance|set_|update|delete|remove)", re.I)


class RHError(Exception):
    pass


class RHNotConnected(RHError):
    pass


def _b64(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def is_write(tool: dict) -> bool:
    ann = tool.get("annotations") or {}
    name = tool.get("name", "")
    if ann.get("readOnlyHint") is True and not WRITE_NAME.search(name):
        return False
    if ann.get("destructiveHint") is True or ann.get("readOnlyHint") is False:
        return True
    return not (READ_NAME.search(name) and not WRITE_NAME.search(name))


class RH:
    def __init__(self, mcp_url: str = MCP_URL):
        self.url = mcp_url
        self.lock = threading.RLock()
        self.cfg = self._load()
        self._meta = None
        self._session = None
        self._tools = None

    # ---- storage ----
    def _load(self) -> dict:
        try:
            return json.loads(FILE.read_text())
        except Exception:
            return {}

    def _save(self):
        FILE.parent.mkdir(parents=True, exist_ok=True)
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.cfg))
        try:
            os.chmod(tmp, 0o600)
        except Exception:
            pass
        os.replace(tmp, FILE)

    @property
    def connected(self) -> bool:
        return bool(self.cfg.get("access") or self.cfg.get("refresh"))

    def disconnect(self):
        with self.lock:
            self.cfg = {k: v for k, v in self.cfg.items() if k in ("client_id", "redirect_uri")}
            self._save()
            self._session = self._tools = None

    # ---- http ----
    def _http(self, method, url, body=None, headers=None, form=False, timeout=30):
        data = None
        h = {"User-Agent": "SekexBot-RH/1", "Accept": "application/json"}
        h.update(headers or {})
        if body is not None:
            if form:
                data = urllib.parse.urlencode(body).encode()
                h["Content-Type"] = "application/x-www-form-urlencoded"
            else:
                data = json.dumps(body).encode()
                h["Content-Type"] = "application/json"
        req = urllib.request.Request(url, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return r.status, dict(r.headers), r.read()
        except urllib.error.HTTPError as e:
            return e.code, dict(e.headers or {}), e.read()
        except urllib.error.URLError as e:
            raise RHError(f"Can't reach Robinhood ({e.reason}).")

    def _json(self, method, url, body=None, headers=None, form=False):
        st, _, raw = self._http(method, url, body, headers, form)
        try:
            return st, json.loads(raw or b"{}")
        except Exception:
            return st, {"raw": raw[:300].decode("utf8", "replace")}

    # ---- OAuth ----
    def meta(self) -> dict:
        if self._meta:
            return self._meta
        p = urllib.parse.urlparse(self.url)
        base = f"{p.scheme}://{p.netloc}"
        for u in (f"{base}/.well-known/oauth-authorization-server{p.path}", f"{base}/.well-known/oauth-authorization-server"):
            st, d = self._json("GET", u)
            if st == 200 and d.get("authorization_endpoint"):
                self._meta = d
                return d
        raise RHError("Couldn't read Robinhood's sign-in settings.")

    def start_auth(self, redirect_uri: str) -> str:
        m = self.meta()
        with self.lock:
            if not self.cfg.get("client_id") or self.cfg.get("redirect_uri") != redirect_uri:
                st, d = self._json("POST", m["registration_endpoint"], {
                    "client_name": "SekexBot", "redirect_uris": [redirect_uri], "grant_types": ["authorization_code", "refresh_token"],
                    "response_types": ["code"], "token_endpoint_auth_method": "none", "scope": " ".join(m.get("scopes_supported") or [])})
                if st not in (200, 201) or not d.get("client_id"):
                    raise RHError(f"Robinhood refused the app registration (HTTP {st}).")
                self.cfg.update(client_id=d["client_id"], redirect_uri=redirect_uri)
            verifier = _b64(secrets.token_bytes(48))
            state = _b64(secrets.token_bytes(18))
            self.cfg.update(pending={"state": state, "verifier": verifier, "t": time.time()})
            self._save()
        q = {"response_type": "code", "client_id": self.cfg["client_id"], "redirect_uri": redirect_uri, "state": state,
             "code_challenge": _b64(hashlib.sha256(verifier.encode()).digest()), "code_challenge_method": "S256",
             "scope": " ".join(m.get("scopes_supported") or []), "resource": self.url}
        return m["authorization_endpoint"] + "?" + urllib.parse.urlencode(q)

    def finish_auth(self, code: str, state: str):
        with self.lock:
            p = self.cfg.get("pending") or {}
            if not p or state != p.get("state") or time.time() - p.get("t", 0) > 900:
                raise RHError("That sign-in link expired or does not match. Tap Connect again.")
            st, d = self._json("POST", self.meta()["token_endpoint"], {
                "grant_type": "authorization_code", "code": code, "redirect_uri": self.cfg["redirect_uri"],
                "client_id": self.cfg["client_id"], "code_verifier": p["verifier"]}, form=True)
            if st != 200 or not d.get("access_token"):
                raise RHError(f"Robinhood did not accept the sign-in (HTTP {st}).")
            self._store_tokens(d)
            self.cfg.pop("pending", None)
            self._save()

    def _store_tokens(self, d):
        self.cfg["access"] = d["access_token"]
        if d.get("refresh_token"):
            self.cfg["refresh"] = d["refresh_token"]
        self.cfg["exp"] = time.time() + float(d.get("expires_in") or 3600) - 60
        self._session = None

    def _token(self) -> str:
        with self.lock:
            if not self.connected:
                raise RHNotConnected("Not connected. Tap Connect Robinhood.")
            if time.time() < self.cfg.get("exp", 0) and self.cfg.get("access"):
                return self.cfg["access"]
            if not self.cfg.get("refresh"):
                raise RHNotConnected("Robinhood sign-in expired. Tap Connect Robinhood again.")
            st, d = self._json("POST", self.meta()["token_endpoint"], {
                "grant_type": "refresh_token", "refresh_token": self.cfg["refresh"], "client_id": self.cfg.get("client_id", "")}, form=True)
            if st != 200 or not d.get("access_token"):
                self.cfg.pop("access", None); self.cfg.pop("refresh", None); self._save()
                raise RHNotConnected("Robinhood sign-in expired. Tap Connect Robinhood again.")
            self._store_tokens(d)
            self._save()
            return self.cfg["access"]

    # ---- MCP ----
    def _rpc(self, method, params=None, notify=False, retry=True):
        body = {"jsonrpc": "2.0", "method": method}
        if params is not None:
            body["params"] = params
        if not notify:
            body["id"] = int(time.time() * 1000) % 10**9
        h = {"Authorization": "Bearer " + self._token(), "Accept": "application/json, text/event-stream", "MCP-Protocol-Version": PROTO}
        if self._session:
            h["Mcp-Session-Id"] = self._session
        st, hd, raw = self._http("POST", self.url, body, h, timeout=45)
        sid = {k.lower(): v for k, v in hd.items()}.get("mcp-session-id")
        if sid:
            self._session = sid
        if st in (401, 403) and retry:
            self.cfg["exp"] = 0
            return self._rpc(method, params, notify, retry=False)
        if st == 404 and self._session and retry:        # session expired
            self._session = None
            self._init()
            return self._rpc(method, params, notify, retry=False)
        if st >= 400:
            raise RHError(f"Robinhood answered HTTP {st}: {raw[:200].decode('utf8', 'replace')}")
        if notify or not raw.strip():
            return {}
        txt = raw.decode("utf8", "replace")
        if txt.lstrip().startswith(("event:", "data:", "id:")) or "\ndata:" in txt:
            msgs = [json.loads(l[5:].strip()) for l in txt.splitlines() if l.startswith("data:") and l[5:].strip().startswith("{")]
            msg = next((m for m in msgs if m.get("id") == body.get("id")), msgs[-1] if msgs else {})
        else:
            msg = json.loads(txt)
        if msg.get("error"):
            raise RHError(str(msg["error"].get("message") or msg["error"])[:300])
        return msg.get("result", {})

    def _init(self):
        self._session = None
        self._rpc("initialize", {"protocolVersion": PROTO, "capabilities": {}, "clientInfo": {"name": "SekexBot", "version": "1"}})
        self._rpc("notifications/initialized", {}, notify=True)

    def tools(self, refresh=False) -> list:
        with self.lock:
            if self._tools is None or refresh:
                self._init()
                out, cur = [], None
                for _ in range(10):
                    r = self._rpc("tools/list", {"cursor": cur} if cur else {})
                    out += r.get("tools", [])
                    cur = r.get("nextCursor")
                    if not cur:
                        break
                for t in out:
                    t["write"] = is_write(t)
                self._tools = out
            return self._tools

    def call(self, name: str, args: dict | None = None) -> dict:
        with self.lock:
            if not any(t["name"] == name for t in self.tools()):
                raise RHError("Unknown Robinhood tool: " + name)
            if self._session is None:
                self._init()
            return self._rpc("tools/call", {"name": name, "arguments": args or {}})


def result_text(res: dict):
    """Turn an MCP tool result into (parsed_json_or_None, plain_text)."""
    parts = [c.get("text", "") for c in (res.get("content") or []) if c.get("type") == "text"]
    txt = "\n".join(parts).strip()
    if res.get("structuredContent") is not None:
        return res["structuredContent"], txt
    try:
        return json.loads(txt), txt
    except Exception:
        return None, txt
