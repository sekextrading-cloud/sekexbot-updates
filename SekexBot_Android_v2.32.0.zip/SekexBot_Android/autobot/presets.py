"""v2.18: custom preset strategies. You describe a setup in words (or show a chart screenshot); the AI turns it into a small, bounded rule set,
which is back-tested on real 5-minute bars, drawn on a chart image, saved, reviewed every day and (PAPER only) can trade by itself.

Pure functions plus a tiny JSON store. No orders are placed here. The AI can only fill in the numbers below; every value is clamped, so a preset can
never touch loss limits, Live mode or position size (size always comes from the risk budget)."""
import json
import re
import threading
import time
from datetime import datetime

import numpy as np
import pandas as pd

from . import jump as jp
from .config import DATA_DIR

FILE = DATA_DIR / "presets.json"
LOCK = threading.RLock()
PATTERNS = {
    "pullback": "Pullback to the moving average in a trend, then a confirming candle (the JUMP IN setup)",
    "vwap_reclaim": "Price crosses back over VWAP in the direction of the trend",
    "breakout": "Price breaks the recent high (or low) on stronger volume",
    "gap_go": "A gap at the open that holds and keeps going",
    "zone": "Support / resistance zone: a break of the zone then a retest that holds, or a bounce off a level that held before; target the prior swing high (or low)",
    "candle": "Candlestick reversal: engulfing, hammer / shooting star, morning / evening star, three inside or three outside, after a drop (buy) or a rise (short); stop just past the pattern",
    "hs": "Head and shoulders (short) or inverse head and shoulders (buy): enter when price breaks the neckline",
    "dbl": "Double top (short) or double bottom (buy): the same high or low twice, enter when the middle level breaks",
    "tri": "Symmetrical triangle: highs falling and lows rising squeeze together, enter on the breakout",
    "tline": "Trend-line break: price closes through a falling (buy) or rising (short) trend line",
    "macross": "Moving-average cross: the fast average crosses the slow one with the trend",
    "rsi_turn": "RSI turn: RSI pulls back to the 40s in an uptrend (or bounces to the 60s in a downtrend) and turns back with the trend",
    "open_sweep": "Open sweep (86 model style): price sweeps a low (or high) away from the 9:30 open, turns back through the open, then pulls back into the Golden zone and holds; stop just past the sweep",
    "cycle": "Cycle turn: the Stochastic (3,5,2) turns up from under 20 (or down from over 80) at support (or resistance) with the trend turning and the 15-minute chart agreeing; stop just past the turn",
    "vwap_rej": "VWAP rejection: after a new low of the day (or high for buys) price rallies back to VWAP and a candle closes the other side of it; stop just past that candle",
    "smc": "Liquidity sweep of a low (or high), then a change of character, then entry on the retest of the fair value gap (smart-money style)",
}
STATS = {"chop": 0, "weak": 0}
LIMITS = {"stop_pct": (0.2, 5.0), "target_r": (0.5, 5.0), "vol_mult": (0.0, 5.0), "lookback": (5, 60), "gap_pct": (0.5, 20.0), "min_price": (0.5, 5000.0)}
DEFAULTS = {"pattern": "pullback", "side": "long", "stop_pct": 1.0, "target_r": 1.5, "vol_mult": 1.0, "above_vwap": True, "lookback": 20,
            "gap_pct": 2.0, "after_hours": True, "min_price": 1.0, "chop_skip": True, "zone_grade": True}


OLD_CANDLES = {k: "candle" for k in ("engulfing", "hammer", "star", "inside3", "outside3")}


def normalize(r, name=None):
    """Clamp anything the AI (or a user) sent into the allowed ranges. Unknown keys are dropped."""
    r = r if isinstance(r, dict) else {}
    out = dict(DEFAULTS)
    p = str(r.get("pattern", out["pattern"])).lower().strip()
    p = OLD_CANDLES.get(p, p)                                  # v2.32: the five candle patterns became one "candle" pattern; saved presets keep working
    out["pattern"] = p if p in PATTERNS else "pullback"
    s = str(r.get("side", out["side"])).lower().strip()
    out["side"] = s if s in ("long", "short", "both") else "long"
    for k, (lo, hi) in LIMITS.items():
        try:
            v = float(r.get(k, out[k]))
        except (TypeError, ValueError):
            v = out[k]
        out[k] = round(max(lo, min(hi, v)), 2)
    out["lookback"] = int(out["lookback"])
    out["above_vwap"] = bool(r.get("above_vwap", out["above_vwap"]))
    out["after_hours"] = bool(r.get("after_hours", out["after_hours"]))
    out["chop_skip"] = bool(r.get("chop_skip", out["chop_skip"]))
    out["zone_grade"] = bool(r.get("zone_grade", out["zone_grade"]))
    out["name"] = (str(name or r.get("name") or "My preset").strip()[:40]) or "My preset"
    out["notes"] = str(r.get("notes", ""))[:300]
    return out


def describe(r):
    side = {"long": "buy", "short": "short", "both": "buy and short"}[r["side"]]
    t = f"{PATTERNS[r['pattern']]}. I {side}. Stop {r['stop_pct']:g}% away, target {r['target_r']:g}x the risk."
    if r["pattern"] in ("breakout", "vwap_reclaim", "pullback") and r["vol_mult"] > 0:
        t += f" Volume at least {r['vol_mult']:g}x its recent average."
    if r["pattern"] == "breakout":
        t += f" Breaks the last {r['lookback']} candles."
    if r["pattern"] == "smc":
        t += " Stop just past the sweep."
    if r["pattern"] == "vwap_rej":
        t += " Stop just past the rejection candle."
    if r["pattern"] == "open_sweep":
        t += " Only in the morning (9:40 to your cut-off). Stop just past the sweep."
    if r["pattern"] == "cycle":
        t += " Needs the Stochastic turn plus enough of the 5 checks. Stop just past the turn."
    if r["pattern"] == "zone":
        t += " Stop just past the zone; target the prior swing high or low (at least 1x the risk)."
    if r["pattern"] == "gap_go":
        t += f" Needs a gap of {r['gap_pct']:g}% or more."
    t += " Above VWAP for buys, below for shorts." if (r["above_vwap"] and r["pattern"] not in ("smc", "vwap_rej", "cycle", "open_sweep")) else ""
    if r.get("chop_skip"):
        t += " Skips choppy, going-nowhere stretches."
    if r.get("zone_grade") and r["pattern"] in ("zone", "hs", "dbl"):
        t += " Skips weak zones."
    t += " After-hours candles count." if r["after_hours"] else " Regular hours only."
    return t


CY_FILE = DATA_DIR / "cycle.json"
CY_DEFAULT = {"stoch": "3-5-2", "lines": "20-80", "need": 4, "htf": "15", "boxes": True}
CY_OK = {"stoch": ("3-5-2", "14-3-3"), "lines": ("20-80", "25-75"), "need": (3, 4, 5), "htf": ("15", "off")}


def cy_cfg():
    c = dict(CY_DEFAULT)
    try:
        c.update(json.loads(CY_FILE.read_text()))
    except Exception:
        pass
    for k, ok in CY_OK.items():
        if c.get(k) not in ok:
            c[k] = CY_DEFAULT[k]
    return c


def cy_set(**kw):
    c = cy_cfg()
    for k, v in kw.items():
        if k in CY_OK and v in CY_OK[k]:
            c[k] = v
    try:
        CY_FILE.write_text(json.dumps(c))
    except Exception:
        pass
    return cy_cfg()


def _htf_trend(d, idx, e_fast=9, e_slow=20):
    """For every 5-minute bar: the trend (+1 / -1 / 0) of the last COMPLETED 15-minute bar at that moment (no peeking at the bar still forming)."""
    c15 = d["close"].resample("15min", label="left", closed="left").last().dropna()
    if len(c15) < e_slow + 2:
        return [0] * len(d)
    f, s_ = c15.ewm(span=e_fast, adjust=False).mean(), c15.ewm(span=e_slow, adjust=False).mean()
    tr = pd.Series([1 if a > b else -1 if a < b else 0 for a, b in zip(f, s_)], index=c15.index)
    # a 15-minute bar labelled t is complete at t+15min; a 5-minute bar at time u may use bars labelled <= u-15min
    pos = tr.index.searchsorted(d.index - pd.Timedelta(minutes=15), side="right") - 1
    return [int(tr.iloc[p]) if p >= 0 else 0 for p in pos]


def _cycle(d, o, h, l, c, atr, days, e9, cfg=None):
    """v2.30, pattern 19: the Cycle turn. Five checks, in the order of the method: (1) a new direction: price back over the 9 average (or under it for
    shorts); (2) momentum turning: the Stochastic rising through its signal line; (3) a cycle low: that turn came from under the lower line
    (over the upper line for shorts); (4) at support: near the recent low or the 50 average (resistance for shorts); (5) the 15-minute trend agrees.
    Checks 2 and 3 are always required; the rest count toward the number needed. A mini-divergence (price makes a lower low, the Stochastic does not)
    is a bonus that lifts the grade. Stop just past the turn."""
    from .indicators import stoch as _stoch
    cfg = cfg or cy_cfg()
    pk, pd_, sm = {"3-5-2": (5, 3, 2), "14-3-3": (14, 3, 3)}.get(cfg["stoch"], (5, 3, 2))      # (%K period, %D period, smoothing); "3-5-2" is the course setting PeriodD 3, PeriodK 5, Smooth 2
    lo_l, hi_l = (int(x) for x in cfg["lines"].split("-"))
    need = int(cfg["need"])
    k, dd = _stoch(d, pk, pd_, sm)
    K, D = k.values, dd.values
    sma50 = d["close"].rolling(50, min_periods=30).mean().values
    htf = _htf_trend(d, d.index) if cfg["htf"] != "off" else None
    n, out = len(d), []
    for i in range(55, n):
        a = atr[i]
        if not (a == a) or a <= 0 or days[i - 6] != days[i] or K[i] != K[i] or D[i] != D[i] or K[i - 1] != K[i - 1]:
            continue
        for side in ("up", "down"):
            up = side == "up"
            if up:
                turn = K[i] > K[i - 1] and K[i - 1] <= D[i - 1] + 1e-9 and K[i] > D[i] - 1e-9      # %K rises through (or is above) its signal line
                cyc = np.nanmin(K[i - 8:i + 1]) < lo_l
                ch1 = c[i] > e9[i] and any(c[j] <= e9[j] for j in range(i - 3, i))
                low6 = l[i - 5:i + 1].min()
                ch4 = low6 <= l[max(0, i - 40):i + 1].min() + 0.8 * a or (sma50[i] == sma50[i] and abs(low6 - sma50[i]) <= 0.5 * a and c[i] >= sma50[i] - 0.2 * a)
                ch5 = True if htf is None else htf[i] > 0
                div = l[i - 5:i + 1].min() < l[i - 14:i - 5].min() and np.nanmin(K[i - 5:i + 1]) >= np.nanmin(K[i - 14:i - 5])
                stop = float(low6 - 0.1 * a)
            else:
                turn = K[i] < K[i - 1] and K[i - 1] >= D[i - 1] - 1e-9 and K[i] < D[i] + 1e-9
                cyc = np.nanmax(K[i - 8:i + 1]) > hi_l
                ch1 = c[i] < e9[i] and any(c[j] >= e9[j] for j in range(i - 3, i))
                high6 = h[i - 5:i + 1].max()
                ch4 = high6 >= h[max(0, i - 40):i + 1].max() - 0.8 * a or (sma50[i] == sma50[i] and abs(high6 - sma50[i]) <= 0.5 * a and c[i] <= sma50[i] + 0.2 * a)
                ch5 = True if htf is None else htf[i] < 0
                div = h[i - 5:i + 1].max() > h[i - 14:i - 5].max() and np.nanmax(K[i - 5:i + 1]) <= np.nanmax(K[i - 14:i - 5])
                stop = float(high6 + 0.1 * a)
            if not (turn and cyc):
                continue
            checks = [bool(ch1), bool(turn), bool(cyc), bool(ch4), bool(ch5)]
            score = sum(checks)
            if score < need:
                continue
            grade = "A" if (score == 5 and div) or score == 5 else "B" if score == 4 else "C"
            nm = "Cycle turn buy" if up else "Cycle turn short"
            why = ("The Stochastic turned up from under " + str(lo_l) if up else "The Stochastic turned down from over " + str(hi_l)) + f" with {score} of 5 checks" + (" and a mini-divergence" if div else "") + f" (grade {grade}). Stop just past the turn."
            out.append((i, side, nm, why, {"stop": stop, "checks": checks, "cgrade": grade, "div": bool(div), "k": round(float(K[i]), 1)}))
    return out


OS_FILE = DATA_DIR / "opensweep.json"
OS_DEFAULT = {"zone": "50-79", "until": "11:00", "boxes": True}
OS_OK = {"zone": ("50-79", "62-79"), "until": ("10:30", "11:00", "11:30")}


def os_cfg():
    c = dict(OS_DEFAULT)
    try:
        c.update(json.loads(OS_FILE.read_text()))
    except Exception:
        pass
    for k, ok in OS_OK.items():
        if c.get(k) not in ok:
            c[k] = OS_DEFAULT[k]
    c["boxes"] = bool(c.get("boxes", True))
    return c


def os_set(**kw):
    c = os_cfg()
    for k, v in kw.items():
        if k in OS_OK and v in OS_OK[k]:
            c[k] = v
        elif k == "boxes" and isinstance(v, bool):
            c[k] = v
    try:
        OS_FILE.write_text(json.dumps(c))
    except Exception:
        pass
    return os_cfg()


def _os_leg(up, i, k0, a, o, h, l, c, cfg):
    """The live leg as of the bars BEFORE bar i (v2.31, pattern 20, "Open sweep"): the day's extreme so far was made at least 2 bars after the open and is well
    past the 9:30 open price (the sweep); price then turned and closed back through the open price; the move off the extreme is at least 1.5 ATR.
    The Golden zone is the pullback area 50-79% (or 62-79%) back down that move. Returns None when the leg is not valid or the zone was already tagged."""
    if i - k0 < 5:
        return None
    o9 = float(o[k0])
    gl, gh = (0.62, 0.79) if cfg["zone"] == "62-79" else (0.5, 0.79)
    if up:
        j = k0 + int(np.argmin(l[k0:i]))
        if j < k0 + 2 or j >= i - 1 or l[j] > o9 - 0.6 * a:
            return None
        ext = float(l[j])
        seg = h[j + 1:i]
        kh = j + 1 + int(np.argmax(seg))
        far = float(seg.max())
        if far - ext < 1.5 * a or c[j + 1:i].max() <= o9:
            return None
        rng = far - ext
        z_near, z_far = far - gl * rng, far - gh * rng            # near = top of the zone for a buy
        if kh + 1 < i - 3 and l[kh + 1:i - 3].min() <= z_near:
            return None                                              # tagged the zone more than 3 bars ago: that chance has gone
        if kh + 1 < i and c[kh + 1:i].min() < z_far - 0.25 * a:
            return None                                              # closed through the whole zone: the pullback is failing
    else:
        j = k0 + int(np.argmax(h[k0:i]))
        if j < k0 + 2 or j >= i - 1 or h[j] < o9 + 0.6 * a:
            return None
        ext = float(h[j])
        seg = l[j + 1:i]
        kh = j + 1 + int(np.argmin(seg))
        far = float(seg.min())
        if ext - far < 1.5 * a or c[j + 1:i].min() >= o9:
            return None
        rng = ext - far
        z_near, z_far = far + gl * rng, far + gh * rng            # near = bottom of the zone for a short
        if kh + 1 < i - 3 and h[kh + 1:i - 3].max() >= z_near:
            return None
        if kh + 1 < i and c[kh + 1:i].max() > z_far + 0.25 * a:
            return None
    return {"open": o9, "ext": ext, "far": far, "near": float(z_near), "deep": float(z_far), "j": j}


def _opensweep(d, o, h, l, c, atr, days, idx, cfg=None):
    """v2.31, pattern 20: Open sweep (the "86 model" style morning setup, both ways). BUY: price drops under the 9:30 open price and sweeps a low, turns and
    closes back over the open price, then pulls back into the Golden zone and a bullish candle holds it. Stop just under the sweep low; the target is the high
    of the move (when it pays at least 1R). SHORT is the mirror image. Only between 9:40 and the cut-off you choose (10:30, 11:00 or 11:30)."""
    cfg = cfg or os_cfg()
    uh, um = (int(x) for x in cfg["until"].split(":"))
    n, out = len(d), []
    first = {}
    for i in range(n):
        if (idx[i].hour, idx[i].minute) >= (9, 30):
            first.setdefault(days[i], i)
    for i in range(8, n):
        a = atr[i]
        t = (idx[i].hour, idx[i].minute)
        if not (a == a) or a <= 0 or days[i] not in first or t < (9, 40) or t >= (uh, um):
            continue
        k0 = first[days[i]]
        for up in (True, False):
            g = _os_leg(up, i, k0, a, o, h, l, c, cfg)
            if not g:
                continue
            if up:
                ok = l[i] <= g["near"] and c[i] > o[i] and c[i] >= g["deep"] - 0.25 * a and c[i] > g["ext"]
                stop = g["ext"] - 0.1 * a
                tp = g["far"]
            else:
                ok = h[i] >= g["near"] and c[i] < o[i] and c[i] <= g["deep"] + 0.25 * a and c[i] < g["ext"]
                stop = g["ext"] + 0.1 * a
                tp = g["far"]
            if not ok:
                continue
            nm = "Open sweep buy" if up else "Open sweep short"
            why = ("Price dropped under the 9:30 open and swept a low, turned back over the open, then pulled back into the Golden zone and held. " if up
                   else "Price popped over the 9:30 open and swept a high, turned back under the open, then bounced into the Golden zone and was rejected. ") + "Stop just past the sweep."
            out.append((i, "up" if up else "down", nm, why, {"stop": float(stop), "tp": float(tp), "zone": sorted([round(g["deep"], 2), round(g["near"], 2)]),
                                                          "open": round(g["open"], 2), "sweep": round(g["ext"], 2), "move_to": round(g["far"], 2)}))
    return out


def os_watch(d5, cfg=None):
    """What is forming right now for the latest day: {'side','status': 'watching'|'ready','zone':[lo,hi],'open','sweep','move_to','stop'} or None."""
    from . import jump as _jp
    cfg = cfg or os_cfg()
    if d5 is None or len(d5) < 40:
        return None
    d = _jp.prep(d5)
    o, h, l, c, atr = (d[k].values for k in ("open", "high", "low", "close", "atr"))
    idx, days = d.index, d.index.date
    n = len(d)
    day = days[-1]
    k0 = next((i for i in range(n) if days[i] == day and (idx[i].hour, idx[i].minute) >= (9, 30)), None)
    a = atr[-1]
    if k0 is None or not (a == a) or a <= 0:
        return None
    sigs = [x for x in _opensweep(d, o, h, l, c, atr, days, idx, cfg) if x[0] >= n - 2 and days[x[0]] == day]
    if sigs:
        x = sigs[-1]
        e = x[4]
        return {"side": x[1], "status": "ready", "zone": e["zone"], "open": e["open"], "sweep": e["sweep"], "move_to": e["move_to"], "stop": round(float(e["stop"]), 2),
                "t": idx[x[0]].strftime("%-I:%M %p"), "price": round(float(c[x[0]]), 2)}
    for up in (True, False):
        g = _os_leg(up, n, k0, a, o, h, l, c, cfg)
        if g:
            return {"side": "up" if up else "down", "status": "watching", "zone": [round(g["deep"], 2), round(g["near"], 2)] if up else [round(g["near"], 2), round(g["deep"], 2)],
                    "open": round(g["open"], 2), "sweep": round(g["ext"], 2), "move_to": round(g["far"], 2), "stop": round(float(g["ext"] - 0.1 * a if up else g["ext"] + 0.1 * a), 2),
                    "price": round(float(c[-1]), 2)}
    return None


def os_auto_state():
    """True when an Open sweep rule is switched on for automatic trading (PAPER; LIVE still needs your arming)."""
    return any(p.get("pattern") == "open_sweep" and p.get("enabled", True) and p.get("auto_paper") for p in load()["presets"])


def os_auto_set(on):
    found = [p for p in load()["presets"] if p.get("pattern") == "open_sweep"]
    if on:
        if found:
            for p in found:
                update(p["id"], enabled=True, auto_paper=True)
        else:
            add({"pattern": "open_sweep", "side": "both", "name": "Open sweep (auto)", "target_r": 2, "chop_skip": False}, True)
    else:
        for p in found:
            update(p["id"], enabled=False, auto_paper=False)
    return os_auto_state()


VR_FILE = DATA_DIR / "vwaprej.json"
VR_DEFAULT = {"after": "9:30", "candle": "bearish", "boxes": True}


def vr_cfg():
    c = dict(VR_DEFAULT)
    try:
        c.update(json.loads(VR_FILE.read_text()))
    except Exception:
        pass
    c["after"] = c["after"] if c["after"] in ("9:30", "10:00") else "9:30"
    c["candle"] = c["candle"] if c["candle"] in ("bearish", "any") else "bearish"
    c["boxes"] = bool(c["boxes"])
    return c


def vr_set(**kw):
    c = vr_cfg()
    ok = {"after": ("9:30", "10:00"), "candle": ("bearish", "any")}
    for k, v in kw.items():
        if v is None or k not in VR_DEFAULT or (k in ok and v not in ok[k]):
            continue
        c[k] = bool(v) if k == "boxes" else v
    c = dict(VR_DEFAULT, **c)
    try:
        VR_FILE.write_text(json.dumps(c))
    except Exception:
        pass
    return vr_cfg()


def _vwaprej(d, o, h, l, c, atr, days, vw, idx, cfg=None):
    """v2.29, pattern 18. SHORT: after the open (9:30 or 10:00) the stock makes a new low of the day, then rallies back up to VWAP, and a candle that
    touched VWAP closes back UNDER it (bearish close when 'bearish' is chosen). The stop sits just above that candle. BUY is the mirror image.
    Needs the stock to have been on the right side of VWAP when the extreme was made, so a stock that is simply chopping around VWAP never counts."""
    cfg = cfg or vr_cfg()
    hh, mm = (10, 0) if cfg["after"] == "10:00" else (9, 30)
    n, out = len(d), []
    first = {}
    for i in range(n):
        first.setdefault(days[i], i)
    for i in range(26, n):
        a = atr[i]
        if not (a == a) or a <= 0 or not (vw[i] == vw[i]) or days[i - 6] != days[i]:
            continue
        s0 = first[days[i]]
        reg = [k for k in range(s0, i + 1) if (idx[k].hour, idx[k].minute) >= (9, 30)]
        if len(reg) < 8 or (idx[i].hour, idx[i].minute) < (hh, mm) or (idx[i].hour, idx[i].minute) >= (16, 0):
            continue
        k0 = reg[0]
        win = [k for k in reg if k > k0 and k >= i - 24 and k < i]
        if not win:
            continue
        bear_ok = (c[i] < o[i]) if cfg["candle"] == "bearish" else True
        bull_ok = (c[i] > o[i]) if cfg["candle"] == "bearish" else True
        # ---- short: a new low of the day happened after the chosen time, price below VWAP then; now a poke up to VWAP is rejected ----
        lows = [k for k in win if (idx[k].hour, idx[k].minute) >= (hh, mm) and l[k] < l[k0:k].min() and c[k] < vw[k]]
        if lows and bear_ok and h[i] >= vw[i] * 0.998 and c[i] < vw[i] and (c[i] < vw[i] - 0.05 * a):
            stop = float(max(h[i], vw[i]) + 0.1 * a)
            out.append((i, "down", "VWAP rejection short", "After a new low of the day price rallied back to VWAP and was turned away: the candle closed under VWAP. Stop just above it.", {"stop": stop}))
            continue
        highs = [k for k in win if (idx[k].hour, idx[k].minute) >= (hh, mm) and h[k] > h[k0:k].max() and c[k] > vw[k]]
        if highs and bull_ok and l[i] <= vw[i] * 1.002 and c[i] > vw[i] and (c[i] > vw[i] + 0.05 * a):
            stop = float(min(l[i], vw[i]) - 0.1 * a)
            out.append((i, "up", "VWAP rejection buy", "After a new high of the day price dropped back to VWAP and held: the candle closed above VWAP. Stop just below it.", {"stop": stop}))
    return out


def _smc(d, o, h, l, c, atr, days):
    """Sweep + CHoCH + FVG retest. Long: a candle pokes under the last 12-candle low and closes back above it (the sweep); price then closes above the last
    lower high (change of character); the push leaves a fair value gap (candle 3's low above candle 1's high); entry is the first green candle that dips back
    into that gap and holds. Shorts mirror it. Stop sits just past the sweep. Returns (i, side, name, why, extra) tuples."""
    n, out = len(d), []
    for s_ in range(14, n - 3):
        if days[s_ - 12] != days[s_]:
            continue
        for up in (True, False):
            if up:
                prior = l[s_ - 12:s_].min()
                if not (l[s_] < prior and c[s_] > prior):
                    continue
                lh = h[s_ - 6:s_].max()
                k = next((q for q in range(s_ + 1, min(n, s_ + 13)) if days[q] == days[s_] and c[q] > lh), None)
            else:
                prior = h[s_ - 12:s_].max()
                if not (h[s_] > prior and c[s_] < prior):
                    continue
                lh = l[s_ - 6:s_].min()
                k = next((q for q in range(s_ + 1, min(n, s_ + 13)) if days[q] == days[s_] and c[q] < lh), None)
            if k is None:
                continue
            m = None
            for q in range(s_, k):
                if q + 1 <= k and q - 1 >= 0 and ((up and l[q + 1] > h[q - 1]) or ((not up) and h[q + 1] < l[q - 1])):
                    m = q
            if m is None:
                continue
            zone = (h[m - 1], l[m + 1]) if up else (h[m + 1], l[m - 1])      # (bottom, top)
            zb, zt = (min(zone), max(zone))
            ob = next((q for q in range(k - 1, s_ - 1, -1) if (c[q] < o[q] if up else c[q] > o[q])), None)
            for i in range(k + 1, min(n, k + 13)):
                if days[i] != days[s_]:
                    break
                touch = l[i] <= zt if up else h[i] >= zb
                hold = c[i] > zb if up else c[i] < zt
                green = c[i] > o[i] if up else c[i] < o[i]
                if touch and hold and green and zt > zb:
                    a = atr[i] if atr[i] == atr[i] else 0
                    stop = (l[s_:i + 1].min() - 0.1 * a) if up else (h[s_:i + 1].max() + 0.1 * a)
                    out.append((i, "up" if up else "down", "Sweep + CHoCH + FVG" if up else "Sweep + CHoCH + FVG (short)",
                                ("Price swept the low under the recent lows and snapped back, broke the last lower high (change of character), left a gap on the way up, and has now pulled back into that gap and held." if up else
                                 "Price swept the high above the recent highs and snapped back, broke the last higher low (change of character), left a gap on the way down, and has now bounced into that gap and failed."),
                                {"stop": float(stop), "sweep": s_, "choch": k, "zone": [round(float(zb), 2), round(float(zt), 2)], "ob": ob}))
                    break
    return out


def _grade(h, l, c, atr, p, b, lvl, up, broke):
    """Zone strength: strong = few touches and price left fast; weak = worn out by many touches, or price barely left."""
    a = atr[b] if atr[b] == atr[b] and atr[b] > 0 else 0
    if a <= 0:
        return "ok"
    lo = max(0, p - 40)
    near = (h[lo:b + 1] >= lvl - 0.25 * a) & (h[lo:b + 1] <= lvl + 0.25 * a) if (up and broke) or ((not up) and not broke) else \
        (l[lo:b + 1] >= lvl - 0.25 * a) & (l[lo:b + 1] <= lvl + 0.25 * a)
    touches, prev = 0, -9
    for k in range(len(near)):
        if near[k] and k - prev >= 3:
            touches += 1
            prev = k
    seg = c[p:min(len(c), p + 12)] if not broke else c[b:min(len(c), b + 5)]
    leave = (float(seg.max()) - lvl) / a if up else (lvl - float(seg.min())) / a
    if touches >= 4 or leave < 0.4:
        return "weak"
    if touches <= 2 and leave >= 1.2:
        return "strong"
    return "ok"


def _zone(d, o, h, l, c, atr, days):
    """Zones from swing highs / lows (3 candles each side). (1) Break and retest: a candle closes through a swing level, price comes back to it and holds
    (a green candle for a long, red for a short): the broken zone flipped. (2) Support / resistance bounce: price returns to a level that already held twice
    and reverses off it. Stop sits just past the zone. Target: the prior swing high / low. Returns (i, side, name, why, extra) tuples."""
    n, out, K = len(d), [], 3
    hp = [p for p in range(K, n - K) if h[p] == h[p - K:p + K + 1].max()]
    lp = [p for p in range(K, n - K) if l[p] == l[p - K:p + K + 1].min()]
    for up in (True, False):
        piv = hp if up else lp                           # long: broken resistance; short: broken support
        for p in piv:
            a = atr[p + K] if atr[p + K] == atr[p + K] else 0
            if a <= 0:
                continue
            lvl = h[p] if up else l[p]
            b = next((q for q in range(p + K + 1, min(n, p + 60)) if (c[q] > lvl + 0.1 * a if up else c[q] < lvl - 0.1 * a)), None)
            if b is None:
                continue
            for i in range(b + 1, min(n, b + 16)):
                if days[i] != days[b]:
                    break
                touch = l[i] <= lvl + 0.2 * a if up else h[i] >= lvl - 0.2 * a
                hold = c[i] > lvl if up else c[i] < lvl
                col = c[i] > o[i] if up else c[i] < o[i]
                if touch and hold and col:
                    lo_, hi_ = (lvl - 0.2 * a, lvl + 0.2 * a)
                    stop = (min(l[b:i + 1].min(), lvl - 0.2 * a) - 0.1 * a) if up else (max(h[b:i + 1].max(), lvl + 0.2 * a) + 0.1 * a)
                    tp = h[max(0, p - 40):b + 1].max() if up else l[max(0, p - 40):b + 1].min()
                    gr = _grade(h, l, c, atr, p, b, lvl, up, True)
                    out.append((i, "up" if up else "down", "Zone retest" if up else "Zone retest (short)",
                                f"Price closed {'above' if up else 'below'} the {'resistance' if up else 'support'} near {lvl:.2f}, came back to it and held: the broken zone flipped. Target: the prior swing {'high' if up else 'low'}.",
                                {"stop": float(stop), "tp": float(tp), "zone": [round(float(lo_), 2), round(float(hi_), 2)], "zs": b, "zlabel": "Zone · " + gr.capitalize(), "grade": gr}))
                    break
        # support / resistance bounce: a level that held before (two swing lows / highs within 0.25 ATR), price returns and reverses off it
        pv = lp if up else hp
        for x in range(1, len(pv)):
            p, q = pv[x], pv[x - 1]
            a = atr[p + K] if atr[p + K] == atr[p + K] else 0
            if a <= 0 or p - q < 4 or p - q > 60 or abs((l[p] - l[q]) if up else (h[p] - h[q])) > 0.25 * a:
                continue
            lvl = min(l[p], l[q]) if up else max(h[p], h[q])
            for i in range(p + K + 1, min(n, p + K + 30)):
                if days[i] != days[p]:
                    break
                broke = (c[i] < lvl - 0.3 * a) if up else (c[i] > lvl + 0.3 * a)
                if broke:
                    break
                touch = l[i] <= lvl + 0.15 * a if up else h[i] >= lvl - 0.15 * a
                col = (c[i] > o[i] and c[i] > lvl) if up else (c[i] < o[i] and c[i] < lvl)
                if touch and col:
                    stop = (min(l[i], lvl) - 0.3 * a) if up else (max(h[i], lvl) + 0.3 * a)
                    tp = h[q:i + 1].max() if up else l[q:i + 1].min()
                    gr = _grade(h, l, c, atr, p, i, lvl, up, False)
                    out.append((i, "up" if up else "down", "Support bounce" if up else "Resistance rejection",
                                f"Price came back to {lvl:.2f}, a {'support' if up else 'resistance'} that already held twice, and reversed off it. Target: the swing {'high' if up else 'low'} since.",
                                {"stop": float(stop), "tp": float(tp), "zone": [round(float(lvl - 0.15 * a), 2), round(float(lvl + 0.15 * a), 2)], "zs": q, "zlabel": "Level · " + gr.capitalize(), "grade": gr}))
                    break
    return out


# ---------------- v2.19: candlestick, chart-shape and indicator patterns ----------------
def _er(c, i, n=12):
    """Efficiency ratio over n bars: 1 = a straight run, near 0 = going nowhere (chop)."""
    if i < n:
        return 1.0
    seg = c[i - n:i + 1]
    path = float(abs(seg[1:] - seg[:-1]).sum())
    return 1.0 if path <= 0 else abs(float(seg[-1] - seg[0])) / path


CHOP_ER = 0.22


def _ok_stop(px, stop):
    d = abs(px - stop)
    return px * 0.0005 <= d <= px * 0.04


def _candles(pat, d, o, h, l, c, atr, days):
    """Candlestick patterns (all need the move before them: a bullish reversal after a drop, a bearish one after a rise)."""
    n, out = len(d), []
    for i in range(6, n):
        a = atr[i]
        if not (a == a) or a <= 0 or days[i - 3] != days[i]:
            continue
        body = abs(c[i] - o[i])
        down_before = c[i - 1] < c[i - 4] and c[i - 1] < c[i - 2]
        up_before = c[i - 1] > c[i - 4] and c[i - 1] > c[i - 2]
        res = []                                   # (up, name, why, stop)
        if pat == "engulfing":
            pb = abs(c[i - 1] - o[i - 1])
            if body >= 0.3 * a and body > pb:
                if c[i - 1] < o[i - 1] and c[i] > o[i] and o[i] <= c[i - 1] and c[i] >= o[i - 1] and down_before:
                    res.append((True, "Bullish engulfing", "A green candle swallowed the whole red candle before it after a drop: buyers took over.", min(l[i], l[i - 1]) - 0.1 * a))
                if c[i - 1] > o[i - 1] and c[i] < o[i] and o[i] >= c[i - 1] and c[i] <= o[i - 1] and up_before:
                    res.append((False, "Bearish engulfing", "A red candle swallowed the whole green candle before it after a rise: sellers took over.", max(h[i], h[i - 1]) + 0.1 * a))
        elif pat == "hammer":
            rng = h[i] - l[i]
            lw, uw = min(o[i], c[i]) - l[i], h[i] - max(o[i], c[i])
            if rng >= 0.6 * a and body > 0:
                if lw >= 2 * body and uw <= 0.6 * body + 0.05 * rng and down_before:
                    res.append((True, "Hammer", "A long tail under the candle after a drop: sellers pushed down but buyers slammed it back up.", l[i] - 0.1 * a))
                if uw >= 2 * body and lw <= 0.6 * body + 0.05 * rng and up_before:
                    res.append((False, "Shooting star", "A long wick above the candle after a rise: buyers pushed up but sellers slammed it back down.", h[i] + 0.1 * a))
        elif pat == "star":
            b2, b1 = abs(c[i - 2] - o[i - 2]), abs(c[i - 1] - o[i - 1])
            if b2 >= 0.6 * a and b1 <= 0.35 * b2 and body >= 0.3 * a:
                mid = (o[i - 2] + c[i - 2]) / 2
                if c[i - 2] < o[i - 2] and c[i] > o[i] and c[i] > mid and down_before_n(c, i - 1):
                    res.append((True, "Morning star", "A big red candle, a small pause candle, then a big green candle back over the middle of the red one: the drop is over.", min(l[i - 2:i + 1]) - 0.1 * a))
                if c[i - 2] > o[i - 2] and c[i] < o[i] and c[i] < mid and up_before_n(c, i - 1):
                    res.append((False, "Evening star", "A big green candle, a small pause candle, then a big red candle back under the middle of the green one: the rise is over.", max(h[i - 2:i + 1]) + 0.1 * a))
        elif pat == "inside3":
            b2 = abs(c[i - 2] - o[i - 2])
            if b2 >= 0.6 * a:
                top2, bot2 = max(o[i - 2], c[i - 2]), min(o[i - 2], c[i - 2])
                inside = max(o[i - 1], c[i - 1]) < top2 and min(o[i - 1], c[i - 1]) > bot2
                if inside and c[i - 2] < o[i - 2] and c[i - 1] > o[i - 1] and c[i] > o[i] and c[i] > o[i - 2] and down_before_n(c, i - 1):
                    res.append((True, "Three inside up", "A big red candle, a small green one inside it, then a green candle closing above the red one's open.", min(l[i - 2:i + 1]) - 0.1 * a))
                if inside and c[i - 2] > o[i - 2] and c[i - 1] < o[i - 1] and c[i] < o[i] and c[i] < o[i - 2] and up_before_n(c, i - 1):
                    res.append((False, "Three inside down", "A big green candle, a small red one inside it, then a red candle closing under the green one's open.", max(h[i - 2:i + 1]) + 0.1 * a))
        elif pat == "outside3":
            b1 = abs(c[i - 1] - o[i - 1])
            if b1 >= 0.5 * a:
                if c[i - 2] < o[i - 2] and c[i - 1] > o[i - 1] and o[i - 1] <= c[i - 2] and c[i - 1] >= o[i - 2] and c[i] > o[i] and c[i] > c[i - 1]:
                    res.append((True, "Three outside up", "A green candle swallowed the red one, then the next candle closed even higher: confirmed reversal up.", min(l[i - 2:i + 1]) - 0.1 * a))
                if c[i - 2] > o[i - 2] and c[i - 1] < o[i - 1] and o[i - 1] >= c[i - 2] and c[i - 1] <= o[i - 2] and c[i] < o[i] and c[i] < c[i - 1]:
                    res.append((False, "Three outside down", "A red candle swallowed the green one, then the next candle closed even lower: confirmed reversal down.", max(h[i - 2:i + 1]) + 0.1 * a))
        for up, nm, why, stop in res:
            if _ok_stop(c[i], stop):
                out.append((i, "up" if up else "down", nm, why, {"stop": float(stop)}))
    return out


def down_before_n(c, j):
    return j >= 3 and c[j] < c[j - 3]


def up_before_n(c, j):
    return j >= 3 and c[j] > c[j - 3]


def _pivots(h, l, K=3):
    n = len(h)
    hp = [p for p in range(K, n - K) if h[p] == h[p - K:p + K + 1].max() and h[p] > h[p - 1]]
    lp = [p for p in range(K, n - K) if l[p] == l[p - K:p + K + 1].min() and l[p] < l[p - 1]]
    return hp, lp


def _shapes(pat, d, o, h, l, c, atr, days):
    """Head and shoulders, double top / bottom, symmetrical triangle, trend-line break. Only pivots already confirmed (3 candles old) are used."""
    n, out, K = len(d), [], 3
    hp, lp = _pivots(h, l, K)
    if pat == "hs":
        for up in (False, True):                     # False: head and shoulders top (short). True: inverse (long)
            pv, opp = (lp, hp) if up else (hp, lp)
            ex = l if up else h
            ox = h if up else l
            for x in range(2, len(pv)):
                a_, b_, c_ = pv[x - 2], pv[x - 1], pv[x]
                a = atr[c_ + K] if atr[c_ + K] == atr[c_ + K] else 0
                if a <= 0 or c_ - a_ > 70:
                    continue
                head = (ex[b_] < min(ex[a_], ex[c_]) - 0.8 * a) if up else (ex[b_] > max(ex[a_], ex[c_]) + 0.8 * a)
                if not head or abs(ex[a_] - ex[c_]) > 1.0 * a:
                    continue
                t1 = [q for q in opp if a_ < q < b_]
                t2 = [q for q in opp if b_ < q < c_]
                if not t1 or not t2:
                    continue
                neck = float((ox[t1].max() + ox[t2].max()) / 2) if up else float((ox[t1].min() + ox[t2].min()) / 2)
                for i in range(c_ + K + 1, min(n, c_ + K + 25)):
                    if days[i] != days[c_]:
                        break
                    if (up and c[i] > neck) or ((not up) and c[i] < neck):
                        stop = (ex[c_] - 0.1 * a) if up else (ex[c_] + 0.1 * a)
                        tp = neck + (neck - ex[b_]) if up else neck - (ex[b_] - neck)
                        if _ok_stop(c[i], stop):
                            out.append((i, "up" if up else "down", "Inverse head & shoulders" if up else "Head & shoulders",
                                        ("Three lows with the middle one lowest (the head), then price closed back above the neckline: the downtrend is breaking." if up else
                                         "Three highs with the middle one highest (the head), then price closed under the neckline: the uptrend is breaking.") + " Target: the head-to-neckline height.",
                                        {"stop": float(stop), "tp": float(tp), "zone": [round(float(neck - 0.1 * a), 2), round(float(neck + 0.1 * a), 2)], "zs": a_, "zlabel": "Neckline"}))
                        break
    elif pat == "dbl":
        for up in (False, True):                     # False: double top (short); True: double bottom (long)
            pv, opp = (lp, hp) if up else (hp, lp)
            ex = l if up else h
            ox = h if up else l
            for x in range(1, len(pv)):
                p, q = pv[x], pv[x - 1]
                a = atr[p + K] if atr[p + K] == atr[p + K] else 0
                if a <= 0 or p - q < 6 or p - q > 60 or abs(ex[p] - ex[q]) > 0.3 * a:
                    continue
                mid = [m for m in opp if q < m < p]
                if not mid:
                    continue
                neck = ox[mid].max() if up else ox[mid].min()
                if abs(neck - (ex[p] + ex[q]) / 2) < 1.0 * a:
                    continue
                for i in range(p + K + 1, min(n, p + K + 25)):
                    if days[i] != days[p]:
                        break
                    if (up and c[i] > neck) or ((not up) and c[i] < neck):
                        stop = (min(ex[p], ex[q]) - 0.1 * a) if up else (max(ex[p], ex[q]) + 0.1 * a)
                        tp = neck + (neck - ex[p]) if up else neck - (ex[p] - neck)
                        if _ok_stop(c[i], stop):
                            out.append((i, "up" if up else "down", "Double bottom" if up else "Double top",
                                        ("Price hit the same low twice and failed to go lower, then closed above the middle peak: buyers defended the floor." if up else
                                         "Price hit the same high twice and failed to go higher, then closed under the middle dip: sellers defended the ceiling.") + " Target: the same height again.",
                                        {"stop": float(stop), "tp": float(tp), "zone": [round(float(neck - 0.1 * a), 2), round(float(neck + 0.1 * a), 2)], "zs": q, "zlabel": "Neckline"}))
                        break
    elif pat == "tri":
        for i in range(30, n):
            a = atr[i] if atr[i] == atr[i] else 0
            if a <= 0:
                continue
            ph = [p for p in hp if i - 50 <= p <= i - K - 1 and days[p] == days[i]]
            pl = [p for p in lp if i - 50 <= p <= i - K - 1 and days[p] == days[i]]
            if len(ph) < 2 or len(pl) < 2:
                continue
            h1, h2, l1, l2 = ph[-2], ph[-1], pl[-2], pl[-1]
            if not (h[h2] < h[h1] - 0.2 * a and l[l2] > l[l1] + 0.2 * a) or h2 - h1 < 4 or l2 - l1 < 4:
                continue
            up_line = lambda t: h[h1] + (h[h2] - h[h1]) * (t - h1) / (h2 - h1)
            lo_line = lambda t: l[l1] + (l[l2] - l[l1]) * (t - l1) / (l2 - l1)
            if up_line(i) - lo_line(i) < 0.5 * a:
                continue
            start = min(h1, l1)
            height = h[h1] - l[l1]
            if c[i] > up_line(i) + 0.1 * a and c[i - 1] <= up_line(i - 1) + 0.1 * a:
                stop = l[l2] - 0.1 * a
                if _ok_stop(c[i], stop):
                    out.append((i, "up", "Triangle breakout", "Highs getting lower and lows getting higher squeezed price into a point, then it closed above the top line. Target: the triangle's height.",
                                {"stop": float(stop), "tp": float(c[i] + height), "zone": [round(float(l[l2]), 2), round(float(h[h2]), 2)], "zs": start, "zlabel": "Triangle"}))
            elif c[i] < lo_line(i) - 0.1 * a and c[i - 1] >= lo_line(i - 1) - 0.1 * a:
                stop = h[h2] + 0.1 * a
                if _ok_stop(c[i], stop):
                    out.append((i, "down", "Triangle breakdown", "Highs getting lower and lows getting higher squeezed price into a point, then it closed under the bottom line. Target: the triangle's height.",
                                {"stop": float(stop), "tp": float(c[i] - height), "zone": [round(float(l[l2]), 2), round(float(h[h2]), 2)], "zs": start, "zlabel": "Triangle"}))
    elif pat == "tline":
        for i in range(25, n):
            a = atr[i] if atr[i] == atr[i] else 0
            if a <= 0:
                continue
            ph = [p for p in hp if i - 45 <= p <= i - K - 1 and days[p] == days[i]]
            pl = [p for p in lp if i - 45 <= p <= i - K - 1 and days[p] == days[i]]
            if len(ph) >= 2 and h[ph[-1]] < h[ph[-2]] and ph[-1] - ph[-2] >= 6:
                p1, p2 = ph[-2], ph[-1]
                ln = lambda t: h[p1] + (h[p2] - h[p1]) * (t - p1) / (p2 - p1)
                if c[i] > ln(i) + 0.1 * a and all(c[t] <= ln(t) + 0.1 * a for t in range(p2, i)):
                    stop = l[max(p2, i - 10):i + 1].min() - 0.1 * a
                    if _ok_stop(c[i], stop):
                        out.append((i, "up", "Trend-line break up", "Price had been making lower highs along a falling line and just closed above it: the downtrend line broke.", {"stop": float(stop)}))
            if len(pl) >= 2 and l[pl[-1]] > l[pl[-2]] and pl[-1] - pl[-2] >= 6:
                p1, p2 = pl[-2], pl[-1]
                ln = lambda t: l[p1] + (l[p2] - l[p1]) * (t - p1) / (p2 - p1)
                if c[i] < ln(i) - 0.1 * a and all(c[t] >= ln(t) - 0.1 * a for t in range(p2, i)):
                    stop = h[max(p2, i - 10):i + 1].max() + 0.1 * a
                    if _ok_stop(c[i], stop):
                        out.append((i, "down", "Trend-line break down", "Price had been making higher lows along a rising line and just closed under it: the uptrend line broke.", {"stop": float(stop)}))
    return out


def _indic(pat, d, o, h, l, c, e9, e20, vw, va, v, atr, days, vm):
    from .indicators import rsi as _rsi
    n, out = len(d), []
    r = _rsi(d["close"], 14).values if pat == "rsi_turn" else None
    for i in range(26, n):
        if days[i - 6] != days[i] or not (atr[i] == atr[i]) or atr[i] <= 0:
            continue
        volok = vm <= 0 or (va[i] == va[i] and va[i] > 0 and v[i] >= vm * va[i])
        if pat == "macross" and volok:
            if e9[i] > e20[i] and e9[i - 1] <= e20[i - 1] and c[i] > e20[i] and e20[i] > e20[i - 3]:
                out.append((i, "up", "MA cross up", "The fast average crossed above the slow one with the slow one rising."))
            elif e9[i] < e20[i] and e9[i - 1] >= e20[i - 1] and c[i] < e20[i] and e20[i] < e20[i - 3]:
                out.append((i, "down", "MA cross down", "The fast average crossed under the slow one with the slow one falling."))
        elif pat == "rsi_turn" and volok:
            if e9[i] > e20[i] and c[i] > e20[i] and r[i - 1] < 42 <= r[i]:
                out.append((i, "up", "RSI turn up", "In an uptrend, RSI dipped into the 30s-40s and turned back up: a pullback ending."))
            elif e9[i] < e20[i] and c[i] < e20[i] and r[i - 1] > 58 >= r[i]:
                out.append((i, "down", "RSI turn down", "In a downtrend, RSI bounced into the 60s and turned back down: a bounce failing."))
    return out


def scan(rules, d5):
    """Signals for one rule set on 5-minute bars (oldest first): {i, t, d, side('up'|'down'), price, stop, tp1, why}."""
    if d5 is None or len(d5) < 40:
        return []
    d = jp.prep(d5)
    n = len(d)
    o, h, l, c, v = (d[k].values for k in ("open", "high", "low", "close", "volume"))
    e9, e20, atr, va, vw = (d[k].values for k in ("ema9", "ema20", "atr", "vavg", "vwap"))
    idx, days = d.index, d.index.date
    want_up, want_dn = rules["side"] in ("long", "both"), rules["side"] in ("short", "both")
    pat, L = rules["pattern"], int(rules["lookback"])
    vm = rules["vol_mult"]
    raw = []
    if pat == "pullback":
        for s in jp.scan(d5):
            if s["kind"] == "in":
                raw.append((s["i"], s["side"], s["name"], s["why"]))
    elif pat == "candle":
        for sub in ("engulfing", "hammer", "star", "inside3", "outside3"):
            raw += _candles(sub, d, o, h, l, c, atr, days)
    elif pat in ("hs", "dbl", "tri", "tline"):
        raw += _shapes(pat, d, o, h, l, c, atr, days)
    elif pat in ("macross", "rsi_turn"):
        raw += _indic(pat, d, o, h, l, c, e9, e20, vw, va, v, atr, days, vm)
    elif pat == "smc":
        raw += _smc(d, o, h, l, c, atr, days)
    elif pat == "vwap_rej":
        raw += _vwaprej(d, o, h, l, c, atr, days, vw, idx)
    elif pat == "cycle":
        raw += _cycle(d, o, h, l, c, atr, days, e9)
    elif pat == "open_sweep":
        raw += _opensweep(d, o, h, l, c, atr, days, idx)
    elif pat == "zone":
        raw += _zone(d, o, h, l, c, atr, days)
    else:
        last_gap_day = {}
        for i in range(max(26, L + 1), n):
            if days[i - 6] != days[i] or not (atr[i] == atr[i]) or atr[i] <= 0:
                continue
            volok = vm <= 0 or (va[i] == va[i] and va[i] > 0 and v[i] >= vm * va[i])
            up_tr, dn_tr = e9[i] > e20[i], e9[i] < e20[i]
            if pat == "vwap_reclaim" and vw[i] == vw[i] and vw[i - 1] == vw[i - 1] and volok:
                if c[i] > vw[i] and c[i - 1] <= vw[i - 1] and up_tr:
                    raw.append((i, "up", "VWAP reclaim", "Price crossed back above VWAP with the trend up."))
                elif c[i] < vw[i] and c[i - 1] >= vw[i - 1] and dn_tr:
                    raw.append((i, "down", "VWAP loss", "Price crossed back under VWAP with the trend down."))
            elif pat == "breakout" and volok:
                if c[i] > h[i - L:i].max() and up_tr:
                    raw.append((i, "up", "Breakout", f"Closed above the high of the last {L} candles."))
                elif c[i] < l[i - L:i].min() and dn_tr:
                    raw.append((i, "down", "Breakdown", f"Closed below the low of the last {L} candles."))
            elif pat == "gap_go":
                day = days[i]
                if day in last_gap_day or not ((9, 30) <= (idx[i].hour, idx[i].minute) <= (11, 0)):
                    continue
                prev = [k for k in range(i) if days[k] != day]
                today = [k for k in range(i + 1) if days[k] == day and (idx[k].hour, idx[k].minute) >= (9, 30)]
                if not prev or not today or (idx[i].hour, idx[i].minute) > (11, 0):
                    continue
                pc = [k for k in prev if days[k] == days[prev[-1]] and (idx[k].hour, idx[k].minute) < (16, 0)]
                if not pc:
                    continue
                gap = (o[today[0]] - c[pc[-1]]) / c[pc[-1]] * 100
                if abs(gap) < rules["gap_pct"]:
                    continue
                if gap > 0 and c[i] > o[today[0]] and c[i] > c[i - 1] and volok:
                    raw.append((i, "up", "Gap and go", f"Gapped up {gap:.1f}% and is holding above the open."))
                    last_gap_day[day] = i
                elif gap < 0 and c[i] < o[today[0]] and c[i] < c[i - 1] and volok:
                    raw.append((i, "down", "Gap down and go", f"Gapped down {abs(gap):.1f}% and is staying under the open."))
                    last_gap_day[day] = i
    out, last = [], {"up": -99, "down": -99}
    for item in sorted(raw, key=lambda r: r[0]):
        i, side, name, why = item[:4]
        ex = item[4] if len(item) > 4 else {}
        up = side == "up"
        if (up and not want_up) or ((not up) and not want_dn) or i - last[side] <= 8:
            continue
        if c[i] < rules["min_price"]:
            continue
        if rules.get("chop_skip") and pat != "tri" and _er(c, i) < CHOP_ER:
            STATS["chop"] = STATS.get("chop", 0) + 1
            continue
        if rules.get("zone_grade") and ex.get("grade") == "weak":
            STATS["weak"] = STATS.get("weak", 0) + 1
            continue
        hh, mm = idx[i].hour, idx[i].minute
        if not rules["after_hours"] and not ((hh, mm) >= (9, 30) and hh < 16):
            continue
        if rules["above_vwap"] and pat in ("pullback", "breakout", "gap_go", "macross", "rsi_turn") and vw[i] == vw[i] and ((up and c[i] <= vw[i]) or ((not up) and c[i] >= vw[i])):
            continue
        px = float(c[i])
        dist = max(px * rules["stop_pct"] / 100.0, 0.01)
        if ex.get("stop"):                                   # structure stop (SMC: just past the sweep)
            dist = abs(px - ex["stop"])
            if dist < px * 0.0005 or dist > px * 0.04:
                continue
        stop = px - dist if up else px + dist
        tp = px + rules["target_r"] * dist if up else px - rules["target_r"] * dist
        if ex.get("tp"):                                     # structure target (prior swing), only when it pays at least 1R and at most 6R
            rew = abs(ex["tp"] - px)
            if dist <= rew <= 6 * dist and ((up and ex["tp"] > px) or ((not up) and ex["tp"] < px)):
                tp = ex["tp"]
        out.append(dict({k: v for k, v in ex.items() if k not in ("stop", "tp")}, **{"i": i, "t": idx[i].strftime("%H:%M"), "d": idx[i].strftime("%a %b %d"), "day": str(days[i]), "side": side, "name": name, "why": why,
                    "price": round(px, 2), "stop": round(stop, 2), "tp1": round(tp, 2)}))
        last[side] = i
    return out


def backtest(rules, d5, horizon=24, sigs=None):
    """Did price reach the target before the stop, within `horizon` bars (2 hours) on the same day? A bar touching both counts as the stop."""
    res = {"n": 0, "hit": 0, "fail": 0, "exp": 0, "rate": None, "avg_r": None, "avg_pct": None}
    if d5 is None or len(d5) < 40:
        return res
    sigs = scan(rules, d5) if sigs is None else sigs
    hi, lo, cl, days = d5["high"].values, d5["low"].values, d5["close"].values, d5.index.date
    rs, pcts = [], []
    for s in sigs:
        i, up = s["i"], s["side"] == "up"
        risk = abs(s["price"] - s["stop"]) or 0.01
        r = None
        end = min(len(d5) - 1, i + horizon)
        j = i
        for j in range(i + 1, end + 1):
            if days[j] != days[i]:
                j -= 1
                break
            stp = lo[j] <= s["stop"] if up else hi[j] >= s["stop"]
            tgt = hi[j] >= s["tp1"] if up else lo[j] <= s["tp1"]
            if stp:
                r = -1.0
                res["fail"] += 1
                break
            if tgt:
                r = rules["target_r"]
                res["hit"] += 1
                break
        if r is None:
            if j <= i:
                continue                                    # no later bar yet: still open
            r = ((cl[j] - s["price"]) if up else (s["price"] - cl[j])) / risk
            res["exp"] += 1
        res["n"] += 1
        rs.append(float(r))
        pcts.append(float(r * risk / s["price"] * 100))
    done = res["hit"] + res["fail"]
    if done >= 3:
        res["rate"] = round(res["hit"] / done * 100)
    if len(rs) >= 4:                                         # v2.32: older half vs newer half, so one lucky streak cannot pass for a record
        h = len(rs) // 2
        res["avg_old"], res["avg_new"] = round(sum(rs[:h]) / h, 2), round(sum(rs[h:]) / (len(rs) - h), 2)
    if rs:
        res["avg_r"] = round(sum(rs) / len(rs), 2)
        res["avg_pct"] = round(sum(pcts) / len(pcts), 2)
    return res


def merge_tests(parts):
    t = {"n": 0, "hit": 0, "fail": 0, "exp": 0}
    rs = []
    for p in parts:
        for k in t:
            t[k] += p.get(k, 0)
        if p.get("avg_r") is not None:
            rs.append((p["avg_r"], p["n"]))
    done = t["hit"] + t["fail"]
    t["rate"] = round(t["hit"] / done * 100) if done >= 3 else None
    tot = sum(n for _, n in rs)
    t["avg_r"] = round(sum(r * n for r, n in rs) / tot, 2) if tot else None
    return t


def chart(d5, sigs, bars=80, focus=None):
    """Compact bars + lines + markers for the phone to draw as an image. Window ends just after the focus signal (or the last bar)."""
    if d5 is None or len(d5) < 20:
        return None
    d = jp.prep(d5)
    end = len(d)
    if focus is not None:
        end = min(len(d), focus["i"] + 12)
    a = max(0, end - bars)
    w = d.iloc[a:end]
    cl_all = d["close"].values
    rows = [{"t": ix.strftime("%H:%M"), "d": ix.strftime("%b %d"), "o": round(float(r.open), 2), "h": round(float(r.high), 2), "l": round(float(r.low), 2),
             "c": round(float(r.close), 2), "v": int(r.volume), "f": None if r.ema9 != r.ema9 else round(float(r.ema9), 2),
             "s": None if r.ema20 != r.ema20 else round(float(r.ema20), 2), "w": None if r.vwap != r.vwap else round(float(r.vwap), 2),
             "g": 1 if _er(cl_all, a + k) < CHOP_ER else 0} for k, (ix, r) in enumerate(w.iterrows())]
    marks = []
    for s in sigs:
        if a <= s["i"] < end:
            m = {"j": s["i"] - a, "side": s["side"], "price": s["price"], "stop": s["stop"], "tp1": s["tp1"], "name": s["name"]}
            if "sweep" in s:
                m.update(sw=s["sweep"] - a, ch=s["choch"] - a, zone=s["zone"], zs=s["choch"] - a, zl="FVG zone")
            elif "zone" in s:
                m.update(zone=s["zone"], zs=max(0, s.get("zs", s["i"]) - a), zl=s.get("zlabel", "Zone"))
            marks.append(m)
    return {"bars": rows, "marks": marks[-6:]}


# ---------------- AI: words / screenshots -> rules ----------------
SYSTEM = ("You turn a trader's description (and optional chart screenshots) into ONE trading preset for a rule engine. "
          "Reply with ONLY a JSON object with these keys: name (short), pattern (one of pullback, vwap_reclaim, breakout, gap_go, smc, zone, candle, hs, dbl, tri, tline, macross, rsi_turn), "
          "side (long, short or both), stop_pct (0.2-5, percent distance of the stop), target_r (0.5-5, target as a multiple of the risk), "
          "vol_mult (0-5, volume must be this many times the recent average; 0 = ignore), above_vwap (true/false), lookback (5-60 candles, for breakout), "
          "gap_pct (0.5-20, for gap_go), after_hours (true/false: do extended-hours candles count), notes (one plain sentence: what you saw or assumed). "
          "pullback = trend, pull back to the moving average, confirming candle (the app's JUMP IN). vwap_reclaim = price crosses VWAP with the trend. "
          "breakout = closes beyond the recent high/low. gap_go = gaps at the open and keeps going. smc = liquidity sweep of a low/high, then a change of character "
          "(CHoCH), then entry on the retest of the fair value gap / order block (use it for smart-money, SMC, liquidity-sweep or FVG setups). "
          "zone = support/resistance zones: break of a swing level then a retest that holds, or a bounce off a level that held twice, target the prior swing (use it for support, resistance, supply/demand, retest or range-bounce setups). candle = any candlestick reversal (engulfing, hammer or shooting star, morning/evening star, three inside, three outside); hs = head and shoulders (or inverse); dbl = double top/bottom; tri = symmetrical triangle breakout; tline = trend-line break; macross = fast/slow moving-average cross; rsi_turn = RSI turning back with the trend. If a screenshot shows markers like JUMP IN, BUY, SELL or "
          "BUY? / SELL?, base the preset on the setup those markers point at. Never mention position size, loss limits or Live trading.")


def from_text(text, images=None):
    """Returns (rules, how). Uses the chosen AI provider; without a key falls back to simple keyword rules (text only)."""
    text = (text or "").strip()
    try:
        from .analyst import _api_error, _pick_model, ai_key, ai_post
        key = ai_key()
    except Exception:
        key = ""
    if key:
        content = [{"type": "image", "source": {"type": "base64", "media_type": im["media_type"], "data": im["data"]}} for im in (images or [])]
        content.append({"type": "text", "text": text or "Make a preset from the setup shown in the attached chart."})
        r = ai_post(120, {"model": _pick_model(key), "max_tokens": 700, "system": SYSTEM, "messages": [{"role": "user", "content": content}]})
        if r.status_code != 200:
            raise RuntimeError(_api_error(r.status_code, r.text))
        out = "".join(b.get("text", "") for b in r.json().get("content", []))
        m = re.search(r"\{.*\}", out, re.S)
        if not m:
            raise RuntimeError("The AI did not return a preset. Try describing the setup differently.")
        try:
            raw = json.loads(m.group(0))
        except json.JSONDecodeError:
            raise RuntimeError("The AI's answer was cut off. Try again.")
        return normalize(raw), "ai"
    if images:
        raise RuntimeError("Reading screenshots needs your AI key (Broker keys, AI). Describe the setup in words instead.")
    return keyword_rules(text), "keywords"


def keyword_rules(text):
    t = text.lower()
    r = dict(DEFAULTS)
    r["pattern"] = (re.search(r"engulf|hammer|shooting star|morning star|evening star|three inside|three outside|candle", t) and "candle" or re.search(r"head and shoulders|head & shoulders|head\s*n\s*shoulders", t) and "hs" or
                    re.search(r"double (top|bottom)", t) and "dbl" or "triangle" in t and "tri" or re.search(r"trend ?line", t) and "tline" or
                    re.search(r"moving average|ma cross|ema cross", t) and "macross" or "rsi" in t and "rsi_turn" or "") or ("smc" if re.search(r"sweep|liquidity|smc|fvg|order block|choch|smart money", t) else "zone" if re.search(r"retest|support|resistance|zone|bounce|supply|demand", t) else "gap_go" if "gap" in t else "breakout" if "break" in t else "vwap_reclaim" if "vwap" in t else "pullback")
    r["side"] = "both" if ("short" in t and ("buy" in t or "long" in t)) else "short" if ("short" in t or "sell" in t) else "long"
    if r["pattern"] in ("candle", "hs", "dbl", "tri", "tline", "macross", "rsi_turn") and not re.search(r"\b(buy|long|short|sell)\b", t):
        r["side"] = "both"
    m = re.search(r"(\d+(?:\.\d+)?)\s*%\s*stop|stop\D{0,12}(\d+(?:\.\d+)?)\s*%", t)
    if m:
        r["stop_pct"] = float(m.group(1) or m.group(2))
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:x|r)\b", t)
    if m:
        r["target_r"] = float(m.group(1))
    r["after_hours"] = not ("regular hours only" in t or "no after" in t)
    r["name"] = (text[:28] or "My preset").strip()
    return normalize(r)


# ---------------- store ----------------
def _blank():
    return {"presets": [], "plans": {"day": "", "items": [], "ran": [], "at": ""}, "auto_log": [], "auto": {"on": False, "via": "shares"}}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
            b = _blank()
            b.update({k: d[k] for k in b if k in d})
            return b
        except Exception:
            return _blank()


def save(d):
    with LOCK:
        try:
            FILE.write_text(json.dumps(d))
        except Exception:
            pass


# ---------------- v2.19: autonomous mode ----------------
SHORT = {"pullback": "Pullback", "vwap_reclaim": "VWAP reclaim", "breakout": "Breakout", "gap_go": "Gap and go", "zone": "Zone retest", "smc": "Sweep+CHoCH+FVG", "vwap_rej": "VWAP rejection", "cycle": "Cycle turn", "open_sweep": "Open sweep",
         "hs": "Head & shoulders", "dbl": "Double top / bottom", "tri": "Triangle", "tline": "Trend-line break", "macross": "MA cross", "rsi_turn": "RSI turn"}


def autonomous_on():
    return bool(load().get("auto", {}).get("on"))


def autonomous_via():
    """How an Autonomous signal is traded: 'shares', 'options' (a call for a buy signal, a put for a short signal) or 'both'."""
    v = str(load().get("auto", {}).get("via", "shares"))
    return v if v in ("shares", "options", "both") else "shares"


def autonomous_set(on, via=None):
    with LOCK:
        d = load()
        cur = d.get("auto", {})
        v = via if via in ("shares", "options", "both") else cur.get("via", "shares")
        d["auto"] = {"on": bool(on), "via": v}
        save(d)
    return bool(on)


def auto_rules():
    """One ready-made rule set per pattern, both directions. The Autonomous switch lets the bot use the ones with a good record on each stock."""
    out = []
    for k in PATTERNS:
        r = normalize({"pattern": k, "side": "both", "name": "Auto · " + SHORT.get(k, k)})
        r.update(id="auto_" + k, enabled=True, auto_paper=True, auto=True)
        out.append(r)
    return out


def good_record(t, min_n=12):
    """Does a back-test deserve trading? v2.32: at least 12 cases (3 was passed by a coin flip about a quarter of the time), an average above +0.2R,
    wins at least 50% when enough finished, and BOTH the older half and the newer half of the cases positive."""
    if not t or t.get("n", 0) < min_n or (t.get("avg_r") is None) or t["avg_r"] <= 0.2:
        return False
    if t.get("avg_old") is None or t["avg_old"] <= 0 or t.get("avg_new") is None or t["avg_new"] <= 0:
        return False
    return t.get("rate") is None or t["rate"] >= 50


def add(rules, auto_paper=False):
    with LOCK:
        d = load()
        rules = normalize(rules)
        rules.update(id="p" + str(int(time.time() * 1000))[-9:], enabled=True, auto_paper=bool(auto_paper), created=datetime.now().strftime("%Y-%m-%d"))
        d["presets"] = (d["presets"] + [rules])[-12:]
        save(d)
        return rules


def update(pid, **kw):
    with LOCK:
        d = load()
        for p in d["presets"]:
            if p["id"] == pid:
                for k in ("enabled", "auto_paper"):
                    if k in kw and kw[k] is not None:
                        p[k] = bool(kw[k])
                save(d)
                return p
    return None


def delete(pid):
    with LOCK:
        d = load()
        d["presets"] = [p for p in d["presets"] if p["id"] != pid]
        d["plans"]["items"] = [x for x in d["plans"]["items"] if x.get("preset_id") != pid]
        save(d)


def review(fetch5, syms, presets, now):
    """Daily pattern review: which of your presets lined up on the latest session of each stock? fetch5(sym) -> 5-minute bars (45 days).
    Returns plan items sorted by the preset's own record on that stock."""
    items = []
    for sym in syms:
        try:
            d5 = fetch5(sym)
        except Exception:
            d5 = None
        if d5 is None or len(d5) < 60:
            continue
        last_day = str(d5.index[-1].date())
        for p in presets:
            if not p.get("enabled", True):
                continue
            sigs = scan(p, d5)
            today = [s for s in sigs if s["day"] == last_day]
            if not today:
                continue
            s = today[-1]
            t = backtest(p, d5, sigs=sigs)
            if p.get("auto") and not good_record(t):
                continue                                   # autonomous mode only keeps patterns with a good record on this stock
            items.append({"symbol": sym, "preset_id": p["id"], "preset": p["name"], "side": s["side"], "t": s["t"], "day": last_day, "entry": s["price"], "stop": s["stop"],
                          "target": s["tp1"], "why": s["why"], "rate": t["rate"], "n": t["n"], "avg_r": t["avg_r"], "chart": chart(d5, sigs, focus=s)})
    items.sort(key=lambda x: ((x["rate"] if x["rate"] is not None else -1), x["n"]), reverse=True)
    return items[:12]
