"""Risk manager built around ONE user number: the daily max loss.

* Day P&L = current equity - yesterday's closing equity (from Alpaca, so it survives restarts).
* When day P&L <= -daily_max_loss: close losing positions, keep winners (with stops), halt new entries until tomorrow.
* Profit lock: once the day is up by >= the daily limit, the bot halts if it gives back half of the peak.
* Every open trade's distance-to-stop counts as "open risk". A new trade is only allowed if
  open risk + its own risk still fits inside what's left of the daily limit, so even if every
  stop is hit at once you stay within your number (barring gaps/slippage).
* Position size = $ risk / (entry - stop). The $ risk scales with the learner's confidence in
  the setup, so proven strategies trade bigger and unproven ones trade smaller.
"""
import math
from dataclasses import dataclass


@dataclass
class SizeDecision:
    qty: float
    risk_dollars: float
    reason: str = ""


class RiskManager:
    def __init__(self, settings):
        self.s = settings
        self.halted = False
        self.halt_reason = ""
        self.peak_pnl = 0.0
        self.day_pnl = 0.0
        self.goal_off_today = False            # you tapped Resume after the win goal: the goal is ignored until tomorrow

    WIN = "Daily win goal reached"

    @property
    def won(self) -> bool:
        """Halted because the daily win goal was reached (not because of a loss)."""
        return bool(self.halted and str(self.halt_reason).startswith(self.WIN))

    def new_day(self):
        self.halted, self.halt_reason, self.peak_pnl, self.day_pnl = False, "", 0.0, 0.0
        self.goal_off_today = False

    def update(self, equity: float, last_equity: float) -> bool:
        """Returns True if the bot must flatten and halt now."""
        self.equity = float(equity or 0)
        self.day_pnl = equity - last_equity
        self.peak_pnl = max(self.peak_pnl, self.day_pnl)
        lim = float(self.s.daily_max_loss)
        if self.halted:
            return False
        if self.day_pnl <= -lim:
            self.halted, self.halt_reason = True, f"Daily max loss hit ({self.day_pnl:,.2f})"
            return True
        goal = float(getattr(self.s, "daily_win_goal", 0) or 0)
        if goal > 0 and not self.goal_off_today and self.day_pnl >= goal:      # v2.55: the day is won: bank it and stop
            self.halted, self.halt_reason = True, f"{self.WIN} (+${self.day_pnl:,.2f} of ${goal:,.0f})"
            return True
        if self.peak_pnl >= lim and self.day_pnl <= 0.5 * self.peak_pnl:
            self.halted, self.halt_reason = True, f"Profit lock: gave back half of +{self.peak_pnl:,.2f}"
            return True
        return False

    @property
    def remaining(self) -> float:
        return max(0.0, float(self.s.daily_max_loss) + min(self.day_pnl, 0.0))

    def size(self, entry: float, stop: float, weight: float, open_risk: float,
             buying_power: float, frac: bool = False) -> SizeDecision:
        if self.halted:
            return SizeDecision(0, 0, "halted")
        rps = abs(entry - stop)
        if rps <= 0:
            return SizeDecision(0, 0, "bad stop")
        budget = self.remaining - open_risk
        risk = min(float(self.s.daily_max_loss) * self.s.risk_per_trade_frac * weight,
                   0.5 * self.remaining, budget)
        if risk <= 0:
            return SizeDecision(0, 0, "no risk budget left")
        fl = (lambda x: math.floor(x * 10000) / 10000.0) if frac else math.floor      # fractional: 4 decimals, rounded down
        qty = fl(risk / rps)
        max_qty = fl(buying_power * self.s.max_position_pct_bp / entry) if entry > 0 else 0
        qty = min(qty, max_qty)
        eq = float(getattr(self, "equity", 0) or 0)
        cap_pct = float(getattr(self.s, "max_position_pct_equity", 0.25) or 0)
        if eq > 0 and cap_pct > 0 and entry > 0:                       # margin buying power is ~4x equity: never let one trade be the whole account
            qty = min(qty, fl(eq * cap_pct / entry))
        nc = float(getattr(self.s, "max_trade_notional", 0) or 0)
        if nc > 0 and entry > 0:                                       # v1.83: one bot trade never bigger than this many dollars
            qty = min(qty, fl(nc / entry))
        if frac:
            if qty * entry < 1.0:                                      # Alpaca's minimum order is about $1
                return SizeDecision(0, 0, "under the $1 minimum order")
        elif qty < 1:
            return SizeDecision(0, 0, "size < 1 share")
        return SizeDecision(qty, round(qty * rps, 2))
