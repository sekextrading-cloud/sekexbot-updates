"""♻ Auto-harvest for your manual trades: bank a small gain, then get back in on a pullback, over and over.

You buy (or short) by hand and tick "Auto-harvest". From then on this loop watches the position:

  HARVEST   sells the whole position as soon as it is up ~0.5 x the stock's normal 5-minute range
            (A), OR the gain has been green for 20 s and starts to fade (gave back 0.15 A from its
            best). A = 2.5 x the 1-minute ATR, never less than 0.15% of the price.
  RE-ENTER  after selling it waits for a pullback: price falls back at least 0.25 A from the highest
            price since the harvest (mirror image for shorts), the 3-minute ribbon still points your
            way, price is still on the right side of the ribbon's slow line, and the last 1-minute
            candle turns back your way. Then it buys / shorts the same size again.
  STOP      ends the cycle (and closes the position) if a trade goes 1.2 A against you (mid price,
            held 25 s, not in the first 3 minutes of a session or while the spread is too wide). It also ends
            if the ribbon turns against you for about a minute while waiting, if the daily loss limit
            halts trading, or when you tap Stop. Stop leaves an open position alone.

Works whether or not the auto-trader is running. Extended hours use limit orders, so the position's
protective stop is watched by the app (the app has to stay open). Overnight (8 PM - 4 AM) it pauses and
holds the position as is; it resumes at 4 AM pre-market."""
import json
import logging
import os
import threading
import re
import time
from datetime import datetime, timedelta

from .indicators import enrich, ribbon_state

log = logging.getLogger("autobot")

TARGET_A = 0.5          # harvest at this many A of profit
STALL_A = 0.15          # ...or once it gives back this much from its best (after 20 s green)
GREEN_A = 0.25          # "green" = at least this much profit
STOP_A = 1.2            # protective stop, in A
CONT_A = 0.3            # ...or jump back in when it keeps running: this far past the exit price, at a new extreme
CONT_SECS = 45          # ...but not sooner than this after the exit
PULLBACK_A = 0.25       # re-enter after this pullback from the best price since the harvest
REENTRY_SECS = 60       # ...but a pullback re-entry waits at least this long after the harvest
BOUNCE_A = 0.1          # ...and only once price has bounced this far off the worst price since the harvest (the drop has stopped)
GREEN_SECS = 20
TURN_SECS = 60          # ribbon against you this long while waiting -> stop cycling
DAY_CYCLE_CAP = 60      # hard safety cap on harvests per symbol per day
POLL = 4                # seconds between checks
MIN_HARVEST_PCT = 0.0005  # v2.44.2: a harvest must be at least this much above your price (covers a slightly worse fill); never a loss

QUICK_MIN_FLOOR = 5.0   # the Quick Harvest minimum can never be set under this many dollars


def quick_min(settings):
    """The fewest dollars one Quick Harvest may bank (default 25)."""
    try:
        return max(QUICK_MIN_FLOOR, float(getattr(settings, "quick_harvest_min", 25.0) or 25.0))
    except Exception:
        return 25.0



class Harvester:
    def __init__(self, get_engine, quote_fn, session_fn, open_fn, close_fn, path):
        self.get_engine, self.quote_fn, self.session_fn = get_engine, quote_fn, session_fn
        self.open_fn, self.close_fn = open_fn, close_fn
        self.path = path
        self.jobs: dict = {}
        self.learn_fn = None           # v2.16: (engine, symbol, session) -> learned take level in % of entry, or None
        self.lock = threading.RLock()
        self.wake = threading.Event()        # v2.37.3: Harvest now wakes the loop at once
        self.hpath = os.path.join(os.path.dirname(path) or ".", "harvest_hist.json")
        self.hist: list = []           # v2.25: every harvest / re-entry / stop with its time; survives Stop and closing the position
        try:
            self.hist = json.loads(open(self.hpath).read())[-600:]
        except Exception:
            self.hist = []
        self._bars = {}                # sym -> (t, A, ribbon_state, last_two_closes)
        self._load()
        threading.Thread(target=self._loop, daemon=True, name="harvester").start()

    # ---------- persistence ----------
    def _load(self):
        try:
            data = json.loads(open(self.path).read())
            for sym, j in (data.get("jobs") or {}).items():
                ph0 = j.get("phase")
                # a harvest sale that was in flight stays 'exiting' so it is finished/recorded after a restart (stop exits fall back to holding)
                j["phase"] = "armed" if ph0 == "entering" else ("holding" if ph0 == "exiting" and j.get("why") == "stop" else ph0)
                self.jobs[sym] = j
        except Exception:
            pass

    def _save(self):
        try:
            with open(self.path, "w") as f:
                json.dump({"jobs": self.jobs}, f)
        except Exception:
            pass

    # ---------- v2.25: history ----------
    def _h(self, sym, kind, txt, amt=None, px=None):
        try:
            e = self.get_engine()
            n = e.broker.now() if e else datetime.now()
            self.hist.append({"day": str(n.date()), "t": n.strftime("%-I:%M %p"), "hm": n.strftime("%H:%M"), "d": n.strftime("%a %b %d"),
                              "sym": sym, "kind": kind, "txt": txt, "amt": None if amt is None else round(float(amt), 2),
                              "px": None if px is None else round(float(px), 4)})
            del self.hist[:-600]
            with open(self.hpath, "w") as f:
                json.dump(self.hist, f)
        except Exception:
            pass

    def history(self, sym=None, day=None):
        with self.lock:
            if day is None:
                try:
                    e = self.get_engine()
                    day = str(e.broker.now().date()) if e else str(datetime.now().date())
                except Exception:
                    day = str(datetime.now().date())
            rows = [h for h in self.hist if h.get("day") == day and (not sym or h["sym"] == sym)]
            return list(reversed(rows))

    def today(self, sym):
        rows = [h for h in self.history(sym) if h["kind"] in ("harvest", "stop", "loss")]
        return {"n": sum(1 for h in rows if h["kind"] == "harvest"), "stops": sum(1 for h in rows if h["kind"] in ("stop", "loss")),
                "amt": round(sum(h["amt"] or 0 for h in rows), 2)}

    # ---------- control ----------
    def arm(self, sym, side, qty, note="", auto=False):
        """side: 'buy' = long harvest cycle, 'sell' = short. qty = size to (re)trade each cycle."""
        with self.lock:
            old = self.jobs.get(sym)
            self.jobs[sym] = {"symbol": sym, "side": side, "qty": float(qty), "phase": "armed", "cycles": 0,
                              "banked": 0.0, "entry": 0.0, "peak_g": 0.0, "green_since": 0.0, "exit_px": 0.0,
                              "extreme": 0.0, "turn_since": 0.0, "armed_t": time.time(), "tries": 0, "sent_t": 0.0,
                              "msg": note or "waiting for your order to fill", "auto": bool(auto),
                              "day_cycles": (old or {}).get("day_cycles", 0)}
            self._save()
        self._h(sym, "started", "Auto-harvest turned on" + (" by itself" if auto else "") + (f" ({note})" if note and not auto else ""))

    def now(self, sym, side=None, qty=0.0):
        """Button on a position: holding -> sell now and keep cycling; waiting -> re-enter now. No job yet -> arm, then sell now.
        Returns a short message."""
        with self.lock:
            j = self.jobs.get(sym)
            if not j:
                if not side:
                    return "no position"
                self.arm(sym, side, qty, "harvesting now")
                self.jobs[sym]["now"] = True
                self._save()
                self._wake()
                return "Harvesting: sells now if the trade is green; if it is red it waits for a gain first (Close sells at a loss)."
            ph = j["phase"]
            if ph in ("holding", "armed"):
                j["now"] = True
                self._save()
                self._wake()
                return "Harvesting: sells now if the trade is green; if it is red it waits for a gain first (Close sells at a loss)."
            if ph == "waiting":
                j["enter_now"] = True
                self._save()
                self._wake()
                return "Buying back now."
            return f"Already busy ({ph}); try again in a moment."

    def _wake(self):
        w = getattr(self, "wake", None)
        if w is not None:
            w.set()

    def stop(self, sym, reason="stopped by you"):
        with self.lock:
            j = self.jobs.pop(sym, None)
            if j:
                self._h(sym, "off", f"Auto-harvest turned off: {reason}")
                self._say(j, f"♻ Auto-harvest OFF for {sym}: {reason}. {j['cycles']} harvest(s), about ${j['banked']:+,.2f} banked.")
                self._save()
            return bool(j)

    def status(self):
        with self.lock:
            return [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in j.items()
                     if k in ("symbol", "side", "qty", "phase", "cycles", "banked", "entry", "msg", "auto")} | {"today": self.today(j["symbol"])}
                    for j in self.jobs.values()]

    # ---------- helpers ----------
    def _say(self, j, msg, level="info", alert=None):
        e = self.get_engine()
        if not e:
            return
        try:
            e.event(msg, level)
            if alert:
                e.alert(alert[0], alert[1], alert[2], symbol=j["symbol"])
        except Exception:
            pass

    def _metrics(self, e, sym, price):
        """(A, ribbon dict or None, closes[-2:]) refreshed every 20 s."""
        c = self._bars.get(sym)
        if c and time.time() - c[0] < 20:
            return c[1], c[2], c[3]
        A, rb, closes = max(price * 0.003, 0.03), None, None
        try:
            raw = e.broker.bars([sym], start=e.broker.now() - timedelta(minutes=150)).get(sym)
            if raw is not None and len(raw) >= 20:
                d = enrich(raw)
                A = max(float(d["atr"].iloc[-1]) * 2.5, price * 0.0015, 0.02)
                rb = ribbon_state(raw)
                closes = [float(x) for x in d["close"].iloc[-3:]]
        except Exception:
            pass
        self._bars[sym] = (time.time(), A, rb, closes)
        return A, rb, closes

    # ---------- the loop ----------
    def _loop(self):
        while True:
            self.wake.wait(POLL)
            self.wake.clear()
            try:
                e = self.get_engine()
                if not e or not self.jobs:
                    continue
                with self.lock:
                    jobs = list(self.jobs.values())
                if not jobs:
                    continue
                sess = self.session_fn(e)
                if sess == "CLOSED":
                    continue
                pos = e.broker.positions()
                for j in jobs:
                    if j["symbol"] in self.jobs:
                        try:
                            self.step(e, j, pos, sess)
                        except Exception as ex:
                            log.warning("harvest %s: %s", j["symbol"], ex)
            except Exception as ex:
                log.warning("harvester: %s", ex)

    def step(self, e, j, pos, sess, now=None):
        sym, now = j["symbol"], (now or time.time())
        d = 1 if j["side"] == "buy" else -1
        if getattr(e.risk, "halted", False):
            return self.stop(sym, "the daily win goal was reached: done for today" if getattr(e.risk, "won", False) else "the daily loss limit halted trading")
        if sym in getattr(e, "trades", {}):
            return self.stop(sym, "the auto-trader is managing this stock")
        p = pos.get(sym)
        has = bool(p and p["qty"] * d > 0)
        bid, ask = self.quote_fn(e, sym, sess)
        if not bid or not ask:
            return
        mark = bid if d > 0 else ask
        ph = j["phase"]
        if sess == "OVERNIGHT" and ph not in ("entering", "exiting") and not (j.get("now") or j.get("enter_now")):
            # 8 PM - 4 AM quotes are thin and wide: an automatic harvest, stop or re-entry there would fill badly.
            # Pause (hold the position as is) and pick up again at 4 AM pre-market. Your own Harvest now / Re-enter
            # now button is a direct request, so it is NOT paused (v1.82.1).
            j["msg"] = "paused overnight (quotes too thin); holding as is, resumes at 4:00 AM. Harvest now still works."
            j["stop_since"] = 0.0
            return
        if j.get("sess") != sess:                 # a new session just started: let quotes settle
            j["sess"], j["sess_t"] = sess, now
            j["stop_since"] = 0.0

        if ph == "armed":
            if has:
                j.update(phase="holding", entry=p["avg_entry"], qty=abs(p["qty"]), peak_g=0.0, green_since=0.0,
                         msg="holding — watching for a quick gain")
                self._save()
                if not j.get("now"):
                    return
                ph = "holding"                             # Harvest now: sell in this same pass
            elif now - j["armed_t"] > 600:
                self.stop(sym, "your order didn't fill in 10 minutes")
                return
            else:
                return
        if ph == "holding" and j.get("now"):              # v2.37.3: Harvest now before anything else (no chart reading first)
            if not has:
                return self.stop(sym, "the position was closed")
            j["entry"] = p["avg_entry"]
            gain_now = (mark - j["entry"]) * d
            if gain_now <= MIN_HARVEST_PCT * j["entry"]:   # v2.44.2: a harvest banks a GAIN. Red -> wait for green; only Close sells at a loss
                if not j.get("now_said"):
                    j["now_said"] = True
                    self._say(j, f"♻ Harvest now on {sym}: it is {'under' if d > 0 else 'over'} your price ({mark:.2f} vs {j['entry']:.2f}), so it waits and sells at the first gain. Use Close to sell at a loss.",
                              "warning", alert=("exit", f"♻ {sym}: not selling at a loss", f"At {mark:.2f} vs your {j['entry']:.2f}. Harvest waits for a gain; tap Close if you want out now."))
                j["msg"] = f"Harvest now armed: waiting for a gain (now {mark:.2f} vs your {j['entry']:.2f}); Close sells at a loss"
                return
            j.pop("now", None)
            j.pop("now_said", None)
            j["exit_px"] = mark
            j["urgent"] = True
            self._say(j, f"♻ Harvest now on {sym}: selling at the market price at your request (≈ +${gain_now * j['qty']:,.2f}), then re-entering on a pullback")
            self._exit(e, j, sess, bid, ask, "harvest")
            return

        if ph == "entering":
            if has:
                j.update(phase="holding", entry=p["avg_entry"], qty=abs(p["qty"]), peak_g=0.0, green_since=0.0,
                         tries=0, msg="re-entered — watching for a quick gain")
                self._h(sym, "reenter", f"{'Bought' if d > 0 else 'Shorted'} {abs(p['qty']):g} @ {p['avg_entry']:.2f}", None, p["avg_entry"])
                self._say(j, f"♻ Re-entered {sym} {abs(p['qty']):g} @~{p['avg_entry']:.2f}",
                          alert=("entry", f"♻ Re-entered {sym}", f"{abs(p['qty']):g} @ {p['avg_entry']:.2f} (cycle {j['cycles'] + 1})"))
                self._save()
            elif now - j["sent_t"] > 45:
                if j["tries"] >= 3:
                    j.update(phase="waiting", tries=0, msg="re-entry order didn't fill; waiting for the next pullback")
                    try:
                        e.broker.cancel_symbol_orders(sym)
                    except Exception:
                        pass
                else:
                    self._enter(e, j, sess, bid, ask, retry=True)
            return

        if ph == "exiting":
            if not has:
                j["exit_px"] = j.get("exit_px") or mark
                try:                                   # v2.27.1 (from your phone's fix): use the price the sale really filled at, not the price aimed for
                    since = e.broker.now() - timedelta(seconds=max(0.0, now - j["sent_t"]) + 30 * max(1, int(j.get("tries", 1))))
                    lp = e.broker.last_exit_price(sym, since, "sell" if d > 0 else "buy")
                    if lp:
                        j["exit_px"] = float(lp)
                except Exception:
                    pass
                gain = (j["exit_px"] - j["entry"]) * d * j["qty"]
                j["urgent"] = False
                j.update(phase="waiting", cycles=j["cycles"] + 1, day_cycles=j["day_cycles"] + 1,
                         banked=j["banked"] + gain, extreme=mark, trough=mark, turn_since=0.0, tries=0, exit_t=now,
                         msg=f"harvested ~${gain:+,.2f}; re-entering on a pullback or if it keeps running")
                self._h(sym, "harvest" if gain >= 0 else "loss", f"{'Sold' if d > 0 else 'Covered'} {j['qty']:g} @ {j['exit_px']:.2f} · in at {j['entry']:.2f}", gain, j["exit_px"])
                self._say(j, f"♻ {'HARVESTED' if gain >= 0 else 'CLOSED AT A LOSS (the fill came back under your price)'} {sym} ≈ ${gain:+,.2f} @~{j['exit_px']:.2f} (cycle {j['cycles']}, total ≈ ${j['banked']:+,.2f})",
                          alert=("profit" if gain >= 0 else "exit", f"♻ {'Harvested' if gain >= 0 else 'Closed at a small loss'} {sym} ≈ {gain:+,.2f}", f"Cycle {j['cycles']} · {'will re-enter on a pullback' if gain >= 0 else 'sold below your price (Harvest now sells at the market). Will re-enter on a pullback'}"))
                self._save()
            elif now - j["sent_t"] > (8 if j.get("urgent") else 30):
                if j["tries"] >= 4:
                    j.update(phase="holding", tries=0, urgent=False, msg="exit order didn't fill; still holding")
                else:
                    self._exit(e, j, sess, bid, ask, j.get("why", "harvest"), retry=True)
            return

        A, rb, closes = self._metrics(e, sym, mark)

        if ph == "holding":
            if not has:
                return self.stop(sym, "the position was closed")
            j["entry"] = p["avg_entry"]
            gain = (mark - j["entry"]) * d
            if j.get("now") and gain > MIN_HARVEST_PCT * j["entry"]:   # Harvest now and it is green: sell, keep cycling
                j.pop("now", None); j.pop("now_said", None)
                j["exit_px"] = mark
                self._say(j, f"♻ Harvest now on {sym}: selling at your request, then re-entering on a pullback")
                self._exit(e, j, sess, bid, ask, "harvest")
                return
            g = gain / A
            # Protective stop on the MID price (not the bid), only after quotes have settled for 3 min in
            # this session, only when the spread is sane, and only if it stays beyond the stop for 25 s
            # (straight away only at 2x the stop). This stops one bad quote from selling you out.
            mid = (bid + ask) / 2
            g_mid = (mid - j["entry"]) * d / A
            wide = (ask - bid) > 0.6 * A
            settling = now - j.get("sess_t", 0) < 180
            if j.get("auto"):                              # v2.16: auto-armed on your own trade: it only takes profit, it never sells you out at a loss
                g_mid = 0.0
            if g_mid <= -STOP_A and not wide and not settling:
                j["stop_since"] = j.get("stop_since") or now
            else:
                j["stop_since"] = 0.0
            hard = g_mid <= -2 * STOP_A and not wide and not settling
            if hard or (j.get("stop_since") and now - j["stop_since"] >= 25):
                self._say(j, f"♻ Protective stop on {sym}: down {abs(g):.1f} x its normal range. Closing and stopping.", "warning",
                          alert=("exit", f"♻ Stopped out {sym}", "Auto-harvest ended for this stock"))
                self._exit(e, j, sess, bid, ask, "stop")
                if j["phase"] != "exiting":       # the exit order failed: keep the job so the next pass retries it
                    return
                loss = (mark - j["entry"]) * d * j["qty"]
                j["banked"] += loss               # count the loss too, so the total is the real net
                self._h(sym, "stop", f"{'Sold' if d > 0 else 'Covered'} {j['qty']:g} @ ~{mark:.2f} · in at {j['entry']:.2f}", loss, mark)
                self._say(j, f"♻ {sym} stop ≈ ${loss:+,.2f}; net for this cycle run ≈ ${j['banked']:+,.2f} over {j['cycles']} harvest(s).")
                with self.lock:
                    self.jobs.pop(sym, None)
                    self._save()
                return
            j["peak_g"] = max(j["peak_g"], g)
            if g >= GREEN_A:
                j["green_since"] = j["green_since"] or now
            elif g <= 0.05:                       # only "un-green" once the gain is really gone (a fade must still count)
                j["green_since"] = 0.0
            green = bool(j["green_since"]) and now - j["green_since"] >= GREEN_SECS
            stalled = green and j["peak_g"] >= 0.28 and g <= j["peak_g"] - STALL_A and g > 0.1
            j["msg"] = f"holding: {g:+.2f} A (harvest at +{TARGET_A}, peak {j['peak_g']:.2f})"
            if j["day_cycles"] >= DAY_CYCLE_CAP:
                return self.stop(sym, "hit the daily safety cap of harvests")
            st_ = getattr(e, "s", None)
            if getattr(st_, "quick_harvest", False):
                # v2.55 Quick Harvest: bank it the moment the whole position is worth the minimum at the price you can sell at
                # (bid for a long, ask for a short). No waiting for the usual target, and never a harvest for less than the minimum.
                qmin = quick_min(st_)
                dollars = gain * j["qty"]
                j["msg"] = f"quick harvest: ${dollars:+,.2f} now, banks at ${qmin:,.0f}"
                if dollars >= qmin and gain > 0:
                    j["exit_px"] = mark
                    self._exit(e, j, sess, bid, ask, "harvest")
                return
            # A harvest must pay for the round trip: we sell at the bid but buy back at the ask, so the gain per
            # share has to beat the spread (plus a little for slippage) or the cycle loses money.
            cost = max(1.2 * (ask - bid), mark * 0.0003)
            pays = gain >= cost
            learned = False
            try:                                          # v2.16: the level this stock usually runs to (learned from past trips)
                lp = self.learn_fn(e, sym, sess) if self.learn_fn else None
                if lp and j["entry"] > 0 and gain / j["entry"] * 100.0 >= lp:
                    learned = True
            except Exception:
                pass
            if gain > MIN_HARVEST_PCT * j["entry"] and ((g >= TARGET_A and pays) or (stalled and gain >= 1.5 * cost) or (learned and pays)):
                j["exit_px"] = mark
                self._exit(e, j, sess, bid, ask, "harvest")
            return

        if ph == "waiting":
            if j.pop("enter_now", False):                 # you tapped Re-enter now
                j["reentry_kind"] = "manual"
                self._say(j, f"♻ Re-enter now on {sym}: buying back at your request")
                self._enter(e, j, sess, bid, ask)
                return
            # track the best price since the harvest
            j["extreme"] = max(j["extreme"], mark) if d > 0 else min(j["extreme"], mark)
            j["trough"] = min(j.get("trough", mark), mark) if d > 0 else max(j.get("trough", mark), mark)   # worst price since the harvest
            ready = bool(rb and rb.get("ready"))
            state = rb["state"] if ready else 0
            if ready and state * d < 0:
                j["turn_since"] = j["turn_since"] or now
                if now - j["turn_since"] >= TURN_SECS:
                    return self.stop(sym, "the ribbon turned against you")
                j["msg"] = "ribbon against you; waiting"
                return
            j["turn_since"] = 0.0
            pulled = (j["extreme"] - mark) * d >= PULLBACK_A * A
            bounced = (mark - j.get("trough", mark)) * d >= BOUNCE_A * A
            waited = now - j.get("exit_t", 0) >= REENTRY_SECS
            pulled_ok = pulled and bounced and waited       # a dip that is still falling is not a re-entry
            side_ok = (not ready) or (state * d > 0 and (mark - rb["slow"]) * d > 0)
            turned = bool(closes and len(closes) >= 2 and (closes[-1] - closes[-2]) * d > 0)
            run = (mark - j.get("exit_px", mark)) * d / A            # how far it has kept running past the harvest price
            cont = (run >= CONT_A and run <= 4.0 and side_ok and turned and (now - j.get("exit_t", now)) >= CONT_SECS
                    and (mark - j["extreme"]) * d >= -1e-9)
            j["extreme_prev"] = j["extreme"]
            j["msg"] = (f"waiting: pullback {(j['extreme'] - mark) * d / A:.2f}/{PULLBACK_A} A, or run {run:.2f}/{CONT_A} A past the exit"
                        f"{'' if side_ok else ', ribbon side not ready'}{'' if turned else ', no bounce candle yet'}")
            lim = float(getattr(getattr(e, "s", None), "max_spread_pct", 0) or 0)
            wide = lim > 0 and (ask - bid) / ((ask + bid) / 2) * 100 > lim       # v2.17.5: don't pay a wide spread to get back in
            if wide:
                j["msg"] = f"waiting: spread {(ask - bid) / ((ask + bid) / 2) * 100:.2f}% is wider than your {lim:g}% limit, not re-entering yet"
            pf = getattr(self, "pause_fn", None)
            if d > 0 and pf and pf():                     # v2.51: no automatic re-buys 2:00-3:00 PM (Re-enter now still works)
                j["msg"] = "waiting: no re-buys 2:00-3:00 PM (the usual dip hour); buys again at 3:00"
                return
            if j["day_cycles"] < DAY_CYCLE_CAP and side_ok and turned and (pulled_ok or cont) and not wide:
                j["reentry_kind"] = "pullback" if pulled_ok else "continuation"
                self._enter(e, j, sess, bid, ask)

    # ---------- orders ----------
    def _enter(self, e, j, sess, bid, ask, retry=False):
        j["tries"] = j["tries"] + 1 if retry else 1
        j["sent_t"] = time.time()
        j["phase"] = "entering"
        try:
            if retry:
                e.broker.cancel_symbol_orders(j["symbol"])
            qty = int(j["qty"])
            try:                                   # v1.95.1: never ask for more than the account can buy right now
                bp = float((e.broker.account() or {}).get("buying_power") or 0)
                px = ask if j["side"] == "buy" else bid
                if bp > 0 and px > 0 and qty * px * 1.002 > bp * 0.98:
                    fit = int(bp * 0.98 / (px * 1.002))
                    if fit < 1:
                        raise RuntimeError(f"not enough buying power (${bp:,.0f}) for even 1 share")
                    j["msg"] = f"re-entry resized {qty} -> {fit} shares to fit buying power"
                    qty = fit
            except RuntimeError:
                raise
            except Exception:
                pass
            self.open_fn(e, j["symbol"], j["side"], qty, sess, bid, ask, j["tries"])
            j["msg"] = j.get("msg") if str(j.get("msg", "")).startswith("re-entry resized") else "re-entry order sent"
        except Exception as ex:
            j["phase"] = "waiting"
            j["msg"] = f"re-entry failed: {str(ex)[:80]}"
            self._say(j, f"♻ Re-entry on {j['symbol']} failed: {str(ex)[:120]}", "warning")

    def _exit(self, e, j, sess, bid, ask, why, retry=False):
        j["tries"] = j["tries"] + 1 if retry else 1
        j["sent_t"] = time.time()
        j["phase"] = "exiting"
        j["why"] = why
        self._save()                               # remember we are mid-sale, in case the app restarts
        try:
            try:                                   # never ask to sell more than is really held (v1.74.1)
                held = abs(float((e.broker.positions().get(j["symbol"]) or {}).get("qty") or 0))
                if held and held < j["qty"]:
                    j["qty"] = held
            except Exception:
                pass
            self.close_fn(e, j["symbol"], int(j["qty"]), j["side"], sess, bid, ask, j["tries"], why == "stop" or bool(j.get("urgent")))
            j["msg"] = "harvest order sent" if why == "harvest" else "exit order sent"
        except Exception as ex:
            j["phase"] = "holding"
            j["msg"] = f"exit failed: {str(ex)[:80]}"
            m = re.search(r"available.{0,6}?(\d+(?:\.\d+)?)", str(ex))
            if "insufficient qty" in str(ex) and m:      # sync to what the broker says we can sell
                j["qty"] = float(m.group(1))
            j["fail_n"] = j.get("fail_n", 0) + 1
            if j["fail_n"] <= 3 or j["fail_n"] % 20 == 0:   # no more than a handful of identical warnings
                self._say(j, f"♻ Exit on {j['symbol']} failed: {str(ex)[:220]}", "warning")
