"""SekexBot version. Bump this with every release and add an entry to CHANGELOG.md.

MAJOR.MINOR.PATCH:  MAJOR = breaking change (settings/data format), MINOR = new feature, PATCH = fix."""
__version__ = "2.47.2"
RELEASE_DATE = "2026-11-06"
