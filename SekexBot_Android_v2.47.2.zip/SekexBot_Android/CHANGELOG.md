# SekexBot changelog

Version numbers are MAJOR.MINOR.PATCH. MAJOR means a breaking change to settings or data, MINOR means a new feature, and PATCH means a fix.
The running version shows in the dashboard header and in the console window when SekexBot starts.

## 2.47.2 — 2026-11-06
- **From your phone, Nov 6: SekexBot was dead from 4:05 AM to 10:41 AM with nothing in the log.** No traceback means Android stopped the whole Termux process (battery / memory), and the old watchdog died with it. Now: the app writes a **heartbeat** every minute; on the next start a stale heartbeat becomes a plain-words note on the Fix tab and a ⚠️ alert ("SekexBot was NOT running from 4:05 AM to 10:41 AM, 6.6 h. No error was logged: Android stopped the app. Check Settings → Apps → Termux → Battery → Unrestricted, and 'Never sleeping apps'"). The watchdog also restarts a **frozen** server (heartbeat 6 min stale), which the old one could not see.
- **Options autopilot switched off** (once): it bought AAPL and META calls by itself at 10:45 while the Rush and Tape were on PAPER trial. Turn it back on in the Options tab when you want it.
- **Lighter on the phone:** the entry alerts, Tape, armed trades and sanity marks now share one 20-second candle cache instead of each fetching the same bars.
- **`sekex log` returns at once** (it used to follow forever, which is why piping it looked stuck); `sekex log -f` follows. New: **`sekex errors`** (the last crash lines) and **`sekex why`** (every unexplained gap or restart, in plain words, with the fix).

## 2.47.1 — 2026-11-05
- **Fix (from your journal, Nov 5): the Opening Rush sold APPX for $19 on a "goal reached +$1,071".** One bad quote on a thin $14 stock marked the position 4% high for a single pass, the day-goal rule fired and everything was sold. Now a quote more than 2% from the last 5-minute close is ignored for P&L and goal checks, and the goal must hold for **3 checks in a row** (about 15 seconds) before the Rush or the Tape closes everything. Same guard on the Tape autopilot.

## 2.47.0 — 2026-11-05
- **New 🧭 Tape autopilot (Auto tab), runs by itself** for the days the whole market moves one way (Nov 5: META, TSLA, AVGO, INTC all down from the open). The tape = SPY vs its 9:30 open plus how many of your watchlist are green vs red. When SPY is **0.8%** from the open with 70% of your list agreeing, it takes the **first structure break** of each stock in that direction (a 5-min close past the last bottom = short; past the last top = buy), and gets out on a 5-min close back across the exit line, at 1.5x the risk, or at 2:00. Tested on your history: **80 trades on 13 tape days, +0.27% a trade, 50% winners, positive in both halves**; shorts on down days +0.40%, buys on up days +0.06% on only 3 up days, so buys start at **half size**. Skips anything already 5% from its open. Max 3 open, $25k each, day goal, your daily loss limit. **PAPER first; LIVE needs the PIN.** Off by default: turn it on from the card. "Short everything red" with no structure trigger lost (−0.4%/trade) on the same data; this is not that.
- **🔐 Arm LIVE for today + tomorrow** (one PIN, for days you cannot reach your phone, e.g. a SCIF): the Rush, Pullback Buyer, Tape and armed trades all honour it.
- **Entry alerts now watch your whole watchlist** (up to 30), not the first 5. That is why META never pinged on Nov 5.
- **Consolidated:** the Market Core "lean 0-100" is now the **Tape bar** (all red … mixed … all green) with the same reading the autopilot uses. The movers, early-warning BUY?/SELL?, ribbon, trend, open-sweep, RSI-zone, range, VWAP, volume, jump, open-drive and reversal alert kinds are retired from the Alerts list (forced off); the early-warning boxes stay hidden behind the chart's 🔬 Detail toggle. One voice: the Tape says which way, each chart's structure says when.

## 2.46.0 — 2026-11-04
- **New: trade from the chart with one tap, and the candle close fires it.** When the signal shows GET READY or BUY NOW / SHORT NOW, the card has one big button: "▲ BUY 39 on the close above 633.99". Tapping it **arms** the trade; nothing is sent. Every 5 minutes, when a candle closes, the app checks: a close beyond the line sends a limit a few cents through it, with the stop at the get-out line and the target at the last top / bottom (a bracket in regular hours). A **wick through the line does not count**. If a candle closes past the stop line first, the setup is off and the arm is cancelled. Closes more than 0.4% past the line are not chased. Arms expire at the end of the day. **Pre-market and after-hours arms wait for 9:30** unless you tap "Allow this session". Cancel any time. PAPER arms and fires; LIVE needs the PIN; the guardrails still apply at fire time.
- **The ticket is filled in for you**: shares for your dollar amount (tap $ or sh to change), entry, stop with the risk in dollars, target with the reward and the ratio. A target closer than the risk is replaced by 1.5x the risk.
- **🧼 Clean chart (default)**: the three lines that matter now (BUY / SHORT line, STOP, TARGET, each labelled in words and dollars per share) and nothing else. The HH / LH letters, the old LONG / SHORT / EXIT boxes, the key levels and the gamma lines move behind **🔬 Detail**.
- **Today, one line each**: a strip under the chart lists every signal of the day as "SHORT 10:15 → 11:35 +$2.10", with the net per share following every signal, so a choppy day reads as a choppy day.

## 2.45.0 — 2026-11-04
- **New: gap-and-go, a second trigger for the Opening Rush.** At **9:35** it also buys stocks that gapped up **2%+** at the open, whose first 5-minute candle closed **green**, on **2x** their normal 9:30 volume (AAPL on Nov 4 is the shape: +2% gap, straight up 3% in 30 minutes, which the pre-market volume rule missed on a mega-cap). Tested on your history across 8 methods and 40 variations: **70 trades, 57% winners, +0.76% a trade, positive in both halves**; shorting gap-downs lost, so it is buy-only. Same stop, sell-by, goal, loss limit and per-pick size; it shares "most picks a day" with the volume picks. Picks show a GAP-AND-GO tag, the 9:35 check lists what it looked at and why each was skipped, and real results are tracked separately for the two triggers. Settings: on/off, gap 1.5/2/3%, volume 1.5/2/3x. On by default, PAPER first like the rest of the Rush.
- Tested and NOT built, from the same sweep: a $15 "super harvest" (89% winners, −$19 a trade after costs), trend scalps with trails, VWAP crosses, 15-minute opening range breaks, fading the first 30 minutes, 3 PM continuation, and 8:30 news-spike entries. All lost on your data.

## 2.44.3 — 2026-11-04
- **Fix (from your phone, Nov 4): Opening Rush picked RIOT, CVS, UBER and WULF but bought nothing.** The buy window was only 9:30-9:33, and a spread over 0.5% in those minutes (normal on a 13% gapper) or the v2.43 news gate skipped the pick for good, while the card just said "managing". Now: the buy window runs **9:30-9:45** and keeps retrying while the spread settles; the **news gate no longer blocks the Rush** (its 30-minute trade is the news move; the gate still covers the Pullback Buyer and the bot's setups); any pick that never gets bought is logged as **NOT bought** with the reason, and you get one alert if nothing was bought at all.
- Fix: the Rush's end-of-run summary flag was not saved, so the "done" alert could repeat after a restart.

## 2.44.2 — 2026-11-02
- **A harvest is a gain, never a loss.** Tapping **Harvest now** on a trade that is under your price no longer sells. It arms and waits: the moment the trade is green it sells and re-enters on a pullback as usual. The card says "waiting for a gain" and you get one alert. **Close** is the only button that sells at a loss. Automatic harvests also need a small cushion above your price (so a slightly worse fill still leaves you green); if a fill still comes back negative it is logged as **CLOSED AT A LOSS**, not a harvest. The protective stop is unchanged and still says "Stopped out".

## 2.44.1 — 2026-11-02
- **Fix (from your phone)**: the plain-English signal card sat on top of the candles on a wide screen; it now has its own box under the stock header.
- **Auto-harvest and the signal disagreed**: the card said HOLD while Auto-harvest's own protective stop sold INTC. The card now says when Auto-harvest is on and that its stop can sell before the get-out line (it is the app selling, not a broker order).
- **"Harvested −$24"**: a Harvest now tap that sells below your price now reads "Closed at a small loss", not "Harvested".

## 2.44.0 — 2026-11-01
- **New 🚦 plain-English trade signal** for any stock, yours or the bot's. One status light (WAIT, GET READY, BUY NOW, HOLD, TAKE PROFIT, GET OUT) and a sentence on the chart header and a light on every position row. The chart draws three lines in words: **You bought**, **🎯 TAKE PROFIT here** (your working sell order) and **🚪 GET OUT if a candle closes under / over** the last bottom / top. Short rows say why you're in (higher bottoms in a row), what to stay in for, when to get out, where to take profit, and **Worth it?** (risk to the get-out line against what the target pays, and a better target if the last high is further).
- **Buttons**: **Set the stop for me** puts a real stop order on the get-out line (regular hours only; overnight stops are not accepted, so the GET OUT alert watches the line). **Move target to $X** replaces your sell order (the old one is put back if the new one is refused). A trade with no stop order shows a ⚠️ warning.
- **Alerts reworded**: 🟡 GET READY, 🟢 BUY NOW / SHORT NOW, 🔴 GET OUT NOW, 🎯 TAKE PROFIT, all in plain English ("A candle closed under $65.90. The move failed. Sell now"). Jargon like lower high / exit line stays in the Learn tab.

## 2.43.0 — 2026-11-01
- **New 🧭 Market Core (top of the Auto tab)**: the session (pre-market, opening rush, lunch chop, power hour), SPY / QQQ vs yesterday and VWAP, VIX, how many of your watchlist are green, and today's big US news (jobs report, Fed, CPI; free calendar with built-in Fed / jobs dates as a backup) plus earnings for your watchlist. A **market lean 0-100** is saved every 5 minutes with a track record of how often it called SPY's next 30 minutes; it is shown, not traded, until it proves itself. **News gate**: no NEW bot trades from 15 minutes before to 5 minutes after a HIGH release (Opening Rush, Pullback Buyer and the bot's setups); open trades keep their stops. Switch it off with Gate OFF.
- **New 🛡️ Guardrails** for your manual trades, from your own journal (-$535/day average): it asks before a short 9:30-10:30, before closing a trade under 2 minutes old, and for 15 minutes after 3 losses in a row. Tap **Trade anyway** to go ahead; it counts what you stopped and how the trades you made anyway did. The bot's own trades are never touched.
- **New 📉➡️📈 Pullback Buyer (PAPER first, off by default)**: the one setup with a steady 10-year record (6,502 trades, 67% wins, +0.53% each, 8 of 10 years up, survivorship bias, tens of dollars a day). At 3:55 PM it buys strong stocks (above their 200-day average) after a hard 2-3 day dip, and sells at the first close above the 5-day average or after 5 days. LIVE needs the PIN arming.

## 2.42.0 — 2026-11-01
- **New 🎓 Trade coach (Learn tab)**: learn and teach entries, exits and reversals on real charts, out loud. **📼 Replay a real day**: pick a stock and a day; the candles appear one at a time (▶ Next or ⏩ Auto) and the coach points at the candle and explains it: trend, the **reversal window** (yellow shading), GET READY, ENTRY, moving the exit line, EXIT. **🔊 Voice** reads every step aloud. **🎮 Practice**: it stops one candle before each setup; you tap BUY / SHORT / WAIT / EXIT, then it shows what the rules said and what happened next, with a practice score. **📡 Live coach**: the same, on today's live chart, spoken as it happens. Nothing is ever sent to Alpaca.
- **Options, start to finish**: switch the coach to 🧩 Options and every entry also says which call or put to buy (at the money, this week's Friday expiry), what it would cost and what it was worth later (estimated). 8 lessons: 4 for reading the chart, 4 for options (call or put, strike and expiry, getting out, the whole trade start to finish).
- **📤 Share this lesson** saves the day's candles and the coach's notes to a file anyone can open in their SekexBot (📂 Open a shared lesson). No account details inside.

## 2.41.0 — 2026-11-01
- **Close on a weekend or holiday now works.** Tapping Close while the market is closed used to send a market order that only waits until Monday 9:30 (and holds the shares meanwhile). Now the close is ⏰ scheduled for the moment the next session opens: Sunday 8 PM (overnight session) for stocks that trade overnight, otherwise 4 AM pre-market, as a limit order priced to fill. Cancel it on the position's ⏰ if you change your mind.
- **Fixed a dangerous button in Fix:** "Undo this fix" could copy an old fix's backup files back over a newer app version (mixing old and new code). It now only shows, and only works, while that fix's files are unchanged.
- **Fix history is clearer:** fixes from your phone that a release rebuilt its own way now show "✓ already in this version" instead of a red "can't re-apply"; others say "rewritten by an update".

## 2.40.0 — 2026-10-30
- **Gamma walls on the simple chart (GEX).** For the stock on the chart (best for SPY, QQQ and the biggest stocks), SekexBot adds up the open interest and gamma of every call and put near the price that expires within 30 days, and draws: the **CALL WALL** (green, the strike with the most call gamma), the **PUT WALL** (red) and the **GAMMA FLIP** (orange). A line under the trend banner says 🧲 **PIN day** (price above the flip: dealers damp the moves, the walls act like magnets, fade the edges) or 🌊 **TREND day** (below the flip: dealers chase the move, breaks can run). Refreshed every 10 minutes while you look at the chart.
- Get ready / Entry alerts add the PIN / TREND read when it is known for that stock.
- Every reading is saved (data/gex_log.jsonl) so that in a few weeks we can test whether the walls and the flip really helped your entries. It's the common public estimate (dealers assumed long calls / short puts), not the dealers' real book, and open interest updates once a day.

## 2.39.0 — 2026-10-30
- **✨ Simple chart (now the default).** The chart shows only what you need to enter and exit: a banner across the top (UPTREND / DOWNTREND / CHOP), HH / HL / LH / LL on every swing high and low, lines across the chart at the pre-market high and low, the opening-range high and low and yesterday's close, ▼ SHORT / ▲ LONG / 🚪 EXIT markers, the white **EXIT LINE** (stay in while price stays on the right side of it) and a yellow **READY** line at the entry. Tap ✨ Simple to switch back to the full chart.
- **Rules (5-min candles):** a downtrend starts when a candle closes below the last swing low after a lower high; it lasts until a candle closes above the last swing high (the exit line). Uptrend is the mirror. On INTC Oct 30 this gave GET READY at 11:20 and ENTRY short at 11:35 ($65.59), and price never closed back above the exit line.
- **New alerts: ⚠️ GET READY → 🎯 ENTRY → 🚪 EXIT LINE.** Get ready when an entry is about one 5-min candle away (with the exact price), Entry when the candle closes past it (the first entry of each new trend, not every add), "❌ setup cancelled" if it falls apart first, and Exit line for any stock you hold. Choose up to 8 stocks under Alerts → 🎯 Entry alerts for (empty = the first 5 of your watchlist).
- **Alerts cut to the important ones (once):** entry alerts, the bot getting in and out, harvests, rejected orders, 🚀 Rush (now its own switch), risk, price alerts, Dip calls and the day summary. The watchlist signal alerts (ribbon, early warnings, highs/lows, VWAP, volume, jump, movers, open sweep, reversal) are off; switch any back on in Alerts.
- **Fixed: VWAP on the chart** kept adding up yesterday's candles when the chart loaded two days, so it could be far from the real price (INTC showed $72 instead of $66). It now starts over each day.
- Harvest / scalp checked end to end: holds, banks the gain, waits for a pullback that bounces, re-enters, and the protective stop ends it; your own trades are never stopped out by it.

## 2.38.0 — 2026-10-30
- **New 🚀 Rush tab: the Opening Rush autopilot**, made for days you can't look at a screen. From 4 AM it watches pre-market volume across your watchlist, today's movers and Alpaca's most-active and biggest-mover lists. At 9:26 it picks the stocks trading **8x or more their normal pre-market volume** (up to 3, strongest first), buys them at 9:30 with a -3% stop and sells by 10:00. Buys only. Alerts (ntfy too) at the picks, each buy and sell, and a summary. Off until you turn it on; PAPER only unless you allow LIVE (then only on PIN-armed days). Settings: amount per pick, picks a day, volume needed, stop, sell-by time, day goal, and "Let runners go" (a trailing stop instead of selling at the sell-by time; off by default because it isn't in the test yet).
- Why this one: tested on your own chart history (Alpaca 5-minute candles with pre-market volume, 30 stocks, May 12 - Oct 30): 51 trades, +0.98% average, 65% winners, positive in both halves. Shorting the same stocks lost in every group. 4 AM, 7 AM and 8 AM entries lost in every version. Small sample, so no promise; the card shows the test next to your real results.
- **Cleanup: the bot's own entry setups are switched off (once).** Every setup in your journal lost money (Sep 28 - Oct 30: about -$535 a day on PAPER), so the engine strategies, Morning Wave autopilot, Jump trader, Run Hunter, pattern autopilot, Open sweep auto, Morning plan auto-trades, direction calls and auto-shorts are off. Your manual trading, Harvest now, the guard, the loss limit, alerts, Dip calls and options settings are unchanged. Anything can be switched back on where it lives.

## 2.37.5 — 2026-10-30
- **Options school moved to the Learn tab.** The lessons were showing at the top of the Options tab; they now live only under Learn, so the Options tab is for trading. Also fixed an out-of-date line on the Options follow card that said Run Hunter did not exist.

## 2.37.4 — 2026-10-30
- **Today's P&L no longer counts a paper reset or added money as profit.** Alpaca's start-of-day balance was $25,003 while the account was $69,088, so the top bar showed +$44,085 and the daily loss limit was effectively off. Now a start balance far from today's balance (more than 30% off) is replaced by today's balance, and a sudden one-step jump in the balance (a deposit, withdrawal or reset) moves the start number by the same amount, so real trading P&L is kept. A short note under Today's P&L says when this happened.

## 2.37.3 — 2026-10-29
- Harvest now is now immediate. Before, it waited for the next 4-second check, read the chart first, and then tried to sell at the middle of the bid and ask, waiting 30 seconds before each better price (up to about a minute before it crossed the spread). Now the tap wakes it at once and it sells at the market price (in extended hours a limit order that crosses the spread), retrying after 8 seconds if needed. The protective stop already worked this way.
- Built in your phone's fix ("lost in an update"): trades opened by the bot's own Morning Plan, Jump trader, Run Hunter and presets were treated as YOUR manual trades, so the manual-position guard could close them (AAPL today) and auto-harvest could take them over. They are now recognised as bot trades for the rest of the day. You can leave the phone copy alone; it is in this version.
- Fix: the manual-position guard's "flip" (in your log: "flip not possible: insufficient qty available") sent one order that crossed zero while the stop / target orders still held the shares, so Alpaca refused it and the guard could only close. It now uses the same two-step flip as the 🔄 Flip button (close, then open the other way once flat), and it waits until the old stop / target orders are really cancelled before closing.
- Bug sweep: a code-wide check for broken names found nothing else, and every button on the dashboard is wired to a real function.
- Tests: new checks for Harvest now and bot-opened trades.

## 2.37.2 — 2026-10-29
- Lighter on the phone: Android kills Termux ("Process completed (signal 9)") when a background app uses a lot of CPU or battery. The Morning Wave now reuses the 5-minute trend until a new 5-minute candle closes (its 20-second check went from about 0.3 s to 0.03 s of work), and the Edge board refreshes every 5 minutes instead of every minute.
- If Termux still closes by itself: turn on Developer options -> "Disable child process restrictions" (Android 14 / One UI 6+), set Termux, Termux:API and Termux:Widget to Battery: Unrestricted, and take Termux out of Sleeping / Deep sleeping apps (Settings -> Battery -> Background usage limits).

## 2.37.1 — 2026-10-28
- Fix: cards on the tab you were already on when the app opened stayed blank (for example 📤 Chart history and 🧮 Edge board on the Radar tab) until you tapped another tab and came back. The opening tab now loads its cards by itself.

## 2.37.0 — 2026-10-28
- 📤 Chart history for Claude (Radar tab, under the Edge board; also on the Learn tab). Makes one zip with your stocks' candles for the last 20, 60 or 120 days (5-minute) or 5 or 10 days (1-minute), 4 AM to 8 PM with pre-market and after-hours marked, a one-line-per-day summary (pre-market high/low and when, gap, regular-hours high/low and when, day move, volume by session) and your trade journal. "Share to Claude…" opens the phone's share sheet so you can send it straight to the Claude app, or Download it and attach it in the chat. Saved in the phone's Download folder too. No keys, PINs, tokens or account number inside. Claude can then study what repeats day after day and turn it into a setup for the bot.
- Tests: new check for the history file and its download.

## 2.36.0 — 2026-10-27
- 🧮 Edge board (Radar tab, top). One score per stock from -100 (strong sell) to +100 (strong buy), blended the way funds combine many weak signals instead of acting on one: trend 30% (5-minute ribbon colour and width plus the 15-minute trend), momentum 20% (move since yesterday's close), VWAP 15%, volume 15% (last 30 minutes vs the morning's normal, in the direction price moved) and setups firing now 20% (Morning Wave, Jump in / out, Open sweep, VWAP rejection, Cycle turn). Your watchlist plus movers, strongest first, every minute, with a small bar for each part.
- Morning Wave can use it: new "Edge filter" row (Off, +30, +50, +60; Off by default). With +50 it only buys waves on stocks scoring +50 or more.
- 🔍 Reality check (Positions tab). For every setup with real closed trades (PAPER or LIVE) in the last 60 days: its last 20 trades ("now") against the trades before them ("before"), win rate, and slip (average gap between the price aimed for and the fill). Status OK / WATCH / FADING / POOR / TOO FEW. A FADING or POOR Morning Wave trades at half size by itself; bot strategies keep their Self-fix tuning; nothing is switched on by itself.
- Morning Wave trades now go into your trade journal as MORNING_WAVE (Scorecard, stats, Reality check), with their slip.
- Tests: new checks for the Edge score, the Reality check and the Morning Wave journal.

## 2.35.0 — 2026-10-27
- 🌊 Morning Wave autopilot (Auto tab, top card, OFF until you turn it on, PAPER only until you allow LIVE). Trades only 4:00 to 10:00 AM, longs only, your watchlist plus pre-market movers up 2% or more. It buys the up-wave you see on the 5-minute chart: the trend ribbon turns green (the chart's BUY), or a pullback buy in a green trend, but only with real volume (1.3x the morning's normal and at least $50k on that candle), price above today's VWAP, the stock at $2 or more, a tight spread, and not stretched far above the trend line. Limit buy at the ask; stop under the last 3 candles or the slow line.
- It manages its own exits (stop orders are not allowed before 9:30): half off at +1.5R and the stop moves to break-even, the rest until a 5-minute close under the fast line, the trend turning red, +3R, or the window end (everything is sold by 10:00). Your settings: $250 risk a trade, stop for the day at +$1,000 (goal) or -$500, at most 3 open and 8 a morning, one trade per stock per 5-minute candle. Your daily loss limit, the earnings-day skip and LIVE PIN arming still apply. The card shows today's P&L against the goal, every trade, why each stock was bought or passed, and the last mornings. "Close all now" sells everything and stops it for the day.
- The manual-position guard and auto-harvest leave the Morning Wave's trades alone (it manages them).
- Fix: Dip calls sent its "in the zone" alerts even while it was switched off.
- Tests: new end-to-end check of the Morning Wave (finds the wave, buys, half off at the first target, break-even stop, second target, day goal, window, PAPER-only).

## 2.34.1 — 2026-10-27
- Fix: "Morning plan ready" arrived at 3:17 PM (twice). The plan was kept only in memory, so after an update or restart the app thought it had no plan yet, built one and alerted again, in the afternoon. Today's plan, its alerts and its trades are now saved and survive a restart; a plan built after 11 AM (because the app started late) shows on the card but does not send a "morning" alert. This also stops a restart from letting the plan buy the same stock a second time the same day.
- Tests: new check for the plan after a restart.

## 2.34.0 — 2026-10-27
- 📉 New tab: Dip calls (the 52-week-high setup from your video). A list of 15 quality, fast-moving companies to start (NVDA, AMZN, META, MSFT, GOOGL, AAPL, TSLA, NFLX, AVGO, AMD, CRM, ORCL, NOW, UBER, SHOP; add or remove any). The scanner shows each stock's 52-week high, its price and how far under the high it is, furthest first, with your zone drawn on a bar. When a stock is 15-25% under its high it buys a CALL about 6 months out with a strike about 10% above today's price, up to $500 per call. If the stock falls another 10% (of the high), it adds one more call with the same expiry (a "leg"). It sells when the stock is back within 5% of its high, when the call is up 100%, or when 30 days are left before expiry. Every setting has buttons on the tab.
- Dip calls safety: OFF until you turn it on. Limit orders at the ask during regular hours only (9:45 AM to 3:45 PM), at most 2 new calls a day and 8 open. PAPER buys by itself; LIVE buys by itself only when LIVE options are unlocked and you armed today with your PIN; nothing new after the daily loss limit halts trading. Alerts (new type "Dip calls", on): a stock enters its zone, a call is bought, a leg is added, a call is sold. Options can lose everything you pay for them.
- Hide tabs: ⚙ → Display → My trader level → "Tabs at the bottom". Tap a tab's name to hide it, tap again to bring it back (Auto always stays). Saved on this phone. Hidden tabs keep working in the background.
- Tests: new checks for the Dip calls rules (zone, contract pick, size, legs, exits, settings) and tab hiding.

## 2.33.0 — 2026-10-27
- Watchlist BUY / SELL alerts now match your chart. They used to watch a 3-minute trend built ONLY from today's candles since 4 AM, so in the early pre-market it had nothing to go on (it needs about 10 candles, and thin pre-market stocks trade only now and then), it did not line up with the 5-minute BUY / SELL you see on the chart, and it only covered the first 20 stocks of your watchlist. Now it uses the same 5-minute trend ribbon as the chart, warmed on the last few days of history (like the chart), for your whole watchlist, in every session from 4 AM: you get the alert when the 5-minute candle that turns the chart green (BUY) or red (SELL) closes. One alert per candle; after a restart an old flip does not alert again. Alert type "BUY / SELL" in Alerts settings (on by default).
- Tests: new check that the alert fires on the same candle as the chart's BUY in the pre-market, for a stock past the 20th on the watchlist, once.

## 2.32.2 — 2026-10-27
- Fix: the chart got stuck on one stock (the first in the scan list, for example XLP) and tapping another stock on your watchlist did nothing. Every refresh swapped your pick back for the first scanned stock whenever your pick was not in the scan list. A stock you pick (watchlist, shortlist or Robinhood) now stays on the chart until you pick another.
- Fix (likely cause of "trading frozen, manual still works"): the Alpaca library sends its web calls with NO time limit. If one connection stalled (Wi-Fi to mobile data, the phone dozing), the trading loop waited on it forever: the screen kept updating and your manual orders went through on fresh connections, but the bot never took another trade. Every Alpaca call now gives up after about 30 seconds and the loop tries again on its next pass.
- Fix: "Run checks" could sit on "Checking..." with no answer (the same stalled-call problem). The checks now finish within 20 seconds, and if Alpaca or the phone does not answer they say so and offer Reconnect.
- Fix: after an update, the Fix tab offered to re-apply a phone fix that the release already contained in slightly different words (the harvest "+$43.20 was an estimate" fix, built in since v2.27.1). Re-applying put a second copy of that code in. Such fixes now show as included and are not offered again.
- Tests: new checks for the chart pick, the Alpaca time limit, the time-limited checks and the included-fix detection.

## 2.32.1 — 2026-10-27
- Fix: the bot could slow to a crawl or look frozen (new trades stopped while manual trading still worked). The VWAP rejection and Gap and go pattern checks re-read the whole history on every candle: on 45 days of data VWAP rejection took 39 seconds and Gap and go 12 seconds on a computer, many times that on a phone, and the work competes with the trading loop. It runs whenever you open the Auto tab (the VWAP record), on every Autonomous-mode stock check, and in the Cycle and Open sweep read-outs. All pattern checks together for one stock went from about 65 seconds to about 6 (identical results, tested against the old code). The three history read-outs now run one at a time with a short pause, so they can never pile up.
- Open sweep check is about 3 times faster (it read the clock off every candle).
- Tests: new speed guard for every pattern, and a check that the read-outs run one at a time.

## 2.32.0 — 2026-10-25
- Cleanup from an audit of your own journal (657 trades, Sept 28 to Oct 14). Seven strategies lost money, about 83% of all the losses: REENTRY, MICRO_SCALP, EXT_MOMENTUM, MEAN_REVERT, FLUSH_BOUNCE, EMA_PULLBACK and RIBBON_FLIP. They are now switched OFF once, on update. Switch any of them back on in the Scorecard (Auto tab). Everything else keeps running and the auto-tuner still sizes them by record.
- Bad-price guard: two paper trades in the journal "closed" at prices nobody traded at (a $33.59 stock at $3.20 for +$12,339, a $23.59 stock at $4.40 for -$11,111). A closing price that is far from the last price the bot saw is now not believable: in PAPER the trade is recorded at the last seen price (the note says so) and you get a warning; in LIVE your real fill is kept and you get a warning to check it with your broker. This keeps the P&L, the daily loss limit and the learner from being fooled by one glitch.
- Stricter Autonomous gate: a pattern used to be trusted after only 3 past trades, which a coin flip passed about a quarter of the time (and with about 16 patterns per stock, several passed by luck every morning). It now needs 12 or more past trades, an average over +0.2R, at least 50% reaching the target, and both the older half and the newer half of those trades positive. This is a real tightening, not a guarantee: a pattern with no edge still passes occasionally.
- The five candlestick patterns (engulfing, hammer / shooting star, morning / evening star, three inside, three outside) are now one "Candle reversal" pattern, so Autonomous mode compares fewer things. Old saved presets that used them keep working.
- Removed unused code: three leftover script functions and two unused API routes (/api/ohub/payoff and /api/level/stats).
- Tests: new regression test for all of the above.

## 2.31.0 — 2026-10-25
- 🌅 Open sweep, pattern 20 (the "86 model" style morning setup, both ways). Price sweeps a low (or a high) away from the 9:30 open price, turns and closes back through the open price, then pulls back into the Golden zone (50-79% back down the move, or 62-79%) and a candle holds it. Stop just past the sweep; target is the high of the move when that pays at least 1R, otherwise 2R. Looks from 9:40 AM to a cut-off you choose (10:30, 11:00 or 11:30).
- Morning setups list (Auto tab): shows what is forming right now on your watchlist, with the open price, the sweep, the Golden zone, stop and target, and each stock's record over the past 45 days (worked out at once from history, no waiting). Your phone gets an alert when a setup starts forming and again when it is in the zone (new alert type "Open sweep", on by default).
- Auto-trade switch on the card (OFF by default): the bot takes Open sweep setups by itself on your watchlist. PAPER trades by itself; LIVE still needs your PIN arming, and the same gates apply (earnings, Focus, Heikin Ashi, Day Playbook cut-off, daily loss limit, trade caps). Autonomous mode also uses it on stocks where its record is good.
- On the chart: a pink dashed 9:30 open line, a yellow Golden zone box and ▲/▼ OPEN SWEEP labels. New Learn lesson 8 walks through it.
- Tests: new regression test for pattern 20 (buy, mirror short, forming and in-zone states, cut-off, settings, auto switch, alert type, chart and Learn hooks).

## 2.30.0 — 2026-10-25
- 🔁 Cycle turn, pattern 19 (Auto tab card, OFF unless Autonomous mode is on, PAPER first). Buys a cycle low and shorts a cycle high using the Stochastic 3·5·2 from the Top Dog Trading method. It needs the Stochastic to turn up through its signal line from under 20 (down from over 80 for shorts), then counts 5 checks: price back over the 9 average, the Stochastic turn, the cycle low, support (or the 50 average), and the 15-minute trend agreeing. You choose how many are needed (3, 4 or 5; default 4). A mini-divergence lifts the grade. Stop just past the turn; targets 1.5/2/3 times the risk.
- No waiting: the per-stock record is worked out at once from the past 45 days of history, so Autonomous mode only uses Cycle turn on stocks where its record is good.
- Shows on the chart for learning: a Stochastic panel under the live chart with the 20/80 lines, and ▲/▼ CYCLE labels with the grade. A new Learn lesson (Cycle turn) walks through the five checks with an example.
- Fix: two elements on the dashboard shared the name stOut (the options test result and the Stats tab), so one could write into the other. The options test now has its own name.
- Tests: 114 of 114 pass, and every tab loads with no script errors.

## 2.29.1 — 2026-10-24
- Fix: other phones stopped checking in with support. The free support tunnel gets a new address each time the collector restarts, but a phone only took the address from latest.json when it had none saved, so every phone kept reporting to the old dead address. Phones now follow the current address in latest.json (checked hourly when an update link is set). Phones on an older version need this update installed once by hand (or the new address pasted in), after which they keep up by themselves.

## 2.29.0 — 2026-10-24
- 🏃 Run Hunter (Auto tab, OFF by default, PAPER first). No fixed clock: it watches every minute from 4 AM for a stock starting a big run (up 3%+ in 15 minutes on 3x+ normal volume, price above VWAP, enough dollars traded to trust the quotes). News plus big volume, or very big volume, means it joins the run with a limit order and a trailing stop. A run on thinner volume with no news is faded: it waits for a VWAP rejection and shorts. It sells when the run is over: volume drops under half its peak, a lower high, a close under VWAP, or the trailing stop. Pick which parts of the day it may trade, size per run, and runs at once. Today's runs list shows times, the reason it ended, and skipped stocks with the reason. Same gates as everything else (Auto-trader running, LIVE PIN arming, earnings, Focus, Heikin Ashi, spread check, 6 a day PAPER / 4 LIVE).
- ⚡ VWAP rejection, pattern 18. After a new low of the day (after 9:30 or 10:00, your choice) price rallies back to VWAP and a candle closes under it: short, stop just above that candle, target 1.5/2/3 times the risk. The mirror image is a buy. It joins the Autonomous mode patterns list, so the bot uses it only where its record on that stock is good. New VWAP strip card (today, overnight and yesterday VWAP, opening range, trend per stock), its 45-day record per stock, and stop/target boxes on the chart for your own open trades (switchable).
- 🧭 Day Playbook (Auto tab, OFF by default). Reads the morning for each watchlist stock from overnight move, overnight volume and news, labels it (gap and fade, gap and run, news spike, quiet) and names the setup. Optionally stops opening NEW regular-hours trades at 10:30 or 11:30 (open trades are still managed and closed; pre-market and after-hours and Run Hunter are not affected). "Check my idea" replays the last 45 days: how often most of the day's range was done by 10:30. Shows what the bot did today and grades its own labels.

## 2.28.0 — 2026-10-24
- AI cost shows in the header as a small chip ("AI $0.42"; tap to open the AI tab; amber near your limit, red when paused). The More tab has a one-line AI summary too. New optional daily AI limit ($1, $2, $5 or Off) with a phone warning at 80% or 100%. When the limit is reached only the AI helpers pause until tomorrow; trading never uses AI and is never affected.
- Algorithm fix: a setup needs 20 closed trades to count as proven and trade at full size, but the self-tuning only looked at the last 12, so no setup could ever become proven and all were stuck at about 35% size. Proven now counts all of a setup's closed trades. A setup with fewer than 20 trades still trades small, and benched setups still only take one small test trade a day.
- Bug sweep: AI usage files are now saved safely (no half-written file after a crash); every tab loads with no script errors; compile check clean.

## 2.27.3 — 2026-10-23
- The AI cost card (tokens and estimated dollars per feature, today and this month) now lives on the AI tab, above the AI Helper, instead of the Auto tab. It also fixes a duplicate element name that could have confused the AI Helper card, and a test now guards against duplicate names.

## 2.27.2 — 2026-10-23
- Options school now also shows in the Learn tab (it is still on the Options tab too), with the same lessons and progress.

## 2.27.1 — 2026-10-23
- Auto-harvest now books the REAL fill price of the sale (looked up from Alpaca), so the "harvested +$X" number matches your Today P&L after hours. If the fill can't be read it falls back to the old estimate. Timing of sells and re-entries is unchanged. (From your phone's fix, which an update had overwritten.)
- Flip: the second leg (opening the other way) now checks buying power and opens a smaller position, or says so plainly, instead of being refused with "insufficient buying power". (From your phone's fix.)
- Checked every other fix in your fixes file against this version: they are already in the code (overnight Harvest now, restart mid-sale, re-entry bounce, jump-signal crashes, future-start bars, Robinhood quantity text and desktop-site hint, Morning wave quotes, extended-hours flush filter, 3rd-green harvest, position-not-found, Harvest all with 2+ positions, faster refresh). One was NOT carried over: separate daily loss limits for Paper and Live, because it changes loss-limit handling.

## 2.27.0 — 2026-10-23
- Options tab: "Why no options trade today?" counts the reasons by name (choppy market, no clean setup, price stretched, one contract over your premium limit, earnings, Focus, Heikin Ashi, signals on stocks not on your options list), with a one-line tip, a one-tap add of those stocks to the options list, and quick premium-limit buttons.
- Options follow the share signals (off by default): a fresh JUMP IN, or a Morning-plan trigger, also buys a call or a put through the options module's own checks (daily options budget, premium limit, earnings, Focus, Heikin Ashi, LIVE unlock). One try per stock, direction and source per 30 minutes. Time-to-expiry presets 3-7, 7-14 and 14-30 days.
- Options school: 8 short plain-dollar lessons (calls and puts, time decay, strikes and delta, why a stock can rise and the option still lose with a live teaching calculator, single option or spread, taking profit and cutting, why the bot skipped, a paper checklist) each with a one-question check; progress is kept on the phone. Education only.

## 2.26.0 — 2026-10-23
- Best times report (Auto tab): pick a stock and a wave size (1 to 3%) and see, from the last 45 days of 15-minute candles (4 AM to 8 PM), how many waves started in each half-hour and what a plain trade started then (stop and target 2 to 1, costs included, wider outside regular hours) would have made, buying or shorting. Top three half-hours, a bar chart of the whole day, and totals for pre-market, regular and after-hours. Past data only; with 32 half-hours some look good by luck, so use it to choose what to test on PAPER.
- AI cost counter (Auto tab): every AI call the app makes (Ask AI, Help, Fix with Claude, Strategy builder, Signal audit, chart reads) is counted per feature and day with tokens and an estimated dollar cost from list prices. Shows today, this month and by feature. Trading uses no AI. The real bill is in your AI provider's console.

## 2.25.0 — 2026-10-23
- Autonomous jump trading (Auto tab, off by default): the bot buys or shorts on a fresh JUMP IN and closes on JUMP OUT by itself. Limit entry with stop and target, dollar size cap, max open at once, strong-only, buy-only, extended hours, and an option to also close your own hand-opened trades. Needs the Auto-trader running; LIVE needs today's PIN arming; earnings, Focus and Heikin Ashi gates apply; no new shorts from 8 PM to 7 AM; 6 trades a day in PAPER and 4 in LIVE. Every action and skip is logged with its reason. Loss limits untouched.
- Harvest history with times: each harvest, re-entry and stop is saved with its time, price and gain. It shows under the Auto-harvest rows (newest first, "banked today") and stays after Stop or closing the position. Chart markers show the harvest time and gain.
- Send fixes to SEKEX button in Backup and fixes: one file with every fix on the phone plus the app version, to hand over so it goes into the next release. It publishes nothing by itself.

## 2.24.0 — 2026-10-22
- Overnight shorts (paper and LIVE): picks shorts 4:05 to 7:45 PM from weak peer groups (and optionally earnings tonight), enters before 8 PM, broker-held GTC stop and target, covers by the open; dynamic group cap

## 2.23.0 — 2026-10-21
- Radar: 'Always scanning' switch (on by default) keeps Radar, jump signals and the watchlist warnings refreshing every minute in every session, even with the tab closed or the Auto-trader stopped

## 2.22.1 — 2026-10-21
- Flip now works in two steps (close first, then open the other way once flat) because one order that crosses zero is rejected; clear alerts if either step stops

## 2.22.0 — 2026-10-21
- Heikin Ashi: chart style toggle (Regular / Heikin Ashi / Both) and an optional trend filter (off by default) that only allows buys while the smoothed candles are green and shorts while red, for stocks, options and Autonomous

## 2.21.1 — 2026-10-20
- Flip button on your own positions: reverse a long to a short (or back) in one order, with the loss-limit, shorting and extended-hours rules applied

## 2.21.0 — 2026-10-20
- Autonomous: Morning plan builds itself at 8:30 and 9:15 AM with an alert and (optional) places the plan's entries; options no longer pay the spread on early trend-flip exits and never open the same stock twice in 5 minutes

## 2.20.0 — 2026-10-20
- Morning plan card (Auto tab): gap, key levels and a buy / short entry with stop and targets for up to 5 stocks, display only; stock trade journal Export CSV

## 2.19.7 — 2026-10-19
- Earnings and risky-news filter now also guards the pattern finder, Autonomous mode and options (Autopilot and auto entries): no new trade in a stock on its earnings day.

## 2.19.6 — 2026-10-19
- Alert popups: the '+N more' chip moved up into the header, right next to the session badge (After-hours etc.), so it never covers your balance or stats; swipe a popup left or right to dismiss it; popups no longer block taps on the screen behind them.

## 2.19.5 — 2026-10-19
- Focus mode: pick 1 to 5 stocks and the bot, pattern finder, options and Autopilot open new trades only in those; exits and manual trades untouched

## 2.19.4 — 2026-10-18
- Autonomous options: pattern signals with a good record on a stock buy a call (up) or put (down) through the options module; switch in the Options tab, choice of shares / options / both in the AI tab

## 2.19.3 — 2026-10-18
- Publishing no longer crashes when the phone connection drops mid-upload (Errno 103): it retries, checks whether the first try got through, and gives a plain message

## 2.19.2 — 2026-10-18
- Robinhood tab: Stocks I own list always shows (Agentic account, optional view-only other accounts), picks the stock positions command, plain options status

## 2.19.1 — 2026-10-18
- Robinhood tab shows only your Agentic (MCP) account, with its cash, buying power and account value; holdings, orders and the overview are filtered to it

## 2.19.0 — 2026-10-18
- Autonomous mode: the bot picks from 17 patterns per stock by its own 30-day record. New patterns: candlesticks (engulfing, hammer/shooting star, morning/evening star, three inside, three outside), head & shoulders, double top/bottom, triangle, trend-line break, MA cross, RSI turn. Chop filter (gray candles) and weak-zone skipping.

## 2.18.3 — 2026-10-17
- Options tab in plain words: pick Careful, Balanced or Bolder (each shows dollars, no percentages), tap stock groups, a plain status line, results in dollars. All the old settings are kept under Fine-tune, also in dollars

## 2.18.2 — 2026-10-17
- Presets now run inside the Auto-trader: they trade only while the Auto switch is ON, in PAPER and in LIVE (LIVE needs the Live PIN to arm each day, 3 a day cap), on every stock the bot scans. New Zone retest / support-bounce preset pattern

## 2.18.1 — 2026-10-17
- New preset pattern: Sweep + CHoCH + FVG (smart-money liquidity sweep, change of character, retest of the fair value gap), long and short, structure stop just past the sweep, drawn with SWEEP / CHoCH / FVG zone marks

## 2.18.0 — 2026-10-17
- Strategy builder on the AI tab: describe a setup or add chart screenshots, get a back-tested preset drawn as an image; daily pattern review after the close and pre-market; presets can auto-trade in PAPER only. Early BUY?/SELL? boxes on the chart are now tappable (always ask first)

## 2.17.9 — 2026-10-16
- Gear screen simplified: Broker settings, separate App Updates, This phone, one tabbed Help & AI card; Run check-up now runs in the background (no more busy timeout)

## 2.17.8 — 2026-10-16
- AI recovers by itself: a retired/unknown model re-picks and retries, busy/rate-limited (429, 5xx, 529) retries once, and a failed model list is no longer trusted. Diagnostics heartbeat waits 20 s (was 8) and tries twice, so slow tunnels and dropped mobile connections still get counted by the collector.

## 2.17.7 — 2026-10-15
- Chart: a bold tag directly above the chart shows the symbol, timeframe, price, VOLUME (latest candle and x the 20-candle average) and your position with P&L; the symbol is also a faint watermark inside the chart. The tag stays pinned under the header while you scroll.

## 2.17.6 — 2026-10-15
- Chart: a stock tag (symbol, timeframe, price, and your position with P&L) sits above the chart and follows you at the top of the screen while you scroll through it, so you always see which stock the chart is.

## 2.17.5 — 2026-10-15
- Spread: harvest sells and re-entries now start at the MIDDLE of bid/ask and walk to the far side over the retries instead of paying the full spread every cycle (protective stops still cross at once). Wide spreads (over your max-spread setting) block auto-start and re-entry. Positions can show P&L as market price or as what you'd really get (bid/ask).

## 2.17.4 — 2026-10-15
- Positions: every row now shows the live bid / ask and Alpaca's own price and P&L ('✓ matches Alpaca', or Alpaca's numbers when they differ after hours), plus an '↗ Alpaca' button to open your account on their site.

## 2.17.3 — 2026-10-15
- Radar jump signals: one card per stock (newest only), WEAK jump-ins hidden and not alerted by default ('Strong & good only' checkbox), and at most one alert per stock per 30 minutes.

## 2.17.2 — 2026-10-15
- Popup alerts no longer fill the screen: max 3 at a time, repeats merge (x3), tap to dismiss, shorter for low-priority ones, a '+N more' chip opens the bell, and Settings > Alerts > 'Popups on screen' (All / Important only / Off). Fixed plain-text popups showing 'undefined'.

## 2.17.1 — 2026-10-15
- New 'sekex repo' menu in Termux: lists every file in your GitHub update repo (old SekexBot files and anything else), tick what to remove, type DELETE. The files the app needs are locked.

## 2.17.0 — 2026-10-15
- Robinhood tab: your Robinhood positions first (P&L, trend, Sell all / Sell half / Decide / Chart), a Decide-here card with trend and levels, and phone alerts for a profit $, a price or a time (server-side, work with the app closed). Orders still need your PIN and confirm.

## 2.16.0 — 2026-10-15
- Your own trades are now automatic: once a stock you bought shows steady profit, the app banks it (learned level or when the gain fades), buys back in while the trend holds, and moves on. Never sells at a loss on its own. New 🤖 Auto sheet replaces typing a target; Settings checkbox to turn it off.

## 2.15.2 — 2026-10-15
- **Positions tab opens with Positions & orders** (then the chart, then Profit taking & re-entry, then Review).
- **Position rows are readable and no longer run off the screen.** The table now fits the phone width (the P&L column is no longer pushed out of view), and each position has its own row of buttons with words instead of icons: Close all, Close half, 🎯 Take $ when green, ⏰ Close later, ♻ Auto-harvest ON/OFF, ⚡ Harvest now. The small ♻ tag next to the symbol now reads AUTO-HARVEST, and a one-line legend under the table explains each button.

## 2.15.1 — 2026-10-15
- **No more deleting by hand before the next upgrade.** Once a version is both installed (`sekex update`) and published (`sekex ship` / `sekex publish`), the leftover `SekexBot_Setup.sh` and `latest.json` in Downloads are renamed to `SekexBot_Setup.sh.old` and `latest.json.old`, so the next download is not saved as "(1)". A phone that does not publish only needs the update step. Nothing is deleted, files from a newer release are left alone, and the old `.old` copy is replaced each time.

## 2.15.0 — 2026-10-15
- **Tabs reorganised (less duplication, clearer flow).**
  - **Auto:** one "Sessions" card (Auto-trader on/off, session focus, long+short system, with Session auto-off and Pre-market preset folded inside), then chart, Profit taking & re-entry, Open positions, Activity, Why no trade?, Daily max loss, and the whole Controls block collapsed under "Settings & Controls" (tap to open).
  - **Positions:** chart first, Profit taking, Positions & orders, then one "Review" card with tabs (Journal, Daily, Stats, Scorecard, Learned, Self-fix, Close-now). The Account card is gone (balances are in the top strip).
  - **Radar:** "Prep" (timeline, morning, evening, overnight) and "Candidates" (big movers, setting up now, stock picker) are now one tabbed card each, moved here from Auto.
  - **Manual:** the Trade pad and Manual ticket share one card with two tabs.
  - Nothing was deleted: every setting and id is kept, and your daily loss limit is unchanged.
- **Controls are colour-coded.** Each group of switches under Advanced has its own coloured header (Sessions & shorts blue, Entries & signals green, Exits & profit amber, Risk & guards red, Self-learning purple, Screen & support teal, Data & app teal) and alternating shaded rows, so the list no longer blends together.
- **Overnight fix (from your phone's own fix, now built in):** before the open, the minute-bars call no longer asks Alpaca for a start time that has not happened yet (Alpaca answered 400 and filled the log). The Jump scanner also starts from the previous day before 9:30. Charts themselves were not affected: they use a separate overnight-aware data path.

## 2.14.3 — 2026-10-15
- **Fix: Jump in / Jump out scanner crashed every time it found a signal** (the price was passed where the stock's own record belongs), so no Jump alerts or Radar cards ever appeared. Fixed, with a test.

## 2.14.2 — 2026-10-15
- **Tab flow.** Positions tab now opens with the chart first, then Profit taking & re-entry, then Positions & orders, then Account, close-now log, stats and journal. Auto tab now runs: session focus, getting started, Auto-trader on/off, chart, Profit taking & re-entry, Open positions, Activity, then the rest of the settings (Controls and the advanced cards are below the chart). Manual tab unchanged.

## 2.14.1 — 2026-10-15
- Take-$ tracer made lighter: positions are cached for 10 s and quotes come in one batch from the live stream, so it no longer adds Alpaca requests every few seconds (it could compete with the scanner for the request limit).

## 2.14.0 — 2026-10-14
- **💰 Profit taking & re-entry** moved onto the Positions tab, with the Trend ribbon chart now on top (above the settings and the position list). The Harvest small %, Auto-learn and Auto re-entry switches live in that card; the Controls card no longer carries them.
- **📈 The bot learns how high your trades run.** Every finished trade (bot and yours) leaves a record of its best gain and where it ended. For each stock and session it picks the take-profit level that would have banked the most, and the bot's harvest uses it. Until a stock has 8 finished trades it uses your fixed % (default 0.10%). Switch: "Learn how high my trades run". The 15-trade "learn from my manual wins" option stays as it was.
- **🎯 Take $ when green** button on every position. It traces the exit P&L (after the spread) with a small chart, shows the best so far, and suggests the learned level in dollars. Type an amount or tap Use learned. When the exit P&L reaches it, the position is closed. A BOT trade closes with the harvest note, so the bot can re-enter while the trend holds; your own trades are only closed, never re-entered. It keeps watching with the app closed and survives a restart.
- Why CORD did not harvest after hours: the wide spread meant a "close now" would have given back about half the mark profit, so the after-hours rule held out for a bigger gain. The take button measures the real exit price, so it does not fire on a profit that would not survive the exit.
- The daily loss limit is not touched.

## 2.13.0 — 2026-10-14
- **📈 Jump in / Jump out** at the top of the Radar tab. On 5-minute candles it watches your open trades, your watchlist and the Day drive picks and pings your phone. **JUMP IN (buy)**: an uptrend pulls back to its average on lighter volume and a green candle closes back above the fast average. **JUMP IN (short)**: a downtrend bounces into its average, fails, and a red candle closes back under. **DON'T CHASE**: a vertical bar on a burst of volume far from its average (the GOOGL open spike). **JUMP OUT** for a trade you hold: price closes back through its moving average or VWAP, or a volume climax with a long wick. Each JUMP IN card has the entry zone, stop, two targets, the projected profit on the proposed purchase and that stock's own 45-day record of the same setup (how many reached target 1, how many hit the stop). Tap a card to trade it yourself or let the bot take it.
- **Markers on the Trend ribbon chart**: JUMP IN, DON'T CHASE and (for a stock you hold) JUMP OUT labels on the candles, with the signal's stop and target 1 drawn as dashed lines.
- **Tap-to-trade on the chart.** Touch a candle and the readout shows Buy here / Short here (or, for a position you hold, Set stop here / Set target here / Close position) at the price you touched. Mode switch in the Radar card: Off, Ask me first (an order summary you confirm) or Auto (sends the moment you tap; on a LIVE account turning Auto on needs your Live PIN). Orders are sized from your risk budget and still obey the daily loss limit, spread and short rules. The chart's crosshair on/off button is unchanged and remembered.
- Alerts: new "Jump in / Jump out signals" type (on by default) under Alerts.

## 2.12.0 — 2026-10-13
- **🚀 Day drives** replaces Open drive in the Radar tab: four windows a day, each with buy AND short forecasts and that stock's own 45-day record of the same setup. Overnight (8 PM to 9:30 AM: flush-and-reclaim, overnight build, overnight breakdown), Open (9:30 to 10:30), After lunch (1:00 to 2:30, breaks the 11:30-1:00 range) and Close (3:00 to 3:55, breaks the day high/low and VWAP). Close shorts show a LAST CALL before 4 PM (Alpaca allows no new shorts after 4), what the stock did overnight after similar days, an oversold-short warning, and the Alpaca borrow check.
- **🤖 Radar Autopilot** (off by default, manual stays the default). Per window Manual or Auto. Your rules: min score 70, min record 60% over at least 5 cases, max 3 trades a day, 2 open, $2,000 per trade, no entries after 3:30 PM, flat by 3:55 PM unless you allow overnight holds, same-theme cap, pause when SPY is down 1.5%, window auto-pauses after 4 losing trades in a row. It starts in LOG-ONLY mode (writes what it would do, sends nothing). Turning it on for LIVE needs your Live PIN. It never changes your daily loss limit, leaves your own trades alone, and has a "Stop and close autopilot trades" button, an activity log and an evening summary.
- **Stocks only / Options only / Both** for Autopilot: calls for buys, puts for shorts (options 9:35 AM to 3:40 PM), with a log-only dry run of the option order.
- **Test that options work**: checks account permission, options buying power, the chain, a quote, a dry-run order and the hours, plus an optional 1-contract round trip (paper is free; LIVE shows the cost and needs the PIN).
- **Replay on my stocks**: what each window would have done over the last 45 days (rough, 15-minute bars).
- Fixes: the volume baseline now uses the same data feed as the live scan; unfilled Autopilot entries are cancelled after 2 minutes; Autopilot trades have a dollar cap per trade.

## 2.11.0 — 2026-10-13
- **🚀 Open drive** at the top of the Radar tab. From 9:30 to 10:30 AM on trading days the app scans your watchlist, positions and movers every 30 seconds for a stock that was quiet in pre-market and then breaks above its pre-market high on a burst of volume (default: 3x normal and +0.8% since the open). You get a phone alert and a card with the buy zone (do not chase above it), a stop just under the breakout, two targets, the projected profit on the proposed purchase, and that stock's own record of such breakouts over the last 45 days (how many kept going, how many fell back).
- Tap a card to trade it yourself (pre-filled ticket) or let the bot take it. Optional setting "Bot may trade it" (off by default): the bot arms only breakouts with a past record of 55% or better over at least 4 breakouts and a score of 70+, and still obeys the daily loss limit, spread and news checks.
- Settings for the alert, the volume multiple and the minimum move are inside the card.

## 2.10.0 — 2026-10-13
- **🔎 Stock review & reversal watch** at the top of the Radar tab. Type or tap any stock (your open positions are one tap away) to see what it usually does tonight (4 PM to the open) and in the first two hours tomorrow, based on that stock's own last 45 days after days that closed like this one. It warns about risky spots (for example shorting into the close after several down days), and shows the typical low and high, a cover zone and stops.
- **Reversal alerts.** Tap "Watch" and the phone pings you, day and night (checked every minute), when the stock bounces off its low so you can cover a short before it falls again, when your open profit has shrunk by a fifth from its best ("protect your profit"), and when the bounce fades. Works for longs too (alerts on a slip off the high). Alert only: nothing is closed for you. Switch it on or off under Alerts → "Reversal watch".
- **Upload a screenshot** from the same card: Claude reads your chart or position and answers where you are in the move and the best exit (needs your AI key).

## 2.9.2 — 2026-10-13
- **Faster, safer restarts.** The app no longer waits forever on a stalled connection to Alpaca while starting (15-second limit), so the dashboard opens even when the phone's network is slow right after an update or restart.
- An old copy that is slow to close is now force-closed after 6 seconds, so it can't keep the lock and block the new copy (the "already running" hang).
- `sekex restart` now skips the 5-second wait, force-stops a stuck copy, waits up to 2 minutes for the new one and shows progress dots.

## 2.9.1 — 2026-10-13
- **Radar "Let the bot take it" no longer fails silently.** A card whose buy window had already started (typical for overnight cards) could be refused without a visible reason; it now arms for today. Any refusal or lost connection is now shown right at the top of the card sheet and as a pop-up, the button shows "Sending to the bot…", and the sheet scrolls so the buttons are never hidden behind the bottom bar.
- **Fix with Claude** now answers immediately ("Sending your description to Claude…") and shows a clear message if the app is busy or cannot be reached, instead of looking dead.
- The 24-hour board is built one request at a time, so repeated taps or auto-refresh cannot pile up on a slow phone.
- Cards for tomorrow's open now say "for <date>" on the arm button instead of "today only".

## 2.9.0 — 2026-10-12
- **📡 Radar · next 24 hours.** A new board at the very top of the Radar tab lists every setup that can be traded in the next 24 hours, best score first. Each card says when to BUY (a date and time window) and when to SELL by, with the buy zone, stop, two targets, the proposed number of shares, the projected profit at target 1 and 2, the loss at the stop, and an expected profit taken from that stock's own history. Filter chips: Tonight, Pre-market, Open, Midday, After-hours.
- **Five new setup types** next to the classic morning / intraday / after-hours / overnight waves: Oversold bounce, Trend pullback, Range breakout, Volume surge, and Gap & Go (pre-market gaps of 1%+). Hit rate and stop rate are measured on the same stock's last 45 days; when the target and the stop both happened in one window it counts as the stop.
- **Same ways to trade as before.** Tap a card to open the pre-filled ticket (limit, stop and target) or to let the bot take it. A card for tomorrow's open can now be armed tonight: the bot takes it on that day when the price is inside the zone, with the usual daily loss limit, spread and news checks. The old "Trade the wave" switch is unchanged and still covers only the classic setups.

## 2.8.2 — 2026-10-12
- **Positions now keep moving at night.** Overnight, pre-market and after-hours, the Positions list used the middle of the quote, which in thin hours is a wide gap that rarely changes. It now uses the latest real trade from the overnight feed when there is one from the last 20 minutes, and falls back to the quote middle only when there isn't. Each row shows where the price came from (last trade or mid quote), how old it is (amber if older than 15 minutes) and the bid/ask gap, so you can tell a quiet market from a stuck app.

## 2.8.1 — 2026-10-12
- **Slide to see your potential profit.** Under the profit/loss graph on the Options ticket there is now a price slider. Drag it to any stock price and the graph marks it and shows your profit or loss (in dollars and %) if the stock is there when the option expires. It follows your limit price and number of contracts.

## 2.8.0 — 2026-10-12
- **Support can suggest a preset to a user, and the user taps Apply.** In the Admin add-on, open a user's trade logs and tap ✨ Suggest a preset. The AI drafts a name, the settings and a plain-English reason from that user's numbers; you edit them, then send. On the user's phone (when "Help SekexBot support" is on) a card appears at the top: "Your support person suggests a preset", showing exactly what would change. Nothing changes until the user taps **Apply**; **No thanks** dismisses it. The Admin screen shows Sent → Seen → Applied or Declined, and you can withdraw an offer.
- **Safety:** only the preset settings can be sent (trade limits, scalp/shorts/re-entry switches, extended-hours switches, risk per trade, max positions), each clamped to a safe range. The daily loss limit, API keys, PIN and Live/Paper mode can never be sent or applied; both the collector and the phone refuse them. Applying saves it as a preset (switch back any time under Auto → Controls → My presets).
- Needs the new support collector (sekexbot_collector.zip) on your PC. Old collectors keep working for everything else; they just have no offers.

## 2.7.2 — 2026-10-12
- **New built-in preset: "Fewer, bigger trades".** Find it under Auto → Controls → 💾 My presets and tap it. It allows at most 2 open trades, turns off quick scalps, "trade every flip", re-entries, % harvesting and the pre-market / after-hours sessions, keeps the time-of-day filter and cool-offs on, and raises the risk per trade to 30% of your daily limit (so each trade is about 1.5x bigger than at Aggressive, and trades are roughly a third as many).
- **It never changes your daily loss limit.** Three full losses at this size would reach the limit, so keep an eye on the limit you chose. Tap your old level (or a saved preset) to go back.
- Presets that you saved yourself now also remember the re-entry and % harvest switches.

## 2.7.1 — 2026-10-12
- **Options are now one tap away.** A new **🧩 Options** tab in the bottom bar holds the **🎯 What should the bot trade?** switch (📈 Stocks only / 🧩 Options only / ⚖️ Both) on top, the **Options Hub** (pick a strike and buy or sell a call or put) under it, and the bot's Options card. The same switch is also the first card on the Auto / Home tab, so you can change it without hunting.
- These cards now show in Rookie mode too (before, they were hidden unless you were in Trader or Advanced). The bot's own detailed Options limits still show in Advanced only.
- Nothing about trading rules changed. Your daily loss limit is untouched.

## 2.7.0 — 2026-10-12
- **🧩 Options Hub (Manual tab).** Buy a single call or put yourself, or sell one you already own. Type a stock (or tap one from your watchlist), pick Buy or Sell and Call or Put, pick an expiry, then tap a strike. The list shows each strike's breakeven, the % move needed to reach it, open interest and ask price, with a green edge for in-the-money, and a ⚠ for a wide spread, thin open interest or no quote.
- **The order ticket** starts at the ask and has limit price and contracts steppers, estimated cost, max loss, max profit, breakeven and a profit/loss graph at expiry with a "now" line. Orders are limit, good for the day.
- **Safety:** long calls and puts only (no naked selling; Sell only closes what you own), regular hours only, a confirm box that states the whole amount you can lose, cost checked against your options buying power, new buys refused after your daily loss limit stops trading (closing is always allowed), contracts the options bot is managing are refused, and on LIVE it needs options unlocked plus your Live PIN. Your daily loss limit setting is unchanged.
- Needs an Alpaca account approved for options (paper accounts usually are). Tested with a stub broker only, not yet against live Alpaca options data.

## 2.6.0 — 2026-10-12
- **🎯 "What should the bot trade?" switch on the Auto tab:** 📈 Stocks only, 🧩 Options only, or ⚖️ Both. Options only stops all new stock entries (regular hours, pre/after-hours, overnight, armed picks and wave trades) while the stock side still manages and exits anything you already hold. It turns the options module on for you; on a LIVE account you still have to unlock options with your PIN first, and if that is refused nothing changes.
- Stocks only turns the options module off (open option positions are still managed to their exit). Both runs each by its own limits. Your daily loss limit applies in every mode and was not changed.

## 2.5.9 — 2026-10-12
- **Chart crosshair on/off.** New **✛ Cross** button above the chart. Turn it off and touching the chart no longer draws the crosshair or pins points: dragging slides the chart, pinch or scroll still zooms, double-tap still resets, and the ⚡ Trade button is untouched. Your choice is remembered.

## 2.5.8 — 2026-10-12
- **Robinhood tab has a chart.** Pick a stock there and a 📈 Chart button appears next to the quote; tapping it jumps to the real candle / VWAP / ribbon chart (the same one Auto and Manual use) for that symbol. No new chart engine, no change to order flow.
- **Positions list no longer shows stale overnight / pre-market / after-hours prices.** Outside regular hours the Positions list now uses the same fresh bid/ask mid-quote for price, P&L and P&L % that the close-now figure uses, instead of the last (possibly hours-old) trade.

## 2.5.7 — 2026-10-11
- **`sekex ship` / `sekex publish` now upload every public release file, not only the zip.** Before, only the app zip, the encrypted admin add-on and latest.json went to GitHub. Now it also uploads **SekexBot_Setup.sh** and the **release-notes PDF** (found next to the zip or in Downloads), skips files GitHub already has, and uploads latest.json last. Step 1 lists exactly what will be uploaded, and warns if a file is missing or if the installer in Downloads is for a different version (that one is never uploaded, so nobody installs an old app).
- Old release-notes PDFs on GitHub are tidied with the zips (keeping the newest 3). The plain Admin zip is never uploaded; only the encrypted add-on is.
- To publish this release use the new Setup.sh or `sekex update` first, so the phone has the new uploader, then run `sekex ship`.

## 2.5.6 — 2026-10-11
- **Fixes the "Connection pool is full" warnings** in the log (seen overnight when the dashboard asks for many prices at once). Alpaca's Python library keeps only 10 connections per client; the app now gives each client 40, so busy screens no longer open a fresh connection for every overflow and feel less sluggish. Warnings only; no trading logic changed.

## 2.5.5 — 2026-10-11
- **Night and extended-hours manual orders now cover the spread.** Alpaca accepts limit orders only outside regular hours, so a Market order from the Manual pad used to be refused with "accepts limit orders only". It is now sent automatically as a limit priced 0.2% through the far side of the spread (buy above the ask, sell below the bid), so it fills like a market order, and the reply tells you the exact limit price used. The confirmation box says so before you send. Orders with an attached stop-loss or take-profit still need regular hours, as before.
- The quick-trade sheet already did this; the bot's own night and extended entries and exits were already marketable limits and are unchanged.

## 2.5.4 — 2026-10-11
- **Cheap stocks get a sane stop and targets.** Radar setups now keep the stop at least 1% of the price (never under 4 cents) away from the entry, and the targets scale with it, so a $1.50 stock no longer gets a $0.13 second target. Prices under $1 show four decimals.
- **Watchlist button follows what you hold:** 🛒 Buy when you have nothing, ✓ Own N (tap to sell, add or close) when long, ↩ Cover N when short, ⏳ Order when an order is already open, so you cannot double-buy by accident.
- **Ollama through a Cloudflare tunnel:** 🔑 Broker keys → AI → Ollama has optional Cloudflare Access Client ID and Secret fields (service token). They are sent as the CF-Access headers on every Ollama request; a Remove link clears them, and a 401/403 on Test now points to them.
- **New lesson screen "Try it on a real stock"** (screen 12 of 13 in A good setup, start to finish): type a symbol (or tap one from your watchlist), pick Buy or Short, and SekexBot reads the last 60 fifteen-minute candles and ticks the 7 checklist boxes with a plain-English reason for each, plus a small chart with the floor, ceiling, stop and target. It is a rough automatic read to practice with, not advice, and nothing is ordered.
- Not changed: the Robinhood balance (still needs the Robinhood tool list), and your daily loss limit.

## 2.5.3 — 2026-10-11
- **Radar weekend plan.** From Friday 8 PM to Sunday 8 PM ET the card shows a 📅 "Weekend plan" banner explaining that no new market data exists and the setups are Monday 4-11 AM ideas scored from Friday's close.
- **Radar rebuilds itself on Sunday** at about 6:00 PM and 7:45 PM ET (the second one picks up the first overnight bars) and sends a notification ("Radar weekend plan ready / refreshed"). If the app starts during the weekend gap it also builds once quietly. The banner shows the last automatic rebuild time.
- Needs the app running on the phone at those times; nothing is placed or changed, display only.

## 2.5.2 — 2026-10-11
- **Radar card shows when its data was last updated** ("updated 3:47:45 PM (12 min ago)"). It turns amber with a **STALE: tap Refresh** warning after 10 minutes, red after 30 minutes, and says "refresh failed, showing old data" if a refresh cannot load.
- **Only one SekexBot can run per data folder.** A second copy now stops with "SekexBot is already running" instead of starting a double instance (which caused duplicate log lines and "connection limit exceeded"). The lock is released automatically if the app dies, and `sekex restart` waits a few seconds for the old copy to finish. The auto-restart watchdog does not loop on this.
- **Only one price-stream connection at a time.** The old stream is now closed (and waited for) before a new one opens, for example when you switch Paper/Live or reconnect, and a second feed can never be started alongside the first.
- Logging can no longer stack a second set of handlers, which removes duplicate log lines inside one app.
- If you still see duplicate lines after updating, check for another device or a Windows PC using the same Alpaca keys: Alpaca allows one stream per account, and that cannot be detected from here.

## 2.5.1 — 2026-10-11
- Re-applied two fixes made on the phone with "Fix with Claude" that were lost in updates (the rest of your exported fixes were already in the code):
  - **Radar → Manual (watchlist):** choosing Manual with an empty list now fills it from your watchlist (first 20 symbols), so the button visibly does something. You can add or remove symbols as usual.
  - **Robinhood orders:** numbers such as the share count are sent as text when the Robinhood tool asks for text, so the order is no longer rejected. The Live PIN and confirmation checks are unchanged.
- Orders, sizing, stops and your daily loss limit are untouched.

## 2.5.0 — 2026-10-11
- **New Learn lesson: 📈 A good setup, start to finish (12 screens).** Teaches a complete buy or short idea step by step with fresh chart drawings: trend (HH/HL, LH/LL), **floor and ceiling** (support and resistance), where stops hide (equal highs/lows, liquidity), the sweep, the change of character (CHoCH), the entry zone, stop and target, a share-size calculator that uses your own daily loss limit, the same recipe mirrored for a short, a quiz, and a 7-box checklist with buttons to practice a trade, open Radar or open the Manual pad.
- Buy view / Short view toggle on every chart. Practice only: nothing touches your broker, and your daily loss limit is never changed.
- The "Your first trade" result screen now links to the new lesson.

## 2.4.0 — 2026-10-10
- **Ollama can now be the AI brain.** 🔑 Broker keys → AI has a third choice, **Ollama (local)**: enter its address (for example http://192.168.1.50:11434 for a PC on your Wi-Fi, or http://127.0.0.1:11434 if Ollama runs on this phone in Termux), optionally pick a model, then Save, Use this AI and Test (the AI tab button now reads Claude / ChatGPT / Ollama). The Test button lists the models Ollama has installed so you can tap one.
- It powers the same features as Claude and ChatGPT (Ask AI, chart reader, check-up, signal review, Fix with Claude). No API key and no per-use cost; small local models are slower and less accurate, so double-check anything important. Trading never depends on any AI.
- A saved Claude or ChatGPT key is still preferred unless you choose Ollama, so nothing changes for you until you do.

## 2.3.1 — 2026-10-10
- The tab is now called **Radar** in every mode (it was Setups in Trader / Advanced, which did not match the page heading).
- **More is now a gear ⚙ at the top right** (next to the theme, bell and sound buttons) instead of a tab at the bottom. Tap it to open settings and help; it lights up while open.

## 2.3.0 — 2026-10-10
- **New guided lessons in the Learn tab (practice only, no broker is touched):**
  - **🎯 Your first trade** (11 screens): the idea (buy up / short down), pick a practice stock, shares, market vs limit, stop and target, plain-English review with a checkbox, place the practice order, watch it move live, close it (sell to close / buy to cover, or let the stop or target do it), and a result with a recap.
  - **📡 How to read a Radar idea** (8 screens): what Radar is, rising vs falling, reading the card (hit rate and n), the zone / stop / targets, projected profit, the RSI zone box, choosing your list and session, and how to act safely.
- **Predict is now Radar** in Rookie mode and **Setups** in Trader / Advanced mode (new 📡 icon). The Radar tab has a 🧭 How to read button that opens the lesson.

## 2.2.3 — 2026-10-10
- `sekex ship` now asks two questions: "Publish to GitHub? [Y/n]" and then "Also delete the old files? [y/N]". Answering no to the delete question still publishes; the old files are simply kept. Add `--keep-old` to skip the delete question, or `--yes` to publish and delete without asking.

## 2.2.2 — 2026-10-10
- **Fixed: inflated Morning wave hit rates.** The "next morning" check wrongly started at 4 AM of the same day, so that day's own swings counted as hits. It now measures only the next morning 4:00-11:00 AM from the close, as described. Hit rates and scores are now honest, so fewer cards will pass the bar; that is expected.
- Fixed: the plan panel said the bot never shorts Fall cards; it only means Trade the wave is buy-only (an armed Fall card can short when Shorting is on).
- Fixed: the RSI zone box was missing on cards past the 12th when you use a list of up to 20 stocks.
- Fixed: tapping tabs/lists quickly could let a slower old response overwrite the newer Radar cards.

## 2.2.1 — 2026-10-10
- sekex ship / publish / update skip a damaged or half-downloaded zip and use the newest complete one, with a clear message instead of a crash

## 2.2.0 — 2026-10-10
- Predict cards show projected profit on the proposed purchase: shares, cost, profit at TP1/TP2, loss if stopped

## 2.1.0 — 2026-10-10
- RSI zone read: trend, RSI zone and pullback/bounce signal with its real past record, on the Manual pad and Predict cards, plus an optional watchlist alert

## 2.0.0 — 2026-10-09
- SekexBot 2.0: Robinhood trading with setup wizard, tap-and-knob ticket, holdings and orders; Predict and AI Helper tabs; wave modes for every session; separate Live and Paper loss limits; auto-tune and daily check-up

## 1.100.0 — 2026-10-09
- Robinhood setup wizard: 7 guided steps from opening the Agentic account to a first 1-share test; dollar presets like the Manual pad

## 1.99.2 — 2026-10-09
- Robinhood screen: tap-and-dial ticket with live price, cost vs buying power, dollars or shares, time-in-force, stop-loss/take-profit when offered, account line, holdings with Sell buttons, open orders with Cancel, readable results

## 1.99.1 — 2026-10-09
- Robinhood ticket is fully tap-driven (stock chips, share buttons, Market/Limit, PIN keypad, confirm button) and sends each value in the type Robinhood expects (quantity as text); extra required fields such as the account appear as buttons

## 1.99.0 — 2026-10-09
- New AI tab for every trader level: one AI Helper you can type or talk to. Tap a time of day (pre-market, open, morning, after lunch, before close, after-hours) for a scan of which stocks have the biggest history of large gains or drops then, or ask in plain words; it can also read a chart, show Predict setups, check your day, run the check-up and health checks, and turn a problem into a draft fix for your approval. Read-only: it cannot trade or change settings.

## 1.98.0 — 2026-10-09
- Proactive bot: option entries that do not fill are re-priced toward the ask up to 2 times (never above your max premium) before cancelling; option fill rate auto-tunes the wait and re-price step (logged); a daily Check-up (More > Check-up & auto-tune) reports repeating errors, loss-limit use, fills and strategies in plain words and can draft a code fix for your PIN approval; duplicate log lines removed. Loss limits are never touched.

## 1.97.0 — 2026-10-09
- New Predict tab for every trader level (Rookie, Trader, Advanced): the Potential Rise / Fall prediction boxes for the current session with a plain-English 'Why this setup and how to trade it' lesson on every card and a 'How to read these boxes' guide; choose Auto top 10 or My list (type your own symbols, up to 20).

## 1.96.3 — 2026-10-09
- Remote access: pasting a Cloudflare tunnel ID (short UUID) instead of the token now explains the difference and where to find the real token.

## 1.96.2 — 2026-10-09
- The gear button in the header is replaced by a one-tap light/dark theme switch (settings stay under More).

## 1.96.1 — 2026-10-09
- Robinhood panel made trader-friendly: a desktop-site reminder before Connect (Robinhood refuses phone browsers), 'Look at my account' buttons (Accounts, Positions...), and a plain BUY / SELL ticket (symbol, shares, market or limit) that picks the right Robinhood command for you. Chart/indicator commands no longer show a REAL MONEY ticket; raw commands moved to a collapsed Advanced section. PIN and confirmation are still required for every order.

## 1.96.0 — 2026-10-09
- Wave watchlist for every session: Pre-market, Regular (after the first hour), After-hours and Overnight each get their own Potential Rise / Fall cards (zone, stop, TP1/TP2, hit rate measured over that session's own window), with an Auto/Pre/Regular/After/Overnight switcher; Trade the wave and armed picks now also work after-hours and overnight (morning From/Until window applies only to pre-market and regular). Max loss: Paper and Live each have their own box and can be edited from either mode without touching the one in use (your limits are unchanged). Admin: your collector address now travels in latest.json so testers' phones report to the same collector you read, fixing 'only me in the Admin'. Fixes from the support export: Harvest re-entry waits 60 s and for the drop to stop, re-entry shrinks to fit buying power, smart-entry quote unpack error.

## 1.95.0 — 2026-10-08
- 'sekex ship' now does everything in one command: checks for old files and shows them, asks once, publishes the newest zip in Downloads to GitHub (zip, admin add-on, latest.json), then deletes everything except the last 3 updates on the phone (Downloads zips, PDFs, backups, rollback copies) and in the GitHub repo. Nothing is deleted if the publish fails. 'Find & fix it' (More > Fix with Claude) now takes up to 3 screenshots (shrunk on the phone; sent to your AI provider only for that fix; never saved).

## 1.94.0 — 2026-10-08
- New 'sekex ship' and 'sekex clean' commands. 'sekex ship' publishes the newest SekexBot zip in your Downloads folder to GitHub (zip, admin add-on, latest.json) and then tidies up. 'sekex clean' lists and deletes old SekexBot zips, release-notes PDFs and backups in Downloads, old rollback copies and old files in your GitHub update repo, keeping the newest 2 of each (never your keys, data, settings, journal, latest.json or what latest.json points at). Use --dry-run to preview, --yes to skip the question, --keep N to change how many are kept. Rollback copies on the phone are now the last 2.

## 1.93.3 — 2026-10-08
- Folded in the self-fix from your export: Morning-wave trader now fetches prices for wave candidates the scanner missed and ignores quotes older than 5 minutes, so pre-market wave setups are no longer skipped with 'no fresh quote'. Risk limits, sizing and stops unchanged. The other fixes in the file were already included.

## 1.93.2 — 2026-10-08
- Manual tab is now in every mode, including Rookie (trade pad, manual ticket, trend research, positions and orders). Rookie tabs: Home, Manual, Trades, Learn, Help.

## 1.93.1 — 2026-10-08
- Bug-check pass: a preset name containing a quote could break the page (fixed); Rookie tab bar now spreads across the screen; Rookie 'What happened' shows only the latest trading day and explains each exit in plain English; the Learn guide shows even before a mode is picked; Rookie warns when the daily loss limit is larger than the account (the limit itself is never changed).

## 1.93.0 — 2026-10-08
- Three trader modes: Rookie / Trader / Advanced. A picker appears on first launch; change it any time in More → My trader level. Rookie shows 5 tabs (Home, Trades, Learn, Help) with plain-English 'Today', a stocks-I'm-watching box, and a Why line for every trade and skip. Trader hides the advanced cards (Options, Long-wave, Robinhood, individual switches). Advanced is unchanged. Every mode can trade Paper or Live; Rookie shows a heads-up warning before going Live. Learn now has content for each mode. Daily loss limits and Paper/Live are never changed by the mode.

## 1.92.0 — 2026-10-08
- Controls: new 🌱 Rookie trade level (buys only, regular hours, one position, smallest size) and 💾 My presets (save/apply/delete your own mix of switches; the daily loss limit is never part of a preset). Every checkbox is now a toggle switch. Phone temperature warning shows °F. Auto tab opens with a 🚀 Getting started guide (connect Alpaca, pick Rookie, set loss limit, choose stocks, start in PAPER) that ticks itself off and can be hidden.

## 1.91.2 — 2026-10-08
- Settings (More tab) is now a category menu: Display, App & account, Home-screen icon, Header message, Voice, Alerts & price alerts, Daily P&L, Safety net & backup, Help & repair, Review my signals, Fix with Claude. Each is one big tappable row with a one-line description; tap to open it, and opening one closes the others. Links that jump to a section (alerts, header message, help, fix) open the right category first. Nothing inside the sections changed.

## 1.91.1 — 2026-10-08
- Robinhood sign-in on a phone: Robinhood's own page refuses phone browsers for this step (it says 'Use your desktop web browser'). The Robinhood tab now explains it and offers two ways around it: switch Chrome to Desktop site and reopen the sign-in, or copy the sign-in link, finish it on a computer, and paste the address it ends on into the Finish box.

## 1.91.0 — 2026-10-08
- Pre-mkt cards are now tappable. Tap any Potential Rise or Potential Fall card for two choices: (1) Trade it myself: opens the trade ticket pre-filled from the card (limit at the zone edge, size from your risk budget using the card's own stop, stop and target 1 attached in regular hours); (2) Let the bot take it (auto, today only): arms the card, and when the price is inside its entry zone the bot sends one limit order with the card's stop and target, sized from your risk budget (shorts for Potential Fall cards, only where shorting is allowed and the stock is easy to borrow). Armed cards show a BOT WILL TAKE IT tag and can be cancelled the same way. Armed picks obey the daily loss limit, the spread check, the news/earnings filter and the margin check, and expire at the end of the day. Daily loss limit untouched.

## 1.90.3 — 2026-10-08
- Separate daily loss limits for PAPER and LIVE. Each mode now keeps its own limit; the box under Daily max loss edits the limit of the mode you are in, and switching PAPER/LIVE switches the limit with it (it shows both). On update both start at your current limit, so nothing changes until you set them apart. Everything that sizes trades or halts (risk, scanner, Easy buy, levels) keeps using the active limit.

## 1.90.2 — 2026-10-08
- Live PIN fixed for new users: saving a PIN was refused with 'Stop the bot before changing broker keys' whenever the auto-trader was running, so a tester could never set one (the Trading mode window then said 'Set a Live PIN first'). A PIN alone now saves while the bot runs, and the Trading mode window has its own Create/Change your Live PIN box (4+ letters or numbers; changing needs the current PIN; wrong tries count toward the 15-minute lockout). Saving a PIN no longer restarts the connection. Broker-key changes still need the bot stopped.

## 1.90.1 — 2026-10-08
- Robinhood connect fixed: (1) the sign-in return page (/api/rh/callback) was blocked for the other browser because it carried no SekexBot token/login, so SekexBot never learned you had signed in. It is now reachable (protected by its one-time state and PKCE). (2) Connect now opens Robinhood in a new tab and this screen waits and updates by itself when you finish, instead of navigating away. (3) Added a Paste the address box as a fallback: copy the address the browser ends on (starts with http://127.0.0.1) and tap Finish. (4) The return address is always http://127.0.0.1:PORT so it matches what was registered, and Robinhood's own error text is shown if it refuses.

## 1.90.0 — 2026-10-08
- Long-wave plan (Learn tab, new 🌊 card): type a ticker and it measures the stock's slow swings from the last few days of 5-minute bars (extended hours included) and plans up to 5 trades: where to BUY before the turn up (with a 20-minute time window), where and when to SELL (just before the old high, not at it), the stop, the reward/risk and the re-entry level and time. Shows swing size, how long a full cycle takes, a confidence score and a walk-forward check of how the same rule would have done on that stock's last few days. It refuses to plan when swings are not regular (random drift scores as no plan) or when the bid/ask spread is broken, and refreshes every minute. Shorts are optional (needs allow_shorts). This is a PLAN ONLY: it does not place orders; nothing trades from it. Daily loss limit untouched.

## 1.89.4 — 2026-10-07
- Safety: never sell into a broken quote. Overnight, a stock can show a bid/ask spread of 30% or more (IHF showed bid 47.57 / ask 64.35 on a 63 stock), which made a fake -11% loss. The manual loss guard now does nothing when the spread is wider than 3% of price (it was about to close at the bid once the fake loss passed 15%), and the daily-limit halt keeps a loser open instead of dumping it into such a quote. Normal quotes behave as before; the daily loss limit value is untouched.

## 1.89.3 — 2026-10-07
- Harvest buttons now judge green or red by what closing would really fill at (bid for longs, ask for shorts), not the mid-price mark. Overnight, with a wide spread, a position could show green while closing it would lose money; the Harvest button no longer treats that as a win (it asks before selling at a loss) and Harvest all stays hidden unless every position is green at the real exit price.

## 1.89.2 — 2026-10-07
- Your self-fix file folded in, tester PIN fix, price alerts from the Trade pad. (1) Green touches: new setting green_touches (default 3, 0 = off) banks a trade the 3rd time it flashes green (+0.3R) and fades back to break-even; stops and the daily loss limit are untouched. (2) Harvester: a restart mid-cycle no longer leaves a job stuck in entering/exiting (entering re-arms, a stop exit resumes holding), exit price is remembered, the exit is saved right away, and the overnight pause no longer freezes a job that is already entering or exiting. (3) Closing a position that is already gone at Alpaca now counts as closed instead of retrying forever. (4) Extended hours: flush bounce/fade ignore swings under 0.8% of price (too thin to trade). (5) New Harvest all button above Positions, shown only when you have 2+ of your own positions and every one is green. (6) PIN fix for a tester's phone: the Live PIN check now ignores a trailing space or newline that phone keyboards add, and setting a PIN rejects spaces and symbols (use letters and numbers, 4+ characters). 5 wrong tries lock that phone for 15 minutes. Each phone has its own PIN, set in Settings on that phone. (7) Price alerts: new 🔔 button next to Quote on the Trade pad sets an alert for any ticker (type the price, it fires above or below), and the alerts for that ticker show under the quote with an ✕ to remove. They use the existing alert channels (in-app, phone notification, ntfy, Telegram).

## 1.89.1 — 2026-10-07
- Easy buy from the watchlist: every stock in My watchlist now has a green 🛒 Buy button. One tap opens the trade sheet already sized to your risk (the same per-trade risk the bot uses, half of 15% of your daily loss limit, capped by your max trade size and buying power) with the suggested stop-loss and take-profit switched on, then BUY sends it (LIVE asks for a confirmation first). Your daily loss limit is never changed.

## 1.89.0 — 2026-10-07
- Robinhood tab (bottom menu): connect Robinhood's official Agentic Trading link (MCP, standard sign-in on Robinhood's own page with PKCE; SekexBot never sees your password). Reads your Robinhood accounts, positions, balances and orders into the tab, and has an Order ticket built from the order tools Robinhood offers. Robinhood itself only lets an app trade in the separate Agentic account it asks you to open. Safety: nothing trades by itself; every order tool needs your Live PIN, a ticked confirmation and an on-screen confirm; unknown tools are treated as order tools; the daily loss limit and stops do NOT apply to Robinhood orders. Tokens are kept in data/robinhood.json (owner-only). Tested against a mock Robinhood server (sign-in, token refresh, tool list, PIN and confirm gating); the real Robinhood sign-in has not been tried yet. Also: --sim now honours AUTOBOT_DATA, regression suite is 24 checks.

## 1.88.1 — 2026-10-07
- Learn tab: the charts are now LIVE. Lesson 2 (floor and ceiling) and Lesson 5 (best entries) draw real daily candles plus the current quote for any ticker you type (starts with your open position, or SPCX), with the floor, ceiling, entry zone, a Best entry right now line and the stop, risk and reward-to-risk if you bought at the market now. Refreshes every 30 seconds while the Learn tab is open. The old SPCX picture is kept as an optional sketch.

## 1.88.0 — 2026-10-07
- Learn tab (bottom menu): six short illustrated lessons on reading a chart: which way price is going (higher highs / higher lows, the 20-day average, volume), where the floor and ceiling are and how they flip, the four buy setups, when to sell and take profit, and the best entry points (retest of a broken ceiling, pullback to the rising average, and why buying the top of an extended candle is the worst entry), with a worked SPCX example and a pre-trade checklist. Plus Read a stock for me: type any ticker and the app reads about six months of daily bars and draws the trend, floor, ceiling and suggested entry zone with stop, target and reward-to-risk. Education only, nothing is traded from this tab. Also new: a regression test suite (python3 tests/regression.py: 23 checks covering risk limits, sessions, the wave trader, options limits, scalping exits, Harvest-now, the profit lock and the Learn reader) and simulate.py now accepts SIM_DATA=<folder> so several simulations can run side by side.

## 1.87.2 — 2026-10-06
- Fix: sekex start / the home-screen Start button could hang forever when the Termux:API app was not installed, because Termux's notification, toast and open-link commands wait for that app. They now give up after 4 seconds, so SekexBot starts and the dashboard address is printed either way. Installing Termux:API from F-Droid still adds the running notification and the Start / Stop buttons. Daily loss limit untouched.

## 1.87.1 — 2026-10-06
- PAPER / LIVE tags: a red LIVE or blue PAPER tag now shows on every row of the Trade journal, on open and closed options trades, in the options journal and next to Positions & orders, so you can see which account each trade belongs to. Mode was already saved with every trade, so older history is tagged too. Daily loss limit untouched.

## 1.87.0 — 2026-10-06
- Options card: new limits Max stocks (different stocks open at once), Per stock, Max open calls, Max open puts, Contracts per trade, and an optional Min delta entry filter (0 = off). Defaults keep the old behaviour (2 open, one per stock). Every open options trade now shows its Greeks (delta, gamma, theta, vega, implied volatility, plus the whole position's theta in $ per day and delta in share-equivalents) from Alpaca's option snapshots, and the entry log line includes delta and theta. The options module's own daily budget and the LIVE lock are unchanged; the stock daily loss limit is untouched.

## 1.86.0 — 2026-10-06
- Trade the wave: an optional switch (OFF by default, works in paper and live) on the Morning wave card. When ON, the bot places a limit buy for a Potential Rise setup (score at least 70 by default) once its price is inside the watch zone, between 9:30 and 10:30 AM ET (editable), with the card's stop and TP1 as the exit levels (a bracket order in regular hours). Sized at half your normal risk, max 2 new wave trades a day, one per symbol, and it obeys the daily loss limit (unchanged), Max $ per bot trade, buying power, spread, earnings and cooldown filters. Falls are never traded. The card shows what was bought and why the bot is waiting. New /api/wave.

## 1.85.0 — 2026-10-06
- Morning wave watchlist, a new card at the top of the Session tab's lower half: conditional Potential Rise / Potential Fall setups for the next morning, built from the latest regular-session 15-minute bars of your watchlist, the big liquid names and ETFs, and the shortlist. Each shows the entry watch zone, stop (SL), two targets (TP1, TP2), the setup name (close high continuation, weak close continuation, overnight bounce), a score out of 100, the historical hit rate of a 0.4% morning move with the sample size, the bar time, and flags (prior bar, earnings). A live tag says IN ZONE or above / below the zone. Display only: it never places an order, and down watches are informational. New /api/morningwave. Daily loss limit untouched.

## 1.84.0 — 2026-10-05
- Night mode is now BUYS only (with scalp / harvest exits: small profit banked fast, protective stop kept), not shorts. Switch it to shorts only with the new selector if you prefer. New Session tab between Positions and More: one tab whose name and list change with the market session (Pre-mkt, Regular, After, Night, Closed), showing that session's movers or the night buy list, your open trades and the bot's status per name. It replaces the Night shorts list menu item. Daily loss limit untouched.

## 1.83.0 — 2026-10-05
- Max $ per bot trade: new hard cap of $10,000 on any single bot trade in every session (Controls > Advanced, 0 = off). In your journal, trades over $20k lost $3.9k while trades under $5k made $0.6k, and the worst stop-outs (up to 3 times the planned loss) were on huge share counts of cheap stocks. Your daily loss limit is not touched.

## 1.82.1 — 2026-10-05
- Fix: Harvest now (and Re-enter now) did nothing between 8 PM and 4 AM because the overnight pause of Auto-harvest also ignored your button. Your button now works overnight (limit orders at the bid or ask); only the automatic harvests, stops and re-entries stay paused there.

## 1.82.0 — 2026-10-05
- Night shorts: from 8 PM to 7 AM ET the bot only shorts (no new longs), only stocks on the setup-short list, and closes them for a profit (the protective stop stays; shorts are not force-closed at the overnight to pre-market change). New menu item Night shorts list in the More menu shows the list, what the bot is waiting for on each name and your open night shorts. On by default, with a switch.

## 1.81.0 — 2026-10-05
- Start on boot by default: SekexBot now starts by itself when the phone turns on (it still needs the Termux:Boot app). New switch in Controls, Start SekexBot by itself when the phone turns on, turns it off. sekex doctor shows the state.

## 1.80.0 — 2026-10-05
- Harvest now button: every position of yours has a green Harvest button that sells right away and keeps the harvest cycle going (re-enters on a pullback). It turns Auto-harvest on if it was off. While the cycle is waiting to buy back, the Auto-harvest row shows Re-enter now. Asks first if the position is below your entry.

## 1.79.0 — 2026-10-05
- Simpler Controls: three simple controls at the top of Controls (Exit style, Shorts, Learn from my results) now set the many overlapping switches for you. The individual switches stay under Advanced, and the three loose ones in the Self-fix card moved there too.

## 1.78.0 — 2026-10-05
- Smart entry: in the pre-market, after-hours and overnight the bot starts its entry limit halfway across the spread and steps to the far side every 15 seconds (ending at the old price), so it pays less of the spread. Skipped when the spread is under 2 cents. The Pre-market preset card counts what it saved and how many entries it missed.

## 1.77.0 — 2026-10-05
- Session auto-off: every night a strategy that loses money in one market session (pre-market, open, midday, afternoon, after-hours, overnight) on at least 12 of your own bot trades is switched off in that session only, then retested a week later on new trades. New card on the Auto tab shows what is off, the retest date and a log. It works next to Self-fix and never touches manual trades or the daily loss limit.

## 1.76.1 — 2026-10-05
- Pre-market only preset: one tap limits the bot's pre-market entries to EXT_TREND and FLUSH_BOUNCE and harvests at 3x the spread; positions show the spread cost next to close now.

## 1.76.0 — 2026-10-05
- Close-now log: new card on the Positions tab. Every time a position could be closed right now for a profit above $10 (your line, you can change it), it records the time, stock, who owns it (you, bot or auto-harvest), the close-now amount at the real bid or ask, the peak, how many minutes it stayed above, the spread and the session. UP = crossed above the line, FELL = dropped back under it, CLOSED = the position was closed while above it. Checked every 5 seconds, kept across restarts, with Export CSV. Close-now is after the spread, so it is the profit you could really take.

## 1.75.0 — 2026-10-05
- Pre-market preset: new card on the Auto tab. Auto-create reads your own closed pre-market trades and builds a safer setup: the best 30-minute-slot window for starting bot trades, a size cap so a typical stop loses about what a typical win makes, and strategies that lost money there switched off in the pre-market only. With fewer than 20 pre-market trades it uses the Recommended preset (7:00 to 9:00, max $10,000). Optional nightly rebuild. Applies to the bot's pre-market entries, and the size cap also to after-hours and overnight. It never touches the daily loss limit and never closes your manual trades.
- Scorecard: new card on the Auto tab that slices your own closed trades by strategy, session, long or short, hour or stock, for this account, PAPER, LIVE or all, over 7, 30 or 90 days. It shows win rate, average win and loss, dollars per trade and P&L, and marks strategies that lose money over 15 or more trades. In By strategy, Turn off stops the bot taking that strategy until you turn it back on. The daily loss limit is not touched.
- Trade pad: a visible Auto-harvest tick. It is the same remembered tick as on the Manual ticket, so every pad order inherited it, and the harvester then sold small gains and stopped out your hand trades. Untick it to keep a manual trade exactly as you left it.

## 1.74.1 — 2026-10-05
- Auto-harvest exit fix: found in your support export. After a re-entry that filled a little less than requested (for example 59 of 60 shares), the harvester kept trying to sell the larger number and Alpaca refused it about 190 times (AAPL on Oct 1). It now never asks to sell more than is really held, re-syncs to the quantity Alpaca reports, and repeats the warning only a few times instead of every few seconds.

## 1.74.0 — 2026-10-04
- Morning prep: a new card on the Auto tab that ranks your watchlist, shortlist and movers from real Alpaca data: price now against the last close (gap), against the 20-day average, and distance to the 20-day high, with ATR and setup tags (TREND LONG, TREND SHORT, NEW 20D HIGH, NEAR HIGH, LONG WATCH). Best long setups first. Tap a row to load it on the Trade Pad. Information only, it never trades.
- Trade pad chips: watchlist and position chips are compact again (the price was showing in a huge font), and overnight or pre-market prices now use the live bid and ask midpoint instead of an hours-old last trade.

## 1.73.3 — 2026-10-04
- Trade pad goes live: the quote under the ticker now refreshes by itself every 3 seconds, and the watchlist and open-position chips show the last price and % change for the day, refreshed every 5 seconds, so you no longer have to tap Quote. Open positions also show the current price.

## 1.73.2 — 2026-10-04
- Trade pad layout: on a wide screen (tablet or phone sideways) the pad is now two columns. Your open positions and the whole watchlist sit on the right, and the six keys run in one row underneath, so the whole pad fits on one screen with no scrolling. On a narrow phone the positions and watchlist stay on the same screen and the long hint text is hidden. Open positions are listed first so you can see and close them quickly.

## 1.73.1 — 2026-10-04
- Trade pad: open positions and watchlist chips. Open positions show as chips with size and open P&L (tap to select, the red X closes that position); your watchlist shows below as one-tap ticker chips.

## 1.73.0 — 2026-10-04
- Trade pad: a hardware-style macro pad on the Manual tab with a knob, CANCEL, CLOSE, LIMIT, MARKET, SELL and BUY keys, for fast manual orders from the phone or a PC. Turn (or drag) the knob to change the size, or tap a preset chip for a one-touch amount.
- Preset amounts: choose Shares or Dollars. Defaults are 5, 10, 25, 50, 100 shares or $100, $250, $500, $1000, $2500. Tap the Presets button to set your own, saved on the device.
- Keys: LIMIT places a marketable limit at the ask (buy) or bid (sell); MARKET is only available when the market is open. SELL and BUY go through the same confirmation, PIN and short rules as the regular ticket. CLOSE closes your position in that stock. CANCEL cancels open orders on that stock, and refuses if the stock is an open bot trade so it cannot strip the bot's stop.
- Keyboard shortcuts for a USB or Bluetooth macro pad: B buy, S sell, C close, X cancel, L limit, M market, arrow keys change size, 1 to 6 pick a preset. They work only on the Manual tab and not while typing.

## 1.72.0 — 2026-10-04
- Options settings: the options module now keeps its own settings in options_settings.json (on/off, style, daily options budget, per-trade limit, max open, take-profit %, stop %, DTE range, stocks to trade). Your stock settings in settings.json no longer carry any options values. Existing options settings are moved over automatically on the first start after the update.
- Options journal: the module has its own journal database, options.db, kept apart from your stock trade journal (trades.db). Existing options rows are copied over once. In the Options card, the new Options journal button shows closed trades, win rate, total P&L, average win and loss, and breakdowns by stock, call or put, style and why closed. Export CSV downloads the whole options journal.
- Unchanged: the options module is still OFF by default, defined risk only, regular hours only, paper only until you unlock Live with your PIN, and it uses its own daily options budget (never your stock daily loss limit).

## 1.71.2 — 2026-10-04
- Release notes: the changelog and this install guide now cover every release from 1.68.2 to 1.71.1.
- Install guide: README_ANDROID gained update steps and sections for the home-screen icon, ChatGPT option, regime filter, session focus, options, fractional mode, green guard and the morning trend rider.

## 1.71.1 — 2026-10-04
- Morning trend rider: no longer needs a gap. A steady 0.8%+ move off the 9:30 open (net move at least 35% of the distance travelled over the last 20 bars) also qualifies, long or short. For instance, IREN on Friday Oct 2 had almost no gap but ground up about 4% from the open. Choppy days still do not qualify.

## 1.71.0 — 2026-10-03
- Green guard: for trades that go green two or three times, never reach the target, then lose (Auto > Advanced, ON by default). Green means up enough to cover the spread plus slippage (never under 0.15R, never over 0.5R). On the second clear green the bot banks the trade, unless it already ran past 0.6R (the gain lock handles those). After one small peak that gives back 40% (50% while Let run is on) it banks what is left. After two greens, or a peak of 1.6x the green size, the stop moves to break-even plus costs.
- Morning trend rider: new MORN_TREND strategy (Auto > Advanced, ON by default) for steady morning grinds, long or short, 9:35 to 11:00. Needs a 1%+ gap one way, price above (below) VWAP, the 9 EMA over (under) the 21 EMA with the 21 EMA rising (falling), then enters on a pullback to the 9 EMA or a break of the last 12 bars on 1.2x volume. Stop is capped at 1.5 ATR. Shorts need Allow shorts and an easy-to-borrow stock. It does not trade pre-market because volume is too thin.

## 1.70.0 — 2026-10-03
- Small-account mode: fractional shares (Auto > Advanced, OFF by default). When one whole share is too big for the risk budget or the position cap, the bot buys a fraction (4 decimals, $1 minimum), long only, regular hours, fractionable stocks only.
- Protection: Alpaca does not allow bracket orders on fractions, so the entry is a day limit order, a plain broker stop goes on once it fills, and the bot itself takes the profit target (keep it running). If the broker refuses a stop on a fraction the bot watches the stop itself and says so in the log. Fractions are not scaled out; whole-share trades keep their normal bracket. Your daily loss limit is unchanged.

## 1.69.2 — 2026-10-03
- ChatGPT option: choose Claude or ChatGPT (OpenAI) as the AI. Gear > Broker keys > AI: pick ChatGPT, paste your OpenAI key, Save, Use this AI, Test. The Model box is optional (blank picks the newest GPT your key can use).
- Where it applies: the chart reader, Ask AI, signal review, Fix with AI and the admin helper all follow the AI you pick. Your Claude key stays saved so you can switch back. An OpenAI API key needs its own billing credits; a ChatGPT Plus plan does not cover the API.

## 1.69.1 — 2026-10-03
- **One-tap SekexBot icon for the home screen.** (1) New Termux:Widget shortcut named SekexBot (with the SekexBot logo): one tap starts SekexBot if it is off, then opens the dashboard. It is installed for everyone by the installer and by every update, and appears first in the Termux:Widget list. Long-press the Termux:Widget app icon and drag SekexBot out to get it as its own icon, or add the widget and tap it. (2) New command: sekex home re-creates the icon and prints the steps. (3) Settings (gear) has a new Home-screen icon card with an Add the SekexBot icon button that installs SekexBot as an app icon (Chrome install prompt, or the Add to Home screen menu). (4) The app icon now works when SekexBot is off: it shows a SekexBot is off page with a Retry button instead of a browser error. Trading is unchanged.

## 1.69.0 — 2026-10-03
- **Options auto-trader (separate module, OFF by default).** New card on the Auto page: Options, with its own on/off switch. Defined risk only: bull/bear vertical DEBIT SPREADS (or single long calls/puts if you pick that, or if the Alpaca account is only options level 2), so the most that can be lost on a trade is what it paid. It scans liquid stocks (SPY, QQQ, IWM, AAPL, NVDA, TSLA, AMD, META, MSFT, AMZN, editable) during regular hours (entries 9:45 AM to 3:30 PM), using the stock bot's ribbon, VWAP, EMA, momentum, market bias and the new market regime (it stays out of chop and quiet markets), confirms the idea twice, picks an expiry 5-21 days out and strikes near the money, checks open interest and bid/ask width, prices a limit order between mid and ask, and sizes it to your per-trade maximum and its OWN daily budget (defaults: 300 per day, 200 per trade, 2 open, up to 3 contracts). Exits: take profit +50%, stop -40%, a trailing give-back, 3 checks of the trend turning against it, expiring today, and flat 15 minutes before the close (it never holds overnight). Safety: your stock daily loss limit is untouched; options never trade on LIVE until you tap Unlock for LIVE and enter your Live PIN; turning it off still manages open positions to exit; Close all options now is a kill switch; if Alpaca refuses a one-ticket spread exit it closes the short leg first and then the long. The stock bot no longer sees option contracts as positions and its end-of-day flatten leaves them to this module. Every options trade is journaled (new options_trades table) and shown in the card. NEW and untested against a live broker: run it on PAPER first. Alpaca must have options trading enabled on the account (level 2 for long options, level 3 for spreads).

## 1.68.3 — 2026-10-03
- **Session focus.** The Auto page now has a Session focus card at the top (Auto / Pre-market / Regular / After-hours / Overnight / Show all). In Auto it follows the session you are in and shows only the cards that matter there: Pre-market shows the pre-market timeline, big movers, setting-up-now list, stock picker and Why no trade; Regular hours shows movers, picker, setting-up-now and Why no trade; After-hours shows evening candidates, the overnight study, self-fix and what the bot learned plus movers; Overnight and Market closed show the study and prep cards. Account, loss limit, controls, open positions and activity are always visible, and a one-line playbook says how the bot behaves in the session. Tap Show all to see everything. Display only: trading is unchanged.

## 1.68.2 — 2026-10-03
- **Fixes and market-aware sizing.** (1) Short orders no longer get rejected with take_profit.limit_price must be <= base_price - 0.01: bracket targets and stops are kept at least a tick on the right side of the entry (the bot used to retry the same bad order every minute). (2) After taking partial profit the new protective stop is clamped beyond the current market, so Alpaca no longer refuses it (stop price must be greater than current price). (3) The low buying power warning is logged once, not on every tick (it logged 353 times in one day). (4) Orders whose stop sits on the wrong side of the entry are skipped. (5) Journal rows left open or pending after a crash, restart or manual close are marked stale on start-up. (6) The live price stream closes its old connection before opening a new one (fixes connection limit exceeded and double sockets). (7) Adding a watchlist name Alpaca does not list (like CHEVRON instead of CVX) is refused. (8) NEW **Market regime filter** (Controls): reads SPY/QQQ and sizes each strategy for the market: trending up/down (size up with-trend, smaller counter-trend, no fading a strong trend), chop (smaller trend-following, bigger mean-reversion), volatile (everything smaller), quiet (smaller trend-following). Shown next to Market bias; each journal trade records its regime. (9) NEW **Strategy breaker**: a strategy down 2R or more today (3+ trades) trades at half size, and down 3.5R or more is paused for the day. Both only change position size, never your daily loss limit, and both have an on/off box.

## 1.68.1 — 2026-10-02
- **Easier admin updates.** Admin phone: put SekexBot_Admin_vX.Y.Z.zip in Downloads next to the app zip and run plain **sekex update** (no path needed, it uses the newest SekexBot_Android zip in Downloads) and the admin add-on updates in the same step, with no publish or network needed. New **sekex admin install** installs the newest admin zip from Downloads by itself (or give it a path), and checks it is a valid add-on first, so a bad zip changes nothing. The published encrypted add-on still works for your other phones. Every other phone is unaffected: it has no admin key, so it ignores the add-on.

## 1.68.0 — 2026-10-02
- **Admin dashboard (admin phone only).** The hidden admin page is now a real dashboard with five tabs. **Overview:** tiles (installs online, installs needing the update, installs with problems, group P&L, win rate, payoff ratio), group P&L by day, where the money goes by strategy, average win vs average loss, versions across the fleet, and who needs attention. **Fleet:** the per-install list and detail you had before. **Trading:** combined results by day, strategy, session, long vs short, exit type, time of day, and the top reasons trades were skipped. **Updates:** latest version seen, who is current or behind, and how to publish. **AI & logs:** one tap to have the AI helper analyze everyone, plus each install's logs (Numbers, Analyze with AI, Zip) and Download all (merged). Trading numbers come only from installs whose owners ticked Share my trade logs. Needs the updated collector (sekexbot_collector.zip) and the admin add-on published with this version.

## 1.67.1 — 2026-10-02
- New **Reset today's P&L to $0** button in Settings (⚙) under Daily P&L. Today's P&L and the daily loss budget count from the account's equity at 8:00 PM ET (the start of each trading day), so they reset on their own then; the button starts them again from the account's equity right now and clears a daily-loss halt. Trades stay in the journal and daily results. On LIVE it asks for your PIN. Your daily limit setting is not changed.

## 1.67.0 — 2026-10-02
- **Auto-flip for your manual trades.** Controls, Guard my manual positions, has a new choice: **Auto-flip (close + reverse)**. When a manual trade is red and the trend has clearly turned against it (the direction call 40+ against you, or the ribbon against you with no call backing you, on 3 checks in a row), the guard closes it and opens the same size the other way in ONE order (selling twice a long, buying twice a short), capped at 30% of equity for the new side. The flipped trade gets Auto-harvest armed (box: harvest the flipped trade), and the guard keeps watching it, so it can flip again: up to 3 flips per stock per day by default (setting, 0 to 10), at least 3 minutes apart. A flip to a short follows the bot's short rules (7 AM start, easy-to-borrow check, shorts switch) and needs loss limit left. If a flip isn't possible, or flips for the day are used up, it just closes. Hitting the hard loss cap with no trend turn only closes. Extended hours use a limit order priced through the quote. Set Guard to Auto-flip to use it; nothing changes until you do. Every flip costs spread twice, so check the journal before raising the daily flips.

## 1.66.1 — 2026-10-02
- Fixed a startup crash in 1.66.0: the app stopped at start-up with a NameError (the log-upload hook was wired before the function it calls existed), so it sat on Starting SekexBot and never came up. Install this instead of 1.66.0.

## 1.66.0 — 2026-10-02
- **Remote trade logs, opt-in.** A new box, **Share my trade logs** (separate from diagnostics and OFF by default; also offered, unticked, in the one-time question), uploads the trade journal, learner and strategy stats, skip reasons, scrubbed settings and a redacted engine log every 3 hours to the support collector, so strategies can be refined from real results. Never API keys, PIN, account number, .env or the collector address. Controls has **Show what is sent** (file names, sizes and the first journal rows), and turning the box off deletes what support holds. **Admin page:** new Trade logs from users: per-install Numbers, 🤖 Analyze with AI (the AI helper reads a numbers summary and suggests strategy changes), Zip download, and Download all logs (merged). The collector also writes one merged file with Export-All-Logs.bat for review. Needs the updated collector (in sekexbot_collector.zip) and the support address built into the app.

## 1.65.0 — 2026-10-02
- Fixes for the payoff problem found in the journal (small wins, big losses). **Harvest-sized stops:** with Harvest small % on, quick trades now risk about 3x the harvest gain (never inside the thin-market floor: 0.45% extended hours, 0.25% regular) instead of the full chart stop, so one stop no longer erases six harvests. Trend entries (EXT_CONT) keep their wide stop. Switch: Controls, Harvest-sized stops. **Spread by trade type:** scalps keep your 0.15% spread limit; trend setups (EXT_CONT, EXT_TREND, EXT_MOMENTUM, PLAN_TREND) may enter up to 0.40% (Controls, Max spread for trend setups). A trade now banks at least twice its entry spread (and 0.5% for EXT_CONT) instead of 0.15%, so a wide spread can't eat the harvest. **One position per leveraged-ETF family:** TQQQ/SQQQ/QQQ, SOXL/SOXS, SPY/SPXL/SPXS and others. Long TQQQ plus short SQQQ is the same bet twice, and long both cancels out, so the bot takes only one per family, also within the same scan. Switch in Controls. **Smaller bot positions:** the per-trade cap drops from 25% to 15% of equity, once, on update (Controls, Max bot position). Manual trades are not limited, but the ticket now warns when one is over 30% of equity. Your daily loss limit is untouched.

## 1.64.0 — 2026-10-02
- Pre-market and after-hours trends are now clearly marked and traded. The Big movers board shows a big **▲ BUY** or **▼ SHORT** for each stock (25 rows instead of 10), a summary line (how many to short, how many to buy), and under each one what the bot will do or why it hasn't: IN TRADE, short starts at 7:00 AM ET, or the last skip reason (spread too wide, learner score, cool-off and so on).
- New entry EXT_CONT for continuation: a stock 2%+ from the close that keeps making new lows (short, from 7:00 AM ET) or new highs (buy), with the ribbon, VWAP and the slow line all agreeing and volume not dead. It is looser than the old trend entry, which needed the break on the exact current bar. It skips the cold-strategy score check but still obeys the spread limit, the daily limit, cool-offs, the benched-setup probe rule and the 7 AM short rule. Switch in Controls: Trade pre-market / after-hours trends (on by default).
- Harvest small % is now ON by default (the hand-trader scalp: bank about 0.1%, then re-enter while the trend holds), also switched on once for existing installs. Untick it in Controls to turn it off.
- Export journal & logs now also holds the why-no-trade skip log, recent events and the movers board, so a missed trade can be traced to the exact blocking rule.

## 1.63.0 — 2026-10-02
- Fixes made with Find & fix it now survive updates. Each applied fix saves a small patch file (what changed) on the phone. Before, an update silently overwrote the fixed files while the fix still showed in the list.
- Applied fixes now show their state: in place, already in this version, lost in an update, or can't be re-applied. For a lost fix, Put this fix back re-applies it (Live PIN, backed up first, auto-rollback if the app won't start), unless the code around it changed too much.
- Share my fixes (Controls, Fix with Claude): downloads one file with every fix on this phone and its patch, so fixes found on a phone can be folded into the next release for everybody.
- Export journal & logs: downloads one zip with the trade journal (CSV), learner and level stats, slippage, scrubbed settings and the recent engine log, for reviewing why trades lose. It contains no API keys, PINs, tokens or addresses.

## 1.62.1 — 2026-10-01
- The support-data question (ticked by default; nothing is sent until the user taps Continue) now shows after every install or update even before a support address is built into the app. Controls says plainly when no address is set, so nothing can be sent yet. Once a build carries the address, users who left it ticked start reporting.

## 1.62.0 — 2026-10-01
- The admin panel is no longer part of the app everyone gets. It is now a private, encrypted add-on that installs only on phones you have marked as admin. Other users' phones never download, install or show it; the public app contains no admin screen, passcode or admin address at all.
- To make a phone an admin phone: run `sekex admin enable` once (it prints a secret admin key; keep it private). `sekex admin key` shows it again, for a second phone, or put ADMIN_KEY= (and UPDATE_URL=) in sekexbot-setup.conf before running the setup script. `sekex admin status` and `sekex admin off` also exist.
- Publishing stays one step: `sekex publish`. The first time (and whenever the add-on itself changes) also put SekexBot_Admin_vX.zip in Downloads; the admin phone remembers it, so later publishes of a new app zip need nothing extra. On a phone without the admin key the add-on is silently left out.
- One update does everything. `sekex update` (and the app's update check) now also installs any new requirements: when the list of required packages changes, the full install runs automatically instead of the quick one. On admin phones the same update also fetches the admin add-on and restarts the app when it changed.
- The support-data question now has a checkbox that is ticked by default. It appears once after an install or update (when the build has a support address), nothing is sent until the user taps Continue, and unticking it first means nothing is ever sent. Controls keeps the same checkbox.
- The panel is opened as before: tap the logo 7 times, enter the passcode, and paste the collector address once.

## 1.61.0 — 2026-10-01
- Optional diagnostics sharing, so support can help fix a problem on someone's phone. New in Controls: Share diagnostics with SekexBot support. It is OFF by default, and a one-time question asks once (only when a support address is set in the build). When on, once a minute the app sends one small technical report: app version, phone make/model and Android version, how much CPU and memory SekexBot itself uses, phone free memory, battery and temperature, free storage, library versions, uptime, whether trading is on, and the last few error messages with keys, tokens and dollar amounts removed. It never sends API keys, passwords, positions, orders, balances, P&L, symbols or the journal. Show exactly what is sent displays the real report. Turning sharing off tells the collector to delete everything it holds for that install.
- Hidden support admin panel (for the person running support). Tap the SekexBot logo 7 times, enter the admin passcode, and see every install that is sharing: online or not, version (old ones flagged), phone and Android level, app CPU and memory, phone memory, battery, storage, errors, with a 6-hour history graph and the recent errors per phone. The passcode is checked by the collector, not stored in the app. The panel needs the separate collector program (collector.py), which is not part of the phone app.
- To report anywhere, a build needs the collector's https address (Admin panel, or DEFAULT_COLLECTOR_URL in autobot/telemetry.py for what you ship to users).

## 1.60.1 — 2026-10-01
- The installer now also copies the tools folder to the phone. Before, `sekex replay SYMBOL DATE` (replays a past day through every strategy) could not run on the phone because its script was never installed. No other change; you do not need a new setup script, `sekex publish` / `sekex update` is all you need for updates.

## 1.60.0 — 2026-10-01
- Keep the screen on. New setting in Controls, Keep this screen on while SekexBot is open: Off, Only while charging (default), or Always. It uses the browser's screen wake lock, so the screen stays on only while the SekexBot page is showing, never in other apps, and it follows the charger automatically. If the browser or battery saver refuses, the note under the setting says so. Samsung phones also have a system-wide option: Settings, About phone, Software information, tap Build number 7 times, then Settings, Developer options, turn on Stay awake (screen never sleeps while charging).

## 1.59.3 — 2026-10-01
- Closing a BOT trade in extended hours: the first Close tap works the order from the middle of the spread, and a second tap while that order is still open now takes the market price at once (before, the second tap repeated the gentle first try). Closing your own positions already worked this way.

## 1.59.2 — 2026-10-01
- The learned exit-slippage figure (added to the Harvest small % target) now ignores stop-outs, time stops and end-of-day exits, which slip far more than calm exits and would have inflated the target.

## 1.59.1 — 2026-10-01
- Spread filter. New setting Max spread for bot entries (Controls, default 0.15% of the price, 0 = off). The bot skips an entry when bid-ask is wider than that, in every session, and says so in the skip log. On a wide spread you start the trade that far under water and the exit pays it again, which is how a green position closes red. Your manual ticket does not block you but warns: a red banner on the quote when the spread is over the limit, and a heads-up with the dollar cost when you place the order.
- Safer defaults. Overnight trading and Shorts 24/5 are switched back OFF (one time, for existing installs too; new installs start with them off). Overnight quotes are the thinnest and widest of any session. You can turn either back on in Controls once your journal shows it pays.

## 1.59.0 — 2026-10-01
- Patient close, so a win stays a win. On a wide spread (pre-market and after-hours often 0.3-0.5%), the on-screen gain is measured at the last trade but a close fills at the bid (or the ask for a short), so a green position can close red. The Close button now works the order instead of hitting the far side: when the spread is 0.04% or wider it posts a limit on the favourable side of the spread and walks toward the market in three steps (about 14 s each in extended hours, 6 s in regular hours), then takes the market. Tap Close a second time at any point to take the market price immediately. The walk gives up and takes the market by itself if the price runs away from you by more than one spread. Tight spreads still close at once.
- The bot does the same for exits that bank a win or a manual close of a bot trade in extended hours: the first order is half-way across the spread, and the 20-second retry then goes to the marketable price. Stop-loss exits stay immediate.
- Plan closes (the ⏰ close later feature) and stops are unchanged and still immediate.
- Reminder: the "close now ≈ $X" line on each position is what closing at the market would really give. If it is red while the position looks green, the spread is bigger than your gain.

## 1.58.0 — 2026-10-01
- Catching the win, not the loss. A trade can look green yet close red for three reasons, and all three are addressed: (1) Speed: closing a position used to cancel its stop/target orders, then wait for Alpaca to confirm, then send the close, which cost a second or more while price moved. The close now goes out straight after the cancels and only waits if Alpaca says the shares are still held. (2) Real price: the bot's profit decisions (harvest, profit lock, scalp exits) used the last trade price, but a close fills at the bid for longs and the ask for shorts. They now use the live bid/ask, so a trade only counts as a win if it is a win you can actually get. (3) Learning the cost: after every close the bot compares the price it decided at with the fill and remembers the average slippage; the Harvest small % target adds that cost automatically, and the log tells you when an exit was slow or slipped.
- Positions now show "close now ≈ $X", what closing right this second would really fill at, next to the on-screen P&L, so a +$3 that is really -$2 after the spread is visible before you tap Close.
- Applies to regular hours; extended hours already used the bid/ask for its limit orders.

## 1.57.0 — 2026-10-01
- Learn from your own manual trades. New button Analyze my manual trades (Controls, under Harvest small %): it reads your finished orders from Alpaca (last 60 days), pairs them into round trips (trades the bot opened are left out), and shows your win rate and break-even win rate, what a typical winner banks and how fast, what your losers look like, a suggested harvest % and stop %, how you re-enter after a win (how soon, and how far from your exit), and your best hours. One tap applies the suggested % as your harvest.
- New switch Auto (use the % learned from my manual wins): the bot's Harvest small % follows what you actually do, refreshed every 30 minutes in the background. It needs 15 or more finished manual trades; until then it uses the fixed % you set. The % can be changed any time, live, with no restart.
- Needs your real Alpaca account's order history, so it shows nothing on the simulator.

## 1.56.0 — 2026-10-01
- New switch Harvest small % (Controls, OFF by default) so the bot can trade the way a hand-trader does: it banks a quick gain of about 0.1% (adjustable 0.05-1%, never less than 3 cents a share so the spread can't turn it into a loss), then the existing Auto re-entry gets back in on a pullback or a run to a new extreme while the ribbon and VWAP still agree. Works in regular and extended hours. Needs Auto re-entry on. Turn it on for a day and compare the journal with it off; the stop is still the strategy's normal stop, so the win-size vs loss-size ratio is what to watch.

## 1.55.4 — 2026-10-01
- Auto-harvest fixes. (1) A harvest now has to beat the round-trip cost: it sells at the bid but buys back at the ask, so the gain per share must exceed the spread (a fade exit needs 1.5x), otherwise a "harvest" was a small loss. (2) The "banked" total only counted winning harvests and left out the stop-out loss; stops are now included, so the total is the real net. (3) If the stop's exit order failed, auto-harvest switched itself off and left the position with no stop; it now keeps the job and retries.

## 1.55.3 — 2026-10-01
- Day P&L is now explained, not just shown. The halt banner shows the equity the day started at and the equity now, so you can check the loss yourself (Day P&L = equity now minus equity at the 8 PM ET day start, open positions included).

## 1.55.2 — 2026-10-01
- Daily-max-loss halt can now be cleared. The red halt banner has a Resume trading button (with a confirmation, and a LIVE warning on the real account) and shows today's P&L as it is now, not only the figure at the moment it halted. Raising the daily limit so today's loss is back inside it clears a daily-max-loss halt automatically. The halt still resets by itself at the 8 PM ET day rollover, and the bot halts again if the limit is hit again.

## 1.55.1 — 2026-10-01
- Trend predictions on every open position. Each row in Positions & orders and in the bot's Open positions list now shows the trend (green or red ribbon: Trend up / Trend down), any early BUY? or SELL? warning with its confidence and how many candles away it is, marked "against you" in red or "with you" in green, and the direction lean (LONG, SHORT or WAIT with its score, flagged when it leans against your position). It covers your manual positions as well as the bot's, refreshes about every 20 seconds, and works in every session.

## 1.55.0 — 2026-10-01
- 24/5 trading, set up to Alpaca's rules. Alpaca trades 24 hours a day, 5 days a week (Sunday 8 PM to Friday 8 PM ET), not 24/7; weekends are closed for stocks. Overnight is now ON for everyone (one-time switch; you can turn it off in Controls). New switch Shorts 24/5 (on by default): the bot may short in every open session, overnight included, instead of only 7 AM to 8 PM; every short still needs a fresh easy-to-borrow check right before the order. Rules the app already follows and now explains on the Controls card: outside 9:30 AM to 4 PM Alpaca accepts only limit orders with Day (or GTC) time in force, whole shares only, no market, stop, stop-limit or bracket orders, so the bot sends limit orders and watches its own stops, half size, 2 positions max. Overnight prices need Alpaca's overnight data (free overnight feed, or boats with Algo Trader Plus); if Alpaca returns none the app now says so once per night and alerts you. Android note: the app has to stay running overnight because the stops live in the bot.

## 1.54.1 — 2026-09-30
- Fix: Close on a manual position could fail. The app cancelled the position's stop/target orders and waited a fixed half second; if Alpaca had not released the shares yet, the close was refused ("insufficient qty / held for orders") and nothing happened. Now it cancels the orders, waits until Alpaca shows them gone, retries up to 4 times, and as a last resort sends a plain market order the other way. A finished bot trade on the same symbol can no longer hijack a manual close, and an after-hours close with no live quote prices off the position's last price instead of refusing.

## 1.54.0 — 2026-09-30
- Fixes for the benched setups. Self-fix: Fresh start: trades closed before this version are no longer counted when a setup is judged (they were closed under the old exits), so EMA_PULLBACK, RIBBON_FLIP and the others are re-tested on fair data; a benched setup's daily probe trade is now a quarter-size test instead of half. MICRO_SCALP: risk is capped at about 0.6 ATR (was 1.0 ATR) so a scalp no longer risks far more than it can win. FLUSH_SHORT: needs two closes under the broken range low, no chasing an exhausted drop (over 1.5 ATR under the range), and volume of 1.5x. FLUSH_BOUNCE: needs a higher low, and the bounce bar must close over the EMA9 as well as the prior high. Includes everything from 1.53.0.

## 1.53.0 — 2026-09-30
- Profit protection, the bot now banks gains properly. Profit lock: once a trade has been 0.6R green it can never give back more than 40% of its best gain (50% from 1.2R, 60% from 2R, 70% from 3R); the stop follows and the bot closes the trade if it falls to that level, in regular and extended hours. Earlier partials: sells 1/3 at +0.7R and 40% of the rest at +1.5R, break-even at +1R, tighter trail from +1.5R, and the far take-profit order is cancelled when a partial is taken. Reversal exit: if the app's direction call turns 55%+ against a trade that is 0.5R or more green, the bot sells half; if it is still against you on the next check it closes the rest.

## 1.52.1 — 2026-09-30
- Voice commands understand you better: extra words before the command no longer break it ('SpaceX status', 'hey Sekex, what's my balance'), SpaceX/Tesla/Apple and other company names map to their tickers, spoken numbers like 'twenty five' and 'one hundred' work, and 'SPCX status' reads that position's P&L. 'Close half' on a 1-share position now says so instead of closing it all.

## 1.52.0 — 2026-09-30
- Shorts from 7 AM for every setup. New switch (Controls, on by default): shorting turns on by itself at 7:00 AM ET and stays on until 8 PM, pre-market included, no matter what the manual Allow short selling box says (before 7 AM it stays off). Every setup can now short: MEAN_REVERT gets a short side (stretched above VWAP, overbought), the extended-hours micro-scalp can short, and a new FLUSH_FADE setup (short mirror of FLUSH_BOUNCE: fast spike up on volume, first red bar under the prior low) runs in regular hours and pre/after-market. Borrow checks, the 2-loss block and all risk limits still apply.

## 1.51.1 — 2026-09-30
- Two fixes from a code review. (1) Restored the suggested stop-loss / take-profit for manual orders: it had stopped working in v1.33.0 (Protect and Suggest levels returned an error) because a new file replaced the code behind it. (2) Closed a security hole: a web page open in the phone's browser could press bodyless buttons on the local dashboard (Flatten, Start, Reopen last close...) when no dashboard token is set. Local requests now must come from the dashboard itself (Origin/Host checks); curl and the sekex command are unaffected.

## 1.51.0 — 2026-09-29
- Voice + header patch built in (it no longer gets wiped by updates). 🎤 Voice commands: tap the green mic (bottom right; can move it to the left or hide it in ⚙ → Voice) and say 'Close META', 'Close half META', 'Close all', 'Status', 'Buy 5 META' or 'Short 15 SPCX'. Every command is shown and read back, and nothing is sent until you tap CONFIRM (it cancels itself after 20 s). Voice orders are capped at 500 shares; voice closes use the Close button's own logic, so after-hours shorts get the extended-hours limit order. Needs Chrome on http://127.0.0.1 or your https link. Welcome greeting ('Hello Ty-see-key, let's make some money!') on your first tap after opening, while 🔊 is ON; editable, with a Test button and an off switch. Header message: optional passcode lock (⚙ → Header message → Set a passcode; 5 wrong tries = 15-minute wait), and long messages now shrink to fit on two lines.

## 1.50.1 — 2026-09-29
- Header message moved into ⚙ Settings → Header message: type the text, tap a color (White, Green, Red, Gold, Blue, Purple) and a size (Small, Medium, Large), see a live preview, then Save or Remove. A 'Show in the header' switch hides it without deleting it. Tapping the message in the header opens this section; the empty 'Tap to add your message' box no longer shows in the header.

## 1.50.0 — 2026-09-29
- 📊 Review my signals with Claude (⚙ → Help, or the link under the chart): ask Claude about your BUY / SELL alerts in plain words. The app first grades every signal on your real recent prices (watchlist + stocks you traded): how late each confirmed BUY/SELL came (in normal candle ranges), whether price followed through over the next 5 candles, how often the BUY?/SELL? warnings were right and how many candles early, split by 1/3/5-minute chart, session and stock. It tests other early-warning settings on the same data and reads your trade journal, skipped signals and log errors. Claude then explains what it found and suggests warning settings (confidence cutoff, how soon the lines must cross, how much the ribbon must thin, the after-hours penalty) that you apply with one tap, kept within safe limits, with reset to default. It only changes the early warnings and their alerts, never how the bot trades. If a code change is needed, one tap sends it to Fix with Claude.

## 1.49.1 — 2026-09-29
- Your own message in the header: tap the empty space next to the session status (✎ Tap to add your message) to write a big, bold line such as a trading rule, and pick its color. It's saved on the bot, so every device shows it; tap it again to change or remove it.

## 1.49.0 — 2026-09-29
- 🤖 Fix with Claude (⚙ → Help & repair): describe a bug in plain words and Claude reads the relevant code, writes a fix and explains it in plain English with a risk level (and a warning if it changes how orders, stops or exits behave). The app tests every fix on a copy first (Python must compile, the dashboard's JavaScript must parse, the copy must start in simulator mode, load the dashboard and run 8 s without errors); a fix that fails is never applied. You review it (plain summary + the code change) and enter your Live PIN to apply; the changed files are backed up and the app restarts (trading resumes). If a fixed app won't start 3 times, or a patched file won't compile, it rolls back by itself; Undo (PIN) restores the last backup. Never touches keys, .env or data; only on the phone itself, not over the remote link. Uses your Claude API key and credits.

## 1.48.1 — 2026-09-29
- Fixed: auto-harvest (♻) stopped out a position on one bad quote when the overnight session started at 8 PM (TEM, Sep 29). Its protective stop now uses the mid price instead of the bid, ignores the first 3 minutes of each session and any time the spread is too wide, and needs price to stay beyond the stop for 25 seconds (straight away only at twice the stop). Overnight (8 PM - 4 AM) auto-harvest pauses and holds the position as is, then resumes at 4 AM pre-market.

## 1.48.0 — 2026-09-29
- ⏰ Close later: a new button on each of your positions sets a plan that closes the whole position by itself at the first of: a time (presets: tonight 7:55 PM, 4:00 AM pre-market, 9:30 AM open, 3:55 PM, or any time you pick), the trend turning against you (a NEW 3-minute ribbon flip red for a long / green for a short), or a take-profit / stop price. It runs on the phone even with the dashboard closed, is saved across restarts, uses extended-hours limit orders outside 9:30-4:00 and re-prices every minute until filled, and waits for the next session if it triggers while the market is shut. If Alpaca refuses to cover a short overnight it keeps trying and closes at 4 AM pre-market. Alerts with beep + voice when the plan fires and when it fills. Tapping Close yourself removes the plan; setting a plan turns off ♻ auto-harvest for that stock.

## 1.47.2 — 2026-09-29
- More close fixes: closing a BOT short after hours now prices the cover at the ask (was the bid, so it could sit unfilled); tapping Close again re-prices a bot exit that hasn't filled; a bot trade from regular hours that is still open after hours now closes with an extended-hours limit (the market close was being rejected silently); a regular-hours bot close that Alpaca rejects now shows the error instead of 'ok'. A full Close turns off auto-harvest (♻) for that stock so it can't buy back in. Watchlist warnings refresh right away when you add or remove a ticker.

## 1.47.1 — 2026-09-29
- Fixed: Close did nothing for SHORT positions in pre-market / after-hours (it refused with 'Covering a short needs regular hours'). Close now sends an extended-hours limit buy to cover a little above the ask (0.3%), the same way longs are sold; press Close again to re-price if it hasn't filled.

## 1.47.0 — 2026-09-29
- Beep and voice alerts for BUY / SELL on your watchlist, with an ON / OFF speaker button in the top bar (next to the bell) that mutes or unmutes everything in one tap, also from the remote link. Phone (works with the screen off, needs Termux:API): the notification plays a sound and vibrates (BUY = 2 short buzzes, SELL = 1 long, early BUY?/SELL? warning = 3 quick taps), and the phone says it out loud, e.g. 'S P C X. Sell signal. Trend turned down.' or 'M E T A. Buy warning. 74 percent.' Early warnings are a new alert (Settings > Alerts), spoken from 65% confidence by default (Warn me from: 60-80% or Never). Dashboard, while open: a rising two-tone beep for BUY, falling for SELL, three taps for warnings, a spoken alert and a colored banner (tap the screen once so the phone allows sound). While the dashboard is speaking, the phone's own voice stays quiet so you never hear it twice. New Settings switches: Beep on BUY / SELL, Say it out loud (with Test).

## 1.46.0 — 2026-09-29
- Early BUY? / SELL? warnings on the chart, for every watchlist stock. Dashed amber boxes appear when the trend ribbon is about to flip, before the confirmed BUY/SELL (the yellow line closing in on the white line, price crossing the yellow line and VWAP, the white line flattening, volume picking up). Each has a confidence %; past ones are graded ✓ (the flip followed within 6 candles) or ✗ (false alarm), and the chart shows the stock's hit rate, how many candles early, and the average price gained vs waiting. Warnings under 60% are hidden. Display only: the bot never trades on them. Watchlist chips now show each stock's trend dot, an amber ring plus BUY?/SELL? % when a warning is live, and 'no data' when Alpaca sends no prices (e.g. QNT). Tapping a warned chip, the new ⚡ Trade button or 'Open trade popup' opens the quick trade sheet with a live chart (1m/3m/5m/15m) and the warning, and the suggested side is outlined. Plain-English ⓘ popups on every chart term: VWAP, uptrend/downtrend, fast/slow lines, ribbon flips, BUY?/SELL?, O/H/L/C, volume, measure tool, after-hours.

## 1.45.0 — 2026-09-29
- Two safety rails: (1) no single position larger than 25% of your equity (margin buying power is ~4x, so one trade could be the whole account, like the 6,043-share KNDI trade); (2) a setup with fewer than 20 closed trades trades at 35% size (70% if it is already winning), full size only after it proves itself. Switch on the Self-fix card.

## 1.44.0 — 2026-09-29
- Let winners run and pick better: SCALE exit now takes 1/4 at +1R with the stop only to -0.5R (break-even after +2R), wider 1.8 ATR trail, target 8R; scalp profiles no longer bank at +0.15R (switch: Let winners run); ribbon-flip exit needs 3 confirmations. Entry filters: no stocks under $2, no trades against a clear early direction call.

## 1.43.0 — 2026-09-29
- Self-fix: the bot reviews its own last 12 closed trades of every setup. Losing setups are benched (one half-size probe trade a day until they recover); winning setups are promoted (ranked first, up to +30% size). New Self-fix card shows each setup's status; on by default, switchable.

## 1.42.0 — 2026-09-29
- Double-tap any row (pre-market timeline, shortlist, evening candidates, movers, setups) to open the quick BUY / SELL sheet. Single tap still opens the chart. Quantity is remembered from your last quick trade.

## 1.41.3 — 2026-09-29
- Anti-churn block is now only 2 losing closes on the same stock within 30 minutes (replaces the max-trades and wait-time rules). The dashboard shows blocked stocks with a Release button; release also clears the older cooling-off counters.

## 1.41.2 — 2026-09-29
- Stop churning one stock: always-on anti-churn guard read from the trade database (max 4 trades and 2 losses per symbol per day, 8 min between trades, 20 min after a loss). Works across restarts and cannot be switched off.

## 1.41.1 — 2026-09-29
- Pre/after-market trades no longer stop out too early: stop is at least 0.45% (or 1.2 ATR) from entry, price (mid) must stay beyond the stop 25 s before exiting (immediate only at -1.4R), and the ribbon-flip exit waits 6 minutes and never cuts a trade already above +0.9R.

## 1.41.0 — 2026-09-29
- Automatic system now finds and trades BOTH longs and shorts (mode picker: Longs + shorts / Shorts only / Longs only). Borrow check applies to shorts only; hard-to-borrow names stay on the shortlist as long-only candidates.

## 1.40.1 — 2026-09-29
- Fixed pre-market orders being rejected for insufficient buying power (BMNR: needed $5,584, had $5,410). Extended-hours checks did not refresh the account, so sizing used a stale buying-power number. Now the account is re-read before every pre-market or after-hours order, the quantity is capped to 95% of real buying power, and if Alpaca still says insufficient buying power the bot reads the real numbers from the error and retries once with a smaller quantity. Regular-hours orders and the manual auto-harvest re-entry get the same shrink-to-fit.

## 1.40.0 — 2026-09-28
- Auto re-entry that jumps back in. After a profitable exit the bot (all setups, regular hours and pre-market/after-hours) gets back in on the same side in two ways: on a pullback of at least a quarter of the stock's normal range with the latest 1-minute bar turning back, or, if there is no pullback and the stock keeps running, as soon as a completed 1-minute bar closes at a new high (or low, for shorts) at least 0.3 of that range past the exit price, with the ribbon and VWAP agreeing. Up to 3 re-entries per stock in a row, within 90 minutes, never after a loss, a ribbon turn against you, a daily-loss halt or an end-of-day flatten; bought or shorted with the same take-profit-along-the-way exit. The manual auto-harvest (the ♻ button) now does the same: back in on a pullback, or after 45 seconds if it keeps running past the harvest price. Switch: Controls > Advanced > Auto re-entry (on by default). New REENTRY trades show in the journal.

## 1.39.0 — 2026-09-28
- Automatic short system. One tap (Enable automatic short system, on the card near the top) for the selected PAPER or LIVE account: it starts the bot, turns on shorts only, morning reversal, the pre-market plan and (with SIP) late-day overnight shorts, then waits for a fresh, confirmed 1-minute short signal before ordering. LIVE asks for your Live PIN. Before every short it rechecks Alpaca's borrow_status (must be easy_to_borrow and shortable; hard-to-borrow names are skipped). Overnight homework: each night after 4:35 PM the whole market is ranked by volume, trade count and movement (plus your watchlist) into a short shortlist, and from 8:00 AM ET it is rechecked every 15 minutes and added to the live scanner with the new movers. Harvest and re-entry: short-system trades use the exit that takes portions near +1R and +2R and trails the rest, and after a profitable exit the same stock is only traded again on a distinct new signal (a different setup, or a 15-minute pause plus a real bounce). Long signals are ignored while the system is on. Turn it off from the same button.

## 1.38.0 — 2026-09-28
- Pre-market timeline: from 4 AM the bot snapshots the big movers at 4 AM, 7 AM, 8:30 and 9:15 (4 AM needs the SIP feed; you have it) and shows how each one moved (holding, faded, extending) in a new Pre-market timeline card, with a phone alert at the 7 AM and 9:15 checks. Short at open: gappers up 1.5%+ that have faded off their pre-market high and are under VWAP go on a short-at-open list, and the new OPEN_SHORT strategy shorts the first close below the pre-market low between 9:31 and 9:50 (stop above the early high or VWAP). On by default; switch: Controls > Advanced > Pre-market plan. Pre-market and after-hours trading already run from 4 AM once the feed is SIP.

## 1.37.0 — 2026-09-28
- Three new tools, all off by default except the review. (1) Morning reversal (Controls > Advanced): looks for a second rejection of the opening high (the first 5 minutes' high), then waits for a completed 1-minute close below the low since that rejection before it shorts, 9:40-11:30, stop just above the opening high. The opening window is ignored, so a 9:35 poke and fake-out does not count, and a breakout above the high cancels it. (2) Pre-close overnight short (Controls > Advanced): scans 3:10-3:35 PM for a spike that is failing (up 3%+ and faded 40% off the high) or a weak close (down 3%+, near the low), under VWAP with a red ribbon, and shorts shares with a broker-held GTC stop and target placed once filled. Needs the SIP feed and a short-enabled account, skips Fridays and days before holidays, and skips earnings and risky news. The bot covers by 10:15 AM if neither order has hit. A GTC stop can fill far worse if the stock gaps up at the open. Shares only, because Alpaca has no extended-hours options orders. (3) Review evening candidates button and card: lists the prior session's setups; each is a watch item that is scanned the next morning, and no order is placed until a fresh signal confirms. It also runs by itself after 4:30 PM. New command: sekex replay SYMBOL DATE prints when each strategy would have fired on that day using your Alpaca data. Fixed: release zips no longer include the simulator's test data folder.

## 1.36.0 — 2026-09-28
- Automatic direction trading: when a Big mover gets a strong LONG or SHORT call (score 45+, most signals agreeing, not stretched from VWAP), the bot now trades it by itself between 9:33 and 11:00 (new DIR_CALL strategy, ridden with the take-profit-along-the-way exit) and sends one phone alert per stock per day. The call uses pre-market bars, so it works from the opening bell instead of 9:44. It is on in Balanced, Aggressive and Max, and off in Conservative (Controls > Advanced, Trade strong early direction calls). DIR_CALL trades are paused automatically if the overnight study finds that kind of call right less than half the time over 20+ calls. The study also replays DIR_CALL each night so the learner sizes it.

## 1.35.0 — 2026-09-28
- Early direction call: every Big mover and any ticker you type into the manual ticket now shows LONG, SHORT or WAIT with a score and the reasons. It is a weighted vote of price vs VWAP, ribbon, swing structure (higher highs or lower lows), 15-minute momentum, buying vs selling volume, position in the day's range, SPY/QQQ, and how that stock's gaps have behaved (follow through or fade) in the overnight study. It says WAIT when the votes disagree and flags when price is stretched from VWAP. The overnight study scores each 9:40 call against the next hour on past days and shows how often LONG, SHORT and STRONG calls were right.

## 1.34.0 — 2026-09-28
- Catch the morning trend and learn overnight. (1) The ribbon now starts from the pre-market bars, so it is ready at 9:30 instead of about 10:00, which is why early trends were missed. Entries open 2 minutes after the bell (was 5). (2) New PLAN_TREND strategy: a name on the Big movers list that gapped 0.8%+ and breaks its early high (or low, for shorts) with VWAP, ribbon and volume agreeing is bought or shorted right away; PLAN_TREND and GAP_GO trades are ridden with the SCALE exit (take profit along the way, trail the rest) instead of a quick scalp. (3) Overnight study: after 5 PM, overnight and on weekends the bot replays the last few trading days of your stocks minute by minute through every strategy and every exit style and teaches the learner, weighted at 0.3 of a real trade; each day is studied once. New Overnight study card with Study now and an on/off box.

## 1.33.0 — 2026-09-28
- Trading levels: pick Conservative, Balanced, Aggressive or Max in one tap instead of setting many boxes. Auto learns which of the first three works best in each session (pre-market, regular, after-hours) from your own trades, judged by average R per trade once a level has 8 trades in that session, and switches at each session start (it never picks Max on its own, and starts from Balanced/Conservative defaults while it learns). Change any single box under Advanced and the level becomes Custom. Existing setups keep their current switches as Custom. The daily max loss and session on/off boxes are never changed by Auto.

## 1.32.0 — 2026-09-28
- Automatic morning and night setup: the Big movers list now builds itself every 5 minutes in pre-market and after-hours even when the auto-trader is stopped (turn off with Controls > Auto-prep), and the last list stays on screen overnight and after a restart, with an as-of time, so it no longer goes empty. If your Alpaca account has the paid SIP data feed, SekexBot detects it at startup and switches to it, which gives the full 4 AM to 8 PM window (free IEX only covered 8 AM pre-market and after-hours until 5 PM). Positions are still flattened shortly before each session ends.

## 1.31.0 — 2026-09-28
- Auto-harvest: tick the new ♻ box on the manual ticket or quick-trade sheet (or tap ♻ on an open position). It sells for a small quick gain (about half the stock's normal 5-minute range, or when the gain starts to fade), then buys or shorts the same size again on a pullback when the ribbon still agrees. It repeats until you tap Stop, and stops on its own if the ribbon turns against you, the daily loss limit halts trading, or a trade goes 1.2 ranges against you (it closes that one). Works long or short, with the auto-trader on or off.
- Reopen last close: one tap, no confirmation, puts back the position you last closed by hand (same stock, side and size), and turns auto-harvest back on if it was on. Shows under Positions after you close something.

## 1.30.1 — 2026-09-28
- Publish in one command: run `sekex publish` in Termux after saving a new zip to Downloads. It finds the newest zip, writes latest.json (version, checksum, notes), uploads the zip and then latest.json to your GitHub update repo, and sets the app's update link. GitHub repo and token are asked for once and stay on the phone.

## 1.30.0 — 2026-09-28
- Pre-open mode: pre-market and after-hours trading are now ON by default (your existing settings switch on once). The bot scans for movers every 5 minutes, keeps taking pre-market entries until 9:20 instead of stopping at 9:05, and only closes pre-market trades in the last 4 minutes before the open.
- Gap fade: new GAP_FADE strategy for a gap that fails. A gap-up losing the opening-range low and VWAP is shorted (SPCX on Sep 28). A gap-down reclaiming the range high and VWAP is bought. Runs 9:40-10:45. Gap and go now starts at 2% gaps, long or short (META on Sep 28).
- Evening movers: new EXT_TREND strategy trades pre-market and after-hours continuation of 1.2%+ movers, long or short, when the ribbon, VWAP and a fresh break agree.
- Big movers list: new card with the top 10 names moving 1%+ from the last close, each with a plan (GO, FADE or WAIT), side, trigger and target. It works in pre-market, at the open and in after-hours, and sends one alert around 8:55 AM and 4:05 PM.

## 1.29.0 — 2026-09-28
- Shorts on by default: SELL flips and short setups now trade in regular hours, and in pre-market and after-hours when the stock is shortable and your account can short. Overnight stays long-only. Stops, take-profits and exits work for shorts in every session.
- Why no trade?: a new panel lists every signal or ribbon flip the bot saw but skipped, with the exact reason (flip too old, below VWAP, time-of-day filter, cooling off, cannot short, slots full, sizing and more). Filter it by symbol.
- Trade every flip: optional switch that takes each fresh ribbon BUY/SELL flip on your watchlist and picks. It skips the VWAP, learner and time-of-day checks for flips only. The daily loss limit and position sizing still apply.

## 1.28.0 — 2026-09-28
- ✋ One-tap manual trading: no more 'Send this order?', 'Close?' or LIVE-money pop-ups on the order ticket, the quick trade sheet or Close buttons. The order goes straight away. To bring the pop-ups back, tick 'Ask before sending or closing manual trades' in Controls. Opening a short when you don't own the stock still asks once, because losses are unlimited.

## 1.27.0 — 2026-09-28
- 🧊 Cooling off is now optional (Controls). 'Cool off after 3 losses in a row' switches off the 20-minute pause and the half-size penalty. 'Symbol cooldown' switches off the wait before re-trading a stock and the skip after 2 losses in a day. Both are on by default. While the bot is cooling off, a ▶ Resume now button clears the pause, the penalty and today's cooldowns in one tap. The daily loss limit always stays on.

## 1.26.0 — 2026-09-28
- 💰 Quick harvest for scalps (Aggressive and Scalp modes, every session): once a scalp has been green for 2 checks in a row, it doesn't wait for the target. It banks the profit when momentum stalls (0.15R back from its best) or when it's near the target. The stock can be re-entered right away if the setup fires again; otherwise the slot goes to the next best candidate. Bug-check fixes: restoring open trades after a restart or a ↩ Revert no longer fails when versions store different trade fields, and log lines show the size weight rounded.

## 1.25.0 — 2026-09-28
- 🔥 Aggressive scalping (Controls, off by default): many fast trades in every session. It adds a MICRO_SCALP setup (1-minute burst over the last 3 bars on 2× volume, above VWAP) and trades every setup with ½ at +0.5R (the rest moves to break-even) and the rest at +1R, out within 8 minutes. Up to 6 positions at 60% size, checks every 10 s (5 s in extended hours), and shorter cooldowns. The daily loss limit still applies. 🔻 Flush short: a tight range that breaks down hard on 2× volume (like TSLA's drop), when shorting is on. 🔺 Flush bounce: the first strong green bar after a fast 2-ATR drop on a volume spike (in all sessions). Flush setups skip the ribbon wait and the time-of-day filter. 🎯 Setting up now: a live top-15 list of stocks coiling for a fast move before it happens (tight range, volume building, lean from VWAP, ribbon and highs/lows), with the likely direction, trigger price, target, expected move, a 0–100 Ready score and ⚡ breaking now. The stock picker now scans 30 names.

## 1.24.0 — 2026-09-28
- 💰 Profit harvesting in every session. Pre-market, after-hours and overnight trades now take profit along the way like regular hours: ⅓ at +1R (the rest moves to break-even), ⅓ at +2R, then a 1× ATR trail or a ribbon flip. Partial sells are marketable limit orders, the only kind Alpaca allows outside regular hours, and each one sends a 💰 alert. ⚡ New Scalp mode (Controls, off by default): ½ at +0.6R, the rest at +1.2R, out within 20 minutes, in every session. ⬆ Update progress: the update screen shows a progress bar, each install step with a ✓, elapsed time and a details log. The app keeps serving while it installs and only restarts at the end.

## 1.23.0 — 2026-09-27
- 🚀 Opening Drive setup (OPEN_DRIVE), modeled on your best trades (SPCX, VKTX, AMD at 9:30): a +2% gapper that breaks its first-5-minute high above VWAP on a volume surge, 9:35–9:50 (a gap-down short when shorting is on). 💰 Take profit along the way (on by default): the bot sells ⅓ at +1R and moves the stop to break-even, sells another ⅓ at +2R, and rides the rest with a 1× ATR trail or until the ribbon flips. A '💰 Took profit' alert fires each time, and the journal and learner count the whole trade. 🕒 Time-of-day filter from your own history: the bot skips new trades in the time slots where your last 90 days lose money (at least 30 trades; today that's midday, morning after the drive, after-hours and overnight), and still allows opening drives until 9:50. Switches for both are in Controls. ⬆ Updates: SekexBot checks for a new version every hour and, in Ask mode, shows Update now / Later / Skip this version; Manual mode never prompts. Every update saves the version it replaces (the last 3 are kept), and '↩ Revert to vX' in the Update screen (or 'sekex rollback X.Y.Z') goes back while keeping your data.

## 1.22.0 — 2026-09-27
- 🔍 Trend research (Manual tab): type a ticker (for example SPCX), choose 10–90 days and tap Study. It finds every big run up or down in the stock's own minute history. For each run you see the start and end times and prices, the move and how long it lasted, grouped as morning, midday or afternoon. It also shows when morning runs typically start, what was true as runs began (opening drive, opening-range break, above or below VWAP, volume surge) and which exit rule kept the most of each run (ribbon flip, VWAP cross, 2 closes against, 1× or 2× ATR trail). These results will shape the bot's new morning and wave strategies.
- 🔔 3:55 PM overnight test: buy (or short) at 3:55 PM and exit at 8 PM, 11 PM, 2 AM, 4 AM, 8 AM, 9:25, 9:35 or 10 AM. Shows average result, long and short win rates, and worst and best days, and highlights the best combination. It uses real overnight (24-hour session) prices where the stock trades overnight.

## 1.21.0 — 2026-09-27
- 📊 Trading stats (Positions tab): every trade in your Alpaca account, bot and manual, matched from buy to sell. Shows total P&L, win rate, average win and loss, and profit factor. P&L by time of day (pre-market, morning 9:30–11:30, midday, afternoon, after-hours, overnight); tap a time to filter. Your top 5 wins and worst 5 losses, bot vs. manual results, and each bot strategy's results. Covers 7 days to 1 year.
- 📰 Earnings and news: the order ticket shows whether the stock reports earnings today or before the next open, plus the latest headlines, with risky ones flagged (offering, halt, bankruptcy, delisting, investigation, reverse split, downgrade…). The auto-trader skips a stock on its earnings day, doesn't buy after-hours or overnight right before a pre-market report, and waits 30 minutes after a risky headline. It uses the free Nasdaq earnings calendar and Alpaca news. If either is unreachable, trading continues.
- 🛡 Safety net (⚙ Settings): a phone-offline alert through free healthchecks.io. The app pings every minute; if the phone dies, sleeps or loses internet, healthchecks.io alerts you by email, SMS, ntfy or Telegram. Nightly backups at 8:10 PM ET of the journal, learning memory and settings (never API keys or tokens) to Downloads/SekexBot/backups, keeping 14, with optional upload to a private GitHub repo. Back up now and Restore buttons included.

## 1.20.5 — 2026-09-27
- Charts at any hour: the chart now shows the last few days, including pre-market, after-hours and the overnight (24-hour) session, not just 9:30–4:00. Nights and weekends show the most recent real prices, the same as Robinhood's 24 Hour Market chart. It uses Alpaca's overnight feed (BOATS on SIP accounts, Alpaca's overnight feed otherwise). Extended hours are lightly shaded and overnight is shaded blue. When nothing is trading, the header says when the last trade happened.

## 1.20.4 — 2026-09-27
- Take profit after a halt: every winner kept open gets a profit lock, set at break-even or better and then at half of its best gain, rising as the price climbs. If the price falls back to the lock, the position is sold (limit orders in extended hours) and you get a "💰 Took profit" alert. This covers manual positions too. Bot trades also get their stop at Alpaca raised to the lock. Profit locks survive an app restart.

## 1.20.3 — 2026-09-27
- Daily loss limit: when it's hit, the bot now closes only the **losing** positions (bot and manual) and keeps the winners open. Winners keep their stop-loss and the bot keeps trailing them; it just opens no new trades until the next day (8 PM ET). In extended hours the losers are closed with limit orders.

## 1.20.2 — 2026-09-27
- Auto-trade safety fixes: after switching from PAPER to LIVE on the same day, the bot could compare your live balance with the paper account's starting balance, read it as a huge loss, and close all live positions. The start-of-day balance is now kept separately for Paper and Live, and any figure far off your real equity is ignored. Updated for FINRA's retirement of the pattern-day-trader rule (Alpaca's Intraday Margin Framework, since June 4, 2026). No day-trade counting and no $25k minimum: the bot sizes within intraday buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders. The app keeps working after Alpaca removes the old day-trade fields from its API on July 6, 2026. A position the bot can't close now raises an alert instead of failing silently. Saved halts and loss streaks are again restored correctly after a restart (the new always-on balance display could skip them).

## 1.20.1 — 2026-09-27
- Fixes: the account bar and Account card now show your balance, buying power and today's P&L at all times, including nights and weekends (they were blank while the market was closed). Switching the data feed to SIP now works while the auto-trader is running — it checks your account really has SIP, switches, and restarts the bot — instead of silently flipping back to IEX.

## 1.20.0 — 2026-09-27
- Paper / Live switch: tap the PAPER / LIVE badge at the top to switch. Live needs your Live PIN, a real-money confirmation and working live keys (checked first); a running auto-trader stops, switches and restarts by itself. Too many wrong PINs lock the switch for 15 minutes. Live is unmistakable on every screen: a red frame, a '● LIVE — REAL MONEY' bar, a pulsing red badge, 'LIVE ·' on order buttons, a red browser bar and '🔴 LIVE' in the title and alerts. Account bar: balance, today's P&L ($ and %), open P&L, buying power and loss left stay pinned under the header on every screen and layout.

## 1.19.0 — 2026-09-27
- Interactive chart: touch or drag for a crosshair with time, OHLC, volume, trend (uptrend/downtrend), fast/slow lines and VWAP; tap to pin a point and measure the move to the crosshair ($, %, time, ribbon flips); pinch or scroll to zoom, drag to pan, double-tap to reset; 1m / 3m / 5m / 15m timeframes; volume bars and a VWAP line.

## 1.18.0 — 2026-09-27
- Streaming prices: real-time quotes and trades from Alpaca's websocket (up to 30 symbols on the free plan), pushed to the dashboard — the ticket, quick sheet and positions P&L move tick by tick with a STREAMING badge. The bot uses streamed prices too, and its extended-hours stops (watched by the app) now react within about a second instead of 15. Falls back to polling automatically if streaming isn't available. Help & repair now checks whether SIP data works on your account and can switch back to IEX with one tap.

## 1.17.0 — 2026-09-27
- Alerts: phone notifications (with Trade and Close buttons) for bot entries, fills, exits with P&L, stops raised, rejections, daily-loss halt, losing streaks, broker restrictions and stale data; watchlist trend alerts (ribbon flip, new high/low of day, VWAP, volume spike); price alerts; end-of-day summary. Optional copies to ntfy or Telegram, quiet hours, per-type switches, and a bell with the alert history. Faster trading: $1k / $5k / 1R / Max size buttons and a price-alert button in the quick sheet; tapping Trade on a notification opens the quick sheet. Help & repair: run checks, one-tap fixes (reconnect, restart, repair install, update), Ask AI (Claude explains errors in plain steps) and Send report. Fixes: bracket orders rejected while the market is closed are re-anchored on Alpaca's reference price automatically, order errors are explained in plain words, and suggested stops can no longer be unrealistically tight.

## 1.16.0 — 2026-09-26
- Live price everywhere, at any time: the order ticket and quick trade sheet show the price, day change (green/red), bid/ask and a LIVE dot, refreshing every 3 seconds, with the cost worked out as shares × price against your buying power. When the market is closed (nights, weekends, holidays) the price falls back to the last trade or last close, labeled 'as of', so orders can always be prepared. The trend chart shows the most recent session when the market is closed instead of 'Waiting for bars'.

## 1.15.0 — 2026-09-26
- Suggested stop-loss / take-profit: tick Attach stop-loss / take-profit and SekexBot proposes Scalp, Day and Swing levels from real support/resistance and the stock's volatility (ATR), with R multiple, trend check and a size that risks the bot's base amount. The quick trade sheet can protect orders with the Day levels automatically. Fix: prices now work on nights and weekends (last session's close), so orders can be prepared while the market is closed.

## 1.14.1 — 2026-09-26
- Gains show green and losses red everywhere, with a + sign on gains: today's P&L, the summary strip, every position and its %, bot trades (new P&L column), the journal, daily results and averages. Totals for Positions & orders, Open positions and Daily results. sekex status colors the day's P&L too.

## 1.14.0 — 2026-09-26
- New layout with a ⚙ gear: choose Tabs (Auto · Manual · Positions · More at the bottom), an Auto | Manual switch, or the classic one-page layout. Light, dark or follow-the-phone theme. A big Auto-trader on/off switch and an always-visible summary strip (equity, today, loss left, open trades). Your choices are remembered on each device.

## 1.13.0 — 2026-09-26
- Double-tap to trade: double-tap any stock in the picker, the scanner chips or your positions to open a quick trade sheet with the suggested size and big BUY / SELL (or SHORT) buttons. A single tap still opens the chart.

## 1.12.1 — 2026-09-26
- Turn off app button uses an icon every phone font can show.

## 1.12.0 — 2026-09-26
- Full order ticket like Alpaca's: Buy/Sell (Short), Market, Limit, Stop, Stop limit and Trailing stop orders, a quantity stepper, a limit price with tap-to-fill bid/ask, Time in force (Day, GTC, IOC, FOK, At the open, At the close) and Trading session (Market hours, Extended hours, 24 Hour Market). In-app updates: install a new version from the dashboard (⬆ Update) by picking the zip, or from an update link that is checked every 6 hours, with a notification and one-tap install.

## 1.11.0 — 2026-09-26
- Manual trading: a Manual trade ticket with Buy and Sell (market or limit, size in shares or dollars, optional stop-loss and take-profit) and a Positions & orders panel for the whole account with Close, Close ½ and Cancel. The bot stays out of any symbol you trade by hand that day and never flattens your manual positions at the close.

## 1.10.0 — 2026-09-26
- Fully automated install: one-file installer (SekexBot_Setup.sh), optional sekexbot-setup.conf to pre-fill keys and settings and start trading automatically, a non-interactive package install with a log, and 'sekex doctor --fix', which checks the phone and opens the screens that fix problems.

## 1.9.1 — 2026-09-26
- Tap-to-use controls: home-screen Start / Stop / Status / Open buttons (Termux:Widget), Start and Stop buttons in the SekexBot notification, pop-up messages, and a ⏻ Turn off app button on the dashboard.

## 1.9.0 — 2026-09-26 (Android edition)
- 🤖 Runs entirely on an Android phone inside Termux. No PC needed. `install.sh` sets everything up, and the `sekex` command starts, stops and checks the bot.
- Watchdog: if the app crashes or Android kills it, it restarts automatically, and trading **resumes** if it was running (a Stop from the dashboard or `sekex stop` is remembered).
- Open trades, today's halt state, profit-lock peak and losing-streak brakes are saved every tick and restored after a restart, so a restart can't reset your limits.
- Wake lock, start on phone boot (Termux:Boot), and an ongoing notification with an Open button.
- Dashboard shows battery, charging and wake-lock status, with warnings when the phone is on battery or hot.
- After-hours and overnight trading start **off** on Android, because their stops are watched by the app itself.
- "Phone access" becomes "Remote access" for checking the phone's bot from another device (uses Termux's cloudflared).

## 1.8.0 — 2026-09-26
- 📱 Phone access through a Cloudflare Tunnel. You can use a Quick link (no account) or your own domain, with a QR code, and auto-connect on start.
- A login page with a password (hashed), 30-day signed sessions, and a lockout after too many wrong attempts.
- Broker keys and phone-access settings can only be changed on the computer running SekexBot.
- The dashboard fits phone screens and can be installed as an app with the SekexBot icon.
- A version number with this changelog.

## 1.7.2
- Chart read: "Analyze live chart" now uses the most recent session at night, on weekends and before the open.
- Clear error messages for the AI screenshot reader: no API credits, bad key, model not found, image too large, rate limit.
- A "Test AI key" button.

## 1.7.1
- New SekexBot logo, app icon, favicon, Windows .ico, and a desktop-shortcut helper.

## 1.7.0
- Account-size-aware stock picker. It scans about 300 stocks and scores each one for opportunity × fit (daily limit, buying power, liquidity).
- "Scan now" button and a Stock picker table with the reasons for each pick.
- Fix: volume and ATR now come from full-market SIP history instead of IEX-only volume.

## 1.6.0
- 🔑 Broker keys screen: enter, test and save Alpaca paper and live keys, a Live PIN, and a Claude key, all in the dashboard.
- Startup no longer opens Notepad.

## 1.5.1
- Renamed to SekexBot.

## 1.5.0
- BullGPT-style screenshot reader. Drop in or paste a chart and get a game plan: trend, levels, timing, scenarios, lean, and what the bot would do.
- Watchlist of tickers that are always scanned and traded in every session (SPCX added to start).

## 1.4.0
- After-hours (4–8 PM) and overnight (8 PM–4 AM) trading: long-only, limit orders, bot-managed stops, half size.
- The daily loss window runs 8 PM → 8 PM ET. The chart is built from quotes overnight.
- Fixed start_bot.bat when the Python environment was missing pip.

## 1.3.0
- Portable SD card / USB edition with a bundled runtime and self-repairing setup.

## 1.2.0
- AI chart read panel: levels, Fibonacci, RSI, VWAP, bias score, and bull and bear scenarios.

## 1.1.0
- EMA ribbon: RIBBON_FLIP strategy, ride-the-ribbon exit, ribbon trend filter, ribbon chart on the dashboard.

## 1.0.0
- First release: morning scanner, five strategies, a Thompson-sampling learner that picks setups and exits, a daily-max-loss risk manager, bracket orders, the dashboard, and the offline simulator.
