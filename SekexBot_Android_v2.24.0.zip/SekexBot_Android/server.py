"""Control server + dashboard.

    python server.py            -> real Alpaca (paper by default), dashboard at http://127.0.0.1:8010
    python server.py --sim      -> offline simulated market (no keys needed) to try the dashboard
"""
import argparse
import logging
import re
import os
import sys
from datetime import date, datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path
from zoneinfo import ZoneInfo

ap = argparse.ArgumentParser()
ap.add_argument("--sim", action="store_true", help="use the offline market simulator")
ap.add_argument("--speed", type=float, default=30, help="sim speed (sim seconds per real second)")
ap.add_argument("--sim-start", default="09:20", help="sim start time HH:MM ET (e.g. 16:30 to try after-hours)")
ap.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"))
ap.add_argument("--port", type=int, default=int(os.getenv("PORT", "8010")))
ARGS = ap.parse_args()
if ARGS.sim:
    os.environ.setdefault("AUTOBOT_DATA", str(Path(__file__).parent / "data_sim"))
elif not os.getenv("SEKEX_GUARDED"):   # (the sekex watchdog already ran the guard before starting us)
    try:        # 🤖 Fix with Claude: roll back a patch that stops the app from starting (standard library only)
        from autobot import selffix_guard as _sg
        _sg.run(Path(__file__).resolve().parent)
    except Exception as _ex:
        print("selffix guard:", _ex)

import uvicorn  # noqa: E402
import pandas as pd  # noqa: E402
from fastapi import FastAPI, Header, HTTPException, Request  # noqa: E402
import json  # noqa: E402
import threading  # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response  # noqa: E402
from pydantic import BaseModel  # noqa: E402

from autobot import db  # noqa: E402
from autobot.config import DATA_DIR, Settings, api_keys, live_pin, mask, write_env  # noqa: E402
from autobot.engine import Engine, was_running  # noqa: E402
from autobot import android  # noqa: E402
from autobot.alerts import Alerts  # noqa: E402
from autobot.watcher import Watcher  # noqa: E402
import time as time_mod  # noqa: E402
from time import sleep as time_sleep  # noqa: E402
from autobot import telemetry  # noqa: E402
from autobot.harvester import Harvester  # noqa: E402
from autobot.indicators import ribbon  # noqa: E402
from autobot.analyst import analyze, vision_read  # noqa: E402
from autobot.learner import Learner  # noqa: E402
from autobot import auth  # noqa: E402
from autobot.version import RELEASE_DATE, __version__  # noqa: E402
from autobot.tunnel import Tunnel  # noqa: E402

NY = ZoneInfo("America/New_York")
WEB = Path(__file__).parent / "web"
BASE_DIR_ = Path(__file__).parent
ASSETS = Path(__file__).parent / "assets"
TOKEN = os.getenv("DASH_TOKEN", "")

# ---- one SekexBot per data folder (v2.5.2): two copies mean two logs, two stream sockets ("connection limit exceeded")
_LOCK_FH = None


def _single_instance(data_dir, wait=10):
    """Hold an OS file lock for as long as this process lives; it is released automatically if the app dies.
    Waits a few seconds so a restart can take over from the copy that is still shutting down."""
    global _LOCK_FH
    import time as _t
    try:
        import fcntl
    except ImportError:                                  # Windows
        fcntl = None
    f = open(Path(data_dir) / ".sekex.lock", "a+")
    end = _t.time() + wait
    while True:
        try:
            if fcntl:
                fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
            else:
                import msvcrt
                f.seek(0)
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            break
        except OSError:
            if _t.time() > end:
                print("\n  SekexBot is already running on this device (same data folder). Not starting a second copy.\n"
                      "  Use the running one, or stop it first:  sekex stop\n")
                sys.exit(3)
            _t.sleep(0.5)
    try:
        f.seek(0)
        f.truncate()
        f.write(str(os.getpid()))
        f.flush()
    except Exception:
        pass
    _LOCK_FH = f


if os.getenv("SEKEX_NO_LOCK") != "1":
    _single_instance(DATA_DIR)


logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(sys.stdout),
                              RotatingFileHandler(DATA_DIR / "autobot.log", maxBytes=2_000_000, backupCount=5)],
                    force=True)             # force: never stack a second set of handlers (duplicate log lines)

settings = Settings.load()
learner = Learner()
alerts = Alerts(ARGS.port)
feed = None                     # streaming prices (autobot.stream)
from autobot.events import Events
events = Events()               # earnings calendar + news
guardian = None                 # heartbeat + backups (autobot.guardian), not in the simulator
_interest = {}                  # sym -> last time a dashboard asked for it
engine: Engine | None = None
setup_error = ""
from autobot.options import OptionsBot
options_bot = OptionsBot(lambda: engine, settings)     # separate module; does nothing until you turn it on


def _sip_ok(k, s):
    try:
        from alpaca.data.enums import DataFeed
        from alpaca.data.historical import StockHistoricalDataClient
        from alpaca.data.requests import StockLatestQuoteRequest
        StockHistoricalDataClient(k, s).get_stock_latest_quote(StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
        return True
    except Exception:
        return False


def build_engine():
    """v2.9.2: the first Alpaca calls get a 15 s limit, so a stalled connection after a restart can never keep the dashboard from opening."""
    import socket
    old_to = socket.getdefaulttimeout()
    socket.setdefaulttimeout(15)
    try:
        _build_engine()
    finally:
        socket.setdefaulttimeout(old_to)


def _build_engine():
    global engine, setup_error
    setup_error = ""
    _set_feed(None)                         # one stream at a time: close the old socket BEFORE opening a new one
    try:
        if ARGS.sim:
            from autobot.sim import SimBroker
            d = datetime.now(NY).date()
            while d.weekday() >= 5:
                d += timedelta(days=1)
            hh, mm = (int(x) for x in ARGS.sim_start.split(":"))
            broker = SimBroker(datetime(d.year, d.month, d.day, hh, mm, tzinfo=NY), speed=ARGS.speed)
            from autobot.stream import SimFeed
            _set_feed(SimFeed(broker))
        else:
            from autobot.broker import AlpacaBroker
            k, s = api_keys(settings.live)
            if settings.data_feed == "iex" and _sip_ok(k, s):       # you pay for SIP: use it (4 AM - 8 PM data)
                settings.data_feed = "sip"
                settings.save()
                logging.info("SIP data subscription detected: data feed switched to SIP")
            broker = AlpacaBroker(k, s, paper=not settings.live, feed=settings.data_feed)
            broker.account()  # validate keys now
            if settings.stream_prices:
                from autobot.stream import LiveFeed
                _set_feed(LiveFeed(k, s, settings.data_feed))
                broker.live = feed
            else:
                _set_feed(None)
        engine = Engine(settings, broker, learner)
        engine.alerts = alerts
        if not ARGS.sim:
            events.set_keys(k, s)
            engine.evfilter = events
        if ARGS.sim:
            engine.mode = "SIM"
    except Exception as e:
        engine = None
        setup_error = _friendly(e, settings.live)
        logging.error("Setup error: %s", e)


def _set_feed(f):
    global feed
    if feed is not None and feed is not f:
        feed.stop()
    feed = f


def _feed_loop():
    """Every 2 s: choose what to stream (positions first) and run the fast stop guard every 1 s."""
    import time as _t
    n = 0
    while True:
        _t.sleep(1)
        f, e = feed, engine
        if f is None or e is None:
            continue
        try:
            e.fast_guard(f)
        except Exception as ex:
            logging.debug("fast guard: %s", ex)
        n += 1
        if n % 2:
            continue
        now = _t.time()
        want = list(e.trades) + list((e.positions or {}).keys())
        want += [sym for sym, t0 in sorted(_interest.items(), key=lambda x: -x[1]) if now - t0 < 90]
        want += [w.upper() for w in settings.watchlist] + list(e.universe[:12]) + list(settings.watch_always)
        f.set_symbols(want)


def _friendly(e, live):
    acct = "LIVE" if live else "paper"
    m = str(e)
    low = m.lower()
    if "missing alpaca" in low:
        return f"No {acct} API keys yet — click 🔑 Broker keys to connect your Alpaca account."
    if "unauthorized" in low or "forbidden" in low or "401" in m or "403" in m:
        return f"Alpaca rejected the {acct} API keys — re-enter them in 🔑 Broker keys."
    if "connection" in low or "max retries" in low or "timed out" in low:
        return "Can't reach Alpaca — check your internet connection, then click Reconnect in 🔑 Broker keys."
    return m


build_engine()
import threading as _th  # noqa: E402
_th.Thread(target=_feed_loop, daemon=True, name="feed-loop").start()
watcher = Watcher(lambda: engine, alerts, settings)
if engine and not ARGS.sim and settings.auto_resume and was_running():
    logging.info("SekexBot was trading when it last shut down - resuming automatically")
    engine.start(resumed=True)
app = FastAPI(title="SekexBot", version=__version__)


PUBLIC = {"/login", "/api/login", "/api/version", "/manifest.webmanifest", "/icon.svg", "/icon-192.png", "/icon-512.png",
          "/apple-touch-icon.png", "/favicon.ico", "/sw.js", "/api/rh/callback"}   # the Robinhood callback is protected by its one-time state + PKCE
LOCAL_ONLY = ("/api/admin/", "/api/selffix/", "/api/support/", "/api/guardian/config", "/api/guardian/restore", "/api/help/fix", "/api/alerts/config", "/api/keys/save", "/api/pin/set", "/api/anthropic_key", "/api/remote/", "/api/reconnect", "/api/app/")


@app.middleware("http")
async def guard(request: Request, call_next):
    path = request.url.path
    if not auth.is_remote(request):
        # Anti-CSRF / DNS-rebinding: a web page open in the phone's browser must not be able to press buttons here.
        hostname = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if hostname not in ("127.0.0.1", "localhost", "::1", ""):
            return JSONResponse({"detail": "blocked: unexpected Host header"}, status_code=403)
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("origin")
            site = request.headers.get("sec-fetch-site")
            if origin and origin != "null":
                from urllib.parse import urlparse
                if (urlparse(origin).hostname or "").lower() not in ("127.0.0.1", "localhost", "::1"):
                    return JSONResponse({"detail": "blocked: cross-site request"}, status_code=403)
            elif origin == "null" or site in ("cross-site", "same-site"):
                return JSONResponse({"detail": "blocked: cross-site request"}, status_code=403)
    if TOKEN and path.startswith("/api") and path not in PUBLIC and not auth.is_remote(request):
        if request.headers.get("x-token") != TOKEN and request.query_params.get("token") != TOKEN:
            return JSONResponse({"detail": "unauthorized"}, status_code=401)
    if auth.is_remote(request) and path not in PUBLIC:
        if not auth.password_set():
            return HTMLResponse("<h3>Remote access is off: set a dashboard password on the device running SekexBot first.</h3>", 403)
        if not auth.valid_session(request.cookies.get(auth.COOKIE)):
            if path.startswith("/api"):
                return JSONResponse({"detail": "Please log in"}, status_code=401)
            return RedirectResponse("/login")
        if any(path.startswith(x) for x in LOCAL_ONLY):
            return JSONResponse({"detail": "For safety, keys and remote-access settings can only be changed "
                                           "on the device running SekexBot."}, status_code=403)
    resp = await call_next(request)
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    return resp


def clean(o):
    """Make numpy scalars JSON-safe."""
    import numpy as np
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.generic):
        return o.item()
    return o


def pin_ok(p) -> bool:
    """Live PIN check that forgives what phone keyboards do (a trailing space or newline added by autocomplete)."""
    import hmac
    a, b = (p or "").strip(), (live_pin() or "").strip()
    return bool(b) and hmac.compare_digest(a.encode(), b.encode())


def need_engine() -> Engine:
    if engine is None:
        raise HTTPException(400, setup_error or "Engine not ready")
    return engine


@app.get("/")
def index():
    return FileResponse(WEB / "dashboard.html", headers={"Cache-Control": "no-store"})


# ---------------- phone / remote access ----------------
tunnel = Tunnel(ARGS.port)


from autobot.signalaudit import Reviewer  # noqa: E402
reviewer = Reviewer()


class ReviewReq(BaseModel):
    question: str = ""
    symbol: str = ""


class TuneReq(BaseModel):
    tune: dict = {}


@app.post("/api/review/start")
def review_start(r: ReviewReq):
    e = need_engine()
    syms = [w.upper() for w in settings.watchlist]
    if r.symbol:
        syms.insert(0, _valid_sym(r.symbol))
    cut = (e.broker.now().date() - timedelta(days=5)).isoformat() if hasattr(e.broker, "now") else ""
    syms += [t["symbol"] for t in db.recent(300) if (t.get("day") or "") >= cut]
    syms = list(dict.fromkeys(s for s in syms if s))
    if not syms:
        raise HTTPException(400, "Add a few stocks to your watchlist first, so there is something to review.")
    try:
        return {"ok": True, "job": reviewer.start(e, r.question, syms)}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.get("/api/review/status")
def review_status():
    from autobot.predict import DEFAULTS, get_tune
    return clean({"job": reviewer.status(), "tune": get_tune(), "defaults": DEFAULTS})


@app.post("/api/review/tune")
def review_tune(r: TuneReq):
    """Apply early-warning settings (only the BUY?/SELL? warnings and their alerts; never how the bot trades)."""
    from autobot.predict import DEFAULTS, save_tune
    t = save_tune(r.tune or DEFAULTS)
    _wl_pred["at"] = 0                      # refresh the watchlist warnings now
    if engine:
        engine.event(f"📊 Early-warning settings: {t}")
    return {"ok": True, "tune": t}


class BannerReq(BaseModel):
    text: str = ""
    color: str = ""
    size: str = "m"
    show: bool = True
    code: str = ""


class BannerLock(BaseModel):
    code: str = ""
    new_code: str = ""


def _banner_read():
    import json
    try:
        return json.loads((DATA_DIR / "banner.json").read_text())
    except Exception:
        return {"text": "", "color": "", "size": "m", "show": True}


def _banner_ok(b, code, request):
    import hashlib
    h = b.get("lock")
    if not h:
        return
    ip = "banner:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong passcodes. Wait 15 minutes.")
    if hashlib.sha256(("sekex-banner:" + (code or "")).encode()).hexdigest() != h:
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong passcode for the header message")


@app.post("/api/banner/lock")
def banner_lock(r: BannerLock, request: Request):
    import hashlib
    import json
    b = _banner_read()
    _banner_ok(b, r.code, request)
    if r.new_code and len(r.new_code) < 4:
        raise HTTPException(400, "Use at least 4 characters")
    if r.new_code:
        b["lock"] = hashlib.sha256(("sekex-banner:" + r.new_code).encode()).hexdigest()
    else:
        b.pop("lock", None)
    (DATA_DIR / "banner.json").write_text(json.dumps(b))
    return {"ok": True, "locked": bool(r.new_code)}


@app.get("/api/banner")
def banner_get():
    b = _banner_read()
    return {k: v for k, v in b.items() if k != "lock"} | {"locked": bool(b.get("lock"))}


@app.post("/api/banner")
def banner_set(r: BannerReq, request: Request):
    """Your own message shown big in the header. Plain text only (shown with textContent, never as HTML)."""
    import json
    import re
    color = r.color.strip() if re.fullmatch(r"#[0-9a-fA-F]{3,8}", r.color.strip() or "") else ""
    old = _banner_read()
    _banner_ok(old, r.code, request)
    b = {"text": r.text.strip()[:120], "color": color, "size": r.size if r.size in ("s", "m", "l") else "m", "show": bool(r.show)}
    if old.get("lock"):
        b["lock"] = old["lock"]
    (DATA_DIR / "banner.json").write_text(json.dumps(b))
    return {k: v for k, v in b.items() if k != "lock"} | {"locked": bool(b.get("lock"))}


@app.get("/api/version")
def version():
    return {"version": __version__, "release_date": RELEASE_DATE}


@app.get("/login")
def login_page():
    return FileResponse(WEB / "login.html")


class LoginReq(BaseModel):
    password: str


@app.post("/api/login")
def login(r: LoginReq, request: Request):
    ip = auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many attempts. Wait 15 minutes.")
    if not auth.password_set() or not auth.check_password(r.password):
        auth.record_fail(ip)
        raise HTTPException(401, "Wrong password")
    logging.info("Remote login from %s", ip)
    resp = JSONResponse({"ok": True})
    resp.set_cookie(auth.COOKIE, auth.make_session(), max_age=auth.SESSION_DAYS * 86400, httponly=True,
                    secure=request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
                    or bool(request.headers.get("cf-ray")), samesite="lax")
    return resp


@app.post("/api/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE)
    return resp


@app.get("/manifest.webmanifest")
def manifest():
    return JSONResponse({"name": "SekexBot", "short_name": "SekexBot", "id": "/", "start_url": "/", "scope": "/", "display": "standalone",
                         "description": "SekexBot auto-trader dashboard", "background_color": "#07090c", "theme_color": "#07090c",
                         "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
                                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
                                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
                                   {"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]},
                        media_type="application/manifest+json")


_SW = """self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
const OFFLINE = '<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="background:#07090c;color:#e6edf3;font-family:system-ui;text-align:center;padding:40px 20px"><div style="font-size:48px">🔌</div><h2>SekexBot is off</h2><p style="color:#8b98a5">Start it with the <b>SekexBot</b> icon (Termux:Widget), or open Termux and type <b>sekex start</b>. Then tap Retry.</p><p><button style="font-size:18px;padding:12px 28px;border-radius:10px;border:0;background:#2563eb;color:#fff" onclick="location.reload()">Retry</button></p></body>';
self.addEventListener('fetch', e => {
  if (e.request.mode === 'navigate') e.respondWith(fetch(e.request).catch(() => new Response(OFFLINE, {headers: {'Content-Type': 'text/html; charset=utf-8'}})));
});
"""


@app.get("/sw.js")
def service_worker():
    return Response(_SW, media_type="application/javascript", headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})


@app.get("/icon.svg")
def icon_svg():
    return FileResponse(ASSETS / "sekexbot-icon.svg", media_type="image/svg+xml")


@app.get("/icon-192.png")
def icon192():
    return FileResponse(ASSETS / "icon-192.png")


@app.get("/icon-512.png")
def icon512():
    return FileResponse(ASSETS / "icon-512.png")


@app.get("/apple-touch-icon.png")
def apple_icon():
    return FileResponse(ASSETS / "icon-180.png")


@app.get("/api/remote/status")
def remote_status():
    st = tunnel.status()
    st.update({"password_set": auth.password_set(), "token_saved": bool(os.getenv("CF_TUNNEL_TOKEN")),
               "hostname": os.getenv("CF_HOSTNAME", ""), "autostart": os.getenv("REMOTE_AUTOSTART", "") == "1"})
    return st


class PwReq(BaseModel):
    password: str


@app.post("/api/remote/password")
def remote_password(r: PwReq):
    if len(r.password) < 8:
        raise HTTPException(400, "Use at least 8 characters")
    auth.set_password(r.password)
    return {"ok": True}


class TunnelReq(BaseModel):
    mode: str = "quick"          # quick | token
    token: str = ""
    hostname: str = ""
    autostart: bool | None = None


@app.post("/api/remote/start")
def remote_start(r: TunnelReq):
    if not auth.password_set():
        raise HTTPException(400, "Set a dashboard password first — anyone with the link would otherwise control your bot.")
    vals = {}
    if r.mode == "token":
        tok = r.token.strip() or os.getenv("CF_TUNNEL_TOKEN", "")
        tok = tok.split("--token")[-1].strip().split()[-1] if tok else ""    # accept the whole install command too
        import re as _re
        if _re.fullmatch(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", tok):
            raise HTTPException(400, "That short code is the tunnel's ID, not its token. The token is a much longer text that starts with 'eyJ'. In Cloudflare open your tunnel, tap Edit or Overview, choose 'Cloudflared', and copy the whole install command (it contains the token), then paste that here.")
        if len(tok) < 50:
            raise HTTPException(400, "Paste the tunnel token (or the whole 'cloudflared service install ...' command).")
        host = r.hostname.strip().replace("https://", "").strip("/") or os.getenv("CF_HOSTNAME", "")
        vals.update({"CF_TUNNEL_TOKEN": tok, "CF_HOSTNAME": host})
    if r.autostart is not None:
        vals["REMOTE_AUTOSTART"] = "1" if r.autostart else "0"
        vals["REMOTE_MODE"] = r.mode
    if vals:
        write_env(vals)
    tunnel.start(r.mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))
    return {"ok": True}


@app.post("/api/remote/stop")
def remote_stop():
    tunnel.stop()
    return {"ok": True}


@app.get("/api/qr")
def qr(url: str):
    import qrcode
    import qrcode.image.svg
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    return Response(img.to_string(), media_type="image/svg+xml")


@app.on_event("startup")
def _autostart_tunnel():
    if os.getenv("REMOTE_AUTOSTART") == "1" and auth.password_set():
        mode = os.getenv("REMOTE_MODE", "token" if os.getenv("CF_TUNNEL_TOKEN") else "quick")
        tunnel.start(mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))


@app.on_event("shutdown")
def _stop_tunnel():
    tunnel.stop()
    def _force():        # v2.9.2: a stuck background thread or open connection must never keep the old copy (and its lock) alive
        import time as _t2
        _t2.sleep(6)
        os._exit(0)
    threading.Thread(target=_force, daemon=True, name="force-exit").start()


@app.get("/api/status")
def status(request: Request):
    base = {"version": __version__, "release_date": RELEASE_DATE, "settings": {"daily_max_loss": settings.daily_max_loss, "loss_paper": settings.loss_paper, "loss_live": settings.loss_live, "live": settings.live,
                         "level": settings.level, "level_auto": settings.level_auto, "level_active": settings.level_active, "level_preset": settings.level_preset, "ui_mode": settings.ui_mode, "onboard": settings.onboard, "onboard_hidden": settings.onboard_hidden,
                         "allow_shorts": settings.allow_shorts, "short_from_7am": settings.short_from_7am, "shorts_24_5": settings.shorts_24_5, "trade_all_flips": settings.trade_all_flips, "auto_study": settings.auto_study, "max_trade_notional": settings.max_trade_notional, "auto_tune": settings.auto_tune, "session_tune": settings.session_tune, "let_run": settings.let_run, "proven_only": settings.proven_only, "auto_direction": settings.auto_direction, "auto_short": settings.auto_short, "auto_mode": settings.auto_mode, "reentry": settings.reentry, "pct_harvest": settings.pct_harvest, "pm_trend": settings.pm_trend, "harvest_stop": settings.harvest_stop, "etf_pair_guard": settings.etf_pair_guard, "regime_filter": settings.regime_filter, "fractional_on": settings.fractional_on, "green_guard": settings.green_guard, "morning_trend": settings.morning_trend, "stocks_on": settings.stocks_on, "options_on": settings.options_on, "options_style": settings.options_style, "options_max_premium": settings.options_max_premium, "options_max_positions": settings.options_max_positions, "options_max_contracts": settings.options_max_contracts, "options_max_stocks": settings.options_max_stocks, "options_max_per_stock": settings.options_max_per_stock, "options_max_calls": settings.options_max_calls, "options_max_puts": settings.options_max_puts, "options_min_delta": settings.options_min_delta, "options_tp_pct": settings.options_tp_pct, "options_stop_pct": settings.options_stop_pct, "options_underlyings": settings.options_underlyings, "strategy_breaker": settings.strategy_breaker, "max_spread_trend_pct": settings.max_spread_trend_pct, "max_position_pct_equity": settings.max_position_pct_equity, "share_diagnostics": settings.share_diagnostics, "share_trade_logs": settings.share_trade_logs, "diag_label": settings.diag_label, "diag_asked": settings.diag_asked, "collector_set": bool(telemetry.collector_url(settings)), "max_spread_pct": settings.max_spread_pct, "guard_manual": settings.guard_manual, "guard_loss_pct": settings.guard_loss_pct, "guard_flip_max": settings.guard_flip_max, "guard_flip_harvest": settings.guard_flip_harvest, "pct_harvest_auto": settings.pct_harvest_auto, "harvest_learn": settings.harvest_learn, "auto_harvest_manual": settings.auto_harvest_manual, "pct_harvest_pct": settings.pct_harvest_pct, "pre_plan": settings.pre_plan, "morning_reversal": settings.morning_reversal, "preclose_short": settings.preclose_short, "auto_prep": settings.auto_prep, "data_feed": settings.data_feed,
                         "ext_premarket": settings.ext_premarket, "ext_afterhours": settings.ext_afterhours,
                         "ext_overnight": settings.ext_overnight, "watchlist": settings.watchlist,
                         "auto_resume": settings.auto_resume, "stream_prices": settings.stream_prices,
                         "scale_out": settings.scale_out, "tod_filter": settings.tod_filter, "scalp_mode": settings.scalp_mode,
                         "aggressive_scalp": settings.aggressive_scalp,
                         "cooloff_streak": settings.cooloff_streak, "cooloff_symbol": settings.cooloff_symbol,
                         "confirm_trades": settings.confirm_trades},
            "ai_key_set": bool(_ai_key()), "ai_provider": _ai_provider(),
            "remote": auth.is_remote(request), "tunnel": {"state": tunnel.state, "url": tunnel.url},
            "sim": ARGS.sim, "setup_error": setup_error, "edition": android.EDITION,
            "device": android.health(), "update": _upd["info"], "update_prefs": _upd_prefs(),
            "stream": feed.info() if feed else {"status": "off", "error": "", "symbols": 0, "updates": 0}, "live_pin_set": bool(live_pin()),
            "leaderboard": learner.leaderboard()}
    if engine:
        engine.refresh_account(max_age=20)
        base.update(engine.status())
    return clean(base)


@app.post("/api/start")
def start():
    need_engine().start()
    return {"ok": True}


class StopReq(BaseModel):
    flatten: bool = False


@app.post("/api/stop")
def stop(r: StopReq):
    need_engine().stop(flatten=r.flatten)
    return {"ok": True}


@app.post("/api/scan")
def scan_now():
    e = need_engine()
    e._scan()
    try:
        e.refresh_setups()
    except Exception as ex:
        logging.warning("setups: %s", ex)
    return {"ok": True, "count": len(e.scan_info), "setups": len(getattr(e, "setups", []))}


@app.post("/api/cooloff/clear")
def cooloff_clear():
    need_engine().end_cooloff()
    return {"ok": True}


@app.post("/api/flatten")
def flatten():
    e = need_engine()
    e.flatten("manual flatten")
    e.event("Manual flatten of bot positions")
    return {"ok": True}


class LimitReq(BaseModel):
    daily_max_loss: float
    mode: str = ""          # "paper" | "live" | "" (= the mode you are in now)


@app.post("/api/limit")
def set_limit(r: LimitReq):
    if r.daily_max_loss <= 0:
        raise HTTPException(400, "Daily limit must be > 0")
    want_live = settings.live if r.mode not in ("paper", "live") else (r.mode == "live")
    if want_live == bool(settings.live):
        settings.daily_max_loss = float(r.daily_max_loss)
        settings.remember_limit()
    elif want_live:
        settings.loss_live = float(r.daily_max_loss)          # the other mode: stored only, active limit untouched
    else:
        settings.loss_paper = float(r.daily_max_loss)
    if "limit" not in settings.onboard:
        settings.onboard = list(settings.onboard) + ["limit"]
    settings.save()
    if engine:
        engine.event(f"Daily max loss ({'LIVE' if want_live else 'PAPER'}) set to ${float(r.daily_max_loss):,.2f}")
        rk = engine.risk
        if rk.halted and rk.halt_reason.startswith("Daily max loss") and rk.day_pnl > -settings.daily_max_loss:
            rk.halted, rk.halt_reason = False, ""
            engine.event("Halt cleared: today's loss is inside the new daily limit")
    return {"ok": True}


class DayResetReq(BaseModel):
    pin: str = ""


class OptionsCfg(BaseModel):
    on: bool | None = None
    style: str | None = None
    daily_budget: float | None = None
    max_premium: float | None = None
    max_contracts: int | None = None
    max_positions: int | None = None
    max_stocks: int | None = None
    max_per_stock: int | None = None
    max_calls: int | None = None
    max_puts: int | None = None
    min_delta: float | None = None
    tp_pct: float | None = None
    stop_pct: float | None = None
    underlyings: str | None = None
    pin: str = ""


@app.get("/api/options/status")
def options_status():
    return options_bot.status()


@app.post("/api/options/config")
def options_config(r: OptionsCfg, request: Request):
    """Turn the options module on/off and set its own limits. Turning it ON while on a LIVE account needs the PIN."""
    if r.on is True and settings.live:
        if not settings.options_live_unlocked:
            raise HTTPException(403, "Options are locked on LIVE. Unlock them first (Unlock for Live).")
    if r.on is not None:
        settings.options_on = bool(r.on)
        options_bot.halted = "" if r.on else options_bot.halted
        options_bot.ev("options module turned " + ("ON" if r.on else "OFF (open positions are still managed to exit)"), "warning")
    if r.style in ("spread", "long"):
        settings.options_style = r.style
        options_bot.style_override = ""
    for k, lo, hi in (("daily_budget", 10, 100000), ("max_premium", 10, 50000), ("tp_pct", 10, 500), ("stop_pct", 10, 90)):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, "options_" + k, float(min(hi, max(lo, v))))
    if r.max_contracts is not None:
        settings.options_max_contracts = int(min(20, max(1, r.max_contracts)))
    if r.max_positions is not None:
        settings.options_max_positions = int(min(6, max(1, r.max_positions)))
    for k, hi in (("max_stocks", 15), ("max_per_stock", 4), ("max_calls", 6), ("max_puts", 6)):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, "options_" + k, int(min(hi, max(1, v))))
    if r.min_delta is not None:
        settings.options_min_delta = float(min(0.9, max(0.0, r.min_delta)))
    if r.underlyings is not None:
        syms = [x.strip().upper() for x in r.underlyings.replace(";", ",").split(",") if x.strip().replace(".", "").isalpha()][:15]
        if syms:
            settings.options_underlyings = syms
    settings.save()
    return options_bot.status()


class OptionsUnlock(BaseModel):
    pin: str = ""
    unlock: bool = True


@app.post("/api/options/live_unlock")
def options_live_unlock(r: OptionsUnlock, request: Request):
    """Allow (or forbid) the options module to trade on a LIVE account. Needs the Live PIN."""
    ip = "pin:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    if not live_pin():
        raise HTTPException(403, "Set a Live PIN first (Settings).")
    if not pin_ok(r.pin):
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong PIN")
    settings.options_live_unlocked = bool(r.unlock)
    if not r.unlock:
        settings.options_on = False
    settings.save()
    options_bot.ev("options " + ("UNLOCKED for LIVE" if r.unlock else "locked for LIVE again"), "warning")
    return options_bot.status()


@app.post("/api/options/close_all")
def options_close_all():
    options_bot.close_all()
    return options_bot.status()


# ---------------- 🧩 Options Hub: manual single-contract tickets ----------------
def _hub_clients(e):
    return options_bot._clients(e)


def _hub_snaps(e, syms):
    from alpaca.data.requests import OptionSnapshotRequest
    _, dc = _hub_clients(e)
    out = {}
    if not syms:
        return out
    for sym, sn in (dc.get_option_snapshot(OptionSnapshotRequest(symbol_or_symbols=list(syms))) or {}).items():
        q = getattr(sn, "latest_quote", None)
        g = getattr(sn, "greeks", None)
        f = lambda x: None if x is None else float(x)
        out[sym] = {"bid": f(getattr(q, "bid_price", None)), "ask": f(getattr(q, "ask_price", None)),
                    "delta": f(getattr(g, "delta", None)), "iv": f(getattr(sn, "implied_volatility", None))}
    return out


@app.get("/api/ohub/chain")
def ohub_chain(sym: str, kind: str = "call", expiry: str = ""):
    from datetime import timedelta as _td
    from alpaca.trading.enums import AssetStatus, ContractType
    from alpaca.trading.requests import GetOptionContractsRequest
    from autobot import optionshub as oh
    e = need_engine()
    sym = _valid_sym(sym)
    kind = "put" if kind == "put" else "call"
    bid, ask = _quote(e, sym, _session_name(e))
    spot = (bid + ask) / 2 if bid and ask else 0.0
    if not spot:
        try:
            spot = float((e.broker.price_info(sym) or {}).get("last") or 0)
        except Exception:
            spot = 0.0
    if not spot:
        raise HTTPException(404, f"No price for {sym} right now.")
    today = e.broker.now().date()
    tr, _ = _hub_clients(e)
    try:
        res = tr.get_option_contracts(GetOptionContractsRequest(
            underlying_symbols=[sym], status=AssetStatus.ACTIVE, type=ContractType.CALL if kind == "call" else ContractType.PUT,
            expiration_date_gte=today, expiration_date_lte=today + _td(days=150),
            strike_price_gte=str(round(spot * 0.75, 2)), strike_price_lte=str(round(spot * 1.25, 2)), limit=1000))
    except Exception as ex:
        raise HTTPException(502, "Could not load the option chain: " + str(ex)[:140])
    by = {}
    for c in (getattr(res, "option_contracts", None) or []):
        if getattr(c, "tradable", True):
            by.setdefault(str(c.expiration_date), []).append({"symbol": c.symbol, "strike": float(c.strike_price),
                                                              "oi": int(float(getattr(c, "open_interest", 0) or 0))})
    if not by:
        raise HTTPException(404, f"{sym} has no tradable options (not every stock does).")
    exps = sorted(by)[:14]
    pick = expiry if expiry in by else next((x for x in exps if (date.fromisoformat(x) - today).days >= 7), exps[0])
    rows = oh.rows_for(kind, spot, by[pick], _hub_snaps(e, [c["symbol"] for c in sorted(by[pick], key=lambda c: abs(c["strike"] - spot))[:16]]))
    try:
        lvl = options_bot._account_level(e)
    except Exception:
        lvl = None
    return clean({"symbol": sym, "kind": kind, "price": round(spot, 2), "expiry": pick, "dte": (date.fromisoformat(pick) - today).days,
                  "expiries": [{"d": x, "dte": (date.fromisoformat(x) - today).days} for x in exps], "rows": rows, "level": lvl,
                  "mode": e.mode, "locked": bool(e.mode == "LIVE" and not settings.options_live_unlocked), "open": _session_name(e) == "REGULAR"})


@app.get("/api/ohub/payoff")
def ohub_payoff(kind: str, strike: float, premium: float, spot: float):
    from autobot import optionshub as oh
    return oh.payoff("put" if kind == "put" else "call", strike, premium, spot)


@app.get("/api/ohub/book")
def ohub_book():
    """Option contracts you hold (any source), so Sell can close them."""
    from autobot import optionshub as oh
    e = need_engine()
    try:
        held = options_bot.held(e)
    except Exception:
        held = {}
    out = []
    for k, v in held.items():
        c = oh.parse_occ(k) or {}
        out.append({"symbol": k, **v, "underlying": c.get("underlying", ""), "kind": c.get("kind", ""), "strike": c.get("strike"), "expiry": str(c.get("expiry", ""))})
    return clean({"held": out})


class HubOrder(BaseModel):
    symbol: str
    side: str = "buy"
    qty: int = 1
    limit_price: float = 0
    confirm: bool = False
    pin: str = ""


@app.post("/api/ohub/order")
def ohub_order(r: HubOrder, request: Request):
    from alpaca.trading.enums import OrderSide, PositionIntent, TimeInForce
    from alpaca.trading.requests import LimitOrderRequest
    from autobot import optionshub as oh
    e = need_engine()
    c = oh.parse_occ(r.symbol)
    if not c:
        raise HTTPException(400, "That is not an option contract symbol.")
    side = r.side.lower()
    live = e.mode == "LIVE"
    if live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    ok_pin = bool(live_pin()) and pin_ok(r.pin) if live else True
    if live and r.pin and not ok_pin:
        auth.record_fail("pin:" + auth.client_ip(request))
    try:
        held = options_bot.held(e).get(r.symbol, {}).get("qty", 0.0)
    except Exception:
        held = 0.0
    try:
        acct = e.broker.trading.get_account()
        bp = float(getattr(acct, "options_buying_power", None) or getattr(acct, "buying_power", 0) or 0)
    except Exception:
        bp = None
    managed = any(p.get("long") == r.symbol or p.get("short") == r.symbol for p in options_bot.pos.values() if p.get("status") in ("open", "entering", "exiting"))
    try:
        lvl = options_bot._account_level(e)
    except Exception:
        lvl = None
    err = oh.check_order(side=side, qty=r.qty, limit=r.limit_price, held_qty=held, bp=bp, level=lvl, market_open=_session_name(e) == "REGULAR",
                         halted=bool(e.risk.halted), live=live, live_unlocked=bool(settings.options_live_unlocked), pin_given_ok=ok_pin,
                         confirm=r.confirm, managed_by_bot=managed)
    if err:
        raise HTTPException(400, err)
    px = round(float(r.limit_price), 2)
    try:
        o = e.broker.trading.submit_order(LimitOrderRequest(
            symbol=r.symbol, qty=int(r.qty), side=OrderSide.BUY if side == "buy" else OrderSide.SELL, time_in_force=TimeInForce.DAY,
            limit_price=px, position_intent=PositionIntent.BUY_TO_OPEN if side == "buy" else PositionIntent.SELL_TO_CLOSE))
    except Exception as ex:
        raise HTTPException(502, "Alpaca refused the order: " + str(ex)[:160])
    options_bot.ev(f"HUB {side.upper()} {c['underlying']} {c['kind']} {c['strike']:g} exp {c['expiry']} x{r.qty} limit ${px:.2f} (manual)", "warning")
    return {"ok": True, "order_id": str(getattr(o, "id", "")), "limit": px, "cost": round(px * oh.MULT * r.qty, 2),
            "message": f"{'Bought' if side == 'buy' else 'Selling'} {r.qty} contract(s) at a limit of ${px:.2f}. It is a day order and fills only if the price reaches your limit."}


@app.get("/api/options/journal")
def options_journal(limit: int = 200):
    """The options module's own journal (options.db): closed and cancelled trades plus a summary."""
    rows = db.opt_all(min(max(int(limit), 1), 2000))
    return {"rows": rows, "summary": db.opt_summary(rows)}


@app.get("/api/options/journal.csv")
def options_journal_csv():
    import csv as _csv
    import io as _io
    rows = db.opt_all(5000)
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(db.OPT_COLS)
    for r in rows:
        w.writerow([r.get(k, "") for k in db.OPT_COLS])
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=sekexbot_options_journal.csv"})


@app.post("/api/day/reset")
def day_reset(r: DayResetReq, request: Request):
    """Start today's P&L (and the daily loss budget) again from the account's equity right now. LIVE needs the PIN."""
    if not engine:
        raise HTTPException(400, "Engine not running")
    if settings.live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin() or not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
    try:
        return {"ok": True, **engine.reset_day_baseline()}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.post("/api/halt/clear")
def clear_halt():
    if not engine:
        raise HTTPException(400, "Engine not running")
    rk = engine.risk
    was = rk.halted
    rk.halted, rk.halt_reason = False, ""
    engine.event("Halt cleared manually - will halt again if the daily limit is hit")
    return {"ok": True, "was_halted": was}


class OptsReq(BaseModel):
    allow_shorts: bool | None = None
    stocks_on: bool | None = None
    short_from_7am: bool | None = None
    shorts_24_5: bool | None = None
    pct_harvest: bool | None = None
    pm_trend: bool | None = None
    harvest_stop: bool | None = None
    etf_pair_guard: bool | None = None
    regime_filter: bool | None = None
    strategy_breaker: bool | None = None
    fractional_on: bool | None = None
    green_guard: bool | None = None
    morning_trend: bool | None = None
    max_spread_trend_pct: float | None = None
    max_position_pct_equity: float | None = None
    max_trade_notional: float | None = None
    max_spread_pct: float | None = None
    guard_manual: str | None = None
    guard_loss_pct: float | None = None
    guard_flip_max: int | None = None
    guard_flip_harvest: bool | None = None
    pct_harvest_auto: bool | None = None
    harvest_learn: bool | None = None
    auto_harvest_manual: bool | None = None
    pct_harvest_pct: float | None = None
    data_feed: str | None = None
    ext_premarket: bool | None = None
    ext_afterhours: bool | None = None
    ext_overnight: bool | None = None
    auto_resume: bool | None = None
    stream_prices: bool | None = None
    scale_out: bool | None = None
    tod_filter: bool | None = None
    scalp_mode: bool | None = None
    aggressive_scalp: bool | None = None
    cooloff_streak: bool | None = None
    cooloff_symbol: bool | None = None
    confirm_trades: bool | None = None
    trade_all_flips: bool | None = None
    auto_prep: bool | None = None
    auto_study: bool | None = None
    auto_tune: bool | None = None
    let_run: bool | None = None
    proven_only: bool | None = None
    auto_direction: bool | None = None
    morning_reversal: bool | None = None
    pre_plan: bool | None = None
    reentry: bool | None = None
    preclose_short: bool | None = None


class LevelReq(BaseModel):
    level: str                      # conservative / balanced / aggressive / max / auto


class UiModeReq(BaseModel):
    mode: str


@app.post("/api/uimode")
def set_uimode(r: UiModeReq):
    """Which screens to show: rookie / trader / advanced. Never touches the daily loss limit or paper/live."""
    m = r.mode.strip().lower()
    if m not in ("rookie", "trader", "advanced"):
        raise HTTPException(400, "unknown mode")
    first = settings.ui_mode == ""
    settings.ui_mode = m
    if m == "rookie" and first:                       # new rookies also get the Rookie trading level
        from autobot.levels import apply_level
        settings.level, settings.level_auto, settings.level_active, settings.level_preset = "rookie", False, "", ""
        apply_level(settings, "rookie")
        if "level" not in settings.onboard:
            settings.onboard = list(settings.onboard) + ["level"]
    settings.save()
    return {"ok": True, "ui_mode": m}


@app.post("/api/level")
def set_level(r: LevelReq):
    from autobot.levels import LEVELS, apply_level
    name = r.level.lower()
    if name == "auto":
        settings.level, settings.level_auto = "auto", True
        if engine:
            engine._level_key = None                  # choose for the current session on the next tick
    elif name in LEVELS:
        settings.level, settings.level_auto, settings.level_active, settings.level_preset = name, False, "", ""
        apply_level(settings, name)
        if "level" not in settings.onboard:
            settings.onboard = list(settings.onboard) + ["level"]
    else:
        raise HTTPException(400, "unknown level")
    settings.save()
    return {"ok": True, "level": settings.level}


PRESET_FILE = DATA_DIR / "level_presets.json"
PRESET_KEYS = ["auto_direction", "allow_shorts", "trade_all_flips", "scalp_mode", "aggressive_scalp", "tod_filter", "cooloff_streak", "cooloff_symbol",
               "scale_out", "ext_risk_mult", "max_positions", "risk_per_trade_frac", "ext_premarket", "ext_afterhours",
               "reentry", "pct_harvest"]   # never the daily loss limit

# ready-made presets that ship with the app (they never touch the daily loss limit)
BUILTIN_PRESETS = {
    "Fewer, bigger trades": {            # v2.7.2: about a third of the trades, each risking about 1.5x more of the daily limit
        "auto_direction": True, "allow_shorts": True, "trade_all_flips": False, "scalp_mode": False, "aggressive_scalp": False,
        "tod_filter": True, "cooloff_streak": True, "cooloff_symbol": True, "scale_out": True, "ext_risk_mult": 0.5,
        "max_positions": 2, "risk_per_trade_frac": 0.30, "ext_premarket": False, "ext_afterhours": False,
        "reentry": False, "pct_harvest": False},
}


def _presets():
    try:
        d = json.loads(PRESET_FILE.read_text())
    except Exception:
        d = {}
    for k, v in BUILTIN_PRESETS.items():
        d.setdefault(k, dict(v))
    return d


# ---- v2.8.0: preset offers from support (tap-to-apply, whitelist only) ----
from autobot import offers as _offers
OFFER_FILE = DATA_DIR / "preset_offer.json"


def _offer_load():
    try:
        return json.loads(OFFER_FILE.read_text())
    except Exception:
        return {}


def _offer_save(o):
    OFFER_FILE.write_text(json.dumps(o))


def _offer_in(raw):
    """Called by the diagnostics check-in with whatever the collector holds (or None)."""
    cur = _offer_load()
    if not raw:
        if cur.get("state") == "new" or cur.get("state") == "seen":
            _offer_save({})                      # support withdrew it
        return
    c = _offers.sanitize(raw)
    if not c:
        return
    if cur.get("id") == c["id"]:
        return                                   # already known (new/seen/applied/declined)
    _offer_save({**c, "state": "new", "ts": int(time_mod.time())})


def _offer_view():
    o = _offer_load()
    if not o or o.get("state") not in ("new", "seen"):
        return None
    cur = {k: getattr(settings, k, None) for k in _offers.RULES}
    return {"id": o["id"], "name": o["name"], "reason": o.get("reason", ""), "changes": _offers.diff(o, cur),
            "keeps_limit": True}


class PresetReq(BaseModel):
    name: str
    action: str = "save"             # save | apply | delete


@app.get("/api/offer")
def offer_get():
    v = _offer_view()
    o = _offer_load()
    if v and o.get("state") == "new":
        o["state"] = "seen"
        _offer_save(o)
        threading.Thread(target=diag.ack_offer, args=(o["id"], "seen"), daemon=True).start()
    return {"offer": v}


class OfferAns(BaseModel):
    id: str
    action: str                                  # apply | decline


@app.post("/api/offer/answer")
def offer_answer(r: OfferAns):
    o = _offer_load()
    if not o or o.get("id") != r.id or o.get("state") not in ("new", "seen"):
        raise HTTPException(404, "That suggestion is no longer available")
    if r.action == "apply":
        clean = _offers.sanitize(o)               # vet again at the moment of applying
        if not clean:
            raise HTTPException(400, "Suggestion rejected")
        d = _presets()
        if clean["name"] not in d and len(d) >= 12:
            raise HTTPException(400, "Up to 12 presets. Delete one first.")
        d[clean["name"]] = {k: getattr(settings, k) for k in PRESET_KEYS}      # keep the user's own values for anything not sent
        d[clean["name"]].update({k: v for k, v in clean["settings"].items() if k in PRESET_KEYS})
        PRESET_FILE.write_text(json.dumps(d))
        for k, v in clean["settings"].items():
            if k in PRESET_KEYS:
                setattr(settings, k, v)
        settings.level, settings.level_auto, settings.level_preset = "custom", False, clean["name"]
        settings.save()
        o["state"] = "applied"
    elif r.action == "decline":
        o["state"] = "declined"
    else:
        raise HTTPException(400, "unknown action")
    _offer_save(o)
    threading.Thread(target=diag.ack_offer, args=(o["id"], o["state"]), daemon=True).start()
    return {"ok": True, "state": o["state"], "active": settings.level_preset}


@app.get("/api/level/presets")
def level_presets():
    return {"presets": sorted(_presets()), "active": settings.level_preset}


@app.post("/api/level/preset")
def level_preset(r: PresetReq):
    name = re.sub(r"\s+", " ", (r.name or "").strip())[:24]
    if not name:
        raise HTTPException(400, "Give the preset a name")
    d = _presets()
    if r.action == "save":
        if name not in d and len(d) >= 12:
            raise HTTPException(400, "Up to 12 presets. Delete one first.")
        d[name] = {k: getattr(settings, k) for k in PRESET_KEYS}
        PRESET_FILE.write_text(json.dumps(d))
        settings.level, settings.level_auto, settings.level_preset = "custom", False, name
        settings.save()
    elif r.action == "apply":
        if name not in d:
            raise HTTPException(404, "No such preset")
        for k, v in d[name].items():
            if k in PRESET_KEYS:
                setattr(settings, k, v)
        settings.level, settings.level_auto, settings.level_preset = "custom", False, name
        settings.save()
    elif r.action == "delete":
        d.pop(name, None)
        PRESET_FILE.write_text(json.dumps(d))
        if settings.level_preset == name:
            settings.level_preset = ""
            settings.save()
    else:
        raise HTTPException(400, "unknown action")
    return {"ok": True, "presets": sorted(d), "active": settings.level_preset}


class OnboardReq(BaseModel):
    step: str = ""
    hide: bool | None = None


@app.post("/api/onboard")
def onboard(r: OnboardReq):
    if r.step in ("level", "limit", "watch") and r.step not in settings.onboard:
        settings.onboard = list(settings.onboard) + [r.step]
    if r.hide is not None:
        settings.onboard_hidden = bool(r.hide)
    settings.save()
    return {"ok": True, "onboard": settings.onboard, "hidden": settings.onboard_hidden}


@app.get("/api/level/stats")
def level_stats():
    from autobot.levels import LEVELS, LevelStats
    st = engine.levels.table() if engine else LevelStats().table()
    return {"levels": {k: {"label": v["label"], "blurb": v["blurb"]} for k, v in LEVELS.items()}, "stats": st,
            "level": settings.level, "auto": settings.level_auto, "active": settings.level_active}


@app.post("/api/options")
def options(r: OptsReq):
    if r.guard_manual in ("off", "alert", "close", "flip"):
        settings.guard_manual = r.guard_manual
        settings.save()
    if r.guard_flip_harvest is not None:
        settings.guard_flip_harvest = bool(r.guard_flip_harvest)
    if r.guard_flip_max is not None:
        settings.guard_flip_max = min(10, max(0, int(r.guard_flip_max)))
    if r.guard_loss_pct is not None:
        settings.guard_loss_pct = min(2.0, max(0.05, float(r.guard_loss_pct)))
        settings.save()
    if r.max_spread_trend_pct is not None:
        settings.max_spread_trend_pct = min(5.0, max(0.0, float(r.max_spread_trend_pct)))
    if r.max_trade_notional is not None:
        settings.max_trade_notional = max(0.0, float(r.max_trade_notional))
    if r.max_position_pct_equity is not None:
        settings.max_position_pct_equity = min(1.0, max(0.02, float(r.max_position_pct_equity)))
    if r.max_spread_pct is not None:
        settings.max_spread_pct = min(5.0, max(0.0, float(r.max_spread_pct)))
        settings.save()
    if r.pct_harvest_pct is not None:
        settings.pct_harvest_pct = min(1.0, max(0.05, float(r.pct_harvest_pct)))
        settings.save()
    for k in ("scale_out", "tod_filter", "scalp_mode", "aggressive_scalp", "cooloff_streak", "cooloff_symbol", "confirm_trades",
              "trade_all_flips", "allow_shorts", "short_from_7am", "shorts_24_5", "auto_prep", "auto_study", "auto_tune", "let_run", "proven_only", "auto_direction", "morning_reversal", "preclose_short", "pre_plan", "reentry", "pct_harvest", "pct_harvest_auto", "harvest_learn", "auto_harvest_manual", "pm_trend", "harvest_stop", "etf_pair_guard", "regime_filter", "strategy_breaker", "fractional_on", "green_guard", "morning_trend", "stocks_on"):
        v = getattr(r, k)
        if v is not None:
            if k not in ("auto_prep", "auto_study", "auto_tune", "short_from_7am", "shorts_24_5", "let_run", "proven_only", "morning_reversal", "preclose_short", "reentry", "confirm_trades", "pct_harvest", "pct_harvest_auto", "harvest_learn", "auto_harvest_manual", "pm_trend", "harvest_stop", "etf_pair_guard", "regime_filter", "strategy_breaker", "fractional_on", "green_guard", "morning_trend", "stocks_on") and getattr(settings, k) != v:
                settings.level, settings.level_auto = "custom", False     # you changed a box by hand: that's your own Custom level
            setattr(settings, k, v)
            if engine and k == "tod_filter" and hasattr(engine, "_tod"):
                del engine._tod
    settings.save()
    if r.allow_shorts is not None:
        settings.allow_shorts = r.allow_shorts
    if r.auto_resume is not None:
        settings.auto_resume = r.auto_resume
    if r.stream_prices is not None and r.stream_prices != settings.stream_prices:
        settings.stream_prices = r.stream_prices
        settings.save()
        if not ARGS.sim and not (engine and engine.running):
            build_engine()
        elif not ARGS.sim:
            if r.stream_prices and engine:
                from autobot.stream import LiveFeed
                k, sec = api_keys(settings.live)
                _set_feed(LiveFeed(k, sec, settings.data_feed))
                engine.broker.live = feed
            elif engine:
                engine.broker.live = None
                _set_feed(None)
    for k in ("ext_premarket", "ext_afterhours", "ext_overnight"):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, k, v)
            if engine:
                engine.event(f"{k.replace('ext_', '').replace('afterhours', 'after-hours')} trading "
                             f"{'ON' if v else 'OFF'}")
    if r.data_feed in ("iex", "sip") and r.data_feed != settings.data_feed:
        if r.data_feed == "sip" and not ARGS.sim:          # make sure the account really has SIP first
            try:
                from alpaca.data.enums import DataFeed
                from alpaca.data.historical import StockHistoricalDataClient
                from alpaca.data.requests import StockLatestQuoteRequest
                k, sec = api_keys(settings.live)
                StockHistoricalDataClient(k, sec).get_stock_latest_quote(
                    StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
            except Exception as ex:
                raise HTTPException(400, "Alpaca says this account can't use SIP data yet "
                                         f"({str(ex)[:120]}). It stays on IEX.")
        was = bool(engine and engine.running)
        if was:
            engine.stop()                  # positions keep their server-side stops
        settings.data_feed = r.data_feed
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        if engine:
            engine.event(f"Data feed switched to {r.data_feed.upper()}" + (" (bot restarted)" if was else ""))
    settings.save()
    return {"ok": True}


class ModeReq(BaseModel):
    live: bool
    pin: str = ""
    restart: bool = False


@app.post("/api/mode")
def mode(r: ModeReq, request: Request):
    """Switch PAPER <-> LIVE. Live needs the PIN and working live keys; if the auto-trader is running it is
    stopped (positions keep their server-side stops), switched, and started again in the new mode."""
    if ARGS.sim:
        raise HTTPException(400, "The simulator has no live mode.")
    if r.live == settings.live:
        return {"ok": True, "live": settings.live}
    was_running = bool(engine and engine.running)
    if was_running and not r.restart:
        raise HTTPException(409, "RUNNING")
    if r.live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(400, "No Live PIN set yet. Add one in ⚙ → Broker keys → Live.")
        if not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
        k, sec = api_keys(True)
        if not (k and sec):
            raise HTTPException(400, "No LIVE keys saved yet. Add them in ⚙ → Broker keys → Live.")
        test = _test_alpaca(k, sec, paper=False)
        if not test["ok"]:
            raise HTTPException(400, test["error"])
    if was_running:
        engine.stop()
    settings.remember_limit()                 # keep the old mode's limit, then use the new mode's own
    settings.live = r.live
    settings.use_limit_for(r.live)
    settings.save()
    build_engine()
    if engine is None:            # could not connect in the new mode: go back
        err = setup_error
        settings.remember_limit()
        settings.live = not r.live
        settings.use_limit_for(settings.live)
        settings.save()
        build_engine()
        raise HTTPException(400, f"Couldn't connect in {'LIVE' if r.live else 'PAPER'} mode: {err}")
    engine.event(f"Switched to {'LIVE — real money' if r.live else 'PAPER'} trading", "warning" if r.live else "info")
    alerts.send("system", "🔴 LIVE trading ON — real money" if r.live else "Back to PAPER trading",
                "Orders now use your real-money account." if r.live else "Orders now use the paper account.")
    if was_running:
        engine.start(resumed=True)
    return {"ok": True, "live": settings.live, "restarted": was_running}


@app.post("/api/reconnect")
def reconnect():
    if engine and engine.running:
        raise HTTPException(400, "Stop the bot first")
    build_engine()
    return {"ok": engine is not None, "error": setup_error}


@app.get("/api/trades")
def trades(limit: int = 200):
    return db.recent(limit)


@app.get("/api/trades.csv")
def trades_csv(limit: int = 5000):
    """v2.19.8: the stock trade journal as a CSV download."""
    import csv, io
    rows = db.recent(limit) or []
    buf = io.StringIO()
    cols = list(rows[0].keys()) if rows else ["day", "symbol", "side", "qty", "entry", "exit", "pnl"]
    w = csv.DictWriter(buf, fieldnames=cols, extrasaction="ignore"); w.writeheader()
    for r in rows:
        w.writerow({k: r.get(k) for k in cols})
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=sekexbot_trade_journal.csv"})


# ---------------- v2.21: Morning plan runs on its own ----------------
_PLAN_FILE = DATA_DIR / "plan.json"
_PLAN = {"day": "", "marks": [], "plans": [], "at": "", "fired": [], "n": 0, "log": []}


def _plan_cfg():
    d = {"auto": True, "trade": True, "symbols": []}
    try:
        d.update(json.loads(_PLAN_FILE.read_text()))
    except Exception:
        pass
    return d


def _plan_cfg_save(d):
    try:
        _PLAN_FILE.write_text(json.dumps({"auto": bool(d.get("auto", True)), "trade": bool(d.get("trade", True)),
                                          "symbols": [x for x in d.get("symbols", []) if re.fullmatch(r"[A-Z.]{1,6}", x)][:5]}))
    except Exception:
        pass


def _plan_syms(typed=""):
    c = _plan_cfg()
    if typed:
        raw = typed.split(",")
    elif getattr(settings, "focus_on", False) and getattr(settings, "focus_symbols", None):
        raw = list(settings.focus_symbols)
    else:
        raw = c.get("symbols") or list(getattr(settings, "focus_symbols", []) or [])
    syms = [x.strip().upper() for x in raw if x and x.strip()]
    return [x for x in dict.fromkeys(syms) if re.fullmatch(r"[A-Z.]{1,6}", x)][:5]


def _plan_build(e, syms, now):
    from autobot import plan as _plan
    data = e.broker.bars(syms, now - timedelta(days=6))
    out = []
    for sym in syms:
        try:
            out.append(_plan.build_plan(sym, data.get(sym), now, events.earnings_text(sym, now) or ""))
        except Exception as ex:
            out.append({"symbol": sym, "ok": False, "why": "Could not build: " + str(ex)[:80]})
    return out


def _plan_pass(e, now, sess, pos):
    """Builds the plan by itself at 8:30 and 9:15 AM ET (or once when the app starts later), alerts you, and, with Auto-trade on,
    places a plan entry in REGULAR hours once price triggers it. Same safety as presets: Auto-trader running, LIVE needs today's PIN arming,
    earnings / risky-news filter, Focus mode, one trade per stock per day, 3 a day in PAPER and 2 in LIVE. Loss limits untouched."""
    c = _plan_cfg()
    if not c.get("auto", True) or now.weekday() >= 5:
        return
    day = str(now.date())
    if _PLAN["day"] != day:
        _PLAN.update(day=day, marks=[], plans=[], at="", fired=[], n=0, log=[])
    mins = now.hour * 60 + now.minute
    mark = "0915" if mins >= 9 * 60 + 15 else "0830" if mins >= 8 * 60 + 30 else ""
    if mins >= 16 * 60 or mins < 4 * 60:
        mark = ""
    if not _PLAN["plans"] and not mark and 4 * 60 <= mins < 16 * 60:
        mark = "late"                      # app started after the usual times: build one now
    if mark and mark not in _PLAN["marks"] and not (mark == "0830" and "late" in _PLAN["marks"]):
        syms = _plan_syms()
        if syms:
            _PLAN["marks"].append(mark)
            try:
                plans = _plan_build(e, syms, now)
                _PLAN.update(plans=plans, at=now.strftime("%I:%M %p").lstrip("0"))
                ok = [p for p in plans if p.get("ok")]
                if ok:
                    txt = "; ".join(f"{p['symbol']} {p['bias'].upper()} (buy above ${p['plan']['buy_above']['price']:.2f})" if p["bias"] != "short"
                                    else f"{p['symbol']} SHORT (below ${p['plan']['short_below']['price']:.2f})" for p in ok)
                    alerts.send("jump", "📋 Morning plan ready", txt, level="info")
            except Exception:
                logging.exception("morning plan build failed")
    if not c.get("trade", True) or sess != "REGULAR" or not getattr(e, "running", False):
        return
    if mins < 9 * 60 + 35 or mins > 15 * 60 + 30 or not _PLAN["plans"]:
        return
    live = e.mode == "LIVE"
    if live and _PR.get("armed") != day:
        return
    if _PLAN["n"] >= (2 if live else 3):
        return
    todo = [p for p in _PLAN["plans"] if p.get("ok") and p["bias"] in ("long", "short") and p["symbol"] not in _PLAN["fired"]
            and getattr(e, "focus_ok", lambda x: True)(p["symbol"]) and not float((pos.get(p["symbol"]) or {}).get("qty") or 0)]
    if not todo:
        return
    try:
        data = e.broker.bars([p["symbol"] for p in todo])
    except Exception:
        return
    for p in todo:
        sym = p["symbol"]
        if getattr(e, "_event_block", lambda *x: False)(sym, now, sess):
            continue
        d1 = data.get(sym)
        if d1 is None or len(d1) < 6:
            continue
        d1 = d1[d1.index.time >= datetime.min.time().replace(hour=9, minute=30)]
        if len(d1) < 6:
            continue
        d1 = d1.iloc[:-1] if d1.index[-1] + timedelta(minutes=1) > now else d1        # last CLOSED minute
        last = float(d1["close"].iloc[-1])
        tp = (d1["high"] + d1["low"] + d1["close"]) / 3
        vw = float((tp * d1["volume"]).sum() / max(d1["volume"].sum(), 1))
        pl = p["plan"]
        up = p["bias"] == "long"
        trig = pl["buy_above"] if up else pl["short_below"]
        risk = abs(trig["price"] - trig["stop"])
        if up:
            hit = last >= trig["price"] and last <= trig["price"] + risk and last > vw
            dip = (not hit) and last > pl["dip_buy"]["stop"] and last <= pl["dip_buy"]["price"] + 0.1 * risk and last > vw * 0.995
        else:
            hit = last <= trig["price"] and last >= trig["price"] - risk and last < vw
            dip = False
        if not (hit or dip):
            continue
        if getattr(e, "ha_block", lambda *x: "")(sym, up, "stocks"):
            continue
        if not up and not settings.allow_shorts:
            _PLAN["fired"].append(sym)
            _PLAN["log"].append(f"{now.strftime('%-I:%M %p')} {sym}: short skipped, Allow short selling is off")
            continue
        _PLAN["fired"].append(sym)
        try:
            if dip:
                stop, tgt, why = pl["dip_buy"]["stop"], pl["dip_buy"]["t1"], "bought the dip"
            else:
                stop = round(last - risk if up else last + risk, 2)
                tgt = round(last + 2 * risk if up else last - 2 * risk, 2)
                why = "broke above the plan level" if up else "broke below the plan level"
            res = _jp_place(e, sym, up, round(last, 2), stop, tgt)
            _PLAN["n"] += 1
            _PLAN["log"].append(f"{now.strftime('%-I:%M %p')} {sym}: {why}. {res['msg']}")
            alerts.send("jump", f"📋 Plan trade ({'LIVE' if live else 'paper'}): {'buy' if up else 'short'} {sym}", f"{why}. {res['msg']}", symbol=sym, level="info")
        except HTTPException as ex:
            _PLAN["log"].append(f"{now.strftime('%-I:%M %p')} {sym}: not sent: {ex.detail}")
        except Exception:
            logging.exception("plan trade failed")
        if _PLAN["n"] >= (2 if live else 3):
            return


class PlanCfg(BaseModel):
    auto: bool | None = None
    trade: bool | None = None
    symbols: str | None = None


class HaCfg(BaseModel):
    on: bool | None = None
    n: int | None = None
    stocks: bool | None = None
    options: bool | None = None
    auto: bool | None = None


def _ha_state_payload():
    from autobot import ha as _ha
    c = _ha.load()
    e = engine
    syms = _plan_syms()
    try:
        syms = list(dict.fromkeys(syms + list(e.broker.positions().keys())))[:8] if e else syms
    except Exception:
        pass
    rows = []
    for sym in syms:
        try:
            d1 = (e.raw.get(sym) if isinstance(e.raw, dict) else None)
            if d1 is None or len(d1) < 40:
                d1 = e.broker.bars([sym]).get(sym)
            d5 = _ha.to5(d1)
            st = _ha.state(d5.iloc[:-1] if len(d5) > 1 else d5, c["n"])
        except Exception:
            st = ("unknown", 0)
        rows.append({"symbol": sym, "color": st[0], "run": st[1]})
    return {"cfg": c, "rows": rows}


@app.get("/api/ha")
def ha_get():
    return _ha_state_payload()


@app.post("/api/ha/config")
def ha_config(r: HaCfg):
    from autobot import ha as _ha
    c = _ha.load()
    for k in ("on", "n", "stocks", "options", "auto"):
        v = getattr(r, k)
        if v is not None:
            c[k] = v
    _ha.save(c)
    if engine:
        engine.event("Heikin Ashi trend filter " + ("ON" if c["on"] else "OFF") + f" (needs {c['n']} candles)")
    return _ha_state_payload()


@app.get("/api/plan/state")
def plan_state():
    c = _plan_cfg()
    return {"cfg": c, "symbols": _plan_syms(), "day": _PLAN["day"], "at": _PLAN["at"], "plans": _PLAN["plans"], "log": _PLAN["log"][-8:],
            "traded": _PLAN["n"], "focus_on": bool(getattr(settings, "focus_on", False))}


@app.post("/api/plan/config")
def plan_config(r: PlanCfg):
    c = _plan_cfg()
    if r.auto is not None:
        c["auto"] = r.auto
    if r.trade is not None:
        c["trade"] = r.trade
    if r.symbols is not None:
        syms = [x.strip().upper() for x in r.symbols.replace(" ", ",").split(",") if x.strip()]
        c["symbols"] = [x for x in dict.fromkeys(syms) if re.fullmatch(r"[A-Z.]{1,6}", x)][:5]
        _PLAN.update(marks=[], plans=[], at="")          # new stocks: build again at the next pass
    _plan_cfg_save(c)
    return plan_state()


@app.get("/api/plan")
def morning_plan(symbols: str = ""):
    """v2.19.8: 📋 Morning plan for up to 5 stocks (default: the Focus stocks). Display only; no orders."""
    from autobot import plan as _plan
    e = need_engine()
    syms = [x.strip().upper() for x in (symbols or ",".join(getattr(settings, "focus_symbols", []) or [])).split(",") if x.strip()]
    syms = [x for x in dict.fromkeys(syms) if re.fullmatch(r"[A-Z.]{1,6}", x)][:5]
    if not syms:
        raise HTTPException(400, "Type 1 to 5 stock symbols, or turn Focus mode on first.")
    now = e.broker.now()
    try:
        out = _plan_build(e, syms, now)
    except Exception as ex:
        raise HTTPException(502, "Price data unavailable: " + str(ex)[:100])
    return {"plans": out, "at": now.strftime("%I:%M %p").lstrip("0"), "focus_on": bool(getattr(settings, "focus_on", False)),
            "note": "Levels are a starting point from the last session and overnight trading. The bot still waits for its own signal before it buys."}


@app.get("/api/daily")
def daily():
    return db.daily_summary()


@app.post("/api/learner/reset")
def reset_learner():
    learner.reset()
    return {"ok": True}


@app.get("/api/chart/{symbol}")
def chart(symbol: str, tf: int = 3):
    e = need_engine()
    sym = symbol.upper()
    df, as_of = None, "live"
    try:
        df = e.broker.chart_bars(sym)
    except Exception:
        df = None
    if df is None or len(df) < 20:          # fall back to the old sources
        df = e.raw.get(sym)
        if df is None or len(df) < 20:
            try:
                df, as_of = e.broker.analysis_bars(sym)
            except Exception:
                df = None
    if df is not None and len(df):
        age = (e.broker.now() - df.index[-1]).total_seconds()
        if age > 300:
            as_of = "last trade " + df.index[-1].strftime("%a %b %d %I:%M %p").replace(" 0", " ")
    if df is None or df.empty:
        return {"bars": [], "as_of": ""}
    tf = tf if tf in (1, 3, 5, 15) else 3
    from autobot.indicators import vwap as _vwap
    vw = _vwap(df)
    h = ribbon(df, lines=True, tf=f"{tf}min").tail(400)
    cols = ["open", "high", "low", "close", "fast", "slow", "band_hi", "band_lo", "state",
            "e10", "e12", "e14", "e16", "e18"]
    out = []
    try:
        from autobot import ha as _ha
        _hac = _ha.ha_df(h[["open", "high", "low", "close"]].dropna())
    except Exception:
        _hac = pd.DataFrame(index=h.index[:0], columns=["open", "high", "low", "close"])
    for ts, row in h.iterrows():
        d = {"t": ts.strftime("%H:%M"), "d": ts.strftime("%a %b %d")}
        hm = ts.hour * 60 + ts.minute
        d["x"] = 0 if 570 <= hm < 960 else (1 if 240 <= hm < 1200 else 2)   # 0 regular, 1 pre/after, 2 overnight
        d.update({c: (None if row[c] != row[c] else round(float(row[c]), 4)) for c in cols})
        d["v"] = int(row["volume"]) if row["volume"] == row["volume"] else 0
        if ts in _hac.index:
            d["ho"], d["hh"], d["hl"], d["hc"] = (round(float(_hac.at[ts, k]), 4) for k in ("open", "high", "low", "close"))
        end = ts + pd.Timedelta(minutes=tf)
        w = vw[vw.index < end]
        d["vwap"] = round(float(w.iloc[-1]), 4) if len(w) else None
        out.append(d)
    trades_ = [t for t in db.recent(300) if t["symbol"] == sym and t["day"] == e.day]
    pred = {"preds": [], "outlook": None, "stats": {}}
    try:
        from autobot.predict import predict as _predict
        off = len(ribbon(df, lines=False, tf=f"{tf}min")) - len(h)      # h is the last 400 candles
        pred = _predict(df, tf)
        pred["preds"] = [dict(p, i=p["i"] - off) for p in pred["preds"] if p["i"] - off >= 0]
    except Exception as ex:
        logging.debug("predict %s: %s", sym, ex)
    jsig = []
    try:
        d5 = jp.to5(df)
        if d5 is not None and len(d5) >= 32:
            first = h.index[0] if len(h) else None
            for s_ in jp.scan(d5):
                if first is not None and s_["ts"] < first:
                    continue
                jsig.append({k: s_[k] for k in ("t", "d", "kind", "side", "price", "name", "why", "zone", "stop", "tp1", "tp2") if k in s_})
    except Exception as ex:
        logging.debug("jump chart %s: %s", sym, ex)
    held = 0
    try:
        held = float(((e.broker.positions() or {}).get(sym) or {}).get("qty") or 0)
    except Exception:
        pass
    return clean({"bars": out, "trades": trades_, "as_of": as_of, "tf": tf, "jump": jsig[-60:], "held": held, "tap": _JP["cfg"].get("tap", "ask"), **pred})


_wl_pred = {"at": 0.0, "tf": 0, "items": []}


@app.get("/api/predict/watchlist")
def predict_watchlist(tf: int = 3, snd: int = 0):
    """Early BUY?/SELL? warnings for every watchlist stock (display only, never trades). Cached 30 s."""
    import time as _tm
    from autobot.predict import chip_status
    e = need_engine()
    if snd:                      # an open dashboard is beeping/speaking itself: the phone stays quiet
        alerts.screen_sound_at = _tm.time()
    tf = tf if tf in (1, 3, 5, 15) else 3
    syms = [w.upper() for w in settings.watchlist]
    if _tm.time() - _wl_pred["at"] < 30 and _wl_pred["tf"] == tf and _wl_pred.get("syms") == syms:
        return clean({"items": _wl_pred["items"], "tf": tf})
    frames = {s: e.raw.get(s) for s in syms if e.raw.get(s) is not None and len(e.raw.get(s)) >= 60}
    missing = [s for s in syms if s not in frames]
    if missing:
        try:
            now = e.broker.now()
            got = e.broker.bars(missing, start=now.replace(hour=4, minute=0, second=0, microsecond=0))
            frames.update({k: v for k, v in (got or {}).items() if v is not None and len(v) >= 60})
        except Exception as ex:
            logging.debug("watchlist bars: %s", ex)
    for s in [s for s in syms if s not in frames][:10]:       # market closed / no bars today: last session
        try:
            df = e.broker.chart_bars(s)
            if df is not None and len(df) >= 60:
                frames[s] = df
        except Exception:
            continue
    items = []
    for s in syms:
        df = frames.get(s)
        if df is None:
            items.append({"symbol": s, "ready": False, "state": 0, "outlook": None, "rate": None,
                          "note": "No price data from Alpaca for this ticker"})
            continue
        try:
            items.append(dict(chip_status(df, tf), symbol=s))
        except Exception as ex:
            items.append({"symbol": s, "ready": False, "state": 0, "outlook": None, "rate": None, "note": str(ex)[:80]})
    _wl_pred.update(at=_tm.time(), tf=tf, items=items, syms=syms)
    return clean({"items": items, "tf": tf})


_pos_tr = {"at": 0.0, "items": {}, "syms": ()}


@app.get("/api/position/trends")
def position_trends():
    """Trend prediction for every open position (broker positions + bot trades): ribbon colour, early BUY?/SELL?
    warning with confidence, the direction call, and whether it works for or against the position. Cached 30 s."""
    import time as _tm
    from autobot.predict import chip_status
    from autobot.direction import direction
    from autobot.indicators import enrich, ribbon_state
    e = need_engine()
    pos = e.broker.positions()
    held = {s: (1 if p["qty"] > 0 else -1) for s, p in pos.items()}
    for s, t in list(e.trades.items()):
        held.setdefault(s, t.dir)
    syms = tuple(sorted(held))
    if _tm.time() - _pos_tr["at"] < 30 and _pos_tr["syms"] == syms:
        return clean({"items": _pos_tr["items"]})
    frames = {s: e.raw.get(s) for s in syms if e.raw.get(s) is not None and len(e.raw.get(s)) >= 30}
    miss = [s for s in syms if s not in frames]
    if miss:
        try:
            now = e.broker.now()
            got = e.broker.bars(miss, start=now.replace(hour=4, minute=0, second=0, microsecond=0))
            frames.update({k: v for k, v in (got or {}).items() if v is not None and len(v) >= 30})
        except Exception:
            pass
    for s in [s for s in syms if s not in frames][:6]:
        try:
            df = e.broker.chart_bars(s)
            if df is not None and len(df) >= 30:
                frames[s] = df
        except Exception:
            continue
    items = {}
    for s in syms:
        df, d = frames.get(s), held[s]
        if df is None:
            items[s] = {"ready": False, "note": "no price data"}
            continue
        try:
            cs = chip_status(df, 3)
            it = {"ready": bool(cs.get("ready")), "state": cs.get("state", 0), "rate": cs.get("rate"), "outlook": cs.get("outlook")}
            try:
                dc = direction(enrich(df), 0.0, ribbon_state(df), e.bias, None)
                it.update(call=dc["call"], score=dc["score"], stretched=dc.get("stretched", False))
            except Exception:
                pass
            o = it["outlook"]
            it["against"] = bool(o and ((o["side"] == "sell" and d > 0) or (o["side"] == "buy" and d < 0)))
            it["with"] = bool(o and ((o["side"] == "buy" and d > 0) or (o["side"] == "sell" and d < 0)))
            it["dir"] = d
            it["lean_against"] = bool(it.get("call") in ("LONG", "SHORT") and ((it["call"] == "SHORT") == (d > 0)))
            items[s] = it
        except Exception as ex:
            items[s] = {"ready": False, "note": str(ex)[:80]}
    _pos_tr.update(at=_tm.time(), items=items, syms=syms)
    return clean({"items": items})


@app.get("/api/analyze/{symbol}")
def analyze_symbol(symbol: str):
    if engine is None:
        return {"error": "The live chart read needs your Alpaca connection: " + (setup_error or "not connected") +
                         " (The screenshot reader works without it.)"}
    e = engine
    sym = symbol.upper().strip()
    if not sym.replace(".", "").isalpha():
        return {"error": "Enter a valid ticker, e.g. NVDA"}
    df, as_of = e.raw.get(sym), "live"
    try:
        if df is None or len(df) < 20:
            df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        return {"error": f"Couldn't load bars for {sym}: {str(ex)[:200]}"}
    if df is None or len(df) < 20:
        return {"error": f"No recent 1-minute data for {sym}. Check the ticker is a US stock/ETF on Alpaca."}
    try:
        res = analyze(sym, df, e.bias, learner)
    except Exception as ex:
        logging.exception("analyze failed")
        return {"error": f"Analysis failed for {sym}: {str(ex)[:200]}"}
    res["as_of"] = as_of
    return clean(res)


class VisionReq(BaseModel):
    image_b64: str
    media_type: str = "image/png"
    question: str = ""


@app.post("/api/vision")
def vision(r: VisionReq):
    if len(r.image_b64) > 7_000_000:
        raise HTTPException(400, "Image too large (max ~5 MB)")
    try:
        plan = vision_read(r.image_b64, r.media_type, r.question)
    except Exception as ex:
        logging.exception("vision failed")
        return {"error": f"Couldn't reach Claude: {str(ex)[:200]}"}
    if plan.get("error"):
        return plan
    sym = (plan.get("symbol") or "").upper().strip()
    if sym and engine and sym.replace(".", "").isalpha():
        try:   # add the live price so you can compare with the screenshot
            q = engine.broker.quotes([sym], engine.session.name if engine.session else "REGULAR").get(sym)
            if q:
                plan["live_price"] = round((q[0] + q[1]) / 2, 2)
        except Exception:
            pass
        plan["on_watchlist"] = sym in [w.upper() for w in settings.watchlist]
    return clean(plan)


class KeyReq(BaseModel):
    key: str


from autobot.analyst import ai_key as _ai_key, provider as _ai_provider  # noqa: E402


@app.post("/api/anthropic_key")
def set_key(r: KeyReq):
    k = r.key.strip().strip('"').strip("'")
    if not k.startswith("sk-"):
        raise HTTPException(400, "That doesn't look like a Claude API key (should start with sk-ant-)")
    vals = {"ANTHROPIC_API_KEY": k}
    if not os.getenv("OPENAI_API_KEY"):
        vals["AI_PROVIDER"] = "anthropic"
    write_env(vals)
    return {"ok": True}


class OpenAIKeyReq(BaseModel):
    key: str = ""
    model: str | None = None


@app.post("/api/openai_key")
def set_openai_key(r: OpenAIKeyReq):
    """Save a ChatGPT (OpenAI) API key. It becomes the active AI unless you already chose Claude with a key saved."""
    k = r.key.strip().strip('"').strip("'")
    vals = {}
    if k:
        if not k.startswith("sk-"):
            raise HTTPException(400, "That doesn't look like an OpenAI API key (should start with sk-)")
        vals["OPENAI_API_KEY"] = k
        if not os.getenv("ANTHROPIC_API_KEY"):
            vals["AI_PROVIDER"] = "openai"
    if r.model is not None:
        vals["OPENAI_MODEL"] = r.model.strip()
    if not vals:
        raise HTTPException(400, "Paste your OpenAI API key")
    write_env(vals)
    from autobot import analyst
    analyst._MODEL_CACHE.pop("oa", None)
    return {"ok": True}


class OllamaReq(BaseModel):
    url: str = ""
    model: str | None = None
    key: str | None = None
    cf_id: str | None = None            # Cloudflare Access service token (blank string removes it)
    cf_secret: str | None = None


@app.post("/api/ollama_config")
def set_ollama(r: OllamaReq):
    """Save where Ollama runs (e.g. http://192.168.1.50:11434) and, optionally, the model. It becomes the active AI when no Claude or ChatGPT key is saved."""
    vals = {}
    u = r.url.strip().strip('"').strip("'")
    if u:
        if not re.match(r"^https?://", u):
            u = "http://" + u
        u = u.rstrip("/")
        u = u[:-3] if u.endswith("/v1") else u
        if not re.match(r"^https?://[^\s/]+(:\d+)?(/[^\s]*)?$", u):
            raise HTTPException(400, "That doesn't look like an address. Example: http://192.168.1.50:11434")
        vals["OLLAMA_BASE_URL"] = u
        if not (os.getenv("ANTHROPIC_API_KEY") or os.getenv("OPENAI_API_KEY")):
            vals["AI_PROVIDER"] = "ollama"
    if r.model is not None:
        vals["OLLAMA_MODEL"] = r.model.strip()
    if r.key is not None:
        vals["OLLAMA_API_KEY"] = r.key.strip()
    if r.cf_id is not None and r.cf_secret is not None:
        vals["OLLAMA_CF_ID"] = r.cf_id.strip()
        vals["OLLAMA_CF_SECRET"] = r.cf_secret.strip()
    if not vals:
        raise HTTPException(400, "Enter the Ollama address")
    write_env(vals)
    from autobot import analyst
    analyst._MODEL_CACHE.pop("ol", None)
    return {"ok": True}


class ProviderReq(BaseModel):
    provider: str


@app.post("/api/ai_provider")
def set_ai_provider(r: ProviderReq):
    p = r.provider.strip().lower()
    if p not in ("anthropic", "openai", "ollama"):
        raise HTTPException(400, "Choose Claude, ChatGPT or Ollama")
    if p == "ollama":
        if not os.getenv("OLLAMA_BASE_URL"):
            raise HTTPException(400, "Save the Ollama address first")
    elif not os.getenv("OPENAI_API_KEY" if p == "openai" else "ANTHROPIC_API_KEY"):
        raise HTTPException(400, f"Save a {'ChatGPT (OpenAI)' if p == 'openai' else 'Claude'} API key first")
    write_env({"AI_PROVIDER": p})
    return {"ok": True, "provider": p}


# ---------------- broker keys (GUI setup) ----------------
# Keys are written to the local .env file and never sent back to the browser (only a masked hint).
def _test_alpaca(key: str, secret: str, paper: bool) -> dict:
    from alpaca.trading.client import TradingClient
    try:
        a = TradingClient(key, secret, paper=paper).get_account()
        return {"ok": True, "account": str(a.account_number), "equity": float(a.equity),
                "buying_power": float(a.buying_power), "status": str(getattr(a.status, "value", a.status))}
    except Exception as e:
        msg = _friendly(e, not paper)
        if "rejected" in msg:
            msg = (f"Alpaca rejected these keys. Check you copied the full Key ID and Secret from your "
                   f"{'LIVE' if not paper else 'Paper'} account (regenerate them if the secret was lost).")
        return {"ok": False, "error": msg}


@app.get("/api/keys")
def keys_status():
    pk, ps = api_keys(False)
    lk, ls = api_keys(True)
    return {"paper": {"set": bool(pk and ps), "hint": mask(pk)},
            "live": {"set": bool(lk and ls), "hint": mask(lk)},
            "live_pin_set": bool(live_pin()), "anthropic_set": bool(os.getenv("ANTHROPIC_API_KEY")),
            "anthropic_hint": mask(os.getenv("ANTHROPIC_API_KEY", "")),
            "openai_set": bool(os.getenv("OPENAI_API_KEY")), "openai_hint": mask(os.getenv("OPENAI_API_KEY", "")),
            "openai_model": os.getenv("OPENAI_MODEL", ""), "ai_provider": _ai_provider(),
            "ollama_set": bool(os.getenv("OLLAMA_BASE_URL")), "ollama_url": os.getenv("OLLAMA_BASE_URL", ""), "ollama_model": os.getenv("OLLAMA_MODEL", ""), "ollama_cf_set": bool(os.getenv("OLLAMA_CF_ID") and os.getenv("OLLAMA_CF_SECRET")),
            "mode": "live" if settings.live else "paper", "connected": engine is not None,
            "error": setup_error, "sim": ARGS.sim}


class KeyTestReq(BaseModel):
    account: str = "paper"      # paper | live
    key: str = ""
    secret: str = ""


def _clean_key(v: str) -> str:
    return v.strip().strip('"').strip("'").replace(" ", "")


@app.post("/api/keys/test")
def keys_test(r: KeyTestReq):
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    if not k or not s_:          # test the saved keys
        k, s_ = api_keys(not paper)
    if not k or not s_:
        raise HTTPException(400, "Enter the API Key ID and Secret first")
    return _test_alpaca(k, s_, paper)


class KeySaveReq(BaseModel):
    account: str = "paper"
    key: str = ""
    secret: str = ""
    live_pin: str = ""


class PinSetReq(BaseModel):
    pin: str = ""
    current: str = ""


@app.post("/api/pin/set")
def pin_set(r: PinSetReq, request: Request):
    """Create or change this phone's Live PIN (works while the bot is running). Changing needs the current PIN."""
    if live_pin() and not pin_ok(r.current):
        ip = request.client.host if request.client else "?"
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong tries. Wait 15 minutes.")
        auth.record_fail(ip)
        raise HTTPException(403, "The current PIN is not right.")
    newpin = (r.pin or "").strip()
    if len(newpin) < 4:
        raise HTTPException(400, "Use a PIN of at least 4 characters")
    if re.search(r"[\s#'\"\\=$`]", newpin):
        raise HTTPException(400, "Use letters and numbers only for the PIN (no spaces or symbols).")
    write_env({"LIVE_PIN": newpin})
    return {"ok": True}


@app.post("/api/keys/save")
def keys_save(r: KeySaveReq):
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    if (k or s_) and engine and engine.running:        # a PIN alone can be saved while the bot runs; keys cannot
        raise HTTPException(400, "Stop the bot before changing broker keys")
    vals = {}
    if k or s_:
        if not (k and s_):
            raise HTTPException(400, "Enter both the API Key ID and the Secret")
        if paper and k.startswith("AK"):
            raise HTTPException(400, "That's a LIVE key (starts with AK). Paper keys start with PK — "
                                     "switch Alpaca's dashboard to Paper Trading and generate keys there.")
        if not paper and k.startswith("PK"):
            raise HTTPException(400, "That's a PAPER key (starts with PK). Live keys start with AK.")
        test = _test_alpaca(k, s_, paper)
        if not test["ok"] and not ARGS.sim:
            return {"ok": False, "error": test["error"]}
        pre = "ALPACA_PAPER" if paper else "ALPACA_LIVE"
        vals[f"{pre}_KEY"], vals[f"{pre}_SECRET"] = k, s_
    if r.live_pin:
        newpin = r.live_pin.strip()
        if len(newpin) < 4:
            raise HTTPException(400, "Use a PIN of at least 4 characters")
        if re.search(r"[\s#'\"\\=$`]", newpin):
            raise HTTPException(400, "Use letters and numbers only for the PIN (no spaces or symbols): some of them get cut off when the app restarts.")
        vals["LIVE_PIN"] = newpin
    if not vals:
        raise HTTPException(400, "Nothing to save")
    write_env(vals)
    if (k or s_) and not ARGS.sim and (paper != settings.live):   # keys for the active mode changed -> reconnect
        build_engine()
    return {"ok": True, "connected": engine is not None, "error": setup_error}


# ---------------- manual trading: your own Buy / Sell / Close ----------------
# Manual positions are yours: the bot never enters, manages or flattens them at the close.
# (The daily-loss halt closes every LOSING position in the account, manual ones included; winners stay open.)
def _session_name(e):
    from autobot.sessions import current_session
    try:
        sess = current_session(e.broker.trading_day, e.broker.now())
        return sess.name if sess else "CLOSED"
    except Exception:
        return "CLOSED"


def _price(e, sym, sess):
    """Always returns something to price an order with (live quote, last trade, or last close)."""
    try:
        return e.broker.price_info(sym, sess)
    except Exception:
        return {"bid": None, "ask": None, "last": None, "prev_close": None, "ts": None, "source": ""}


def _quote(e, sym, sess):
    p = _price(e, sym, sess)
    bid, ask, last = p.get("bid"), p.get("ask"), p.get("last")
    return (bid or last), (ask or last)


def _valid_sym(sym):
    sym = (sym or "").upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker, e.g. AAPL")
    return sym


@app.get("/api/manual/quote/{symbol}")
def manual_quote(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    sess = _session_name(e)
    pr = _price(e, sym, sess)
    last, pc = pr.get("last"), pr.get("prev_close")
    if last is None and not pr.get("bid"):
        raise HTTPException(404, f"No price found for {sym}. Check the ticker is a US stock or ETF on Alpaca.")
    bid, ask = pr.get("bid") or last, pr.get("ask") or last
    ts = pr.get("ts")
    live = sess != "CLOSED" and bool(pr.get("bid")) and bool(ts) and (e.broker.now() - ts).total_seconds() < 900
    pos = e.broker.positions().get(sym)
    return clean({"symbol": sym, "bid": bid, "ask": ask, "last": last or (bid + ask) / 2, "session": sess,
                  "prev_close": pc, "change": (last - pc) if last and pc else None,
                  "change_pct": ((last / pc - 1) * 100) if last and pc else None,
                  "live": live, "source": pr.get("source", ""), "as_of": ts.strftime("%a %b %d %I:%M %p").replace(" 0", " ") if ts else "",
                  "has_book": bool(pr.get("bid")),
                  "spread_pct": round((ask - bid) / ((ask + bid) / 2) * 100, 3) if bid and ask and ask >= bid else None,
                  "max_spread_pct": settings.max_spread_pct,
                  "position": pos["qty"] if pos else 0, "avg_entry": pos["avg_entry"] if pos else None,
                  "bot": sym in e.trades, "buying_power": (e.acct or e.broker.account()).get("buying_power")})


class PreSet(BaseModel):
    pre_window: bool | None = None
    pre_from: int | None = None
    pre_until: int | None = None
    ext_max_notional: float | None = None
    pre_auto: bool | None = None


def _pre_state():
    return {"pre_window": settings.pre_window, "pre_from": settings.pre_from, "pre_until": settings.pre_until,
            "ext_max_notional": settings.ext_max_notional, "pre_entries_off": settings.pre_entries_off,
            "pre_strategy_off": settings.pre_strategy_off, "pre_only": settings.pre_only, "ext_harvest_spread_mult": settings.ext_harvest_spread_mult, "pre_auto": settings.pre_auto, "note": settings.pre_preset_note}


def apply_pre_preset(source="auto"):
    """Build the pre-market preset from the journal (or the recommended one) and save it. Daily loss limit untouched."""
    from autobot import prepreset
    e = need_engine()
    rows = [r for r in db.recent(20000) if r.get("mode") == e.mode] if source == "auto" else []
    if source == "only":
        res = {"settings": dict(prepreset.STATIC, pre_only=["EXT_TREND", "FLUSH_BOUNCE"], ext_harvest_spread_mult=3.0), "trades": 0, "source": "only",
               "note": "Pre-market only preset: the bot runs just EXT_TREND and FLUSH_BOUNCE in the pre-market (the two that held up in your journal), "
                       "starts trades 7:00 to 9:00, max $10,000 each, and harvests at least 3 times the spread."}
    elif source == "auto":
        res = prepreset.build(rows)
        res["settings"].setdefault("pre_only", [])
        res["settings"].setdefault("ext_harvest_spread_mult", 2.0)
    else:
        res = {"settings": dict(prepreset.STATIC, pre_only=[], ext_harvest_spread_mult=2.0), "trades": 0, "source": "recommended",
               "note": "Recommended preset: start pre-market trades 7:00 to 9:00, max $10,000 per trade, nothing else changed."}
    for k, v in res["settings"].items():
        setattr(settings, k, v)
    settings.pre_preset_note = res["note"]
    settings.save()
    e.event("Pre-market preset applied: " + res["note"], "info")
    return res


def run_autotune():
    """Nightly: switch strategies off per market session when they lose there (own closed trades), retest after a week."""
    from autobot import sessiontune as autotune
    e = need_engine()
    today = e.broker.now().strftime("%Y-%m-%d")
    rows = [r for r in db.recent(20000) if r.get("mode") == e.mode and r.get("status") == "closed"]
    off, since, ev = autotune.evaluate(rows, today, settings.tune_off, settings.tune_since, int(settings.tune_min_trades or 12))
    settings.tune_off, settings.tune_since = off, since
    if ev:
        settings.tune_log = (settings.tune_log + [{"day": today, "text": t} for t in ev])[-60:]
        for t in ev:
            e.event("Session auto-off: " + t, "info")
    settings.save()
    return ev


def _tune_state():
    from autobot import sessiontune as autotune
    items = [{"session": s, "label": autotune.LABEL.get(s, s), "strategy": st, "retest": d}
             for s in autotune.SESSIONS for st, d in sorted((settings.tune_off or {}).get(s, {}).items())]
    return {"on": settings.session_tune, "min_trades": settings.tune_min_trades, "off": items, "log": list(reversed(settings.tune_log or []))[:15]}


class TuneIn(BaseModel):
    on: bool | None = None
    run: bool = False
    clear: bool = False


@app.get("/api/autotune")
def autotune_get():
    return _tune_state()


@app.post("/api/autotune")
def autotune_set(r: TuneIn):
    if r.on is not None:
        settings.session_tune = bool(r.on)
    if r.clear:
        settings.tune_off, settings.tune_since = {}, {}
    settings.save()
    ev = run_autotune() if r.run else []
    return dict(_tune_state(), changes=ev)


class SmartIn(BaseModel):
    on: bool


@app.get("/api/smart")
def smart_get():
    from autobot import smartentry
    return dict(smartentry.stats(), on=settings.smart_entry)


@app.post("/api/smart")
def smart_set(r: SmartIn):
    settings.smart_entry = bool(r.on)
    settings.save()
    return smart_get()


class BootIn(BaseModel):
    on: bool


def _boot_flag():
    return os.path.join(os.path.expanduser("~"), ".sekexbot", "no_autostart")


def _boot_state():
    script = os.path.exists(os.path.join(os.path.expanduser("~"), ".termux", "boot", "10-sekexbot"))
    return {"on": bool(settings.start_on_boot), "script": script, "flag": os.path.exists(_boot_flag())}


def _boot_apply():
    """Mirror the setting to the file the boot script looks at (so the phone's boot script needs no Python)."""
    try:
        f = _boot_flag()
        os.makedirs(os.path.dirname(f), exist_ok=True)
        if settings.start_on_boot:
            if os.path.exists(f):
                os.remove(f)
        else:
            open(f, "w").write("off")
    except Exception as ex:
        logging.warning("start-on-boot flag: %s", ex)


@app.get("/api/boot")
def boot_get():
    return _boot_state()


@app.post("/api/boot")
def boot_set(r: BootIn):
    settings.start_on_boot = bool(r.on)
    settings.save()
    _boot_apply()
    return _boot_state()


class WaveIn(BaseModel):
    on: bool | None = None
    min_score: int | None = None
    from_min: int | None = None
    until_min: int | None = None
    max_trades: int | None = None
    risk_mult: float | None = None


class NightIn(BaseModel):
    on: bool | None = None
    dir: str | None = None


@app.get("/api/night")
def night_get():
    e = need_engine()
    now = e.broker.now()
    items = []
    nd = e.night_dir()
    for r in (e.shortlist or []):
        sym = str(r.get("symbol", "")).upper()
        if not sym or (nd == "sell" and "long only" in str(r.get("borrow", ""))):
            continue
        try:
            st = e._mover_bot({"symbol": sym, "side": "short" if nd == "sell" else "buy"}, now)
        except Exception:
            st = ""
        items.append({"symbol": sym, "score": r.get("score"), "tags": r.get("tags") or [], "change": r.get("change"),
                      "borrow": r.get("borrow"), "status": st})
    mine = [{"symbol": t.symbol, "qty": t.qty, "entry": t.entry, "status": t.status, "pnl": round(((t.last_price or t.entry) - t.entry) * t.dir * t.qty, 2)}
            for t in list(e.trades.values()) if t.ext and (t.side == "sell") == (nd == "sell")]
    return clean({"dir": nd, "on": settings.night_short, "active": e.night_window(now), "window": "8:00 PM - 7:00 AM ET", "items": items,
                  "at": e.shortlist_at, "trades": mine, "account_can_short": bool(e.acct.get("shorting_enabled", True))})


@app.post("/api/night")
def night_set(r: NightIn):
    if r.on is not None:
        settings.night_short = bool(r.on)
    if r.dir in ("buy", "sell"):
        settings.night_dir = r.dir
    settings.save()
    return night_get()


_mw_cache = {"at": 0.0, "key": "", "data": None}
_WK = {"last": "", "done": set(), "caught": False}      # weekend auto-rebuild bookkeeping


def _weekend_gap(now):
    """True from Friday 8 PM to Sunday 8 PM ET: no market data is produced, so Radar is a 'weekend plan' from Friday's close."""
    wd, h = now.weekday(), now.hour
    return (wd == 4 and h >= 20) or wd == 5 or (wd == 6 and h < 20)
MW_CORE = ["AAPL", "MSFT", "NVDA", "AMD", "TSLA", "AMZN", "META", "GOOGL", "AVGO", "NFLX", "SPY", "QQQ", "IWM"]


def _wave_state():
    e = need_engine()
    log = [{"at": t.strftime("%-I:%M %p"), "msg": m} for t, m in (getattr(e, "wave_log", None) or [])][-8:]
    return {"on": settings.wave_trade, "min_score": settings.wave_min_score, "from_min": settings.wave_from, "until_min": settings.wave_until,
            "max_trades": settings.wave_max_trades, "risk_mult": settings.wave_risk_mult, "mode": "SIMULATOR" if getattr(e, "mode", "") == "SIM" else ("LIVE" if settings.live else "PAPER"),
            "taken": sorted(getattr(e, "wave_done", set()) or []), "log": log, "daily_limit": settings.daily_max_loss}


class PickIn(BaseModel):
    symbol: str
    side: str = "up"                 # up = buy, down = short
    zone: list[float] = []
    stop: float = 0
    tp1: float = 0
    name: str = ""
    score: int = 0
    off: bool = False
    day: str = ""                    # v2.9.0: the date the card should be taken (a card for tomorrow's open); empty = today


class PredPrefs(BaseModel):
    source: str | None = None
    add: str = ""
    remove: str = ""


@app.post("/api/predict/prefs")
def predict_prefs(r: PredPrefs):
    """v1.97 Predict tab: Auto (top 10 by score) or Manual (your own symbols, up to 20)."""
    if r.source in ("auto", "manual"):
        settings.pred_source = r.source
    cur = [x.upper() for x in settings.pred_manual]
    if r.source == "manual" and not cur and not r.add and not r.remove:      # empty manual list: start from the watchlist so the choice visibly does something
        cur = [w.upper() for w in settings.watchlist if w and w.replace(".", "").isalpha()][:20]
    for sym in [x for x in re.split(r"[\s,;]+", r.add.upper()) if x]:
        sym = _valid_sym(sym)
        if sym not in cur:
            cur.append(sym)
    if r.remove:
        cur = [x for x in cur if x != r.remove.upper()]
    if len(cur) > 20:
        raise HTTPException(400, "Manual list is limited to 20 symbols.")
    settings.pred_manual = cur
    settings.save()
    _mw_cache["data"] = None
    return {"source": settings.pred_source, "manual": settings.pred_manual}


@app.get("/api/wave/picks")
def wave_picks():
    e = need_engine()
    return {"picks": e.picks(upcoming=True)}


@app.post("/api/wave/pick")
def wave_pick(r: PickIn):
    """Arm (or disarm) a Pre-market card: the bot takes it today when price is in the zone, with the card's stop and target."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if r.off:
        return {"picks": e.set_pick(sym, None)}
    day = ""
    if r.day:
        try:
            dd = datetime.strptime(r.day, "%Y-%m-%d").date()
        except ValueError:
            raise HTTPException(400, "Bad date")
        today = e.broker.now().date()
        if dd > today + timedelta(days=5):
            raise HTTPException(400, "That setup is not for the next few days.")
        day = str(dd) if dd > today else ""        # v2.9.1: a window that started earlier (overnight cards) is simply today
    if r.side not in ("up", "down") or len(r.zone) != 2 or not (0 < r.zone[0] <= r.zone[1]):
        raise HTTPException(400, "That card has no usable entry zone.")
    lo, hi = r.zone
    if r.side == "up" and not (r.stop < lo and r.tp1 > hi):
        raise HTTPException(400, "For a buy the stop must be below the zone and the target above it.")
    if r.side == "down" and not (r.stop > hi and 0 < r.tp1 < lo):
        raise HTTPException(400, "For a short the stop must be above the zone and the target below it.")
    if r.side == "down" and not settings.allow_shorts and not getattr(e, "shorts_allowed", lambda: False)():
        raise HTTPException(400, "Shorting is off in Controls, so a Potential Fall card can't be traded automatically.")
    d = e.set_pick(sym, {"side": r.side, "zone": [lo, hi], "stop": r.stop, "tp1": r.tp1, "name": r.name[:60], "score": r.score}, day or None)
    e.event(f"Armed {sym} ({'buy' if r.side == 'up' else 'short'}) zone {lo:.2f}-{hi:.2f} stop {r.stop:.2f} target {r.tp1:.2f}: the bot takes it {('on ' + day) if day else 'today'} if price is in the zone")
    return {"picks": d}


@app.get("/api/wave")
def wave_get():
    return clean(_wave_state())


@app.post("/api/wave")
def wave_set(r: WaveIn):
    e = need_engine()
    if r.on is not None:
        settings.wave_trade = bool(r.on)
        e.event("Trade the wave switched " + ("ON" if settings.wave_trade else "OFF"), "info")
    if r.min_score is not None:
        settings.wave_min_score = max(40, min(95, int(r.min_score)))
    if r.from_min is not None:
        settings.wave_from = max(240, min(900, int(r.from_min)))
    if r.until_min is not None:
        settings.wave_until = max(300, min(930, int(r.until_min)))
    if r.max_trades is not None:
        settings.wave_max_trades = max(1, min(6, int(r.max_trades)))
    if r.risk_mult is not None:
        settings.wave_risk_mult = max(0.1, min(1.0, float(r.risk_mult)))
    settings.save()
    return clean(_wave_state())


def _wave_plan(r, px, size_fn):
    """v2.2: projected profit on the proposed purchase for one Predict card. size_fn(entry, stop) -> (qty, why) uses the bot's own risk sizing."""
    long = r.get("side") == "up"
    lo, hi = r["zone"]
    entry = float(px) if px and lo <= px <= hi else (lo + hi) / 2
    stop, tp1, tp2 = float(r["stop"]), float(r["tp1"]), float(r["tp2"])
    qty, why = size_fn(entry, stop)
    sgn = 1 if long else -1
    p1, p2, ls = sgn * (tp1 - entry), sgn * (tp2 - entry), sgn * (stop - entry)
    risk_ps = abs(entry - stop)
    atr = float(r.get("atr") or 0)
    out = {"long": long, "entry": round(entry, 2 if entry >= 1 else 4), "qty": int(qty), "why": why if not qty else "", "cost": round(qty * entry, 2),
           "tp1": round(qty * p1, 2), "tp2": round(qty * p2, 2), "stop": round(qty * ls, 2),
           "rr1": round(p1 / risk_ps, 2) if risk_ps else None, "rr2": round(p2 / risk_ps, 2) if risk_ps else None,
           "unlikely": bool(tp2 <= 0 or (atr and abs(tp2 - entry) > 1.6 * atr)), "poor": bool(risk_ps and p1 / risk_ps < 1.0)}
    return out


_r24_cache = {"at": 0.0, "key": "", "data": None}
_r24_lock = threading.Lock()


@app.get("/api/radar24")
def radar24(force: int = 0):
    """v2.9.1: one build at a time, so repeated taps or the auto-refresh can never pile up on a slow phone."""
    with _r24_lock:
        return _radar24_impl(force)


def _radar24_impl(force: int = 0):
    """v2.9.0: the 24-hour Radar board: every setup for the next 24 hours with buy window, sell-by time, stop, targets, hit rate and
    the projected profit on the proposed purchase (sized by the bot's own risk rules)."""
    import time as _tm
    from autobot import morningwave as mw
    from autobot import radar24 as r24
    e = need_engine()
    manual = settings.pred_source == "manual" and bool(settings.pred_manual)
    if manual:
        syms = [x for x in dict.fromkeys(list(settings.pred_manual)) if x and x.replace(".", "").isalpha()][:20]
    else:
        syms = list(dict.fromkeys([w.upper() for w in settings.watchlist] + MW_CORE
                                  + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])[:8]]))
        syms = [x for x in syms if x and x.replace(".", "").isalpha()][:30]
    now = e.broker.now()
    sess = _session_name(e)
    key = ",".join(syms) + "|" + settings.pred_source
    if not force and _r24_cache["data"] and _r24_cache["key"] == key and _tm.time() - _r24_cache["at"] < 300:
        return clean(dict(_r24_cache["data"], age_s=round(_tm.time() - _r24_cache["at"])))
    if not hasattr(e.broker, "bars15"):
        return clean({"items": [], "note": "Real data only (not in the simulator)", "asof": ""})
    try:
        bars = e.broker.bars15(syms, 45)
    except Exception as ex:
        raise HTTPException(502, f"Bar data failed: {str(ex)[:140]}")
    def tday(d):
        try:
            return e.broker.trading_day(d) is not None
        except Exception:
            return d.weekday() < 5
    items = []
    for mode in mw.MODES:
        rise, fall = mw.build(bars, 0.4, mode)
        for r in rise + fall:
            sc = r24.schedule_old(r, now, tday)
            if not sc:
                continue
            r.update(sc)
            items.append(r)
    for sym, d in bars.items():
        try:
            items += r24.analyze_new(sym, d, now, tday)
        except Exception:
            continue
    items = [r for r in items if r["exit_by"] > now and r["entry_from"] <= now + timedelta(hours=24)]
    # one card per symbol + setup family + window; keep the best score
    best = {}
    for r in items:
        k = (r["symbol"], r["kind"], r.get("mode"))
        if k not in best or r["score"] > best[k]["score"]:
            best[k] = r
    items = sorted(best.values(), key=lambda x: (-x["score"], x["entry_from"]))[:40]
    for r in items:
        try:
            pr = _price(e, r["symbol"], sess)
            px = pr.get("last")
            if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or px is None):
                px = (pr["bid"] + pr["ask"]) / 2
        except Exception:
            px = None
        r["price"] = round(px, 2) if px else None
        try:
            r["event"] = events.earnings_text(r["symbol"], now) or ""
        except Exception:
            r["event"] = ""
        try:
            def _sz(entry, stop):
                dec = e.risk.size(entry, stop, float(settings.wave_risk_mult), e._open_risk(), e.acct.get("buying_power", 0))
                q = int(dec.qty)
                bp = float(e.acct.get("buying_power", 0) or 0)
                if bp > 0 and q * entry > 0.95 * bp:
                    q = int(0.95 * bp / entry)
                return q, getattr(dec, "reason", "") or "size is 0 shares"
            r["plan"] = _wave_plan(r, px, _sz)
            p = r["plan"]
            if p and p.get("qty") and r.get("stop_rate") is not None:        # expected profit from this stock's own record (new types)
                win = r.get("p_win", 0) / 100
                p["ev"] = round(win * p["tp1"] + r["stop_rate"] / 100 * p["stop"], 2)
        except Exception:
            r["plan"] = None
        if px:
            lo, hi = r["zone"]
            r["zone_state"] = "IN ZONE" if lo <= px <= hi else ("above zone" if px > hi else "below zone")
        r["bucket"] = r24.bucket(r["entry_from"])
        r["entry_day"] = str(r["entry_from"].astimezone(r24.NY).date())
        r["buy_txt"] = r24.fmt(r["entry_from"], now) + " to " + r24.fmt(r["entry_to"], now).split(" ", 1)[-1] if r["entry_from"].date() == r["entry_to"].date() else r24.fmt(r["entry_from"], now) + " to " + r24.fmt(r["entry_to"], now)
        r["sell_txt"] = "by " + r24.fmt(r["exit_by"], now)
        for k in ("entry_from", "entry_to", "exit_by"):
            r[k] = r[k].isoformat()
    out = {"items": items, "asof": now.strftime("%a %b %-d, %-I:%M %p %Z"), "ts": round(_tm.time()), "age_s": 0, "scanned": len(bars),
           "session": sess, "limit": settings.daily_max_loss, "source": "manual" if manual else "auto"}
    _r24_cache.update(at=_tm.time(), key=key, data=out)
    return clean(out)


# ---------------- v2.10: one-stock review + reversal watch ----------------
from autobot.stockwatch import StockWatch  # noqa: E402
stockwatch = StockWatch(DATA_DIR / "stockwatch.json")
_rv_cache = {}


def _watch_px(e, sym):
    """Best current price at any hour: latest real trade (if recent) else the middle of the quote."""
    sess = _session_name(e)
    pr = _price(e, sym, sess)
    mid = (pr["bid"] + pr["ask"]) / 2 if pr.get("bid") and pr.get("ask") else pr.get("last")
    if sess != "REGULAR" and hasattr(e.broker, "last_trades"):
        lt = e.broker.last_trades([sym], sess).get(sym)
        if lt and (e.broker.now() - lt[1]).total_seconds() <= 1200:
            return lt[0]
    return mid or pr.get("last")


def _watch_loop():
    import time as _tm
    while True:
        _tm.sleep(60)
        try:
            if engine is None or not stockwatch.list():
                continue
            for sym in list(stockwatch.list()):
                px = _watch_px(engine, sym)
                stockwatch.tick(sym, px, lambda t, b, _s=sym: alerts.send("reversal", t, b, symbol=_s, level="warn", speak=t))
        except Exception:
            logging.exception("reversal watch tick failed")


threading.Thread(target=_watch_loop, daemon=True, name="stock-watch").start()


@app.get("/api/review")
def stock_review(symbol: str, force: int = 0):
    import time as _tm
    from autobot import review as rv
    e = need_engine()
    sym = _valid_sym(symbol)
    hit = _rv_cache.get(sym)
    if not force and hit and _tm.time() - hit[0] < 300:
        return clean(hit[1])
    if not hasattr(e.broker, "bars15"):
        return {"symbol": sym, "ok": False, "note": "Real market data is needed for a stock review (not available in the simulator)."}
    try:
        bars = e.broker.bars15([sym], 45)
        d = bars.get(sym)
    except Exception as ex:
        raise HTTPException(502, f"Bar data failed: {str(ex)[:140]}")
    if d is None or not len(d):
        return {"symbol": sym, "ok": False, "note": "No price history found for that symbol."}
    out = rv.review(sym, d, e.broker.now(), _watch_px(e, sym))
    try:
        p = (e.broker.positions() or {}).get(sym)
        out["position"] = {"qty": p["qty"], "side": "short" if p["qty"] < 0 else "long", "entry": p["avg_entry"]} if p else None
    except Exception:
        out["position"] = None
    out["watching"] = stockwatch.list().get(sym)
    _rv_cache[sym] = (_tm.time(), out)
    return clean(out)


class WatchIn(BaseModel):
    symbol: str
    side: str = "short"
    bounce_pct: float = 0.8
    cover: float = 0
    entry: float = 0
    qty: float = 0
    off: bool = False


@app.get("/api/watch")
def watch_list():
    return {"watches": clean(stockwatch.list())}


@app.post("/api/watch")
def watch_set(r: WatchIn):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if r.off:
        stockwatch.remove(sym)
        return {"watches": clean(stockwatch.list())}
    px = _watch_px(e, sym)
    if not px:
        raise HTTPException(400, "Could not get a price for that symbol right now.")
    ent, qty = (r.entry if r.entry > 0 else None), r.qty
    try:
        p = (e.broker.positions() or {}).get(sym)
        if p and not ent and ((p["qty"] < 0) == (r.side != "long")):
            ent, qty = p["avg_entry"], abs(p["qty"])
    except Exception:
        pass
    stockwatch.add(sym, r.side, float(px), max(0.3, min(5.0, r.bounce_pct)), r.cover if r.cover > 0 else None, ent)
    if ent:
        stockwatch.w[sym]["qty"] = qty
        stockwatch._save()
    e.event(f"Reversal watch on {sym} ({'short' if r.side != 'long' else 'long'}), alert on a {r.bounce_pct:.1f}% bounce from the low", "info")
    return {"watches": clean(stockwatch.list())}


# ---------------- v2.12: Day drives (4 windows) + Radar Autopilot + options self-test ----------------
from autobot import daydrive as dd  # noqa: E402
from autobot.autopilot import Autopilot, theme_of  # noqa: E402
_DD_FILE = DATA_DIR / "daydrive.json"
_DD = {"cfg": {"alert": True, "vol": 3.0, "move": 0.8}, "items": {w: {} for w in dd.WINDOWS}, "day": "", "hist_at": 0.0, "hist_key": "",
       "recs": {}, "slots": {}, "d15": {}, "last": 0.0, "scanned": 0, "alerted": [], "window": "", "note": "", "borrow": {}, "spy": (0.0, None)}
try:
    _DD["cfg"].update(json.loads(_DD_FILE.read_text()))
    _DD["cfg"].pop("bot", None)
except Exception:
    pass
_dd_lock = threading.Lock()
ap = Autopilot(DATA_DIR / "autopilot.json", DATA_DIR / "autopilot_log.json")


def _od_symbols(e):
    pos = []
    try:
        pos = list((e.broker.positions() or {}).keys())
    except Exception:
        pass
    syms = list(dict.fromkeys([w.upper() for w in settings.watchlist] + pos + MW_CORE + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])[:8]]))
    return [x for x in syms if x and x.replace(".", "").isalpha()][:30]


def _dd_close_min(e, now):
    try:
        td = e.broker.trading_day(now.date())
        if td:
            return td[1].hour * 60 + td[1].minute
    except Exception:
        pass
    return 960


def _dd_window(e, now):
    """Active window name or '' (also '' when the market is closed that day / night)."""
    cm = _dd_close_min(e, now)
    w = dd.window_for(now, cm)
    if not w:
        return "", cm
    try:
        day = now.date() + timedelta(days=1) if (w == "overnight" and now.hour >= 20) else now.date()
        if not e.broker.trading_day(day):
            return "", cm
    except Exception:
        pass
    return w, cm


def _dd_history(e, syms, now):
    import time as _tm
    key = ",".join(syms)
    if _DD["recs"] and _DD["hist_key"] == key and _tm.time() - _DD["hist_at"] < 6 * 3600:
        return
    feeds = (e.broker.feed,) if hasattr(e.broker, "feed") else None          # same data source as the live bars, so "volume vs normal" compares like with like
    hist = e.broker.bars15(syms, 45, feeds=feeds)
    recs, slots, d15 = {}, {}, {}
    for sym, d in hist.items():
        try:
            recs[sym], slots[sym] = dd.records_for(d)
            d15[sym] = d
        except Exception:
            pass
    _DD.update(recs=recs, slots=slots, d15=d15, hist_at=_tm.time(), hist_key=key)


def _spy_move(e):
    import time as _tm
    if _tm.time() - _DD["spy"][0] < 60:
        return _DD["spy"][1]
    mv = None
    try:
        pr = _price(e, "SPY", _session_name(e))
        if pr.get("last") and pr.get("prev_close"):
            mv = (pr["last"] / pr["prev_close"] - 1) * 100
    except Exception:
        pass
    _DD["spy"] = (_tm.time(), mv)
    return mv


def _ap_ctx(e, now):
    held = set()
    try:
        held = set((e.broker.positions() or {}).keys()) | set(e.trades.keys())
    except Exception:
        pass
    mine = {k: v for k, v in ap.state["armed"].items() if v.get("result") is None and not v.get("dry")}
    themes = {}
    for k in mine:
        themes[theme_of(k)] = themes.get(theme_of(k), 0) + 1
    # your own trades are never counted as autopilot's, and autopilot never adds to a stock you already hold
    held_manual = held - set(mine)
    return {"now_min": now.hour * 60 + now.minute, "taken_n": len(ap.state["taken"]), "open_n": len(mine), "spy_move": _spy_move(e),
            "theme_open": themes, "held": held_manual}


def _ap_take(e, c, now):
    """Act on one card that passed the Autopilot rules: arm the stock pick and/or open the option. Dry run = log only."""
    sym, up = c["symbol"], c["side"] == "up"
    cfg = ap.cfg
    dry = bool(cfg["dry"])
    nt = now.strftime("%-I:%M %p")
    desc = f"{c['name'].title()} score {c['score']}, record {c['hits']}/{c['n']}"
    did = False
    if cfg["instr"] in ("stocks", "both"):
        if dry:
            ap.log("would", f"WOULD {'BUY' if up else 'SHORT'} {sym} zone ${c['zone'][0]:.2f}-${c['zone'][1]:.2f}, stop ${c['stop']:.2f}, target ${c['tp1']:.2f} ({desc}). Log-only run: nothing was sent.", c["window"], sym, nt)
            did = True
        else:
            e.set_pick(sym, {"side": c["side"], "zone": c["zone"], "stop": c["stop"], "tp1": c["tp1"], "name": "AUTOPILOT " + c["name"],
                             "score": c["score"], "max_notional": cfg["max_notional"]})
            ap.state["armed"][sym] = {"day": str(now.date()), "window": c["window"], "side": c["side"], "t": nt, "result": None, "opened": False, "dry": False}
            ap.log("armed", f"{'BUY' if up else 'SHORT'} {sym} armed for the bot: zone ${c['zone'][0]:.2f}-${c['zone'][1]:.2f}, stop ${c['stop']:.2f}, target ${c['tp1']:.2f} ({desc}). Cancelled by the bot if not filled in 2 minutes.", c["window"], sym, nt)
            e.event(f"AUTOPILOT armed {sym} ({c['window']}, score {c['score']})", "info")
            try:
                alerts.send("entry", f"🤖 Autopilot armed {sym}", f"{c['name'].title()} · zone ${c['zone'][0]:.2f}-${c['zone'][1]:.2f} · stop ${c['stop']:.2f}", symbol=sym)
            except Exception:
                pass
            did = True
    if cfg["instr"] in ("options", "both"):
        direction = "call" if up else "put"
        ok, why = options_bot.autopilot_open(e, sym, direction, f"autopilot {c['window']}: {c['name'].lower()}", c["price"], dry=dry)
        if ok:
            d = options_bot.last_dry if dry else None
            txt = (f"WOULD BUY {d['qty']} {sym} {direction} {d['strikes']} exp {d['expiry']} limit ${d['limit']:.2f} (cost ${d['cost']:,.0f}). Log-only run." if d
                   else f"Options: bought a {direction} on {sym} (see the Options tab).")
            ap.log("would" if dry else "armed", txt, c["window"], sym, nt)
            did = True
        else:
            ap.log("skip", f"Options on {sym}: {why}", c["window"], sym, nt)
    if did:
        ap.state["taken"].append(sym)
        ap.save()


def _ap_consider(e, c, now, ctx):
    """Check one card against the Autopilot rules; log the reason when it is skipped (once per card per day)."""
    if not ap.cfg["on"]:
        return
    ok, why = ap.check(c, ctx)
    key = f"{c['window']}:{c['symbol']}:{why[:30]}"
    if not ok:
        if why in ("autopilot is off",) or f"{c['window']} window is on manual" == why:
            return
        seen = ap.state.setdefault("skipped", [])
        if key not in seen:
            seen.append(key)
            del seen[:-200]
            ap.log("skip", f"Skipped {c['symbol']} ({c['name'].title()}): {why}", c["window"], c["symbol"], now.strftime("%-I:%M %p"))
        return
    _ap_take(e, c, now)
    ctx.update(_ap_ctx(e, now))


def _ap_board24(e, now, ctx):
    d = _r24_cache.get("data")
    if not d or not ap.cfg["on"] or not ap.cfg["win"].get("board24"):
        return
    for r in d.get("items", []):
        try:
            a = datetime.fromisoformat(r["entry_from"])
            b = datetime.fromisoformat(r["entry_to"])
        except Exception:
            continue
        if not (a <= now <= b) or r.get("entry_day") != str(now.date()):
            continue
        n = int(r.get("n") or 0)
        c = {"symbol": r["symbol"], "side": r["side"], "window": "board24", "name": r.get("name", "24h setup"), "score": int(r.get("score", 0)),
             "has_record": n > 0, "n": n, "hits": round(n * float(r.get("hit_rate", 0)) / 100), "hit_rate": float(r.get("hit_rate", 0)),
             "zone": r["zone"], "stop": r["stop"], "tp1": r["tp1"], "price": r.get("price") or (r["zone"][0] + r["zone"][1]) / 2}
        _ap_consider(e, c, now, ctx)


def _ap_maintain(e, now):
    """Follow what Autopilot armed: note fills, closed results (the 4-losers rule), unfilled picks, the flat-by time and the evening summary."""
    day = str(now.date())
    ap.new_day(day)
    if not ap.state["armed"]:
        return
    try:
        pos = e.broker.positions() or {}
    except Exception:
        return
    nm = now.hour * 60 + now.minute
    fm = int(ap.cfg["flat_by"][:2]) * 60 + int(ap.cfg["flat_by"][3:])
    changed = False
    for sym, a in list(ap.state["armed"].items()):
        if a.get("result") is not None or a.get("dry"):
            continue
        if sym in pos:
            if not a.get("opened"):
                a["opened"], changed = True, True
                ap.log("filled", f"{sym} filled: {abs(pos[sym]['qty']):g} shares at about ${pos[sym]['avg_entry']:.2f}", a["window"], sym, now.strftime("%-I:%M %p"))
            if (not ap.cfg["hold_overnight"]) and a["window"] != "overnight" and nm >= fm and nm < 16 * 60:
                try:
                    _close_now(e, sym, 100, urgent=True)
                    ap.log("closed", f"{sym}: closed at the {ap.cfg['flat_by']} flat-by time (no overnight holds)", a["window"], sym, now.strftime("%-I:%M %p"))
                except Exception as ex:
                    ap.log("skip", f"{sym}: could not close at the flat-by time: {str(getattr(ex, 'detail', ex))[:80]}", a["window"], sym)
            continue
        if a.get("opened"):                                      # it was open and now it is gone: closed
            rows = db.closed_today(e.day if hasattr(e, "day") else day, sym)
            pnl = sum(float(r.get("pnl") or 0) for r in rows[-1:]) if rows else 0.0
            a["result"], changed = round(pnl, 2), True
            ap.log("result", f"{sym} closed: {'+' if pnl >= 0 else '-'}${abs(pnl):,.2f}", a["window"], sym, now.strftime("%-I:%M %p"))
            if ap.note_result(a["window"], pnl):
                ap.log("pause", f"{a['window'].title()} window paused: the last 4 autopilot trades all lost. Switch it on again to resume.", a["window"], "", now.strftime("%-I:%M %p"))
                try:
                    alerts.send("system", "Autopilot paused a window", f"{a['window'].title()}: last 4 trades lost. Switch it on again to resume.")
                except Exception:
                    pass
            continue
        if sym not in e.picks() and sym not in e.trades:         # never filled: the pick expired or the order was cancelled
            a["result"], changed = "none", True
            if sym in ap.state["taken"]:
                ap.state["taken"].remove(sym)
            ap.log("unfilled", f"{sym} was not filled (price left the zone or the order was cancelled); it does not count toward today's limit", a["window"], sym, now.strftime("%-I:%M %p"))
    if nm >= 16 * 60 + 5 and ap.state.get("summary_sent") != day and ap.cfg["on"]:
        ap.state["summary_sent"], changed = day, True
        mine = [a for a in ap.state["armed"].values() if a.get("day") == day and not a.get("dry")]
        tot = sum(a["result"] for a in mine if isinstance(a.get("result"), (int, float)))
        skipped = sum(1 for x in ap.logs if x["day"] == day and x["a"] == "skip")
        try:
            alerts.send("summary", "🤖 Autopilot today", f"{len(mine)} trade(s) armed, {skipped} skipped. Result {'+' if tot >= 0 else '-'}${abs(tot):,.2f}." + (" (Log-only run: nothing was traded.)" if ap.cfg["dry"] else ""))
        except Exception:
            pass
    if changed:
        ap.save()


def _dd_scan(force=False):
    """One pass: find the active window's breakouts, alert, let Autopilot consider them. At most one per 25 s."""
    import time as _tm
    e = engine
    if e is None or not hasattr(e.broker, "bars15"):
        return
    with _dd_lock:
        if _tm.time() - _DD["last"] < 25 and not force:
            return
        _DD["last"] = _tm.time()
        now = e.broker.now()
        try:
            _ap_maintain(e, now)
        except Exception:
            logging.exception("autopilot maintain failed")
        win, cm = _dd_window(e, now)
        _DD["window"] = win
        day = str(now.date())
        if _DD["day"] != day:
            _DD["day"] = day
            _DD["alerted"] = []
            for w in ("open", "lunch", "close"):
                _DD["items"][w] = {}
            if now.hour < 20:
                _DD["items"]["overnight"] = {k: v for k, v in _DD["items"]["overnight"].items() if now.hour < 10}
        if not win:
            return
        syms = _od_symbols(e)
        _dd_history(e, syms, now)
        if win == "overnight":
            start = now.replace(hour=16, minute=0, second=0, microsecond=0) - (timedelta(days=1) if now.hour < 16 else timedelta(0))
        else:
            start = now.replace(hour=4, minute=0, second=0, microsecond=0)
        try:
            today = e.broker.bars(syms, start)
        except Exception:
            return
        _DD["scanned"] = len(today)
        cfg = _DD["cfg"]
        ctx = _ap_ctx(e, now)
        fn = {"open": dd.detect_open, "lunch": dd.detect_lunch, "close": dd.detect_close, "overnight": dd.detect_overnight}[win]
        found = {}
        for sym, d1 in today.items():
            try:
                kw = {}
                if win == "close":
                    kw = {"d15": _DD["d15"].get(sym), "close_min": cm}
                c = fn(sym, d1, now, _DD["recs"].get(sym, {}), _DD["slots"].get(sym, {}), float(cfg["vol"]), float(cfg["move"]), **kw)
            except Exception:
                logging.exception("day drive %s %s failed", win, sym)
                c = None
            if not c:
                continue
            c["seen"] = now.strftime("%-I:%M %p")
            found[sym] = c
            key = f"{win}:{sym}:{c['side']}"
            if key not in _DD["alerted"]:
                _DD["alerted"].append(key)
                body = f"${c['price']:.2f} · {c['level_txt']} · volume {c['rvol']}x normal" + (f" · past record {c['hits']} of {c['n']} kept going" if c["has_record"] else "")
                title = f"{'🚀' if c['side'] == 'up' else '🔻'} {sym} {dd.LABEL[win].lower()} {'breakout' if c['side'] == 'up' else 'breakdown'}"
                if cfg.get("alert"):
                    alerts.send("opendrive", title, body, symbol=sym, level="info", speak=f"{sym} {dd.LABEL[win]} {'breakout' if c['side'] == 'up' else 'breakdown'}")
                e.event(f"Day drive ({win}): {sym} {body}", "info")
            _ap_consider(e, c, now, ctx)
        _DD["items"][win] = found if found or win != "overnight" else _DD["items"][win]
        if win == "close" and found:
            pass
        try:
            _ap_board24(e, now, ctx)
        except Exception:
            logging.exception("autopilot board24 failed")


def _dd_loop():
    import time as _tm
    while True:
        _tm.sleep(30)
        try:
            _dd_scan()
        except Exception:
            logging.exception("day drive scan failed")


threading.Thread(target=_dd_loop, daemon=True, name="day-drive").start()


def _borrow(e, sym):
    import time as _tm
    hit = _DD["borrow"].get(sym)
    if hit and _tm.time() - hit[0] < 120:
        return hit[1]
    out = None
    try:
        if hasattr(e.broker, "recheck_borrow"):
            ok, status = e.broker.recheck_borrow(sym)
            out = {"ok": bool(ok), "status": status, "at": e.broker.now().strftime("%-I:%M %p")}
    except Exception:
        out = None
    _DD["borrow"][sym] = (_tm.time(), out)
    return out


class DDCfg(BaseModel):
    alert: bool | None = None
    vol: float | None = None
    move: float | None = None


@app.get("/api/daydrives")
def daydrives_get(scan: int = 0):
    e = need_engine()
    if scan:
        try:
            _dd_scan(force=True)
        except Exception:
            logging.exception("day drive manual scan failed")
    now = e.broker.now()
    win, cm = _dd_window(e, now)
    items = []
    for w in dd.WINDOWS:
        for r in sorted(_DD["items"][w].values(), key=lambda x: -x["score"]):
            r = dict(r)
            try:
                def _sz(entry, stop):
                    dec = e.risk.size(entry, stop, float(settings.wave_risk_mult), e._open_risk(), e.acct.get("buying_power", 0))
                    q = int(dec.qty)
                    bp = float(e.acct.get("buying_power", 0) or 0)
                    if bp > 0 and q * entry > 0.95 * bp:
                        q = int(0.95 * bp / entry)
                    return q, getattr(dec, "reason", "") or "size is 0 shares"
                r["plan"] = _wave_plan(r, r["price"], _sz)
            except Exception:
                r["plan"] = None
            if r["side"] == "down":
                r["borrow"] = _borrow(e, r["symbol"])
                try:
                    ok, why = e._can_short(r["symbol"])
                    r["short_ok"], r["short_why"] = bool(ok), why
                except Exception:
                    pass
            if r["window"] == "close":
                r["mins_left"] = max(0, cm - (now.hour * 60 + now.minute))
                r["last_call"] = bool(r["side"] == "down" and r["mins_left"] <= 15)
            items.append(r)
    st_ = ap.state
    day = str(now.date())
    mine = [a for a in st_["armed"].values() if a.get("day") == day and not a.get("dry")]
    pnl = sum(a["result"] for a in mine if isinstance(a.get("result"), (int, float)))
    return clean({"items": items, "window": win, "windows": list(dd.WINDOWS), "cfg": _DD["cfg"], "scanned": _DD["scanned"], "asof": now.strftime("%-I:%M %p"),
                  "has_data": hasattr(e.broker, "bars15"), "close_min": cm, "mode": e.mode, "shorts_on": bool(ap.cfg["shorts"]),
                  "ap": {"cfg": ap.cfg, "taken": len(st_["taken"]), "open": sum(1 for a in mine if a.get("result") is None), "pnl": round(pnl, 2),
                         "log": ap.logs[:40], "results": st_.get("results", {}), "limit": settings.daily_max_loss, "live_pin_set": bool(live_pin())}})


@app.post("/api/daydrives/config")
def daydrives_cfg(r: DDCfg):
    c = _DD["cfg"]
    if r.alert is not None:
        c["alert"] = bool(r.alert)
    if r.vol is not None:
        c["vol"] = max(1.5, min(10.0, float(r.vol)))
    if r.move is not None:
        c["move"] = max(0.3, min(5.0, float(r.move)))
    try:
        _DD_FILE.write_text(json.dumps(c))
    except Exception:
        pass
    return {"cfg": c}


class APCfg(BaseModel):
    on: bool | None = None
    dry: bool | None = None
    win: dict | None = None
    buys: bool | None = None
    shorts: bool | None = None
    instr: str | None = None
    min_score: float | None = None
    min_rate: float | None = None
    min_n: float | None = None
    max_day: float | None = None
    max_open: float | None = None
    max_notional: float | None = None
    last_entry: str | None = None
    flat_by: str | None = None
    hold_overnight: bool | None = None
    spy_stop: float | None = None
    theme_cap: float | None = None
    pin: str = ""


@app.post("/api/autopilot/config")
def autopilot_cfg(r: APCfg, request: Request):
    e = need_engine()
    o = r.model_dump(exclude={"pin"})
    risky = (r.on is True and not ap.cfg["on"]) or (r.dry is False and ap.cfg["dry"]) or (r.shorts is True and not ap.cfg["shorts"]) or (r.instr in ("options", "both") and ap.cfg["instr"] == "stocks")
    if risky and e.mode == "LIVE":
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(403, "Set a Live PIN first (Settings), then you can switch Autopilot on for LIVE.")
        if not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
    was_on = ap.cfg["on"]
    ap.set_cfg(o)
    if r.on is True and not was_on:
        e.event(f"AUTOPILOT switched ON ({'log-only' if ap.cfg['dry'] else 'trading'}, {e.mode})", "warning")
        ap.log("on", f"Autopilot switched on ({'LOG ONLY: nothing will be traded' if ap.cfg['dry'] else 'TRADING'}, {e.mode} account)", "", "")
    if r.on is False and was_on:
        e.event("AUTOPILOT switched OFF", "warning")
        ap.log("off", "Autopilot switched off", "", "")
    if r.dry is False:
        ap.log("live", "Log-only mode turned OFF: autopilot will now send real orders", "", "")
    return {"ap": ap.cfg}


@app.post("/api/autopilot/close")
def autopilot_close():
    """Close every trade Autopilot opened and cancel what it armed. Your own trades are untouched."""
    e = need_engine()
    closed, cancelled = [], []
    try:
        pos = e.broker.positions() or {}
    except Exception:
        pos = {}
    for sym, a in list(ap.state["armed"].items()):
        if a.get("result") is not None or a.get("dry"):
            continue
        if sym in pos:
            try:
                _close_now(e, sym, 100, urgent=True)
                closed.append(sym)
            except Exception as ex:
                ap.log("skip", f"{sym}: could not close: {str(getattr(ex, 'detail', ex))[:80]}", a["window"], sym)
        elif sym in e.picks():
            e.set_pick(sym, None)
            cancelled.append(sym)
        a["result"] = "stopped"
    ap.cfg["on"] = False
    ap.log("off", f"Closed {len(closed)} autopilot trade(s) and cancelled {len(cancelled)} armed card(s); autopilot is off", "", "")
    ap.save()
    return {"closed": closed, "cancelled": cancelled}


@app.get("/api/daydrives/replay")
def daydrives_replay(window: str = "open", symbols: str = ""):
    """Rough 45-day replay of one window on your stocks (15-minute bars): what the rule would have done."""
    from autobot import daydrive as _dd
    e = need_engine()
    if window not in dd.WINDOWS:
        raise HTTPException(400, "Unknown window")
    if not hasattr(e.broker, "bars15"):
        return {"ok": False, "note": "Real market data is needed (not available in the simulator)."}
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip().replace(".", "").isalpha()][:30] or _od_symbols(e)
    feeds = (e.broker.feed,) if hasattr(e.broker, "feed") else None
    hist = _DD["d15"] if _DD["d15"] and all(s in _DD["d15"] for s in syms) else e.broker.bars15(syms, 45, feeds=feeds)
    rows, tot_n, tot_w, tot_r, tot_pct = [], 0, 0, 0.0, 0.0
    for sym in syms:
        d = hist.get(sym)
        if d is None:
            continue
        rp = _dd.replay(d, window)
        if rp["n"]:
            rows.append({"symbol": sym, **{k: rp[k] for k in ("n", "wins", "win_rate", "avg_r", "total_pct")}})
            tot_n += rp["n"]
            tot_w += rp["wins"]
            tot_r += rp["avg_r"] * rp["n"]
            tot_pct += rp["total_pct"]
    rows.sort(key=lambda x: -x["total_pct"])
    return clean({"ok": True, "window": window, "n": tot_n, "win_rate": round(tot_w / tot_n * 100) if tot_n else 0, "avg_r": round(tot_r / tot_n, 2) if tot_n else 0,
                  "avg_pct": round(tot_pct / tot_n, 2) if tot_n else 0, "total_pct": round(tot_pct, 1), "symbols": len(syms), "rows": rows[:12],
                  "note": "Rough: 15-minute bars, entry at the breakout bar's close, stop just back through the level, target 1.5x the risk. A bar that touches both counts as the stop. Past results do not promise future ones."})


@app.get("/api/options/selftest")
def options_selftest(symbol: str = "SPY"):
    """Checks that options can really trade from this app. Sends nothing."""
    from alpaca.trading.enums import AssetStatus, ContractType
    from alpaca.trading.requests import GetOptionContractsRequest
    from autobot import optionshub as oh
    e = need_engine()
    sym = _valid_sym(symbol)
    steps = []

    def add(name, ok, detail, warn=False):
        steps.append({"name": name, "ok": bool(ok), "warn": bool(warn), "detail": detail})
        return ok
    try:
        lvl = options_bot._account_level(e)
    except Exception as ex:
        lvl = None
        add("Account permission", False, "Could not read your Alpaca account: " + str(ex)[:100])
    if lvl is not None:
        add("Account permission", lvl >= 2, f"Options level {lvl}. " + ("Calls and puts are allowed." if lvl >= 2 else "Not approved for options yet. Request options trading in your Alpaca account."))
    try:
        acct = e.broker.trading.get_account()
        bp = float(getattr(acct, "options_buying_power", None) or getattr(acct, "buying_power", 0) or 0)
        add("Options buying power", bp >= 100, f"${bp:,.2f} available for options.")
    except Exception as ex:
        bp = 0.0
        add("Options buying power", False, "Could not read it: " + str(ex)[:100])
    sess = _session_name(e)
    add("Options hours", sess == "REGULAR", "The options market is open now." if sess == "REGULAR" else "The options market is closed right now (it trades 9:30 AM to 4 PM ET), so the test can check everything except a live order.", warn=sess != "REGULAR")
    add("Account mode", True, f"{e.mode} account." + (" Options are UNLOCKED for LIVE." if (e.mode != "LIVE" or settings.options_live_unlocked) else " Options are LOCKED for LIVE (unlock in the Options tab with your PIN)."), warn=(e.mode == "LIVE" and not settings.options_live_unlocked))
    contract = None
    try:
        bid, ask = _quote(e, sym, sess)
        spot = (bid + ask) / 2 if bid and ask else float((e.broker.price_info(sym) or {}).get("last") or 0)
        today = e.broker.now().date()
        tr, _ = _hub_clients(e)
        res = tr.get_option_contracts(GetOptionContractsRequest(
            underlying_symbols=[sym], status=AssetStatus.ACTIVE, type=ContractType.CALL, expiration_date_gte=today + timedelta(days=5),
            expiration_date_lte=today + timedelta(days=40), strike_price_gte=str(round(spot * 0.97, 2)), strike_price_lte=str(round(spot * 1.03, 2)), limit=200))
        cs = [c for c in (getattr(res, "option_contracts", None) or []) if getattr(c, "tradable", True)]
        if not cs:
            add("Option chain", False, f"No tradable contracts found for {sym}.")
        else:
            cs.sort(key=lambda c: (str(c.expiration_date), abs(float(c.strike_price) - spot)))
            c0 = cs[0]
            contract = c0.symbol
            add("Option chain", True, f"Found {len(cs)} contracts near the price of {sym} (${spot:,.2f}). Using {c0.symbol}.")
    except Exception as ex:
        add("Option chain", False, "Could not load the chain: " + str(ex)[:120])
    q = {}
    if contract:
        try:
            q = _hub_snaps(e, [contract]).get(contract) or {}
            b_, a_ = q.get("bid"), q.get("ask")
            if b_ and a_ and a_ >= b_:
                gap = (a_ - b_) / a_ * 100
                add("Quote", True, f"Bid ${b_:.2f}, ask ${a_:.2f}, gap {gap:.1f}%." + (" The gap is wide: expect poor fills." if gap > 15 else ""), warn=gap > 15)
            else:
                add("Quote", False, "No live bid/ask on that contract right now (normal when the market is closed).", warn=True)
        except Exception as ex:
            add("Quote", False, "Could not read the quote: " + str(ex)[:100])
    if contract and q.get("ask"):
        px = round(float(q["ask"]), 2)
        err = oh.check_order(side="buy", qty=1, limit=px, held_qty=0, bp=bp, level=lvl, market_open=(sess == "REGULAR"), halted=bool(e.risk.halted),
                             live=(e.mode == "LIVE"), live_unlocked=bool(settings.options_live_unlocked), pin_given_ok=True, confirm=True, managed_by_bot=False)
        cap = float(settings.options_max_premium)
        cost = px * 100
        add("Order dry run", err is None, (f"Would buy 1 contract at a limit of ${px:.2f} (cost ${cost:,.0f}). All order checks pass." if err is None else "The order checks would stop it: " + err)
            + (f" Your per-contract premium cap is ${cap:,.0f}." if cost > cap else ""), warn=cost > cap)
    ok_all = all(s["ok"] or s["warn"] for s in steps)
    return clean({"symbol": sym, "steps": steps, "ok": ok_all, "contract": contract, "ask": q.get("ask"), "bid": q.get("bid"), "mode": e.mode, "level": lvl,
                  "can_trade_test": bool(contract and q.get("ask") and sess == "REGULAR" and (lvl or 0) >= 2)})


class SelfTestTrade(BaseModel):
    symbol: str = "SPY"
    confirm: bool = False
    pin: str = ""


@app.post("/api/options/selftest/trade")
def options_selftest_trade(r: SelfTestTrade, request: Request):
    """Buy ONE contract at the ask, wait for the fill, sell it back at the bid. Paper: free. Live: shows the cost and needs the PIN."""
    import time as _tm
    from alpaca.trading.enums import OrderSide, PositionIntent, TimeInForce
    from alpaca.trading.requests import LimitOrderRequest
    e = need_engine()
    st_ = options_selftest(r.symbol)
    if not st_.get("can_trade_test"):
        raise HTTPException(400, "The live test needs the options market open, an approved account and a contract with a live quote. Run the checks first.")
    live = e.mode == "LIVE"
    ask, bid, contract = float(st_["ask"]), float(st_.get("bid") or 0), st_["contract"]
    if live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not r.confirm or not live_pin() or not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, f"This is a LIVE account: the test buys 1 contract (about ${ask * 100:,.0f}) and sells it straight back. Confirm with your Live PIN.")
        if not settings.options_live_unlocked:
            raise HTTPException(403, "Options are locked for LIVE. Unlock them in the Options tab first.")
    tr = e.broker.trading
    log = []
    try:
        o = tr.submit_order(LimitOrderRequest(symbol=contract, qty=1, side=OrderSide.BUY, time_in_force=TimeInForce.DAY, limit_price=round(ask, 2),
                                              position_intent=PositionIntent.BUY_TO_OPEN))
    except Exception as ex:
        raise HTTPException(502, "Alpaca refused the test order: " + str(ex)[:160])
    fill = None
    for _ in range(25):
        _tm.sleep(2)
        try:
            o2 = tr.get_order_by_id(o.id)
        except Exception:
            continue
        if str(getattr(o2, "status", "")).lower().endswith("filled") and float(getattr(o2, "filled_qty", 0) or 0) >= 1:
            fill = float(o2.filled_avg_price)
            break
    if fill is None:
        try:
            tr.cancel_order_by_id(o.id)
        except Exception:
            pass
        return {"ok": False, "log": ["Bought: the order did not fill in 50 seconds, so it was cancelled. Nothing is open."], "contract": contract}
    log.append(f"Bought 1 {contract} at ${fill:.2f} (cost ${fill * 100:,.2f}).")
    sold = None
    sell_px = round(max(0.01, bid or fill * 0.95), 2)
    for attempt in range(3):
        try:
            so = tr.submit_order(LimitOrderRequest(symbol=contract, qty=1, side=OrderSide.SELL, time_in_force=TimeInForce.DAY, limit_price=sell_px,
                                                   position_intent=PositionIntent.SELL_TO_CLOSE))
        except Exception as ex:
            log.append("Sell order refused: " + str(ex)[:100])
            break
        for _ in range(12):
            _tm.sleep(2)
            try:
                s2 = tr.get_order_by_id(so.id)
            except Exception:
                continue
            if str(getattr(s2, "status", "")).lower().endswith("filled"):
                sold = float(s2.filled_avg_price)
                break
        if sold is not None:
            break
        try:
            tr.cancel_order_by_id(so.id)
        except Exception:
            pass
        sell_px = round(max(0.01, sell_px * 0.9), 2)
    if sold is None:
        log.append(f"⚠ The contract is still OPEN. Close it from the Options tab (Sell). It could not be sold at the bid within the time limit.")
        return {"ok": False, "log": log, "contract": contract, "open": True}
    log.append(f"Sold at ${sold:.2f}.")
    net = (sold - fill) * 100
    log.append(f"Round trip result: {'+' if net >= 0 else '-'}${abs(net):,.2f} (this is the cost of the bid/ask gap). Options trading works from this app.")
    options_bot.ev(f"SELF-TEST round trip on {contract}: bought ${fill:.2f}, sold ${sold:.2f}", "warning")
    return {"ok": True, "log": log, "contract": contract, "net": round(net, 2)}


# ---------------- v2.13: Jump in / Jump out signals + tap-to-trade ----------------
from autobot import jump as jp  # noqa: E402

_JP_FILE = DATA_DIR / "jump.json"
_JP = {"cfg": {"alert": True, "tap": "ask", "strong_only": True}, "last_alert": {}, "items": [], "alerted": [], "rec": {}, "last": 0.0, "scanned": 0, "asof": "", "hist_n": 0}
try:
    _JP["cfg"].update(json.loads(_JP_FILE.read_text()))
except Exception:
    pass
_jp_lock = threading.Lock()


def _jp_symbols(e):
    pos = {}
    try:
        pos = e.broker.positions() or {}
    except Exception:
        pass
    dd_syms = []
    try:
        for w in dd.WINDOWS:
            dd_syms += list(_DD["items"][w].keys())
    except Exception:
        pass
    syms = list(dict.fromkeys(list(pos.keys()) + [w.upper() for w in settings.watchlist][:8] + dd_syms))
    return [x for x in syms if x and x.replace(".", "").isalpha()][:14], pos


def _jp_record(e, sym):
    """This stock's own record of jump-in signals (45 days of 5-minute bars). Cached 6 hours; at most a few fetches per scan."""
    import time as _tm
    c = _JP["rec"].get(sym)
    if c and _tm.time() - c[0] < 6 * 3600:
        return c[1]
    if _JP["hist_n"] >= 3:
        return c[1] if c else None
    _JP["hist_n"] += 1
    try:
        d = e.broker.bars5(sym, 45)
        rec = jp.record(d) if d is not None else None
    except Exception:
        rec = None
    if rec is not None:
        _JP["rec"][sym] = (_tm.time(), rec)
    return rec


def _jp_card(e, s, sym, rec, price):
    up = s["side"] == "up"
    r = (rec or {}).get(s["side"], {"n": 0, "hit": 0, "fail": 0})
    n, hit = r["n"], r["hit"]
    rate = round(hit / n * 100) if n >= 5 else None
    score = int(max(40, min(95, 55 + ((rate - 50) * 0.6 if rate is not None else 0) + (8 if s.get("kind") == "in" else 0))))
    c = {"symbol": sym, "side": s["side"], "window": "jump", "jump": s["kind"], "kind": s["kind"], "name": s["name"], "why": s["why"], "t": s["t"], "score": score,
         "label": "STRONG" if score >= 75 else "GOOD" if score >= 62 else "WEAK", "price": round(float(price), 2), "n": n, "hits": hit, "fails": r["fail"],
         "hit_rate": rate if rate is not None else 0, "has_record": rate is not None, "move_pct": 1.0, "entry_day": "", "warn": []}
    if s["kind"] == "in":
        c.update(zone=s["zone"], stop=s["stop"], tp1=s["tp1"], tp2=s["tp2"], atr=s.get("atr", 0), level=s["price"], level_txt=s["name"])
    return c


def _jp_tidy(items, strong_only):
    """v2.17.3: one card per stock and kind (the newest wins), and with strong_only the WEAK "jump in" cards are hidden.
    Jump OUT / don't-chase cards are never hidden: they are about positions you hold."""
    out, seen = [], set()
    for x in sorted(items, key=lambda r: (str(r.get("day", "")), r.get("t", "")), reverse=True):
        if strong_only and x.get("kind") == "in" and x.get("label") == "WEAK":
            continue
        k = (x["symbol"], x["kind"])
        if k in seen:
            continue
        seen.add(k)
        out.append(x)
    return out


# ---------------- v2.24: 🌙 Overnight shorts (picked 4:05-7:45 PM, entered before 8 PM, held with broker GTC stop/target, covered by the open) ----------------
from autobot import onshort as ons  # noqa: E402
_ONS = {"day": "", "cands": [], "at": "", "built": 0.0, "daily": {}, "alerted": "", "log": [], "err": ""}


def _ons_window(e, now):
    """(ok, why): Mon-Thu evenings 4:05-7:45 PM ET with a trading day tomorrow."""
    mm = now.hour * 60 + now.minute
    if now.weekday() >= 4:
        return False, "no trading day tomorrow (Friday/weekend): no overnight shorts over the weekend"
    if mm < 16 * 60 + 5:
        return False, "candidates build at 4:05 PM ET"
    if mm >= 19 * 60 + 45:
        return False, "entry window closed at 7:45 PM ET (no new shorts after 8 PM)"
    return True, ""


def _ons_build(e, now):
    import time as _tm
    cfg = ons.load()
    syms = list(dict.fromkeys(list((e.broker.positions() or {}).keys()) + [w.upper() for w in settings.watchlist][:8] + MW_CORE
                              + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])[:8]]))
    syms = [x for x in syms if x and x.replace(".", "").isalpha()][:24]
    if _ONS["day"] != str(now.date()):
        _ONS.update(day=str(now.date()), daily={}, cands=[], alerted="", log=[])
    for sym in syms:
        if sym not in _ONS["daily"]:
            try:
                _ONS["daily"][sym] = e.broker.daily_bars(sym, 90)
            except Exception:
                _ONS["daily"][sym] = None
    daily = {k: v for k, v in _ONS["daily"].items() if k in syms and v is not None and len(v) > 25}
    d1 = e.broker.bars(list(daily.keys()))
    stats = {}
    for sym, d in daily.items():
        b = d1.get(sym)
        if b is None or len(b) < 10:
            continue
        pc = d[d.index.date < now.date()]
        if not len(pc):
            continue
        reg = b[(b.index.hour * 60 + b.index.minute >= 570) & (b.index.hour * 60 + b.index.minute < 960)]
        r_ = reg if len(reg) else b
        tp = (r_["high"] + r_["low"] + r_["close"]) / 3
        vw = float((tp * r_["volume"]).sum() / max(r_["volume"].sum(), 1))
        stats[sym] = {"last": float(b["close"].iloc[-1]), "prev_close": float(pc["close"].iloc[-1]), "vwap": vw}
    try:
        tonight = {k: v for k, v in events.earnings_on(now.date()).items() if k in stats}
    except Exception:
        tonight = {}
    pos = e.broker.positions() or {}
    held = {k: abs(float(v.get("qty") or 0) * float(v.get("price") or stats.get(k, {}).get("last") or 0)) for k, v in pos.items()}
    spreads = {}
    try:
        for sym in list(stats)[:24]:
            b_, a_ = _quote(e, sym, "AFTER")
            if b_ and a_ and a_ >= b_:
                spreads[sym] = (a_ - b_) / a_ * 100
    except Exception:
        pass
    eq = float((e.acct or {}).get("equity") or getattr(e.risk, "equity", 0) or 0)
    cands = ons.build(stats, daily, tonight, cfg, eq, float(getattr(e.risk, "remaining", 0) or 0), held, spreads)
    _ONS.update(cands=cands, at=now.strftime("%I:%M %p").lstrip("0"), built=_tm.time(), err="")
    return cands


def _ons_place(e, c, now, cfg, why_prefix=""):
    """Sends the evening limit-sell and registers it with the engine's overnight follow-up (GTC stop+target once filled, cover by the open)."""
    import uuid
    sym = c["symbol"]
    ok, why = e._can_short(sym)
    if not ok:
        raise RuntimeError(why)
    if e._margin_block():
        raise RuntimeError("buying power is nearly used up")
    if e.risk.halted or e.risk.remaining <= 0:
        raise RuntimeError("the daily loss limit is used up")
    held = [x for x, o in e.overnight.items() if o.get("stage") in ("entry", "held")]
    if len(held) >= 2:
        raise RuntimeError("2 overnight shorts are already open")
    if sym in e.overnight or sym in e.positions or sym in e.trades:
        raise RuntimeError(f"{sym} is already open")
    total_open = sum(abs(float(p.get("qty") or 0) * float(p.get("price") or 0)) for k, p in (e.broker.positions() or {}).items() if k in e.overnight)
    qty = ons.size(c, cfg, total_open, float(e.risk.remaining), float(e.acct.get("buying_power", 0) or 0))
    if qty < 1:
        raise RuntimeError("size came out under 1 share (caps, loss room or buying power)")
    b_, a_ = _quote(e, sym, "AFTER")
    px = round(float(b_ or c["price"]) * 0.999, 2)
    oid = e.broker.manual_order(sym, "sell", qty, "limit", limit_price=px, extended=True, client_id=f"onsh-{uuid.uuid4().hex[:12]}", tif="day")
    e.overnight[sym] = {"stage": "entry", "order_id": oid, "qty": qty, "stop": c["stop"], "target": c["target"], "entry_ref": px, "kind": "EVENING_" + c["kind"].upper(),
                        "opened": now.isoformat(), "day": e.day, "why": c["why"], "ev": True, "cover_hm": 9 * 60 + 35}
    e._save_overnight()
    e.event(f"Overnight short {sym}: {qty} sh limit @ {px} ({c['why']}); GTC stop {c['stop']:.2f} / target {c['target']:.2f} go on once filled; covers by the open")
    return qty, px


def _ons_pass(e, now):
    cfg = ons.load()
    day = str(now.date())
    try:                                           # always follow open overnight shorts (fills -> GTC exits, morning cover), even outside the window
        if e.overnight:
            e.positions = e.broker.positions()
            e._overnight_tick(now, e.broker.clock())
    except Exception:
        logging.exception("overnight shorts follow-up failed")
    if not cfg["on"]:
        return
    ok, why = _ons_window(e, now)
    _ONS["err"] = "" if ok else why
    if not ok:
        return
    import time as _tm
    if _tm.time() - _ONS["built"] < 540 and _ONS["day"] == day:
        return
    cands = _ons_build(e, now)
    live = e.mode == "LIVE"
    good = [c for c in cands if c["kind"] in ("group", "earnings") and c.get("cap", 0) > 0]
    if good and _ONS["alerted"] != day:
        _ONS["alerted"] = day
        alerts.send("movers", "🌙 Overnight short candidates", "; ".join(f"{c['symbol']} ({c['why'][:40]})" for c in good[:4]), level="info")
    if cfg["mode"] != "place" or not good:
        return
    if live and _PR.get("armed") != day:
        if good and not _ONS.get("armmsg") == day:
            _ONS["armmsg"] = day
            _ONS["log"].append(f"{now.strftime('%-I:%M %p')} LIVE: candidates found but not placed. Arm today with your PIN, or tap Place on a card.")
        return
    for c in good[:2]:
        try:
            q, px = _ons_place(e, c, now, cfg)
            _ONS["log"].append(f"{now.strftime('%-I:%M %p')} {c['symbol']}: short {q} @ {px} sent ({c['why'][:50]})")
            alerts.send("movers", f"🌙 Overnight short ({'LIVE' if live else 'paper'}): {c['symbol']}", f"{q} sh limit @ {px}, stop {c['stop']}, target {c['target']}. Covers by the open.", symbol=c["symbol"], level="info")
        except RuntimeError as ex:
            _ONS["log"].append(f"{now.strftime('%-I:%M %p')} {c['symbol']}: not placed: {ex}")
        except Exception as ex:
            logging.exception("overnight short place failed")
            _ONS["log"].append(f"{now.strftime('%-I:%M %p')} {c['symbol']}: failed: {str(ex)[:100]}")
    _ONS["log"] = _ONS["log"][-12:]


def _ons_loop():
    import time as _tm
    while True:
        _tm.sleep(60)
        try:
            e = engine
            if e and not ARGS.sim:
                _ons_pass(e, e.broker.now())
        except Exception as ex:
            _ONS["err"] = str(ex)[:100]
            logging.warning("overnight shorts: %s", ex)


threading.Thread(target=_ons_loop, daemon=True, name="overnight-shorts").start()


class OnsCfg(BaseModel):
    on: bool | None = None
    mode: str | None = None
    earn: bool | None = None
    max_each: float | None = None
    max_total: float | None = None


def _ons_state():
    e = engine
    cfg = ons.load()
    held = []
    try:
        for sym, o in (e.overnight or {}).items():
            held.append({"symbol": sym, "stage": o.get("stage"), "qty": o.get("qty"), "stop": o.get("stop"), "target": o.get("target"), "why": o.get("why", "")})
    except Exception:
        pass
    ok, why = _ons_window(e, e.broker.now()) if e else (False, "")
    return {"cfg": cfg, "cands": _ONS["cands"], "at": _ONS["at"], "held": held, "log": _ONS["log"][-8:], "window_ok": ok, "window_note": why,
            "live": bool(e and e.mode == "LIVE"), "armed": _PR.get("armed") == (str(e.broker.now().date()) if e else ""), "err": _ONS["err"]}


@app.get("/api/onshort")
def onshort_get():
    return clean(_ons_state())


@app.post("/api/onshort/config")
def onshort_config(r: OnsCfg):
    c = ons.load()
    for k in ("on", "mode", "earn", "max_each", "max_total"):
        v = getattr(r, k)
        if v is not None:
            c[k] = v
    ons.save(c)
    if engine:
        engine.event(f"Overnight shorts: {'ON' if ons.load()['on'] else 'OFF'} ({ons.load()['mode']}, earnings shorts {'ON' if ons.load()['earn'] else 'off'})")
    return clean(_ons_state())


class OnsPlace(BaseModel):
    symbol: str


@app.post("/api/onshort/place")
def onshort_place(r: OnsPlace):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    now = e.broker.now()
    ok, why = _ons_window(e, now)
    if not ok:
        raise HTTPException(400, why)
    c = next((x for x in _ONS["cands"] if x["symbol"] == sym and x["kind"] in ("group", "earnings")), None)
    if not c:
        raise HTTPException(404, f"{sym} is not a current candidate. Refresh the list.")
    try:
        q, px = _ons_place(e, c, now, ons.load())
    except RuntimeError as ex:
        raise HTTPException(400, f"Can't short {sym}: {ex}")
    except Exception as ex:
        raise HTTPException(400, "Alpaca rejected it: " + str(ex)[:160])
    return {"ok": True, "msg": f"Short {q} {sym} limit @ {px} sent. Stop {c['stop']} / target {c['target']} go on once it fills; it covers by the open."}


@app.post("/api/onshort/refresh")
def onshort_refresh():
    e = need_engine()
    now = e.broker.now()
    ok, why = _ons_window(e, now)
    if not ok:
        raise HTTPException(400, why)
    try:
        _ons_build(e, now)
    except Exception as ex:
        raise HTTPException(502, "Could not build: " + str(ex)[:120])
    return clean(_ons_state())


# ---------------- v2.23: Radar always scanning ----------------
_RADAR_FILE = DATA_DIR / "radar.json"
_RADAR = {"last": 0.0, "n": 0, "err": "", "sess": ""}


def _radar_always():
    try:
        return bool(json.loads(_RADAR_FILE.read_text()).get("always", True))
    except Exception:
        return True                                   # on unless you switch it off


def _radar_loop():
    """With the switch ON, Radar refreshes by itself every minute around the clock (pre-market, regular, after-hours, overnight, 24/5),
    whether or not you have the Radar tab open and whether or not the Auto-trader is running. It only reads prices and builds lists:
    it places no orders. Weekend: the weekend loop above already rebuilds the plan on Sunday evening."""
    import time as _tm
    while True:
        _tm.sleep(60)
        try:
            e = engine
            if not e or ARGS.sim or not _radar_always():
                continue
            now = e.broker.now()
            if _weekend_gap(now):
                continue
            _RADAR["sess"] = _session_name(e)
            _jp_scan(force=True)
            morning_wave(0, "", 0.4, "")
            predict_watchlist(3, 0)
            _RADAR["last"], _RADAR["n"], _RADAR["err"] = _tm.time(), _RADAR["n"] + 1, ""
        except Exception as ex:
            _RADAR["err"] = str(ex)[:100]
            logging.warning("radar always: %s", ex)


class RadarAlways(BaseModel):
    on: bool


def _radar_weekend():
    try:
        return bool(engine and _weekend_gap(engine.broker.now()))
    except Exception:
        return False


def _radar_status():
    import time as _tm
    on = _radar_always()
    return {"on": on, "age_s": round(_tm.time() - _RADAR["last"]) if _RADAR["last"] else None, "scans": _RADAR["n"], "err": _RADAR["err"],
            "session": _RADAR["sess"], "weekend": _radar_weekend()}


@app.get("/api/radar/always")
def radar_always_get():
    return _radar_status()


@app.post("/api/radar/always")
def radar_always_set(r: RadarAlways):
    try:
        _RADAR_FILE.write_text(json.dumps({"always": bool(r.on)}))
    except Exception:
        pass
    if engine:
        engine.event("Radar always scanning: " + ("ON" if r.on else "OFF"))
    return _radar_status()


def _jp_scan(force=False):
    import time as _tm
    e = engine
    if e is None:
        return
    if not force and _tm.time() - _JP["last"] < 55:
        return
    with _jp_lock:
        _JP["last"] = _tm.time()
        _JP["hist_n"] = 0
        now = e.broker.now()
        sess = _session_name(e)
        syms, pos = _jp_symbols(e)
        if not syms or not hasattr(e.broker, "bars"):
            return
        if sess != "REGULAR" and not force and not _radar_always():       # v2.23: the Always-scanning switch keeps Radar signals running in every session
            _JP["items"] = [x for x in _JP["items"] if x.get("day") == str(now.date())]
            return
        try:
            _st = now.replace(hour=9, minute=30, second=0, microsecond=0) - timedelta(minutes=1)
            if _st >= now:                      # before the open: a start in the future makes Alpaca answer 400
                _st -= timedelta(days=1)
            d1 = e.broker.bars(syms, _st)
        except Exception:
            logging.exception("jump scan: bars failed")
            return
        items, fresh = [], []
        for sym in syms:
            d = d1.get(sym)
            d5 = jp.to5(d) if d is not None else None
            if d5 is None or len(d5) < 32:
                continue
            if d5.index[-1] + timedelta(minutes=5) > now:      # the newest bucket is still forming
                d5 = d5.iloc[:-1]
                if len(d5) < 32:
                    continue
            held = None
            try:
                q = float((pos.get(sym) or {}).get("qty") or 0)
                held = "up" if q > 0 else "down" if q < 0 else None
            except Exception:
                pass
            try:
                _pr_live(e, sym, d5, held, now, sess)
            except Exception:
                logging.exception("preset live check failed")
            sigs = [s for s in jp.scan(d5, tail=3) if s["i"] >= len(d5) - 3]
            rec = _jp_record(e, sym)
            for s in sigs:
                if s["kind"] == "out" and s["side"] != held:
                    continue
                if s["kind"] == "in" and held:
                    continue
                card = _jp_card(e, s, sym, rec, d5["close"].iloc[-1])
                card["day"] = str(now.date())
                card["held"] = bool(held)
                items.append(card)
                key = f"{now.date()}:{sym}:{s['kind']}:{s['side']}:{s['t']}"
                if key not in _JP["alerted"]:
                    _JP["alerted"].append(key)
                    del _JP["alerted"][:-300]
                    fresh.append(card)
        try:
            _pr_universe_pass(e, now, sess, syms, pos, _st)
        except Exception:
            logging.exception("preset universe pass failed")
        try:
            _plan_pass(e, now, sess, pos)
        except Exception:
            logging.exception("morning plan pass failed")
        keep = [x for x in _JP["items"] if x.get("day") == str(now.date()) and (x["symbol"], x["kind"], x["side"], x["t"]) not in {(y["symbol"], y["kind"], y["side"], y["t"]) for y in items}]
        _JP["items"] = _jp_tidy(items + keep, False)[:30]
        _JP["scanned"], _JP["asof"] = len(syms), now.strftime("%-I:%M %p")
        if _JP["cfg"].get("alert"):
            for c in fresh:
                try:
                    if _JP["cfg"].get("strong_only", True) and c["kind"] == "in" and c.get("label") == "WEAK":
                        continue                       # weak setups stay on the list only
                    ak = f"{c['symbol']}:{c['kind']}"
                    if _tm.time() - _JP["last_alert"].get(ak, 0) < 1800:
                        continue                       # same stock and kind: at most one alert per 30 minutes
                    _JP["last_alert"][ak] = _tm.time()
                    if c["kind"] == "in":
                        up = c["side"] == "up"
                        body = f"{c['name']} · zone ${c['zone'][0]:.2f}-${c['zone'][1]:.2f} · stop ${c['stop']:.2f} · target ${c['tp1']:.2f}" + (f" · record {c['hits']}/{c['n']}" if c["has_record"] else " · not enough history")
                        alerts.send("jump", f"{'🟢 JUMP IN, buy' if up else '🔴 JUMP IN, short'} {c['symbol']}", body, symbol=c["symbol"], level="info")
                    elif c["kind"] == "out":
                        alerts.send("jump", f"🚪 JUMP OUT {c['symbol']}", c["why"], symbol=c["symbol"], level="warning")
                    else:
                        alerts.send("jump", f"⚠ Don't chase {c['symbol']}", c["why"], symbol=c["symbol"])
                except Exception:
                    pass


def _jp_loop():
    import time as _tm
    while True:
        _tm.sleep(20)
        try:
            _jp_scan()
        except Exception:
            logging.exception("jump loop")


threading.Thread(target=_jp_loop, daemon=True, name="jump-signals").start()


class JPCfg(BaseModel):
    alert: bool | None = None
    strong_only: bool | None = None
    tap: str | None = None          # off | ask | auto
    pin: str = ""


@app.get("/api/jump")
def jump_get(scan: int = 0):
    e = need_engine()
    if scan:
        try:
            _jp_scan(force=True)
        except Exception:
            logging.exception("jump manual scan failed")
    items = _jp_tidy(_JP["items"], bool(_JP["cfg"].get("strong_only", True)))
    for r in items:
        if r.get("kind") == "in":
            try:
                def _sz(entry, stop):
                    dec = e.risk.size(entry, stop, float(settings.wave_risk_mult), e._open_risk(), e.acct.get("buying_power", 0))
                    q = int(dec.qty)
                    bp = float(e.acct.get("buying_power", 0) or 0)
                    if bp > 0 and q * entry > 0.95 * bp:
                        q = int(0.95 * bp / entry)
                    return q, getattr(dec, "reason", "") or "size is 0 shares"
                r["plan"] = _wave_plan(r, r["price"], _sz)
            except Exception:
                r["plan"] = None
    return clean({"items": items, "cfg": _JP["cfg"], "scanned": _JP["scanned"], "asof": _JP["asof"], "mode": e.mode, "session": _session_name(e), "live_pin_set": bool(live_pin())})


@app.post("/api/jump/config")
def jump_cfg(r: JPCfg, request: Request):
    e = need_engine()
    c = _JP["cfg"]
    if r.alert is not None:
        c["alert"] = bool(r.alert)
    if r.strong_only is not None:
        c["strong_only"] = bool(r.strong_only)
    if r.tap is not None:
        if r.tap not in ("off", "ask", "auto"):
            raise HTTPException(400, "Tap mode must be off, ask or auto")
        if r.tap == "auto" and c.get("tap") != "auto" and e.mode == "LIVE":
            ip = "pin:" + auth.client_ip(request)
            if auth.rate_limited(ip):
                raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
            if not live_pin():
                raise HTTPException(403, "Set a Live PIN first (Settings), then you can switch chart taps to Auto on a LIVE account.")
            if not pin_ok(r.pin):
                auth.record_fail(ip)
                raise HTTPException(403, "Wrong PIN")
        c["tap"] = r.tap
        if r.tap == "auto":
            e.event("Chart taps set to AUTO (orders go out without a confirm)", "warning")
    try:
        _JP_FILE.write_text(json.dumps(c))
    except Exception:
        pass
    return {"cfg": c}


class JPTap(BaseModel):
    symbol: str
    action: str                      # buy | short | stop | target | close
    price: float = 0
    stop: float | None = None
    target: float | None = None
    qty: float = 0
    confirmed: bool = False


@app.post("/api/jump/tap")
def jump_tap(r: JPTap):
    """Chart tap -> order. 'ask' mode needs confirmed=true (the dashboard sends it after you press Confirm); 'auto' sends straight away; 'off' refuses.
    Every normal check (daily loss limit, spread, short rules) still runs inside the manual order path."""
    e = need_engine()
    mode = _JP["cfg"].get("tap", "ask")
    sym = _valid_sym(r.symbol)
    if mode == "off":
        raise HTTPException(403, "Chart taps are switched off. Turn them on to Ask or Auto.")
    if mode == "ask" and not r.confirmed:
        raise HTTPException(400, "Please confirm the order first.")
    act = r.action.lower()
    try:
        pos = (e.broker.positions() or {}).get(sym)
    except Exception:
        pos = None
    pq = float((pos or {}).get("qty") or 0)
    px = round(float(r.price), 2) if r.price else 0
    if act == "close":
        if not pq:
            raise HTTPException(400, f"You have no {sym} position to close.")
        _close_now(e, sym, 100, urgent=True)
        return {"ok": True, "msg": f"Closing {sym}."}
    if act in ("stop", "target"):
        if not pq:
            raise HTTPException(400, f"You have no {sym} position. Set a stop or target only on an open trade.")
        if px <= 0:
            raise HTTPException(400, "Tap a price on the chart first.")
        long_ = pq > 0
        side = "sell" if long_ else "buy"
        ot = "stop" if act == "stop" else "limit"
        if act == "stop":
            try:
                ref = float((e.broker.last_trades([sym]) or {}).get(sym) or 0)
            except Exception:
                ref = 0.0
            if ref and ((long_ and px >= ref) or ((not long_) and px <= ref)):
                raise HTTPException(400, "A stop goes on the losing side of the current price.")
        o = ManualOrder(symbol=sym, side=side, qty=abs(pq), order_type=ot, limit_price=px if ot == "limit" else None, stop_price=px if ot == "stop" else None, tif="gtc" if _session_name(e) == "REGULAR" else "day")
        res = manual_order(o)
        return {"ok": True, "msg": f"{'Stop' if act == 'stop' else 'Target'} for {abs(pq):g} {sym} set at ${px:.2f}.", "order": res}
    if act not in ("buy", "short"):
        raise HTTPException(400, "Unknown action")
    if pq:
        raise HTTPException(409, f"You already hold {sym}. Close it first, or use Set stop / Set target.")
    if px <= 0:
        raise HTTPException(400, "Tap a price on the chart first.")
    return _jp_place(e, sym, act == "buy", px, r.stop, r.target, int(r.qty or 0))


def _jp_place(e, sym, up, px, stop=None, target=None, qty=0):
    """Limit entry with stop and target, sized from the risk budget. Used by chart taps and by PAPER presets. Raises HTTPException when it cannot."""
    if not stop:
        try:
            d5 = jp.to5(e.broker.bars([sym]).get(sym))
            a = float(jp.prep(d5)["atr"].iloc[-1]) if d5 is not None and len(d5) > 10 else 0.0
        except Exception:
            a = 0.0
        dist = max(a, px * 0.004)
        stop = round(px - dist if up else px + dist, 2)
    risk = abs(px - stop)
    if risk <= 0:
        raise HTTPException(400, "The stop is at the entry price. Pick a different stop.")
    if not target:
        target = round(px + 1.5 * risk if up else px - 1.5 * risk, 2)
    if qty < 1:
        dec = e.risk.size(px, stop, float(settings.wave_risk_mult), e._open_risk(), e.acct.get("buying_power", 0))
        qty = int(dec.qty)
        bp = float(e.acct.get("buying_power", 0) or 0)
        if bp > 0 and qty * px > 0.95 * bp:
            qty = int(0.95 * bp / px)
        if qty < 1:
            raise HTTPException(400, "Your risk budget sizes this to 0 shares. " + (getattr(dec, "reason", "") or ""))
    o = ManualOrder(symbol=sym, side="buy" if up else "sell", qty=qty, order_type="limit", limit_price=px, stop=stop, target=target, confirm_short=not up)
    res = manual_order(o)
    return {"ok": True, "msg": f"{'BUY' if up else 'SHORT'} {qty} {sym} limit ${px:.2f} · stop ${stop:.2f} · target ${target:.2f} sent.", "order": res, "qty": qty, "stop": stop, "target": target}


# ---------------- v2.18: custom preset strategies (AI builder, daily pattern review, PAPER auto-trade) ----------------
from autobot import presets as pr  # noqa: E402

_PR = {"job": {"state": "idle"}, "review_running": False, "fired": [], "auto_day": "", "auto_n": 0}


class PRBuild(BaseModel):
    text: str = ""
    images: list = []


class PRSave(BaseModel):
    rules: dict
    auto_paper: bool = False


class PRUpd(BaseModel):
    id: str
    enabled: bool | None = None
    auto_paper: bool | None = None
    delete: bool = False


class PRPlan(BaseModel):
    symbol: str
    action: str


def _pr_syms(e, cap=14):
    syms = _jp_symbols(e)[0]
    return list(dict.fromkeys(syms + [w.upper() for w in settings.watchlist]))[:cap]


def _pr_build_job(e, text, imgs):
    try:
        _PR["job"] = {"state": "working", "step": "Reading your description…"}
        rules, how = pr.from_text(text, imgs)
        _PR["job"] = {"state": "working", "step": "Back-testing on your stocks…"}
        parts, best, tested = [], None, []
        for sym in _pr_syms(e, 6):
            try:
                d5 = e.broker.bars5(sym, 45)
            except Exception:
                d5 = None
            if d5 is None or len(d5) < 60:
                continue
            sigs = pr.scan(rules, d5)
            t = pr.backtest(rules, d5, sigs=sigs)
            parts.append(t)
            tested.append(sym)
            if sigs and (best is None or sigs[-1]["i"] / len(d5) > best[2] or len(sigs) > len(best[1])):
                best = (sym, sigs, sigs[-1]["i"] / len(d5), d5)
        test = pr.merge_tests(parts)
        ch = pr.chart(best[3], best[1], focus=best[1][-1]) if best else None
        _PR["job"] = {"state": "done", "rules": rules, "how": how, "summary": pr.describe(rules), "test": test, "tested": tested,
                      "chart": ch, "chart_sym": best[0] if best else None}
    except Exception as ex:
        logging.exception("preset build failed")
        _PR["job"] = {"state": "error", "detail": str(ex)[:300]}


@app.post("/api/presets/build")
def presets_build(r: PRBuild):
    e = need_engine()
    if not r.text.strip() and not r.images:
        raise HTTPException(400, "Describe the setup, or add a chart screenshot.")
    if _PR["job"].get("state") == "working":
        raise HTTPException(409, "Still working on the last one. Wait a moment.")
    try:
        from autobot.selffix import clean_images
        imgs = clean_images(r.images)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    _PR["job"] = {"state": "working", "step": "Starting…"}
    threading.Thread(target=_pr_build_job, args=(e, r.text.strip()[:1500], imgs), daemon=True, name="preset-build").start()
    return {"ok": True}


@app.get("/api/presets/job")
def presets_job():
    return clean(_PR["job"])


class FocusReq(BaseModel):
    on: bool = False
    symbols: list[str] = []


@app.get("/api/focus")
def focus_get():
    return {"on": bool(settings.focus_on), "symbols": list(settings.focus_symbols), "watchlist": list(settings.watchlist),
            "held": sorted((engine.positions or {}).keys()) if engine and getattr(engine, "positions", None) else []}


@app.post("/api/focus")
def focus_set(r: FocusReq):
    """Focus mode: new entries (stocks, presets, options, Autopilot) only in these 1 to 5 stocks. Exits and your manual trades are not affected."""
    syms = []
    for x in r.symbols:
        x = str(x).upper().strip().lstrip("$")
        if re.fullmatch(r"[A-Z]{1,6}(\.[A-Z])?", x) and x not in syms:
            syms.append(x)
    if len(syms) > 5:
        raise HTTPException(400, "Pick 1 to 5 stocks.")
    if r.on and not syms:
        raise HTTPException(400, "Pick at least one stock first.")
    settings.focus_symbols, settings.focus_on = syms, bool(r.on)
    settings.save()
    e = engine
    if e is not None:
        try:
            e.event(("Focus mode ON: new trades only in " + ", ".join(syms)) if r.on else "Focus mode OFF: all stocks allowed again", "warning")
        except Exception:
            pass
        threading.Thread(target=lambda: getattr(e, "_scan", lambda: None)(), daemon=True, name="focus-scan").start()
    return {"ok": True, "on": settings.focus_on, "symbols": settings.focus_symbols}


@app.get("/api/presets")
def presets_get():
    d = pr.load()
    e = engine
    return clean({"presets": d["presets"], "plans": d["plans"], "job": _PR["job"], "review_running": _PR["review_running"], "patterns": pr.PATTERNS,
                  "mode": e.mode if e else "", "auto_log": d["auto_log"][-8:], "running": bool(e and e.running),
                  "armed": bool(e and _PR.get("armed") == str(e.broker.now().date())),
                  "autonomous": pr.autonomous_on(), "via": pr.autonomous_via(), "options_on": bool(settings.options_on), "stats": pr.STATS, "short": pr.SHORT})


class PRAuto(BaseModel):
    on: bool = False
    via: str = ""


@app.post("/api/presets/autonomous")
def presets_autonomous(r: PRAuto):
    pr.autonomous_set(r.on, r.via or None)
    return {"ok": True, "autonomous": pr.autonomous_on(), "via": pr.autonomous_via()}


@app.post("/api/presets/save")
def presets_save(r: PRSave):
    p = pr.add(r.rules, r.auto_paper)
    return {"ok": True, "preset": p}


@app.post("/api/presets/update")
def presets_update(r: PRUpd):
    if r.delete:
        pr.delete(r.id)
        return {"ok": True}
    p = pr.update(r.id, enabled=r.enabled, auto_paper=r.auto_paper)
    if not p:
        raise HTTPException(404, "Preset not found")
    return {"ok": True, "preset": p}


@app.post("/api/presets/plan")
def presets_plan(r: PRPlan):
    d = pr.load()
    sym = _valid_sym(r.symbol)
    if r.action == "watch" and sym not in [w.upper() for w in settings.watchlist]:
        settings.watchlist = list(settings.watchlist) + [sym]
        settings.save()
    d["plans"]["items"] = [x for x in d["plans"]["items"] if x["symbol"] != sym]
    pr.save(d)
    return {"ok": True}


def _pr_review(e, why="manual"):
    if _PR["review_running"]:
        return
    _PR["review_running"] = True
    try:
        d = pr.load()
        now = e.broker.now()
        items = pr.review(lambda s: e.broker.bars5(s, 45), _pr_syms(e, 20), d["presets"] + (pr.auto_rules() if pr.autonomous_on() else []), now)
        d = pr.load()
        d["plans"].update(day=str(now.date()), items=items, at=now.strftime("%a %-I:%M %p"), why=why)
        pr.save(d)
        if items and why != "manual":
            top = items[0]
            alerts.send("jump", f"📅 Pattern review: {len(items)} setup{'s' if len(items) != 1 else ''} lined up",
                        f"Best: {top['symbol']} · {top['preset']}" + (f" · {top['rate']}% record" if top["rate"] is not None else ""), level="info")
    except Exception:
        logging.exception("pattern review failed")
    finally:
        _PR["review_running"] = False


@app.post("/api/presets/review")
def presets_review():
    e = need_engine()
    if not pr.load()["presets"] and not pr.autonomous_on():
        raise HTTPException(400, "Save a preset first, or switch on Autonomous.")
    threading.Thread(target=_pr_review, args=(e, "manual"), daemon=True, name="preset-review").start()
    return {"ok": True}


def _pr_loop():
    import time as _tm
    while True:
        _tm.sleep(60)
        try:
            e = engine
            if e is None or not (pr.load()["presets"] or pr.autonomous_on()):
                continue
            now = e.broker.now()
            if now.weekday() >= 5:
                continue
            hm = (now.hour, now.minute)
            key = None
            if hm >= (16, 20) and hm < (20, 0):
                key = f"close:{now.date()}"
            elif (8, 30) <= hm < (9, 25):
                key = f"pre:{now.date()}"
            if key:
                d = pr.load()
                if key not in d["plans"].get("ran", []):
                    d["plans"]["ran"] = (d["plans"].get("ran", []) + [key])[-10:]
                    pr.save(d)
                    _pr_review(e, key.split(":")[0])
        except Exception:
            logging.exception("preset loop")


threading.Thread(target=_pr_loop, daemon=True, name="preset-review-loop").start()


class PRArm(BaseModel):
    pin: str = ""
    off: bool = False


@app.post("/api/presets/arm")
def presets_arm(r: PRArm, request: Request):
    """LIVE only: arm preset auto-trading for today with the Live PIN. It lapses at the end of the day or when you turn it off."""
    e = need_engine()
    if r.off:
        _PR["armed"] = ""
        return {"ok": True, "armed": False}
    if e.mode != "LIVE":
        return {"ok": True, "armed": False, "note": "Not needed in PAPER."}
    ip = "pin:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    if not live_pin():
        raise HTTPException(403, "Set a Live PIN first (Settings).")
    if not pin_ok(r.pin):
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong PIN")
    _PR["armed"] = str(e.broker.now().date())
    e.event("Preset auto-trading ARMED for LIVE today", "warning")
    return {"ok": True, "armed": True}


def _pr_universe_pass(e, now, sess, syms, pos, st):
    """Presets watch everything the bot scans, not just the Radar list: the day's universe and always-watch stocks (up to 30 more)."""
    if sess != "REGULAR" or not getattr(e, "running", False):
        return
    if e.mode == "LIVE" and _PR.get("armed") != str(now.date()):
        return
    if not pr.autonomous_on() and not any(p.get("enabled", True) and p.get("auto_paper") for p in pr.load()["presets"]):
        return
    extra = [x for x in dict.fromkeys(list(getattr(e, "reg_universe", None) or []) + list(getattr(e, "universe", None) or []) + list(settings.watch_always))
             if x and x.replace(".", "").isalpha() and x not in syms][:30]
    extra = [x for x in extra if getattr(e, "focus_ok", lambda y: True)(x)]
    if not extra:
        return
    d1 = e.broker.bars(extra, st)
    for sym in extra:
        d = d1.get(sym)
        d5 = jp.to5(d) if d is not None else None
        if d5 is None or len(d5) < 10:
            continue
        if d5.index[-1] + timedelta(minutes=5) > now:
            d5 = d5.iloc[:-1]
        if len(d5) < 10:
            continue
        q = float((pos.get(sym) or {}).get("qty") or 0)
        _pr_live(e, sym, d5, "up" if q > 0 else "down" if q < 0 else None, now, sess)


def _pr_live(e, sym, d5, held, now, sess):
    """A preset with auto-trade ON that fires on the newest closed candle places an ordinary sized order (stop + target attached), but only while the
    main Auto-trader switch is ON. Once per stock per preset per day; at most 5 a day in PAPER, 3 in LIVE. LIVE also needs today's PIN arming."""
    if held or sess != "REGULAR" or not getattr(e, "running", False) or not getattr(e, "focus_ok", lambda x: True)(sym):
        return
    if getattr(e, "_event_block", lambda *x: False)(sym, now, sess):   # v2.19.7: earnings day / risky news -> same skip as the main bot
        return
    live = e.mode == "LIVE"
    if live and _PR.get("armed") != str(now.date()):
        return
    ps = [p for p in pr.load()["presets"] if p.get("enabled", True) and p.get("auto_paper")]
    auto = pr.autonomous_on()
    if not ps and not auto:
        return
    day = str(now.date())
    if _PR["auto_day"] != day:
        _PR.update(auto_day=day, auto_n=0, fired=[], hist={}, rec={})
    import time as _tm
    if _tm.time() - _PR.get("hn_t", 0) > 50:
        _PR.update(hn=0, hn_t=_tm.time(), rn=0)
    H = _PR.setdefault("hist", {}).get(sym)
    if H is None:                                # earlier days (older than the data delay) + today's live candles, so patterns have enough history
        if _PR.get("hn", 0) >= 2:
            return
        _PR["hn"] = _PR.get("hn", 0) + 1
        try:
            h = e.broker.bars5(sym, 30 if auto else 6)
            h = h[h.index.date < now.date()] if h is not None else None
        except Exception:
            h = None
        _PR["hist"][sym] = H = h if h is not None else False
    if H is False or H is None or len(H) == 0:
        return
    H = H.copy()
    H.index = H.index.tz_convert(d5.index.tz)
    import pandas as _pd
    if auto:                                     # Autonomous: every pattern is a candidate, but only ones with a good record on THIS stock (prior days) may trade
        rk = _PR.setdefault("rec", {})
        kk = f"{day}:{sym}"
        if kk not in rk and _PR.get("rn", 0) < 1:
            _PR["rn"] = _PR.get("rn", 0) + 1
            rk[kk] = {}
            for r_ in pr.auto_rules():
                try:
                    rk[kk][r_["pattern"]] = pr.backtest(r_, H)
                except Exception:
                    pass
        good = [(rk.get(kk, {}).get(r_["pattern"]), r_) for r_ in pr.auto_rules()]
        good = [(t, r_) for t, r_ in good if pr.good_record(t)]
        good.sort(key=lambda x: (x[0]["avg_r"], x[0]["n"]), reverse=True)
        ps = ps + [dict(r_, _auto=True) for _, r_ in good]
    if not ps:
        return
    d5 = _pd.concat([H, d5])
    for p in ps:
        if _PR["auto_n"] >= (3 if live else 5):
            return
        k = f"{day}:{sym}:auto" if p.get("_auto") else f"{day}:{sym}:{p['id']}"
        if k in _PR["fired"]:
            continue
        dd = d5.iloc[-500:] if p.get("_auto") else d5
        sigs = [s for s in pr.scan(p, dd) if s["i"] == len(dd) - 1 and s["day"] == day]
        if not sigs:
            continue
        s = sigs[-1]
        _hw = getattr(e, "ha_block", lambda *x: "")(sym, s["side"] == "up", "auto" if p.get("_auto") else "stocks")
        if _hw:                                   # v2.22: Heikin Ashi trend filter (not marked fired: it can try again next candle)
            continue
        _PR["fired"].append(k)
        try:
            up = s["side"] == "up"
            via = pr.autonomous_via() if p.get("_auto") else "shares"
            msgs, did, kind = [], False, ""
            if via in ("shares", "both"):
                res = _jp_place(e, sym, up, s["price"], s["stop"], s["tp1"])
                msgs.append(res["msg"]); did = True; kind = "buy" if up else "short"
            if via in ("options", "both"):
                if not settings.options_on:
                    msgs.append("options skipped: the Options switch is Off")
                else:
                    ok, why = options_bot.autopilot_open(e, sym, "call" if up else "put", f"{p['name']}: {s['why']}", s["price"])
                    msgs.append(f"options: bought a {'call' if up else 'put'} on {sym} (see the Options tab)" if ok else f"options skipped: {why}")
                    if ok:
                        did = True; kind = kind or ("call" if up else "put")
            if not did:
                logging.info("preset %s on %s: %s", p["name"], sym, "; ".join(msgs))
                d = pr.load()
                d["auto_log"] = (d["auto_log"] + [{"at": now.strftime("%a %-I:%M %p"), "text": f"{p['name']} {sym}: " + "; ".join(msgs)}])[-20:]
                pr.save(d)
                continue
            _PR["auto_n"] += 1
            d = pr.load()
            d["auto_log"] = (d["auto_log"] + [{"at": now.strftime("%a %-I:%M %p"), "text": f"{p['name']}: " + "; ".join(msgs)}])[-20:]
            pr.save(d)
            alerts.send("jump", f"🤖 {p['name']} ({'LIVE' if live else 'paper'}): {kind} {sym}", "; ".join(msgs), symbol=sym, level="info")
        except HTTPException as ex:
            logging.info("preset %s on %s skipped: %s", p["name"], sym, ex.detail)
        except Exception:
            logging.exception("preset auto-trade failed")


# ---------------- v2.14: Take-$-when-green tracer + profit-peak learning ----------------
_TK = {"targets": {}, "seen": {}, "log": []}      # targets: sym -> {usd, learn, set, peak, trace}; seen: sym -> last look at every open position
_TK_FILE = DATA_DIR / "take_targets.json"
_TK_LOCK = threading.Lock()


def _tk_load():
    try:
        d = json.loads(_TK_FILE.read_text())
        if isinstance(d, dict):
            _TK["targets"] = d
    except Exception:
        pass


def _tk_save():
    try:
        _TK_FILE.write_text(json.dumps(_TK["targets"]))
    except Exception:
        pass


_tk_load()


_TK_POS = {"t": 0.0, "p": {}}


def _tk_positions(e):
    """Positions with a 10 s cache shared by the take loop and the screen (keeps Alpaca calls low)."""
    if time_mod.time() - _TK_POS["t"] > 10:
        try:
            _TK_POS["p"] = e.broker.positions()
            _TK_POS["t"] = time_mod.time()
        except Exception:
            _TK_POS["t"] = time_mod.time() - 5
    return dict(_TK_POS["p"])


def _tk_exit_pl(e, sym, pos, sess, qs=None):
    """P&L if closed right now at the price we would REALLY get (bid for longs, ask for shorts); falls back to the mark.
    qs = one batched quotes() answer for all positions (live stream cache first), so this adds no per-symbol REST calls."""
    try:
        q = (qs or {}).get(sym)
        if q and q[0] and q[1]:
            ref = q[0] if pos["qty"] > 0 else q[1]
            return (ref - pos["avg_entry"]) * pos["qty"]
    except Exception:
        pass
    return pos.get("upl", 0.0)


def _tk_quotes(e, poss, sess):
    try:
        return e.broker.quotes(list(poss.keys()), "REGULAR" if sess == "REGULAR" else "AFTER") or {}
    except Exception:
        return {}


_AH_SKIP: set = set()      # stocks where you tapped Stop: not auto-watched again until the position is gone
_AH_GREEN = 0.15           # % of cost (after the spread) that counts as "showing profit"
_AH_SECS = 30              # ...for this long, steadily, before the app takes over


def _ah_watch(e, sym, pos, sn, pct, sess, now, spr_pct=0.0):
    """v2.16: your own stock positions are taken care of automatically. Once one has shown steady profit for ~30 s
    the app arms Auto-harvest on it: bank the gain (learned level or fade), re-enter on a pullback/continuation while the
    trend holds, stop when it turns. It never sells at a loss on its own."""
    try:
        if not getattr(settings, "auto_harvest_manual", True):
            return
        if sym in e.trades or sym in harvester.jobs or sym in _AH_SKIP:
            return
        if not re.fullmatch(r"[A-Z]{1,5}(\.[A-Z])?", sym) or abs(pos["qty"]) < 1 or abs(pos["qty"]) != int(abs(pos["qty"])):
            return                                   # options / crypto / fractional shares are left alone
        if sess in ("OVERNIGHT", "CLOSED") or getattr(getattr(e, "risk", None), "halted", False):
            return
        lim = float(getattr(settings, "max_spread_pct", 0) or 0)
        if lim > 0 and spr_pct > lim:
            return                                   # a wide spread eats the gain: don't start cycling this stock
        if pct >= _AH_GREEN:
            sn.setdefault("green_since", now)
            if now - sn["green_since"] >= _AH_SECS:
                from autobot.sessions import bot_day
                e.manual_syms[sym] = bot_day(e.broker.now())
                harvester.arm(sym, "buy" if pos["qty"] > 0 else "sell", abs(pos["qty"]), "auto: your trade is showing steady profit", auto=True)
                e.event(f"♻ Auto-watch ON for your {sym} ({abs(pos['qty']):g} sh): steady profit {pct:+.2f}% - it will bank it and re-enter while the trend holds")
        else:
            sn.pop("green_since", None)
    except Exception:
        logging.exception("auto watch")


def _hv_learn(e, sym, sess):
    if not settings.harvest_learn:
        return None
    from autobot import peaklearn
    from autobot.engine import PEAK_FILE
    sg = peaklearn.suggest(PEAK_FILE, sym, sess, e._slip_pct())
    return float(sg["pct"]) if sg and sg.get("pct") else None


def _tk_tick():
    e = engine
    if e is None:
        return
    poss = _tk_positions(e)
    sess = _session_name(e)
    qs = _tk_quotes(e, poss, sess) if poss else {}
    from autobot import peaklearn
    from autobot.engine import PEAK_FILE
    now = time_mod.time()
    with _TK_LOCK:
        for sym, pos in poss.items():
            if not pos.get("qty"):
                continue
            avg, qty = pos["avg_entry"], pos["qty"]
            cost = abs(avg * qty) or 1.0
            ex = _tk_exit_pl(e, sym, pos, sess, qs)
            sn = _TK["seen"].setdefault(sym, {"peak_pct": 0.0, "last_pct": 0.0, "bot": False, "sess": sess, "t": now})
            pct = ex / cost * 100.0
            sn.update(last_pct=pct, peak_pct=max(sn["peak_pct"], pct), bot=sym in e.trades, sess=sess, t=now)
            try:
                _q = qs.get(sym)
                _sp = ((_q[1] - _q[0]) / ((_q[1] + _q[0]) / 2) * 100.0) if _q and _q[0] and _q[1] else 0.0
            except Exception:
                _sp = 0.0
            _ah_watch(e, sym, pos, sn, pct, sess, now, _sp)
            tg = _TK["targets"].get(sym)
            if tg:
                tg["peak"] = max(tg.get("peak", 0.0), ex)
                tr = tg.setdefault("trace", [])
                if not tr or now - tr[-1][0] >= 10:
                    tr.append([int(now), round(ex, 2)])
                    del tr[:-90]
                tg["now"] = round(ex, 2)
                if tg.get("usd", 0) > 0 and ex >= tg["usd"]:
                    note = "harvest" if sym in e.trades else "take-target"
                    try:
                        _close_now(e, sym, 100, urgent=True, note=note)
                        e.event(f"🎯 TAKE {sym}: reached ${tg['usd']:.2f} (exit P&L {ex:+.2f}) - closed"
                                + (" - the bot may re-enter while the trend holds" if note == "harvest" else " (your trade - not re-entered)"))
                        e.alert("profit", f"🎯 {sym} banked ${ex:,.2f}", "Your take amount was reached.", symbol=sym)
                        _TK["log"].append({"t": int(now), "sym": sym, "usd": tg["usd"], "got": round(ex, 2)})
                        del _TK["log"][:-40]
                        _TK["targets"].pop(sym, None)
                        _tk_save()
                    except Exception as ex2:
                        tg["err"] = str(getattr(ex2, "detail", ex2))[:160]
        # positions that vanished = finished trips: teach the learner (bot trades are recorded by the engine itself)
        for sym in [k for k in _AH_SKIP if k not in poss]:
            _AH_SKIP.discard(sym)
        for sym in [k for k in _TK["seen"] if k not in poss]:
            sn = _TK["seen"].pop(sym)
            if not sn.get("bot") and sn["peak_pct"] > 0:
                peaklearn.record(PEAK_FILE, sym, sn.get("sess", "REGULAR"), sn["peak_pct"], sn["last_pct"], "you")
            if sym in _TK["targets"]:
                _TK["targets"].pop(sym, None)
                _tk_save()


def _tk_loop():
    import time as _tm
    while True:
        _tm.sleep(4)
        try:
            _tk_tick()
        except Exception:
            logging.exception("take loop")


threading.Thread(target=_tk_loop, daemon=True, name="take-targets").start()


class TKSet(BaseModel):
    symbol: str
    usd: float | None = None          # take this much (exit P&L, after the spread); 0 / None with learn=False clears
    learn: bool = False               # use the learned level for this stock
    clear: bool = False


def _tk_suggest(e, sym, pos):
    from autobot import peaklearn
    from autobot.engine import PEAK_FILE
    sg = peaklearn.suggest(PEAK_FILE, sym, _session_name(e), e._slip_pct())
    if not sg:
        return None
    cost = abs(pos["avg_entry"] * pos["qty"])
    sg["usd"] = round(cost * sg["pct"] / 100.0, 2)
    return sg


@app.get("/api/take")
def take_get():
    e = need_engine()
    from autobot import peaklearn
    from autobot.engine import PEAK_FILE
    out = []
    poss = _tk_positions(e)
    qs = _tk_quotes(e, poss, _session_name(e)) if poss else {}
    with _TK_LOCK:
        for sym, pos in poss.items():
            tg = _TK["targets"].get(sym) or {}
            sn = _TK["seen"].get(sym) or {}
            t = e.trades.get(sym)
            out.append({"symbol": sym, "bot": bool(t), "target": tg.get("usd"), "learned": bool(tg.get("learn")), "now": tg.get("now"),
                        "peak": tg.get("peak"), "trace": tg.get("trace", [])[-60:], "err": tg.get("err", ""),
                        "hv": next((j for j in harvester.status() if j["symbol"] == sym), None), "skip": sym in _AH_SKIP,
                        "peak_pct": round(sn.get("peak_pct", 0.0), 3), "suggest": _tk_suggest(e, sym, pos),
                        "exit_pl": round(_tk_exit_pl(e, sym, pos, _session_name(e), qs), 2)})
    return clean({"items": out, "log": _TK["log"][-10:], "stats": peaklearn.stats(PEAK_FILE), "learn_on": bool(settings.harvest_learn)})


@app.post("/api/take/set")
def take_set(r: TKSet):
    e = need_engine()
    sym = r.symbol.upper()
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    with _TK_LOCK:
        if r.clear:
            _TK["targets"].pop(sym, None)
            _tk_save()
            return {"ok": True, "cleared": True}
        usd, learned = r.usd, False
        if r.learn:
            sg = _tk_suggest(e, sym, pos)
            if not sg:
                raise HTTPException(400, "Not enough finished trades to learn from yet - type an amount instead.")
            usd, learned = sg["usd"], True
        if not usd or usd <= 0:
            raise HTTPException(400, "Enter an amount above $0.")
        old = _TK["targets"].get(sym) or {}
        _TK["targets"][sym] = {"usd": round(float(usd), 2), "learn": learned, "set": int(time_mod.time()),
                               "peak": old.get("peak", 0.0), "trace": old.get("trace", [])}
        _tk_save()
    e.event(f"🎯 Take target set on {sym}: ${float(usd):.2f} when green" + (" (learned)" if learned else ""))
    return {"ok": True, "usd": round(float(usd), 2), "learned": learned}


@app.get("/api/morningwave")
def morning_wave(force: int = 0, symbols: str = "", move: float = 0.4, mode: str = ""):
    """v1.85: Morning Wave watchlist. Conditional up / down setups for the next morning from the latest regular-session
    15-minute bars: entry watch zone, stop, two targets, historical hit rate and score. Display only, never trades."""
    import time as _tm
    from autobot import morningwave as mw
    e = need_engine()
    extra = [x.strip().upper() for x in symbols.split(",") if x.strip()]
    manual = settings.pred_source == "manual" and bool(settings.pred_manual)
    if manual:
        syms = [x for x in dict.fromkeys(list(settings.pred_manual)) if x and x.replace(".", "").isalpha()][:20]
    else:
        syms = list(dict.fromkeys(extra + [w.upper() for w in settings.watchlist] + MW_CORE
                                  + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])[:8]]))
        syms = [x for x in syms if x and x.replace(".", "").isalpha()][:30]
    now = e.broker.now()
    sess = _session_name(e)
    mode = mode.upper() if mode.upper() in mw.MODES else mw.mode_for(sess, now.hour * 60 + now.minute)
    key = ",".join(syms) + f"|{move}|{mode}|{settings.pred_source}"
    wk = _weekend_gap(now)
    if not force and _mw_cache["data"] and _mw_cache["key"] == key and _tm.time() - _mw_cache["at"] < 300:
        return clean(dict(_mw_cache["data"], age_s=round(_tm.time() - _mw_cache["at"]), weekend=wk, wk_auto=_WK["last"]))
    if not hasattr(e.broker, "bars15"):
        return clean({"rise": [], "fall": [], "note": "Real data only (not in the simulator)", "asof": ""})
    try:
        bars = e.broker.bars15(syms, 45)
    except Exception as ex:
        raise HTTPException(502, f"Bar data failed: {str(ex)[:140]}")
    rise, fall = mw.build(bars, move, mode)
    if not manual:                                   # Auto: the 10 best-scoring setups overall
        keep = {id(r) for r in sorted(rise + fall, key=lambda x: -x["score"])[:10]}
        rise, fall = [r for r in rise if id(r) in keep], [r for r in fall if id(r) in keep]
    for r in rise + fall:
        try:
            ev = events.earnings_text(r["symbol"], now)
        except Exception:
            ev = None
        r["event"] = ev or ""
        r["event_checked"] = ev is not None
        r["prior_bar"] = r["bar_date"] != str(now.date())
        try:
            pr = _price(e, r["symbol"], sess)
            px = pr.get("last")
            if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or px is None):
                px = (pr["bid"] + pr["ask"]) / 2
        except Exception:
            px = None
        r["price"] = round(px, 2) if px else None
        try:
            def _sz(entry, stop):
                dec = e.risk.size(entry, stop, float(settings.wave_risk_mult), e._open_risk(), e.acct.get("buying_power", 0))
                q = int(dec.qty)
                bp = float(e.acct.get("buying_power", 0) or 0)
                if bp > 0 and q * entry > 0.95 * bp:
                    q = int(0.95 * bp / entry)
                return q, getattr(dec, "reason", "") or "size is 0 shares"
            r["plan"] = _wave_plan(r, px, _sz)
        except Exception:
            r["plan"] = None
        if px:
            lo, hi = r["zone"]
            r["zone_state"] = "IN ZONE" if lo <= px <= hi else ("above zone" if px > hi else "below zone")
    out = {"rise": rise, "fall": fall, "asof": now.strftime("%b %-d, %-I:%M %p %Z"), "ts": round(_tm.time()), "age_s": 0, "weekend": wk, "wk_auto": _WK["last"], "scanned": len(bars), "move_pct": move,
           "session": sess, "mode": mode, "title": mw.MODES[mode]["title"], "window": mw.MODES[mode]["window"],
           "source": "manual" if manual else "auto", "manual": list(settings.pred_manual),
           "none": [x for x in syms if manual and x not in {r["symbol"] for r in rise + fall}]}
    _mw_cache.update(at=_tm.time(), key=key, data=out)
    return clean(out)


@app.get("/api/sesstab")
def sesstab():
    """v1.84: one tab whose content follows the market session: Pre-market / Regular / After-hours / Night / Closed."""
    e = need_engine()
    now = e.broker.now()
    ss = e.session
    name = ss.name if ss else "CLOSED"
    night = e.night_window(now)
    nd = e.night_dir()
    items, title, at = [], "", ""
    if night and name in ("OVERNIGHT", "CLOSED", "PRE"):
        name = "NIGHT"
        title = "Night " + ("buys" if nd == "buy" else "shorts")
        n = night_get()
        items, at = n.get("items", []), n.get("at", "")
    else:
        title = {"PRE": "Pre-market", "REGULAR": "Regular hours", "AFTER": "After-hours", "OVERNIGHT": "Overnight"}.get(name, "Market closed")
        for m in (e._movers_view() or [])[:25]:
            items.append({"symbol": m.get("symbol"), "score": m.get("score"), "tags": [x for x in [m.get("plan"), m.get("call")] if x],
                          "change": m.get("move"), "side": m.get("side"), "status": m.get("bot", "")})
        at = getattr(e, "movers_at", "")
        if not items:
            for r in (e.shortlist or [])[:15]:
                items.append({"symbol": r.get("symbol"), "score": r.get("score"), "tags": r.get("tags") or [], "change": r.get("change"),
                              "status": e._mover_bot({"symbol": str(r.get("symbol", "")).upper(), "side": "buy"}, now)})
            at = e.shortlist_at
    mine = [{"symbol": t.symbol, "side": t.side, "qty": t.qty, "entry": t.entry, "status": t.status,
             "pnl": round(((t.last_price or t.entry) - t.entry) * t.dir * t.qty, 2)}
            for t in list(e.trades.values()) if t.ext or name == "REGULAR"]
    return clean({"session": name, "title": title, "items": items, "at": at, "trades": mine, "night_on": settings.night_short,
                  "night_dir": nd, "night_active": night, "window": "8:00 PM - 7:00 AM ET",
                  "account_can_short": bool(e.acct.get("shorting_enabled", True))})


@app.get("/api/pre/settings")
def pre_settings_get():
    return _pre_state()


@app.post("/api/pre/preset")
def pre_preset(source: str = "auto"):
    res = apply_pre_preset(source if source in ("auto", "only") else "recommended")
    return dict(_pre_state(), applied=res["source"])


@app.post("/api/pre/settings")
def pre_settings_set(r: PreSet):
    """Pre-market guard (v1.75). Never touches the daily loss limit."""
    if r.pre_window is not None:
        settings.pre_window = bool(r.pre_window)
        if settings.pre_window:
            settings.pre_entries_off = False
    if r.pre_from is not None:
        settings.pre_from = max(240, min(int(r.pre_from), 570))
    if r.pre_until is not None:
        settings.pre_until = max(240, min(int(r.pre_until), 570))
    if settings.pre_until <= settings.pre_from:
        settings.pre_until = min(570, settings.pre_from + 30)
    if r.ext_max_notional is not None:
        settings.ext_max_notional = max(0.0, min(float(r.ext_max_notional), 1_000_000.0))
    if r.pre_auto is not None:
        settings.pre_auto = bool(r.pre_auto)
    settings.save()
    return _pre_state()


# ---------- v1.76: Close-now log: every time a position could be closed for a real profit ----------
_cn_file = DATA_DIR / "closenow_log.jsonl"
_cn_events = []
_cn_state = {}
try:
    if _cn_file.exists():
        _cn_events = [json.loads(x) for x in _cn_file.read_text().splitlines()[-3000:] if x.strip()]
except Exception:
    _cn_events = []


def _cn_add(ev):
    _cn_events.append(ev)
    del _cn_events[:-3000]
    try:
        with open(_cn_file, "a") as f:
            f.write(json.dumps(ev) + "\n")
    except Exception:
        pass


def _cn_tick():
    e = engine
    if not e:
        return
    thr = float(getattr(settings, "closenow_min", 10.0) or 10.0)
    pos = e.broker.positions()
    now = e.broker.now()
    sess = _session_name(e)
    qs = {}
    if pos:
        try:
            qs = e.broker.quotes(list(pos.keys()), sess) or {}
        except Exception:
            qs = {}
    stamp = now.strftime("%Y-%m-%d %H:%M:%S")
    for s, p in pos.items():
        q = qs.get(s)
        if not (q and q[0] and q[1]):
            continue
        qty = float(p["qty"])
        xp = q[0] if qty > 0 else q[1]
        avg = float(p["avg_entry"])
        cn = (xp - avg) * qty
        spr = (q[1] - q[0]) / q[1] * 100 if q[1] else 0
        who = "bot" if s in e.trades else ("harvest" if s in harvester.jobs else "you")
        st = _cn_state.get(s)
        base = {"t": stamp, "symbol": s, "who": who, "session": sess, "qty": qty, "avg": round(avg, 4), "exit_px": round(xp, 4),
                "spread_pct": round(spr, 3), "side": "long" if qty > 0 else "short"}
        if cn >= thr and not st:
            _cn_state[s] = {"t0": now, "peak": cn, "last": cn}
            _cn_add(dict(base, event="UP", close_now=round(cn, 2), peak=round(cn, 2), note=f"close-now crossed above ${thr:,.0f}"))
        elif st:
            st["last"] = cn
            st["peak"] = max(st["peak"], cn)
            if cn < thr - 2:
                mins = (now - st["t0"]).total_seconds() / 60
                _cn_add(dict(base, event="FELL", close_now=round(cn, 2), peak=round(st["peak"], 2), mins=round(mins, 1),
                             note=f"fell back under ${thr:,.0f}, was up to ${st['peak']:,.2f}, {mins:.1f} min above"))
                _cn_state.pop(s, None)
    for s in [k for k in _cn_state if k not in pos]:
        st = _cn_state.pop(s)
        mins = (now - st["t0"]).total_seconds() / 60
        _cn_add({"t": stamp, "symbol": s, "who": "", "session": sess, "event": "CLOSED", "close_now": round(st["last"], 2),
                 "peak": round(st["peak"], 2), "mins": round(mins, 1), "qty": 0, "avg": 0, "exit_px": 0, "spread_pct": 0, "side": "",
                 "note": f"position closed; last close-now ${st['last']:,.2f}, peak ${st['peak']:,.2f}, {mins:.1f} min above"})


def _cn_loop():
    import time as _t
    while True:
        _t.sleep(5)
        try:
            _cn_tick()
        except Exception as ex:
            logging.debug("close-now log: %s", ex)


_th.Thread(target=_cn_loop, daemon=True, name="closenow").start()


@app.get("/api/closenow/log")
def closenow_log(limit: int = 300):
    return clean({"items": list(reversed(_cn_events[-max(1, min(int(limit), 3000)):])), "min": settings.closenow_min})


@app.get("/api/closenow/log.csv")
def closenow_csv():
    import csv as _csv
    import io as _io
    cols = ["t", "symbol", "who", "side", "event", "close_now", "peak", "mins", "qty", "avg", "exit_px", "spread_pct", "session", "note"]
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(cols)
    for r in _cn_events:
        w.writerow([r.get(k, "") for k in cols])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=sekexbot_closenow_log.csv"})


class CnThr(BaseModel):
    min: float


@app.post("/api/closenow/threshold")
def closenow_thr(r: CnThr):
    settings.closenow_min = max(1.0, min(float(r.min), 100000.0))
    settings.save()
    return {"ok": True, "min": settings.closenow_min}


@app.get("/api/scorecard")
def scorecard(days: int = 30, mode: str = "this", by: str = "strategy"):
    """Your own journal sliced by strategy / session / side / hour / symbol. Display only."""
    e = need_engine()
    days = max(1, min(int(days), 365))
    want = None if mode == "all" else (e.mode if mode in ("this", "") else mode.upper())
    cut = (e.broker.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    rows = [r for r in db.recent(20000) if r.get("status") == "closed" and (r.get("day") or "") >= cut
            and (want is None or r.get("mode") == want)]
    groups = {}
    for r in rows:
        if by == "session":
            k = r.get("bucket") or "?"
        elif by == "side":
            k = "long (buy)" if r.get("side") == "buy" else "short (sell)"
        elif by == "symbol":
            k = r.get("symbol") or "?"
        elif by == "hour":
            try:
                k = f"{datetime.fromisoformat(r['opened_at']).hour:02d}:00"
            except Exception:
                k = "?"
        else:
            by, k = "strategy", (r.get("strategy") or "?").split("@")[0]
        groups.setdefault(k, []).append(float(r.get("pnl") or 0))
    out = []
    off = set(settings.strategy_off or [])
    for k, v in groups.items():
        w = [x for x in v if x > 0]
        l = [x for x in v if x < 0]
        gp, gl = sum(w), -sum(l)
        out.append({"key": k, "n": len(v), "win_rate": round(100 * len(w) / len(v), 1), "avg_win": round(sum(w) / len(w), 2) if w else 0,
                    "avg_loss": round(sum(l) / len(l), 2) if l else 0, "expectancy": round(sum(v) / len(v), 2),
                    "pnl": round(sum(v), 2), "pf": round(gp / gl, 2) if gl else None,
                    "off": by == "strategy" and k in off})
    out.sort(key=lambda r: r["pnl"])
    tot = [float(r.get("pnl") or 0) for r in rows]
    return clean({"items": out, "by": by, "days": days, "mode": want or "ALL", "trades": len(rows), "pnl": round(sum(tot), 2),
                  "off": sorted(off), "note": "" if rows else "No closed trades in this period yet."})


class StratOff(BaseModel):
    name: str
    off: bool = True


@app.post("/api/strategy/off")
def strategy_off(r: StratOff):
    """Switch one strategy off (or back on). The daily loss limit is untouched."""
    e = need_engine()
    name = r.name.split("@")[0].strip().upper()
    if not name.replace("_", "").isalnum():
        raise HTTPException(400, "Bad strategy name")
    cur = [x for x in (settings.strategy_off or []) if x != name]
    if r.off:
        cur.append(name)
    settings.strategy_off = sorted(cur)
    settings.save()
    e.event(f"Strategy {name} switched {'OFF' if r.off else 'back ON'} in the Scorecard", "info")
    return {"ok": True, "off": settings.strategy_off}


_prep_cache = {"at": 0.0, "items": [], "asof": ""}


@app.get("/api/prep/morning")
def prep_morning(force: int = 0):
    """Real-data prep for the open: gap vs the last close, trend vs the 20-day average, distance to the 20-day high,
    ATR and volume for the watchlist + shortlist + movers. Display only, it never trades. Cached 60 s."""
    import time as _tm
    e = need_engine()
    if not force and _tm.time() - _prep_cache["at"] < 60 and _prep_cache["items"]:
        return clean({"items": _prep_cache["items"], "asof": _prep_cache["asof"], "session": _prep_cache.get("sess", "")})
    if not hasattr(e.broker, "_daily_stats"):
        return clean({"items": [], "asof": "", "note": "Real data only (not in the simulator)"})
    syms = list(dict.fromkeys([w.upper() for w in settings.watchlist]
                              + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])]
                              + [str(m.get("symbol", "")).upper() for m in (e.movers or [])]))
    syms = [s for s in syms if s and s.replace(".", "").isalpha()][:36]
    sess = _session_name(e)
    try:
        st = e.broker._daily_stats(syms)
    except Exception as ex:
        raise HTTPException(502, f"Daily data failed: {str(ex)[:140]}")
    rows = []
    for s in syms:
        d = st.get(s)
        if not d:
            continue
        pr = _price(e, s, sess)
        px = pr.get("last")
        if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or px is None):
            px = (pr["bid"] + pr["ask"]) / 2
        if not px or not d.get("prev_close"):
            continue
        pc, sma, hi, lo, atr = d["prev_close"], d["sma20"], d["hi20"], d["lo20"], d["atr"]
        gap = (px / pc - 1) * 100
        vs_sma = (px / sma - 1) * 100
        to_hi = (px / hi - 1) * 100
        rng = (px - lo) / (hi - lo) * 100 if hi > lo else 50
        atr_pct = atr / px * 100 if px else 0
        score = (1 if px > sma else -1) + (1 if to_hi > -3 else 0) + max(-1.5, min(1.5, gap / 2)) + (0.5 if px > hi else 0)
        tags = []
        if px > hi:
            tags.append("NEW 20D HIGH")
        if px > sma and gap >= 1:
            tags.append("TREND LONG")
        elif px < sma and gap <= -1:
            tags.append("TREND SHORT")
        if px > sma and to_hi > -3 and "NEW 20D HIGH" not in tags:
            tags.append("NEAR HIGH")
        if px > sma and -1 < gap < 1 and "TREND LONG" not in tags:
            tags.append("LONG WATCH")
        if px < sma and gap > 1:
            tags.append("BOUNCE (below avg)")
        rows.append({"symbol": s, "price": round(px, 2), "prev_close": round(pc, 2), "gap": round(gap, 2),
                     "vs_sma20": round(vs_sma, 2), "to_hi20": round(to_hi, 2), "range_pos": round(rng),
                     "atr_pct": round(atr_pct, 2), "adv": int(d.get("adv") or 0), "score": round(score, 2), "tags": tags})
    rows.sort(key=lambda r: -r["score"])
    asof = e.broker.now().strftime("%a %I:%M %p").replace(" 0", " ")
    _prep_cache.update(at=_tm.time(), items=rows, asof=asof, sess=sess)
    return clean({"items": rows, "asof": asof, "session": sess})


_px_cache = {"at": 0.0, "key": "", "items": {}}


@app.get("/api/manual/prices")
def manual_prices(symbols: str = ""):
    """Last price and % change for a handful of tickers (trade pad chips). Cached 4 s."""
    import time as _tm
    e = need_engine()
    syms = []
    for s in symbols.replace(" ", "").upper().split(","):
        if s and s not in syms:
            try:
                syms.append(_valid_sym(s))
            except Exception:
                pass
    syms = syms[:40]
    key = ",".join(syms)
    if _tm.time() - _px_cache["at"] < 4 and _px_cache["key"] == key:
        return clean({"items": _px_cache["items"], "session": _px_cache.get("sess", "")})
    sess = _session_name(e)
    out = {}
    for s in syms:
        try:
            pr = _price(e, s, sess)
            last, pc = pr.get("last"), pr.get("prev_close")
            if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or last is None):
                last = (pr["bid"] + pr["ask"]) / 2        # nights/extended: the last trade can be hours old
            if last:
                out[s] = {"last": last, "pct": ((last / pc - 1) * 100) if pc else None}
        except Exception:
            continue
    _px_cache.update(at=_tm.time(), key=key, items=out, sess=sess)
    return clean({"items": out, "session": sess})


@app.get("/api/manual/levels/{symbol}")
def manual_levels(symbol: str, side: str = "buy", entry: float | None = None):
    """Suggested stop-loss / take-profit (Scalp / Day / Swing) for a manual order."""
    from autobot.levelsuggest import suggest
    e = need_engine()
    sym = _valid_sym(symbol)
    side = "sell" if side.lower() == "sell" else "buy"
    try:
        df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        raise HTTPException(400, f"Couldn't load bars for {sym}: {str(ex)[:160]}")
    if df is None or len(df) < 20:
        raise HTTPException(400, f"Not enough recent data for {sym} to suggest levels yet.")
    if not entry:
        sess = _session_name(e)
        pr = _price(e, sym, sess)
        if sess == "REGULAR" and pr.get("bid"):
            entry = pr["ask"] if side == "buy" else pr["bid"]
        else:                                   # closed / extended: Alpaca prices brackets off the last trade
            entry = pr.get("last") or float(df["close"].iloc[-1])
    daily = None
    if hasattr(e.broker, "_daily_stats"):
        try:
            daily = e.broker._daily_stats([sym]).get(sym)
        except Exception:
            daily = None
    bias = "NEUTRAL"
    try:
        bias = analyze(sym, df, e.bias, learner).get("bias", "NEUTRAL")
    except Exception:
        pass
    acct = e.acct or {}
    res = suggest(side, float(entry), df, daily, bias, settings.daily_max_loss, settings.risk_per_trade_frac,
                  acct.get("buying_power", 0))
    res.update(symbol=sym, as_of=as_of)
    return clean(res)


def _friendly_reject(msg: str) -> str:
    """Turn Alpaca's JSON errors into plain words (the raw text stays in the log)."""
    import json as _j
    logging.warning("Order rejected: %s", msg)
    d = {}
    try:
        d = _j.loads(msg[msg.index("{"):])
        m = d.get("message", msg)
    except Exception:
        m = msg
    low = m.lower()
    if "stop_loss.stop_price must be" in low:
        return f"Stop-loss is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the stop."
    if "take_profit.limit_price must be" in low:
        return f"Take-profit is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the target."
    if "insufficient buying power" in low:
        return "Not enough buying power for this order. Lower the quantity."
    if "not shortable" in low or "cannot be sold short" in low:
        return "This stock can't be shorted right now."
    if "extended hours" in low:
        return "This order type isn't allowed in extended hours. Use a limit order."
    if "margin call" in low or "intraday" in low:
        return "Not enough intraday buying power (Alpaca's intraday margin rules). Use a smaller size or close something first."
    if "pattern day" in low or "day trad" in low:
        return "Blocked by a broker trading restriction. (The old $25k day-trade rule ended June 4, 2026; if you still see this, contact Alpaca.)"
    return "Alpaca rejected the order: " + m[:220]


class ManualOrder(BaseModel):
    symbol: str
    side: str                       # buy | sell
    qty: float = 0
    dollars: float = 0              # alternative to qty: spend about this much
    order_type: str = "market"      # market | limit | stop | stop_limit | trailing_stop
    limit_price: float | None = None
    stop_price: float | None = None     # trigger for stop / stop_limit
    trail_percent: float | None = None  # trailing_stop: trail by % ...
    trail_price: float | None = None    # ... or by $
    tif: str = "day"                # day | gtc | ioc | fok | opg | cls
    session: str = "auto"           # regular | extended | 24h | auto (= the session open now)
    stop: float | None = None       # optional stop-loss leg (regular hours, market/limit)
    target: float | None = None     # optional take-profit leg (regular hours, market/limit)
    confirm_short: bool = False
    harvest: bool = False           # ♻ auto-harvest: bank a small gain, then re-enter on a pullback


SESSION_LABEL = {"regular": "Market hours", "extended": "Extended hours", "24h": "24 Hour Market"}
TIF_LABEL = {"day": "Good for day", "gtc": "Good 'til canceled", "ioc": "Immediate or cancel",
             "fok": "Fill or kill", "opg": "At the open", "cls": "At the close"}


@app.post("/api/manual/order")
def manual_order(r: ManualOrder):
    import math
    import uuid
    e = need_engine()
    sym, side = _valid_sym(r.symbol), r.side.lower()
    ot, tif = r.order_type.lower(), r.tif.lower()
    if side not in ("buy", "sell"):
        raise HTTPException(400, "Side must be buy or sell")
    if ot not in ("market", "limit", "stop", "stop_limit", "trailing_stop"):
        raise HTTPException(400, "Unknown order type")
    if tif not in TIF_LABEL:
        raise HTTPException(400, "Unknown time in force")
    if sym in e.trades:
        raise HTTPException(409, f"The bot is managing {sym}. Close it first (Positions → Close) or wait for the bot's exit.")
    now_sess = _session_name(e)
    sess = r.session.lower()
    if sess == "auto":
        sess = {"PRE": "extended", "AFTER": "extended", "OVERNIGHT": "24h"}.get(now_sess, "regular")
    if sess not in SESSION_LABEL:
        raise HTTPException(400, "Unknown trading session")
    ext = sess != "regular"

    # ---- v2.5.5: extended / night sessions accept limit orders only. A market order from the ticket becomes a limit priced
    # 0.2% through the far side of the spread (buy above the ask, sell below the bid), so it still fills like a market order ----
    auto_limit_note = ""
    if ext and ot == "market" and not (r.stop or r.target):
        _bq = _quote(e, sym, now_sess if now_sess in ("PRE", "AFTER", "OVERNIGHT") else "OVERNIGHT")
        _b0, _a0 = _bq
        _ref0 = _a0 if side == "buy" else _b0
        if _ref0:
            _px0 = _ref0 * (1.002 if side == "buy" else 0.998)
            _px0 = round(_px0, 2 if _px0 >= 1 else 4)
            ot, r.order_type, r.limit_price = "limit", "limit", _px0
            auto_limit_note = (f"{SESSION_LABEL[sess]} accepts limit orders only, so your market order was sent as a limit at ${_px0:,.{2 if _px0 >= 1 else 4}f} "
                               f"(0.2% {'above the ask' if side == 'buy' else 'below the bid'}) to cover the spread. It fills at the best price available up to that limit.")
    # ---- the rules Alpaca applies, checked here first so the message is clear ----
    if ext and ot != "limit":
        raise HTTPException(400, f"{SESSION_LABEL[sess]} accepts limit orders only. Switch the order type to Limit.")
    if ext and tif not in ("day", "gtc"):
        raise HTTPException(400, f"{SESSION_LABEL[sess]} orders must be Good for day or Good 'til canceled.")
    if tif in ("opg", "cls") and ot not in ("market", "limit"):
        raise HTTPException(400, "At the open / At the close work with market or limit orders only.")
    if ot == "trailing_stop" and tif not in ("day", "gtc"):
        raise HTTPException(400, "Trailing stops must be Good for day or Good 'til canceled.")
    legs = bool(r.stop or r.target)
    if legs and (ext or ot not in ("market", "limit") or tif not in ("day", "gtc")):
        raise HTTPException(400, "Stop-loss / take-profit can only be attached to a market or limit order, "
                                 "in Market hours, Good for day or Good 'til canceled.")

    bid, ask = _quote(e, sym, now_sess)
    ref = ask if side == "buy" else bid
    if ot in ("limit", "stop_limit"):
        if not r.limit_price or r.limit_price <= 0:
            raise HTTPException(400, "Enter a limit price")
        ref = r.limit_price
    if ot in ("stop", "stop_limit"):
        if not r.stop_price or r.stop_price <= 0:
            raise HTTPException(400, "Enter a stop price")
        ref = ref if ot == "stop_limit" else r.stop_price
    if ot == "trailing_stop":
        if not (r.trail_percent or r.trail_price) or (r.trail_percent or 0) < 0 or (r.trail_price or 0) < 0:
            raise HTTPException(400, "Enter a trail amount (% or $)")
    if not ref:
        raise HTTPException(400, f"No price available for {sym} right now")
    qty = math.floor(r.qty) if r.qty else (math.floor(r.dollars / ref) if r.dollars else 0)
    if qty < 1:
        raise HTTPException(400, "Enter at least 1 share (or a dollar amount worth at least 1 share)")

    held = (e.broker.positions().get(sym) or {}).get("qty", 0)
    if side == "sell" and held < qty and not r.confirm_short:
        raise HTTPException(409, "SHORT_CONFIRM")
    d = 1 if side == "buy" else -1
    if r.stop and (ref - r.stop) * d <= 0:
        raise HTTPException(400, f"Stop-loss must be {'below' if d > 0 else 'above'} the entry price ({ref:.2f})")
    if r.target and (r.target - ref) * d <= 0:
        raise HTTPException(400, f"Take-profit must be {'above' if d > 0 else 'below'} the entry price ({ref:.2f})")

    notes = [auto_limit_note] if auto_limit_note else []
    open_now = {"regular": now_sess == "REGULAR", "extended": now_sess in ("PRE", "REGULAR", "AFTER"),
                "24h": now_sess != "CLOSED"}[sess]
    if sess == "24h" and tif == "day" and now_sess != "OVERNIGHT":
        notes.append("Good for day ends at 8 PM ET today. Choose Good 'til canceled to keep it working overnight.")
    if not open_now and tif not in ("opg", "cls"):
        notes.append(f"{SESSION_LABEL[sess]} isn't open right now: the order waits and works from the start of the next session.")
    try:
        if not auto_limit_note and ((side == "buy" and held >= 0) or (side == "sell" and held <= 0)):
            _b, _a = _quote(e, sym, sess)
            if _b and _a and _a > _b and settings.max_spread_pct and (_a - _b) / ((_a + _b) / 2) * 100 > settings.max_spread_pct:
                _sp = (_a - _b) / ((_a + _b) / 2) * 100
                notes.append(f"Heads-up: {sym}'s spread is {_sp:.2f}% (bid {_b:.2f} / ask {_a:.2f}). A market order starts about "
                             f"${(_a - _b) / 2 * qty:,.0f} under water and the exit pays the same again. A limit near the middle does better.")
    except Exception:
        pass
    try:
        _eq = float(getattr(e.risk, "equity", 0) or 0)
        _cap = float(getattr(settings, "max_position_pct_equity", 0.15) or 0.15)
        if _eq > 0 and ref and qty * ref > max(2 * _cap, 0.30) * _eq and ((side == "buy" and held >= 0) or (side == "sell" and held <= 0)):
            notes.append(f"Heads-up: this is ${qty * ref:,.0f}, {qty * ref / _eq * 100:.0f}% of your equity. The bot never puts more than "
                         f"{_cap * 100:.0f}% in one trade. Your biggest losses so far were large hand-sized positions.")
    except Exception:
        pass
    try:
        oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=r.stop or None,
                                    target=r.target or None, extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                    stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                    trail_price=r.trail_price or None, tif=tif)
    except Exception as ex:
        import re
        msg = str(ex)
        m = re.search(r'"base_price"\s*:\s*"?([0-9.]+)', msg)
        if m and (r.stop or r.target):
            # Alpaca checks the stop/target against its reference price (the last trade while closed).
            # Keep the same distances, re-anchor them on that price, and try once more.
            base = float(m.group(1))
            ref = r.limit_price if (ot == "limit" and r.limit_price) else base
            shift = base - (bid if side == "sell" else ask) if ot != "limit" else 0
            new_stop = round(r.stop + shift, 2) if r.stop else None
            new_tgt = round(r.target + shift, 2) if r.target else None
            if new_stop and (ref - new_stop) * (1 if side == "buy" else -1) < 0.01:
                new_stop = round(ref - (0.01 if side == "buy" else -0.01) - abs(r.stop - (ask if side == "buy" else bid)) * (1 if side == "buy" else -1), 2)
            try:
                oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=new_stop, target=new_tgt,
                                            extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                            stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                            trail_price=r.trail_price or None, tif=tif)
                notes.append(f"Auto-fixed: Alpaca prices this order from {base:.2f}, so the stop-loss / take-profit were "
                             f"moved by the same amount to {new_stop or '—'} / {new_tgt or '—'}.")
                r.stop, r.target = new_stop, new_tgt
            except Exception as ex2:
                raise HTTPException(400, _friendly_reject(str(ex2)))
        else:
            raise HTTPException(400, _friendly_reject(msg))
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    px = {"market": "market", "limit": f"limit {r.limit_price:.2f}" if r.limit_price else "limit",
          "stop": f"stop {r.stop_price}", "stop_limit": f"stop {r.stop_price} limit {r.limit_price}",
          "trailing_stop": f"trailing {str(r.trail_percent) + '%' if r.trail_percent else '$' + str(r.trail_price)}"}[ot]
    extra = " ".join(x for x in (f"SL {r.stop:.2f}" if r.stop else "", f"TP {r.target:.2f}" if r.target else "") if x)
    if r.harvest:
        if ot not in ("market", "limit"):
            notes.append("Auto-harvest works with market or limit orders, so it was not turned on for this one.")
        elif (side == "buy" and held >= 0) or (side == "sell" and held <= 0):
            harvester.arm(sym, side, qty)
            notes.append("♻ Auto-harvest is ON: it banks a small gain, then re-enters on a pullback, until you tap Stop."
                         + (" It replaces the stop-loss / take-profit you attached with its own protective stop." if legs else ""))
        else:
            notes.append("Auto-harvest only works on an order that opens a position, not one that closes it.")
    e.event(f"MANUAL {side.upper()} {qty} {sym} {px} · {TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}")
    e.alert("manual", f"You: {side.upper()} {qty} {sym} {px}", f"{TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}",
            symbol=sym, close_btn=True)
    return {"ok": True, "order_id": oid, "qty": qty, "notes": notes}


class ManualClose(BaseModel):
    symbol: str
    pct: float = 100
    urgent: bool = False            # True = take the bid/ask right now (no patient ladder)


def _remember_close(e, sym, side, qty, hv):
    """Keep the last manual close so one tap can reopen it."""
    import json
    e.last_close = {"symbol": sym, "side": side, "qty": float(qty), "hv": bool(hv),
                    "at": e.broker.now().strftime("%H:%M")}
    try:
        (DATA_DIR / "last_close.json").write_text(json.dumps(e.last_close))
    except Exception:
        pass


def _last_close(e):
    import json
    lc = getattr(e, "last_close", None)
    if lc is None:
        try:
            lc = json.loads((DATA_DIR / "last_close.json").read_text())
            e.last_close = lc
        except Exception:
            lc = None
    return lc


@app.post("/api/manual/reopen")
def manual_reopen():
    """One tap, no confirmation: put back the position you last closed by hand (same stock, side and size)."""
    import uuid
    e = need_engine()
    lc = _last_close(e)
    if not lc:
        raise HTTPException(404, "Nothing to reopen yet: close a position first.")
    sym, side, qty = lc["symbol"], lc["side"], int(lc["qty"])
    if sym in e.trades:
        raise HTTPException(409, f"The bot is managing {sym} right now.")
    sess = _session_name(e)
    if sess == "CLOSED":
        raise HTTPException(400, "The market is closed. Reopen it when a session is open.")
    bid, ask = _quote(e, sym, sess)
    if not bid or not ask:
        raise HTTPException(400, f"No {sym} quote right now")
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    if sess == "OVERNIGHT" and side == "sell":
        raise HTTPException(400, "Shorting isn't available overnight.")
    held = (e.broker.positions().get(sym) or {}).get("qty", 0)
    if held * (1 if side == "buy" else -1) > 0:
        raise HTTPException(409, f"You already hold {sym}.")
    try:
        if ext:
            px = round(ask * 1.002, 2) if side == "buy" else round(bid * 0.998, 2)
            e.broker.manual_order(sym, side, qty, "limit", limit_price=px, extended=True,
                                  client_id=f"man-{uuid.uuid4().hex[:12]}", tif="day")
        else:
            e.broker.manual_order(sym, side, qty, "market", client_id=f"man-{uuid.uuid4().hex[:12]}")
    except Exception as ex:
        raise HTTPException(400, _friendly_reject(str(ex)))
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    note = ""
    if lc.get("hv"):
        harvester.arm(sym, side, qty)
        note = " · ♻ auto-harvest back ON"
    e.event(f"MANUAL REOPEN {side.upper()} {qty} {sym} (repeat of your {lc['at']} close){note}")
    e.alert("manual", f"You: reopened {side.upper()} {qty} {sym}", "One-tap reopen of your last close" + note, symbol=sym, close_btn=True)
    return {"ok": True, "symbol": sym, "qty": qty, "side": side}


class ManualFlip(BaseModel):
    symbol: str


def _flip_two_step(e, sym, pos):
    """v2.22.1: 🔄 Flip in TWO orders: close first, then open the other way once the position is flat. (One order that crosses zero is
    rejected by some accounts / sessions, which is why the one-order flip 'did nothing'.) Gates are the same as a bot short.
    Returns the plain-words start message; the second step runs in the background and reports by alert."""
    import math
    from autobot.sessions import bot_day
    q = abs(float(pos["qty"]))
    long_ = float(pos["qty"]) > 0
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    now = e.broker.now()
    if e.risk.remaining <= 0 or e.risk.halted:
        raise RuntimeError("the daily loss limit is used up, so no new position")
    if long_:                                   # a long flips to a SHORT: same gates as the bot's own shorts
        if not (e.shorts_allowed(now) and e.acct.get("shorting_enabled", True)):
            raise RuntimeError("shorts aren't allowed right now (the 7 AM rule, the shorts switch, or your account)")
        if sess == "OVERNIGHT" and not getattr(settings, "shorts_24_5", False):
            raise RuntimeError("overnight shorting is off (Settings: 24/5 shorts). Use Close all instead")
        ok, why2 = e._can_short(sym)
        if not ok:
            raise RuntimeError(why2)
    bid, ask = _quote(e, sym, sess)
    px = (bid if long_ else ask) or pos.get("price")
    if not px:
        raise RuntimeError("no live price")
    eq = float(getattr(e.risk, "equity", 0) or 0)
    new_qty = int(q if eq <= 0 else min(q, math.floor(0.30 * eq / float(px))))
    if new_qty < 1:
        raise RuntimeError("too small to flip")
    e.broker.cancel_symbol_orders(sym)
    close_side, open_side = ("sell", "sell") if long_ else ("buy", "buy")

    def send(side, qty, ref_px):
        import uuid
        cid = f"man-flip-{uuid.uuid4().hex[:10]}"
        if ext:
            lim = round(float(ref_px) * (0.999 if side == "sell" else 1.001), 2)
            return e.broker.manual_order(sym, side, int(qty), "limit", limit_price=lim, extended=True, client_id=cid, tif="day")
        return e.broker.manual_order(sym, side, int(qty), "market", client_id=cid, tif="day")

    send(close_side, int(q) if q == int(q) else q, px)
    e.manual_syms[sym] = bot_day(now)

    def worker():
        import time as _t
        try:
            flat = False
            for k in range(60):                               # up to ~2 minutes for the close to fill
                _t.sleep(2)
                if not (e.broker.positions().get(sym)):
                    flat = True
                    break
                if ext and k in (20, 40):                      # thin books: re-price the close at the latest quote
                    try:
                        e.broker.cancel_symbol_orders(sym)
                        b2, a2 = _quote(e, sym, _session_name(e))
                        left = abs(float((e.broker.positions().get(sym) or {}).get("qty") or 0))
                        if left:
                            send(close_side, left if left != int(left) else int(left), (b2 if long_ else a2) or px)
                    except Exception:
                        pass
            if not flat:
                e.event(f"FLIP {sym}: the close has not filled yet, so the new position was NOT opened. Check Positions & Orders.")
                alerts.send("jump", f"🔄 Flip {sym}: close not filled", "The new position was not opened. Check Positions & Orders.", symbol=sym, level="warning")
                return
            b2, a2 = _quote(e, sym, _session_name(e))
            p2 = (a2 if long_ else b2) or px                  # opening a short sells at the bid, opening a long buys at the ask
            eq2 = float(getattr(e.risk, "equity", 0) or 0)
            n2 = int(new_qty if eq2 <= 0 else min(new_qty, math.floor(0.30 * eq2 / float(p2))))
            if n2 < 1:
                e.event(f"FLIP {sym}: closed, but too small to open the other way")
                return
            if e.risk.remaining <= 0 or e.risk.halted:
                e.event(f"FLIP {sym}: closed; the daily loss limit is used up, so no new position")
                return
            send(open_side, n2, (b2 if long_ else a2) or px)
            e.manual_syms[sym] = bot_day(e.broker.now())
            hv = ""
            if getattr(settings, "guard_flip_harvest", True):
                harvester.arm(sym, "sell" if long_ else "buy", n2, note="flipped: waiting for the reversal to fill")
                harvester.jobs[sym]["flip"] = True
            msg = f"Closed {int(q):,} and opened a {n2:,} {'short' if long_ else 'long'}."
            e.event(f"MANUAL FLIP {sym}: {msg}")
            alerts.send("jump", f"🔄 Flipped {sym}", msg + (" (limit order, it may take a moment to fill)" if ext else ""), symbol=sym, level="info")
        except Exception as ex:
            logging.exception("flip worker failed")
            e.event(f"FLIP {sym}: stopped after the close: {str(ex)[:150]}")
            alerts.send("jump", f"🔄 Flip {sym} stopped", f"The position is closed but the new one was not opened: {str(ex)[:120]}", symbol=sym, level="warning")
    threading.Thread(target=worker, daemon=True).start()
    return (f"Closing your {int(q):,} {sym} {'long' if long_ else 'short'} now. When it is flat I will open a {new_qty:,} "
            f"{'short' if long_ else 'long'}" + (" (extended hours: limit orders, this can take a minute)" if ext else "") + ". You'll get an alert.")


@app.post("/api/manual/flip")
def manual_flip(r: ManualFlip):
    """v2.22.1: 🔄 Flip. Reverse one of YOUR positions: close it, then open the other way (up to the same size, max 30% of equity)."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    t = e.trades.get(sym)
    if t is not None and t.status == "open":
        raise HTTPException(409, f"The bot is managing {sym}. Close it first, then trade the other way.")
    if _walkers.get(sym):
        raise HTTPException(409, f"A close for {sym} is already working. Cancel it first.")
    try:
        harvester.stop(sym, "flipped by hand")
    except Exception:
        pass
    closeplans.cancel(sym)
    try:
        msg = _flip_two_step(e, sym, pos)
    except RuntimeError as ex:
        raise HTTPException(400, "Can't flip " + sym + ": " + str(ex))
    except Exception as ex:
        raise HTTPException(400, "Alpaca rejected the flip: " + str(ex)[:200])
    e.event(f"MANUAL FLIP {sym} started: {msg}")
    return {"ok": True, "msg": msg}


@app.post("/api/manual/close")
def manual_close(r: ManualClose):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    res = _close_now(e, sym, r.pct, urgent=r.urgent)
    if r.pct >= 100:
        closeplans.cancel(sym)               # closed by hand: any ⏰ plan for it is done
    return res


def _close_now(e, sym, pct=100, urgent=True, note="manual close"):
    """Close all (pct=100) or part of a position right now, the right way for the session.
    urgent=False (the Close button) uses the patient ladder when the spread is wide, to keep a win a win."""
    import math
    import uuid
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    q = abs(pos["qty"])
    qty = q if pct >= 100 else max(1, math.floor(q * pct / 100))
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    t = e.trades.get(sym)
    if t is not None and t.status != "open":
        t = None                            # a finished bot trade must not hijack a manual close
    if t:                                   # a bot trade: close it the bot's way so the journal/learner stay right
        if qty < q:
            raise HTTPException(400, "Bot trades can only be closed in full")
        t.note = note
        if ext and t.ext:
            bid, ask = _quote(e, sym, sess)
            ref = ask if t.dir < 0 else bid          # a short is covered at the ask, a long sold at the bid
            again = bool(t.exit_order_id)            # a second tap while the first order is still working = take the market now
            t.exit_order_id = ""                     # a new tap re-prices an exit that hasn't filled
            e._ext_exit(t, "manual close (now)" if again else "manual close", ref or t.last_price or t.entry)
            if again:
                e.event(f"Second tap on {sym}: taking the market price now")
            e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy})")
            return {"ok": True, "qty": qty, "notes": ["Extended hours: sent a limit order to close the bot's trade. "
                                                      "The bot re-prices it every 20 seconds until it fills."]}
        if not ext:
            if e.broker.close_position(sym) is False:
                raise HTTPException(400, "Alpaca rejected the close: " + (getattr(e.broker, "last_close_error", "") or "unknown")[:220])
            e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy})")
            return {"ok": True, "qty": qty, "notes": []}
        # a bot trade opened in regular hours but still open after hours: close it with a limit order below
        e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy}) - extended-hours limit")
    notes = []
    if not t:
        w = _walkers.get(sym)
        if w:
            w["urgent"] = True                        # tapping Close again = stop waiting, take the price now
            notes.append("Taking the bid/ask now (second tap).")
            return {"ok": True, "qty": qty, "notes": notes}
        if not urgent:
            walk = _start_smart_close(e, sym, qty, pos["qty"] < 0, sess, ext)
            if walk:
                _remember_close(e, sym, "buy" if pos["qty"] > 0 else "sell", qty, harvester.jobs.get(sym) is not None)
                if qty >= q and sym in harvester.jobs:
                    harvester.stop(sym, "you closed the position")
                e.event(f"MANUAL CLOSE {qty:g} {sym} (patient: " + walk + ")")
                return {"ok": True, "qty": qty, "notes": [
                    "The spread is wide, so the bot is working the order from the better side toward the market over about a minute "
                    "to keep more of your gain. Tap Close again to take the market price right now."]}
    try:
        if ext:
            # Outside regular hours Alpaca only takes LIMIT orders marked extended-hours - for a long
            # (sell) AND for a short (buy to cover). Price a little through the quote so it fills.
            e.broker.cancel_symbol_orders(sym)
            import time as _tm
            _tm.sleep(0.4)
            bid, ask = _quote(e, sym, sess)
            short = pos["qty"] < 0
            ref = ask if short else bid
            if not ref:
                ref = pos.get("price")                   # no live quote: price off the position's last price
            if not ref:
                raise HTTPException(400, f"No {sym} quote right now - try again in a few seconds")
            px = round(ref * (1.003 if short else 0.997), 2)
            e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit", limit_price=px, extended=True,
                                  client_id=f"manx-{uuid.uuid4().hex[:12]}")
            notes.append(f"Extended hours: sent a limit {'buy to cover' if short else 'sell'} of {qty:g} {sym} at {px:.2f}. "
                         "If it hasn't filled in a minute, press Close again (it re-prices at the new quote).")
        else:
            e.broker.close_qty(sym, qty)
            if qty < q:
                notes.append("Any stop-loss / take-profit on this position was cancelled - set new ones if you want them.")
            if sess == "CLOSED":
                notes.append("The market is closed: it will close at the open.")
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(400, f"Alpaca rejected the close: {str(ex)[:220]}")
    _remember_close(e, sym, "buy" if pos["qty"] > 0 else "sell", qty, harvester.jobs.get(sym) is not None)
    if qty >= q and sym in harvester.jobs:   # a full close you asked for: auto-harvest must not buy back in
        harvester.stop(sym, "you closed the position")
        notes.append("♻ Auto-harvest turned off for " + sym + ".")
    e.event(f"MANUAL CLOSE {qty:g} {sym}" + (" (partial)" if qty < q else ""))
    return {"ok": True, "qty": qty, "notes": notes}


_walkers: dict = {}
WALK_MIN_SPREAD_PCT = 0.04          # spreads tighter than this are not worth being patient over
WALK_STEPS = (0.75, 0.5, 0.25)      # start near the favourable side, then walk toward the market, then take it
WALK_SECS_EXT, WALK_SECS_REG = 14, 6


def _start_smart_close(e, sym, qty, short, sess, ext):
    """Patient exit for a manual close. Returns a short description if a walker started, else '' (use the urgent path)."""
    bid, ask = _quote(e, sym, sess)
    if not bid or not ask or ask <= bid:
        return ""
    spr = ask - bid
    if spr / ((bid + ask) / 2) * 100 < WALK_MIN_SPREAD_PCT:
        return ""
    import threading
    import uuid
    w = _walkers[sym] = {"urgent": False}
    step_secs = WALK_SECS_EXT if ext else WALK_SECS_REG

    def flat():
        p = e.broker.positions().get(sym)
        return (not p) or abs(p["qty"]) <= (abs(pos0) - qty) + 1e-6

    pos0 = (e.broker.positions().get(sym) or {"qty": qty})["qty"]

    def run():
        try:
            start_ref = None
            for f in WALK_STEPS:
                if w["urgent"]:
                    break
                b, a = _quote(e, sym, sess)
                if not b or not a or a <= b:
                    break
                ref = a if short else b
                start_ref = start_ref or ref
                if abs(ref - start_ref) > 1.0 * spr and (ref > start_ref if short else ref < start_ref):
                    break                                   # price is running away from us: stop being patient
                px = round(b + f * (a - b), 2) if not short else round(a - f * (a - b), 2)
                px = max(px, b) if not short else min(px, a)
                e.broker.cancel_symbol_orders(sym)
                time_sleep(0.3)
                e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit", limit_price=px, extended=ext,
                                      client_id=f"manw-{uuid.uuid4().hex[:12]}")
                end = time_mod.time() + step_secs
                while time_mod.time() < end and not w["urgent"]:
                    time_sleep(1.0)
                    if flat():
                        e.event(f"Patient close of {sym} filled at about {px:.2f}")
                        return
            if flat():
                return
            e.broker.cancel_symbol_orders(sym)
            time_sleep(0.4)
            b, a = _quote(e, sym, sess)
            if ext:
                ref = (a if short else b) or (e.broker.positions().get(sym) or {}).get("price")
                if ref:
                    e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit",
                                          limit_price=round(ref * (1.003 if short else 0.997), 2), extended=True,
                                          client_id=f"manx-{uuid.uuid4().hex[:12]}")
            else:
                e.broker.close_qty(sym, qty)
        except Exception as ex:
            e.event(f"Patient close of {sym} failed ({str(ex)[:100]}); closing at the market", "warning")
            try:
                e.broker.cancel_symbol_orders(sym)
                if not ext:
                    e.broker.close_qty(sym, qty)
            except Exception:
                pass
        finally:
            _walkers.pop(sym, None)

    threading.Thread(target=run, daemon=True, name=f"walk-{sym}").start()
    return f"spread {spr / ((bid + ask) / 2) * 100:.2f}%"


@app.get("/api/manual/book")
def manual_book():
    """Every position and open order in the account, marked bot or manual."""
    e = need_engine()
    pos = e.broker.positions()
    try:
        orders = e.broker.open_orders()
    except Exception:
        orders = []
    bot_ids = {t.order_id for t in e.trades.values()} | {t.tp_order_id for t in e.trades.values()} | \
              {t.exit_order_id for t in e.trades.values()}
    plans = {p["symbol"]: p for p in closeplans.list()}
    rows = [{"symbol": s, "qty": p["qty"], "avg": p["avg_entry"], "price": p["price"], "upl": p["upl"], "plan": plans.get(s),
             "upl_pct": (p["price"] / p["avg_entry"] - 1) * 100 * (1 if p["qty"] > 0 else -1) if p["avg_entry"] else 0,
             "b_price": p["price"], "b_upl": p["upl"],      # Alpaca's own numbers, untouched (the screen may swap in a live quote after hours)
             "bot": s in e.trades, "hv": s in harvester.jobs} for s, p in sorted(pos.items())]
    try:                                    # what closing right now would really fill at: bid for longs, ask for shorts
        qs = e.broker.quotes([r["symbol"] for r in rows], _session_name(e)) or {}
        lts = e.broker.last_trades([r["symbol"] for r in rows], _session_name(e)) if (_session_name(e) not in ("REGULAR", "CLOSED") and hasattr(e.broker, "last_trades")) else {}
        for r in rows:
            q = qs.get(r["symbol"])
            if q and q[0] and q[1]:
                xp = q[0] if r["qty"] > 0 else q[1]
                r["exit_px"] = xp
                r["bid"], r["ask"] = q[0], q[1]
                r["exit_upl"] = round((xp - r["avg"]) * r["qty"], 2)
                if _session_name(e) not in ("REGULAR", "CLOSED"):      # Alpaca's own price is the stale regular-session last trade
                    now_ny = e.broker.now()
                    mid = (q[0] + q[1]) / 2
                    px, src, ts = mid, "mid quote", (q[2] if len(q) > 2 else None)
                    lt = lts.get(r["symbol"])
                    if lt and (now_ny - lt[1]).total_seconds() <= 1200 and (ts is None or lt[1] >= ts - timedelta(seconds=30)
                                                                           or q[0] * 0.998 <= lt[0] <= q[1] * 1.002):
                        px, src, ts = lt[0], "last trade", lt[1]      # a real recent print beats the middle of a wide quote
                    r["price"] = round(px, 4)
                    r["upl"] = round((px - r["avg"]) * r["qty"], 2)
                    r["upl_pct"] = (px / r["avg"] - 1) * 100 * (1 if r["qty"] > 0 else -1) if r["avg"] else 0
                    r["px_src"] = src
                    r["px_age_s"] = int((now_ny - ts).total_seconds()) if ts else None
                    r["spread"] = round(q[1] - q[0], 4)
    except Exception:
        pass
    for o in orders:
        o["bot"] = o["id"] in bot_ids or o["client_id"].startswith(("ab-", "abx-", "abt-", "abe-")) or o["symbol"] in e.trades
    burl = None
    if e.mode == "PAPER":
        burl = "https://app.alpaca.markets/paper/dashboard/overview"
    elif e.mode == "LIVE":
        burl = "https://app.alpaca.markets/brokerage/dashboard/overview"
    return clean({"positions": rows, "orders": orders, "session": _session_name(e), "mode": e.mode, "broker_url": burl,
                  "harvest": harvester.status(), "last_close": _last_close(e)})


# ---------------- ♻ auto-harvest (manual trades) ----------------
def _hv_px(bid, ask, side, tries):
    """v2.17.5: don't give away the spread. Buy: start at the middle of bid/ask and walk up to the ask over the retries
    (sell: down from the middle to the bid). Retry 3 and later cross the spread so the order still gets done."""
    spr = max(ask - bid, 0.0)
    frac = (0.5, 0.75, 1.0)[min(max(tries, 1), 3) - 1]
    return round(bid + spr * frac, 2) if side == "buy" else round(ask - spr * frac, 2)


def _hv_open(e, sym, side, qty, sess, bid, ask, tries):
    import uuid
    cid = f"manh-{uuid.uuid4().hex[:12]}"
    try:                                     # a re-entry must fit today's buying power: shrink instead of being rejected
        bp = float(e.broker.account().get("buying_power", 0) or 0)
        ref = ask if side == "buy" else bid
        if bp > 0 and ref:
            qty = max(1, min(int(qty), int(0.95 * bp / ref)))
    except Exception:
        pass
    if sess in ("PRE", "AFTER", "OVERNIGHT"):
        px = _hv_px(bid, ask, side, tries) if tries < 3 else (round(ask * (1 + 0.001 * tries), 2) if side == "buy" else round(bid * (1 - 0.001 * tries), 2))
        e.broker.manual_order(sym, side, qty, "limit", limit_price=px, extended=True, client_id=cid, tif="day")
    elif tries < 3 and ask > bid:
        e.broker.manual_order(sym, side, qty, "limit", limit_price=_hv_px(bid, ask, side, tries), client_id=cid, tif="day")
    else:
        e.broker.manual_order(sym, side, qty, "market", client_id=cid)


def _hv_close(e, sym, qty, side, sess, bid, ask, tries, urgent=False):
    """urgent (a protective stop) always crosses the spread. A profit harvest starts at the middle and walks to the far side."""
    import uuid
    passive = not urgent and tries < 3 and ask > bid
    if sess in ("PRE", "AFTER", "OVERNIGHT"):
        e.broker.cancel_symbol_orders(sym)
        cid = f"manh-{uuid.uuid4().hex[:12]}"
        osd = "sell" if side == "buy" else "buy"
        if passive:
            px = _hv_px(bid, ask, osd, tries)
        else:
            px = round(bid * (1 - 0.002 * tries), 2) if side == "buy" else round(ask * (1 + 0.002 * tries), 2)
        e.broker.manual_order(sym, osd, qty, "limit", limit_price=px, extended=True, client_id=cid, tif="day")
    elif passive:
        e.broker.cancel_symbol_orders(sym)
        e.broker.manual_order(sym, "sell" if side == "buy" else "buy", qty, "limit", limit_price=_hv_px(bid, ask, "sell" if side == "buy" else "buy", tries),
                              client_id=f"manh-{uuid.uuid4().hex[:12]}", tif="day")
    else:
        e.broker.cancel_symbol_orders(sym)
        e.broker.close_qty(sym, qty)


def _plan_alert(kind, title, body, sym, speak):
    try:
        alerts.send(kind, title, body, symbol=sym, speak=speak)
    except Exception:
        pass


def _plan_close(e, sym):
    return _close_now(e, sym, 100).get("notes", [])


from autobot.closeplan import ClosePlans  # noqa: E402
closeplans = ClosePlans(lambda: engine, _plan_close, _session_name, lambda e, sym, sess: _quote(e, sym, sess),
                        _plan_alert, DATA_DIR / "close_plans.json")


def _guard_flip(e, sym, pos, why):
    """Guard 'flip' mode: reverse a manual position in ONE order (sell 2x a long = close it and open a same-size short,
    and the reverse for a short). Raises with the reason when it can't, and the guard then just closes."""
    import math
    import uuid
    from autobot.sessions import bot_day
    q = abs(pos["qty"])
    long_ = pos["qty"] > 0
    side = "sell" if long_ else "buy"
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    now = e.broker.now()
    if e.risk.remaining <= 0 or e.risk.halted:
        raise RuntimeError("the daily loss limit is used up, so no new position")
    if long_:                                   # flipping to a short: same gates as the bot's own shorts
        if not (e.shorts_allowed(now) and e.acct.get("shorting_enabled", True)):
            raise RuntimeError("shorts aren't allowed right now (the 7 AM rule or the shorts switch)")
        if sess == "OVERNIGHT" and not getattr(settings, "shorts_24_5", False):
            raise RuntimeError("overnight shorting is off")
        ok, why2 = e._can_short(sym)
        if not ok:
            raise RuntimeError(why2)
    bid, ask = _quote(e, sym, sess)
    ref = bid if long_ else ask
    px = ref or pos.get("price")
    if not px:
        raise RuntimeError("no live price")
    eq = float(getattr(e.risk, "equity", 0) or 0)
    new_qty = q if eq <= 0 else min(q, math.floor(0.30 * eq / px))
    if new_qty < 1:
        raise RuntimeError("too small to flip")
    e.broker.cancel_symbol_orders(sym)
    total = int(q + new_qty)
    cid = f"man-flip-{uuid.uuid4().hex[:10]}"
    if ext:
        lim = round(px * (0.999 if long_ else 1.001), 2)
        e.broker.manual_order(sym, side, total, "limit", limit_price=lim, extended=True, client_id=cid, tif="day")
    else:
        e.broker.manual_order(sym, side, total, "market", client_id=cid, tif="day")
    e.manual_syms[sym] = bot_day(now)
    hv = ""
    if getattr(settings, "guard_flip_harvest", True):
        harvester.arm(sym, "sell" if long_ else "buy", new_qty, note="flipped: waiting for the reversal to fill")
        harvester.jobs[sym]["flip"] = True                  # the guard keeps watching it, so it can flip again
        hv = " Auto-harvest is armed on the new position: it banks quick gains and re-enters while the trend holds."
    return (f"{'Sold' if long_ else 'Bought'} {total:,} to close {q:,.0f} and open a {new_qty:,} "
            f"{'short' if long_ else 'long'}" + (" (limit order, extended hours: it may take a moment to fill)" if ext else "") + "." + hv)


def _guard_close(e, sym):
    harvester.stop(sym, "the guard closed it")
    return _plan_close(e, sym)


def _guard_skip(e, sym):
    j = harvester.jobs.get(sym)
    if j and not (j.get("flip") and j.get("phase") in ("holding", "waiting", "entering")):
        return True                          # a normal harvest job, or a flipped one still waiting to fill, manages itself
    return sym in e.trades or any(p["symbol"] == sym for p in closeplans.list())


from autobot.guard_manual import ManualGuard  # noqa: E402
guard = ManualGuard(lambda: engine, lambda: settings, _session_name, lambda e, sym, sess: _quote(e, sym, sess),
                    _guard_close, _plan_alert,
                    _guard_skip,
                    _guard_flip)


class ClosePlanReq(BaseModel):
    symbol: str
    at: str | None = None          # ISO time in New York, e.g. 2026-09-30T04:00
    on_flip: bool = False
    tp: float | None = None
    sl: float | None = None


@app.get("/api/closeplan")
def closeplan_list():
    return {"plans": closeplans.list()}


@app.post("/api/closeplan")
def closeplan_set(r: ClosePlanReq):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym} and closes it itself. Use Close to take it now.")
    d = 1 if pos["qty"] > 0 else -1
    if r.tp and pos.get("price") and (r.tp - pos["price"]) * d <= 0:
        raise HTTPException(400, f"Take-profit must be {'above' if d > 0 else 'below'} the current price {pos['price']:.2f}")
    if r.sl and pos.get("price") and (r.sl - pos["price"]) * d >= 0:
        raise HTTPException(400, f"Stop must be {'below' if d > 0 else 'above'} the current price {pos['price']:.2f}")
    if r.at:
        from datetime import datetime as _dt
        try:
            when = _dt.fromisoformat(r.at)
        except ValueError:
            raise HTTPException(400, "Pick a valid time")
        when = when if when.tzinfo else when.replace(tzinfo=NY)
        if when <= e.broker.now():
            raise HTTPException(400, "That time has already passed - pick a later time")
    try:
        p = closeplans.set(sym, d, r.at, r.on_flip, r.tp, r.sl)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if sym in harvester.jobs:
        harvester.stop(sym, "a ⏰ close plan now manages this position")
    e.event(f"⏰ {sym}: {p['msg']}")
    return {"ok": True, "plan": p}


@app.post("/api/closeplan/cancel")
def closeplan_cancel(r: ManualClose):
    sym = _valid_sym(r.symbol)
    closeplans.cancel(sym)
    return {"ok": True}


harvester = Harvester(lambda: engine, lambda e, sym, sess: _quote(e, sym, sess), _session_name, _hv_open, _hv_close,
                      DATA_DIR / "harvest.json")
harvester.learn_fn = _hv_learn


# ---------------- automatic morning / night setup ----------------
def _prep_loop():
    """Every 5 minutes in pre-market and after-hours, build the movers list even when the auto-trader is stopped.
    (While the bot runs it does this itself.) The list is kept overnight, so the night setup is still there in the morning."""
    import time as _t
    from autobot.sessions import current_session
    last = 0.0
    while True:
        _t.sleep(30)
        try:
            e = engine
            if not e or not settings.auto_prep or e.running or ARGS.sim:
                continue
            if _t.time() - last < 300:
                continue
            now = e.broker.now()
            sess = current_session(e.broker.trading_day, now)
            if not sess or sess.name not in ("PRE", "AFTER"):
                continue
            start, end = e._ext_window(sess)
            if not (start <= now < end):
                continue
            last = _t.time()
            n = e.prep_movers(sess)
            if n:
                logging.info("auto-prep: %d movers (%s)", n, sess.name)
        except Exception as ex:
            logging.warning("auto-prep: %s", ex)


_th.Thread(target=_prep_loop, daemon=True, name="prep").start()
threading.Thread(target=_radar_loop, daemon=True, name="radar-always").start()


def _weekend_radar_loop():
    """v2.5.3: rebuild Radar by itself on Sunday at about 6:00 PM and 7:45 PM ET (and once after a start during the
    weekend gap), then notify. No new market data exists before 8 PM Sunday, so this keeps the weekend plan fresh and
    makes sure the first overnight bars are included."""
    import time as _t
    while True:
        _t.sleep(60)
        try:
            e = engine
            if not e or ARGS.sim:
                continue
            now = e.broker.now()
            if not _weekend_gap(now):
                _WK["caught"] = False
                continue
            hm = now.hour * 60 + now.minute
            slot = ""
            if now.weekday() == 6 and 18 * 60 <= hm < 18 * 60 + 15:
                slot = "6pm"
            elif now.weekday() == 6 and 19 * 60 + 45 <= hm < 20 * 60:
                slot = "745pm"
            key = now.strftime("%Y-%m-%d") + slot
            notify = True
            if not slot:
                if _WK["caught"]:
                    continue
                key, notify = "catchup", False               # first look after a (re)start: build quietly, once
            elif key in _WK["done"]:
                continue
            _WK["caught"] = True
            _WK["done"].add(key)
            r = morning_wave(force=1)
            _WK["last"] = now.strftime("%a %-I:%M %p")
            nr, nf = len(r.get("rise") or []), len(r.get("fall") or [])
            logging.info("weekend radar rebuild (%s): %d rise / %d fall", slot or "catch-up", nr, nf)
            if notify:
                alerts.send("system", "📡 Radar weekend plan " + ("ready" if slot == "6pm" else "refreshed with the first overnight bars"),
                            f"{nr} rising and {nf} falling setups for Monday. Open Radar to review the zones.")
        except Exception as ex:
            logging.warning("weekend radar: %s", ex)


_th.Thread(target=_weekend_radar_loop, daemon=True, name="weekend-radar").start()


def _study_loop():
    """Once the day is over (after 4:30 PM, overnight, weekends) study any completed trading day we have not studied yet."""
    import time as _t
    last = 0.0
    while True:
        _t.sleep(60)
        try:
            e = engine
            if not e or not settings.auto_study or ARGS.sim or _t.time() - last < 3 * 3600:
                continue
            now = e.broker.now()
            if not (now.hour >= 17 or now.hour < 4 or now.weekday() >= 5):
                continue
            last = _t.time()
            try:
                if settings.auto_prep and not e.evening_at.startswith(now.strftime('%a')):
                    e.evening_review()
            except Exception as ex2:
                logging.warning('evening review: %s', ex2)
            r = e.study_night()
            logging.info("overnight study: %s", r.get("note"))
            if settings.session_tune:
                try:
                    run_autotune()
                except Exception as ex4:
                    logging.warning("auto-tune: %s", ex4)
            if settings.pre_auto:
                try:
                    apply_pre_preset("auto")
                except Exception as ex3:
                    logging.warning("pre-market preset: %s", ex3)
        except Exception as ex:
            logging.warning("overnight study: %s", ex)


_th.Thread(target=_study_loop, daemon=True, name="study").start()


def _shortlist_loop():
    """Overnight homework (after 4:35 PM and before 4 AM, once per night) and the morning refresh (8:00-9:25 AM ET,
    every 15 minutes). Runs even when the bot is stopped."""
    import time as _t
    done_night, last_morning = "", 0.0
    while True:
        _t.sleep(60)
        try:
            e = engine
            if not e or ARGS.sim or not (settings.auto_prep or settings.auto_short):
                continue
            now = e.broker.now()
            hm = now.hour * 60 + now.minute
            if now.weekday() < 5 and 8 * 60 <= hm <= 9 * 60 + 25 and _t.time() - last_morning > 900:
                last_morning = _t.time()
                e.refresh_shortlist("morning refresh")
            elif (hm >= 16 * 60 + 35 or hm < 4 * 60) and done_night != now.strftime("%Y-%m-%d") + str(hm >= 16 * 60):
                done_night = now.strftime("%Y-%m-%d") + str(hm >= 16 * 60)
                e.refresh_shortlist("overnight homework")
        except Exception as ex:
            logging.warning("shortlist: %s", ex)


_th.Thread(target=_shortlist_loop, daemon=True, name="shortlist").start()


# ---------------- Robinhood tab (official Agentic Trading MCP) ----------------
from autobot import rhmcp  # noqa: E402
rh = rhmcp.RH()


class RHCall(BaseModel):
    tool: str
    args: dict = {}
    confirm: bool = False
    pin: str = ""


def _rh_err(fn):
    try:
        return fn()
    except rhmcp.RHNotConnected as ex:
        raise HTTPException(409, str(ex))
    except rhmcp.RHError as ex:
        raise HTTPException(502, str(ex))


@app.get("/api/rh/status")
def rh_status():
    return {"connected": rh.connected, "mcp": rh.url, "pin_set": bool(live_pin()),
            "note": "Robinhood only lets an agent trade in its dedicated Agentic account. This tab can read all your Robinhood accounts."}


@app.post("/api/rh/connect")
def rh_connect(request: Request):
    base = str(request.base_url).rstrip("/")
    host = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]").lower()
    if host in ("localhost", "127.0.0.1", "::1", ""):
        base = f"http://127.0.0.1:{ARGS.port}"           # always the same spelling, so the registered redirect matches
    return {"url": _rh_err(lambda: rh.start_auth(base + "/api/rh/callback"))}


class RHFinish(BaseModel):
    url: str = ""


@app.post("/api/rh/finish")
def rh_finish(r: RHFinish):
    """Fallback when the sign-in page could not reach the app by itself: paste the address the browser ended on."""
    from urllib.parse import urlparse, parse_qsl
    q = dict(parse_qsl(urlparse((r.url or "").strip()).query))
    if q.get("error") or not q.get("code"):
        raise HTTPException(400, "That address has no sign-in code. Paste the full address from the browser's address bar after you tapped Allow.")
    _rh_err(lambda: rh.finish_auth(q["code"], q.get("state", "")))
    return {"connected": True}


@app.get("/api/rh/callback")
def rh_callback(code: str = "", state: str = "", error: str = ""):
    from fastapi.responses import HTMLResponse
    msg, ok = "", False
    if error or not code:
        msg = "Robinhood did not complete the sign-in (" + (error or "no code") + "). Go back and tap Connect again."
    else:
        try:
            rh.finish_auth(code, state)
            ok, msg = True, "Robinhood is connected to SekexBot. You can close this tab and return to the app."
        except rhmcp.RHError as ex:
            msg = str(ex)
    colour = "#22c55e" if ok else "#ef4444"
    return HTMLResponse(f"<!doctype html><meta name=viewport content='width=device-width,initial-scale=1'><body style='font:18px system-ui;background:#07090c;color:#e6edf3;padding:28px'>"
                        f"<h2 style='color:{colour}'>{'Connected' if ok else 'Not connected'}</h2><p>{msg}</p><p><a style='color:#93c5fd' href='/'>Back to SekexBot</a></p>")


@app.post("/api/rh/disconnect")
def rh_disconnect():
    rh.disconnect()
    return {"connected": False}


@app.get("/api/rh/tools")
def rh_tools(refresh: bool = False):
    ts = _rh_err(lambda: rh.tools(refresh))
    import re as _re
    money = _re.compile(r"(order|trade|buy|sell|transfer|withdraw|deposit|liquidate|rebalance|close_position|exercise)", _re.I)
    chart = _re.compile(r"(legend|chart|indicator|layout|drawing|template|screen|alert_rule)", _re.I)
    def kind(t):
        if not t["write"]:
            return "read"
        if money.search(t["name"]):
            return "money"
        return "chart" if chart.search(t["name"]) else "other"
    return {"tools": [{"name": t["name"], "description": (t.get("description") or "")[:400], "write": t["write"], "kind": kind(t),
                       "schema": t.get("inputSchema") or {}} for t in ts]}


@app.get("/api/rh/overview")
def rh_overview():
    """Read-only snapshot: calls the account / position / balance / order lookup tools that need no arguments."""
    import re as _re
    ts = _rh_err(lambda: rh.tools())
    pick = [t for t in ts if not t["write"] and not (t.get("inputSchema") or {}).get("required")
            and _re.search(r"account|portfolio|position|holding|balance|buying|order|activity|transaction", t["name"], _re.I)][:6]
    out = []
    for t in pick:
        try:
            data, txt = rhmcp.result_text(rh.call(t["name"], {}))
            out.append({"tool": t["name"], "data": clean(data) if data is not None else None, "text": txt[:4000]})
        except rhmcp.RHError as ex:
            out.append({"tool": t["name"], "error": str(ex)})
    return {"results": out, "tools": len(ts)}


@app.post("/api/rh/read")
def rh_read(r: RHCall):
    t = next((x for x in _rh_err(lambda: rh.tools()) if x["name"] == r.tool), None)
    if not t:
        raise HTTPException(404, "Unknown Robinhood tool")
    if t["write"]:
        raise HTTPException(403, "That tool can change your account. Use the order ticket (needs PIN + confirm).")
    data, txt = rhmcp.result_text(_rh_err(lambda: rh.call(r.tool, r.args)))
    return {"tool": r.tool, "data": clean(data) if data is not None else None, "text": txt[:6000]}


def _rh_fit_args(args, schema):
    """Robinhood's tools declare some numbers (e.g. quantity) as strings: send them in the type the tool asks for."""
    props = (schema or {}).get("properties") or {}
    out = dict(args or {})
    for k, v in list(out.items()):
        want = (props.get(k) or {}).get("type")
        if want == "string" and isinstance(v, (int, float)) and not isinstance(v, bool):
            out[k] = str(int(v)) if float(v).is_integer() else str(v)
    return out


@app.post("/api/rh/call")
def rh_call(r: RHCall, request: Request):
    """Any tool that can change the account (place or cancel an order, ...). Needs the Live PIN and confirm=true."""
    t = next((x for x in _rh_err(lambda: rh.tools()) if x["name"] == r.tool), None)
    if not t:
        raise HTTPException(404, "Unknown Robinhood tool")
    if t["write"]:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(403, "Set a Live PIN first (Settings). Robinhood orders need it.")
        if not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
        if not r.confirm:
            raise HTTPException(400, "Confirmation missing. Nothing was sent.")
        r.args = _rh_fit_args(r.args, t.get("inputSchema"))
        logging.getLogger("autobot").warning("ROBINHOOD ORDER via MCP tool %s args=%s", r.tool, json.dumps(r.args)[:300])
        if engine is not None:
            try:
                engine.event(f"Robinhood: sent {r.tool} {json.dumps(r.args)[:160]}", "warning")
            except Exception:
                pass
    data, txt = rhmcp.result_text(_rh_err(lambda: rh.call(r.tool, r.args)))
    return {"tool": r.tool, "data": clean(data) if data is not None else None, "text": txt[:6000]}


# ---------------- v2.17: Robinhood alerts (the bot cannot watch Robinhood, so it tells your phone) ----------------
_RHW_FILE = DATA_DIR / "rh_watch.json"
_RHW: dict = {}          # id -> {symbol, acct, tool, usd, above, below, at, set}


def _rhw_load():
    try:
        d = json.loads(_RHW_FILE.read_text())
        if isinstance(d, dict):
            _RHW.update(d)
    except Exception:
        pass


def _rhw_save():
    try:
        _RHW_FILE.write_text(json.dumps(_RHW))
    except Exception:
        pass


_rhw_load()


def _rh_list(data):
    root = (data or {}).get("data") if isinstance(data, dict) and isinstance(data.get("data"), (dict, list)) else data
    if isinstance(root, list):
        lst = root
    elif isinstance(root, dict):
        lst = root.get("positions") or root.get("holdings") or root.get("results") or next((v for v in root.values() if isinstance(v, list)), [])
    else:
        lst = []
    return [x for x in lst if isinstance(x, dict)]


def _rh_pos_row(x):
    def num(*ks):
        for k in ks:
            try:
                v = x.get(k)
                if v not in (None, ""):
                    return float(v)
            except Exception:
                pass
        return 0.0
    sy = str(x.get("symbol") or x.get("ticker") or (x.get("instrument") or {}).get("symbol") or "").upper()
    return sy, num("quantity", "qty", "shares"), num("last_trade_price", "price", "current_price"), num("average_buy_price", "average_cost", "avg_price")


def _rhw_tick():
    if not _RHW or not rh.connected or engine is None:
        return
    now = time_mod.time()
    groups: dict = {}
    for wid, w in _RHW.items():
        groups.setdefault((w.get("tool"), w.get("acct")), []).append(wid)
    fired = []
    for (tool, acct), ids in groups.items():
        try:
            tl = next((x for x in rh.tools() if x["name"] == tool and not x["write"]), None)
            if not tl:
                continue
            req = (tl.get("inputSchema") or {}).get("required") or []
            data, _txt = rhmcp.result_text(rh.call(tool, {k: str(acct) for k in req}))
            rows = {r[0]: r for r in map(_rh_pos_row, _rh_list(data)) if r[0]}
        except Exception:
            continue
        for wid in ids:
            w = _RHW[wid]
            sym = w["symbol"]
            r = rows.get(sym)
            if r is None:
                if rows:                                 # the position is gone (sold): drop its watches
                    fired.append((wid, None))
                continue
            _s, q, px, avg = r
            pl = (px - avg) * q if (px and avg) else None
            msg = None
            if w.get("usd") and pl is not None and pl >= w["usd"]:
                msg = ("profit", f"🟢 Robinhood {sym}: up ${pl:,.2f}", f"Your take amount ${w['usd']:,.2f} was reached. Sell on Robinhood or in the app's Robinhood tab.")
            elif w.get("above") and px and px >= w["above"]:
                msg = ("profit", f"🟢 Robinhood {sym} at ${px:,.2f}", f"Price is above your ${w['above']:,.2f} alert.")
            elif w.get("below") and px and px <= w["below"]:
                msg = ("exit", f"🔻 Robinhood {sym} at ${px:,.2f}", f"Price fell to your ${w['below']:,.2f} stop alert. Decide whether to sell.")
            elif w.get("at") and now >= w["at"]:
                msg = ("exit", f"⏰ Robinhood {sym}: time to look", f"Now ${px:,.2f}" + (f", P&L ${pl:+,.2f}" if pl is not None else "") + ". This is the time you picked.")
            if msg:
                try:
                    engine.alert(msg[0], msg[1], msg[2], symbol=sym)
                    engine.event(f"Robinhood alert: {msg[1]}")
                except Exception:
                    pass
                fired.append((wid, msg))
    if fired:
        for wid, _m in fired:
            _RHW.pop(wid, None)
        _rhw_save()


def _rhw_loop():
    import time as _tm
    while True:
        _tm.sleep(25)
        try:
            _rhw_tick()
        except Exception:
            logging.exception("rh watch")


threading.Thread(target=_rhw_loop, daemon=True, name="rh-watch").start()


class RHWatch(BaseModel):
    symbol: str
    acct: str = ""
    tool: str = ""            # the read-only holdings command the screen used
    usd: float | None = None      # alert when this much is made
    above: float | None = None
    below: float | None = None
    at: float | None = None       # epoch seconds
    clear: bool = False


@app.get("/api/rh/watch")
def rh_watch_list():
    return {"items": [dict(w, id=k) for k, w in _RHW.items()]}


@app.post("/api/rh/watch")
def rh_watch_set(r: RHWatch):
    sym = _valid_sym(r.symbol)
    if r.clear:
        for k in [k for k, w in _RHW.items() if w["symbol"] == sym]:
            _RHW.pop(k)
        _rhw_save()
        return {"ok": True}
    if not (r.usd or r.above or r.below or r.at):
        raise HTTPException(400, "Pick an amount, a price or a time.")
    if not r.tool or not r.acct:
        raise HTTPException(400, "Open the Robinhood tab and let it load your holdings first.")
    cur = next((k for k, w in _RHW.items() if w["symbol"] == sym), None) or f"{sym}-{int(time_mod.time())}"
    w = _RHW.get(cur) or {"symbol": sym}
    w.update(acct=r.acct, tool=r.tool, set=int(time_mod.time()))
    for k in ("usd", "above", "below", "at"):
        v = getattr(r, k)
        if v:
            w[k] = float(v)
    _RHW[cur] = w
    _rhw_save()
    return {"ok": True}


@app.get("/api/learn/read/{symbol}")
def learn_read(symbol: str):
    """Learn tab: floor, ceiling, trend and entry zones from daily bars."""
    from autobot import learn as _learn
    e = need_engine()
    sym = _valid_sym(symbol)
    try:
        df = e.broker.daily_bars(sym)
    except Exception as ex:
        raise HTTPException(502, f"Couldn't load {sym}: {str(ex)[:150]}")
    live = None
    try:                                            # fold the live quote into today's candle so the reading is current
        bid, ask = _quote(e, sym, _session_name(e))
        if bid and ask and df is not None and len(df):
            px = round((float(bid) + float(ask)) / 2, 2)
            now = e.broker.now()
            df = df.copy()
            if df.index[-1].date() == now.date():
                i = df.index[-1]
                df.loc[i, "close"] = px; df.loc[i, "high"] = max(float(df.loc[i, "high"]), px); df.loc[i, "low"] = min(float(df.loc[i, "low"]), px)
            else:
                import pandas as _pd
                prev = float(df["close"].iloc[-1])
                df.loc[_pd.Timestamp(now.date()).tz_localize(df.index.tz)] = [prev, max(prev, px), min(prev, px), px, 0]
            live = {"price": px, "bid": float(bid), "ask": float(ask), "at": now.strftime("%I:%M:%S %p").lstrip("0")}
    except Exception:
        live = None
    out = _learn.read(df, sym)
    out["live"] = live
    return clean(out)


@app.get("/api/longwave/{symbol}")
def longwave_plan(symbol: str, shorts: int = 0):
    """Long-wave plan: the stock's slow swings and the next entries, exits and re-entries projected from them."""
    from autobot import longwave as _lw
    e = need_engine()
    sym = _valid_sym(symbol)
    try:
        df = e.broker.bars5(sym)
    except Exception as ex:
        raise HTTPException(502, f"Couldn't load {sym}: {str(ex)[:150]}")
    if df is None or not len(df):
        raise HTTPException(404, f"No recent 5-minute bars for {sym}.")
    spr = 0.0005
    try:
        bid, ask = _quote(e, sym, _session_name(e))
        if bid and ask and ask > bid:
            spr = max(0.0002, (float(ask) - float(bid)) / ((float(ask) + float(bid)) / 2) / 2)
    except Exception:
        pass
    out = _lw.plan(df, sym, spread_pct=spr, allow_short=bool(shorts) and settings.allow_shorts)
    out["spread_pct"] = round(spr * 200, 3)
    try:
        out["backtest"] = _lw.backtest(df, spr)
    except Exception:
        out["backtest"] = None
    # a wide, broken quote makes any plan meaningless: say so instead of planning
    if spr > 0.015:
        out["ok"] = False; out["legs"] = []
        out["reason"] = "The bid/ask spread is too wide right now (a broken overnight quote). No plan until it tightens."
    out["bars"] = [round(float(x), 2) for x in df["close"].tail(150)]
    return clean(out)


@app.get("/api/direction/{symbol}")
def direction_call(symbol: str):
    e = need_engine()
    try:
        return clean(e.direction_for(_valid_sym(symbol)))
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(502, f"Couldn't read {symbol}: {str(ex)[:150]}")


class AutoShortReq(BaseModel):
    pin: str = ""
    mode: str = "both"          # both | short | long


@app.post("/api/autoshort/enable")
def autoshort_enable(r: AutoShortReq, request: Request):
    """One tap: turn on the automatic short system for the CURRENT account (PAPER or LIVE) and start the bot.
    LIVE needs the Live PIN again, because this places real orders by itself."""
    global engine
    if engine is None:
        build_engine()
    e = need_engine()
    if settings.live and not ARGS.sim:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(400, "No Live PIN set yet. Add one in ⚙ → Broker keys → Live.")
        if not pin_ok(r.pin):
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
    notes = []
    settings.auto_short, settings.allow_shorts, settings.pre_plan, settings.morning_reversal = True, True, True, True
    settings.auto_mode = r.mode if r.mode in ("both", "short", "long") else "both"
    settings.level, settings.level_auto = "custom", False
    if settings.data_feed == "sip":
        settings.preclose_short = True
        notes.append("late-day overnight shorts on")
    else:
        settings.preclose_short = False
        notes.append("late-day overnight shorts need the SIP feed, so they stay off")
    settings.ext_premarket = settings.ext_afterhours = True
    settings.save()
    try:
        if not ARGS.sim and hasattr(e.broker, "screener"):
            _th.Thread(target=lambda: e.refresh_shortlist("enable"), daemon=True, name="shortlist-now").start()
    except Exception:
        pass
    e.event(f"Automatic system ENABLED ({settings.auto_mode}) on {'LIVE' if settings.live else 'PAPER'}", "warning" if settings.live else "info")
    alerts.send("system", "Automatic system ON", f"{'LIVE' if settings.live else 'PAPER'} account, {settings.auto_mode}. Waits for confirmed 1-minute signals.")
    if not e.running:
        e.start()
    return {"ok": True, "live": settings.live, "notes": notes}


@app.post("/api/autoshort/disable")
def autoshort_disable():
    settings.auto_short = False
    settings.save()
    if engine:
        engine.event("Automatic system OFF (the bot keeps running with your other settings)")
    return {"ok": True}


class ReleaseReq(BaseModel):
    symbol: str = "*"


@app.get("/api/tune")
def tune_get():
    e = need_engine()
    return clean({"enabled": settings.auto_tune, "items": e.tuner.table()})


@app.get("/api/blocks")
def blocks_get():
    e = need_engine()
    return clean({"items": e.blocked_symbols()})


@app.post("/api/blocks/release")
def blocks_release(r: ReleaseReq):
    e = need_engine()
    return {"ok": True, "released": e.release_block(r.symbol)}


@app.get("/api/shortlist")
def shortlist_get():
    e = need_engine()
    return clean({"items": e.shortlist, "at": e.shortlist_at, "auto_short": settings.auto_short, "auto_mode": settings.auto_mode, "live": settings.live})


@app.post("/api/shortlist/refresh")
def shortlist_refresh():
    e = need_engine()
    try:
        n = e.refresh_shortlist("manual")
    except Exception as ex:
        raise HTTPException(502, f"Shortlist failed: {str(ex)[:150]}")
    return clean({"ok": True, "count": n, "items": e.shortlist, "at": e.shortlist_at})


@app.get("/api/premarket")
def premarket():
    e = need_engine()
    return clean(e.pm_timeline())


@app.get("/api/evening")
def evening_list():
    e = need_engine()
    return clean({"items": e.evening, "at": e.evening_at, "overnight": e.overnight})


@app.post("/api/evening/review")
def evening_review():
    e = need_engine()
    try:
        n = e.evening_review()
    except Exception as ex:
        raise HTTPException(502, f"Review failed: {str(ex)[:150]}")
    return clean({"ok": True, "count": n, "items": e.evening, "at": e.evening_at})


@app.get("/api/study")
def study_status():
    from autobot.study import summary
    return summary()


class StudyReq(BaseModel):
    pass


@app.post("/api/study/run")
def study_run():
    if not engine:
        raise HTTPException(400, "not ready")
    _th.Thread(target=lambda: engine.study_night(), daemon=True, name="study-now").start()
    return {"ok": True}


class HarvestReq(BaseModel):
    symbol: str


# ---------------- diagnostics sharing (opt-in) + hidden admin panel ----------------
def _diag_state():
    e = engine
    try:
        st = e.status() if e else {}
    except Exception:
        st = {}
    return {"running": st.get("running"), "halted": st.get("halted"), "session": st.get("state") and _session_name(e) if e else None,
            "streaming": bool(getattr(getattr(e, "broker", None), "live", None))}


diag = telemetry.Reporter(settings, _diag_state)
diag.offer_fn = lambda raw: _offer_in(raw)
diag.bundle_fn = lambda: _support_zip()      # defined further down; resolved when called


class DiagCfg(BaseModel):
    share: bool | None = None
    label: str | None = None
    asked: bool | None = None
    collector_url: str | None = None
    share_logs: bool | None = None


@app.get("/api/diag/status")
def diag_status():
    return {**diag.status(), "label": settings.diag_label, "collector_url": settings.collector_url}


@app.get("/api/diag/preview")
def diag_preview():
    """Exactly what would be sent. Nothing here is a key, a position, an order, or any money figure."""
    return telemetry.build(settings, _diag_state())


@app.post("/api/diag/config")
def diag_config(r: DiagCfg):
    if r.collector_url is not None:
        u = r.collector_url.strip().rstrip("/")
        if u and not telemetry.valid_url(u):
            raise HTTPException(400, "The collector address must start with https:// (http:// is only allowed for localhost or a home network).")
        settings.collector_url = u
    if r.label is not None:
        settings.diag_label = r.label.strip()[:40]
    if r.asked is not None:
        settings.diag_asked = bool(r.asked)
    if r.share is not None:
        was = settings.share_diagnostics
        settings.share_diagnostics = bool(r.share)
        settings.diag_asked = True
        if was and not r.share:
            threading.Thread(target=diag.forget, daemon=True).start()     # switching off also deletes what support holds
        if r.share and not was:
            threading.Thread(target=diag.send_now, daemon=True).start()
    if r.share_logs is not None:
        was_l = settings.share_trade_logs
        settings.share_trade_logs = bool(r.share_logs)
        settings.diag_asked = True
        if was_l and not r.share_logs:
            threading.Thread(target=diag.forget, daemon=True).start()     # off = delete what support holds, logs included
        if r.share_logs and not was_l:
            threading.Thread(target=diag.send_logs_now, daemon=True).start()
    settings.save()
    return {"ok": True, **diag_status()}


# ---------------- optional add-ons (installed outside the app folder; absent on normal phones) ----------------
ADDON_DIR = Path.home() / ".sekexbot" / "admin"


@app.get("/ext.js")
def ext_js():
    """Dashboard extension script. Empty unless an add-on is installed on this phone."""
    f = ADDON_DIR / "ext.js"
    return Response(f.read_text(encoding="utf-8") if f.exists() else "", media_type="application/javascript",
                    headers={"Cache-Control": "no-store"})


def _load_addons():
    f = ADDON_DIR / "admin_ext.py"
    if not f.exists():
        return
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("sekex_admin_ext", f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.register(app, settings=settings, telemetry=telemetry)
        logging.getLogger("autobot").info("Add-on loaded: %s", f.name)
    except Exception as ex:
        logging.getLogger("autobot").warning("Add-on failed to load: %s", ex)


@app.get("/api/manual/learn")
def manual_learn(days: int = 60):
    """What your own manual round trips say: win rate, typical winner and loser, quick-win size, re-entry habits."""
    e = need_engine()
    if not hasattr(e.broker, "trading"):
        return {"n": 0, "error": "The simulator has no real order history; connect your Alpaca account to learn from your trades."}
    from autobot import manuallearn
    try:
        r = manuallearn.learn(e.broker, max(7, min(180, int(days))))
    except Exception as ex:
        raise HTTPException(502, f"Couldn't read your order history from Alpaca: {str(ex)[:150]}")
    e.manual_learn = r
    return r


@app.post("/api/manual/learn/apply")
def manual_learn_apply():
    r = getattr(need_engine(), "manual_learn", None) or {}
    pct = r.get("suggest_harvest_pct")
    if not pct:
        raise HTTPException(400, "Analyze your manual trades first (needs some winning round trips).")
    settings.pct_harvest_pct = float(pct)
    settings.save()
    return {"ok": True, "pct": pct}


@app.post("/api/harvest/arm")
def harvest_arm(r: HarvestReq):
    """Turn auto-harvest on for a position you already hold."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym}; auto-harvest is for your own trades.")
    pos = e.broker.positions().get(sym)
    if not pos or not pos["qty"]:
        raise HTTPException(404, f"You don't hold {sym}.")
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    _AH_SKIP.discard(sym)
    harvester.arm(sym, "buy" if pos["qty"] > 0 else "sell", abs(pos["qty"]), "watching your position")
    e.event(f"♻ Auto-harvest ON for {sym} ({abs(pos['qty']):g} sh)")
    return {"ok": True}


@app.post("/api/harvest/now")
def harvest_now(r: HarvestReq):
    """Harvest now: sell the position at once and keep the harvest cycle going (re-enter on a pullback); while waiting to re-enter, buy back now."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym}; this button is for your own trades.")
    pos = e.broker.positions().get(sym)
    job = [j for j in harvester.status() if j["symbol"] == sym]
    if not job and (not pos or not pos["qty"]):
        raise HTTPException(404, f"You don't hold {sym}.")
    if not job:
        from autobot.sessions import bot_day
        e.manual_syms[sym] = bot_day(e.broker.now())
        msg = harvester.now(sym, "buy" if pos["qty"] > 0 else "sell", abs(pos["qty"]))
    else:
        msg = harvester.now(sym)
    e.event(f"♻ Harvest now tapped for {sym}: {msg}")
    return {"ok": True, "msg": msg}


@app.post("/api/harvest/stop")
def harvest_stop(r: HarvestReq):
    need_engine()
    sym = _valid_sym(r.symbol)
    _AH_SKIP.add(sym)                       # you said stop: don't auto-watch it again
    return {"ok": harvester.stop(sym)}


@app.get("/api/harvest")
def harvest_list():
    return {"jobs": harvester.status()}


class CancelReq(BaseModel):
    order_id: str


@app.post("/api/manual/cancel")
def manual_cancel(r: CancelReq):
    e = need_engine()
    e.broker.cancel(r.order_id)
    e.event("MANUAL cancel order " + r.order_id[:8])
    return {"ok": True}


class CancelSym(BaseModel):
    symbol: str


@app.post("/api/manual/cancel_symbol")
def manual_cancel_symbol(r: CancelSym):
    """Trade pad CANCEL key: cancel the open (unfilled) orders on one symbol. Refused for a BOT trade, because
    cancelling its bracket would take away its stop and target (use CLOSE for those)."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    t = e.trades.get(sym)
    if t is not None and t.status == "open":
        raise HTTPException(409, f"{sym} is a BOT trade: cancelling its orders would remove its stop and target. Use CLOSE instead.")
    e.broker.cancel_symbol_orders(sym)
    e.event(f"MANUAL cancel all open orders on {sym}")
    return {"ok": True}


# ---------------- in-app updates (Android edition) ----------------
# Two ways, both from the dashboard on the phone itself (never from Remote access):
#   1. pick a SekexBot_Android_vX.Y.Z.zip file on the phone -> uploaded here -> installed
#   2. an update link (UPDATE_URL in .env) to a latest.json you host -> check -> download -> install
# The zip is checked (it must be a SekexBot Android package, and match the SHA-256 in latest.json)
# before `sekex update` installs it; your keys, settings, learning memory and journal are kept.
UPD_DIR = Path.home() / ".sekexbot"
_upd = {"checked": 0.0, "info": None}


def _zip_version(path: Path) -> str:
    import zipfile
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise HTTPException(400, "That file isn't a zip.")
    names = z.namelist()
    if any(n.startswith("/") or ".." in n.split("/") for n in names):
        raise HTTPException(400, "That zip has unsafe file paths - not installing it.")
    if "SekexBot_Android/install.sh" not in names or "SekexBot_Android/VERSION" not in names:
        raise HTTPException(400, "That zip isn't a SekexBot Android package (SekexBot_Android_vX.Y.Z.zip).")
    return z.read("SekexBot_Android/VERSION").decode().strip()


def _vtuple(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _run_update(path: Path, new_ver: str):
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "In-app updates are for the Android edition. On a PC, replace the files and restart.")
    log = open(Path.home() / "sekexbot-update.log", "w")
    env = dict(os.environ, SEKEX_QUICK="1", SEKEX_QUIET="1")
    env.pop("SEKEX_LOGGING", None)
    subprocess.Popen(["bash", exe, "update", str(path)], stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                     env=env, start_new_session=True)
    if engine:
        engine.event(f"Updating SekexBot {__version__} -> {new_ver}. Back in about a minute.", "warning")
    return {"ok": True, "from": __version__, "to": new_ver}


REL_DIR = UPD_DIR / "releases"


def _releases():
    out = []
    for f in sorted(REL_DIR.glob("SekexBot_Android_v*.zip"), key=lambda p: p.stat().st_mtime, reverse=True):
        v = f.stem.split("_v")[-1]
        if v != __version__:
            out.append({"version": v, "saved": datetime.fromtimestamp(f.stat().st_mtime, NY).strftime("%b %d %I:%M %p")})
    return out


def _upd_prefs():
    return {"mode": os.getenv("UPDATE_MODE", "ask"), "skip": os.getenv("UPDATE_SKIP", "")}


@app.get("/api/app/update/progress")
def update_progress():
    """Live install progress while an update/rollback runs (the old app keeps serving until the restart)."""
    import time as _t
    steps, t0 = [], None
    f = UPD_DIR / "update_progress.log"
    if f.exists():
        for ln in f.read_text().splitlines():
            ts, _, msg = ln.partition("|")
            if ts.isdigit():
                t0 = t0 or int(ts)
                steps.append({"t": int(ts), "msg": msg})
    tail = []
    lg = Path.home() / "sekexbot-update.log"
    if lg.exists():
        import re as _re
        tail = [_re.sub(r"\x1b\[[0-9;]*m", "", x) for x in lg.read_text(errors="ignore").splitlines()[-8:] if x.strip()]
    expected = 7
    done = any(x["msg"] == "DONE" for x in steps)
    failed = any(x["msg"].startswith("FAILED") for x in steps)
    pct = 100 if done else min(95, int(100 * len(steps) / expected))
    return {"current": __version__, "steps": steps, "pct": pct, "done": done, "failed": failed,
            "elapsed": int(_t.time() - t0) if t0 else 0, "log": tail}


@app.get("/api/app/update/status")
def update_status():
    return {"current": __version__, "edition": android.EDITION, "update_url": os.getenv("UPDATE_URL", ""),
            "info": _upd["info"], "prefs": _upd_prefs(), "releases": _releases()}


class UpdPrefsReq(BaseModel):
    mode: str | None = None          # ask | manual
    skip: str | None = None          # a version to stop asking about ("" = clear)


@app.post("/api/app/update/prefs")
def update_prefs(r: UpdPrefsReq):
    vals = {}
    if r.mode in ("ask", "manual"):
        vals["UPDATE_MODE"] = r.mode
    if r.skip is not None:
        vals["UPDATE_SKIP"] = r.skip.strip()
    if vals:
        write_env(vals)
    return {"ok": True, "prefs": _upd_prefs()}


class RollbackReq(BaseModel):
    version: str


@app.post("/api/app/rollback")
def rollback(r: RollbackReq):
    v = r.version.strip()
    if not all(p.isdigit() for p in v.split(".")):
        raise HTTPException(400, "Pick a version from the list")
    path = REL_DIR / f"SekexBot_Android_v{v}.zip"
    if not path.exists():
        raise HTTPException(404, f"No saved copy of v{v} on this phone")
    if _zip_version(path) != v:
        raise HTTPException(400, "That saved copy looks damaged")
    return _run_update(path, v)


@app.post("/api/app/update/upload")
async def update_upload(request: Request, allow_downgrade: bool = False):
    data = await request.body()
    if not data or len(data) > 60_000_000:
        raise HTTPException(400, "Pick the SekexBot_Android_vX.Y.Z.zip file (up to 60 MB).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    path.write_bytes(data)
    ver = _zip_version(path)
    if _vtuple(ver) < _vtuple(__version__) and not allow_downgrade:
        raise HTTPException(409, f"DOWNGRADE:{ver}")
    return _run_update(path, ver)


class UpdUrlReq(BaseModel):
    url: str


@app.post("/api/app/update/url")
def update_set_url(r: UpdUrlReq):
    u = r.url.strip()
    if u and not u.startswith("https://"):
        raise HTTPException(400, "The update link must start with https://")
    write_env({"UPDATE_URL": u})
    _upd.update(checked=0.0, info=None)
    return {"ok": True}


def _check_manifest():
    import time
    from urllib.parse import urljoin
    import requests
    url = os.getenv("UPDATE_URL", "")
    if not url:
        raise HTTPException(400, "Add your update link first (the address of latest.json).")
    try:
        m = requests.get(url, timeout=20, headers={"Cache-Control": "no-cache"}).json()
    except Exception as ex:
        raise HTTPException(400, f"Couldn't read the update link: {str(ex)[:160]}")
    if not m.get("version") or not m.get("url"):
        raise HTTPException(400, "The update link doesn't look like a SekexBot latest.json")
    info = {"latest": m["version"], "url": urljoin(url, m["url"]), "sha256": m.get("sha256", ""),
            "notes": m.get("notes", ""), "available": _vtuple(m["version"]) > _vtuple(__version__)}
    _upd.update(checked=time.time(), info=info)
    try:        # v1.95.1: the admin's collector address rides along in latest.json, so testers report to the same place you read
        cu = str(m.get("collector") or "").strip().rstrip("/")
        if cu and not (settings.collector_url or "").strip() and telemetry.valid_url(cu):
            settings.collector_url = cu
            settings.save()
    except Exception:
        pass
    return info


@app.get("/api/telemetry/collector")
def telemetry_collector():
    return {"collector_url": telemetry.collector_url(settings)}


@app.get("/api/app/update/check")
def update_check():
    return {"current": __version__, **_check_manifest()}


@app.post("/api/app/update/install")
def update_install():
    import hashlib
    import requests
    info = _check_manifest()
    if not info["available"]:
        raise HTTPException(400, f"You already have the latest version ({__version__}).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    try:
        with requests.get(info["url"], stream=True, timeout=120) as r:
            r.raise_for_status()
            h = hashlib.sha256()
            with open(path, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
                    h.update(chunk)
    except Exception as ex:
        raise HTTPException(400, f"Download failed: {str(ex)[:160]}")
    if not info["sha256"] or h.hexdigest().lower() != info["sha256"].lower():
        path.unlink(missing_ok=True)
        raise HTTPException(400, "The download didn't match the checksum in latest.json - not installing it.")
    ver = _zip_version(path)
    return _run_update(path, ver)


@app.on_event("startup")
def _auto_update_check():
    """Every 6 hours, if an update link is set, look for a new version and notify the phone."""
    import shutil
    import subprocess
    import threading
    import time

    def loop():
        told = ""
        while True:
            time.sleep(90)
            if os.getenv("UPDATE_URL"):
                try:
                    info = _check_manifest()
                    pr = _upd_prefs()
                    if info["available"] and info["latest"] != told and pr["mode"] == "ask" \
                            and info["latest"] != pr["skip"] and shutil.which("termux-notification"):
                        told = info["latest"]
                        subprocess.run(["termux-notification", "--id", "sekexbot-update", "--title",
                                        f"SekexBot {info['latest']} is available",
                                        "--content", "Tap to open SekexBot and choose Update now or Later",
                                        "--action", f"termux-open-url http://127.0.0.1:{ARGS.port}"], timeout=10)
                except Exception:
                    pass
            time.sleep(3600)          # look for a new version every hour
    if android.IS_ANDROID:
        threading.Thread(target=loop, daemon=True, name="update-check").start()


# ---------------- streaming prices to the dashboard (Server-Sent Events) ----------------
@app.get("/api/stream")
async def price_stream(request: Request, symbols: str = ""):
    import asyncio
    import json as _j
    import time as _t
    from fastapi.responses import StreamingResponse
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip()][:30]

    async def gen():
        sent, last_ping = {}, 0.0
        while not await request.is_disconnected():
            now = _t.time()
            for x in syms:
                _interest[x] = now
            f = feed
            out = {}
            if f is not None:
                for x in syms:
                    lv = f.get(x, max_age=30)
                    if lv and lv.get("last"):
                        v = (round(lv["bid"] or 0, 4), round(lv["ask"] or 0, 4), round(lv["last"], 4))
                        if sent.get(x) != v:
                            sent[x] = v
                            out[x] = {"bid": v[0] or None, "ask": v[1] or None, "last": v[2]}
            if out:
                yield f"data: {_j.dumps(out)}\n\n"
            elif now - last_ping > 15:
                last_ping = now
                yield f": ping {int(now)}\n\n"
            await asyncio.sleep(0.25)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})


# ---------------- 🛠 help & repair ----------------
def _diag():
    from autobot import helpdesk
    return helpdesk.diagnose({"engine": engine, "setup_error": setup_error, "settings": settings, "version": __version__,
                              "device": android.health(), "sim": ARGS.sim, "update_info": _upd["info"],
                              "feed": feed})


@app.get("/api/help/diagnose")
def help_diagnose():
    return clean(_diag())



# ---------------- AI Helper: one chat for every AI tool (v1.99) ----------------
_ts_cache = {"at": 0.0, "key": "", "bars": None}


def _scan_bars(e, symbols):
    import time as _tm
    extra = [x.strip().upper() for x in (symbols or []) if str(x).strip()]
    syms = list(dict.fromkeys(extra + ([] if extra else [w.upper() for w in settings.watchlist] + MW_CORE + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])[:10]])))
    syms = [x for x in syms if x and x.replace(".", "").isalpha()][:30]
    key = ",".join(syms)
    if _ts_cache["bars"] is not None and _ts_cache["key"] == key and _tm.time() - _ts_cache["at"] < 600:
        return _ts_cache["bars"]
    if not hasattr(e.broker, "bars15"):
        raise HTTPException(400, "Real market data is needed for this scan (not available in the simulator).")
    bars = e.broker.bars15(syms, 45)
    _ts_cache.update(at=_tm.time(), key=key, bars=bars)
    return bars


def _do_scan(window="morning", threshold_pct=1.0, symbols=None, top=8):
    from autobot import trendscan
    e = need_engine()
    if not trendscan.window_key(window):
        raise HTTPException(400, "Window must be one of: " + ", ".join(trendscan.WINDOWS))
    try:
        thr = max(0.2, min(10.0, float(threshold_pct or 1.0)))
    except Exception:
        thr = 1.0
    try:
        bars = _scan_bars(e, symbols if isinstance(symbols, list) else [])
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(502, f"Bar data failed: {str(ex)[:140]}")
    out = trendscan.scan(bars, window, thr, max(3, min(15, int(top or 8))))
    out["asof"] = e.broker.now().strftime("%b %-d, %-I:%M %p %Z")
    return clean(out)


@app.get("/api/ai/scan")
def ai_scan(window: str = "morning", threshold: float = 1.0, symbols: str = "", top: int = 8):
    """Time-of-day trend scan (no AI key needed): the biggest historical rises / falls inside one part of the day."""
    return _do_scan(window, threshold, [x for x in symbols.split(",") if x.strip()], top)


_rz_cache = {}


@app.get("/api/rsizone")
def rsi_zone(symbols: str = ""):
    """RSI zone read (v2.1) for up to 20 stocks: trend, RSI zone, continuation signal and its real past record. Information only."""
    import time as _tm
    from autobot import rsizone
    e = need_engine()
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip() and x.strip().replace(".", "").isalpha()][:20]
    if not syms:
        raise HTTPException(400, "Give one or more symbols.")
    key = ",".join(sorted(syms))
    hit = _rz_cache.get(key)
    if hit and _tm.time() - hit[0] < 300:
        return hit[1]
    bars = _scan_bars(e, syms)
    rows = []
    for sym in syms:
        try:
            rows.append(rsizone.analyze(sym, bars.get(sym)))
        except Exception as ex:
            rows.append({"symbol": sym, "ok": False, "note": str(ex)[:80]})
    out = {"rows": rows, "note": "Information only. It is a record of what happened, not a forecast."}
    _rz_cache[key] = (_tm.time(), out)
    return out


class AIChatReq(BaseModel):
    messages: list[dict] = []


def _ai_tools():
    def t_scan(a):
        return _do_scan(a.get("window", "morning"), a.get("threshold_pct", 1.0), a.get("symbols"), a.get("top", 8))

    def t_chart(a):
        r = analyze_symbol(str(a.get("symbol", "")))
        return json.loads(json.dumps(r, default=str)[:3500]) if isinstance(r, dict) and len(json.dumps(r, default=str)) > 3500 else r

    def t_pred(a):
        r = morning_wave(0, "", 0.4, str(a.get("mode", "") or ""))
        keep = ("symbol", "side", "name", "score", "hit_rate", "n", "zone", "stop", "tp1", "tp2", "zone_state", "price")
        slim = lambda L: [{k: x.get(k) for k in keep} for x in (L or [])[:8]]
        return {"mode": r.get("mode"), "window": r.get("window"), "rise": slim(r.get("rise")), "fall": slim(r.get("fall")), "asof": r.get("asof"), "note": r.get("note", "")}

    def t_day(a):
        e = need_engine()
        pos = []
        try:
            for sym, p in list(e.positions.items())[:12]:
                pos.append({"symbol": sym, "qty": getattr(p, "qty", None) if not isinstance(p, dict) else p.get("qty"),
                            "unrealized": getattr(p, "unrealized_pl", None) if not isinstance(p, dict) else p.get("unrealized_pl")})
        except Exception:
            pass
        return {"mode": e.mode, "state": e.state, "equity": (e.acct or {}).get("equity"), "buying_power": (e.acct or {}).get("buying_power"),
                "day_pnl": round(float(e.risk.day_pnl), 2), "daily_loss_limit": settings.daily_max_loss, "positions": pos}

    def t_check(a):
        return _checkup.run(need_engine(), options_bot, None, "manual")

    def t_health(a):
        d = _diag()
        return {"issues": d.get("issues", [])[:8], "ok": d.get("ok", [])[:8]}

    def t_fix(a):
        return {"type": "fix", "problem": str(a.get("problem", ""))[:600]}
    return {"scan_trends": t_scan, "read_chart": t_chart, "predictions": t_pred, "my_day": t_day, "check_up": t_check, "health": t_health, "propose_fix": t_fix}


@app.post("/api/ai/chat")
def ai_chat(r: AIChatReq):
    from autobot import aihelper
    e = engine
    now_text = ""
    try:
        if e:
            now_text = e.broker.now().strftime("%A %b %-d, %-I:%M %p ET") + f", session {_session_name(e)}, mode {e.mode}, trader level {settings.ui_mode or 'advanced'}"
    except Exception:
        pass
    return clean(aihelper.chat(r.messages, _ai_tools(), now_text))


from autobot import checkup as _checkup  # noqa: E402


@app.on_event("startup")
def _checkup_start():
    _checkup.start_scheduler(lambda: engine, lambda: options_bot, lambda: selffix, settings)


@app.get("/api/checkup")
def checkup_get():
    return {"reports": _checkup.history(), "on": settings.auto_checkup, "fix_draft": settings.auto_fix_draft, "opt_autotune": settings.opt_autotune,
            "opt_reprice": settings.opt_reprice, "reprice_max": settings.opt_reprice_max, "step": settings.opt_reprice_step_pct, "wait": settings.options_fill_wait_s,
            "tune_log": list(reversed(settings.tune_log or []))[:10]}


class CheckupPrefs(BaseModel):
    on: bool | None = None
    fix_draft: bool | None = None
    opt_autotune: bool | None = None
    opt_reprice: bool | None = None


@app.post("/api/checkup/prefs")
def checkup_prefs(r: CheckupPrefs):
    if r.on is not None:
        settings.auto_checkup = bool(r.on)
    if r.fix_draft is not None:
        settings.auto_fix_draft = bool(r.fix_draft)
    if r.opt_autotune is not None:
        settings.opt_autotune = bool(r.opt_autotune)
    if r.opt_reprice is not None:
        settings.opt_reprice = bool(r.opt_reprice)
    settings.save()
    return checkup_get()


@app.post("/api/checkup/run")
def checkup_run():
    e = need_engine()
    import threading
    if getattr(checkup_run, "_t", None) and checkup_run._t.is_alive():
        return {"started": False, "running": True}
    checkup_run._t = threading.Thread(target=lambda: _checkup.run(e, options_bot, selffix, "manual"), daemon=True)
    checkup_run._t.start()
    return {"started": True}


class FixReq(BaseModel):
    action: str


@app.post("/api/help/fix")
def help_fix(r: FixReq):
    import shutil
    import subprocess
    a = r.action
    if a == "reconnect":
        if engine and engine.running:
            engine.stop()
            build_engine()
            if engine:
                engine.start(resumed=True)
        else:
            build_engine()
        return {"ok": engine is not None, "message": "Reconnected." if engine else setup_error}
    if a == "use_iex":
        was = bool(engine and engine.running)
        if engine and engine.running:
            engine.stop()
        settings.data_feed = "iex"
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        return {"ok": engine is not None, "message": "Switched the data feed to IEX (free)."}
    if a == "trade_on":
        need_engine().start()
        return {"ok": True, "message": "Auto-trader started."}
    if a in ("restart", "repair"):
        exe = shutil.which("sekex")
        if not android.IS_ANDROID or not exe:
            raise HTTPException(400, "Restart / repair from the app works on the Android edition.")
        cmd = ["bash", exe, "restart"] if a == "restart" else \
            ["bash", "-c", f"SEKEX_QUICK=1 SEKEX_QUIET=1 bash {BASE_DIR_}/install.sh > $HOME/sekexbot-repair.log 2>&1; bash {exe} restart"]
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return {"ok": True, "restarting": True,
                "message": "Restarting…" if a == "restart" else "Repairing the install, then restarting (1–3 min)…"}
    if a == "update":
        return update_install()
    raise HTTPException(400, "Unknown repair action")


class AskReq(BaseModel):
    question: str = ""
    error: str = ""


@app.post("/api/help/ask")
def help_ask(r: AskReq):
    from autobot import helpdesk
    return helpdesk.ask(r.question[:800], _diag(), __version__, r.error[:600])


from autobot.selffix import SelfFix  # noqa: E402
selffix = SelfFix(__version__, lambda: {"mode": engine.mode if engine else "-", "running": bool(engine and engine.running),
                                        "session": engine.session.name if engine and engine.session else "-",
                                        "state": engine.state if engine else setup_error, "sim": ARGS.sim})
if not ARGS.sim:
    selffix.confirm_after_boot()


class FixReq(BaseModel):
    problem: str = ""
    error: str = ""
    images: list[dict] = []


class PinReq(BaseModel):
    pin: str = ""


class FixPinReq(BaseModel):
    id: str
    pin: str = ""


def _need_pin(request, pin):
    ip = "pin:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    if not live_pin():
        raise HTTPException(400, "Set a Live PIN first (⚙ → Broker keys → Live). Fixes need it to be applied.")
    if not pin_ok(pin):
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong PIN")


def _restart_soon(why):
    import threading as _thr
    logging.warning("Restarting for %s", why)

    def _go():
        import time as _tm
        _tm.sleep(1.5)
        os._exit(0)            # the sekex watchdog starts it again in ~5 s; trading resumes if it was running
    _thr.Thread(target=_go, daemon=True).start()


@app.get("/api/selffix/status")
def selffix_status():
    return clean(selffix.status())


@app.post("/api/selffix/start")
def selffix_start(r: FixReq):
    try:
        return {"ok": True, "job": selffix.start(r.problem[:2000], r.error[:2000], r.images)}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.post("/api/selffix/discard")
def selffix_discard():
    selffix.discard()
    return {"ok": True}


@app.post("/api/selffix/apply")
def selffix_apply(r: PinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        rec = selffix.apply()
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix applied: {rec['summary'][:160]}", "warning")
    _restart_soon("a Claude fix")
    return {"ok": True, "fix": rec}


@app.post("/api/selffix/undo")
def selffix_undo(r: PinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        rec = selffix.undo()
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix undone: {rec['summary'][:120]}", "warning")
    _restart_soon("undoing a Claude fix")
    return {"ok": True, "fix": rec}


@app.post("/api/selffix/reapply")
def selffix_reapply(r: FixPinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        selffix.prepare_reapply(r.id)
        rec = selffix.apply()
    except (ValueError, SyntaxError) as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix re-applied after an update: {rec['summary'][:140]}", "warning")
    _restart_soon("re-applying a Claude fix")
    return {"ok": True, "fix": rec}


@app.get("/api/selffix/export")
def selffix_export():
    body = json.dumps(selffix.export(), indent=1)
    return Response(body, media_type="application/json",
                    headers={"Content-Disposition": f'attachment; filename="sekexbot_fixes_v{__version__}.json"'})


_SECRET_WORDS = ("key", "secret", "pin", "token", "password", "pass", "webhook", "chat_id", "url")


def _support_files() -> dict:
    """The review bundle (journal, learner, strategy stats, skip log, scrubbed settings, redacted log tail) as
    {file name: bytes}. Used by the Export button and, when the user opted in, by the remote log upload."""
    import csv
    import io
    import sqlite3
    out = {}
    dbf = DATA_DIR / "trades.db"
    if dbf.exists():
        try:
            c = sqlite3.connect(f"file:{dbf}?mode=ro", uri=True)
            cur = c.execute("select * from trades order by opened_at")
            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow([d[0] for d in cur.description])
            w.writerows(cur.fetchall())
            out["journal_trades.csv"] = buf.getvalue().encode()
            c.close()
        except Exception as ex:
            out["journal_error.txt"] = str(ex).encode()
    for name in ("learner.json", "level_stats.json", "slippage.json", "day_state.json", "premkt.json", "prep.json", "manual_learn.json", "tune_epoch.json"):
        f = DATA_DIR / name
        if f.exists() and f.stat().st_size < 3_000_000:
            out[name] = f.read_bytes()
    try:
        st = json.loads((DATA_DIR / "settings.json").read_text())
        st = {k: v for k, v in st.items() if not any(w in k.lower() for w in _SECRET_WORDS) and k not in ("collector_url", "diag_label")}
        out["settings_scrubbed.json"] = json.dumps(st, indent=1).encode()
    except Exception:
        pass
    lg = DATA_DIR / "autobot.log"
    if lg.exists():
        try:
            from autobot.helpdesk import redact
            lines = lg.read_text(errors="replace").splitlines()[-6000:]
            out["autobot_log_tail.txt"] = redact("\n".join(lines)).encode()
        except Exception:
            pass
    try:
        if engine:
            out["why_no_trade_skips.json"] = json.dumps(list(engine.skips)[:600], indent=1).encode()
            out["recent_events.json"] = json.dumps(list(engine.events)[:300], indent=1).encode()
            out["movers_board.json"] = json.dumps(engine._movers_view(), indent=1).encode()
    except Exception:
        pass
    try:
        out["fixes_on_this_phone.json"] = json.dumps(selffix.export(), indent=1).encode()
    except Exception:
        pass
    out["README.txt"] = (f"SekexBot {__version__} support export, {datetime.now():%Y-%m-%d %H:%M}.\n"
                         "Contains: the trade journal, strategy/learner state, scrubbed settings and the recent engine log.\n"
                         "It does not contain API keys, PINs, tokens, the .env file or the account number.\n").encode()
    return out


def _support_zip() -> bytes:
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in _support_files().items():
            z.writestr(n, b)
    return buf.getvalue()


@app.get("/api/support/export")
def support_export():
    """One zip with the trade journal and the strategy/engine logs, for reviewing why trades lose. Phone only."""
    return Response(_support_zip(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="sekexbot_support_export_v{__version__}.zip"'})


@app.get("/api/diag/logs_preview")
def diag_logs_preview():
    """What the remote log upload would send: file names, sizes, and the first journal rows."""
    files = _support_files()
    j = files.get("journal_trades.csv", b"").decode(errors="replace").splitlines()
    return {"files": {n: len(b) for n, b in files.items()}, "journal_rows": max(0, len(j) - 1),
            "journal_header_and_first_rows": j[:4],
            "never_included": "API keys, PINs, tokens, the .env file, your account number, your collector address"}


@app.post("/api/help/report")
def help_report():
    from autobot import helpdesk
    st = {"mode": engine.mode if engine else "-", "state": engine.state if engine else setup_error,
          "running": bool(engine and engine.running), "edition": android.EDITION,
          "session": engine.session.name if engine and engine.session else "-"}
    text = helpdesk.report(_diag(), __version__, st)
    dl = Path.home() / "storage" / "downloads"
    target = (dl if dl.exists() else DATA_DIR) / f"SekexBot_report_{datetime.now(NY).strftime('%Y%m%d_%H%M')}.txt"
    try:
        target.write_text(text)
    except Exception:
        target = None
    return {"ok": True, "path": str(target) if target else "", "text": text[:20000]}


# ---------------- alerts ----------------
@app.get("/api/alerts")
def alerts_get(since: int = 0):
    items = [a for a in list(alerts.history) if a["id"] > since]
    return {"items": items[:60], "cfg": alerts.public_cfg()}


class AlertCfg(BaseModel):
    enabled: dict | None = None
    phone: bool | None = None
    quiet_start: str | None = None
    quiet_end: str | None = None
    quiet_keep_risk: bool | None = None
    ntfy_topic: str | None = None
    ntfy_server: str | None = None
    tg_token: str | None = None
    tg_chat: str | None = None
    beep: bool | None = None
    voice: bool | None = None
    predict_min: int | None = None


class SoundReq(BaseModel):
    on: bool


@app.post("/api/alerts/sound")
def alerts_sound(r: SoundReq):
    """The 🔊 ON / OFF button in the top bar: turns the phone's beep and voice on or off together.
    Allowed from the remote link too (it can only make alerts quieter or louder, nothing else)."""
    alerts.cfg["beep"] = alerts.cfg["voice"] = bool(r.on)
    if not r.on:
        alerts.screen_sound_at = 0.0
    alerts.save()
    return {"ok": True, "on": bool(r.on)}


@app.post("/api/alerts/test_voice")
def alerts_test_voice():
    return {"ok": alerts.test_voice()}


@app.post("/api/alerts/config")
def alerts_config(r: AlertCfg):
    import re
    for k, v in r.model_dump(exclude_none=True).items():
        if k == "enabled":
            alerts.cfg["enabled"].update({a: bool(b) for a, b in v.items() if a in alerts.cfg["enabled"]})
        elif k in ("quiet_start", "quiet_end"):
            if v and not re.fullmatch(r"[0-2]\d:[0-5]\d", v):
                raise HTTPException(400, "Quiet hours must look like 22:00")
            alerts.cfg[k] = v
        elif k == "ntfy_topic":
            if v and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", v):
                raise HTTPException(400, "ntfy topic: letters, numbers, - and _ only")
            alerts.cfg[k] = v
        else:
            alerts.cfg[k] = v.strip() if isinstance(v, str) else v
    alerts.save()
    return {"ok": True, "cfg": alerts.public_cfg()}


@app.post("/api/alerts/test")
def alerts_test():
    alerts.test()
    return {"ok": True}


class PriceAlertReq(BaseModel):
    symbol: str = ""
    op: str = "above"
    price: float = 0
    note: str = ""
    remove: str = ""


@app.post("/api/alerts/price")
def alerts_price(r: PriceAlertReq):
    if r.remove:
        watcher.remove_price_alert(r.remove)
    else:
        sym = _valid_sym(r.symbol)
        if r.op not in ("above", "below") or r.price <= 0:
            raise HTTPException(400, "Choose above or below and a price")
        if len(alerts.cfg.get("price_alerts", [])) >= 50:
            raise HTTPException(400, "Up to 50 price alerts")
        watcher.add_price_alert(sym, r.op, r.price, r.note[:60])
    return {"ok": True, "price_alerts": alerts.cfg.get("price_alerts", [])}


@app.post("/api/app/shutdown")
def app_shutdown():
    """Android: turn the whole app off (same as the home-screen Stop button / `sekex stop`)."""
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "Turning the app off from the dashboard is only available on the Android edition.")
    subprocess.Popen(["bash", exe, "stop", "--gui"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
    return {"ok": True}


@app.post("/api/ai_test")
def ai_test():
    from autobot.analyst import ai_ping
    return ai_ping()


class WatchReq(BaseModel):
    symbol: str
    action: str = "add"      # add | remove


@app.post("/api/watchlist")
def watchlist(r: WatchReq):
    sym = r.symbol.upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker")
    if r.action != "remove" and engine and getattr(engine, "mode", "") != "SIM":
        try:                                       # reject names Alpaca doesn't list (e.g. a company name instead of a ticker)
            if not engine.broker._tradable(sym, False):
                raise HTTPException(400, f"{sym} isn't a tradable ticker on Alpaca. Use the stock symbol (e.g. CVX for Chevron).")
        except HTTPException:
            raise
        except Exception:
            pass
    wl = [w.upper() for w in settings.watchlist]
    if r.action == "remove":
        wl = [w for w in wl if w != sym]
    elif sym not in wl:
        wl.append(sym)
    settings.watchlist = wl
    settings.save()
    if engine:
        engine.last_scan = None
        engine.ext_last_scan = None
        engine.event(f"Watchlist {'removed' if r.action == 'remove' else 'added'} {sym} — rescanning")
    return {"ok": True, "watchlist": wl}


# ---------------- 📊 stats · 📰 earnings/news · 🛡 heartbeat & backups ----------------
@app.get("/api/stats")
def stats_api(days: int = 90, session: str = ""):
    from autobot import stats as st
    e = need_engine()
    days = max(1, min(int(days), 365))
    try:
        if ARGS.sim:
            trips = []
            for r in db.recent(2000):
                if r.get("status") != "closed" or not r.get("closed_at"):
                    continue
                o, c = datetime.fromisoformat(r["opened_at"]), datetime.fromisoformat(r["closed_at"])
                trips.append({"symbol": r["symbol"], "side": "long" if r["side"] == "buy" else "short", "qty": r["qty"],
                              "entry": r["entry"], "exit": r["exit"], "opened": o.astimezone(NY), "closed": c.astimezone(NY),
                              "pnl": r["pnl"] or 0, "cost": (r["qty"] or 0) * (r["entry"] or 0)})
        else:
            trips = st.round_trips(st.fetch_fills(e.broker, days))
    except Exception as ex:
        raise HTTPException(502, f"Couldn't load your trade history from Alpaca: {str(ex)[:160]}")
    out = st.summarize(trips, db.recent(3000), days, session if session in st.ORDER else None)
    out["mode"] = e.mode
    return clean(out)


_research_cache = {}


@app.get("/api/research/{symbol}")
def research(symbol: str, days: int = 30, min_move: float = 1.5):
    """🔍 Trend legs + 3:55 PM overnight test from the stock's own minute history (runs on your Alpaca data)."""
    import time as _t
    from autobot import trends
    e = need_engine()
    sym = _valid_sym(symbol)
    days = max(5, min(int(days), 90))
    key = (sym, days, e.mode)
    c = _research_cache.get(key)
    if c and _t.time() - c[0] < 600:
        df = c[1]
    else:
        try:
            df = e.broker.chart_bars(sym, days=days + 3)
        except Exception as ex:
            raise HTTPException(502, f"Couldn't load {sym} history: {str(ex)[:150]}")
        if df is None or len(df) < 200:
            raise HTTPException(404, f"Not enough minute history for {sym} yet.")
        _research_cache[key] = (_t.time(), df)
    legs = trends.trend_legs(df, min_move=max(0.3, min(float(min_move), 20)) / 100)
    cb = trends.closing_bell(df)
    return clean({"symbol": sym, "days": days, "from": str(df.index[0].date()), "to": str(df.index[-1].date()),
                  "legs": legs[-80:], "summary": trends.summarize_legs(legs), "closing_bell": cb})


@app.get("/api/skips")
def skips_api(symbol: str = "", limit: int = 80):
    """'Why no trade?' - recent signals/flips the bot saw but did not take, with the reason."""
    e = need_engine()
    sym = symbol.strip().upper()
    rows = [r for r in list(e.skips) if not sym or r["symbol"] in (sym, "(all)")]
    return {"skips": rows[:max(1, min(int(limit), 300))]}


@app.get("/api/events/{symbol}")
def events_api(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    now = e.broker.now()
    news = events.news(sym, max_age=60) if not ARGS.sim else []
    return {"symbol": sym, "earnings": events.earnings_text(sym, now) if not ARGS.sim else "",
            "news": news[:6], "bot_block": events.block_reason(sym, now, _session_name(e)) if not ARGS.sim else "",
            **events.info()}


def _guard_status():
    e = engine
    if e is None:
        return ("NOT CONNECTED", 0, False)
    return (e.mode, len(e.positions or {}), bool(e.running))


def _need_guardian():
    if guardian is None:
        raise HTTPException(400, "Heartbeat and backups aren't available in the simulator.")
    return guardian


@app.get("/api/guardian")
def guardian_get():
    return _need_guardian().public()


class GuardCfg(BaseModel):
    hc_url: str | None = None
    gh_repo: str | None = None
    gh_token: str | None = None
    backup_on: bool | None = None


@app.post("/api/guardian/config")
def guardian_cfg(r: GuardCfg):
    g = _need_guardian()
    d = r.model_dump(exclude_none=True)
    if "hc_url" in d and d["hc_url"] and not d["hc_url"].startswith("https://"):
        raise HTTPException(400, "Paste the full ping URL from healthchecks.io (starts with https://hc-ping.com/…).")
    if "gh_repo" in d and d["gh_repo"] and d["gh_repo"].count("/") != 1:
        raise HTTPException(400, "Repo must look like owner/name, e.g. sekextrading-cloud/SekeXBot-Mobile")
    g.cfg.update(d)
    g.save()
    ok = g.ping() if d.get("hc_url") else None
    return {"ok": True, "ping": ok, **g.public()}


@app.post("/api/guardian/test")
def guardian_test():
    g = _need_guardian()
    if not g.cfg["hc_url"]:
        raise HTTPException(400, "Add your healthchecks.io ping URL first.")
    return {"ok": g.ping(), **g.public()}


@app.post("/api/guardian/backup")
def guardian_backup():
    g = _need_guardian()
    r = g.backup()
    return {**r, **g.public()}


@app.post("/api/guardian/restore")
async def guardian_restore(request: Request):
    g = _need_guardian()
    if engine and engine.running:
        raise HTTPException(409, "Stop the auto-trader before restoring a backup.")
    data = await request.body()
    try:
        n = g.restore(data)
    except Exception as ex:
        raise HTTPException(400, str(ex)[:160])
    learner.__init__()
    return {"ok": True, "files": n, "note": "Restored. Restart the app (⚙ → Turn off app, then open it) to reload everything."}


@app.on_event("startup")
def _start_guardian():
    global guardian
    if not ARGS.sim:
        from autobot.guardian import Guardian
        guardian = Guardian(_guard_status)


_load_addons()


if __name__ == "__main__":
    print(f"\n  SekexBot v{__version__} ({RELEASE_DATE}){' - Android edition' if android.IS_ANDROID else ''}")
    print(f"  SekexBot dashboard -> http://{ARGS.host}:{ARGS.port}"
          f"  ({'SIMULATOR' if ARGS.sim else ('LIVE' if settings.live else 'PAPER')})\n")
    uvicorn.run(app, host=ARGS.host, port=ARGS.port, log_level="warning", timeout_graceful_shutdown=4)
