"""v2.44: Plain-English trade signal for ONE stock: a status light, three lines (your price, take-profit, get-out) and short sentences.

States: WAIT, GET_READY, BUY_NOW (no position)  |  HOLD, TAKE_PROFIT, GET_OUT (you hold it).
Works for any position (yours or the bot's), from the same 5-minute swing reading as the chart (structure.py):
  * Get-out line = the last swing bottom under a long (last swing top over a short). A 5-minute candle that CLOSES beyond it = get out.
  * Take-profit = the nearest sell order you already have working; "room" = the highest recent swing top above it.
  * Worth it? = what you risk (entry to the get-out line) against what the target pays.
It describes where a trade is wrong and when to take the win. It does not predict."""
from . import structure as stx

LIGHTS = ["WAIT", "GET_READY", "BUY_NOW", "HOLD", "TAKE_PROFIT", "GET_OUT"]
NAME = {"WAIT": "WAIT", "GET_READY": "GET READY", "BUY_NOW": "BUY NOW", "HOLD": "HOLD", "TAKE_PROFIT": "TAKE PROFIT", "GET_OUT": "GET OUT"}
COLOR = {"WAIT": "#64748b", "GET_READY": "#d29922", "BUY_NOW": "#238636", "HOLD": "#238636", "TAKE_PROFIT": "#1f6feb", "GET_OUT": "#da3633"}


def _m(x):
    return f"${x:,.2f}" if abs(x) >= 0.1 else f"${x:,.4f}"


def _turns(lab, side):
    """How many bottoms in a row got higher (long) / tops in a row got lower (short), counted from the latest."""
    want, good = ("L", "HL") if side == "long" else ("H", "LH")
    n = 0
    for x in reversed([x for x in lab if x["kind"] == want]):
        if x["label"] == good:
            n += 1
        else:
            break
    return n


def targets(orders, sym, side, price):
    """The nearest working order that would CLOSE the position at a profit: limit sell at / above price (long) / limit buy at / below (short)."""
    best = None
    for o in orders or []:
        if o.get("symbol") != sym or o.get("limit") is None:
            continue
        if side == "long" and o.get("side") == "sell" and o["limit"] >= price * 0.997:
            best = o["limit"] if best is None else min(best, o["limit"])
        elif side == "short" and o.get("side") == "buy" and o["limit"] <= price * 1.003:
            best = o["limit"] if best is None else max(best, o["limit"])
    return best


def has_stop(orders, sym, side):
    for o in orders or []:
        if o.get("symbol") == sym and (o.get("stop") or o.get("trail")) and o.get("side") == ("sell" if side == "long" else "buy"):
            return True
    return False


def build(sym, d5, pos=None, orders=None, price=None, analysis=None):
    """pos: {'qty','avg_entry','price','upl'} or None. d5: closed 5-minute candles (yesterday + today). Returns the signal dict."""
    if d5 is None or len(d5) < 12:
        return {"symbol": sym, "state": "WAIT", "name": "WAIT", "color": COLOR["WAIT"], "title": "WAIT", "text": "Not enough candles yet to read this stock.", "rows": {}, "lines": {}}
    use = d5.iloc[-260:]
    last = float(use["close"].iloc[-1])
    px = float(price or last)
    lab = stx.label(stx.swings(use.iloc[-120:]))
    qty = float((pos or {}).get("qty") or 0)
    if qty:
        return _held(sym, use, lab, pos, orders, px)
    a = analysis or stx.analyze(use, use.index[-1].date())
    return _flat(sym, a, px)


def _flat(sym, a, px):
    p = a.get("plan")
    out = {"symbol": sym, "price": round(px, 4), "held": False, "side": None, "rows": {}, "lines": {}}
    if not p or p["state"] in ("in",):
        return dict(out, state="WAIT", name="WAIT", color=COLOR["WAIT"], title="⚪ WAIT",
                    text=f"No clear entry in {sym} right now. Nothing to do; I'll tell you when one is close.")
    side = "long" if p["side"] == "long" else "short"
    bet = "a rise (buy)" if side == "long" else "a drop (short)"
    above = "above" if side == "long" else "below"
    out.update(side=side, lines={"entry": p["entry"], "exit": p["exit_line"], "price": round(px, 4)})
    risk = abs(p["entry"] - p["exit_line"])
    out["rows"] = {"stay": f"If you take it, your exit is a close {'under' if side == 'long' else 'over'} {_m(p['exit_line'])}.",
                   "risk": f"Risk about {_m(risk)} a share from the entry line." if risk else ""}
    if p["state"] == "ready":
        d = abs(px - p["entry"])
        return dict(out, state="GET_READY", name="GET READY", color=COLOR["GET_READY"], title="🟡 GET READY",
                    text=f"{sym} is {_m(d)} from the entry line {_m(p['entry'])}, a bet on {bet}. Act only if a 5-minute candle CLOSES {above} it. If it doesn't, skip it.")
    if p["state"] == "go":
        return dict(out, state="BUY_NOW", name="BUY NOW" if side == "long" else "SHORT NOW", color=COLOR["BUY_NOW"], title="🟢 " + ("BUY NOW" if side == "long" else "SHORT NOW"),
                    text=f"A candle just closed {above} {_m(p['entry'])}. If you take it ({bet}), your exit is a close {'under' if side == 'long' else 'over'} {_m(p['exit_line'])}.")
    return dict(out, state="WAIT", name="WAIT", color=COLOR["WAIT"], title="⚪ WAIT",
                text=f"{sym} already moved through the entry ({_m(p['entry'])}). Too late to chase: wait for it to pull back.")


def _held(sym, use, lab, pos, orders, px):
    qty = float(pos["qty"])
    side = "long" if qty > 0 else "short"
    entry = float(pos.get("avg_entry") or px)
    n = abs(qty)
    line, broken = stx.exit_line_for(use, side)
    if line is None:
        lo = float(use["low"].iloc[-12:].min()) if side == "long" else float(use["high"].iloc[-12:].max())
        line, broken = lo, (float(use["close"].iloc[-1]) < lo if side == "long" else float(use["close"].iloc[-1]) > lo)
    d = 1 if side == "long" else -1
    tgt = targets(orders, sym, side, px)
    upl = float(pos.get("upl") if pos.get("upl") is not None else (px - entry) * qty)
    room = None
    tops = [x["price"] for x in lab if x["kind"] == ("H" if side == "long" else "L") and (x["price"] - (tgt or px)) * d > 0 and abs(x["price"] / px - 1) < 0.08]
    if tops:
        room = max(tops) if side == "long" else min(tops)
    risk = (entry - line) * d
    reward = ((tgt - entry) * d) if tgt else None
    k = _turns(lab, side)
    word = "higher bottoms" if side == "long" else "lower tops"
    lines = {"entry": round(entry, 4), "exit": round(line, 4), "target": round(tgt, 4) if tgt else None, "price": round(px, 4), "room": round(room, 4) if room else None}
    stop_on = has_stop(orders, sym, side)
    rows = {}
    rows["why"] = (f"It has made {k} {word} in a row ({'buyers' if side == 'long' else 'sellers'} step in sooner each time). That is the trend you are riding." if k >= 2
                   else f"The last {'bottom' if side == 'long' else 'top'} is {_m(line)}. As long as that holds, the move is intact.")
    rows["stay"] = f"Price stays {'above' if side == 'long' else 'below'} {_m(line)}. Small wiggles on the right side of it don't matter."
    rows["out"] = f"A 5-minute candle CLOSES {'under' if side == 'long' else 'over'} {_m(line)}. That means the move failed. Don't wait for it to come back."
    if tgt:
        rows["take"] = f"{_m(tgt)} is your sell order." + (f" The last {'high' if side == 'long' else 'low'} was {_m(room)}, so there may be room beyond it." if room else "")
    elif room:
        rows["take"] = f"No sell order is working. The last {'high' if side == 'long' else 'low'} was {_m(room)}: a natural place to take profit."
    else:
        rows["take"] = "No sell order is working and I see no clear target. Decide where you take the win."
    worth = None
    if reward is not None:
        if risk <= 0:
            worth = ("good", f"Your get-out line is already past your price, so a stop there locks in profit ({_m(-risk)} a share).")
        else:
            r = reward / risk if risk else 0
            lvl = "good" if r >= 1.8 else "ok" if r >= 1.2 else "bad"
            txt = f"Risk {_m(risk)} to make {_m(reward)}: " + ("about even" if lvl == "ok" else "pays well" if lvl == "good" else "pays less than it risks") + "."
            if lvl != "good" and room and ((room - entry) * d) / risk >= 1.8:
                txt += f" A target at {_m(room)} would pay {_m((room - entry) * d)} for the same risk."
            worth = (lvl, txt)
    if worth:
        rows["worth"], rows["worth_level"] = worth[1], worth[0]
    head = f"You {'own' if side == 'long' else 'are short'} <b>{int(n) if n == int(n) else n:g} {sym}</b> at <b>{_m(entry)}</b>. Right now <b>{_m(px)}</b> (<b>{'+' if upl >= 0 else '−'}${abs(upl):,.0f}</b>)."
    if broken:
        st, ttl = "GET_OUT", "🔴 GET OUT"
        text = head + f" A candle closed {'under' if side == 'long' else 'over'} {_m(line)}: <b>the move failed.</b> Sell now; every minute costs more."
    elif tgt and (px - tgt) * d >= -abs(tgt) * 0.001:
        st, ttl = "TAKE_PROFIT", "🎯 TAKE PROFIT"
        text = head + f" Price is at your target {_m(tgt)}. Take the win."
    else:
        st, ttl = "HOLD", "🟢 HOLD — you're in"
        text = head + f" The move is still alive: price is {'above' if side == 'long' else 'below'} the get-out line <b>{_m(line)}</b>." + (f" Your sell order at <b>{_m(tgt)}</b> is waiting." if tgt else "")
    out = {"symbol": sym, "held": True, "side": side, "qty": qty, "state": st, "name": NAME[st], "color": COLOR[st], "title": ttl, "text": text,
           "price": round(px, 4), "upl": round(upl, 2), "lines": lines, "rows": rows, "no_stop": not stop_on,
           "actions": {"stop_price": round(line, 2), "target_price": round(room, 2) if room and (not tgt or abs(room - entry) > abs(tgt - entry)) else None}}
    if not stop_on:
        out["stop_note"] = "No stop order is protecting this trade. Stops only work in regular hours; overnight the GET OUT alert watches the line and you tap Close."
    return out
