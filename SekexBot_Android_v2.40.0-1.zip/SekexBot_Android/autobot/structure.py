"""v2.39: Simple chart reading - swing highs/lows (HH / HL / LH / LL), the trend they make, the entry, the exit line, and the
key price levels drawn across the chart.

Rules (5-minute candles):
  * A swing high is a candle whose high is the highest of the 2 candles before and the 2 after it (swing low: the mirror).
    Highs and lows alternate; two in a row of the same kind keep the more extreme one.
  * UPTREND = the last high is higher than the one before AND the last low is higher than the one before (HH + HL).
    DOWNTREND = lower high + lower low (LH + LL). Anything else = CHOP (mixed: stay out or scalp small).
  * ENTRY (downtrend): after a lower high has formed, a 5-minute candle CLOSES below the last swing low. The EXIT LINE is
    that lower high: the short stays good while price stays under it; a 5-min close above it = get out.
    Uptrend is the mirror: close above the last swing high after a higher low; exit line = that higher low.
  * GET READY: the trend and the lower-high / higher-low are in place and price is within about one normal 5-min candle
    of the entry level.
This is a way to read and manage a trade, not a prediction: in testing, most days that look one-sided by 11 AM did not
keep going all day. The exit line is what keeps you in when a day does run (INTC Oct 30) and gets you out when it turns."""
import pandas as pd

K = 2                 # candles each side that make a swing point


def swings(d5, k=K):
    """[(i, 'H'|'L', price)] alternating, oldest first. Only candles with k closed candles after them count."""
    h, l = d5["high"].values, d5["low"].values
    n = len(d5)
    raw = []
    for i in range(k, n - k):
        if h[i] >= h[i - k:i + k + 1].max() and h[i] > max(h[i - k:i].max(), h[i + 1:i + k + 1].max()) - 1e-12:
            raw.append((i, "H", float(h[i])))
        if l[i] <= l[i - k:i + k + 1].min() and l[i] < min(l[i - k:i].min(), l[i + 1:i + k + 1].min()) + 1e-12:
            raw.append((i, "L", float(l[i])))
    out = []
    for s in raw:
        if out and out[-1][1] == s[1]:
            if (s[1] == "H" and s[2] >= out[-1][2]) or (s[1] == "L" and s[2] <= out[-1][2]):
                out[-1] = s
            continue
        out.append(s)
    return out


def label(sw):
    """Adds HH / LH / HL / LL (the first high / low of the list is just H / L)."""
    res, last = [], {"H": None, "L": None}
    for i, kind, px in sw:
        p = last[kind]
        if p is None:
            nm = kind
        elif kind == "H":
            nm = "HH" if px > p else "LH"
        else:
            nm = "HL" if px > p else "LL"
        last[kind] = px
        res.append({"i": i, "kind": kind, "price": round(px, 4), "label": nm})
    return res


def trend(lab):
    hs = [x for x in lab if x["kind"] == "H"][-2:]
    ls = [x for x in lab if x["kind"] == "L"][-2:]
    if len(hs) < 2 or len(ls) < 2:
        return "CHOP"
    if hs[1]["price"] > hs[0]["price"] and ls[1]["price"] > ls[0]["price"]:
        return "UP"
    if hs[1]["price"] < hs[0]["price"] and ls[1]["price"] < ls[0]["price"]:
        return "DOWN"
    return "CHOP"


BANNER = {"UP": "UPTREND · higher highs + higher lows · buy the dips, don't short them",
          "DOWN": "DOWNTREND · lower highs + lower lows · sell the bounces, don't buy them",
          "CHOP": "CHOP · mixed highs and lows · stay out or scalp small"}


def levels(df1, d5, now_day):
    """Key prices for today: pre-market high/low, opening range (9:30-10:00) high/low, yesterday's close, VWAP."""
    out = []
    t = d5[d5.index.date == now_day]
    m = t.index.hour * 60 + t.index.minute
    pm = t[(m >= 240) & (m < 570)]
    if len(pm):
        out += [{"name": "Pre-market high", "price": round(float(pm["high"].max()), 4), "color": "#94a3b8"},
                {"name": "Pre-market low", "price": round(float(pm["low"].min()), 4), "color": "#d29922"}]
    orr = t[(m >= 570) & (m < 600)]
    if len(orr) and (m >= 600).any():
        out += [{"name": "Opening range high", "price": round(float(orr["high"].max()), 4), "color": "#58a6ff"},
                {"name": "Opening range low", "price": round(float(orr["low"].min()), 4), "color": "#58a6ff"}]
    prev = d5[(d5.index.date < now_day)]
    if len(prev):
        pm_ = prev.index.hour * 60 + prev.index.minute
        reg = prev[(pm_ >= 570) & (pm_ < 960)]
        if len(reg):
            out.append({"name": "Yesterday close", "price": round(float(reg["close"].iloc[-1]), 4), "color": "#a78bfa"})
    return out


def replay(d5, k=K):
    """Walks the candles in order, the way you would watch them live (a swing is only known k candles later).
    Trend starts on a break of structure and ends when the exit line is crossed:
      DOWN starts when a candle closes below the last swing low while the last high was a lower high; it ends when a
      candle closes above the last swing high (the exit line). UP is the mirror. Otherwise CHOP.
    Returns (state, events, last_high, prev_high, last_low, prev_low, entry levels already used). events: [{'i','kind': 'go'|'exit','side','price','level','line'}]."""
    sw = swings(d5, k)
    by_conf = {}
    for i, kind, px in sw:
        by_conf.setdefault(i + k, []).append((i, kind, px))
    c = d5["close"].values
    H = [None, None]          # previous, last swing high
    L = [None, None]
    state, events, entry_used = "CHOP", [], set()
    for t in range(len(d5)):
        for i, kind, px in by_conf.get(t, []):
            if kind == "H":
                H = [H[1], px]
            else:
                L = [L[1], px]
        if H[1] is None or L[1] is None:
            continue
        if state == "DOWN" and c[t] > H[1]:
            events.append({"i": t, "kind": "exit", "side": "short", "price": float(c[t]), "line": H[1]})
            state = "CHOP"
        elif state == "UP" and c[t] < L[1]:
            events.append({"i": t, "kind": "exit", "side": "long", "price": float(c[t]), "line": L[1]})
            state = "CHOP"
        lower_high = H[0] is not None and H[1] < H[0]
        higher_low = L[0] is not None and L[1] > L[0]
        if c[t] < L[1] and (lower_high or state == "DOWN") and ("s", L[1]) not in entry_used:
            entry_used.add(("s", L[1]))
            events.append({"i": t, "kind": "go", "side": "short", "price": float(c[t]), "level": L[1], "line": H[1], "start": state != "DOWN"})
            state = "DOWN"
        elif c[t] > H[1] and (higher_low or state == "UP") and ("l", H[1]) not in entry_used:
            entry_used.add(("l", H[1]))
            events.append({"i": t, "kind": "go", "side": "long", "price": float(c[t]), "level": H[1], "line": L[1], "start": state != "UP"})
            state = "UP"
    return state, events, H[1], H[0], L[1], L[0], entry_used


def analyze(d5, now_day=None, df1=None):
    """d5: closed 5-minute candles, oldest first, New-York index (yesterday + today works best).
    Returns the trend banner, labelled swings, today's entry / exit events, the current plan (wait / ready / go / in)
    and the key levels."""
    empty = {"trend": "CHOP", "banner": BANNER["CHOP"], "swings": [], "events": [], "plan": None, "levels": []}
    if d5 is None or len(d5) < 8:
        return empty
    now_day = now_day or d5.index[-1].date()
    use = d5.iloc[-260:]
    off = len(d5) - len(use)
    state, events, h1, h0, l1, l0, used = replay(use)
    lab = label(swings(use))
    for x in lab:
        ts = use.index[x["i"]]
        x.update(t=ts.strftime("%H:%M"), d=ts.strftime("%a %b %d"), i=x["i"] + off)
    evs = []
    for ev in events:
        ts = use.index[ev["i"]]
        if ts.date() == now_day:
            evs.append(dict(ev, i=ev["i"] + off, t=ts.strftime("%H:%M"), d=ts.strftime("%a %b %d")))
    c = float(use["close"].iloc[-1])
    rng = float((use["high"] - use["low"]).iloc[-12:].mean() or 0) or c * 0.002
    last_t = len(use) - 1
    plan = None
    if h1 is not None and l1 is not None:
        lower_high = h0 is not None and h1 < h0
        higher_low = l0 is not None and l1 > l0
        go_now = [ev for ev in events if ev["i"] >= last_t - 1 and ev["kind"] == "go"]     # this candle or the one before (a missed pass still alerts)
        if go_now:
            ev = go_now[-1]
            late = abs(c - ev["level"]) > 1.5 * rng
            plan = {"side": ev["side"], "entry": ev["level"], "exit_line": ev["line"], "state": "late" if late else "go", "start": bool(ev.get("start"))}
        elif state == "DOWN":
            near = lower_high and l1 < c <= l1 + max(rng, c * 0.0015) and ("s", l1) not in used
            plan = {"side": "short", "entry": l1, "exit_line": h1, "state": "ready" if near else "in", "add": bool(near)}
        elif state == "UP":
            near = higher_low and h1 - max(rng, c * 0.0015) <= c < h1 and ("l", h1) not in used
            plan = {"side": "long", "entry": h1, "exit_line": l1, "state": "ready" if near else "in", "add": bool(near)}
        elif lower_high and not higher_low and l1 < c <= l1 + max(rng, c * 0.0015):
            plan = {"side": "short", "entry": l1, "exit_line": h1, "state": "ready"}
        elif higher_low and not lower_high and h1 - max(rng, c * 0.0015) <= c < h1:
            plan = {"side": "long", "entry": h1, "exit_line": l1, "state": "ready"}
        if plan:
            plan.update(entry=round(plan["entry"], 4), exit_line=round(plan["exit_line"], 4), price=round(c, 4),
                        dist=round(abs(c - plan["entry"]), 4), bar_t=use.index[-1].strftime("%Y-%m-%d %H:%M"))
    tr = state
    if tr == "CHOP" and plan and plan["state"] == "ready":
        tr = "DOWN" if plan["side"] == "short" else "UP"     # structure is leaning that way; not confirmed until the break
    lv = []
    try:
        lv = levels(df1, d5, now_day)
    except Exception:
        pass
    exits = [ev for ev in evs if ev["kind"] == "exit"]
    return {"trend": state, "lean": tr, "banner": BANNER[state], "swings": lab[-16:], "events": evs[-20:], "plan": plan, "levels": lv,
            "range": round(rng, 4), "last_exit": exits[-1] if exits else None}


def exit_line_for(d5, side):
    """The line a position you hold should stay beyond: long -> the last swing low; short -> the last swing high.
    Returns (line, broken_on_last_close) or (None, False)."""
    if d5 is None or len(d5) < 8:
        return None, False
    lab = label(swings(d5.iloc[-120:]))
    want = "L" if side == "long" else "H"
    xs = [x for x in lab if x["kind"] == want]
    if not xs:
        return None, False
    line = xs[-1]["price"]
    c = float(d5["close"].iloc[-1])
    return line, (c < line) if side == "long" else (c > line)


def to5(df1):
    """1-minute candles -> closed 5-minute candles (the still-forming one is dropped)."""
    if df1 is None or not len(df1):
        return df1
    d = df1.resample("5min", label="left", closed="left").agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
    if len(d) and d.index[-1] + pd.Timedelta(minutes=5) > df1.index[-1] + pd.Timedelta(minutes=1):
        d = d.iloc[:-1]
    return d
