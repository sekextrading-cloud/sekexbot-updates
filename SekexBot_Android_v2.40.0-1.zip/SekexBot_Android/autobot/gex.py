"""v2.40: Gamma exposure (GEX) by strike, the walls and the gamma flip.

How it is estimated (the common public method; no one outside the dealers knows their real book):
  * For every listed call and put near the price (expiries up to ~30 days), dollar gamma = gamma x open interest x 100
    x price^2 x 1%. Calls count as + (dealers assumed long them), puts as - (dealers assumed short them).
  * CALL WALL = the strike with the biggest + gamma; PUT WALL = the biggest - gamma. Price often stalls or pins there.
  * GAMMA FLIP = the price where the total turns from + to - (gamma recomputed at nearby prices with Black-Scholes).
    Above the flip (total +): dealers sell rallies and buy dips -> moves get damped, PIN / chop day.
    Below the flip (total -): dealers chase the move -> moves can run, TREND day.
Strongest for index ETFs (SPY, QQQ) and the biggest stocks. It is context, not a buy/sell signal; open interest updates
once a day, so the walls are most reliable in the morning."""
import json
import math
from datetime import date, datetime

from .config import DATA_DIR

LOG = DATA_DIR / "gex_log.jsonl"


def _n(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def bs_gamma(s, k, t, iv):
    if not (s and k and t and iv) or s <= 0 or k <= 0 or t <= 0 or iv <= 0:
        return 0.0
    d1 = (math.log(s / k) + 0.5 * iv * iv * t) / (iv * math.sqrt(t))
    return _n(d1) / (s * iv * math.sqrt(t))


def compute(spot, rows, today=None):
    """rows: [{'strike','type':'call'|'put','oi','gamma','iv','expiry':'YYYY-MM-DD'}].
    Returns the per-strike profile, the total, the walls, the flip and the regime (or None if there is nothing to use)."""
    today = today or date.today()
    use = [r for r in rows if r.get("oi") and r.get("strike")]
    if not spot or not use:
        return None
    by = {}
    for r in use:
        g = r.get("gamma")
        if g is None or g != g:
            try:
                t = max((date.fromisoformat(str(r["expiry"])) - today).days, 0.5) / 365.0
            except Exception:
                t = 7 / 365.0
            g = bs_gamma(spot, r["strike"], t, r.get("iv") or 0.3)
        v = float(g) * float(r["oi"]) * 100.0 * spot * spot * 0.01 * (1 if r["type"] == "call" else -1)
        by[r["strike"]] = by.get(r["strike"], 0.0) + v
    total = sum(by.values())
    if not by:
        return None
    call_wall = max(by, key=lambda k: by[k])
    put_wall = min(by, key=lambda k: by[k])

    def total_at(s2):
        tot = 0.0
        for r in use:
            try:
                t = max((date.fromisoformat(str(r["expiry"])) - today).days, 0.5) / 365.0
            except Exception:
                t = 7 / 365.0
            iv = r.get("iv") or 0.3
            tot += bs_gamma(s2, r["strike"], t, iv) * float(r["oi"]) * 100.0 * s2 * s2 * 0.01 * (1 if r["type"] == "call" else -1)
        return tot
    flip = None
    grid = [spot * (1 + p / 1000.0) for p in range(-60, 61, 2)]          # +/- 6% in 0.2% steps
    vals = [total_at(s2) for s2 in grid]
    for i in range(1, len(grid)):
        if (vals[i - 1] < 0) != (vals[i] < 0):
            a, b = vals[i - 1], vals[i]
            x = grid[i - 1] + (grid[i] - grid[i - 1]) * (-a / (b - a) if b != a else 0.5)
            if flip is None or abs(x - spot) < abs(flip - spot):
                flip = x
    tot_now = total_at(spot)
    regime = "PIN" if tot_now > 0 else "TREND"
    prof = sorted(by.items())
    near = [(k, v) for k, v in prof if abs(k - spot) <= spot * 0.05]
    return {"spot": round(spot, 2), "total": round(tot_now / 1e6, 2), "call_wall": call_wall, "put_wall": put_wall,
            "call_wall_m": round(by[call_wall] / 1e6, 2), "put_wall_m": round(by[put_wall] / 1e6, 2),
            "flip": round(flip, 2) if flip else None, "regime": regime,
            "read": ("PIN day: dealers damp the moves (price above the gamma flip). Fade the edges; the walls act like magnets."
                     if regime == "PIN" else
                     "TREND day: dealers chase the move (price below the gamma flip). Breaks can run; don't fade them."),
            "profile": [{"strike": k, "m": round(v / 1e6, 2)} for k, v in near]}


def log(sym, res, now=None):
    """One line per reading, so later we can test whether the walls / flip helped."""
    if not res:
        return
    try:
        with open(LOG, "a") as f:
            f.write(json.dumps({"t": (now or datetime.now()).isoformat(), "sym": sym, **{k: res[k] for k in ("spot", "total", "call_wall", "put_wall", "flip", "regime")}}) + "\n")
    except Exception:
        pass
