"""Replay a night through SWING_BOUNCE the way the engine trades it (approximation).
usage: python3 -I swing_sim.py <SekexBot_Android dir>"""
import os, sys, tempfile
os.environ["AUTOBOT_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, sys.argv[1])
import numpy as np
import pandas as pd
from autobot.indicators import enrich
from autobot.strategies import find_ext_signals

TZ = "America/New_York"
SHARES = 800
EXT_MIN_STOP_PCT = 0.0045
TIME_STOP_MIN = 75

# IREN 10/27-10/28 swings, read off the 5-min chart (approx). (start_price, end_price, "HH:MM" end)
IREN = [(27.52, 27.58, "21:00"), (27.58, 27.50, "21:30"), (27.50, 27.60, "22:00"), (27.60, 27.54, "22:25"),
        (27.54, 27.95, "23:20"), (27.95, 27.76, "00:30"), (27.76, 27.95, "01:10"), (27.95, 27.78, "02:00"),
        (27.78, 27.98, "02:45"), (27.98, 27.65, "03:45"), (27.65, 28.14, "04:10"), (28.14, 27.93, "04:45"),
        (27.93, 28.16, "05:15"), (28.16, 27.90, "06:00")]
DOWN = [(28.20, 27.40, "06:00")]          # straight bleed all night
UP = [(27.40, 28.20, "06:00")]            # straight grind up all night


def build(legs, seed, noise=0.010):
    rng = np.random.default_rng(seed)
    t0 = pd.Timestamp("2026-10-27 20:00", tz=TZ)
    pts, t = [], t0
    for a, b, end in legs:
        hh, mm = map(int, end.split(":"))
        te = pd.Timestamp(f"2026-10-{27 if hh >= 20 else 28} {hh:02d}:{mm:02d}", tz=TZ)
        n = int((te - t).total_seconds() // 60)
        path = np.linspace(a, b, n + 1)[1:] if n > 0 else []
        pts += list(path)
        t = te
    c = pd.Series(np.array(pts) + rng.normal(0, noise, len(pts)), index=pd.date_range(t0, periods=len(pts), freq="1min"))
    o = c.shift(1).fillna(c.iloc[0])
    wick = np.abs(rng.normal(0, noise * 0.6, len(c)))
    return pd.DataFrame({"open": o, "close": c, "high": np.maximum(o, c) + wick, "low": np.minimum(o, c) - wick,
                         "volume": rng.integers(1, 30, len(c)).astype(float)})   # overnight: quote-sample counts


def session_start(ts):
    s = ts.normalize() + pd.Timedelta(hours=4)          # PRE starts 04:00
    if ts.hour >= 20:
        return ts.normalize() + pd.Timedelta(hours=20)  # OVERNIGHT starts 20:00
    if ts.hour < 4:
        return ts.normalize() - pd.Timedelta(hours=4)   # yesterday 20:00
    return s


def run(df):
    full = enrich(df)
    trades, pos = [], None
    ctx = {"ext": True, "move": {}, "ribbon": {}, "shorts": False, "quote_bars": True}
    for i in range(30, len(full)):
        now = full.index[i]
        bar = full.iloc[i]
        if pos:
            age = (now - pos["t"]).total_seconds() / 60
            r = (bar["close"] - pos["entry"]) / (pos["entry"] - pos["stop"])
            if bar["high"] >= pos["target"]:
                pos.update(exit=pos["target"], why="target", t_out=now)
            elif bar["close"] <= pos["stop"]:
                pos.update(exit=bar["close"], why="stop", t_out=now)
            elif age >= TIME_STOP_MIN and r < 0.3:
                pos.update(exit=bar["close"], why="time", t_out=now)
            if "exit" in pos:
                pos["pnl"] = (pos["exit"] - pos["entry"]) * SHARES
                trades.append(pos)
                pos = None
            continue
        sigs = find_ext_signals({"IREN": full.iloc[: i + 1]}, ctx, session_start(now))
        sg = next((s for s in sigs if s.strategy == "SWING_BOUNCE"), None)
        if not sg:
            continue
        limit = round(sg.entry + 0.01, 2)                      # pay ~1 cent over (ask side)
        min_d = EXT_MIN_STOP_PCT * limit                        # engine widens thin-market stops
        stop = min(sg.stop, round(limit - min_d, 2))
        pos = {"t": now, "entry": limit, "stop": stop, "target": sg.extra["target"]}
    return trades


def summary(label, legs, seeds, show=False):
    tot, n, wins = [], 0, 0
    for sd in seeds:
        tr = run(build(legs, sd))
        tot.append(sum(t["pnl"] for t in tr))
        n += len(tr)
        wins += sum(t["pnl"] > 0 for t in tr)
        if show and sd == seeds[0]:
            for t in tr:
                print(f"  {t['t'].strftime('%H:%M')} BUY {t['entry']:.2f}  stop {t['stop']:.2f}  tgt {t['target']:.2f}"
                      f"  -> {t['t_out'].strftime('%H:%M')} {t['why']:6s} {t['exit']:.2f}  {t['pnl']:+8.2f}")
    tot = np.array(tot)
    print(f"{label:6s} nights={len(seeds)} trades/night={n / len(seeds):.1f} win%={100 * wins / max(n, 1):.0f} "
          f"avg ${tot.mean():+.0f}  median ${np.median(tot):+.0f}  worst ${tot.min():+.0f}  best ${tot.max():+.0f}")


if __name__ == "__main__":
    print("Sample IREN night (seed 0):")
    summary("IREN", IREN, list(range(30)), show=True)
    summary("DOWN", DOWN, list(range(30)))
    summary("UP", UP, list(range(30)))
