"""Checks autobot/manualpatterns.py with a fake broker. usage: python3 -I patterns_test.py <SekexBot_Android dir>"""
import os, sys, tempfile
os.environ["AUTOBOT_DATA"] = tempfile.mkdtemp()
sys.path.insert(0, sys.argv[1])
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
import numpy as np, pandas as pd
from autobot import manualpatterns as mp

NY = ZoneInfo("America/New_York")
rng = np.random.default_rng(1)


def bars_5m(start, end, path):
    """5-min bars following path(t) -> price."""
    idx = pd.date_range(start, end, freq="5min", tz=NY)
    c = np.array([path(t) for t in idx]) + rng.normal(0, 0.01, len(idx))
    o = np.r_[c[0], c[:-1]]
    return pd.DataFrame({"open": o, "high": np.maximum(o, c) + 0.02, "low": np.minimum(o, c) - 0.02, "close": c,
                         "volume": rng.integers(500, 5000, len(idx)).astype(float)}, index=idx)


class FakeBroker:
    def __init__(self):
        self.calls = 0
        self.frames = {}

    def daily_bars(self, sym, days=480):
        idx = pd.date_range("2025-06-01", "2026-10-27", freq="B", tz=NY)
        c = np.linspace(70, 27, len(idx))                    # long downtrend, like IREN
        return pd.DataFrame({"open": c, "high": c + 1, "low": c - 1, "close": c, "volume": 1e6}, index=idx)

    def bars_hist(self, symbols, start, end, minutes=5):
        self.calls += 1
        return {s: self.frames[s] for s in symbols if s in self.frames}


def trip(sym, d, t, entry, exit_, qty=800, hold=1800):
    return {"sym": sym, "dir": d, "qty": qty, "entry": entry, "exit": exit_, "pct": (exit_ - entry) / entry * d * 100,
            "usd": (exit_ - entry) * d * qty, "hold": hold, "open_t": t, "close_t": t + timedelta(seconds=hold),
            "source": "Alpaca", "time_known": True}


b = FakeBroker()
trips = []
# 12 nights: price peaks at 28.00 at 23:00, dips to 27.80 by 23:45 -> manual dip-buy at 27.82 (wins);
# then rallies to 28.10 by 00:30 -> manual breakout chase at 28.12 (loses)
for k in range(12):
    day = datetime(2026, 10, 1, tzinfo=NY) + timedelta(days=k)
    s, e = day.replace(hour=20), day.replace(hour=20) + timedelta(hours=6)

    def path(t, day=day):
        m = (t - day.replace(hour=20)).total_seconds() / 60
        if m <= 180: return 27.6 + 0.4 * m / 180        # 20:00 -> 23:00 up to 28.00
        if m <= 225: return 28.0 - 0.2 * (m - 180) / 45  # -> 23:45 down to 27.80
        if m <= 270: return 27.8 + 0.3 * (m - 225) / 45  # -> 00:30 up to 28.10
        return 28.1 - 0.4 * (m - 270) / 90
    sym = f"T{k}"
    b.frames[sym] = bars_5m(s, e, path)
    trips.append(trip(sym, 1, day.replace(hour=23, minute=50), 27.82, 27.98))       # dip-buy win
    trips.append(trip(sym, 1, (day + timedelta(days=1)).replace(hour=0, minute=35), 28.12, 27.95))  # chase loss

left = mp.tag(b, trips)
r = mp.report(trips, left)
setups = {row["label"]: row for g in r["groups"] if g["key"] == "setup" for row in g["rows"]}
print("setups:", {k: (v["n"], v["win_rate"]) for k, v in setups.items()})
print("best:", [e["what"] for e in r["best"]]); print("worst:", [e["what"] for e in r["worst"]])
assert setups["dip-buy (pullback off the high)"]["n"] == 12 and setups["dip-buy (pullback off the high)"]["win_rate"] == 100
chase = [setups[k] for k in ("breakout (above the last hour's high)", "bought near the high (chase)") if k in setups]
assert sum(c["n"] for c in chase) == 12 and all(c["win_rate"] == 0 for c in chase), chase
assert any("dip-buy" in e["what"] for e in r["best"]) and any("breakout" in e["what"] for e in r["worst"])
daily = {row["label"] for g in r["groups"] if g["key"] == "daily" for row in g["rows"]}
assert daily == {"against the daily trend"}, daily                   # longs in a daily downtrend
sess = {row["label"] for g in r["groups"] if g["key"] == "session" for row in g["rows"]}
assert sess == {"Overnight 8 PM-4 AM"}, sess

# cache: second run fetches nothing
calls = b.calls
mp.tag(b, [dict(t) for t in trips])
assert b.calls == calls, "features should come from the cache"

# no look-ahead: an entry at the very start (fewer than 12 completed bars) is not tagged from future bars
early = trip("T0", 1, datetime(2026, 10, 1, 20, 30, tzinfo=NY), 27.7, 27.8)
mp.tag(b, [early]); assert early.get("setup") == mp.UNKNOWN, early

# max_groups: untagged trips are reported and retried later
b2 = FakeBroker(); b2.frames = b.frames
mp.FEAT_FILE.unlink()
TAGS = ("id", "setup", "vwap", "ema", "trend", "daily")
more = [{k: v for k, v in t.items() if k not in TAGS} for t in trips]
left = mp.tag(b2, more, max_groups=3)
assert left > 0 and sum(1 for t in more if t.get("setup")) < len(more), left
print("max_groups ok: left", left)

# Robinhood CSV (newest first, like the real export), options row + dividend skipped, one row with a Time column
csv_text = '''"Activity Date","Process Date","Settle Date","Instrument","Description","Trans Code","Quantity","Price","Amount","Time"
"10/03/2026","10/03/2026","10/06/2026","IREN","IREN Ltd","Sell","800","$28.40","$22,720.00","10:15 AM"
"10/03/2026","10/03/2026","10/06/2026","IREN","IREN Ltd","Buy","800","$27.90","($22,320.00)","9:42 AM"
"10/02/2026","10/02/2026","10/05/2026","IREN","IREN 11/21/2026 Call $30.00","BTO","1","$1.20","($120.00)",""
"10/02/2026","10/02/2026","10/05/2026","SOFI","SoFi","Sell","100","$9.50","$950.00",""
"10/01/2026","10/01/2026","10/02/2026","SOFI","SoFi","Buy","100","$10.00","($1,000.00)",""
"09/30/2026","09/30/2026","09/30/2026","AAPL","Cash Div: R/D 2026-09-15","CDIV","","","$2.40",""
'''
r1 = mp.import_robinhood(csv_text)
print("rh import:", r1)
assert r1["added"] == 2 and r1["skipped"].get("BTO") == 1 and r1["skipped"].get("CDIV") == 1
assert mp.import_robinhood(csv_text)["added"] == 0, "re-import must not duplicate"
rh = mp.robinhood_saved()
iren = next(t for t in rh if t["sym"] == "IREN"); sofi = next(t for t in rh if t["sym"] == "SOFI")
assert iren["time_known"] and abs(iren["usd"] - 400) < 1e-6, iren
assert not sofi["time_known"] and sofi["hold_days"] == 1 and abs(sofi["usd"] + 50) < 1e-6, sofi
assert mp.hold_label(sofi) == "1 day" and mp.hold_label(iren) == "30 min-2 h"
try:
    mp.import_robinhood("a,b\n1,2\n"); raise SystemExit("bad csv accepted")
except ValueError as ex:
    print("bad csv rejected:", ex)
mp.clear_robinhood(); assert mp.robinhood_saved() == []

# analyze() with a broker that has no Alpaca 'trading' (simulator) and no Robinhood trips: empty, no crash
out = mp.analyze(FakeBroker(), 60)
assert out["n"] == 0, out
print("ALL PATTERN TESTS PASSED")
