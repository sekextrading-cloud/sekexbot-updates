"""Your trading METHOD, from your own trades.

manuallearn.py tells you HOW MUCH you win and lose. This tells you WHAT you were doing when you won: for every
manual round trip it rebuilds the 5-minute chart (and the daily chart) as it stood at the moment you entered and
tags the setup -- dip-buy or breakout, which session, above/below VWAP and the 5-minute EMA20, with or against the
5-minute and the daily trend, how long you held -- then groups your results by each tag so your real edges (and
your leaks) stand out.

Sources
  * Alpaca: your filled orders (bot orders skipped), paired by manuallearn.round_trips. Exact times, full tagging.
  * Robinhood: the account-activity CSV (Account > Reports and statements). Robinhood's export has DATES ONLY, so
    those trades get the daily-trend and hold tags but no intraday setup -- unless you add a 'Time' column
    (e.g. 9:42 or 9:42 PM, Eastern) to the rows you care about, then they get the full set. Imported trips are kept
    in data/manual_rh_trips.json (re-importing the same file adds nothing twice).

Price history comes from Alpaca's data API; overnight (8 PM - 4 AM) 5-minute bars need a feed that carries them,
so overnight entries may show 'no bars at entry'."""
import csv
import io
import json
import statistics as st
import threading
import time as _time
from collections import defaultdict
from datetime import datetime, timedelta

import pandas as pd

from .config import DATA_DIR

try:
    from zoneinfo import ZoneInfo
    NY = ZoneInfo("America/New_York")
except Exception:          # pragma: no cover
    NY = None

RH_FILE = DATA_DIR / "manual_rh_trips.json"
FEAT_FILE = DATA_DIR / "manual_features.json"
FEAT_VERSION = 1
MIN_BUCKET = 5               # a bucket needs this many trades before it can be called an edge or a leak
MIN_COMBO = 4
MAX_FETCH_GROUPS = 80        # price-history lookups per run (the rest are tagged on the next run)
DIP_MIN = 0.0045             # same yardstick as SWING_BOUNCE: >= 0.45% off the last hour's high is a real dip
UNKNOWN = "no bars at entry"
_lock = threading.Lock()


# ---------------------------------------------------------------- labels
def session_of(t):
    m = t.hour * 60 + t.minute
    if m >= 20 * 60 or m < 4 * 60:
        return "Overnight 8 PM-4 AM"
    if m < 9 * 60 + 30:
        return "Pre-market 4-9:30 AM"
    if m < 10 * 60 + 30:
        return "Open 9:30-10:30"
    if m < 14 * 60:
        return "Midday 10:30-2"
    if m < 16 * 60:
        return "Power hour 2-4 PM"
    return "After-hours 4-8 PM"


def _session_start(t):
    """Start of the session t falls in (for session VWAP)."""
    m = t.hour * 60 + t.minute
    day = t.replace(hour=0, minute=0, second=0, microsecond=0)
    if m >= 20 * 60:
        return day + timedelta(hours=20)
    if m < 4 * 60:
        return day - timedelta(hours=4)
    if m < 9 * 60 + 30:
        return day + timedelta(hours=4)
    if m < 16 * 60:
        return day + timedelta(hours=9, minutes=30)
    return day + timedelta(hours=16)


def hold_label(tr):
    if not tr.get("time_known", True):
        d = int(tr.get("hold_days") or 0)
        return "same day" if d == 0 else "1 day" if d == 1 else "2-5 days" if d <= 5 else "over 5 days"
    s = float(tr.get("hold") or 0)
    if s < 300:
        return "under 5 min"
    if s < 1800:
        return "5-30 min"
    if s < 7200:
        return "30 min-2 h"
    if s < 86400:
        return "2 h-1 day"
    return "over 1 day"


def _aware(t):
    if isinstance(t, str):
        t = datetime.fromisoformat(t)
    if t.tzinfo is None:
        t = t.replace(tzinfo=NY)
    return t.astimezone(NY)


def trip_id(tr):
    return "|".join(str(x) for x in (tr.get("source", "Alpaca"), tr["sym"], tr["dir"], _aware(tr["open_t"]).isoformat(),
                                       round(float(tr["qty"]), 4), round(float(tr["entry"]), 4)))


# ---------------------------------------------------------------- features
def intraday_features(b5, t, px, d):
    """Setup tags from 5-minute bars that had COMPLETED before the entry at time t, price px, direction d (+1 / -1)."""
    if b5 is None or not len(b5):
        return {}
    b = b5[b5.index + pd.Timedelta(minutes=5) <= t]
    if len(b) < 12:
        return {}
    last = b.iloc[-12:]                                      # the hour before the entry
    hi, lo = float(last["high"].max()), float(last["low"].min())
    rng = hi - lo
    if d > 0:
        if px > hi:
            setup = "breakout (above the last hour's high)"
        else:
            off, pos = (hi - px) / hi, ((px - lo) / rng if rng > 0 else 0.5)
            setup = ("dip-buy (pullback off the high)" if off >= DIP_MIN and pos <= 0.5 else
                     "bought near the high (chase)" if pos >= 0.8 else "mid-range")
    else:
        if px < lo:
            setup = "breakdown short (below the last hour's low)"
        else:
            off, pos = (px - lo) / lo, ((hi - px) / rng if rng > 0 else 0.5)
            setup = ("pop-short (sold a bounce)" if off >= DIP_MIN and pos <= 0.5 else
                     "shorted near the low (chase)" if pos >= 0.8 else "mid-range")
    out = {"setup": setup}
    sb = b[b.index >= _session_start(t)]
    if len(sb) and float(sb["volume"].sum()) > 0:
        tp = (sb["high"] + sb["low"] + sb["close"]) / 3
        vwap = float((tp * sb["volume"]).sum() / sb["volume"].sum())
        out["vwap"] = "entered above VWAP" if px >= vwap else "entered below VWAP"
    c = b["close"]
    e9, e20 = c.ewm(span=9, adjust=False).mean(), c.ewm(span=20, adjust=False).mean()
    out["ema"] = "entered above 5-min EMA20" if px >= float(e20.iloc[-1]) else "entered below 5-min EMA20"
    rising = float(e20.iloc[-1]) > float(e20.iloc[-4])
    tr = 1 if (e9.iloc[-1] > e20.iloc[-1] and rising) else -1 if (e9.iloc[-1] < e20.iloc[-1] and not rising) else 0
    out["trend"] = "5-min trend flat" if tr == 0 else ("with the 5-min trend" if tr == d else "against the 5-min trend")
    return out


def daily_features(daily, day, d):
    """Daily trend at the close BEFORE the entry day: above/below the 50- and 200-day averages."""
    if daily is None or not len(daily):
        return {}
    db = daily[daily.index.date < day]
    if len(db) < 50:
        return {}
    c = db["close"]
    px, m50 = float(c.iloc[-1]), float(c.rolling(50).mean().iloc[-1])
    m200 = float(c.rolling(200).mean().iloc[-1]) if len(c) >= 200 else None
    up = px > m50 and (m200 is None or px > m200)
    down = px < m50 and (m200 is None or px < m200)
    tr = 1 if up else -1 if down else 0
    return {"daily": "daily trend mixed" if tr == 0 else ("with the daily trend" if tr == d else "against the daily trend")}


def _load(path, default):
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def _save(path, obj):
    try:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(obj))
        tmp.replace(path)
    except Exception:
        pass


def tag(broker, trips, max_groups=MAX_FETCH_GROUPS):
    """Adds tag fields to each trip (cached by trip id). Returns how many still need price history."""
    with _lock:
        cache = _load(FEAT_FILE, {})
        if cache.get("_v") != FEAT_VERSION:
            cache = {"_v": FEAT_VERSION}
        todo = defaultdict(list)                       # (sym, NY date) -> trips needing intraday bars
        need_daily = set()
        for tr in trips:
            tr["id"] = trip_id(tr)
            f = cache.get(tr["id"])
            if f is not None:
                tr.update(f)
                continue
            if tr.get("time_known", True):
                todo[(tr["sym"], _aware(tr["open_t"]).date())].append(tr)
            need_daily.add(tr["sym"])
        dailies = {}
        for sym in sorted(need_daily):
            try:
                dailies[sym] = broker.daily_bars(sym, days=480)
            except Exception:
                dailies[sym] = None
        left = 0
        for gi, ((sym, day), grp) in enumerate(sorted(todo.items(), key=lambda kv: kv[0][1], reverse=True)):
            if gi >= max_groups:
                left += len(grp)
                continue
            ts = [_aware(t["open_t"]) for t in grp]
            try:
                b5 = (broker.bars_hist([sym], min(ts) - timedelta(hours=3), max(ts), 5) or {}).get(sym)
                if b5 is not None and len(b5):
                    b5.index = pd.to_datetime(b5.index).tz_convert(NY)
            except Exception:
                b5 = None
            for t, tr in zip(ts, grp):
                f = intraday_features(b5, t, float(tr["entry"]), int(tr["dir"])) or {"setup": UNKNOWN}
                tr["_intra"] = f
        for tr in trips:
            if tr["id"] in cache:
                continue
            if tr.get("time_known", True) and "_intra" not in tr:
                continue                                   # not reached this run: no cache entry, retried next time
            f = dict(tr.pop("_intra", {}))
            f.update(daily_features(dailies.get(tr["sym"]), _aware(tr["open_t"]).date(), int(tr["dir"])))
            tr.update(f)
            cache[tr["id"]] = f
        _save(FEAT_FILE, cache)
    return left


# ---------------------------------------------------------------- Robinhood CSV
def _num(s):
    s = str(s or "").strip().replace("$", "").replace(",", "")
    neg = s.startswith("(") and s.endswith(")")
    s = s.strip("()").rstrip("S").strip()
    if not s:
        return None
    v = float(s)
    return -v if neg else v


def _parse_time(s):
    s = str(s or "").strip().upper().replace(".", "")
    for fmt in ("%H:%M", "%H:%M:%S", "%I:%M %p", "%I:%M:%S %p", "%I:%M%p"):
        try:
            return datetime.strptime(s, fmt).time()
        except ValueError:
            continue
    return None


def parse_robinhood_csv(text):
    """Robinhood account-activity CSV -> (fills, skipped). Only stock Buy / Sell rows; options, dividends, transfers
    and fees are counted in skipped. Robinhood lists newest first, so rows are replayed bottom-up."""
    text = (text or "").lstrip("﻿")
    rows = list(csv.DictReader(io.StringIO(text)))
    if not rows:
        raise ValueError("The file has no rows.")
    cols = {c.strip().lower(): c for c in rows[0].keys() if c}
    need = ["activity date", "instrument", "trans code", "quantity", "price"]
    miss = [n for n in need if n not in cols]
    if miss:
        raise ValueError("This doesn't look like a Robinhood activity export (missing: " + ", ".join(miss) + ").")
    tcol = cols.get("time") or cols.get("activity time") or cols.get("execution time")
    fills, skipped = [], defaultdict(int)
    for seq, r in enumerate(reversed(rows)):
        code = str(r.get(cols["trans code"]) or "").strip()
        if code not in ("Buy", "Sell"):
            skipped[code or "blank"] += 1
            continue
        try:
            sym = str(r.get(cols["instrument"]) or "").strip().upper()
            qty, px = _num(r.get(cols["quantity"])), _num(r.get(cols["price"]))
            day = datetime.strptime(str(r.get(cols["activity date"])).strip(), "%m/%d/%Y").date()
        except Exception:
            skipped["unreadable"] += 1
            continue
        if not sym or not qty or not px:
            skipped["unreadable"] += 1
            continue
        tm = _parse_time(r.get(tcol)) if tcol else None
        if tm:
            t = datetime.combine(day, tm).replace(tzinfo=NY)
        else:
            t = datetime.combine(day, datetime.min.time()).replace(tzinfo=NY) + timedelta(seconds=seq)   # keeps file order
        fills.append({"sym": sym, "side": "buy" if code == "Buy" else "sell", "qty": abs(qty), "px": abs(px), "t": t,
                      "cid": "", "time_known": bool(tm)})
    fills.sort(key=lambda f: f["t"])
    return fills, dict(skipped)


def robinhood_trips(fills):
    from .manuallearn import round_trips
    known = {(f["sym"], f["t"]): f["time_known"] for f in fills}
    trips = round_trips(fills)
    for tr in trips:
        tr["source"] = "Robinhood"
        tr["time_known"] = bool(known.get((tr["sym"], tr["open_t"]))) and bool(known.get((tr["sym"], tr["close_t"])))
        tr["hold_days"] = (tr["close_t"].date() - tr["open_t"].date()).days
        tr.pop("re_gap", None)
        tr.pop("re_pb", None)
    return trips


def _ser(tr):
    o = {k: v for k, v in tr.items() if not k.startswith("_")}
    for k in ("open_t", "close_t"):
        if isinstance(o.get(k), datetime):
            o[k] = o[k].isoformat()
    return o


def import_robinhood(text):
    fills, skipped = parse_robinhood_csv(text)
    new = robinhood_trips(fills)
    with _lock:
        have = _load(RH_FILE, [])
        ids = {trip_id(t) for t in have}
        added = 0
        for tr in new:
            i = trip_id(tr)
            if i not in ids:
                have.append(_ser(tr))
                ids.add(i)
                added += 1
        _save(RH_FILE, have)
    open_left = sum(1 for _ in fills)  # informational
    return {"fills": open_left, "trips_in_file": len(new), "added": added, "total_robinhood": len(have),
            "skipped": skipped, "times_in_file": any(f["time_known"] for f in fills)}


def robinhood_saved():
    out = []
    for t in _load(RH_FILE, []):
        t = dict(t)
        t["open_t"], t["close_t"] = _aware(t["open_t"]), _aware(t["close_t"])
        out.append(t)
    return out


def clear_robinhood():
    with _lock:
        _save(RH_FILE, [])


# ---------------------------------------------------------------- report
FEATURES = [("source", "Account"), ("side", "Direction"), ("session", "Session"), ("setup", "Setup"),
            ("vwap", "VWAP"), ("ema", "5-min EMA20"), ("trend", "5-min trend"), ("daily", "Daily trend"),
            ("hold", "Hold time")]


def _stats(ts):
    n = len(ts)
    pct = [float(t["pct"]) for t in ts]
    wins = sum(1 for p in pct if p > 0)
    return {"n": n, "win_rate": round(100 * wins / n, 1) if n else 0, "avg_pct": round(st.mean(pct), 3) if n else 0,
            "med_pct": round(st.median(pct), 3) if n else 0, "net_usd": round(sum(float(t["usd"]) for t in ts), 2)}


def _labels(tr):
    lab = {"source": tr.get("source", "Alpaca"), "side": "long" if int(tr["dir"]) > 0 else "short",
           "hold": hold_label(tr)}
    if tr.get("time_known", True):
        lab["session"] = session_of(_aware(tr["open_t"]))
    for k in ("setup", "vwap", "ema", "trend", "daily"):
        if tr.get(k):
            lab[k] = tr[k]
    return lab


def report(trips, untagged=0):
    res = {"n": len(trips), "untagged": untagged, "at": _time.time()}
    if not trips:
        return res
    res["overall"] = _stats(trips)
    labs = [(_labels(t), t) for t in trips]
    groups, edges = [], []
    for key, title in FEATURES:
        b = defaultdict(list)
        for lab, t in labs:
            if key in lab:
                b[lab[key]].append(t)
        if not b:
            continue
        rows = []
        for val, ts in sorted(b.items(), key=lambda kv: -len(kv[1])):
            s = _stats(ts)
            s["label"] = val
            rows.append(s)
            if s["n"] >= MIN_BUCKET and val != UNKNOWN and key != "source":
                edges.append({"what": f"{title}: {val}", **s})
        groups.append({"key": key, "title": title, "rows": rows})
    res["groups"] = groups
    ov = res["overall"]["avg_pct"]
    res["best"] = sorted([e for e in edges if e["avg_pct"] > ov and e["avg_pct"] > 0], key=lambda e: -e["avg_pct"])[:4]
    res["worst"] = sorted([e for e in edges if e["avg_pct"] < ov and e["avg_pct"] < 0], key=lambda e: e["avg_pct"])[:4]
    combo = defaultdict(list)
    for lab, t in labs:
        if "setup" in lab and "session" in lab and lab["setup"] != UNKNOWN:
            combo[(lab["side"], lab["setup"], lab["session"])].append(t)
    cr = []
    for (side, setup, sess), ts in combo.items():
        if len(ts) >= MIN_COMBO:
            s = _stats(ts)
            s.update(side=side, setup=setup, session=sess)
            cr.append(s)
    res["combos"] = sorted(cr, key=lambda s: -s["avg_pct"])
    res["recent"] = [{"sym": t["sym"], "side": "long" if int(t["dir"]) > 0 else "short",
                      "open": _aware(t["open_t"]).strftime("%m-%d %H:%M") if t.get("time_known", True) else _aware(t["open_t"]).strftime("%m-%d"),
                      "pct": round(float(t["pct"]), 2), "usd": round(float(t["usd"]), 2), "source": t.get("source", "Alpaca"),
                      **{k: v for k, v in _labels(t).items() if k in ("session", "setup", "vwap", "trend", "daily", "hold")}}
                     for t in sorted(trips, key=lambda t: _aware(t["open_t"]), reverse=True)[:40]]
    return res


def analyze(broker, days=60, include_alpaca=True, include_robinhood=True):
    trips = []
    note = []
    if include_alpaca and hasattr(broker, "trading"):
        from . import manuallearn
        try:
            for t in manuallearn.round_trips(manuallearn.fetch_fills(broker, days)):
                t["source"] = "Alpaca"
                t["time_known"] = True
                t["open_t"], t["close_t"] = _aware(t["open_t"]), _aware(t["close_t"])
                trips.append(t)
        except Exception as ex:
            note.append(f"Couldn't read Alpaca order history: {str(ex)[:120]}")
    if include_robinhood:
        trips += robinhood_saved()
    left = tag(broker, trips) if trips else 0
    out = report(trips, left)
    out["days"] = days
    if note:
        out["note"] = " ".join(note)
    return out
