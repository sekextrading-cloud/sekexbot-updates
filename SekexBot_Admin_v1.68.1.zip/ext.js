/* SekexBot support admin add-on (installed only on the admin's phone). */
(function () {
if (document.getElementById('adm')) return;
const host = document.createElement('div');
host.innerHTML = `<div id="adm" style="display:none;position:fixed;inset:0;z-index:300;background:var(--bg);overflow:auto">
  <div style="max-width:920px;margin:0 auto;padding:14px 16px 40px">
    <div style="display:flex;align-items:center;gap:8px;margin-bottom:10px"><b style="font-size:18px;flex:1">🛠 Support admin</b>
      <button class="btn" id="admLock" onclick="admLock()" style="display:none">Lock</button><button class="btn" onclick="admClose()">Close</button></div>
    <div id="admLogin">
      <div class="mut" style="margin-bottom:8px">Enter the admin passcode. It is checked by the collector, not stored in this app.</div>
      <input id="admPass" type="password" inputmode="numeric" autocomplete="off" placeholder="Passcode" style="width:100%;max-width:260px;font-size:18px" onkeydown="if(event.key==='Enter')admLogin()">
      <div style="margin-top:8px"><input id="admUrl" placeholder="Collector address (https://…)" style="width:100%;max-width:420px"></div>
      <div style="margin-top:8px"><button class="btn" onclick="admLogin()">Unlock</button> <span id="admMsg" class="neg"></span></div>
    </div>
    <div id="admMain" style="display:none">
      <div id="admTabs" style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:10px"></div>
      <div id="admLogsBar" style="display:none"></div>
      <div id="admP-ov"><div class="mut">Loading…</div></div>
      <div id="admP-fleet" style="display:none">
        <div id="admSum" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:8px"></div>
        <input id="admQ" placeholder="Search name, model, version…" oninput="adm.q=this.value;admRender()" style="width:100%;margin-bottom:8px">
        <div id="admList"></div>
        <div id="admDetail" style="display:none"></div>
      </div>
      <div id="admP-trade" style="display:none"></div>
      <div id="admP-upd" style="display:none"></div>
      <div id="admP-ai" style="display:none">
        <div style="margin:4px 0"><button class="btn" onclick="admAiGroup()">🤖 Analyze everyone with AI</button></div>
        <div id="admAiGroup"></div>
        <div id="admLogs"></div>
      </div>
    </div>
  </div>
</div>
`;
document.body.appendChild(host.firstElementChild);
const adm = {tok: null, timer: null, list: [], q: '', open: null};
(function () {
  let n = 0, t = 0; const el = document.querySelector('header h1 svg'); if (!el) return;
  el.addEventListener('click', () => { const now = Date.now(); n = (now - t < 2500) ? n + 1 : 1; t = now; if (n >= 7) { n = 0; admOpen(); } });
})();
function admOpen() {
  $('adm').style.display = 'block'; document.body.style.overflow = 'hidden';
  call('diag/status').then(r => { if (!$('admUrl').value) $('admUrl').value = r.collector_url || ''; }).catch(() => {});
  if (adm.tok) { admShowMain(); } else { $('admLogin').style.display = ''; $('admMain').style.display = 'none'; $('admLock').style.display = 'none'; setTimeout(() => $('admPass').focus(), 100); }
}
function admClose() { $('adm').style.display = 'none'; document.body.style.overflow = ''; clearInterval(adm.timer); adm.timer = null; }
function admLock() { adm.tok = null; $('admPass').value = ''; admClose(); }
async function admFetch(path, method) {
  const r = await fetch('/api/admin/' + path, {method: method || 'GET', headers: {'x-token': TOKEN, 'x-admin-token': adm.tok || '', 'Content-Type': 'application/json'}});
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { if (r.status === 401 && adm.tok) { adm.tok = null; admOpen(); } throw new Error(j.detail || ('Error ' + r.status)); }
  return j;
}
async function admLogin() {
  $('admMsg').textContent = '';
  try {
    const r = await fetch('/api/admin/login', {method: 'POST', headers: {'x-token': TOKEN, 'Content-Type': 'application/json'},
      body: JSON.stringify({passcode: $('admPass').value, collector_url: $('admUrl').value})});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.detail || ('Error ' + r.status));
    adm.tok = j.token; $('admPass').value = ''; admShowMain();
  } catch (e) { $('admMsg').textContent = e.message; }
}
function admShowMain() {
  $('admLogin').style.display = 'none'; $('admMain').style.display = ''; $('admLock').style.display = '';
  tabsPaint(); admRefresh(); admOverview(); clearInterval(adm.timer); adm.timer = setInterval(() => { if (!adm.open) { admRefresh(); admOverview(); } }, 10000);
}
async function admRefresh() {
  try { const j = await admFetch('devices'); adm.list = j.devices || []; admRender(); } catch (e) { $('admList').innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
function vcmp(a, b) { const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0); } return 0; }
function ago(s) { return s < 90 ? 'now' : s < 5400 ? Math.round(s / 60) + ' min ago' : s < 172800 ? Math.round(s / 3600) + ' h ago' : Math.round(s / 86400) + ' d ago'; }
function dur(s) { return s < 3600 ? Math.round(s / 60) + ' min' : s < 172800 ? (s / 3600).toFixed(1) + ' h' : (s / 86400).toFixed(1) + ' d'; }
function admFlags(d, latest) {
  const f = [], b = d.battery || {}, sy = d.sys || {};
  if (!d._online) f.push(['offline ' + ago(d._last_seen_s), 'mut']);
  if (vcmp(d.app_version, latest) < 0) f.push(['old version', 'warn']);
  if ((d.cpu_app_pct || 0) > 80) f.push(['high CPU', 'bad']);
  if ((d.rss_mb || 0) > 500) f.push(['high app memory', 'bad']);
  if (sy.avail_mb != null && sy.avail_mb < 400) f.push(['phone low on memory', 'bad']);
  if (b.pct != null && b.pct < 20 && !b.charging) f.push(['battery low', 'bad']);
  if (b.temp_c != null && b.temp_c > 42) f.push(['phone hot', 'bad']);
  if (d.disk_free_gb != null && d.disk_free_gb < 1) f.push(['storage low', 'bad']);
  if (((d.errors || {}).count_1h || 0) > 10) f.push(['many errors', 'bad']);
  return f;
}
const FCOL = {bad: 'var(--red)', warn: 'var(--yellow)', mut: 'var(--mut)'};
function admRender() {
  const L = adm.list, q = adm.q.toLowerCase();
  const latest = L.reduce((m, d) => vcmp(d.app_version, m) > 0 ? d.app_version : m, '0.0.0');
  const on = L.filter(d => d._online).length, old = L.filter(d => vcmp(d.app_version, latest) < 0).length;
  const sick = L.filter(d => admFlags(d, latest).some(f => f[1] === 'bad')).length;
  const chip = (t, c) => `<span style="border:1px solid var(--line2);border-radius:999px;padding:3px 10px;font-size:13px;color:${c || 'var(--text)'}">${t}</span>`;
  $('admSum').innerHTML = chip(L.length + ' installs') + chip(on + ' online', 'var(--green)') + chip(old + ' on an old version', old ? 'var(--yellow)' : '') + chip(sick + ' with problems', sick ? 'var(--red)' : '') + chip('latest seen v' + latest, 'var(--mut)');
  const rows = L.filter(d => !q || JSON.stringify([d.label, d.os, d.app_version, d.install_id]).toLowerCase().includes(q));
  rows.sort((a, b) => (b._online - a._online) || (a._last_seen_s - b._last_seen_s));
  $('admList').innerHTML = rows.length ? rows.map(d => {
    const o = d.os || {}, b = d.battery || {}, sy = d.sys || {}, ap = d.app || {}, fl = admFlags(d, latest);
    const dev = o.model ? `${esc(o.maker || '')} ${esc(o.model)} · Android ${esc(o.android)} (SDK ${esc(o.sdk)})` : `${esc(o.system || '')} ${esc(o.kernel || '')}`;
    return `<div onclick="admDetail('${d.install_id}')" style="border:1px solid var(--line2);border-radius:10px;padding:10px;margin-bottom:8px;background:var(--panel);cursor:pointer">
      <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap"><span style="width:10px;height:10px;border-radius:50%;background:${d._online ? 'var(--green)' : 'var(--mut)'}"></span>
        <b>${esc(d.label || 'Install ' + d.install_id.slice(0, 8))}</b><span class="badge">v${esc(d.app_version)}</span>
        <span class="badge ${ap.mode === 'live' ? 'b-live' : 'b-paper'}">${ap.mode === 'live' ? 'LIVE' : 'PAPER'}</span><span style="margin-left:auto;color:var(--mut);font-size:12px">${ago(d._last_seen_s)}</span></div>
      <div style="font-size:13px;color:var(--mut);margin-top:4px">${dev}</div>
      <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:4px 12px;font-size:13px;margin-top:6px">
        <span>CPU (app) <b>${d.cpu_app_pct ?? '–'}%</b> of 1 core</span><span>App memory <b>${d.rss_mb ?? '–'} MB</b></span>
        <span>Phone free <b>${sy.avail_mb ?? '–'}</b> / ${sy.total_mb ?? '–'} MB</span><span>Battery <b>${b.pct ?? '–'}%</b>${b.charging ? ' ⚡' : ''}${b.temp_c != null ? ' · ' + b.temp_c + '°C' : ''}</span>
        <span>Up <b>${dur(d.uptime_s || 0)}</b></span><span>Trading <b>${ap.halted ? 'HALTED' : ap.trading_on ? 'on' : 'off'}</b></span>
        <span>Errors (1 h) <b style="color:${((d.errors || {}).count_1h || 0) ? 'var(--red)' : 'inherit'}">${(d.errors || {}).count_1h ?? 0}</b></span><span>Storage free <b>${d.disk_free_gb ?? '–'} GB</b></span></div>
      ${fl.length ? '<div style="margin-top:6px;display:flex;gap:6px;flex-wrap:wrap">' + fl.map(f => `<span style="font-size:12px;border:1px solid ${FCOL[f[1]]};color:${FCOL[f[1]]};border-radius:999px;padding:1px 8px">${esc(f[0])}</span>`).join('') + '</div>' : ''}</div>`;
  }).join('') : '<div class="mut">No installs have reported yet. Users appear here after they turn on Share diagnostics (or answer Share to the one-time question).</div>';
}
function spark(vals, color, unit) {
  const v = vals.filter(x => x != null); if (v.length < 2) return '<div class="mut" style="font-size:12px">not enough data yet</div>';
  const mx = Math.max(...v, 1), mn = Math.min(...v, 0), W = 300, H = 50;
  const pts = vals.map((x, i) => x == null ? null : `${(i / (vals.length - 1) * W).toFixed(1)},${(H - (x - mn) / (mx - mn || 1) * (H - 4) - 2).toFixed(1)}`).filter(Boolean).join(' ');
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:56px;background:var(--inp);border-radius:6px"><polyline points="${pts}" fill="none" stroke="${color}" stroke-width="1.5"/></svg><div class="mut" style="font-size:11px">min ${mn.toFixed(0)} · max ${mx.toFixed(0)} ${unit} (last 6 h)</div>`;
}
async function admDetail(id) {
  adm.open = id; const box = $('admDetail'); $('admList').style.display = 'none'; $('admSum').style.display = 'none'; $('admQ').style.display = 'none';
  box.style.display = ''; $('admLogsBar').style.display = 'none'; box.innerHTML = '<div class="mut">Loading…</div>';
  try {
    const j = await admFetch('device/' + id + '?hours=6'), d = j.device, o = d.os || {}, s = j.samples || [];
    const kv = (k, v) => `<div style="display:flex;gap:8px;padding:3px 0;border-bottom:1px solid var(--line)"><span style="color:var(--mut);min-width:130px">${k}</span><span style="word-break:break-word">${v}</span></div>`;
    box.innerHTML = `<button class="btn" onclick="admBack()">← Back</button> <b style="margin-left:8px">${esc(d.label || 'Install ' + id.slice(0, 8))}</b>
      <div style="margin:10px 0">${kv('Install ID', esc(id))}${kv('SekexBot', 'v' + esc(d.app_version))}${kv('Phone', esc((o.maker || '') + ' ' + (o.model || '')))}${kv('Android', esc(o.android || '–') + ' · SDK ' + esc(o.sdk || '–') + ' · patch ' + esc(o.patch || '–'))}${kv('Build', esc(o.build || '–'))}
        ${kv('Kernel / CPU', esc((o.kernel || '') + ' · ' + (o.arch || '') + ' · ' + ((d.sys || {}).cores || '?') + ' cores'))}${kv('Python', esc(o.python || '–'))}${kv('Libraries', esc(Object.entries(d.libs || {}).map(([k, v]) => k + ' ' + v).join(', ')) || '–')}
        ${kv('Load (1 min)', (d.sys || {}).load1 ?? '–')}${kv('App threads', d.threads ?? '–')}${kv('First seen', new Date(d._first_seen * 1000).toLocaleString())}${kv('Last report', ago(d._last_seen_s))}</div>
      <b>App CPU % (of one core)</b>${spark(s.map(x => x[1]), 'var(--blue)', '%')}<div style="height:8px"></div>
      <b>App memory MB</b>${spark(s.map(x => x[2]), 'var(--green)', 'MB')}<div style="height:8px"></div>
      <b>Phone free memory MB</b>${spark(s.map(x => x[3]), 'var(--yellow)', 'MB')}<div style="height:8px"></div>
      <b>Battery %</b>${spark(s.map(x => x[4]), 'var(--red)', '%')}
      <div style="margin:12px 0 4px"><b>Recent errors</b> <span class="mut">(scrubbed of keys and amounts)</span></div>
      <pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;background:var(--inp);padding:8px;border-radius:8px">${esc(((d.errors || {}).last || []).join('\n') || 'none')}</pre>
      <button class="btn" onclick="admForget('${id}')" style="margin-top:8px">Remove this install from the list</button>`;
  } catch (e) { box.innerHTML = '<button class="btn" onclick="admBack()">← Back</button><div class="neg">' + esc(e.message) + '</div>'; }
}
function admBack() { adm.open = null; $('admLogsBar').style.display = ''; $('admDetail').style.display = 'none'; $('admList').style.display = ''; $('admSum').style.display = 'flex'; $('admQ').style.display = ''; admRefresh(); }
async function admForget(id) { if (!confirm('Remove this install and its history from the collector? It reappears if it reports again.')) return; try { await admFetch('device/' + id, 'DELETE'); } catch (e) { alert(e.message); } admBack(); }

async function admDownload(path, name) {
  try {
    const r = await fetch('/api/admin/' + path, {headers: {'x-token': TOKEN, 'x-admin-token': adm.tok || ''}});
    if (!r.ok) { const j = await r.json().catch(() => ({})); throw new Error(j.detail || ('Error ' + r.status)); }
    const u = URL.createObjectURL(await r.blob()); const a = document.createElement('a'); a.href = u; a.download = name; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(u), 5000);
  } catch (e) { alert(e.message); }
}
/* ---------- dashboard (v1.68) ---------- */
const TABS = [['ov', 'Overview'], ['fleet', 'Fleet'], ['trade', 'Trading'], ['upd', 'Updates'], ['ai', 'AI & logs']];
adm.tab = 'ov'; adm.ov = null;
const money = v => (v < 0 ? '-$' : '+$') + Math.abs(Math.round(v)).toLocaleString();
const tone = v => v > 0 ? 'var(--green)' : v < 0 ? 'var(--red)' : 'var(--mut)';
function tabsPaint() {
  $('admTabs').innerHTML = TABS.map(([k, n]) => `<button class="btn" onclick="admTab('${k}')" style="${adm.tab === k ? 'border-color:var(--blue);color:var(--blue);font-weight:700' : ''}">${n}</button>`).join('');
  TABS.forEach(([k]) => { $('admP-' + k).style.display = adm.tab === k ? '' : 'none'; });
}
function admTab(k) { adm.tab = k; adm.open = null; tabsPaint(); if (k === 'ai') admLogsOpen(); if (k === 'fleet') admBack(); dashPaint(); }
async function admOverview() {
  try { adm.ov = await admFetch('overview'); dashPaint(); }
  catch (e) { const p = $('admP-' + adm.tab); if (adm.tab !== 'fleet' && adm.tab !== 'ai' && p) p.innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
function tile(label, value, sub, c) {
  return `<div style="flex:1;min-width:130px;border:1px solid var(--line2);border-radius:10px;padding:10px 12px;background:var(--panel)">
    <div class="mut" style="font-size:12px">${label}</div><div style="font-size:24px;font-weight:800;color:${c || 'var(--text)'};line-height:1.2">${value}</div>
    <div class="mut" style="font-size:12px">${sub || '&nbsp;'}</div></div>`;
}
function card(title, body, note) {
  return `<div style="border:1px solid var(--line2);border-radius:12px;padding:12px;margin:10px 0;background:var(--panel)">
    <div style="font-weight:700;margin-bottom:2px">${title}</div>${note ? `<div class="mut" style="font-size:12px;margin-bottom:8px">${note}</div>` : '<div style="height:6px"></div>'}${body}</div>`;
}
/* horizontal bars, signed values grow left (loss) or right (gain) from a centre line; values stay in text ink */
function hbars(obj, o) {
  o = o || {}; const e = Object.entries(obj || {}); if (!e.length) return '<div class="mut">No data yet.</div>';
  const val = ([, v]) => typeof v === 'object' ? v.pnl : v;
  const mx = Math.max(...e.map(x => Math.abs(val(x))), 1), signed = e.some(x => val(x) < 0) || o.signed;
  return e.map(([k, v]) => {
    const n = val([k, v]), w = Math.max(2, Math.abs(n) / mx * (signed ? 48 : 96)), col = o.color || (n < 0 ? 'var(--red)' : 'var(--green)');
    const extra = typeof v === 'object' ? `${v.trades} trades · win ${v.win_pct}% · avg ${v.avg_r}R` : '';
    const left = signed ? (n < 0 ? 50 - w : 50) : 0;
    const txt = o.fmt ? o.fmt(n) : (o.count ? n : (n < 0 ? '▼ ' : '▲ ') + money(n));
    return `<div style="margin:5px 0"><div style="display:flex;justify-content:space-between;gap:8px;font-size:13px"><span style="overflow-wrap:anywhere">${esc(k)}</span><b>${txt}</b></div>
      <div style="position:relative;height:10px;background:var(--inp);border-radius:5px;margin-top:2px"><div title="${esc(k)}: ${txt}${extra ? ' · ' + extra : ''}" style="position:absolute;left:${left}%;width:${w}%;top:0;bottom:0;background:${col};border-radius:${n < 0 && signed ? '5px 0 0 5px' : '0 5px 5px 0'}"></div>
      ${signed ? '<div style="position:absolute;left:50%;top:-2px;bottom:-2px;width:1px;background:var(--mut)"></div>' : ''}</div>
      ${extra ? `<div class="mut" style="font-size:11px">${extra}</div>` : ''}</div>`;
  }).join('');
}
function dailyChart(daily) {
  if (!daily || !daily.length) return '<div class="mut">No closed trades from sharing installs yet.</div>';
  const W = 600, H = 150, pad = 4, mx = Math.max(...daily.map(d => Math.abs(d[1])), 1), mid = H / 2, bw = Math.max(3, (W - pad * 2) / daily.length - 3);
  const bars = daily.map((d, i) => {
    const h = Math.max(2, Math.abs(d[1]) / mx * (mid - 12)), x = pad + i * ((W - pad * 2) / daily.length), up = d[1] >= 0;
    return `<rect x="${x.toFixed(1)}" y="${up ? mid - h : mid}" width="${bw.toFixed(1)}" height="${h.toFixed(1)}" rx="3" fill="${up ? 'var(--green)' : 'var(--red)'}"><title>${esc(d[0])}: ${money(d[1])}</title></rect>`;
  }).join('');
  const tbl = '<details style="margin-top:6px"><summary class="mut" style="font-size:12px">Table view</summary><table style="font-size:12px;width:100%">' + daily.map(d => `<tr><td>${esc(d[0])}</td><td style="text-align:right;color:${tone(d[1])}">${money(d[1])}</td></tr>`).join('') + '</table></details>';
  return `<svg viewBox="0 0 ${W} ${H}" style="width:100%;height:150px" role="img" aria-label="Daily profit and loss, all sharing installs"><line x1="0" x2="${W}" y1="${mid}" y2="${mid}" stroke="var(--mut)" stroke-width="1"/>${bars}
    <text x="2" y="10" font-size="10" fill="var(--mut)">${money(mx)}</text><text x="2" y="${H - 2}" font-size="10" fill="var(--mut)">${money(-mx)}</text></svg>
    <div style="display:flex;justify-content:space-between" class="mut"><span style="font-size:11px">${esc(daily[0][0])}</span><span style="font-size:11px">${esc(daily[daily.length - 1][0])}</span></div>${tbl}`;
}
function payoffBars(t) {
  if (t.avg_win == null) return '<div class="mut">No data yet.</div>';
  const mx = Math.max(t.avg_win, -t.avg_loss, 1), row = (n, v, c) => `<div style="margin:6px 0"><div style="display:flex;justify-content:space-between;font-size:13px"><span>${n}</span><b>${money(v)}</b></div><div style="height:10px;background:var(--inp);border-radius:5px"><div style="height:100%;width:${Math.abs(v) / mx * 100}%;background:${c};border-radius:5px"></div></div></div>`;
  const ok = t.payoff != null && t.payoff >= 1;
  return row('Average win', t.avg_win, 'var(--green)') + row('Average loss', t.avg_loss, 'var(--red)') +
    `<div style="font-size:13px;margin-top:6px">Payoff ratio <b style="color:${ok ? 'var(--green)' : 'var(--red)'}">${t.payoff ?? '–'} ${ok ? '▲' : '▼'}</b> <span class="mut">(a win pays this many losses; below 1 needs a win rate over ${t.payoff ? Math.round(100 / (1 + t.payoff)) : '–'}% to break even)</span></div>`;
}
function dashPaint() {
  tabsPaint(); const o = adm.ov; if (!o) return; const f = o.fleet, t = o.trading;
  const ov = $('admP-ov'), tr = $('admP-trade'), up = $('admP-upd');
  const tiles = '<div style="display:flex;gap:8px;flex-wrap:wrap">' +
    tile('Installs online', f.online + ' / ' + f.installs, (f.installs ? Math.round(100 * f.online / f.installs) + '% reporting' : ''), f.online === f.installs ? 'var(--green)' : '') +
    tile('Need the update', f.behind, 'latest v' + esc(f.latest), f.behind ? 'var(--yellow)' : 'var(--green)') +
    tile('With problems', f.problems, 'CPU, memory, battery, errors', f.problems ? 'var(--red)' : 'var(--green)') +
    tile('Group P&L', t.closed_trades ? money(t.total_pnl) : '–', t.closed_trades + ' trades · ' + t.installs_with_logs + ' sharing', tone(t.total_pnl)) +
    tile('Win rate', t.win_pct != null ? t.win_pct + '%' : '–', t.profit_factor != null ? 'profit factor ' + t.profit_factor : '') +
    tile('Payoff ratio', t.payoff != null ? t.payoff : '–', 'avg win ÷ avg loss', t.payoff != null ? (t.payoff >= 1 ? 'var(--green)' : 'var(--red)') : '') + '</div>';
  const attention = f.list.filter(i => i.flags.some(x => x !== 'offline' && x !== 'old version')).slice(0, 6);
  const att = attention.length ? attention.map(i => `<div style="font-size:13px;margin:4px 0"><b>${esc(i.label || 'Install ' + i.install_id.slice(0, 8))}</b> <span style="color:var(--red)">▼ ${esc(i.flags.filter(x => x !== 'offline' && x !== 'old version').join(', '))}</span></div>`).join('') : '<div style="color:var(--green)">▲ No installs with problems.</div>';
  ov.innerHTML = tiles +
    card('Group P&L by day', dailyChart(t.daily), 'Combined closed trades from every install that shares its trade logs (opt-in).') +
    card('Where the money goes (by strategy)', hbars(t.by_strategy), 'Worst at the top. Green right of the line = gain, red left = loss.') +
    card('Average win vs average loss', payoffBars(t)) +
    card('Fleet: versions', hbars(f.versions, {count: true, color: 'var(--blue)'}), 'Installs per app version.') +
    card('Needs attention', att);
  tr.innerHTML = tiles +
    card('Group P&L by day', dailyChart(t.daily)) + card('By strategy', hbars(t.by_strategy)) + card('By session', hbars(t.by_session)) +
    card('Long vs short', hbars(t.by_side)) + card('By exit type', hbars(t.by_exit), 'How trades ended. Plain/none = closed without a note.') +
    card('By time of day', hbars(t.by_time)) + card('Why trades were skipped (top reasons)', hbars(Object.fromEntries(t.top_skips || []), {count: true, color: 'var(--blue)', signed: false}), 'Numbers replaced with # so similar reasons group together.');
  const list = f.list.slice().sort((a, b) => vcmp(a.version, b.version) || (a.last_seen_s - b.last_seen_s));
  up.innerHTML = '<div style="display:flex;gap:8px;flex-wrap:wrap">' + tile('Latest version seen', 'v' + esc(f.latest), 'newest running anywhere') + tile('On the latest', f.installs - f.behind, 'of ' + f.installs, 'var(--green)') + tile('Behind', f.behind, 'need the update', f.behind ? 'var(--yellow)' : 'var(--green)') + '</div>' +
    card('Installs by version', hbars(f.versions, {count: true, color: 'var(--blue)'})) +
    card('Who needs the update', list.length ? list.map(i => `<div style="display:flex;gap:8px;align-items:center;justify-content:space-between;border-bottom:1px solid var(--line);padding:6px 0;font-size:13px"><span><b>${esc(i.label || 'Install ' + i.install_id.slice(0, 8))}</b> <span class="mut">${esc(i.model)}</span></span><span>v${esc(i.version)} ${vcmp(i.version, f.latest) < 0 ? '<span style="color:var(--yellow)">▼ behind</span>' : '<span style="color:var(--green)">▲ current</span>'} <span class="mut">· ${ago(i.last_seen_s)}</span></span></div>`).join('') : '<div class="mut">No installs yet.</div>',
      'Sorted oldest version first. An install updates when its owner taps Update.') +
    card('How to publish an update', '<div style="font-size:13px;line-height:1.6">On your admin phone: <code>sekex publish /path/SekexBot_Android_vX.zip</code> (keep the matching SekexBot_Admin zip in the same folder). It uploads the app, the encrypted admin add-on and latest.json. Then on every phone: Update. Your own phone also runs <code>sekex update</code> with the zip path.</div>');
}
async function admAiGroup() {
  const o = $('admAiGroup'); o.innerHTML = '<div class="mut">The AI helper is reading the combined results…</div>';
  try {
    const r = await fetch('/api/admin/ai/group', {method: 'POST', headers: {'x-token': TOKEN, 'x-admin-token': adm.tok || '', 'Content-Type': 'application/json'}, body: '{}'});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.detail || ('Error ' + r.status));
    o.innerHTML = j.error ? '<div class="neg">' + esc(j.error) + '</div>' : '<div style="white-space:pre-wrap;font-size:14px;line-height:1.5">' + esc(j.answer) + '</div><div class="mut" style="font-size:11px;margin-top:4px">' + esc(j.model || '') + ' · suggestions from numbers only, check before changing settings</div>';
  } catch (e) { o.innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
async function admLogsOpen() {
  const box = $('admLogs'); box.style.display = ''; box.innerHTML = '<div class="mut">Loading…</div>';
  try {
    const j = await admFetch('logs'), L = j.logs || [];
    box.innerHTML = '<div style="margin:10px 0 4px"><b>Trade logs from users</b> <button class="btn" onclick="admDownload(\'logs/all.zip\',\'sekexbot_all_logs.zip\')">⬇ Download all (merged)</button></div>' +
      (L.length ? L.map(d => `<div style="border:1px solid var(--line2);border-radius:10px;padding:10px;margin:8px 0;background:var(--panel)">
        <b>${esc(d.label || 'Install ' + d.install_id.slice(0, 8))}</b> <span class="badge">v${esc(d.version)}</span>
        <span class="mut" style="font-size:12px"> · received ${ago(j.now - d.ts)} · ${(d.size / 1024).toFixed(0)} KB · ${d.bundles} saved</span>
        <div style="margin-top:6px"><button class="btn" onclick="admLogSummary('${d.install_id}')">Numbers</button> <button class="btn" onclick="admLogAnalyze('${d.install_id}')">🤖 Analyze with AI</button> <button class="btn" onclick="admDownload('logs/${d.install_id}/zip','sekexbot_logs_${d.install_id.slice(0, 8)}.zip')">⬇ Zip</button></div>
        <div id="admLogOut-${d.install_id}"></div></div>`).join('') : '<div class="mut" style="margin-top:8px">No trade logs yet. Users send them only if they tick “Share my trade logs” (off by default). They arrive every 3 hours.</div>');
  } catch (e) { box.innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
function admLogsHide() {}
async function admLogSummary(id) {
  const o = $('admLogOut-' + id); o.innerHTML = '<div class="mut">Loading…</div>';
  try { const j = await admFetch('logs/' + id + '/summary'); o.innerHTML = '<pre style="white-space:pre-wrap;word-break:break-word;font-size:12px;background:var(--inp);padding:8px;border-radius:8px;max-height:50vh;overflow:auto">' + esc(JSON.stringify(j.summary, null, 1)) + '</pre>'; }
  catch (e) { o.innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
async function admLogAnalyze(id) {
  const o = $('admLogOut-' + id); o.innerHTML = '<div class="mut">The AI helper is reading the numbers…</div>';
  try {
    const r = await fetch('/api/admin/logs/' + id + '/analyze', {method: 'POST', headers: {'x-token': TOKEN, 'x-admin-token': adm.tok || '', 'Content-Type': 'application/json'}, body: '{}'});
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(j.detail || ('Error ' + r.status));
    o.innerHTML = j.error ? '<div class="neg">' + esc(j.error) + '</div>' : '<div style="white-space:pre-wrap;margin-top:8px;font-size:14px;line-height:1.5">' + esc(j.answer) + '</div><div class="mut" style="font-size:11px;margin-top:4px">' + esc(j.model || '') + ' · a suggestion from numbers only, check it before changing settings</div>';
  } catch (e) { o.innerHTML = '<div class="neg">' + esc(e.message) + '</div>'; }
}
window.admDownload = admDownload; window.admLogsOpen = admLogsOpen; window.admLogsHide = admLogsHide; window.admLogSummary = admLogSummary; window.admLogAnalyze = admLogAnalyze;
window.admTab = admTab; window.admAiGroup = admAiGroup;
window.admOpen = admOpen;
window.admClose = admClose;
window.admLock = admLock;
window.admLogin = admLogin;
window.admRender = admRender;
window.admBack = admBack;
window.admDetail = admDetail;
window.admForget = admForget;
})();
