"""v2.54: Winners only - one big switch that runs only what has made money on this phone and switches everything else off.

The rule, from your own journal (closed trades, PAPER and LIVE together, bad prints already voided):
  * MIN_TRADES (5) or more closed trades,
  * a net profit,
  * and still a profit without its single best trade (one lucky trade, or one bad print, is not a strategy).
A feature with no record yet can run ON TRIAL when its test on your chart history was positive (today: the Opening Rush big-first-candle
rule). A trial ends at MIN_TRADES trades of its own; from then on the rule above decides. The switch never changes a 'LIVE allowed'
setting, a size or a limit: it only turns autopilots on or off, and it puts your old on/off settings back when you switch it off.

This module is the rule and the saved state; server.py knows how to read and flip each feature."""
import json
import threading

from .config import DATA_DIR

FILE = DATA_DIR / "winners.json"
LOCK = threading.Lock()
MIN_TRADES = 5


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    out = {"on": False, "snapshot": {}, "checked": "", "manual": [], "log": []}
    out.update({k: d[k] for k in out if k in d})
    out["on"] = bool(out["on"])
    return out


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def base(name):
    return str(name or "").split("@")[0]


def score(pnls):
    """pnls: the closed-trade results of one feature. -> n, win %, pnl, pnl without the best trade, passes?"""
    p = [float(x or 0) for x in pnls]
    n = len(p)
    tot = sum(p)
    wo = tot - max(p) if p else 0.0
    return {"n": n, "win": round(100 * sum(1 for x in p if x > 0) / n) if n else None, "pnl": round(tot, 2), "wo_best": round(wo, 2),
            "pass": bool(n >= MIN_TRADES and tot > 0 and wo > 0)}


def verdict(sc, trial=False, manual=False):
    """('on' | 'trial' | 'manual' | 'off', plain reason)."""
    if sc["pass"]:
        return "on", f"{sc['n']} trades · {sc['win']}% wins"
    if manual:
        return "manual", "you switched it on yourself"
    if trial and sc["n"] < MIN_TRADES:
        return "trial", f"on trial: positive in the test, {sc['n']} of {MIN_TRADES} trades so far"
    if sc["n"] == 0:
        return "off", "no closed trades yet: not proven"
    if sc["n"] < MIN_TRADES:
        return "off", f"only {sc['n']} trades (needs {MIN_TRADES})"
    if sc["pnl"] <= 0:
        return "off", f"{sc['n']} trades · {sc['win']}% wins"
    return "off", f"{sc['n']} trades · one trade carries it (without it: {sc['wo_best']:+,.0f})"


def caution(sc):
    """A winner that still deserves a warning."""
    if not sc["pass"]:
        return ""
    if sc["n"] < 20:
        return "small sample"
    if (sc["win"] or 0) < 35:
        return "few winners: big wins carry it"
    return ""
