"""Auto-tune (v1.77): every night, switch a strategy off in ONE market session when YOUR OWN closed bot trades show it
losing there, and give it another try a week later. It never touches the daily loss limit, manual trades or other sessions."""
from datetime import datetime, timedelta

SESSIONS = ["PRE", "OPEN", "MIDDAY", "POWER", "AFTER", "OVERNIGHT"]
LABEL = {"PRE": "pre-market", "OPEN": "market open (9:30-10:30)", "MIDDAY": "midday (10:30-2:00)",
         "POWER": "afternoon (2:00-4:00)", "AFTER": "after-hours", "OVERNIGHT": "overnight"}
WINDOW_DAYS = 30
RETEST_DAYS = 7
PF_BAD = 0.9


def session_of(t):
    m = t.hour * 60 + t.minute
    if 4 * 60 <= m < 9 * 60 + 30:
        return "PRE"
    if m < 10 * 60 + 30 and m >= 9 * 60 + 30:
        return "OPEN"
    if 10 * 60 + 30 <= m < 14 * 60:
        return "MIDDAY"
    if 14 * 60 <= m < 16 * 60:
        return "POWER"
    if 16 * 60 <= m < 20 * 60:
        return "AFTER"
    return "OVERNIGHT"


def _strat(r):
    return str(r.get("strategy") or "").split("@")[0].upper()


def is_off(off, strategy, sess):
    return str(strategy).split("@")[0].upper() in (off or {}).get(sess, {})


def evaluate(rows, today, off, since, min_n=12):
    """rows: closed journal rows (same mode). today: 'YYYY-MM-DD'. off: {sess:{strat:retest_date}}. since: {'SESS:STRAT': date}.
    Returns (off, since, events[str])."""
    off = {s: dict(v) for s, v in (off or {}).items()}
    since = dict(since or {})
    ev = []
    cut = (datetime.strptime(today, "%Y-%m-%d") - timedelta(days=WINDOW_DAYS)).strftime("%Y-%m-%d")
    for s in list(off):
        for st, d in list(off[s].items()):
            if d <= today:                                    # retest time: back on, judged only on new trades from now
                del off[s][st]
                since[f"{s}:{st}"] = today
                ev.append(f"{st} back ON in the {LABEL.get(s, s)} for a fresh try (it was off for a week)")
        if not off[s]:
            del off[s]
    groups = {}
    for r in rows:
        st = _strat(r)
        if r.get("status") != "closed" or r.get("pnl") is None or not st or "MANUAL" in st or "HARVEST" in st or not st.replace("_", "").isalnum():
            continue
        try:
            sess = session_of(datetime.fromisoformat(r["opened_at"]))
        except Exception:
            continue
        if (r.get("day") or "") < max(cut, since.get(f"{sess}:{st}", "")):
            continue
        groups.setdefault((sess, st), []).append(float(r["pnl"]))
    for (sess, st), v in groups.items():
        if len(v) < min_n or st in off.get(sess, {}):
            continue
        gp, gl, tot = sum(x for x in v if x > 0), -sum(x for x in v if x < 0), sum(v)
        pf = gp / gl if gl else 9.9
        if tot < 0 and pf < PF_BAD:
            until = (datetime.strptime(today, "%Y-%m-%d") + timedelta(days=RETEST_DAYS)).strftime("%Y-%m-%d")
            off.setdefault(sess, {})[st] = until
            ev.append(f"{st} switched OFF in the {LABEL.get(sess, sess)}: {len(v)} trades, ${tot:+.2f}, profit factor {pf:.2f}. Retest {until}")
    return off, since, ev
