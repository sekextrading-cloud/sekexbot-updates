"""Smart entry (v1.78): in extended hours the bot no longer pays the whole spread up front.
It starts a limit order halfway across the spread, then steps toward the far side every STEP_S seconds, and ends at the
old marketable price. Stats of what it saved are kept in data/smart_entry.json."""
import json
from .config import DATA_DIR

STEP_S = 15
FRACS = (0.5, 0.75, 1.0)
FILE = DATA_DIR / "smart_entry.json"


def stage_for(age_s):
    return min(len(FRACS) - 1, int(max(age_s, 0) // STEP_S))


def smart_px(bid, ask, short, stage):
    """Price for a given stage. Long: bid + f*spread. Short: ask - f*spread. Stage 2 is the far side (ask / bid)."""
    f = FRACS[max(0, min(stage, len(FRACS) - 1))]
    sp = max(ask - bid, 0.0)
    return round(ask - f * sp if short else bid + f * sp, 4 if min(bid, ask) < 1 else 2)


def worth_it(bid, ask):
    """Only when the spread is at least 2 cents; below that there is nothing to save."""
    return ask - bid >= 0.02


def _load():
    try:
        return json.loads(FILE.read_text())
    except Exception:
        return {"n": 0, "saved": 0.0, "cheap": 0, "at_far": 0, "missed": 0, "stages": [0, 0, 0]}


def record_fill(stage, saved_usd):
    d = _load()
    d["n"] += 1
    d["saved"] = round(d["saved"] + saved_usd, 2)
    d["stages"][max(0, min(stage, 2))] += 1
    d["cheap" if stage < 2 else "at_far"] += 1
    try:
        FILE.write_text(json.dumps(d))
    except Exception:
        pass


def record_missed():
    d = _load()
    d["missed"] += 1
    try:
        FILE.write_text(json.dumps(d))
    except Exception:
        pass


def stats():
    return _load()
