"""♻ Auto-harvest for your manual trades: bank a small gain, then get back in on a pullback, over and over.

You buy (or short) by hand and tick "Auto-harvest". From then on this loop watches the position:

  HARVEST   sells the whole position as soon as it is up ~0.5 x the stock's normal 5-minute range
            (A), OR the gain has been green for 20 s and starts to fade (gave back 0.15 A from its
            best). A = 2.5 x the 1-minute ATR, never less than 0.15% of the price.
  RE-ENTER  after selling it waits for a pullback: price falls back at least 0.25 A from the highest
            price since the harvest (mirror image for shorts), the 3-minute ribbon still points your
            way, price is still on the right side of the ribbon's slow line, and the last 1-minute
            candle turns back your way. Then it buys / shorts the same size again.
  STOP      ends the cycle (and closes the position) if a trade goes 1.2 A against you (mid price,
            held 25 s, not in the first 3 minutes of a session or while the spread is too wide). It also ends
            if the ribbon turns against you for about a minute while waiting, if the daily loss limit
            halts trading, or when you tap Stop. Stop leaves an open position alone.

Works whether or not the auto-trader is running. Extended hours use limit orders, so the position's
protective stop is watched by the app (the app has to stay open). Overnight (8 PM - 4 AM) it pauses and
holds the position as is; it resumes at 4 AM pre-market."""
import json
import logging
import threading
import re
import time
from datetime import datetime, timedelta

from .indicators import enrich, ribbon_state

log = logging.getLogger("autobot")

TARGET_A = 0.5          # harvest at this many A of profit
STALL_A = 0.15          # ...or once it gives back this much from its best (after 20 s green)
GREEN_A = 0.25          # "green" = at least this much profit
STOP_A = 1.2            # protective stop, in A
CONT_A = 0.3            # ...or jump back in when it keeps running: this far past the exit price, at a new extreme
CONT_SECS = 45          # ...but not sooner than this after the exit
PULLBACK_A = 0.25       # re-enter after this pullback from the best price since the harvest
GREEN_SECS = 20
TURN_SECS = 60          # ribbon against you this long while waiting -> stop cycling
DAY_CYCLE_CAP = 60      # hard safety cap on harvests per symbol per day
POLL = 4                # seconds between checks


class Harvester:
    def __init__(self, get_engine, quote_fn, session_fn, open_fn, close_fn, path):
        self.get_engine, self.quote_fn, self.session_fn = get_engine, quote_fn, session_fn
        self.open_fn, self.close_fn = open_fn, close_fn
        self.path = path
        self.jobs: dict = {}
        self.lock = threading.RLock()
        self._bars = {}                # sym -> (t, A, ribbon_state, last_two_closes)
        self._load()
        threading.Thread(target=self._loop, daemon=True, name="harvester").start()

    # ---------- persistence ----------
    def _load(self):
        try:
            data = json.loads(open(self.path).read())
            for sym, j in (data.get("jobs") or {}).items():
                j["phase"] = {"entering": "armed", "exiting": "holding"}.get(j.get("phase"), j.get("phase"))
                self.jobs[sym] = j
        except Exception:
            pass

    def _save(self):
        try:
            with open(self.path, "w") as f:
                json.dump({"jobs": self.jobs}, f)
        except Exception:
            pass

    # ---------- control ----------
    def arm(self, sym, side, qty, note=""):
        """side: 'buy' = long harvest cycle, 'sell' = short. qty = size to (re)trade each cycle."""
        with self.lock:
            old = self.jobs.get(sym)
            self.jobs[sym] = {"symbol": sym, "side": side, "qty": float(qty), "phase": "armed", "cycles": 0,
                              "banked": 0.0, "entry": 0.0, "peak_g": 0.0, "green_since": 0.0, "exit_px": 0.0,
                              "extreme": 0.0, "turn_since": 0.0, "armed_t": time.time(), "tries": 0, "sent_t": 0.0,
                              "msg": note or "waiting for your order to fill",
                              "day_cycles": (old or {}).get("day_cycles", 0)}
            self._save()

    def now(self, sym, side=None, qty=0.0):
        """Button on a position: holding -> sell now and keep cycling; waiting -> re-enter now. No job yet -> arm, then sell now.
        Returns a short message."""
        with self.lock:
            j = self.jobs.get(sym)
            if not j:
                if not side:
                    return "no position"
                self.arm(sym, side, qty, "harvesting now")
                self.jobs[sym]["now"] = True
                self._save()
                return "Auto-harvest is on and will sell within a few seconds, then re-enter on a pullback."
            ph = j["phase"]
            if ph in ("holding", "armed"):
                j["now"] = True
                self._save()
                return "Selling within a few seconds; it will re-enter on a pullback."
            if ph == "waiting":
                j["enter_now"] = True
                self._save()
                return "Buying back within a few seconds."
            return f"Already busy ({ph}); try again in a moment."

    def stop(self, sym, reason="stopped by you"):
        with self.lock:
            j = self.jobs.pop(sym, None)
            if j:
                self._say(j, f"♻ Auto-harvest OFF for {sym}: {reason}. {j['cycles']} harvest(s), about ${j['banked']:+,.2f} banked.")
                self._save()
            return bool(j)

    def status(self):
        with self.lock:
            return [{k: (round(v, 2) if isinstance(v, float) else v) for k, v in j.items()
                     if k in ("symbol", "side", "qty", "phase", "cycles", "banked", "entry", "msg")}
                    for j in self.jobs.values()]

    # ---------- helpers ----------
    def _say(self, j, msg, level="info", alert=None):
        e = self.get_engine()
        if not e:
            return
        try:
            e.event(msg, level)
            if alert:
                e.alert(alert[0], alert[1], alert[2], symbol=j["symbol"])
        except Exception:
            pass

    def _metrics(self, e, sym, price):
        """(A, ribbon dict or None, closes[-2:]) refreshed every 20 s."""
        c = self._bars.get(sym)
        if c and time.time() - c[0] < 20:
            return c[1], c[2], c[3]
        A, rb, closes = max(price * 0.003, 0.03), None, None
        try:
            raw = e.broker.bars([sym], start=e.broker.now() - timedelta(minutes=150)).get(sym)
            if raw is not None and len(raw) >= 20:
                d = enrich(raw)
                A = max(float(d["atr"].iloc[-1]) * 2.5, price * 0.0015, 0.02)
                rb = ribbon_state(raw)
                closes = [float(x) for x in d["close"].iloc[-3:]]
        except Exception:
            pass
        self._bars[sym] = (time.time(), A, rb, closes)
        return A, rb, closes

    # ---------- the loop ----------
    def _loop(self):
        while True:
            time.sleep(POLL)
            try:
                e = self.get_engine()
                if not e or not self.jobs:
                    continue
                with self.lock:
                    jobs = list(self.jobs.values())
                if not jobs:
                    continue
                sess = self.session_fn(e)
                if sess == "CLOSED":
                    continue
                pos = e.broker.positions()
                for j in jobs:
                    if j["symbol"] in self.jobs:
                        try:
                            self.step(e, j, pos, sess)
                        except Exception as ex:
                            log.warning("harvest %s: %s", j["symbol"], ex)
            except Exception as ex:
                log.warning("harvester: %s", ex)

    def step(self, e, j, pos, sess, now=None):
        sym, now = j["symbol"], (now or time.time())
        d = 1 if j["side"] == "buy" else -1
        if getattr(e.risk, "halted", False):
            return self.stop(sym, "the daily loss limit halted trading")
        if sym in getattr(e, "trades", {}):
            return self.stop(sym, "the auto-trader is managing this stock")
        p = pos.get(sym)
        has = bool(p and p["qty"] * d > 0)
        bid, ask = self.quote_fn(e, sym, sess)
        if not bid or not ask:
            return
        mark = bid if d > 0 else ask
        ph = j["phase"]
        if sess == "OVERNIGHT" and not (j.get("now") or j.get("enter_now")):
            # 8 PM - 4 AM quotes are thin and wide: an automatic harvest, stop or re-entry there would fill badly.
            # Pause (hold the position as is) and pick up again at 4 AM pre-market. Your own Harvest now / Re-enter
            # now button is a direct request, so it is NOT paused (v1.82.1).
            j["msg"] = "paused overnight (quotes too thin); holding as is, resumes at 4:00 AM. Harvest now still works."
            j["stop_since"] = 0.0
            return
        if j.get("sess") != sess:                 # a new session just started: let quotes settle
            j["sess"], j["sess_t"] = sess, now
            j["stop_since"] = 0.0

        if ph == "armed":
            if has:
                j.update(phase="holding", entry=p["avg_entry"], qty=abs(p["qty"]), peak_g=0.0, green_since=0.0,
                         msg="holding — watching for a quick gain")
                self._save()
            elif now - j["armed_t"] > 600:
                self.stop(sym, "your order didn't fill in 10 minutes")
            return

        if ph == "entering":
            if has:
                j.update(phase="holding", entry=p["avg_entry"], qty=abs(p["qty"]), peak_g=0.0, green_since=0.0,
                         tries=0, msg="re-entered — watching for a quick gain")
                self._say(j, f"♻ Re-entered {sym} {abs(p['qty']):g} @~{p['avg_entry']:.2f}",
                          alert=("entry", f"♻ Re-entered {sym}", f"{abs(p['qty']):g} @ {p['avg_entry']:.2f} (cycle {j['cycles'] + 1})"))
                self._save()
            elif now - j["sent_t"] > 45:
                if j["tries"] >= 3:
                    j.update(phase="waiting", tries=0, msg="re-entry order didn't fill; waiting for the next pullback")
                    try:
                        e.broker.cancel_symbol_orders(sym)
                    except Exception:
                        pass
                else:
                    self._enter(e, j, sess, bid, ask, retry=True)
            return

        if ph == "exiting":
            if not has:
                gain = (j["exit_px"] - j["entry"]) * d * j["qty"]
                j.update(phase="waiting", cycles=j["cycles"] + 1, day_cycles=j["day_cycles"] + 1,
                         banked=j["banked"] + gain, extreme=mark, turn_since=0.0, tries=0, exit_t=now,
                         msg=f"harvested ~${gain:+,.2f}; re-entering on a pullback or if it keeps running")
                self._say(j, f"♻ HARVESTED {sym} ≈ ${gain:+,.2f} @~{j['exit_px']:.2f} (cycle {j['cycles']}, total ≈ ${j['banked']:+,.2f})",
                          alert=("profit", f"♻ Harvested {sym} ≈ {gain:+,.2f}", f"Cycle {j['cycles']} · will re-enter on a pullback"))
                self._save()
            elif now - j["sent_t"] > 30:
                if j["tries"] >= 4:
                    j.update(phase="holding", tries=0, msg="exit order didn't fill; still holding")
                else:
                    self._exit(e, j, sess, bid, ask, j.get("why", "harvest"), retry=True)
            return

        A, rb, closes = self._metrics(e, sym, mark)

        if ph == "holding":
            if not has:
                return self.stop(sym, "the position was closed")
            j["entry"] = p["avg_entry"]
            if j.pop("now", False):                       # you tapped Harvest now: sell right away, then keep cycling
                j["exit_px"] = mark
                self._say(j, f"♻ Harvest now on {sym}: selling at your request, then re-entering on a pullback")
                self._exit(e, j, sess, bid, ask, "harvest")
                return
            gain = (mark - j["entry"]) * d
            g = gain / A
            # Protective stop on the MID price (not the bid), only after quotes have settled for 3 min in
            # this session, only when the spread is sane, and only if it stays beyond the stop for 25 s
            # (straight away only at 2x the stop). This stops one bad quote from selling you out.
            mid = (bid + ask) / 2
            g_mid = (mid - j["entry"]) * d / A
            wide = (ask - bid) > 0.6 * A
            settling = now - j.get("sess_t", 0) < 180
            if g_mid <= -STOP_A and not wide and not settling:
                j["stop_since"] = j.get("stop_since") or now
            else:
                j["stop_since"] = 0.0
            hard = g_mid <= -2 * STOP_A and not wide and not settling
            if hard or (j.get("stop_since") and now - j["stop_since"] >= 25):
                self._say(j, f"♻ Protective stop on {sym}: down {abs(g):.1f} x its normal range. Closing and stopping.", "warning",
                          alert=("exit", f"♻ Stopped out {sym}", "Auto-harvest ended for this stock"))
                self._exit(e, j, sess, bid, ask, "stop")
                if j["phase"] != "exiting":       # the exit order failed: keep the job so the next pass retries it
                    return
                loss = (mark - j["entry"]) * d * j["qty"]
                j["banked"] += loss               # count the loss too, so the total is the real net
                self._say(j, f"♻ {sym} stop ≈ ${loss:+,.2f}; net for this cycle run ≈ ${j['banked']:+,.2f} over {j['cycles']} harvest(s).")
                with self.lock:
                    self.jobs.pop(sym, None)
                    self._save()
                return
            j["peak_g"] = max(j["peak_g"], g)
            if g >= GREEN_A:
                j["green_since"] = j["green_since"] or now
            elif g <= 0.05:                       # only "un-green" once the gain is really gone (a fade must still count)
                j["green_since"] = 0.0
            green = bool(j["green_since"]) and now - j["green_since"] >= GREEN_SECS
            stalled = green and j["peak_g"] >= 0.28 and g <= j["peak_g"] - STALL_A and g > 0.1
            j["msg"] = f"holding: {g:+.2f} A (harvest at +{TARGET_A}, peak {j['peak_g']:.2f})"
            if j["day_cycles"] >= DAY_CYCLE_CAP:
                return self.stop(sym, "hit the daily safety cap of harvests")
            # A harvest must pay for the round trip: we sell at the bid but buy back at the ask, so the gain per
            # share has to beat the spread (plus a little for slippage) or the cycle loses money.
            cost = max(1.2 * (ask - bid), mark * 0.0003)
            pays = gain >= cost
            if (g >= TARGET_A and pays) or (stalled and gain >= 1.5 * cost):
                j["exit_px"] = mark
                self._exit(e, j, sess, bid, ask, "harvest")
            return

        if ph == "waiting":
            if j.pop("enter_now", False):                 # you tapped Re-enter now
                j["reentry_kind"] = "manual"
                self._say(j, f"♻ Re-enter now on {sym}: buying back at your request")
                self._enter(e, j, sess, bid, ask)
                return
            # track the best price since the harvest
            j["extreme"] = max(j["extreme"], mark) if d > 0 else min(j["extreme"], mark)
            ready = bool(rb and rb.get("ready"))
            state = rb["state"] if ready else 0
            if ready and state * d < 0:
                j["turn_since"] = j["turn_since"] or now
                if now - j["turn_since"] >= TURN_SECS:
                    return self.stop(sym, "the ribbon turned against you")
                j["msg"] = "ribbon against you; waiting"
                return
            j["turn_since"] = 0.0
            pulled = (j["extreme"] - mark) * d >= PULLBACK_A * A
            side_ok = (not ready) or (state * d > 0 and (mark - rb["slow"]) * d > 0)
            turned = bool(closes and len(closes) >= 2 and (closes[-1] - closes[-2]) * d > 0)
            run = (mark - j.get("exit_px", mark)) * d / A            # how far it has kept running past the harvest price
            cont = (run >= CONT_A and run <= 4.0 and side_ok and turned and (now - j.get("exit_t", now)) >= CONT_SECS
                    and (mark - j["extreme"]) * d >= -1e-9)
            j["extreme_prev"] = j["extreme"]
            j["msg"] = (f"waiting: pullback {(j['extreme'] - mark) * d / A:.2f}/{PULLBACK_A} A, or run {run:.2f}/{CONT_A} A past the exit"
                        f"{'' if side_ok else ', ribbon side not ready'}{'' if turned else ', no bounce candle yet'}")
            if j["day_cycles"] < DAY_CYCLE_CAP and side_ok and turned and (pulled or cont):
                j["reentry_kind"] = "pullback" if pulled else "continuation"
                self._enter(e, j, sess, bid, ask)

    # ---------- orders ----------
    def _enter(self, e, j, sess, bid, ask, retry=False):
        j["tries"] = j["tries"] + 1 if retry else 1
        j["sent_t"] = time.time()
        j["phase"] = "entering"
        try:
            if retry:
                e.broker.cancel_symbol_orders(j["symbol"])
            self.open_fn(e, j["symbol"], j["side"], int(j["qty"]), sess, bid, ask, j["tries"])
            j["msg"] = "re-entry order sent"
        except Exception as ex:
            j["phase"] = "waiting"
            j["msg"] = f"re-entry failed: {str(ex)[:80]}"
            self._say(j, f"♻ Re-entry on {j['symbol']} failed: {str(ex)[:120]}", "warning")

    def _exit(self, e, j, sess, bid, ask, why, retry=False):
        j["tries"] = j["tries"] + 1 if retry else 1
        j["sent_t"] = time.time()
        j["phase"] = "exiting"
        j["why"] = why
        try:
            try:                                   # never ask to sell more than is really held (v1.74.1)
                held = abs(float((e.broker.positions().get(j["symbol"]) or {}).get("qty") or 0))
                if held and held < j["qty"]:
                    j["qty"] = held
            except Exception:
                pass
            self.close_fn(e, j["symbol"], int(j["qty"]), j["side"], sess, bid, ask, j["tries"])
            j["msg"] = "harvest order sent" if why == "harvest" else "exit order sent"
        except Exception as ex:
            j["phase"] = "holding"
            j["msg"] = f"exit failed: {str(ex)[:80]}"
            m = re.search(r"available.{0,6}?(\d+(?:\.\d+)?)", str(ex))
            if "insufficient qty" in str(ex) and m:      # sync to what the broker says we can sell
                j["qty"] = float(m.group(1))
            j["fail_n"] = j.get("fail_n", 0) + 1
            if j["fail_n"] <= 3 or j["fail_n"] % 20 == 0:   # no more than a handful of identical warnings
                self._say(j, f"♻ Exit on {j['symbol']} failed: {str(ex)[:220]}", "warning")
