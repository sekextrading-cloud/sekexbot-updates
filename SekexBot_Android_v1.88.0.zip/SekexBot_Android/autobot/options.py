"""Options module (separate from the stock bot, off by default).

Defined-risk only: a VERTICAL DEBIT SPREAD (buy one option, sell a further-out-of-the-money one against it) or a
single LONG call/put. The most that can be lost on a trade is what was paid for it. It never sells naked options,
never holds past the close (unless you change that), and has its OWN daily loss budget. On a LIVE account it stays
locked until you unlock it with your PIN.

Flow each ~15 s (regular hours only):
  1. manage open positions: take profit, stop, trail, signal flip, time exit, end-of-day flatten
  2. when allowed, look for a call/put idea on liquid underlyings (ribbon + VWAP + EMA + momentum + market regime),
     pick expiry and strikes, check liquidity and price, size it to the per-trade and daily budgets, and place a limit order
The stock engine's own signals, regime and ribbons are reused, so both modules agree about the market."""
import json
import logging
import math
import threading
import time
import uuid
from collections import deque
from datetime import date, datetime, timedelta

from . import db
from .config import DATA_DIR, api_keys

log = logging.getLogger("autobot")
STATE_FILE = DATA_DIR / "options_state.json"
MULT = 100
DEFAULT_UNDERLYINGS = ["SPY", "QQQ", "IWM", "AAPL", "NVDA", "TSLA", "AMD", "META", "MSFT", "AMZN"]


# ---------------------------------------------------------------- pure logic (unit-tested)
def signal(df, ribbon, regime, bias, is_index=False):
    """'call' / 'put' / None plus a reason, from enriched 1-min bars of the underlying."""
    try:
        if df is None or len(df) < 20 or not ribbon or not ribbon.get("ready"):
            return None, "not enough data yet"
        d = df[df.index.date == df.index[-1].date()]
        if len(d) < 16:
            return None, "not enough bars today"
        l = d.iloc[-1]
        close, vwap, ema, atr = float(l["close"]), float(l["vwap"]), float(l["ema21"]), float(l["atr"])
        if atr <= 0 or close <= 0:
            return None, "no volatility reading"
        mom = (close / float(d["close"].iloc[-15]) - 1) * 100
        stretch = abs(close - ema) / atr
        name = (regime or {}).get("name", "NORMAL")
        st = ribbon.get("state", 0)
        if name in ("CHOP", "QUIET"):
            return None, f"market is {name.lower()} — options lose to time decay here"
        if stretch > 2.5:
            return None, "price is stretched far from its average — not chasing"
        if st > 0 and close > vwap and close > ema and mom >= 0.15 and (bias >= 0 or is_index) and name != "TREND_DOWN":
            return "call", f"ribbon up, above VWAP/EMA, +{mom:.2f}% in 15 min, regime {name}"
        if st < 0 and close < vwap and close < ema and mom <= -0.15 and (bias <= 0 or is_index) and name != "TREND_UP":
            return "put", f"ribbon down, below VWAP/EMA, {mom:.2f}% in 15 min, regime {name}"
        return None, "no clean setup"
    except Exception as e:                       # never let a data glitch trade
        return None, f"signal error: {e}"


def _spread_ok(bid, ask):
    if bid is None or ask is None or bid <= 0 or ask <= 0 or ask < bid:
        return False
    mid = (bid + ask) / 2
    return (ask - bid) <= max(0.10, 0.12 * mid)


def build_plan(direction, price, contracts, quotes, cfg, today):
    """contracts: [{symbol, strike, expiry(date), oi}] of ONE type (call or put) near the money.
    quotes: {symbol: (bid, ask)}. Returns (plan dict, '') or (None, reason)."""
    if not contracts:
        return None, "no option contracts listed"
    call = direction == "call"
    exps = sorted({c["expiry"] for c in contracts if (c["expiry"] - today).days >= cfg["min_dte"]})
    if not exps:
        return None, "no expiry far enough out"
    why = "nothing passed the price / liquidity checks"
    for exp in exps[:2]:
        ch = sorted([c for c in contracts if c["expiry"] == exp], key=lambda c: c["strike"])
        if len(ch) < 2:
            continue
        # long leg: nearest strike at/in the money
        if call:
            cand = [c for c in ch if c["strike"] <= price]
            li = ch.index(cand[-1]) if cand else 0
        else:
            cand = [c for c in ch if c["strike"] >= price]
            li = ch.index(cand[0]) if cand else len(ch) - 1
        lc = ch[li]
        lq = quotes.get(lc["symbol"])
        if not lq or not _spread_ok(*lq) or lc["oi"] < cfg["min_oi"]:
            why = "the main option is too thinly traded or too wide"
            continue
        dte = (exp - today).days
        if cfg["style"] == "long":
            debit_mid = (lq[0] + lq[1]) / 2
            limit = round(min(lq[1], debit_mid + 0.3 * (lq[1] - debit_mid)), 2)
            plan = _size({"style": "long", "direction": direction, "long": lc["symbol"], "short": "", "expiry": exp,
                          "strikes": f"{lc['strike']:g}", "limit": limit, "mid": debit_mid, "max_value": None, "dte": dte}, cfg)
            if plan[0]:
                return plan
            why = plan[1]
            continue
        for k in (1, 2, 3):
            si = li + k if call else li - k
            if si < 0 or si >= len(ch):
                continue
            sc = ch[si]
            sq = quotes.get(sc["symbol"])
            if not sq or not _spread_ok(*sq) or sc["oi"] < max(10, cfg["min_oi"] // 4):
                continue
            width = abs(sc["strike"] - lc["strike"])
            net_bid, net_ask = lq[0] - sq[1], lq[1] - sq[0]
            if net_ask <= 0.05 or net_bid <= 0:
                continue
            mid = (net_bid + net_ask) / 2
            limit = round(min(net_ask, mid + 0.3 * (net_ask - mid)), 2)
            if limit < 0.20 or limit > 0.62 * width:         # reward must be at least ~0.6x what is risked
                why = "the spread costs too much for the reward"
                continue
            plan = _size({"style": "spread", "direction": direction, "long": lc["symbol"], "short": sc["symbol"],
                          "expiry": exp, "strikes": f"{lc['strike']:g}/{sc['strike']:g}", "limit": limit, "mid": mid,
                          "max_value": width, "dte": dte}, cfg)
            if plan[0]:
                return plan
            why = plan[1]
    return None, why


def _size(plan, cfg):
    per = plan["limit"] * MULT
    if per <= 0:
        return None, "bad price"
    stop_loss_per = per * cfg["stop_pct"] / 100.0
    qty = int(min(cfg["max_premium"] // per, cfg["max_contracts"], cfg["room"] // stop_loss_per if stop_loss_per > 0 else 0))
    if qty < 1:
        if per > cfg["max_premium"]:
            return None, f"one contract costs ${per:,.0f}, over your ${cfg['max_premium']:,.0f} per-trade limit"
        return None, "not enough of today's options budget left for this trade"
    plan = dict(plan, qty=qty, cost=round(qty * per, 2), risk_at_stop=round(qty * stop_loss_per, 2))
    return plan, ""


def exit_decision(pos, value, now_min, cfg, flip=False):
    """value = current price of one spread/contract. Returns reason string to exit, or ''."""
    entry = pos["debit"]
    if entry <= 0:
        return ""
    pct = (value / entry - 1) * 100
    pos["peak_pct"] = max(pos.get("peak_pct", pct), pct)
    if now_min >= cfg["flatten_min"] and not cfg.get("hold_overnight"):
        return "end-of-day flatten"
    if pos.get("dte_left", 99) <= 0 and now_min >= 15 * 60 + 30:
        return "expiring today"
    if pct >= cfg["tp_pct"]:
        return f"profit target {pct:+.0f}%"
    if pct <= -cfg["stop_pct"]:
        return f"stop {pct:+.0f}%"
    if pos["peak_pct"] >= 0.6 * cfg["tp_pct"] and pct <= pos["peak_pct"] - 0.4 * cfg["tp_pct"]:
        return f"trailing: gave back from {pos['peak_pct']:+.0f}% to {pct:+.0f}%"
    if flip and pct < 5:
        return f"the trend turned against it ({pct:+.0f}%)"
    return ""


# ---------------------------------------------------------------- the bot
class OptionsBot:
    def __init__(self, get_engine, settings):
        self.get_engine, self.s = get_engine, settings
        self.lock = threading.RLock()
        self.pos = {}                        # id -> position dict
        self.cool = {}                       # underlying -> epoch until
        self.confirm = {}
        self.events = deque(maxlen=60)
        self.state = "off"
        self.day = ""
        self.halted = ""
        self.level = None
        self._level_at = 0
        self._data = None
        self._last_recon = 0
        self.kill = False
        self.style_override = ""
        self.greeks = {}                     # option symbol -> {delta, gamma, theta, vega, rho, iv} from the latest snapshot
        self._load()
        threading.Thread(target=self._run, daemon=True, name="options").start()

    # ---- bookkeeping
    def ev(self, msg, level="info"):
        self.events.appendleft({"t": datetime.now().strftime("%H:%M:%S"), "level": level, "msg": msg})
        log.log(logging.WARNING if level == "warning" else logging.INFO, "Options: %s", msg)
        e = self.get_engine()
        try:
            if e:
                e.event("Options: " + msg, level if level in ("warning", "info") else "info")
        except Exception:
            pass

    def _save(self):
        try:
            with self.lock:
                STATE_FILE.write_text(json.dumps({"day": self.day, "halted": self.halted, "cool": self.cool,
                                                  "pos": {k: v for k, v in self.pos.items() if v["status"] != "closed"}}, default=str))
        except Exception as ex:
            log.warning("options state save: %s", ex)

    def _load(self):
        try:
            st = json.loads(STATE_FILE.read_text())
            self.day, self.halted = st.get("day", ""), st.get("halted", "")
            self.cool = {k: float(v) for k, v in (st.get("cool") or {}).items()}
            self.pos = st.get("pos") or {}
        except Exception:
            pass

    def cfg(self, room=0.0):
        s = self.s
        return {"min_dte": int(s.options_min_dte), "min_oi": int(s.options_min_oi),
                "style": self.style_override or s.options_style, "max_premium": float(s.options_max_premium), "max_contracts": int(s.options_max_contracts),
                "stop_pct": float(s.options_stop_pct), "tp_pct": float(s.options_tp_pct), "room": room,
                "flatten_min": 16 * 60 - int(s.options_flatten_min), "hold_overnight": False}

    # ---- broker access
    def _clients(self, e):
        if self._data is None or self._data[0] is not e.broker:
            from alpaca.data.historical.option import OptionHistoricalDataClient
            k, sec = api_keys(e.mode == "LIVE")
            self._data = (e.broker, OptionHistoricalDataClient(k, sec))
        return e.broker.trading, self._data[1]

    def _quotes(self, e, syms):
        from alpaca.data.requests import OptionSnapshotRequest
        _, dc = self._clients(e)
        out = {}
        if not syms:
            return out
        snaps = dc.get_option_snapshot(OptionSnapshotRequest(symbol_or_symbols=list(syms)))
        for sym, sn in (snaps or {}).items():
            q = getattr(sn, "latest_quote", None)
            if q and q.bid_price is not None and q.ask_price is not None:
                out[sym] = (float(q.bid_price), float(q.ask_price))
            g = getattr(sn, "greeks", None)
            iv = getattr(sn, "implied_volatility", None)
            if g is not None or iv is not None:
                f = lambda x: None if x is None else float(x)
                self.greeks[sym] = {"delta": f(getattr(g, "delta", None)), "gamma": f(getattr(g, "gamma", None)), "theta": f(getattr(g, "theta", None)),
                                    "vega": f(getattr(g, "vega", None)), "rho": f(getattr(g, "rho", None)), "iv": f(iv)}
        return out

    def net_greeks(self, long_sym, short_sym=""):
        """Greeks of the whole trade per share: long leg minus short leg (a spread). None if the data feed gave none."""
        gl = self.greeks.get(long_sym)
        if not gl:
            return None
        gs = self.greeks.get(short_sym) if short_sym else None
        if short_sym and not gs:
            return None
        out = {}
        for k in ("delta", "gamma", "theta", "vega", "rho"):
            a = gl.get(k)
            b = (gs or {}).get(k) if short_sym else 0.0
            out[k] = None if (a is None or b is None) else round(a - b, 5)
        out["iv"] = gl.get("iv")
        return out

    def _account_level(self, e):
        if time.time() - self._level_at < 300 and self.level is not None:
            return self.level
        a = e.broker.trading.get_account()
        lv = getattr(a, "options_trading_level", None) or getattr(a, "options_approved_level", None) or 0
        self.level, self._level_at = int(lv or 0), time.time()
        return self.level

    def held(self, e):
        out = {}
        for p in e.broker.trading.get_all_positions():
            if "option" in str(getattr(p, "asset_class", "")).lower():
                out[p.symbol] = {"qty": float(p.qty), "price": float(p.current_price or 0), "upl": float(p.unrealized_pl or 0)}
        return out

    # ---- the loop
    def _run(self):
        while True:
            time.sleep(15)
            try:
                self._tick()
            except Exception as ex:
                log.warning("Options tick failed: %s", ex)
                self.state = f"error: {str(ex)[:80]}"

    def _tick(self):
        e = self.get_engine()
        if not e or e.mode == "SIM":
            self.state = "off (no live or paper account)" if not e else "off (simulator)"
            return
        s = self.s
        now = e.broker.now()
        today = e.day or now.date().isoformat()
        if today != self.day:
            self.day, self.halted = today, ""
            self.confirm.clear()
            self._save()
        with self.lock:
            open_n = len([p for p in self.pos.values() if p["status"] != "closed"])
        if not open_n:
            self.kill = False
        if not s.options_on and not open_n:
            self.state = "off"
            return
        from .sessions import current_session
        try:
            _s = current_session(e.broker.trading_day, now)
            sess = _s.name if _s else "CLOSED"
        except Exception:
            sess = "CLOSED"
        regular = (sess == "REGULAR")
        if not regular:
            self.state = "waiting — options trade in regular hours only" if s.options_on else f"off ({open_n} open)"
            return
        if time.time() - self._last_recon > 60:
            self._reconcile(e)
        self._manage(e, now)
        if not s.options_on:
            self.state = f"off — managing {open_n} open position(s) to exit"
            return
        self._entries(e, now)

    # ---- reconcile with the broker
    def _reconcile(self, e):
        self._last_recon = time.time()
        try:
            held = self.held(e)
        except Exception:
            return
        with self.lock:
            for p in list(self.pos.values()):
                if p["status"] == "open" and p["long"] not in held:
                    self._finish(e, p, p.get("last_value", p["debit"]), "position no longer at the broker")

    # ---- manage open positions
    def _manage(self, e, now):
        with self.lock:
            live = [p for p in self.pos.values() if p["status"] in ("entering", "open", "exiting")]
        if not live:
            return
        tr = e.broker.trading
        syms = {p["long"] for p in live} | {p["short"] for p in live if p["short"]}
        try:
            q = self._quotes(e, syms)
        except Exception as ex:
            self.ev(f"could not read option quotes: {str(ex)[:80]}", "warning")
            return
        nowmin = now.hour * 60 + now.minute
        for p in live:
            try:
                if p["status"] == "entering":
                    self._check_entry(e, p)
                    continue
                lq, sq = q.get(p["long"]), (q.get(p["short"]) if p["short"] else (0, 0))
                if not lq or sq is None:
                    continue
                val_mid = (lq[0] + lq[1]) / 2 - ((sq[0] + sq[1]) / 2 if p["short"] else 0)
                val_bid = lq[0] - (sq[1] if p["short"] else 0)
                p["last_value"], p["last_bid"] = round(val_mid, 3), round(val_bid, 3)
                ng = self.net_greeks(p["long"], p["short"])
                if ng:
                    p["greeks"] = ng
                if p["status"] == "exiting":
                    self._check_exit(e, p, lq, sq)
                    continue
                p["dte_left"] = (date.fromisoformat(str(p["expiry"])[:10]) - now.date()).days
                flip = self._flipped(e, p)
                why = "manual: close all" if self.kill else exit_decision(p, val_mid, nowmin, self.cfg(), flip)
                if not why and self._realized(e) - self._open_loss() <= -float(self.s.options_daily_budget):
                    why = "daily options budget used up"
                if why:
                    self._send_exit(e, p, lq, sq, why)
            except Exception as ex:
                self.ev(f"managing {p.get('underlying')}: {str(ex)[:100]}", "warning")
        self._save()

    def _flipped(self, e, p):
        rb = (getattr(e, "ribbons", None) or {}).get(p["underlying"])
        if not rb or not rb.get("ready"):
            return False
        against = (rb["state"] < 0) if p["direction"] == "call" else (rb["state"] > 0)
        p["flip_n"] = p.get("flip_n", 0) + 1 if against else 0
        return p["flip_n"] >= 3

    def _check_entry(self, e, p):
        tr = e.broker.trading
        try:
            o = tr.get_order_by_id(p["order_id"])
        except Exception:
            return
        st = str(getattr(o.status, "value", o.status)).lower()
        filled = float(getattr(o, "filled_qty", 0) or 0)
        if st == "filled" or (filled >= p["qty"]):
            px = float(getattr(o, "filled_avg_price", 0) or p["limit"])
            p.update(status="open", debit=abs(px), qty=int(filled or p["qty"]), opened_fill=time.time())
            self.ev(f"FILLED {p['underlying']} {p['direction'].upper()} {p['strikes']} x{p['qty']} @ ${abs(px):.2f} debit")
            e.alert("fill", f"Options filled: {p['underlying']} {p['direction']}", f"{p['strikes']} x{p['qty']} @ ${abs(px):.2f}", symbol=p["underlying"])
        elif st in ("canceled", "cancelled", "rejected", "expired"):
            if filled >= 1:
                p.update(status="open", qty=int(filled), debit=abs(float(getattr(o, "filled_avg_price", 0) or p["limit"])))
            else:
                self._drop(p, f"entry {st}")
        elif time.time() - p["sent_at"] > int(self.s.options_fill_wait_s):
            try:
                tr.cancel_order_by_id(p["order_id"])
            except Exception:
                pass
            if filled >= 1:
                p.update(status="open", qty=int(filled), debit=abs(float(getattr(o, "filled_avg_price", 0) or p["limit"])))
            else:
                self._drop(p, "entry not filled in time — cancelled")

    def _drop(self, p, why):
        p["status"] = "closed"
        self.cool[p["underlying"]] = time.time() + 900
        self.ev(f"{p['underlying']}: {why}")
        db.opt_upsert(self._row(p, status="cancelled", reason=why))

    def _send_exit(self, e, p, lq, sq, why):
        from alpaca.trading.enums import OrderClass, OrderSide, PositionIntent, TimeInForce
        from alpaca.trading.requests import LimitOrderRequest, OptionLegRequest
        tr = e.broker.trading
        tries = p.get("exit_tries", 0)
        if p["short"]:
            net_bid, net_ask = lq[0] - sq[1], lq[1] - sq[0]
        else:
            net_bid, net_ask = lq[0], lq[1]
        mid = (net_bid + net_ask) / 2
        aggr = [0.0, 0.5, 1.0, 1.0][min(tries, 3)]
        px = mid - aggr * (mid - net_bid) - (0.05 * max(mid, 0.2) if tries >= 3 else 0)
        px = max(round(px, 2), 0.01)
        try:
            if p["short"]:
                req = LimitOrderRequest(qty=p["qty"], order_class=OrderClass.MLEG, time_in_force=TimeInForce.DAY,
                                        limit_price=-px, legs=[
                    OptionLegRequest(symbol=p["long"], ratio_qty=1, side=OrderSide.SELL, position_intent=PositionIntent.SELL_TO_CLOSE),
                    OptionLegRequest(symbol=p["short"], ratio_qty=1, side=OrderSide.BUY, position_intent=PositionIntent.BUY_TO_CLOSE)])
            else:
                req = LimitOrderRequest(symbol=p["long"], qty=p["qty"], side=OrderSide.SELL, time_in_force=TimeInForce.DAY,
                                        limit_price=px, position_intent=PositionIntent.SELL_TO_CLOSE)
            o = tr.submit_order(req)
            p.update(status="exiting", close_order_id=str(o.id), exit_sent=time.time(), exit_reason=why, exit_px=px)
            if tries == 0:
                self.ev(f"EXIT {p['underlying']} {p['direction'].upper()} {p['strikes']}: {why} (limit ${px:.2f})")
        except Exception as ex:
            self.ev(f"exit order for {p['underlying']} rejected: {str(ex)[:140]}", "warning")
            p["exit_tries"] = tries + 1
            if p["short"] and p["exit_tries"] >= 2:
                self._legs_exit(e, p, lq, sq, why)

    def _legs_exit(self, e, p, lq, sq, why):
        """Fallback if the broker refuses the one-ticket spread exit: buy back the short leg first (so nothing is ever
        naked), then sell the long leg."""
        from alpaca.trading.enums import OrderSide, PositionIntent, TimeInForce
        from alpaca.trading.requests import LimitOrderRequest
        tr = e.broker.trading
        try:
            o = tr.submit_order(LimitOrderRequest(symbol=p["short"], qty=p["qty"], side=OrderSide.BUY, time_in_force=TimeInForce.DAY,
                                                  limit_price=round(sq[1], 2), position_intent=PositionIntent.BUY_TO_CLOSE))
            p.update(status="exiting", close_order_id=str(o.id), exit_sent=time.time(), exit_reason=why, leg_stage="short", exit_px=sq[1])
            self.ev(f"closing {p['underlying']} leg by leg (short first)", "warning")
        except Exception as ex:
            self.ev(f"could not close {p['underlying']} spread leg: {str(ex)[:120]}", "warning")

    def _check_exit(self, e, p, lq, sq):
        tr = e.broker.trading
        try:
            o = tr.get_order_by_id(p["close_order_id"])
        except Exception:
            return
        st = str(getattr(o.status, "value", o.status)).lower()
        if st == "filled":
            if p.get("leg_stage") == "short":
                from alpaca.trading.enums import OrderSide, PositionIntent, TimeInForce
                from alpaca.trading.requests import LimitOrderRequest
                p["short_cover"] = abs(float(o.filled_avg_price or 0))
                o2 = tr.submit_order(LimitOrderRequest(symbol=p["long"], qty=p["qty"], side=OrderSide.SELL, time_in_force=TimeInForce.DAY,
                                                       limit_price=round(max(lq[0], 0.01), 2), position_intent=PositionIntent.SELL_TO_CLOSE))
                p.update(close_order_id=str(o2.id), leg_stage="long", exit_sent=time.time())
                return
            val = abs(float(o.filled_avg_price or p.get("exit_px") or 0))
            if p.get("leg_stage") == "long":
                val = abs(float(o.filled_avg_price or 0)) - p.get("short_cover", 0)
            self._finish(e, p, val, p.get("exit_reason", "exit"))
        elif st in ("canceled", "cancelled", "rejected", "expired"):
            p.update(status="open", exit_tries=p.get("exit_tries", 0) + 1)
        elif time.time() - p.get("exit_sent", 0) > 20:
            try:
                tr.cancel_order_by_id(p["close_order_id"])
            except Exception:
                pass
            p.update(status="open", exit_tries=p.get("exit_tries", 0) + 1)

    def _finish(self, e, p, exit_val, why):
        pnl = (exit_val - p["debit"]) * p["qty"] * MULT
        p.update(status="closed", exit=round(exit_val, 3), pnl=round(pnl, 2), reason=why, closed_at=datetime.now().isoformat())
        self.cool[p["underlying"]] = time.time() + 1200
        db.opt_upsert(self._row(p, status="closed", reason=why))
        self.ev(f"CLOSED {p['underlying']} {p['direction'].upper()} {p['strikes']} x{p['qty']}: {why} — P&L ${pnl:+,.2f}",
                "warning" if pnl < 0 else "info")
        e.alert("exit" if pnl < 0 else "profit", f"Options {'+' if pnl >= 0 else ''}${pnl:,.2f}: {p['underlying']}", why, symbol=p["underlying"])
        self._save()

    def _row(self, p, **kw):
        d = {"id": p["id"], "day": self.day, "mode": (self.get_engine().mode if self.get_engine() else ""), "underlying": p["underlying"],
             "direction": p["direction"], "style": p["style"], "long_sym": p["long"], "short_sym": p["short"], "qty": p["qty"],
             "expiry": str(p["expiry"])[:10], "strikes": p["strikes"], "entry": p.get("debit"), "exit": p.get("exit"),
             "pnl": p.get("pnl"), "opened_at": p["opened_at"], "closed_at": p.get("closed_at"), "regime": p.get("regime", ""),
             "why": p.get("why", "")}
        d.update(kw)
        return d

    # ---- entries
    def _realized(self, e):
        try:
            return db.opt_today_pnl(self.day, e.mode)
        except Exception:
            return 0.0

    def _open_loss(self, exclude=None):
        with self.lock:
            return sum(max(0.0, (p["debit"] - p.get("last_value", p["debit"])) * p["qty"] * MULT)
                       for p in self.pos.values() if p["status"] in ("open", "exiting"))

    def _room(self, e):
        used = max(0.0, -self._realized(e)) + self._open_loss()
        with self.lock:
            reserved = sum(p.get("risk_at_stop", 0) for p in self.pos.values() if p["status"] in ("entering", "open", "exiting"))
        return float(self.s.options_daily_budget) - used - reserved

    def _entries(self, e, now):
        s = self.s
        if e.mode == "LIVE" and not s.options_live_unlocked:
            self.state = "LIVE locked — unlock options for Live with your PIN"
            return
        try:
            lv = self._account_level(e)
        except Exception as ex:
            self.state = f"cannot read account: {str(ex)[:60]}"
            return
        if lv < 2:
            self.state = f"your Alpaca account is not approved for options (level {lv}). Request options trading in Alpaca."
            return
        if self.halted:
            self.state = "halted: " + self.halted
            return
        room = self._room(e)
        if room <= 0:
            self.halted = "daily options budget used up"
            self.ev("daily options budget used — no new options trades today", "warning")
            self.state = "halted: " + self.halted
            return
        with self.lock:
            active = [p for p in self.pos.values() if p["status"] in ("entering", "open", "exiting")]
        nowmin = now.hour * 60 + now.minute
        if nowmin < 9 * 60 + 45 or nowmin > 15 * 60 + 30:
            self.state = "on — waiting for 9:45 AM–3:30 PM entry window"
            return
        if len(active) >= int(s.options_max_positions):
            self.state = f"on — {len(active)} open (max {s.options_max_positions})"
            return
        n_calls = sum(1 for p in active if p["direction"] == "call")
        n_puts = len(active) - n_calls
        stocks_open = {p["underlying"] for p in active}
        if len(stocks_open) >= int(getattr(s, "options_max_stocks", 6)) and len(active) > 0:
            self.state = f"on — {len(stocks_open)} stock(s) open (max {s.options_max_stocks} stocks)"
            return
        if lv < 3 and s.options_style == "spread" and self.style_override != "long":
            self.style_override = "long"
            self.ev("account is options level 2: using long calls/puts (spreads need level 3)", "warning")
        bars = getattr(e, "bars_last", None) or {}
        regime, bias = getattr(e, "regime", {}), getattr(e, "bias", 0)
        per = {}
        for p in active:
            per[p["underlying"]] = per.get(p["underlying"], 0) + 1
        max_per = max(1, int(getattr(s, "options_max_per_stock", 1)))
        watching = 0
        for u in [x.upper() for x in (s.options_underlyings or DEFAULT_UNDERLYINGS)]:
            if per.get(u, 0) >= max_per or time.time() < self.cool.get(u, 0):
                continue
            if per.get(u, 0) == 0 and len(stocks_open) >= int(getattr(s, "options_max_stocks", 6)):
                continue
            direction, why = signal(bars.get(u), (getattr(e, "ribbons", None) or {}).get(u), regime, bias, is_index=u in ("SPY", "QQQ", "IWM"))
            key = (u, direction)
            if not direction:
                self.confirm.pop((u, "call"), None)
                self.confirm.pop((u, "put"), None)
                continue
            if (direction == "call" and n_calls >= int(getattr(s, "options_max_calls", 6))) or \
               (direction == "put" and n_puts >= int(getattr(s, "options_max_puts", 6))):
                continue
            watching += 1
            self.confirm[key] = self.confirm.get(key, 0) + 1
            if self.confirm[key] < 2:
                continue
            if self._open(e, u, direction, why, float(bars[u]["close"].iloc[-1]), room, regime):
                break
        self.state = f"on — scanning {len(s.options_underlyings or DEFAULT_UNDERLYINGS)} stocks, {watching} idea(s), budget left ${room:,.0f}"

    def _open(self, e, u, direction, why, price, room, regime):
        from alpaca.trading.enums import AssetStatus, ContractType, OrderClass, OrderSide, PositionIntent, TimeInForce
        from alpaca.trading.requests import GetOptionContractsRequest, LimitOrderRequest, OptionLegRequest
        tr = e.broker.trading
        today = e.broker.now().date()
        cfg = self.cfg(room)
        try:
            res = tr.get_option_contracts(GetOptionContractsRequest(
                underlying_symbols=[u], status=AssetStatus.ACTIVE, type=ContractType.CALL if direction == "call" else ContractType.PUT,
                expiration_date_gte=today + timedelta(days=cfg["min_dte"]), expiration_date_lte=today + timedelta(days=int(self.s.options_max_dte)),
                strike_price_gte=str(round(price * 0.94, 2)), strike_price_lte=str(round(price * 1.06, 2)), limit=1000))
            rows = []
            for c in (getattr(res, "option_contracts", None) or []):
                if not getattr(c, "tradable", True):
                    continue
                rows.append({"symbol": c.symbol, "strike": float(c.strike_price), "expiry": c.expiration_date,
                             "oi": int(float(getattr(c, "open_interest", 0) or 0))})
            if not rows:
                self.cool[u] = time.time() + 600
                return False
            exps = sorted({r["expiry"] for r in rows})[:2]
            pick = [r for r in rows if r["expiry"] in exps]
            near = sorted(pick, key=lambda r: abs(r["strike"] - price))[:14]
            quotes = self._quotes(e, [r["symbol"] for r in near])
            near = [r for r in near if r["symbol"] in quotes]
            plan, reason = build_plan(direction, price, near, quotes, cfg, today)
        except Exception as ex:
            self.ev(f"{u}: could not look up options ({str(ex)[:100]})", "warning")
            self.cool[u] = time.time() + 600
            return False
        if not plan:
            self.ev(f"{u} {direction}: skipped — {reason}")
            self.cool[u] = time.time() + 600
            return False
        g0 = self.net_greeks(plan["long"], plan["short"])
        gl = self.greeks.get(plan["long"]) or {}
        md = float(getattr(self.s, "options_min_delta", 0) or 0)
        if md > 0 and gl.get("delta") is not None and abs(gl["delta"]) < md:
            self.ev(f"{u} {direction}: skipped — the main option's delta is {gl['delta']:.2f}, under your minimum {md:.2f}")
            self.cool[u] = time.time() + 600
            return False
        try:
            if plan["style"] == "spread":
                req = LimitOrderRequest(qty=plan["qty"], order_class=OrderClass.MLEG, time_in_force=TimeInForce.DAY, limit_price=plan["limit"], legs=[
                    OptionLegRequest(symbol=plan["long"], ratio_qty=1, side=OrderSide.BUY, position_intent=PositionIntent.BUY_TO_OPEN),
                    OptionLegRequest(symbol=plan["short"], ratio_qty=1, side=OrderSide.SELL, position_intent=PositionIntent.SELL_TO_OPEN)])
            else:
                req = LimitOrderRequest(symbol=plan["long"], qty=plan["qty"], side=OrderSide.BUY, time_in_force=TimeInForce.DAY,
                                        limit_price=plan["limit"], position_intent=PositionIntent.BUY_TO_OPEN)
            o = tr.submit_order(req)
        except Exception as ex:
            self.ev(f"{u}: Alpaca rejected the options order: {str(ex)[:150]}", "warning")
            self.cool[u] = time.time() + 1800
            return False
        pid = "op-" + uuid.uuid4().hex[:10]
        p = {"id": pid, "underlying": u, "direction": direction, "style": plan["style"], "long": plan["long"], "short": plan["short"],
             "qty": plan["qty"], "expiry": str(plan["expiry"]), "strikes": plan["strikes"], "limit": plan["limit"], "debit": plan["limit"],
             "risk_at_stop": plan["risk_at_stop"], "status": "entering", "order_id": str(o.id), "sent_at": time.time(),
             "opened_at": datetime.now().isoformat(), "regime": (regime or {}).get("name", ""), "why": why, "peak_pct": 0.0,
             "g0": g0, "greeks": g0, "mode": e.mode}
        with self.lock:
            self.pos[pid] = p
        db.opt_upsert(self._row(p, status="pending"))
        self.ev(f"ENTRY {u} {direction.upper()} {plan['strikes']} exp {plan['expiry']} x{plan['qty']} limit ${plan['limit']:.2f} "
                f"(cost ${plan['cost']:,.0f}, risk at stop ${plan['risk_at_stop']:,.0f})" + (f" Δ{g0['delta']:+.2f} Θ{g0['theta']:+.2f}" if g0 and g0.get("delta") is not None and g0.get("theta") is not None else "") + f" — {why}")
        e.alert("entry", f"Options: {u} {direction}", f"{plan['strikes']} x{plan['qty']} @ ${plan['limit']:.2f}", symbol=u)
        self._save()
        return True

    # ---- controls
    def close_all(self):
        self.kill = True
        self.ev("manual: closing all options positions", "warning")

    def _pos_greeks(self, p):
        """Net greeks per share plus the whole position in dollars: delta in share-equivalents, theta in $ per day, vega in $ per vol point."""
        g = p.get("greeks")
        if not g:
            return None
        q = float(p.get("qty") or 0) * MULT
        tot = lambda k: None if g.get(k) is None else round(g[k] * q, 2)
        return dict(g, pos_delta=tot("delta"), pos_theta=tot("theta"), pos_vega=tot("vega"))

    def status(self):
        e = self.get_engine()
        with self.lock:
            rows = [dict(p) for p in self.pos.values() if p["status"] != "closed"]
        out = []
        for p in rows:
            v = p.get("last_value")
            pct = ((v / p["debit"] - 1) * 100) if (v is not None and p.get("debit")) else None
            out.append({"id": p["id"], "underlying": p["underlying"], "direction": p["direction"], "style": p["style"],
                        "strikes": p["strikes"], "expiry": str(p["expiry"])[:10], "qty": p["qty"], "debit": p.get("debit"),
                        "value": v, "pnl_pct": None if pct is None else round(pct, 1),
                        "pnl": None if v is None else round((v - p["debit"]) * p["qty"] * MULT, 2), "status": p["status"],
                        "why": p.get("why", ""), "greeks": self._pos_greeks(p), "g0": p.get("g0"),
                        "mode": p.get("mode") or (e.mode if e else "")})
        try:
            realized = self._realized(e) if e else 0.0
            recent = db.opt_recent(15)
            room = self._room(e) if e else 0.0
        except Exception:
            realized, recent, room = 0.0, [], 0.0
        return {"on": bool(self.s.options_on), "state": self.state, "mode": e.mode if e else "-", "level": self.level,
                "live_unlocked": bool(self.s.options_live_unlocked), "halted": self.halted, "positions": out,
                "realized_today": round(realized, 2), "budget": float(self.s.options_daily_budget), "room": round(room, 2),
                "events": list(self.events)[:25], "recent": recent}
