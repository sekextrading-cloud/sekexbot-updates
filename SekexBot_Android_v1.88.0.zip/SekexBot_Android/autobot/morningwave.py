"""Morning Wave watchlist (v1.85): conditional up / down setups for the next morning, built from the latest
regular-session 15-minute bars of tracked stocks and ETFs. Display only: it never places an order.

Each setup is a pattern in how the last regular session CLOSED (strong close, weak close, down-day bounce).
The hit rate is how often the same pattern, over the lookback, was followed by a >= MOVE_PCT excursion
(high for up watches, low for down watches) in the next morning (4:00 AM - 11:00 AM ET), measured from that close.
It counts a price excursion, not a profitable trade."""
from datetime import time
from zoneinfo import ZoneInfo

import pandas as pd

NY = ZoneInfo("America/New_York")
MOVE_PCT = 0.4
MIN_N = 8
MIN_SCORE = 55
NAMES = {"CLOSE_HIGH": "CLOSE HIGH CONTINUATION", "WEAK_CLOSE": "WEAK CLOSE CONTINUATION", "BOUNCE": "OVERNIGHT BOUNCE"}
SIDE = {"CLOSE_HIGH": "up", "WEAK_CLOSE": "down", "BOUNCE": "up"}


def _days(d: pd.DataFrame):
    """[{date, o, h, l, c, bar_ts, nxt_hi, nxt_lo}] from 15-minute bars (extended hours allowed)."""
    d = d.sort_index()
    d.index = pd.to_datetime(d.index).tz_convert(NY)
    t = d.index.time
    reg = d[(t >= time(9, 30)) & (t < time(16, 0))]
    out = []
    for day, g in reg.groupby(reg.index.date):
        if len(g) < 20:                       # half days and thin days are skipped
            continue
        out.append({"date": day, "o": float(g["open"].iloc[0]), "h": float(g["high"].max()), "l": float(g["low"].min()),
                    "c": float(g["close"].iloc[-1]), "bar_ts": g.index[-1], "hi": None, "lo": None})
    by_date = {r["date"]: r for r in out}
    dates = [r["date"] for r in out]
    for i in range(len(dates) - 1):
        nd = dates[i + 1]
        m = d[(d.index.date == nd) & (d.index.time >= time(4, 0)) & (d.index.time < time(11, 0))]
        if len(m):
            by_date[dates[i]]["hi"], by_date[dates[i]]["lo"] = float(m["high"].max()), float(m["low"].min())
    return out


def _classify(prev_c, r):
    rng = r["h"] - r["l"]
    if rng <= 0 or not prev_c:
        return None, 0.0
    pos = (r["c"] - r["l"]) / rng
    chg = r["c"] / prev_c - 1
    if pos >= 0.80 and chg > 0:
        return "CLOSE_HIGH", pos
    if pos <= 0.20 and chg < 0:
        return "WEAK_CLOSE", 1 - pos
    if chg < 0 and 0.20 < pos <= 0.50:
        return "BOUNCE", 1 - pos
    return None, pos


def analyze(sym: str, d: pd.DataFrame, move_pct: float = MOVE_PCT):
    """One setup for the symbol, or None."""
    days = _days(d)
    if len(days) < 12:
        return None
    feats = []
    for i in range(1, len(days)):
        k, strength = _classify(days[i - 1]["c"], days[i])
        feats.append((i, k, strength))
    li, kind, strength = feats[-1]
    if not kind:
        return None
    side = SIDE[kind]
    n = hit = 0
    for i, k, _ in feats[:-1]:
        if k != kind or days[i]["hi"] is None:
            continue
        c = days[i]["c"]
        n += 1
        if side == "up" and days[i]["hi"] / c - 1 >= move_pct / 100:
            hit += 1
        if side == "down" and 1 - days[i]["lo"] / c >= move_pct / 100:
            hit += 1
    if n < MIN_N:
        return None
    rate = hit / n
    score = round(100 * (0.55 * rate + 0.25 * min(n, 20) / 20 + 0.20 * min(1.0, max(0.0, strength))))
    if score < MIN_SCORE or rate < 0.5:
        return None
    last = days[-1]
    atr = sum(r["h"] - r["l"] for r in days[-14:]) / len(days[-14:])
    c = last["c"]
    if side == "up":
        lo, hi = c - 0.12 * atr, c + 0.10 * atr
        mid = (lo + hi) / 2
        sl = lo - 0.45 * atr
        risk = mid - sl
        tp1, tp2 = mid + 1.2 * risk, mid + 2.0 * risk
    else:
        lo, hi = c - 0.10 * atr, c + 0.12 * atr
        mid = (lo + hi) / 2
        sl = hi + 0.45 * atr
        risk = sl - mid
        tp1, tp2 = mid - 1.2 * risk, mid - 2.0 * risk
    bt = last["bar_ts"]
    return {"symbol": sym, "side": side, "kind": kind, "name": NAMES[kind], "score": score,
            "label": "STRONG" if score >= 75 else "WATCH", "hit_rate": round(rate * 100), "n": n, "move_pct": move_pct,
            "zone": [round(lo, 2), round(hi, 2)], "stop": round(sl, 2), "tp1": round(tp1, 2), "tp2": round(tp2, 2),
            "close": round(c, 2), "atr": round(atr, 4), "bar": bt.strftime("%b ") + str(bt.day) + bt.strftime(", %-I:%M %p %Z"),
            "bar_date": str(last["date"])}


def build(bars: dict, move_pct: float = MOVE_PCT):
    rise, fall = [], []
    for sym, d in (bars or {}).items():
        try:
            r = analyze(sym, d, move_pct)
        except Exception:
            r = None
        if r:
            (rise if r["side"] == "up" else fall).append(r)
    rise.sort(key=lambda x: -x["score"])
    fall.sort(key=lambda x: -x["score"])
    return rise, fall
