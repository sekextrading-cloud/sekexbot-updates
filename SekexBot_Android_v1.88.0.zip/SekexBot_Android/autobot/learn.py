"""Learn tab: read a daily chart the way the lessons teach it (trend, floor, ceiling, entries).

Everything here is a plain-language reading of the last ~6 months of daily bars. It is an aid for learning and
for sanity-checking a trade, not a prediction and not advice: levels are where price has reacted before."""
from __future__ import annotations

import pandas as pd


def _swings(df: pd.DataFrame, k: int = 3):
    """Swing highs / lows: a bar whose high (low) is the extreme of the k bars on each side."""
    hi, lo = [], []
    h, l = df["high"].values, df["low"].values
    for i in range(k, len(df) - k):
        if h[i] == max(h[i - k:i + k + 1]):
            hi.append((i, float(h[i])))
        if l[i] == min(l[i - k:i + k + 1]):
            lo.append((i, float(l[i])))
    return hi, lo


def _cluster(levels, tol):
    """Group swing prices that sit within tol of each other; strength = number of touches (recent ones count a bit more)."""
    out = []
    for i, p in sorted(levels, key=lambda x: x[1]):
        for c in out:
            if abs(c["price"] - p) <= tol:
                c["pts"].append((i, p))
                c["price"] = sum(x[1] for x in c["pts"]) / len(c["pts"])
                break
        else:
            out.append({"price": p, "pts": [(i, p)]})
    for c in out:
        c["touches"] = len(c["pts"])
        c["last"] = max(x[0] for x in c["pts"])
    return out


def read(df: pd.DataFrame, symbol: str = "") -> dict:
    if df is None or len(df) < 30:
        return {"error": "Not enough daily history to read this chart (need about 6 weeks)."}
    df = df.tail(160).copy()
    n = len(df)
    c = df["close"]
    last = float(c.iloc[-1])
    tr = pd.concat([df["high"] - df["low"], (df["high"] - c.shift()).abs(), (df["low"] - c.shift()).abs()], axis=1).max(axis=1)
    atr = float(tr.rolling(14).mean().iloc[-1])
    sma20 = float(c.rolling(20).mean().iloc[-1])
    sma50 = float(c.rolling(50).mean().iloc[-1]) if n >= 50 else None
    slope20 = float(c.rolling(20).mean().iloc[-1] - c.rolling(20).mean().iloc[-6]) / 5 if n >= 26 else 0.0
    hi, lo = _swings(df)
    tol = max(atr * 0.6, last * 0.006)
    sup = [x for x in _cluster(lo, tol) if x["price"] < last]
    res = [x for x in _cluster(hi, tol) if x["price"] > last]
    floor = max(sup, key=lambda x: x["price"]) if sup else None
    ceil = min(res, key=lambda x: x["price"]) if res else None
    # higher highs / higher lows over the last 3 swings each
    hh = len(hi) >= 2 and hi[-1][1] > hi[-2][1]
    hl = len(lo) >= 2 and lo[-1][1] > lo[-2][1]
    lh = len(hi) >= 2 and hi[-1][1] < hi[-2][1]
    ll = len(lo) >= 2 and lo[-1][1] < lo[-2][1]
    score = (1 if last > sma20 else -1) + (1 if sma50 and last > sma50 else -1 if sma50 else 0) + (1 if slope20 > 0 else -1) + (1 if hh and hl else -1 if lh and ll else 0)
    trend = "UP" if score >= 2 else "DOWN" if score <= -2 else "SIDEWAYS"
    # volume confirmation: last 3 days vs 20-day average
    v = df["volume"]
    vr = float(v.tail(3).mean() / max(v.tail(23).head(20).mean(), 1))
    ext = (last - sma20) / atr if atr else 0.0                 # how many ATRs above the 20-day average
    gap_day = float((df["open"].iloc[-1] - c.iloc[-2]) / c.iloc[-2] * 100)
    day_chg = float((last - c.iloc[-2]) / c.iloc[-2] * 100)
    big = float(tr.iloc[-1] / atr) if atr else 0.0

    notes, plan = [], []
    if trend == "UP":
        notes.append("Trend is UP: price is above its 20-day average and the lows are getting higher. Look for buys, not shorts.")
    elif trend == "DOWN":
        notes.append("Trend is DOWN: price is below its averages and the highs are getting lower. Do not try to catch the falling knife; wait for it to base.")
    else:
        notes.append("Trend is SIDEWAYS: price is bouncing between a floor and a ceiling. Buy near the floor, sell near the ceiling, and stand aside in the middle.")
    if big >= 2.2 and day_chg > 0:
        notes.append(f"Today is a very large up day ({day_chg:+.1f}%, {big:.1f}x a normal day's range). Big breakouts usually pull back or go sideways for a few days; buying the top of the candle is the riskiest entry.")
    if ext >= 3:
        notes.append(f"Price is {ext:.1f} average-ranges above its 20-day average: stretched. Wait for a pullback toward {sma20:.2f} rather than chasing.")
    if vr >= 1.5:
        notes.append(f"Volume is {vr:.1f}x normal: the move has real buyers/sellers behind it.")
    elif vr <= 0.7:
        notes.append("Volume is thin versus normal: moves on low volume fail more often.")
    stop_buf = 0.5 * atr
    if floor:
        notes.append(f"Floor (support) near {floor['price']:.2f}, tested {floor['touches']} time(s).")
    if ceil:
        notes.append(f"Ceiling (resistance) near {ceil['price']:.2f}, tested {ceil['touches']} time(s).")
    if not ceil:
        notes.append("No ceiling above: price is at or near its highs for this window (open air). Targets must come from the stock's normal range, not a level.")
    if trend != "DOWN":
        if floor and (last - floor["price"]) / atr <= 1.2:
            plan.append({"kind": "BUY", "name": "Bounce off the floor", "zone": [round(floor["price"], 2), round(floor["price"] + 0.6 * atr, 2)],
                         "stop": round(floor["price"] - stop_buf, 2), "target": round(ceil["price"] if ceil else last + 2 * atr, 2),
                         "why": "Price is sitting on support. Buy only after a candle that closes back up from the floor; stop just under it."})
        elif trend == "UP" and sma20 < last:
            z_hi = min(last, sma20 + 0.5 * atr)
            plan.append({"kind": "BUY", "name": "Pullback to the 20-day average", "zone": [round(sma20 - 0.2 * atr, 2), round(z_hi, 2)],
                         "stop": round(sma20 - 1.2 * atr, 2), "target": round(ceil["price"] if ceil else last + 2 * atr, 2),
                         "why": "In an uptrend the best entry is the first dip into the rising average, not the top of the last big candle."})
        if ceil and last < ceil["price"]:
            plan.append({"kind": "BUY", "name": "Breakout above the ceiling", "zone": [round(ceil["price"] * 1.001, 2), round(ceil["price"] + 0.5 * atr, 2)],
                         "stop": round(ceil["price"] - 0.5 * atr, 2), "target": round(ceil["price"] + 2 * atr, 2),
                         "why": "Only if price CLOSES above the ceiling on volume at least 1.5x normal; the old ceiling then becomes the new floor. A poke above that falls back is a fake-out."})
    if trend == "DOWN" or (ceil and (ceil["price"] - last) / atr <= 1.0):
        if ceil:
            plan.append({"kind": "SELL/SHORT", "name": "Rejection at the ceiling", "zone": [round(ceil["price"] - 0.4 * atr, 2), round(ceil["price"], 2)],
                         "stop": round(ceil["price"] + 0.6 * atr, 2), "target": round(floor["price"] if floor else last - 2 * atr, 2),
                         "why": "Price is at resistance. Sell longs, or short only after a candle fails there (long upper wick, closes lower)."})
    if not plan:
        plan.append({"kind": "WAIT", "name": "No clean entry right now", "zone": [], "stop": None, "target": None,
                     "why": "Nothing lines up: not at a floor, not at a ceiling, no pullback. Waiting is a position."})
    for p in plan:
        if p.get("stop") and p.get("zone"):
            ent = (p["zone"][0] + p["zone"][1]) / 2
            risk = abs(ent - p["stop"])
            p["rr"] = round(abs(p["target"] - ent) / risk, 2) if risk > 0 and p.get("target") else None
    return {"symbol": symbol, "price": round(last, 2), "trend": trend, "atr": round(atr, 2), "sma20": round(sma20, 2),
            "sma50": round(sma50, 2) if sma50 else None,
            "floor": {"price": round(floor["price"], 2), "touches": floor["touches"]} if floor else None,
            "ceiling": {"price": round(ceil["price"], 2), "touches": ceil["touches"]} if ceil else None,
            "volume_x": round(vr, 2), "stretch_atr": round(ext, 2), "day_pct": round(day_chg, 2), "notes": notes, "plan": plan,
            "bars": [{"t": i.strftime("%b %d"), "o": round(float(r.open), 2), "h": round(float(r.high), 2), "l": round(float(r.low), 2), "c": round(float(r.close), 2)} for i, r in df.tail(70).iterrows()],
            "disclaimer": "A reading of where price has reacted before. Not a prediction and not advice."}
