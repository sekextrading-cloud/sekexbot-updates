# SekexBot for Android — setup guide (1.88.0)

SekexBot runs **entirely on your Android phone**. No PC is needed. It runs inside **Termux**, a free Linux app, and you use it from the same dashboard you know, opened in your phone's browser.

> **Get Termux from F-Droid or GitHub, not the Play Store.** The Play Store version is old and broken.
> You need three apps, all from the same source (all F-Droid, or all GitHub):
> - **Termux** (required)
> - **Termux:API** (battery status, notifications, wake lock)
> - **Termux:Boot** (start SekexBot automatically when the phone turns on)
> - **Termux:Widget** (Start / Stop buttons on your home screen)

---

## 1. Install (one time)

**Automated install: one file, one command.**

1. Install **Termux**, **Termux:API**, **Termux:Boot** and **Termux:Widget** from F-Droid (f-droid.org). Open Termux:Boot once.
2. Save **`SekexBot_Setup.sh`** to the phone's **Download** folder.
3. Optional, for a zero-typing setup: fill in **`sekexbot-setup.conf`** (your Alpaca paper keys, daily limit, and `START_TRADING=yes`) and save it in **Download** too.
4. Open Termux, paste this one line and press Enter:

```
termux-setup-storage; until [ -r /sdcard/Download/SekexBot_Setup.sh ]; do sleep 2; done; bash /sdcard/Download/SekexBot_Setup.sh
```

Tap **Allow** when Android asks about files. The installer then runs by itself with no questions (10–40 minutes; keep the phone plugged in). It:

- installs Python and every library, compiling one if the phone needs it;
- installs SekexBot, the `sekex` command, start-on-boot and the home-screen buttons;
- applies `sekexbot-setup.conf` if present, then **deletes it** (it holds your keys);
- starts SekexBot, and starts the auto-trader on paper if you set `START_TRADING=yes`;
- runs a setup check (`sekex doctor --fix`) that opens the F-Droid page for any missing add-on and Termux's battery page;
- opens the dashboard.

Everything is logged to `~/sekexbot-install.log`.

**Bringing over what the PC bot learned (optional):** before step 4, make a folder named **`SekexBot_data`** in Download and copy the PC's `data` folder and `.env` file into it. The installer imports your keys, learning memory and trade journal (only if the phone has none yet). Delete that folder afterwards, since `.env` holds your keys.

## 2. Tell Android not to kill it (important)

Android closes background apps to save battery. Do all of these:

- **Settings → Apps → Termux → Battery → Unrestricted** (on some phones: "Don't optimize" or "No restrictions").
- Do the same for **Termux:API**.
- **Samsung:** Settings → Battery → Background usage limits → **Never sleeping apps** → add Termux.
- **Xiaomi / Redmi / POCO:** Security app → Permissions → **Autostart** → enable Termux; and set Battery saver → Termux → **No restrictions**.
- **OnePlus / Oppo / Realme:** Battery → App battery management → Termux → **Allow background activity**.
- Keep the **phone plugged in and on Wi-Fi** while it trades.
- Optional: Settings → Developer options → **Stay awake** (screen stays on while charging).

## 3. Start and stop with a tap (no typing)

**Home-screen buttons.** Long-press an empty spot on your home screen → **Widgets** → **Termux:Widget**. Drag the widget onto the screen. It lists four SekexBot buttons:

| Button | What it does |
|---|---|
| ▶ **SekexBot Start** | Starts SekexBot and opens the dashboard |
| ■ **SekexBot Stop** | Stops the auto-trader and closes the app |
| ℹ **SekexBot Status** | Pops up mode, state, today's P&L and battery |
| ▢ **SekexBot Open** | Opens the dashboard |

Want single icons instead? Long-press the **Termux:Widget** app icon → drag **SekexBot Start** and **SekexBot Stop** onto the home screen as their own shortcuts.

**The notification.** While SekexBot runs, its notification has **Open** and **Stop** buttons. After you stop it, the notification shows a **Start** button.

**The dashboard.** **▶ Start Auto-Trader** and **■ Stop** turn trading on and off while the app keeps running. **🔌 Turn off app** closes SekexBot completely; turn it back on with the home-screen Start button or the notification.

## 4. First start

```
sekex start
```

The dashboard opens in your browser at **http://127.0.0.1:8010**.

1. Tap **🔑 Broker keys**, paste your Alpaca **Paper** keys, then tap **Test connection** and **Save & connect**.
2. Set your **Daily max loss** and tap **▶ Start Auto-Trader**.
3. In Chrome, tap **⋮ → Add to Home screen** to get a SekexBot app icon.

A **SekexBot** notification stays in your notification bar. Tap it to open the dashboard.

## Layout and theme (⚙ gear, top right)

- **Tabs** (default on phones): **Auto · Manual · Positions · More** along the bottom. Auto has the big on/off switch, loss limit, controls, stock picker and activity. Manual has the order ticket, chart and AI read. Positions has every position, the journal and daily results. More holds Settings, Broker keys, Remote access, Update and Turn off app.
- **Auto | Manual**: one big switch under the header flips between the two sides; the gear opens Settings.
- **One page**: everything on one scrolling page, as before (default on a computer).
- **Theme**: Dark, Light, or Phone (follows the phone's setting).

A summary strip (equity, today's P&L, loss left, open trades) stays at the top in Tabs and Auto | Manual. Your choices are saved on each device.

## Paper or Live — and knowing which you're in

- **Tap the PAPER / LIVE badge** at the top to switch. Going Live needs your **Live PIN**, a tick on "I understand this trades real money", and working **live keys** (they're tested first). If the auto-trader is running it stops, switches and restarts by itself; open positions keep their stop-loss at Alpaca. 5 wrong PINs lock the switch for 15 minutes.
- **In Live mode you can't miss it:** a red frame around every screen with **● LIVE — REAL MONEY** at the top, a pulsing red badge, **LIVE ·** on every Buy/Sell button, a red phone status bar, and **🔴 LIVE** on alerts.
- **Account bar:** Balance, Today's P&L ($ and %), Open P&L, Buying power and Loss left are pinned under the header on every screen.
- **SIP data:** if your Alpaca account includes SIP, set **Controls → Data feed → SIP**. ⚙ → Help & repair → Run checks confirms it works.

## Manual trading (Buy / Sell / Close)

The dashboard's **Manual trade** ticket works like Alpaca's order screen:

| Field | Choices |
|---|---|
| Side | **Buy**, or **Sell** (shows **Short** when you don't hold the stock) |
| Order type | Market, Limit, Stop, Stop limit, Trailing stop (by % or $) |
| Quantity | Shares with − / + buttons, or a dollar amount |
| Limit / stop price | − / + buttons; tap the Bid or Ask to fill it in |
| Time in force | Good for day, Good 'til canceled, Immediate or cancel, Fill or kill, At the open, At the close |
| Trading session | Market hours (9:30–4), Extended hours (4 AM–8 PM), 24 Hour Market (Sun 8 PM–Fri 8 PM) |

**Interactive chart:** touch or drag on the trend chart for a **crosshair** — the readout shows the time, open/high/low/close, volume, **UPTREND / DOWNTREND**, the fast/slow lines and VWAP. **Tap** to pin a point, then move to measure the trend between the two points ($, %, time and ribbon flips). **Pinch** (or mouse-scroll) to zoom, drag with two fingers (or the mouse) to pan, **double-tap** to reset. Pick **1m / 3m / 5m / 15m** candles. The dashed blue line is VWAP; bars at the bottom are volume.

**Streaming prices:** with **Stream live prices** on (Controls, default), SekexBot keeps a live connection to Alpaca and pushes every price change to the app — the ticket, quick sheet and position P&L move tick by tick (badge: **STREAMING**; summary strip: **● Live**). It follows up to 30 symbols (your positions first, then the ticket, watchlist and top picks). The bot's extended-hours stops react within about a second. Alpaca's free plan allows **one** stream per account: if the PC version is running with the same keys, the phone falls back to polling (and Run checks tells you). Overnight prices always use polling.

**SIP vs IEX:** IEX is free but shows part of the market's trading; SIP (all exchanges) needs Alpaca's paid Algo Trader Plus plan. Switch in Controls → Data feed; **⚙ → Help & repair → Run checks** tells you whether SIP works on your account.

**Live price and cost:** the ticket and quick sheet show the price, the day's change (green/red), bid/ask and a **LIVE** dot, refreshing every 3 seconds, and the estimated cost as shares × price with your buying power. When the market is closed, the last trade or close is shown with its "as of" time, so you can always prepare an order; it fills when its session opens. The trend chart also shows the most recent session while the market is closed.

**Suggested stop-loss / take-profit:** tick **Attach stop-loss / take-profit** and SekexBot proposes three plans — **Scalp** (tight, 1.5R), **Day** (default, 2R) and **Swing** (wide, 2.5R). Stops sit just beyond real support (buy) or resistance (short), sized by the stock's volatility; targets are pulled in ahead of the next level. Each plan shows its R and a size that risks the same amount the bot would (15% of your daily limit) — tap **Use N sh** to apply it. It also says whether you're trading with or against the trend. These are level-based estimates, not predictions.

**Size presets:** the quick sheet has **$1k**, **$5k**, **1R risk** (what the bot risks per trade, with the suggested stop) and **Max** (25% of buying power).

**Double-tap to trade:** double-tap a stock in the Stock picker, the scanner chips or Positions. A quick trade sheet opens with the picker's suggested size (or your position size), − / + buttons, and big **BUY** and **SELL** (or **SHORT**) buttons. In market hours it sends a market order; in pre-market, after-hours or overnight it sends a limit order just past the ask or bid. A single tap still opens the chart, and **Open full order ticket** hands the stock to the full ticket.

The ticket only offers combinations Alpaca accepts. Extended hours and 24 Hour Market take **limit** orders only, Good for day or Good 'til canceled. For a 24 Hour order to keep working overnight, choose **Good 'til canceled**. In Market hours, a market or limit order can carry an optional **stop-loss / take-profit**, held at Alpaca. The ticket shows the estimated cost, your buying power, and when the order will start working if that session is closed now.

In **Positions & orders**, every position in the account is marked **YOU** or **BOT**. **Close** exits the whole position, **½** closes half, and **Cancel** removes an open order. Tap a symbol to load it into the ticket.

Rules:
- Manual positions are yours. The bot never enters a symbol you traded by hand that day, and never flattens your positions at the close.
- The daily loss halt still closes **everything** in the account, including manual positions.
- Extended hours: limit orders only (a market order is sent as a marketable limit), long only, and no stop-loss or take-profit.
- Closing half a position cancels its stop-loss and take-profit; set new ones if you want them.
- In LIVE mode every order and close asks for a confirmation marked LIVE MONEY.

## Alerts (🔔 bell, top right)

SekexBot tells you right away what happened, even with the app closed (needs the Termux:API app):

| Group | Alerts |
|---|---|
| Trades | Bot entries, fills, exits with P&L, stop raised to breakeven, rejected orders, your manual orders |
| Risk | Daily loss halt / profit lock, losing streak pause, broker restriction, stale overnight data, errors |
| Trend | For your watchlist: ribbon flip green/red, new high/low of day, VWAP reclaim/loss, volume spike |
| Price | "Tell me when SPCX goes above 150" — set in ⚙ → Alerts, or 🔔 in the quick trade sheet |
| Summary | End-of-day P&L, win rate and best setup at 4:05 PM ET |

Notifications have **Trade** (opens the quick trade sheet) and **Close** (closes the position) buttons. Turn each type on or off in **⚙ → Alerts**, set **quiet hours** (risk alerts still come through), and optionally copy alerts to the free **ntfy** app or **Telegram** to get them on another device. The 🔔 bell shows the history.

## 🛠 Help & repair (⚙ → Help & repair)

- **Run checks**: Alpaca connection, market data, wake lock, battery, storage, recent errors and rejections, updates.
- **One-tap fixes**: Reconnect Alpaca, Restart app, Repair install (re-installs libraries), Install update.
- **✨ Ask AI**: describe the problem or tap **🛠 Help** next to any order error — Claude explains it in plain steps using the checks and the recent log (keys removed). Needs a Claude API key.
- **Send report**: saves a support report (no keys) to Download and copies it, to send to your developer.

The app never rewrites its own code; real fixes arrive as updates. Some order errors are fixed automatically — for example, a stop-loss rejected while the market is closed is re-anchored on Alpaca's reference price and resent.

## Updating from the app

Tap **⬆ Update** at the top of the dashboard (on the phone itself):

- **Install from a file:** download the new `SekexBot_Android_vX.Y.Z.zip` to the phone, pick it, and tap **Install**.
- **Update link (one tap):** host the zip and `latest.json` (both made by `build_setup.sh`) on your site or a GitHub release, and paste the link to `latest.json` once. SekexBot checks every 6 hours, sends a notification when a new version is out, and installs it with one tap. Every download is checked against the SHA-256 in `latest.json`.
- **Publish in one command:** save the new zip from the chat to Downloads, open Termux and run `sekex publish`. First time it asks for your GitHub repo (public, for example `sekextrading-cloud/sekexbot-updates`) and a fine-grained token with Contents: Read and write on that repo. It stores them only on the phone, writes `latest.json` for you, uploads the zip first and `latest.json` last, and points the app's update link at it.

An update takes about a minute and keeps your keys, settings, learning memory and journal. Trading resumes by itself. Updates can't be started through Remote access.

## 5. Commands (optional; type these in Termux)

| Command | What it does |
|---|---|
| `sekex start` | Starts SekexBot in the background with a wake lock and auto-restart |
| `sekex stop` | Stops the auto-trader, then the app. Regular-hours stops stay at Alpaca. |
| `sekex status` | Shows mode, state, today's P&L, battery and warnings |
| `sekex open` | Opens the dashboard |
| `sekex log` | Shows the live log (Ctrl+C to quit) |
| `sekex restart` | Restarts the app. Trading resumes if it was running. |
| `sekex sim` | Runs the offline simulator (no keys needed) |
| `sekex backup` | Saves keys, learning memory and journal as a zip in Downloads |
| `sekex update <zip>` | Installs a newer SekexBot_Android zip and keeps your data |
| `sekex setup` | Re-runs the installer (repairs missing libraries) |
| `sekex doctor` | Checks the phone setup; `--fix` opens the screens that fix problems |
| `sekex trade-on` | Starts the auto-trader (same as the dashboard's Start button) |

## 6. What's different from the PC version

- **Auto-restart and auto-resume.** If SekexBot crashes or Android kills it, the watchdog restarts it within seconds. If the auto-trader was running, it **resumes by itself**. A Stop from the dashboard or `sekex stop` is remembered, so it won't restart trading you stopped on purpose. You can turn auto-resume off in **Controls**.
- **Nothing resets on a restart.** Open trades, today's loss-limit halt, the profit-lock peak and the losing-streak brakes are saved every tick and restored.
- **Starts when the phone boots**, through Termux:Boot. It waits 20 seconds for the network, then starts. Trading resumes only if it was running before.
- **After-hours and overnight trading start OFF.** Outside regular hours Alpaca holds no stop-loss for you. The app watches the stop itself, so if Android closes the app at night, that position is unprotected. You can switch them on in **Controls** if you accept that risk.
- **Phone status banner.** The dashboard shows battery, charging, temperature and wake lock, and warns you when the phone is on battery or hot.
- **🌐 Remote access** replaces "Phone access". You don't need it on the phone itself; it's only for checking the phone's bot from a laptop or tablet. It uses Termux's own `cloudflared` package.

## 7. Safety notes

- Regular-hours trades are **bracket orders**, so the stop-loss and take-profit sit on Alpaca's servers even if the phone dies.
- Your keys live in `~/sekexbot/.env` on the phone. Anyone who can open Termux on your unlocked phone can read them. Use a screen lock, and treat `sekex backup` zips as private.
- Run on **paper for several weeks** before going live. The simulator only checks the mechanics, not profitability.
- Use a dedicated Alpaca account. Hitting the daily limit closes **every** position in the account.
- Not financial advice. Automated trading can lose money.

## Troubleshooting

| Problem | Fix |
|---|---|
| Dashboard won't open | Run `sekex status`. If it says not running, run `sekex start`. Check `sekex log` for errors. |
| Bot stops overnight or when the screen is off | Recheck step 2 (battery settings), and make sure the banner says **wake lock on**. |
| "Package check failed" during install | Run `pkg update && pkg upgrade`, then `sekex setup` (or `bash install.sh` again). |
| No battery info in the banner | Install the **Termux:API** app from the same source as Termux. |
| Doesn't start after a reboot | Open the **Termux:Boot** app once, and give it Unrestricted battery too. |
| Remote access says cloudflared isn't installed | `pkg install cloudflared` |
| No SekexBot buttons in the widget | Install **Termux:Widget** from the same source as Termux, then run `sekex setup`. Remove and re-add the widget to refresh it. |
| Widget buttons do nothing, or no pop-up appears | Make sure Termux, Termux:API and Termux:Widget all came from the same source (all F-Droid). Give Termux and Termux:API Unrestricted battery, then run `sekex setup`. |


## Safety net setup (v1.21)
1. **Phone-offline alert:** sign up free at healthchecks.io → Add Check → Period **1 minute**, Grace **3 minutes** → Integrations: add email / SMS / ntfy / Telegram → copy the **ping URL** → SekexBot ⚙ → 🛡 Safety net → paste → Save → Test.
2. **Backups:** on by default every night at 8:10 PM ET, saved to Downloads/SekexBot/backups (run `termux-setup-storage` once so the app can write there).
3. **GitHub backups (optional):** GitHub → Settings → Developer settings → Fine-grained tokens → only your private repo → Repository permissions → **Contents: Read and write** → paste the repo (owner/name) and token in ⚙ → 🛡 Safety net.
4. **Restore:** stop the auto-trader, ⚙ → 🛡 Safety net → Restore… → pick a backup zip, then restart the app.

- **Auto-harvest (♻):** on a manual buy or short, the bot banks a small gain and gets back in on a pullback, repeatedly, until you tap Stop. Its own protective stop is 1.2 x the stock's normal 5-minute range. Extended-hours stops are watched by the app, so keep it open.
- **Reopen last close:** one tap under Positions puts back the position you last closed by hand.

## Trading levels
Controls > Trading level: Conservative (long only, regular hours), Balanced (longs + shorts, pre/after at half size), Aggressive (every ribbon flip, scalps), Max (everything on, largest size), Auto (learns the best of the first three per session from your trades), Custom (any change under Advanced). The daily max loss always applies.

## Morning trends and overnight study
The ribbon is seeded with pre-market bars so it is ready at 9:30. PLAN_TREND trades the Big movers names that break their early high/low. The bot studies recent days after 5 PM and overnight (Overnight study card; Study now to run it by hand). Simulated trades approximate fills and count 0.3 of a real trade.

## Direction call
Big movers table (Call column) and the manual ticket show LONG / SHORT / WAIT for a stock, with the reasons. It is a lean from the chart, not a prediction; Overnight study shows how often past 9:40 calls were right.

## Morning reversal, overnight short, evening candidates
Controls > Advanced has two switches, both off: Morning reversal and Pre-close overnight short. The Evening candidates card has a Review button (also automatic after 4:30 PM). `sekex replay SPCX 2026-09-28` prints when each strategy would have fired on a past day. Overnight shorts are shares with broker-held GTC stop/target; the stop can gap at the open.

## Updating (any version)
Download the new SekexBot_Android zip to Download, then in Termux: `sekex update /sdcard/Download/SekexBot_Android_v1.72.0.zip` (or `sekex update` with no path to use the newest zip in Download). To stop the bot first and update in separate steps: `sekex stop`, then `sekex update <zip>`, then `sekex start`. Your keys, journal and learning memory are kept. Admin phones also install the matching SekexBot_Admin zip.

## Home-screen icon (v1.69.1)
`sekex home` adds a one-tap **SekexBot** shortcut (Termux:Widget, with the logo) that starts the bot if it is off and opens the dashboard. It is installed automatically by the installer.

## Pick your AI: Claude or ChatGPT (v1.69.2)
Gear, then Broker keys, then **AI**. Choose Claude or ChatGPT, paste that provider's key, Save, **Use this AI**, then Test. The chart reader, Ask AI, signal review and Fix all use the active AI. OpenAI API credits are billed separately from a ChatGPT Plus plan.

## Market regime and strategy breaker (v1.68.2)
Auto, Advanced: the **regime filter** sizes strategies up or down for trend, chop, volatile and quiet markets (never above about 1.2x) and blocks the clearest counter-trend fades. The **strategy breaker** halves size, then pauses, a strategy that is losing badly today. Neither touches your daily loss limit.

## Session focus (v1.68.3)
The Auto page's **Session focus** card shows only what matters for the session you are in (Auto follows the clock; or pick Pre-market, Regular, After-hours, Overnight, or Show all).

## Options auto-trader (v1.69.0, OFF by default)
Auto page, **Options** card, its own switch and its own daily options budget. Defined risk only (vertical debit spreads, or single long calls/puts), regular hours only, PAPER only until you unlock Live with your PIN. Needs an Alpaca account with options approved. Turn it on in PAPER first and watch the first trades before trusting it.

Since v1.72 the module is fully separate: its own on/off switch, its own settings file (options_settings.json), its own daily options budget and its own journal (options.db). The Options card's **Options journal** button shows its results (win rate, P&L, by stock, call/put, style and exit reason) and **Export CSV** downloads them. Turning it off leaves your stock bot untouched; open options positions are still managed to their exit.

## Small-account mode: fractional shares (v1.70.0, OFF by default)
Auto, Advanced, **Small-account mode**. When one whole share is too big for the risk budget, the bot buys a fraction (long only, regular hours, stocks Alpaca marks fractionable, $1 minimum). Fractions get a broker stop; the bot takes the profit target itself, so keep it running. Whole-share trades are unchanged.

## Green guard (v1.71.0, ON by default)
Auto, Advanced, **Green guard**. A trade that keeps going green but never reaches its target is banked (on its second clear green, or after giving back 40-50% of a small peak) and its stop moves to break-even plus costs. The "green" size adapts to the spread and slippage.

## Morning trend rider, MORN_TREND (v1.71.0, ON by default)
Auto, Advanced, **Morning trend rider**. 9:35-11:00, long or short, for steady grinds: a 1%+ gap OR a steady 0.8%+ move off the 9:30 open, price above (below) VWAP, 9 EMA over (under) 21 EMA, entered on a pullback to the 9 EMA or a break of the last 12 bars. Shorts need Allow shorts and an easy-to-borrow stock. It does not trade pre-market.

## Trade pad (v1.73.0)

Manual tab, above the order ticket. Tap a watchlist chip or an open-position chip to pick the symbol (the red X on a position chip closes it), or type it. On a wide screen the positions and watchlist sit to the right of the controls and the six keys run in one row, so nothing needs scrolling. The quote and chip prices refresh on their own (3 and 5 seconds) while the Manual tab is open. Then choose Shares or Dollars, tap a preset chip or turn the knob, then press BUY or SELL. LIMIT (default) sends a marketable limit at the ask or bid; MARKET works only while the market is open. CLOSE exits your position in that stock, CANCEL cancels its open orders (refused for open bot trades). Every order uses the normal confirmation, PIN and short-selling rules. Edit presets with the Presets button; they are saved per device.

Hardware macro pad: program the pad's keys to send B, S, C (close), X (cancel), L, M, the arrow keys and 1 to 6 to the browser with the dashboard on the Manual tab. Suggested layout: knob = left/right arrows, knob press = 1, then CLOSE = C, CANCEL = X, LIMIT = L, MARKET = M, SELL = S, BUY = B.

## Morning prep (v1.74.0)

Auto tab, card Morning prep. Uses real Alpaca data for your watchlist, shortlist and movers: Gap (price now vs the last close), vs 20d avg, To 20d high, ATR, and a Setup tag. TREND LONG or TREND SHORT = a 1%+ gap with the trend behind it, which is what the morning trend rider looks for at 9:35. NEW 20D HIGH, NEAR HIGH and LONG WATCH are long candidates. Best long setups first. Tap a row to put it on the Trade Pad. Refreshes every minute, information only, it never trades.

## Pre-market preset, Scorecard (v1.75.0)

Auto tab. Pre-market preset: Auto-create builds a window, a size cap and a strategy-off list for the pre-market from your own closed trades (Recommended: start 7:00 to 9:00, max $10,000 per trade, used when there are fewer than 20 pre-market trades). Tick Rebuild it every night to refresh it after the nightly study. It only limits the bot's own entries; your manual trades and the daily loss limit are untouched. Scorecard: your closed trades by strategy, session, side, hour or stock; Turn off stops a losing strategy. Trade pad: the Auto-harvest tick is shown, because when it is on the bot sells small gains and stops out your manual trades.

## Close-now log (v1.76.0)

Positions tab, card Close-now log. Close-now is what you would really make if you closed this second (bid for longs, ask for shorts, so after the spread). The log records every time it goes above your line (default $10; change it in the card): UP when it crosses, FELL when it drops back under (with the peak and how many minutes it was above), CLOSED if the position was closed while above. It covers your trades, the bot's and auto-harvest, is checked every 5 seconds, survives restarts, and Export CSV downloads it. Use it to see whether winners that were available got taken or given back, then tune Harvest small % and the pre-market preset.


## Pre-market only preset (v1.76.1)

Auto tab, Pre-market preset: the new button Pre-market only: EXT_TREND + FLUSH_BOUNCE makes the bot start trades only with those two strategies in the pre-market (the two that held up in your journal), 7:00 to 9:00, max $10,000 each, and sell for a profit only when it is at least 3 times the spread. It limits only the bot's own entries; manual trades and the daily loss limit are untouched. Open positions now show (spread cost $X) next to close now. The sample behind this is small, so treat it as a test.


## Session auto-off (v1.77.0)

Auto tab, Session auto-off card. Self-fix already benches and promotes setups. Session auto-off adds a hard, per-session rule: each night, any strategy with at least 12 closed bot trades in one market session over the last 30 days that lost money there (profit factor under 0.9) is switched off in that session only. A week later it is switched back on for a fresh try and judged only on the new trades. The card lists what is off and why, with a log; On/Off, Run now and Reset are on the card. Manual trades, other sessions and your daily loss limit are untouched.


## Smart entry (v1.78.0)

Auto tab, Pre-market preset card, tick Smart entry. In the pre-market, after-hours and overnight the spread is wide, and the bot used to pay the full spread on every entry. Now the entry limit starts halfway between bid and ask and moves toward the far side at 15 and 30 seconds, ending at the old price, so you only pay the whole spread when the market will not come to you. If it still has not filled after 90 seconds it is dropped, as before. Skipped when the spread is under 2 cents. The card shows how many entries filled early, how many needed the far side, how many were missed, and the dollars saved compared with the old price. Regular hours are unchanged (those entries carry a broker stop and target).


## Simple controls (v1.79.0)

Controls tab, at the top of the Advanced area: three simple controls. Exit style picks how trades are closed: Ride the trend, Harvest (the default), Scalp or Aggressive scalp. It sets Take profit along the way, Let winners run, Scalp mode, Aggressive scalping, Harvest small %, Harvest-sized stops and Green guard together. Shorts picks Off, Regular hours, From 7 AM or 24/5. Learn from my results turns on or off Strategy breaker, Self-fix, Session auto-off, the time-of-day filter and reduced size until a setup has 20 trades. If you change an individual switch under Advanced so the mix no longer matches, Exit style shows Custom. Nothing was removed and your current settings were not changed. The internal one-time migration flags in the settings file are what stop old upgrades from re-running, so they stay.


## Harvest now (v1.80.0)

Positions tab. Each of your own positions has a green ⚡ Harvest button next to the ♻ button. It sells the position right away at the bid (ask for shorts) and keeps the Auto-harvest cycle going, so the bot buys back on a pullback or if the stock keeps running, and harvests again. If Auto-harvest was off it is switched on first. In the Auto-harvest list the same button reads ⚡ Harvest now while the position is held and ⚡ Re-enter now while the cycle is waiting to buy back. If the position is below your entry the app asks before selling. It does not apply to the bot's own trades, and the daily loss limit still stops cycles.


## Start on boot (v1.81.0)

SekexBot now starts by itself when the phone turns on. This is on by default and needs the Termux:Boot app (install it from F-Droid and open it once). To turn it off, untick Start SekexBot by itself when the phone turns on in Controls (Advanced). The line below it, Auto-resume trading if the app is restarted, decides whether trading starts again too. After an update the boot script is refreshed automatically. Also set Termux and Termux:Boot to Unrestricted battery in Android settings, and take them out of any sleeping-apps list. sekex doctor tells you whether the boot script is in place and whether the switch is on. To check, restart the phone, wait a minute after unlocking, and run sekex status.


## Night shorts (v1.82.0)

From 8:00 PM to 7:00 AM ET the bot trades shorts only. It sells short only the stocks on the setup-short list (the ranked short shortlist, easy-to-borrow names only, built after the close and refreshed through the night), and only when a fresh 1-minute short signal confirms. No new longs are started at night; they wait for 7 AM. The bot sells for a profit using the harvest rules and keeps its protective stop, and night shorts are not forced closed when overnight turns into pre-market; after 7 AM the normal rules take over. Open the list from More, then Night shorts list; the card also has the on/off switch. It is on by default and switches the overnight session on. It needs Trading ON, an Alpaca account that can short, and the daily loss limit still applies. With the free IEX feed pre-market data starts at 8 AM, so the 4 to 7 AM part only has data on SIP.


## Harvest now overnight (v1.82.1)

Auto-harvest pauses by itself from 8 PM to 4 AM because overnight quotes are thin. That pause used to ignore your Harvest now and Re-enter now buttons too. They now work overnight: the order is a limit order at the bid (ask for a short) and it is retried more aggressively if it does not fill. Only the automatic harvests, stops and re-entries stay paused until 4 AM.


## Max $ per bot trade (v1.83.0)

Controls > Advanced, Max $ per bot trade (default $10,000, 0 = off). The bot never opens a single trade bigger than this many dollars, in any session. It works with the existing Max bot position % of equity: the smaller of the two wins. From your own journal (350 closed trades, Sep 28 to Oct 2): trades over $20,000 lost about $3,900, trades under $5,000 made about $600, and the 7 stop-outs that lost more than twice the planned risk were on very large share counts (for example 9,281 shares of a $2.43 stock). The daily loss limit is unchanged.

## Night buys and the Session tab (v1.84.0)
**Night mode is now buys only.** From 8:00 PM to 7:00 AM ET the bot only buys, only the stocks on the night list, and takes a small profit fast (scalp / harvest exits; the protective stop stays). No shorts at night; they wait for 7 AM. If you liked the v1.82 behaviour, pick "Shorts only (close on profit)" in the selector and it works as before.

**One Session tab.** Between Positions and More there is now a tab whose name and icon follow the market: Pre-mkt (4:00-9:30 AM), Regular, After (4:00-8:00 PM), Night (8 PM-7 AM) and Closed. Tap it to see that session's list (movers in the day sessions, the night list at night), what the bot is waiting for on each name and your open trades. At night it also holds the Night mode switch and the Buys / Shorts selector. The old "Night shorts list" menu item is replaced by "Session list" in More.


## Morning wave watchlist (v1.85.0)
Open the Session tab and scroll to **Morning wave watchlist**. It lists conditional setups for the next morning, split into **Potential Rise** and **Potential Fall**. For each stock or ETF you get the entry watch zone, the stop (SL), two targets (TP1, TP2), the setup name, a score out of 100, and a line like "76% hit 0.4% move (n=17)".

**How to read it.** The setups come from how the last regular session closed: a strong close near the high (close high continuation), a weak close near the low (weak close continuation) or a down day that held up in the middle of its range (overnight bounce). The hit rate says how often the same pattern, over the last 6 or so weeks, was followed by a 0.4% price move in the right direction between 4 AM and 11 AM ET. It counts a price excursion, not a profitable trade. The zone, stop and targets use the latest regular-session bars (the bar time is shown), not the live quote, so a "Prior bar, recheck at open" flag shows outside regular hours. A tag says IN ZONE once the live price is inside the zone. Only consider an entry then, and check spreads and news first. Earnings are flagged; other news is not checked.

**It never trades.** The card is display only, and down watches are informational (the overnight order flow does not support shorts). It scans your watchlist, the shortlist and a core list of liquid names and ETFs, refreshes every 5 minutes, and has a Refresh button. Your daily loss limit is untouched.


## Trade the wave (v1.86.0)
On the Morning wave card there is now a **Trade the wave** switch. It is OFF by default and works the same in paper and live (the card shows PAPER or LIVE next to it, so check it before you turn it on).

**What it does when ON.** Between 9:30 and 10:30 AM ET (change From / Until to start earlier, for example 8:00 AM for pre-market) the bot looks at the Potential Rise setups whose score is at least Min score (70). When a stock's price is inside its entry watch zone it places a limit buy: in regular hours a bracket order with the card's stop (SL) and TP1, before 9:30 a limit order whose stop and TP1 the app watches. TP2 is shown for reference only. It takes at most Max trades/day (2) and only one entry per stock.

**Safety.** Size is your normal risk times Size x (0.5 = half). Your daily loss limit is unchanged and still stops new entries, and Max \$ per bot trade, Max bot position, buying power, the spread check, the earnings / news filter, the 2-loss symbol cool-off and "you traded it by hand today" all still apply. Falls are never traded. The line under the switch lists what was bought today and why the bot is still waiting (for example price outside the zone).

**Start small.** The hit rate counts a 0.4% price move over about 6 weeks, not profit. Run it in paper for a few mornings, look at the journal for the WAVE strategy, then decide about live.


## Options limits and Greeks (v1.87.0)
**New boxes on the Options card** (Auto tab): *Max stocks* (how many different stocks can have an open options trade at once), *Per stock* (how many open trades on the same stock), *Max open calls* and *Max open puts* (how many of each side), *Contracts per trade* (the most contracts in one order; the \$ per trade limit still applies), and *Min delta*. *Max open* is still the overall cap, and the smaller limit always wins. The defaults give the same behaviour as before: 2 open, one per stock.

**Min delta** skips an entry when the main option's delta is smaller than the number you set (0 = off). At-the-money is around 0.50; a higher minimum means a more in-the-money, slower-decaying option, a lower one means a cheaper but more speculative one.

**Greeks.** Under the open trades table, each trade shows delta (the \$ it gains per \ move in the stock), gamma (how fast delta changes), theta (time decay per day), vega (\$ per 1 point of implied volatility) and IV. For a spread these are the long leg minus the short leg. The bold part is the whole position: theta in \$ per day and delta in share-equivalents. If Alpaca sends no Greeks for a contract, it says "not available yet". The numbers are for display and the optional Min delta filter; exits still use your take-profit, stop and the trend flip. Options on LIVE still need your PIN unlock.


## PAPER and LIVE tags (v1.87.1)
Every trade now carries a tag showing which account it ran on: a red **LIVE** or a blue **PAPER** (yellow SIM in the simulator). You see it in the Trade journal (Mode column), on open and recently closed options trades, in the options journal, and beside the Positions & orders heading. The mode was already saved with every trade, so your older history shows it too. The big red bar at the top and the LIVE / PAPER badge in the header are unchanged.


## If starting seems to hang (v1.87.2)
Starting SekexBot no longer waits on the Termux:API app. If that app is not installed, the notification and the "open the browser" step are skipped after a few seconds, and Termux prints the address to open yourself (normally http://127.0.0.1:8010). To get the running notification and the Start / Stop buttons, install **Termux:API**, **Termux:Boot** and **Termux:Widget** from F-Droid (the same source as Termux). On an older version, either install Termux:API or run  pkg uninstall termux-api  and start again.

## Learn tab (v1.88.0)
A new **Learn** button sits on the bottom menu. It has six short illustrated lessons: direction (higher highs and higher lows, the 20-day average, volume), floor and ceiling, the four buy setups, when to sell, the best entry points (with an SPCX example and a pre-trade checklist), and how SekexBot uses these ideas. Tap **Read a stock for me**, type a ticker, and the app draws the last few months of daily candles with the trend, the nearest floor and ceiling, and a suggested entry zone with stop, target and reward-to-risk. It is a learning aid only: nothing is bought or sold from this tab.

Developers: `python3 tests/regression.py` runs the 23-check regression suite (about 1 minute). `python3 tests/regression.py audit name:path/to/trades.db:LIMIT` audits a simulator journal. `SIM_DATA=/some/folder python3 simulate.py ...` keeps a simulation's data separate.
