"""SekexBot regression suite. Run:  python3 tests/regression.py   (uses a throw-away data folder; never touches your data)

Covers: version consistency, settings migrations (daily loss limit must survive), risk manager, sessions, night mode,
morning-wave setups, wave trader, options limits and greeks, simulator journal audits, and every API endpoint."""
import json, os, re, subprocess, sys, tempfile, time, traceback
from datetime import date, datetime, time as dtime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="sekex_reg_")
os.environ["AUTOBOT_DATA"] = TMP
NY = ZoneInfo("America/New_York")
RESULTS = []


def test(name):
    def deco(fn):
        t0 = time.time()
        try:
            fn()
            RESULTS.append((name, "PASS", "", time.time() - t0))
        except AssertionError as e:
            RESULTS.append((name, "FAIL", str(e) or traceback.format_exc().splitlines()[-2], time.time() - t0))
        except Exception as e:
            RESULTS.append((name, "ERROR", f"{type(e).__name__}: {e}\n" + "".join(traceback.format_exc().splitlines(True)[-4:]), time.time() - t0))
        return fn
    return deco


# ---------------------------------------------------------------- static
@test("static: every python file compiles")
def _():
    r = subprocess.run([sys.executable, "-m", "compileall", "-q", str(ROOT / "autobot"), str(ROOT / "server.py"), str(ROOT / "bin")], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


@test("static: dashboard JavaScript parses")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    for i, m in enumerate(re.findall(r"<script>(.*?)</script>", html, re.S)):
        p = Path(TMP) / f"s{i}.js"
        p.write_text(m)
        r = subprocess.run(["node", "--check", str(p)], capture_output=True, text=True)
        assert r.returncode == 0, r.stderr[:300]


@test("static: shell scripts parse")
def _():
    for f in ("bin/sekex", "install.sh"):
        r = subprocess.run(["bash", "-n", str(ROOT / f)], capture_output=True, text=True)
        assert r.returncode == 0, f + ": " + r.stderr


@test("static: dashboard ids used by the code exist in the page")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    have = set(re.findall(r'id="([^"]+)"', html))
    used = set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)", html))
    dyn = {x for x in used if x not in have}
    # ids created by script (innerHTML) are fine: accept those that appear in a template string
    missing = sorted(x for x in dyn if f'id="{x}"' not in html and f"id=\\\"{x}\\\"" not in html and f"id='{x}'" not in html)
    assert len(missing) <= 3, "ids used in code but not in the page: " + ", ".join(missing[:15])


@test("static: version is the same everywhere")
def _():
    from autobot.version import __version__ as v
    assert (ROOT / "VERSION").read_text().strip() == v, "VERSION file differs from version.py"
    assert re.search(rf"^## {re.escape(v)} ", (ROOT / "CHANGELOG.md").read_text(), re.M), "CHANGELOG has no entry for " + v
    assert v in (ROOT / "README_ANDROID.md").read_text().splitlines()[0], "README_ANDROID header is not v" + v


# ---------------------------------------------------------------- settings
@test("settings: migrations never change the user's daily loss limit")
def _():
    from autobot import config
    d = Path(TMP) / "mig"
    d.mkdir()
    config.SETTINGS_FILE = d / "settings.json"
    config.OPTIONS_FILE = d / "options_settings.json"
    config.SETTINGS_FILE.write_text(json.dumps({"daily_max_loss": 137.5, "max_position_pct_equity": 0.25}))
    s = config.Settings.load()
    assert s.daily_max_loss == 137.5, f"daily limit changed to {s.daily_max_loss}"
    assert s.v130_defaults and s.v155_defaults is not None and s.v159_defaults and s.v163_defaults and s.v165_defaults, "legacy migration flags missing"
    assert abs(s.max_position_pct_equity - 0.15) < 1e-9
    s2 = config.Settings.load()
    assert s2.daily_max_loss == 137.5
    s2.daily_max_loss = 99.0
    s2.wave_trade = True
    s2.options_max_stocks = 3
    s2.save()
    s3 = config.Settings.load()
    assert s3.daily_max_loss == 99.0 and s3.wave_trade is True and s3.options_max_stocks == 3, "round trip failed"


@test("settings: risky features are OFF by default")
def _():
    from autobot.config import Settings
    s = Settings()
    assert s.wave_trade is False and s.options_on is False and s.options_live_unlocked is False
    assert s.night_dir == "buy"


# ---------------------------------------------------------------- risk
def _rm(**kw):
    from autobot.config import Settings
    from autobot.risk import RiskManager
    s = Settings()
    s.daily_max_loss = kw.pop("limit", 200.0)
    for k, v in kw.items():
        setattr(s, k, v)
    r = RiskManager(s)
    r.equity = 25000.0
    return s, r


@test("risk: halts at the daily loss limit and sizes to zero afterwards")
def _():
    s, r = _rm()
    assert r.update(25000 - 100, 25000) is False
    assert r.update(25000 - 200.01, 25000) is True and r.halted
    assert r.size(100, 99, 1.0, 0, 50000).qty == 0
    r.new_day()
    assert not r.halted


@test("risk: profit lock after giving back half of a limit-sized gain")
def _():
    s, r = _rm()
    assert r.update(25000 + 220, 25000) is False
    assert r.update(25000 + 100, 25000) is True and "Profit lock" in r.halt_reason


@test("risk: trade risk never exceeds the budget; caps always win")
def _():
    s, r = _rm(limit=200.0)
    r.update(25000 - 50, 25000)                      # $150 left
    d = r.size(100.0, 99.0, 1.0, 0.0, 50000.0)
    assert d.risk_dollars <= 0.5 * r.remaining + 1e-9, d
    d2 = r.size(100.0, 99.0, 1.0, 140.0, 50000.0)    # open risk already uses most of what is left
    assert d2.risk_dollars <= (r.remaining - 140.0) + 1e-9, d2
    s.max_trade_notional = 1000.0
    d3 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d3.qty * 100.0 <= 1000.0 + 1e-6, f"notional cap broken: {d3.qty} sh"
    s.max_trade_notional = 0.0
    s.max_position_pct_equity = 0.05
    d4 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d4.qty * 100.0 <= 25000.0 * 0.05 + 1e-6, "equity % cap broken"
    d5 = r.size(100.0, 99.99, 1.0, 0.0, 1000.0)      # buying power tiny
    assert d5.qty * 100.0 <= 1000.0 + 1e-6, "buying power cap broken"
    assert r.size(100.0, 100.0, 1.0, 0.0, 50000.0).qty == 0, "zero-risk stop must size to 0"


# ---------------------------------------------------------------- sessions
def _trading_day(d):
    return None if d.weekday() >= 5 else (datetime.combine(d, dtime(9, 30), NY), datetime.combine(d, dtime(16, 0), NY))


@test("sessions: boundaries, weekend gap, and the 8 PM bot day")
def _():
    from autobot.sessions import bot_day, current_session
    def at(y, m, d, h, mi):
        return datetime(y, m, d, h, mi, tzinfo=NY)
    cases = [((2026, 10, 6, 3, 59), "OVERNIGHT"), ((2026, 10, 6, 4, 0), "PRE"), ((2026, 10, 6, 9, 29), "PRE"), ((2026, 10, 6, 9, 30), "REGULAR"),
             ((2026, 10, 6, 15, 59), "REGULAR"), ((2026, 10, 6, 16, 0), "AFTER"), ((2026, 10, 6, 19, 59), "AFTER"), ((2026, 10, 6, 20, 0), "OVERNIGHT"),
             ((2026, 10, 9, 20, 30), None), ((2026, 10, 10, 12, 0), None), ((2026, 10, 11, 20, 0), "OVERNIGHT")]
    for (y, m, d, h, mi), want in cases:
        s = current_session(_trading_day, at(y, m, d, h, mi))
        got = s.name if s else None
        assert got == want, f"{y}-{m}-{d} {h}:{mi:02d} expected {want}, got {got}"
    assert bot_day(at(2026, 10, 6, 19, 59)) != bot_day(at(2026, 10, 6, 20, 0)), "daily window must roll at 8 PM ET"


# ---------------------------------------------------------------- engine pieces
def _engine(**kw):
    from autobot.config import Settings
    from autobot.engine import Engine
    from autobot.learner import Learner
    from autobot.sim import SimBroker
    s = Settings()
    s.daily_max_loss, s.tick_seconds = 200, 60
    for k, v in kw.items():
        setattr(s, k, v)
    b = SimBroker(datetime(2026, 9, 14, 9, 0, tzinfo=NY), equity=25000, seed=3)
    e = Engine(s, b, Learner())
    e.running = True
    return e


@test("night mode: window, direction and shorts gate")
def _():
    e = _engine(night_short=True, night_dir="buy")
    n = lambda h, m: datetime(2026, 9, 14, h, m, tzinfo=NY)
    assert e.night_window(n(20, 0)) and e.night_window(n(6, 59)) and not e.night_window(n(7, 0)) and not e.night_window(n(19, 59))
    assert e.night_dir() == "buy" and e.shorts_allowed(n(22, 0)) is False, "night buys mode must not allow shorts"
    e.s.night_dir = "sell"
    assert e.night_dir() == "sell" and e.shorts_allowed(n(22, 0)) is True
    e.s.night_short = False
    assert not e.night_window(n(22, 0))


def _wave_rows(eng):
    def fake(now):
        out = []
        for sy in list(eng.broker.day_bars)[:4]:
            px = eng.broker._px(sy)
            out.append({"symbol": sy, "side": "up", "kind": "CLOSE_HIGH", "name": "CLOSE HIGH CONTINUATION", "score": 80 if sy != list(eng.broker.day_bars)[3] else 60,
                        "label": "STRONG", "hit_rate": 80, "n": 12, "zone": [round(px * 0.995, 2), round(px * 1.005, 2)],
                        "stop": round(px * 0.985, 2), "tp1": round(px * 1.012, 2), "tp2": round(px * 1.02, 2), "atr": px * 0.02})
        return out
    return fake


@test("wave trader: off by default, honours window, min score, max trades, zone, and halts")
def _():
    from autobot import db
    e = _engine(wave_min_score=70, wave_from=570, wave_until=700, wave_max_trades=2, wave_trade=False)
    e._wave_rows = _wave_rows(e)
    seen = []
    orig_bracket, orig_ext = e.broker.submit_bracket, e.broker.submit_limit_ext
    e.broker.submit_bracket = lambda *a, **k: (seen.append(("REG", a, e.broker.now())), orig_bracket(*a, **k))[1]
    e.broker.submit_limit_ext = lambda *a, **k: (seen.append(("EXT", a, e.broker.now())), orig_ext(*a, **k))[1]
    def run_until(h, m):
        guard = 0
        while (e.broker.now().hour, e.broker.now().minute) < (h, m) and guard < 4000:
            w = e.tick()
            e.broker.sleep(w or 60)
            guard += 1
    # 1) switch OFF -> nothing from the wave trader
    run_until(10, 0)
    wave_trades = [t for t in e.trades.values() if t.strategy == "WAVE"]
    assert not wave_trades and not getattr(e, "wave_done", None), "wave trader traded while switched OFF"
    # 2) ON, inside the window
    e.s.wave_trade = True
    run_until(10, 30)
    done = getattr(e, "wave_done", set())
    assert 1 <= len(done) <= 2, f"expected 1-2 wave entries, got {len(done)}"
    assert all(s in [x["symbol"] for x in e._wave_rows(None) if x["score"] >= 70] for s in done), "entered a setup under the min score"
    for kind, a, t in seen:
        if a[0] in done:
            assert 570 <= t.hour * 60 + t.minute < 700, "wave order outside its window"
    rows = [r for r in db.recent(500) if r["strategy"] == "WAVE"]
    for r in rows:
        assert r["stop"] < r["entry"] < r["target"], f"bad levels {r}"
        assert r["risk"] <= 0.15 * 200 * 0.5 * 1.05 + 1e-6, f"risk {r['risk']} over budget"
    # 3) halted risk -> no entries
    e2 = _engine(wave_trade=True, wave_min_score=70, wave_from=570, wave_until=700)
    e2._wave_rows = _wave_rows(e2)
    first = True
    for _ in range(400):
        w = e2.tick(); e2.broker.sleep(w or 60)
        if first:   # the first tick runs the new-day reset, which clears any halt; halt after it
            first = False
            e2.risk.halted, e2.risk.halt_reason = True, "test halt"
            e2.wave_done = set()
        if e2.broker.now().hour >= 10:
            break
    assert not getattr(e2, "wave_done", None), "wave trader traded while the daily loss limit had halted trading"


# ---------------------------------------------------------------- morning wave setups
@test("morning wave: pattern that always follows through is listed; one that never does is not")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    def build(follow):
        rows, px = [], 100.0
        days = pd.bdate_range("2026-08-20", "2026-10-05")
        prev_strong = False
        for i, day in enumerate(days):
            idx = pd.date_range(f"{day.date()} 04:00", f"{day.date()} 19:45", freq="15min", tz=NY)
            strong = (i % 2 == 0)
            for t in idx:
                reg = dtime(9, 30) <= t.time() < dtime(16, 0)
                o = px
                if reg:
                    frac = (t.hour * 60 + t.minute - 570) / 390
                    px = px * (1 + (0.0006 if strong else -0.0006) * (1 if frac < 0.9 else 1))
                else:
                    if prev_strong and follow and t.time() >= dtime(9, 0):
                        px = px * 1.0012                          # next morning pushes up
                    else:
                        px = px * (1 + 0.00001)
                rows.append((t, o, max(o, px) * 1.0003, min(o, px) * 0.9997, px, 1000))
            prev_strong = strong
        return pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
    yes = mw.analyze("AAA", build(True))
    no = mw.analyze("BBB", build(False))
    if yes:
        assert yes["side"] == "up" and yes["stop"] < yes["zone"][0] <= yes["zone"][1] < yes["tp1"] < yes["tp2"], yes
        assert 0 <= yes["score"] <= 100 and 0 <= yes["hit_rate"] <= 100
    assert no is None or no["hit_rate"] < 100, "a pattern with no follow-through must not show a perfect hit rate"
    rise, fall = mw.build({"AAA": build(True), "BBB": build(False)})
    assert isinstance(rise, list) and isinstance(fall, list)


# ---------------------------------------------------------------- options
@test("options: build_plan sizing never breaks the premium, budget or contract limits")
def _():
    from autobot import options as O
    today = date(2026, 10, 6)
    exp = today + timedelta(days=9)
    ch = [{"symbol": f"C{k}", "strike": float(k), "expiry": exp, "oi": 800} for k in range(95, 106)]
    quotes = {c["symbol"]: (max(0.05, 100 - c["strike"] + 3.0), max(0.05, 100 - c["strike"] + 3.1)) for c in ch}
    for style in ("spread", "long"):
        cfg = {"min_dte": 5, "min_oi": 100, "style": style, "max_premium": 200.0, "max_contracts": 3, "stop_pct": 40.0, "tp_pct": 50.0, "room": 150.0,
               "flatten_min": 900, "hold_overnight": False}
        plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
        if plan:
            assert plan["qty"] >= 1 and plan["qty"] <= 3
            assert plan["cost"] <= 200.0 + 1e-6, plan
            assert plan["risk_at_stop"] <= 150.0 + 1e-6, plan
    cfg["max_premium"] = 1.0
    plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
    assert plan is None, "an option costing more than the per-trade limit must not be planned"


@test("options: stock, per-stock, call and put limits plus greeks")
def _():
    import pandas as pd
    from types import SimpleNamespace as NS
    from autobot.config import Settings
    from autobot import options as O
    s = Settings(); s.options_on = True
    b = O.OptionsBot(lambda: None, s)
    b._account_level = lambda e: 3
    b._room = lambda e: 300
    opened = []
    b._open = lambda e, u, d, why, px, room, reg: (opened.append((u, d)) or True)
    O.signal = lambda *a, **k: ("call", "t")
    bars = {u: pd.DataFrame({"close": [100.0]}) for u in s.options_underlyings}
    e = NS(mode="PAPER", bars_last=bars, regime={}, bias=0, ribbons={})
    now = datetime(2026, 10, 6, 10, 30)
    def run(rows, **kw):
        for k, v in kw.items():
            setattr(s, k, v)
        b.pos = {f"p{i}": {"status": "open", "underlying": u, "direction": d} for i, (u, d) in enumerate(rows)}
        opened.clear(); b.confirm = {}; b.cool = {}
        for _ in range(2):
            b._entries(e, now)
        return list(opened)
    assert run([]), "nothing open: it should open a trade"
    assert run([("SPY", "call")], options_max_stocks=1, options_max_positions=4) == [], "max stocks ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=1) == [], "max calls ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=6, options_max_per_stock=2), "per-stock 2 should allow a second SPY trade"
    assert run([("SPY", "call"), ("QQQ", "put")], options_max_stocks=2, options_max_positions=2, options_max_per_stock=1) == [], "total cap ignored"
    b.greeks = {"L": {"delta": .55, "gamma": .04, "theta": -.12, "vega": .2, "rho": .01, "iv": .4}, "S": {"delta": .4, "gamma": .03, "theta": -.09, "vega": .15, "rho": .01, "iv": .38}}
    g = b.net_greeks("L", "S")
    assert abs(g["delta"] - .15) < 1e-9 and abs(g["theta"] + .03) < 1e-9 and b.net_greeks("L", "X") is None
    pg = b._pos_greeks({"qty": 2, "greeks": g})
    assert abs(pg["pos_delta"] - 30) < 1e-6 and abs(pg["pos_theta"] + 6) < 1e-6


# ---------------------------------------------------------------- API
@test("API: every GET endpoint answers (no 500s) and POSTs keep the daily limit")
def _():
    import socket, urllib.request, urllib.error
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    d = Path(TMP) / "api"; d.mkdir()
    env = dict(os.environ, AUTOBOT_DATA=str(d))
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--host", "127.0.0.1", "--sim", "--speed", "60"],
                         cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/version", timeout=2).read(); break
            except Exception:
                time.sleep(1)
        else:
            raise AssertionError("server did not start: " + (p.stderr.read(600).decode() if p.poll() is not None else "timeout"))
        def get(path):
            try:
                return urllib.request.urlopen(base + path, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        def post(path, body):
            req = urllib.request.Request(base + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
            try:
                return urllib.request.urlopen(req, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        post("/api/start", {})
        time.sleep(3)
        spec = json.loads(urllib.request.urlopen(base + "/openapi.json").read())
        bad = []
        skip = ("/docs", "/openapi", "/redoc", ".csv", "export", "download", "backup", "/api/app/update", "/logs/stream")
        n = 0
        for path, ops in spec["paths"].items():
            if "get" in ops and "{" not in path and not any(x in path for x in skip):
                st = get(path); n += 1
                if st >= 500:
                    bad.append(f"{path} -> {st}")
        assert not bad, "GET endpoints failing: " + "; ".join(bad)
        before = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        for path, body in (("/api/wave", {"on": True, "min_score": 75}), ("/api/wave", {"on": False}), ("/api/night", {"on": True, "dir": "buy"}),
                           ("/api/options/config", {"max_stocks": 3, "max_calls": 2, "max_puts": 2, "max_per_stock": 2, "min_delta": 0.3}),
                           ("/api/options/config", {"max_stocks": 0, "min_delta": 5})):
            st = post(path, body)
            assert st < 500, f"POST {path} -> {st}"
        wv = json.loads(urllib.request.urlopen(base + "/api/wave").read())
        assert wv["on"] is False and wv["min_score"] == 75
        opt = json.loads(urllib.request.urlopen(base + "/api/options/status").read())
        assert opt["on"] is False, "options must stay off unless switched on"
        after = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        assert before == after, f"daily loss limit changed {before} -> {after}"
        mw = json.loads(urllib.request.urlopen(base + "/api/morningwave?force=1").read())
        assert "rise" in mw and "fall" in mw
        for r in mw["rise"]:
            assert r["stop"] < r["zone"][0] and r["tp1"] > r["zone"][1], r
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:
            p.kill()



# ---------------------------------------------------------------- scalping + harvest
def _mk_trade(profile="SCALP", entry=100.0, stop=99.0, side="buy", **kw):
    from autobot.engine import Trade
    t = Trade("t1", "ZZZ", side, "EMA_PULLBACK", profile, "AM", 10, entry, stop, stop, entry + 2, 0.5, 10.0,
              datetime(2026, 9, 14, 10, 0, tzinfo=NY), "o1", status="open", **kw)
    return t


@test("scalping: quick-harvest banks a stalled green trade, not a red or fresh one; only for scalp profiles")
def _():
    e = _engine(let_run=False, scale_out=False, scalp_mode=True)
    assert e._harvest_profile("QUICK") == "SCALP"
    e.s.scalp_mode = False
    assert e._harvest_profile("QUICK") == "QUICK"
    e.s.let_run = e.s.scale_out = True
    assert e._harvest_profile("QUICK") == "SCALE", "let-winners-run must disable scalp profiles"
    e.s.let_run = False
    t = _mk_trade("SCALP")
    assert e._quick_harvest(t, 0.5) is False, "must not bank on the first green check"
    assert e._quick_harvest(t, 0.5) is True or e._quick_harvest(t, 0.5) is False
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.7)
    assert e._quick_harvest(t, 0.7) is False, "still rising: let it run"
    assert e._quick_harvest(t, 0.5) is False or t.pos_ticks >= 0
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.8)
    assert e._quick_harvest(t, 0.6) is True, "gave back 0.2R from the best after 2 green checks: bank it"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.3); e._quick_harvest(t, 0.3)
    assert e._quick_harvest(t, -0.2) is False, "a red trade is never 'harvested'"
    t = _mk_trade("SCALE"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 0.5) is False, "non-scalp profiles are untouched"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.5); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 1.1) is True, "near the 1.2R scalp target: take it"


@test("scalping: give-back lock never hands back more than the allowed share of the best gain")
def _():
    e = _engine()
    t = _mk_trade("SCALE", entry=100, stop=99)            # 1R = $1
    lvl, ex = e._gain_lock(t, 0.4)
    assert lvl is None and not ex, "no lock below +0.6R"
    lvl, ex = e._gain_lock(t, 1.0)
    assert abs(lvl - 100.4) < 1e-9 and not ex, f"lock at 40% of 1.0R expected, got {lvl}"
    lvl, ex = e._gain_lock(t, 0.39)
    assert ex, "falling through the lock must exit"
    lvl, ex = e._gain_lock(t, 2.5)
    assert abs(lvl - 100 - 0.6 * 2.5) < 1e-9, "60% lock from 2R"
    s = _mk_trade("SCALE", entry=100, stop=101, side="sell")      # short: lock is below entry
    lvl, ex = e._gain_lock(s, 1.0) if s.dir < 0 else (None, False)
    assert lvl is None or lvl < 100, "short lock must sit below entry"


@test("harvest (halt): winners kept with a ratcheting profit lock that never goes below break-even or backwards")
def _():
    e = _engine()
    e.profit_locks = {}
    e.broker.update_stop = lambda *a, **k: None
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 104.0})
    lk1 = e.profit_locks["ZZZ"]
    assert abs(lk1 - (100 + 2 + 0.1)) < 1e-9, lk1
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 102.0})
    assert e.profit_locks["ZZZ"] == lk1, "lock must not move back down"
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 110.0})
    assert e.profit_locks["ZZZ"] > lk1
    e._lock_update("YYY", {"qty": 10, "avg_entry": 100.0, "price": 99.0})
    assert "YYY" not in e.profit_locks, "a loser gets no lock"
    e._lock_update("SSS", {"qty": -10, "avg_entry": 50.0, "price": 48.0})
    assert e.profit_locks["SSS"] < 50.0, "short lock sits below entry"


def _fake_harvest(price=100.0, spread=0.02, A=0.5, held=10, halted=False):
    import time as _t
    from types import SimpleNamespace as NS
    from autobot.harvester import Harvester
    calls = []
    state = {"bid": price - spread / 2, "ask": price + spread / 2, "held": held}
    broker = NS(positions=lambda: ({"ZZZ": {"qty": state["held"], "avg_entry": 100.0, "price": state["bid"]}} if state["held"] else {}),
                cancel_symbol_orders=lambda s: None)
    e = NS(risk=NS(halted=halted), trades={}, broker=broker)
    h = Harvester.__new__(Harvester)
    import threading
    h.get_engine = lambda: e; h.quote_fn = lambda e_, s, sess: (state["bid"], state["ask"]); h.session_fn = lambda e_: "REGULAR"
    h.open_fn = lambda *a: calls.append(("open",) + a[1:3])
    h.close_fn = lambda *a: calls.append(("close",) + a[1:4])
    h.path = Path("/tmp/reg_harvest_test.json"); h.jobs = {}; h.lock = threading.RLock(); h._bars = {}
    h._save = lambda: None
    h._say = lambda *a, **k: None
    h._bars["ZZZ"] = (_t.time() + 1e6, A, None, [100.0, 100.1])       # fixed A, bounce candle up
    return h, e, state, calls


@test("harvest: sells at +0.5 A, never for less than the spread, stalls bank, then re-enters on a pullback")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10)
    j = h.jobs["ZZZ"]; pos = e.broker.positions(); now = _t.time()
    h.step(e, j, pos, "REGULAR", now); assert j["phase"] == "holding"
    st["bid"], st["ask"] = 100.10, 100.12                       # +0.2 A: not yet
    h.step(e, j, e.broker.positions(), "REGULAR", now + 5); assert not calls
    st["bid"], st["ask"] = 100.30, 100.32                       # +0.6 A: harvest
    h.step(e, j, e.broker.positions(), "REGULAR", now + 10)
    assert calls and calls[0][0] == "close" and j["phase"] == "exiting", calls
    st["held"] = 0
    h.step(e, j, e.broker.positions(), "REGULAR", now + 15)
    assert j["phase"] == "waiting" and j["cycles"] == 1 and j["banked"] > 0, j
    # no pullback yet -> no re-entry; then a pullback of > 0.25 A with an up-candle -> buys again
    st["bid"], st["ask"] = 100.32, 100.34
    h.step(e, j, e.broker.positions(), "REGULAR", now + 20)
    assert len(calls) == 1, "re-entered without a pullback"
    st["bid"], st["ask"] = 100.10, 100.12
    h.step(e, j, e.broker.positions(), "REGULAR", now + 25)
    assert calls[-1][0] == "open" and j["phase"] == "entering", (calls, j["msg"])
    st["held"] = 10
    h.step(e, j, e.broker.positions(), "REGULAR", now + 30); assert j["phase"] == "holding"
    # wide spread: a tiny gain that does not pay for the round trip is not harvested
    h2, e2, st2, c2 = _fake_harvest(spread=0.40)
    h2.arm("ZZZ", "buy", 10); j2 = h2.jobs["ZZZ"]; n = _t.time()
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n)
    st2["bid"], st2["ask"] = 100.26, 100.66
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n + 5)
    assert not c2, "harvested a gain smaller than the spread cost"


@test("harvest: Harvest-now sells immediately; protective stop closes and ends the job; halt and overnight are respected")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n)
    j["sess_t"] = n - 999
    assert "Selling" in h.now("ZZZ")
    h.step(e, j, e.broker.positions(), "REGULAR", n + 4)
    assert calls and calls[0][0] == "close", "Harvest now did not sell"
    # protective stop: 2.4 A against the entry (hard stop) closes straight away and drops the job
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 98.7, 98.72
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0][0] == "close" and "ZZZ" not in h.jobs, (calls, h.jobs)
    # halted -> job stops, no orders
    h, e, st, calls = _fake_harvest(halted=True)
    h.arm("ZZZ", "buy", 10); h.step(e, h.jobs["ZZZ"], e.broker.positions(), "REGULAR")
    assert "ZZZ" not in h.jobs and not calls
    # overnight pause: no automatic sale at +1 A, but the Harvest-now button still works
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 100.6, 100.62
    h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 5)
    assert not calls, "automatic harvest ran overnight"
    h.now("ZZZ"); h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 9)
    assert calls and calls[0][0] == "close"
    # short side mirrors: gain when price falls
    h, e, st, calls = _fake_harvest()
    st["held"] = -10
    e.broker.positions = lambda: {"ZZZ": {"qty": -10, "avg_entry": 100.0, "price": st["ask"]}}
    h.arm("ZZZ", "sell", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 99.68, 99.70
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0] == ("close", "ZZZ", 10, "sell"), calls


@test("learn: floor/ceiling/trend reading is sane on rising, falling and flat charts")
def _():
    import pandas as pd, numpy as np
    from autobot import learn
    def mk(path):
        idx = pd.bdate_range(end="2026-09-14", periods=len(path)).tz_localize(NY)
        c = np.array(path, float)
        return pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c * 1.01, "low": c * 0.99, "close": c, "volume": 1e6}, index=idx)
    up = learn.read(mk([100 + i * 0.6 + (3 if i % 7 == 0 else 0) for i in range(120)]), "UP")
    assert up["trend"] == "UP", up["trend"]
    dn = learn.read(mk([200 - i * 0.6 - (3 if i % 7 == 0 else 0) for i in range(120)]), "DN")
    assert dn["trend"] == "DOWN", dn["trend"]
    assert not any(p["kind"] == "BUY" for p in dn["plan"]), "must not suggest buying a falling stock"
    flat = learn.read(mk([100 + 5 * np.sin(i / 4) for i in range(120)]), "FLAT")
    assert flat["floor"] and flat["ceiling"] and flat["floor"]["price"] < flat["price"] < flat["ceiling"]["price"], flat
    for r in (up, dn, flat):
        for p in r["plan"]:
            if p.get("stop") and p["zone"] and p["kind"] == "BUY":
                assert p["stop"] < p["zone"][0], f"stop not below the buy zone {p}"
    assert learn.read(mk([100] * 10), "X").get("error")


# ---------------------------------------------------------------- journal audit of simulator runs
def audit_journal(db_file, limit, max_notional, label):
    import sqlite3
    c = sqlite3.connect(db_file); c.row_factory = sqlite3.Row
    rows = [dict(r) for r in c.execute("SELECT * FROM trades WHERE status='closed' ORDER BY opened_at")]
    problems = []
    by_day = {}
    open_iv = {}
    for r in rows:
        side = 1 if r["side"] == "buy" else -1
        if r["qty"] is None or r["qty"] <= 0:
            problems.append(f"{r['id']} qty {r['qty']}")
        if (r["stop"] - r["entry"]) * side >= 0 and r["bucket"] != "MANUAL":
            problems.append(f"{r['symbol']} {r['strategy']} stop {r['stop']:.2f} on the wrong side of entry {r['entry']:.2f}")
        if r["qty"] * r["entry"] > max_notional * 1.05 + 1 and not r["id"].startswith("m"):
            problems.append(f"{r['symbol']} notional ${r['qty']*r['entry']:,.0f} over the ${max_notional:,.0f} cap")
        by_day[r["day"]] = by_day.get(r["day"], 0.0) + (r["pnl"] or 0.0)
        if r["pnl"] is not None and r["exit"] is not None:
            calc = (r["exit"] - r["entry"]) * side * r["qty"]
            if abs(calc - r["pnl"]) > max(0.05, 0.02 * abs(calc)) and abs(r["pnl"]) > 0.5:
                problems.append(f"{r['symbol']} pnl {r['pnl']:.2f} != (exit-entry)*qty {calc:.2f}")
        iv = open_iv.setdefault(r["symbol"], [])
        if r["closed_at"] and r["opened_at"]:
            for a, b in iv:
                if r["opened_at"] < b and r["closed_at"] > a:
                    problems.append(f"{r['symbol']} two positions open at once ({r['opened_at'][:16]})")
                    break
            iv.append((r["opened_at"], r["closed_at"]))
    worst = min(by_day.values()) if by_day else 0.0
    return {"trades": len(rows), "pnl": round(sum(by_day.values()), 2), "worst_day": round(worst, 2), "problems": problems[:12], "n_problems": len(problems)}


if __name__ == "__main__":
    only_audit = len(sys.argv) > 1 and sys.argv[1] == "audit"
    if only_audit:
        out = {}
        for arg in sys.argv[2:]:
            name, dbp, lim = arg.split(":")
            out[name] = audit_journal(dbp, float(lim), 10000.0, name)
        print(json.dumps(out, indent=1))
        sys.exit(0)
    w = max(len(n) for n, *_ in RESULTS)
    fails = 0
    for n, st, msg, dt in RESULTS:
        print(f"{st:5s} {n:{w}s} ({dt:5.1f}s)")
        if st != "PASS":
            fails += 1
            print("      " + msg.replace("\n", "\n      "))
    print(f"\n{len(RESULTS) - fails}/{len(RESULTS)} passed")
    sys.exit(1 if fails else 0)
