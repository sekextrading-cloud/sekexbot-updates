# SekexBot

**Version 1.69.1** (2026-10-03) — this copy is the **Android edition**; see [README_ANDROID.md](README_ANDROID.md) first. See [CHANGELOG.md](CHANGELOG.md) for what changed in each release. The running version shows in the dashboard header.

This is a self-learning day-trading bot for your Alpaca account. You set one number, your **daily max loss**, and press **Start**. After that the bot:

1. **Picks the best stocks for your account** about 20 minutes before the open, again every 30 minutes, or whenever you press **Scan now**. It looks at about 300 stocks: Alpaca's most-active lists, the day's top gainers and losers, about 90 liquid leaders and your watchlist. Each one gets two scores:
   - **Opportunity:** the gap, relative volume, a healthy daily range (2–7% ATR is ideal), trend (near a 20-day high or low) and whether it's a top mover.
   - **Fit:** how a normal-sized trade works with *your* daily limit and buying power. It checks how many shares that would be, whether the whole risk budget fits under the per-position cap, and whether your order is a tiny slice of a typical minute's volume.

   The final score is the two multiplied together. A $2,000 account gets cheaper, liquid movers, and stocks it can't hold at least 3 shares of are skipped. A $250,000 account can use high-priced leaders but skips thin stocks. The **Stock picker** table shows the top picks with the reasons for each. Volume and ATR come from Alpaca's full-market (SIP) history, which the free plan allows for data older than 15 minutes, so the numbers aren't limited to IEX volume.
2. **Watches every symbol on 1-minute bars all session** and looks for six setups:

   | Setup | What it looks for |
   |---|---|
   | RIBBON_FLIP | The EMA ribbon (fast yellow line, slow white line, green/red fill) flips green and price closes above the white line. This is the indicator from your TradingView chart. |
   | ORB | A breakout of the first 15-minute opening range on strong volume |
   | GAP_GO | A gapper (2%+) breaking to a new high or low of the day, with VWAP (before 10:45); long or short |
   | GAP_FADE | A gap that fails: gap-up losing the opening-range low + VWAP shorts (SPCX Sep 28), gap-down reclaiming the range high + VWAP goes long |
   | EXT_TREND | Pre-market / after-hours continuation of a 1.2%+ mover with the ribbon and VWAP, long or short |
   | VWAP_RECLAIM | Price reclaims VWAP with the short EMA rising |
   | EMA_PULLBACK | A trend-continuation bounce off EMA9 after a fresh high |
   | MEAN_REVERT | A washed-out flush more than 2.2 ATR below VWAP that starts reversing |

   The **ribbon is also a trend filter**. The other setups only go long while the ribbon is green, and only go short while it's red (shorting is off unless you turn it on).
3. **Learns how to get in and how to get out.** Every setup is paired with four exit plans:
   - QUICK: take profit at 1.2R.
   - STANDARD: take profit at 2R, and move the stop to breakeven at 1R.
   - RUNNER: target 3.5R, move to breakeven at 1R, then trail the stop.
   - RIBBON: ride the trade until the ribbon flips back.

   After each trade the result in R (profit ÷ risk) goes into a Thompson-sampling learner. It favors the setup/exit pairs that work, benches the ones that keep losing, and tracks results by time of day. Its stats decay slightly each day so it keeps adapting.
4. **Sizes trades from your daily limit.** Base risk per trade is 15% of the daily limit, scaled up or down by how confident the learner is in that setup. Before any new trade, the risk to stop of all open trades plus the new one must fit inside what's left of the daily limit.
5. **Protects the day:**
   - Daily loss limit hit: cancel pending bot entries, close every **losing** position (bot and manual), keep winners open with a **profit lock** (stop raised to at least break-even, then to half the best gain, rising with the price; if the price falls back to it the position is sold and the profit banked), and open no new trades until tomorrow.
   - Up by at least your limit and then gives back half the peak: stop and keep the rest.
   - 3 losses in a row: pause new entries for 20 minutes, then trade at half size.
   - A symbol loses twice in one day: the bot stops trading it for the day.
   - Every entry is a **bracket order**, so the stop and target sit on Alpaca's servers even if your PC goes down.
   - Everything is flattened 8 minutes before the close. The bot never holds overnight.
6. **Runs day after day** until you press Stop.

## After-hours and overnight trading

You can switch each session on or off from the dashboard. By default after-hours and overnight are on, and pre-market is off.

| Session (ET) | What it trades |
|---|---|
| After-hours, 4:00–8:00 PM | Earnings and news movers since the close |
| Overnight, 8:00 PM–4:00 AM, Sunday–Thursday nights | Alpaca 24/5 stocks (`overnight_tradable`) |
| Pre-market, 4:00–9:30 AM | Movers vs yesterday's close |

Extended hours work differently from regular hours:

- **Limit orders only, and no server-side bracket stops.** The bot leaves a take-profit order resting at Alpaca, but it watches the stop itself every 15 seconds and exits with a marketable limit order, re-pricing it until it fills. **Keep the bot running while it holds a night position.**
- **Safer by design:**
  - Long only.
  - Half the normal risk per trade.
  - At most 2 positions.
  - Spreads over 0.6% are skipped.
  - It won't chase a price that has already run.
  - Every position is closed 10 minutes before its session ends.
- **Setups:** EXT_MOMENTUM (a stock moving since the close that breaks its session high above session VWAP) and a long-only RIBBON_FLIP. The learner tracks these separately per session, e.g. `EXT_MOMENTUM@AFTER`.
- **Overnight data:** trade prints are delayed overnight, so the bot builds its own 1-minute chart from real-time quotes. It needs about 30 minutes after the session opens before the ribbon is ready.
- **Free IEX data** only covers about 8:00 AM–5:00 PM. On IEX the bot trades pre-market from 8:00 AM and after-hours only until 5:00 PM. Overnight uses Alpaca's separate overnight feed. For full 4 AM–8 PM coverage, switch to SIP (Alpaca's paid Algo Trader Plus).
- **The daily loss limit** runs from 8 PM to 8 PM ET, so a night session counts toward the next trading day. If you hit the limit during the day, the bot also sits out that evening's after-hours session.
- **Stale data:** if quotes for an open position stop updating for 5 minutes, the bot exits.

## BullGPT-style chart reader

The **AI chart read** panel on the dashboard has two tools.

- **Screenshot → game plan.** Drag a chart screenshot onto the box, paste it with Ctrl+V, or click to choose a file. It works with TradingView, Robinhood, Webull, thinkorswim or any other chart. You can also add a question, such as *"When is the morning setup for Monday?"*. Claude reads the chart and returns:
  - the trend, with what it sees on the chart
  - resistance and support levels, with notes
  - timing windows (pre-market, opening range, best entry window)
  - bull, range and bear scenarios with trigger, entry, stop and targets
  - its lean, and what would prove it wrong
  - an answer to your question
  - how the bot's own setups would treat the chart

  The bot works out the R:R itself rather than trusting the AI's math, and it flags any stop placed on the wrong side of the entry. When the ticker is recognized, it shows the live price and adds buttons to put the ticker on your watchlist or analyze it with live data.
  To use it, paste your Claude API key into the box on the dashboard; it's saved to your `.env` file. The bot picks the newest Sonnet model automatically, or you can set `ANTHROPIC_MODEL` to choose one.
- **Analyze live chart** works for any ticker with no API key. It computes levels, Fibonacci, RSI, VWAP, ribbon state and bias from the bot's own data, plus bull and bear plans.

Levels read from a screenshot are estimates from the image. Check them against a live chart.

## Your watchlist

Add tickers (SPCX is there to start) above the ribbon chart. Watchlist symbols are scanned and traded every session, pre-market, regular, after-hours and overnight, even when they aren't gapping or among the most active. They skip the liquidity filters but still have to be tradable on Alpaca.

## Phone access (Cloudflare Tunnel)

Click **📱 Phone access** on the dashboard of the computer running SekexBot.

1. **Set a dashboard password.** You can't turn on phone access without one. The password is stored only as a salted hash.
2. **Connect**, using one of two options:
   - **⚡ Quick link:** one click, no Cloudflare account needed. You get a random `https://…trycloudflare.com` address that changes every time the tunnel restarts.
   - **🌐 My domain (permanent):** in Cloudflare Zero Trust, go to **Networks → Tunnels → Create a tunnel** (Cloudflared) and copy the install command. Paste the command and your hostname (for example `bot.sekexpro.com`) into SekexBot. In Cloudflare, set the tunnel's public hostname to point at `HTTP localhost:8010`. Tick "Connect automatically" and SekexBot reconnects every time it starts.
3. **Scan the QR code** with your phone, sign in, then use **Add to Home Screen** (iPhone) or **Install app** (Android) to get a SekexBot app icon.

How it's protected:

- **Nothing is exposed on your network.** SekexBot only listens on 127.0.0.1, and cloudflared makes an outgoing connection. You don't open any router ports.
- **Every request through the tunnel needs a login.** Sessions last 30 days, are signed, and are cancelled if you change the password. Sign-in is locked for 15 minutes after 5 wrong attempts.
- **From the phone you can do nearly everything**: start and stop the bot, change the daily limit, flatten positions, use the watchlist and chart reads. Switching to live still asks for your Live PIN.
- **Some settings only work on the computer running SekexBot:** broker and API keys, and the phone-access settings themselves.
- **For extra protection, add Cloudflare Access** (Zero Trust → Access → Applications) with a rule that allows only your email address.
- **cloudflared downloads automatically** into the `tools` folder the first time you connect (about 50 MB). On the portable edition it stays on the drive.

## Setup (Windows)

1. Install Python 3.11 or newer from python.org, and tick "Add to PATH".
2. Double-click **`start_simulator.bat`** first. It runs a fake market (no keys needed) so you can learn the dashboard.
3. Double-click **`start_bot.bat`**. The dashboard opens at http://127.0.0.1:8010.
4. Click **🔑 Broker keys**. It opens by itself the first time. Paste your Alpaca **paper** Key ID and Secret, press **Test connection**, then **Save & connect**. The steps for finding your keys are shown right there.
5. Set your daily max loss and press **Start Auto-Trader**.

On Mac or Linux, use `./start_bot.sh` (add `--sim` for the simulator).

## Going live

Let it trade paper for several weeks first. The learner needs real trades to learn from. When you're ready:

1. In **🔑 Broker keys → Live**, add your live Key ID and Secret (these start with AK) and set a Live PIN.
2. Stop the bot, click **Switch to LIVE** and enter the PIN.

The learned stats carry over from paper.

## Things to know

- **Use a dedicated account, or leave it only to the bot.** The daily limit is measured on account equity, and hitting it closes all positions in the account.
- **Your PC must stay on and awake during market hours**, because the bot runs on it. Open trades keep their server-side stop and target even if it goes down.
- **Data feed:** IEX is free but covers only part of the market's volume. SIP (Alpaca's paid plan) gives full-market data and better signals.
- **Pattern-day-trader rule:** FINRA replaced the $25k PDT rule with new intraday margin standards effective June 4, 2026, and Alpaca switched on that date to its Intraday Margin Framework. There is no day-trade count and no $25k minimum anymore. Accounts with $2,000 or more get up to 4x intraday buying power, and orders that would create a margin deficit are refused before they're placed. Repeatedly missing intraday margin calls can restrict an account for 90 days. The bot sizes every trade within your buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders.
- **Slippage and gaps can push a loss slightly past the limit.** Entries use marketable limit orders capped at 0.15% slippage, and a gap through a stop can overshoot by a few dollars.
- **Remote access:** use 📱 Phone access (see above). Don't forward ports to the dashboard.

## Offline test

```
python simulate.py --days 20 --fresh
```

This runs the real engine against synthetic market days and prints daily P&L and what the learner picked up. It checks the mechanics (fills, stops, daily limit, learning). **It says nothing about real profitability.**

## Files

```
server.py            dashboard + control API
simulate.py          fast offline simulation
autobot/engine.py    main loop: scan -> signals -> orders -> manage -> learn
autobot/strategies.py  the six entry setups + ribbon trend filter
autobot/indicators.py  EMA/RSI/ATR/VWAP + EMA ribbon
autobot/learner.py   Thompson-sampling strategy/exit learner
autobot/risk.py      daily-limit risk manager and position sizing
autobot/analyst.py   BullGPT-style chart read + screenshot analysis
autobot/broker.py    Alpaca adapter (alpaca-py)
autobot/sim.py       offline market simulator
data/                settings, learner memory, trade journal (SQLite), logs
```

This is software, not financial advice. Automated trading can lose money, including more than the daily limit in fast markets.
