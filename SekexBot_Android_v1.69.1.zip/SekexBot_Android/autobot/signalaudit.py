"""📊 Review my signals: grade every BUY / SELL and BUY? / SELL? on your real price data, then ask Claude.

audit() works on the last few days of 1-minute bars for your watchlist and the stocks you traded:
  * confirmed flips (the solid BUY / SELL): how LATE each one was (how much of the move from the last swing
    low/high was already gone, in ATRs) and whether price FOLLOWED THROUGH over the next 5 candles,
  * early warnings (BUY? / SELL?): hit rate, how many candles early, price gained vs waiting,
  * the same, split by session (pre-market / regular / after-hours / overnight) and by timeframe,
  * a small grid test of the warning settings (confidence cutoff, how soon the lines must cross, how much
    the ribbon must thin, the after-hours penalty) on the SAME data, so a suggestion is backed by numbers,
  * your trade journal by strategy, the "Why no trade?" skips, and repeated errors from the log.
review() sends that summary (no keys, no account numbers) with your question to Claude and returns its
findings plus an optional tuning proposal, clamped to safe limits. Applying tuning only changes the early
warnings (display and alerts); it never changes how the bot trades."""
import itertools
import json
import os
import re
import threading
import time
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
import requests

from . import db
from .analyst import _api_error, _base, _pick_model
from .helpdesk import recent_log, redact
from .indicators import ribbon
from .predict import DEFAULTS, LIMITS, clamp_tune, get_tune, predict

TFS = (1, 3, 5)
MAX_SYMS = 12
FOLLOW = 5            # candles to judge follow-through after a signal
SWING = 12            # candles back to find the swing low/high a signal should have caught


def _sess(ts):
    hm = ts.hour * 60 + ts.minute
    return "regular" if 570 <= hm < 960 else "pre" if 240 <= hm < 570 else "after" if 960 <= hm < 1200 else "overnight"


def _flips(h: pd.DataFrame):
    """Every confirmed flip with lateness and follow-through, in ATR units."""
    st, c, hi, lo = h["state"].values, h["close"].values, h["high"].values, h["low"].values
    a = h["atr"].replace(0, np.nan).bfill().ffill().values
    out = []
    for i in range(1, len(h)):
        if st[i] == 0 or st[i] == st[i - 1] or not (a[i] == a[i]) or a[i] <= 0:
            continue
        d = int(st[i])
        j0 = max(0, i - SWING)
        ext = lo[j0:i + 1].min() if d > 0 else hi[j0:i + 1].max()
        late = (c[i] - ext) * d / a[i]                       # how far price had already moved our way
        k = min(len(h) - 1, i + FOLLOW)
        if k <= i:
            continue
        fwd = (c[k] - c[i]) * d / a[i]
        mfe = ((hi[i + 1:k + 1].max() - c[i]) if d > 0 else (c[i] - lo[i + 1:k + 1].min())) / a[i]
        out.append({"t": h.index[i], "side": "buy" if d > 0 else "sell", "late": float(late), "fwd": float(fwd),
                    "mfe": float(mfe), "sess": _sess(h.index[i]), "complete": k == i + FOLLOW})
    return out


def _agg_flips(fl):
    fl = [f for f in fl if f["complete"]]
    if not fl:
        return None
    late = [f["late"] for f in fl]
    fwd = [f["fwd"] for f in fl]
    return {"n": len(fl), "late_atr_median": round(float(np.median(late)), 2),
            "late_over_1atr_pct": round(100 * sum(x > 1 for x in late) / len(fl)),
            "follow_through_pct": round(100 * sum(x > 0 for x in fwd) / len(fl)),
            "fwd5_atr_avg": round(float(np.mean(fwd)), 2),
            "whipsaw_pct": round(100 * sum(f["mfe"] < 0.3 for f in fl) / len(fl))}


def _agg_preds(ps):
    done = [p for p in ps if p["outcome"] in ("hit", "miss")]
    if not done:
        return None
    hits = [p for p in done if p["outcome"] == "hit"]
    return {"n": len(done), "hit_pct": round(100 * len(hits) / len(done)),
            "lead_avg": round(float(np.mean([p["lead"] for p in hits])), 1) if hits else None,
            "edge_avg": round(float(np.mean([p["edge"] for p in hits])), 3) if hits else None}


def _grid(frames, tf):
    """Try other warning settings on the same bars. Score = hits - 1.5 x false alarms (false alarms hurt more)."""
    base = get_tune()
    grid = {"min_conf": [55, 60, 65, 70, 75], "max_eta": [2.5, 4.0, 5.0], "shrink": [0.55, 0.65, 0.75],
            "ext_penalty": [base["ext_penalty"]]}
    rows = []
    for mc, me, sh, ep in itertools.product(*grid.values()):
        t = {"min_conf": mc, "max_eta": me, "shrink": sh, "ext_penalty": ep}
        hit = miss = 0
        lead = []
        for df in frames.values():
            try:
                r = predict(df, tf, tune=t)
            except Exception:
                continue
            for p in r["preds"]:
                if p["outcome"] == "hit":
                    hit += 1
                    lead.append(p["lead"])
                elif p["outcome"] == "miss":
                    miss += 1
        n = hit + miss
        if n:
            rows.append({"tune": t, "warnings": n, "hit_pct": round(100 * hit / n), "lead": round(float(np.mean(lead)), 1) if lead else None,
                         "score": round(hit - 1.5 * miss, 1)})
    rows.sort(key=lambda r: (-r["score"], -r["hit_pct"]))
    cur = next((r for r in rows if all(abs(r["tune"][k] - base[k]) < 1e-9 for k in ("min_conf", "max_eta", "shrink"))), None)
    return {"current": cur, "best": rows[:5]}


def audit(e, symbols, progress=lambda s: None):
    frames = {}
    for i, sym in enumerate(symbols[:MAX_SYMS]):
        progress(f"Loading price history {i + 1}/{min(len(symbols), MAX_SYMS)}: {sym}")
        try:
            df = e.broker.chart_bars(sym)
            if df is not None and len(df) >= 120:
                frames[sym] = df
        except Exception:
            continue
    if not frames:
        raise RuntimeError("No price history came back from Alpaca for your watchlist. Try again when you're connected.")
    out = {"symbols": list(frames), "days": sorted({str(d) for df in frames.values() for d in df.index.date})[-6:],
           "tuning_now": get_tune(), "by_tf": {}, "by_symbol_3m": {}, "by_session_3m": {}}
    for tf in TFS:
        progress(f"Grading signals on the {tf}-minute chart…")
        fl_all, pr_all = [], []
        for sym, df in frames.items():
            h = ribbon(df, lines=False, tf=f"{tf}min")
            if h is None or len(h) < 30:
                continue
            fl = _flips(h)
            pr = predict(df, tf, h=h)["preds"]
            for p in pr:
                p["sess"] = _sess(h.index[p["i"]])
            fl_all += fl
            pr_all += pr
            if tf == 3:
                out["by_symbol_3m"][sym] = {"flips": _agg_flips(fl), "warnings": _agg_preds(pr)}
        out["by_tf"][f"{tf}m"] = {"flips": _agg_flips(fl_all), "warnings": _agg_preds(pr_all)}
        if tf == 3:
            for s in ("pre", "regular", "after", "overnight"):
                out["by_session_3m"][s] = {"flips": _agg_flips([f for f in fl_all if f["sess"] == s]),
                                           "warnings": _agg_preds([p for p in pr_all if p["sess"] == s])}
    progress("Testing other warning settings on the same data…")
    out["tuning_test_3m"] = _grid(frames, 3)
    # trades
    trades = [t for t in db.recent(600) if t.get("status") == "closed" and t.get("r") is not None]
    by = defaultdict(list)
    for t in trades:
        by[t["strategy"]].append(t)
    out["trades"] = {"closed": len(trades), "by_strategy": {
        k: {"n": len(v), "win_pct": round(100 * sum((x["pnl"] or 0) > 0 for x in v) / len(v)),
            "avg_r": round(float(np.mean([x["r"] for x in v])), 2), "pnl": round(sum(x["pnl"] or 0 for x in v), 2)}
        for k, v in sorted(by.items(), key=lambda kv: -len(kv[1]))[:12]}}
    # skips + log
    skips = list(getattr(e, "skips", []) or [])
    out["skips_top_reasons"] = Counter(re.sub(r"[\d.]+", "#", s.get("why", ""))[:90] for s in skips).most_common(10)
    lines = recent_log(1500)
    bad = [ln for ln in lines if " ERROR " in ln or " WARNING " in ln or "rejected" in ln.lower() or "failed" in ln.lower()]
    out["log_problems_top"] = Counter(re.sub(r"^\S+ \S+ \w+ ", "", re.sub(r"[\d.]{3,}", "#", ln))[:110] for ln in bad).most_common(12)
    out["log_signal_lines"] = [ln for ln in lines if re.search(r"ribbon|flip|BUY\?|SELL\?|early warning", ln)][-25:]
    return out, frames


PROMPT = """You are the trading-signal analyst inside SekexBot, an app that trades the user's Alpaca account.
You get an automatic audit of the user's own recent data: confirmed ribbon flips (BUY/SELL: 'late_atr_median' =
how much of the move was already gone when the signal fired, in ATRs; 'follow_through_pct' = how often price kept
going the signal's way over the next 5 candles; 'whipsaw_pct' = signals that went nowhere), early warnings
(BUY?/SELL?: hit_pct, lead in candles, edge = $/share better than waiting), a grid test of warning settings on the
same data, the trade journal by strategy, skipped-signal reasons and repeated log problems.
Answer the user's question in plain English for a non-programmer, short sections, concrete numbers from the audit.
Say which timeframe/session/stocks the signals work best and worst on, and what to change. Be honest when the
sample is small (under ~20 signals) and say so. Do not promise profits.
End with ONE line that is exactly: TUNE_JSON: {...}  containing only the early-warning settings you recommend from
{"min_conf","max_eta","shrink","ext_penalty"} (pick from the grid test when it has enough data), or TUNE_JSON: {}
if no change is justified. If the fix needs code changes (not just settings), add one line: CODE_FIX: <one
sentence describing the change>."""


class Reviewer:
    def __init__(self):
        self.job = None
        self.lock = threading.Lock()

    def status(self):
        j = self.job
        return {k: v for k, v in (j or {}).items() if k != "audit_full"} if j else None

    def start(self, e, question, symbols):
        if not os.getenv("ANTHROPIC_API_KEY"):
            raise ValueError("Add a Claude API key first: ⚙ → Broker keys → AI chart reader.")
        with self.lock:
            if self.job and self.job["state"] == "working":
                raise ValueError("A review is already running.")
            self.job = {"state": "working", "step": "Starting…", "question": question.strip()[:1500], "t": time.time()}
        threading.Thread(target=self._run, args=(e, symbols), daemon=True, name="signal-review").start()
        return self.status()

    def _run(self, e, symbols):
        j = self.job
        try:
            aud, _ = audit(e, symbols, progress=lambda s: j.update(step=s))
            j.update(step="Claude is reading the results…", audit=aud)
            key = os.getenv("ANTHROPIC_API_KEY", "")
            user = (f"User's question: {j['question'] or 'Why are my buy/sell alerts late or wrong, and how do I make them more precise?'}\n\n"
                    f"Audit (JSON):\n{redact(json.dumps(aud, default=str))[:60000]}")
            r = requests.post(_base() + "/v1/messages", timeout=240, headers={
                "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                json={"model": _pick_model(key), "max_tokens": 2500, "system": PROMPT,
                      "messages": [{"role": "user", "content": user}]})
            if r.status_code != 200:
                raise RuntimeError(_api_error(r.status_code, r.text))
            text = "".join(b.get("text", "") for b in r.json().get("content", []))
            tune, code = None, ""
            m = re.search(r"TUNE_JSON:\s*(\{.*?\})", text, re.S)
            if m:
                try:
                    t = json.loads(m.group(1))
                    t = {k: v for k, v in t.items() if k in LIMITS}
                    if t:
                        tune = clamp_tune({**get_tune(), **t})
                except Exception:
                    tune = None
            c = re.search(r"CODE_FIX:\s*(.+)", text)
            if c:
                code = c.group(1).strip()[:600]
            answer = re.sub(r"\n?TUNE_JSON:.*", "", re.sub(r"\n?CODE_FIX:.*", "", text)).strip()
            j.update(state="done", step="Done", answer=answer, tune=tune, code_fix=code,
                     usage=r.json().get("usage", {}))
        except Exception as ex:
            j.update(state="failed", step=str(ex)[:400])
