"""🛠 Help & repair: find problems, fix the known ones with one tap, and ask Claude about the rest.

diagnose() runs quick checks and returns issues, each with a plain-language fix and, where the
app can do it itself, a one-tap repair action. ask() sends your question plus the diagnosis and
the recent log (keys and secrets removed) to Claude, and returns step-by-step help.

Code changes are made only through 🤖 Fix with Claude (autobot/selffix.py): tested on a copy, PIN to apply, auto-rollback."""
import os
import re
import shutil
from collections import deque

import requests

from .analyst import _api_error, _base, _pick_model
from .config import BASE_DIR, DATA_DIR

SECRET_RE = re.compile(r"(PK|AK|sk-ant-)[A-Za-z0-9_\-]{6,}|(?i:secret|token|password|key)[\"']?\s*[:=]\s*\S+")


def redact(text: str) -> str:
    return SECRET_RE.sub("[hidden]", text)


def recent_log(n=120):
    f = DATA_DIR / "autobot.log"
    if not f.exists():
        return []
    with open(f, errors="replace") as fh:
        return [redact(ln.rstrip()) for ln in deque(fh, n)]


def diagnose(ctx: dict) -> dict:
    """ctx: engine, setup_error, settings, version, device, sim, update_info, tunnel"""
    issues, ok = [], []
    e = ctx.get("engine")

    def add(sev, title, detail, fix, action=None):
        issues.append({"severity": sev, "title": title, "detail": detail, "fix": fix, "action": action})

    # Alpaca connection
    if ctx.get("setup_error"):
        err = ctx["setup_error"]
        if "No " in err and "keys" in err:
            add("high", "Alpaca not connected", err, "Open ⚙ → Broker keys and paste your keys.", "open_keys")
        else:
            add("high", "Alpaca connection failed", err, "Reconnect. If it keeps failing, re-enter your keys.", "reconnect")
    elif e:
        ok.append("Alpaca connected (" + e.mode + ")")
        try:
            p = e.broker.price_info("SPY", "REGULAR")
            if p.get("last"):
                ok.append(f"Market data working (SPY {p['last']:.2f}, {p.get('source', '')})")
            else:
                add("med", "No market data", "SPY returned no price.", "Reconnect; check your internet.", "reconnect")
        except Exception as ex:
            add("med", "Market data error", str(ex)[:160], "Reconnect; check your internet.", "reconnect")
        st = ctx.get("settings")
        if st is not None and getattr(e.broker, "data", None) is not None:
            try:
                from alpaca.data.enums import DataFeed
                from alpaca.data.requests import StockLatestQuoteRequest
                e.broker.data.get_stock_latest_quote(StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
                ok.append("SIP (full-market) data: available on your account"
                          + ("" if st.data_feed == "sip" else " — switch Data feed to SIP in Controls to use it"))
            except Exception as ex:
                low = str(ex).lower()
                if st.data_feed == "sip":
                    add("high", "SIP data not available", "Your Alpaca plan doesn't include real-time SIP data "
                        f"({str(ex)[:90]}).", "Switch the data feed back to IEX (free), or subscribe to Algo Trader Plus.",
                        "use_iex")
                elif "subscription" in low or "permission" in low or "403" in low:
                    ok.append("Data feed: IEX (free). SIP needs Alpaca's paid Algo Trader Plus plan")
        f = ctx.get("feed")
        if f is not None:
            fi = f.info()
            if fi["status"] == "live":
                ok.append(f"Streaming prices live ({fi['symbols']} symbols)")
            elif fi["error"]:
                add("med", "Price streaming not connected", fi["error"],
                    "Prices still update by polling. Reconnect to retry streaming.", "reconnect")
        if e.risk.halted:
            add("info", "Trading halted for today", e.risk.halt_reason,
                "This is the daily loss / profit-lock rule working. It resets at 8 PM ET.")
        if e.entries_blocked_reason:
            add("info", "New entries paused", e.entries_blocked_reason, "Broker rule; resets tomorrow.")
        if not e.running:
            add("info", "Auto-trader is off", "The bot isn't trading.", "Turn it on from the Auto tab if you want it to trade.",
                "trade_on")

    # device (Android)
    dev = ctx.get("device") or {}
    if dev:
        if dev.get("wake_lock") is False:
            add("high", "Wake lock is off", "Android may pause SekexBot when the screen is off.",
                "Restart the app with the wake lock.", "restart")
        b = dev.get("battery") or {}
        if b and not b.get("plugged"):
            add("med", "Phone on battery", f"{b.get('percent')}% left.", "Plug the phone in while it trades.")
        if not dev.get("api"):
            add("med", "Termux:API missing", "Needed for notifications, alerts and battery status.",
                "Install Termux:API from F-Droid (same source as Termux).")

    # errors in the log
    lines = recent_log(300)
    errs = [ln for ln in lines if " ERROR " in ln or "Traceback" in ln or "Loop error" in ln]
    rej = [ln for ln in lines if "rejected" in ln.lower()]
    if errs:
        add("med", f"{len(errs)} recent error(s) in the log", errs[-1][-220:],
            "Tap Ask AI for an explanation, or Restart the app.", "restart")
    if rej:
        add("info", f"{len(rej)} recent order rejection(s)", rej[-1][-220:], "Tap Ask AI to see why and how to avoid it.")

    # storage
    try:
        free = shutil.disk_usage(str(BASE_DIR)).free / 1e9
        if free < 0.3:
            add("high", "Phone storage almost full", f"{free:.2f} GB free.", "Free up space; the journal and logs need room.")
        else:
            ok.append(f"Storage OK ({free:.1f} GB free)")
    except Exception:
        pass

    # update / AI key
    up = ctx.get("update_info") or {}
    if up.get("available"):
        add("info", f"Update available: v{up['latest']}", "Newer versions may fix this problem.", "Install it.", "update")
    if not os.getenv("ANTHROPIC_API_KEY"):
        add("info", "Ask AI is off", "No Claude API key saved.", "Add one in ⚙ → Broker keys → AI chart reader to get AI help.",
            "open_keys")
    order = {"high": 0, "med": 1, "info": 2}
    issues.sort(key=lambda i: order[i["severity"]])
    return {"issues": issues, "ok": ok, "version": ctx.get("version")}


HELP_PROMPT = """You are the built-in help assistant of SekexBot, an Android (Termux) app that auto-trades and
manually trades US stocks through the user's Alpaca account (paper or live). The user is not a programmer.

What the app can fix itself with one tap (suggest these by name when they apply):
- "Reconnect" (re-connects to Alpaca), "Restart app" (restarts SekexBot; trading resumes if it was on),
- "Repair install" (re-installs the libraries), "Install update", "Broker keys" (re-enter keys).
Termux commands the user can run: sekex status, sekex doctor --fix, sekex restart, sekex log, sekex setup.

Rules: answer in short numbered steps, plain words, under 180 words. Say what the problem is first.
Explain Alpaca order rejections precisely (e.g. brackets are checked against Alpaca's reference price,
extended hours need limit orders, buying power, shortability. FINRA retired the $25k pattern-day-trader rule on June 4, 2026: Alpaca now uses
intraday buying power and intraday margin calls; unmet margin calls can restrict an account for 90 days). Never ask for API keys or
passwords. Never tell the user to edit code; if it looks like a bug in SekexBot, say so and suggest
"Send report" so the developer can fix it in an update. You don't give financial advice."""


def ask(question: str, diag: dict, version: str, extra: str = "") -> dict:
    key = os.getenv("ANTHROPIC_API_KEY", "")
    if not key:
        return {"error": "Add a Claude API key in ⚙ → Broker keys → AI chart reader to use Ask AI."}
    issues = "\n".join(f"- [{i['severity']}] {i['title']}: {i['detail']}" for i in diag.get("issues", [])) or "- none found"
    log_tail = "\n".join(recent_log(60))
    user = (f"SekexBot version {version}.\nUser's question: {question.strip() or 'Something is wrong, what should I do?'}\n\n"
            f"Automatic checks found:\n{issues}\n\n{('Error shown on screen: ' + redact(extra) + chr(10)) if extra else ''}"
            f"Recent log (secrets removed):\n{log_tail[-6000:]}")
    model = _pick_model(key)
    try:
        r = requests.post(_base() + "/v1/messages", timeout=90, headers={
            "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
            json={"model": model, "max_tokens": 700, "system": HELP_PROMPT,
                  "messages": [{"role": "user", "content": user}]})
    except Exception as ex:
        return {"error": f"Couldn't reach Claude: {str(ex)[:150]}"}
    if r.status_code != 200:
        return {"error": _api_error(r.status_code, r.text)}
    text = "".join(b.get("text", "") for b in r.json().get("content", []))
    return {"answer": text.strip(), "model": model}


def report(diag: dict, version: str, status: dict) -> str:
    """A plain-text support report (no keys) for sending to the developer."""
    lines = [f"SekexBot support report · v{version}", "",
             "Checks:"] + [f"  [{i['severity']}] {i['title']}: {i['detail']}" for i in diag.get("issues", [])] + \
            [f"  ok: {o}" for o in diag.get("ok", [])] + ["", "Status:"] + \
            [f"  {k}: {redact(str(v))[:200]}" for k, v in status.items()] + ["", "Recent log:"] + recent_log(200)
    return "\n".join(lines)
