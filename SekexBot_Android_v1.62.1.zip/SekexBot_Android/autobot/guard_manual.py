"""🛡 Guard for YOUR manual positions: act when a trade is red AND the trend has turned against it.

Every 15 s it checks each position you hold that nothing else is already managing (not a bot trade, not auto-harvest,
no ⏰ close plan). A position is "turning against you" when, at the price a close would really get (bid for longs, ask
for shorts), it is down at least MIN_RED %, and the app's direction call (8-factor vote, score 25+ against you) or the
3-minute ribbon points against you, on 3 checks in a row. A hard cap closes (or alerts) at the loss limit no matter what.

Modes (Controls: Guard my manual positions):  off  |  alert  (push you a message with a Close button)  |  close  (close it for you)."""
import logging
import threading
import time

from .direction import direction
from .indicators import enrich, ribbon_state

log = logging.getLogger("autobot")
POLL = 15
CONFIRM = 3             # consecutive "against" checks before acting
MIN_RED = 0.03          # % down (at the exit-side price) before the trend call matters
SCORE = 25              # direction-call strength against you
REALERT = 600           # seconds between repeat alerts on the same position


class ManualGuard:
    def __init__(self, get_engine, get_settings, session_fn, quote_fn, close_fn, alert_fn, skip_fn):
        self.get_engine, self.get_settings, self.session_fn = get_engine, get_settings, session_fn
        self.quote_fn, self.close_fn, self.alert_fn, self.skip_fn = quote_fn, close_fn, alert_fn, skip_fn
        self.n = {}                      # sym -> consecutive against-count
        self.alerted = {}                # sym -> last alert time
        self.last = {}                   # sym -> last status (for the dashboard)
        threading.Thread(target=self._loop, daemon=True, name="manual-guard").start()

    def status(self):
        return dict(self.last)

    def _frame(self, e, sym):
        df = (getattr(e, "raw", {}) or {}).get(sym)
        if df is None or len(df) < 60:
            try:
                now = e.broker.now()
                df = (e.broker.bars([sym], start=now.replace(hour=4, minute=0, second=0, microsecond=0)) or {}).get(sym)
            except Exception:
                df = None
        return df

    def _loop(self):
        while True:
            time.sleep(POLL)
            try:
                s = self.get_settings()
                mode = getattr(s, "guard_manual", "alert")
                e = self.get_engine()
                if mode == "off" or not e:
                    self.n.clear(); self.last = {}
                    continue
                sess = self.session_fn(e)
                if sess == "CLOSED":
                    continue
                pos = e.broker.positions()
                for sym in list(self.n):
                    if sym not in pos:
                        self.n.pop(sym, None)
                for sym, p in pos.items():
                    try:
                        self.check(e, s, mode, sym, p, sess)
                    except Exception as ex:
                        log.warning("guard %s: %s", sym, ex)
            except Exception as ex:
                log.warning("manual guard: %s", ex)

    def check(self, e, s, mode, sym, p, sess, now=None):
        now = now or time.time()
        if self.skip_fn(e, sym):
            self.last.pop(sym, None)
            return None
        d = 1 if p["qty"] > 0 else -1
        bid, ask = self.quote_fn(e, sym, sess)
        mark = bid if d > 0 else ask
        if not mark or not p["avg_entry"]:
            return None
        pct = (mark - p["avg_entry"]) / p["avg_entry"] * d * 100        # + = winning, at the real exit price
        usd = (mark - p["avg_entry"]) * p["qty"]
        cap = float(getattr(s, "guard_loss_pct", 0.15))
        why = ""
        if pct <= -cap:
            why = f"down {abs(pct):.2f}% (your loss limit is {cap:g}%)"
        elif pct <= -MIN_RED:
            df = self._frame(e, sym)
            against = None
            if df is not None and len(df) >= 60:
                rb = ribbon_state(df)
                dc = None
                try:
                    dc = direction(enrich(df), 0.0, rb, getattr(e, "bias", 0), None)
                except Exception:
                    pass
                call_vs = bool(dc and dc.get("call") in ("LONG", "SHORT") and abs(dc.get("score", 0)) >= SCORE
                               and (dc["call"] == "SHORT") == (d > 0))
                rib_vs = bool(rb.get("ready") and rb["state"] == -d)
                if call_vs or rib_vs:
                    against = ("the direction call is " + dc["call"] + f" {dc['score']:+d}") if call_vs else "the ribbon turned against it"
            if against:
                self.n[sym] = self.n.get(sym, 0) + 1
                if self.n[sym] >= CONFIRM:
                    why = f"down {abs(pct):.2f}% and {against}"
            else:
                self.n[sym] = 0
        else:
            self.n[sym] = 0
        self.last[sym] = {"pct": round(pct, 3), "against": self.n.get(sym, 0), "mode": mode}
        if not why:
            return None
        if mode == "close":
            self.alert_fn("exit", f"🛡 Closing {sym}", f"{why}. About ${usd:+,.2f}.", sym, f"{' '.join(sym)}. Guard closing.")
            self.close_fn(e, sym)
            self.n.pop(sym, None)
            e.event(f"🛡 Guard closed {sym}: {why} (≈ ${usd:+,.2f})", "warning")
            return "closed"
        if now - self.alerted.get(sym, 0) >= REALERT:
            self.alerted[sym] = now
            self.alert_fn("exit", f"🛡 {sym} turning against you", f"{why}. About ${usd:+,.2f} if closed now.", sym,
                          f"{' '.join(sym)}. Turning against you.")
            e.event(f"🛡 {sym}: {why} (≈ ${usd:+,.2f}). Close it, or set Guard to Auto-close.", "warning")
            return "alerted"
        return None
