# SekexBot changelog

Version numbers are MAJOR.MINOR.PATCH. MAJOR means a breaking change to settings or data, MINOR means a new feature, and PATCH means a fix.
The running version shows in the dashboard header and in the console window when SekexBot starts.

## 1.62.1 — 2026-10-01
- The support-data question (ticked by default; nothing is sent until the user taps Continue) now shows after every install or update even before a support address is built into the app. Controls says plainly when no address is set, so nothing can be sent yet. Once a build carries the address, users who left it ticked start reporting.

## 1.62.0 — 2026-10-01
- The admin panel is no longer part of the app everyone gets. It is now a private, encrypted add-on that installs only on phones you have marked as admin. Other users' phones never download, install or show it; the public app contains no admin screen, passcode or admin address at all.
- To make a phone an admin phone: run `sekex admin enable` once (it prints a secret admin key; keep it private). `sekex admin key` shows it again, for a second phone, or put ADMIN_KEY= (and UPDATE_URL=) in sekexbot-setup.conf before running the setup script. `sekex admin status` and `sekex admin off` also exist.
- Publishing stays one step: `sekex publish`. The first time (and whenever the add-on itself changes) also put SekexBot_Admin_vX.zip in Downloads; the admin phone remembers it, so later publishes of a new app zip need nothing extra. On a phone without the admin key the add-on is silently left out.
- One update does everything. `sekex update` (and the app's update check) now also installs any new requirements: when the list of required packages changes, the full install runs automatically instead of the quick one. On admin phones the same update also fetches the admin add-on and restarts the app when it changed.
- The support-data question now has a checkbox that is ticked by default. It appears once after an install or update (when the build has a support address), nothing is sent until the user taps Continue, and unticking it first means nothing is ever sent. Controls keeps the same checkbox.
- The panel is opened as before: tap the logo 7 times, enter the passcode, and paste the collector address once.

## 1.61.0 — 2026-10-01
- Optional diagnostics sharing, so support can help fix a problem on someone's phone. New in Controls: Share diagnostics with SekexBot support. It is OFF by default, and a one-time question asks once (only when a support address is set in the build). When on, once a minute the app sends one small technical report: app version, phone make/model and Android version, how much CPU and memory SekexBot itself uses, phone free memory, battery and temperature, free storage, library versions, uptime, whether trading is on, and the last few error messages with keys, tokens and dollar amounts removed. It never sends API keys, passwords, positions, orders, balances, P&L, symbols or the journal. Show exactly what is sent displays the real report. Turning sharing off tells the collector to delete everything it holds for that install.
- Hidden support admin panel (for the person running support). Tap the SekexBot logo 7 times, enter the admin passcode, and see every install that is sharing: online or not, version (old ones flagged), phone and Android level, app CPU and memory, phone memory, battery, storage, errors, with a 6-hour history graph and the recent errors per phone. The passcode is checked by the collector, not stored in the app. The panel needs the separate collector program (collector.py), which is not part of the phone app.
- To report anywhere, a build needs the collector's https address (Admin panel, or DEFAULT_COLLECTOR_URL in autobot/telemetry.py for what you ship to users).

## 1.60.1 — 2026-10-01
- The installer now also copies the tools folder to the phone. Before, `sekex replay SYMBOL DATE` (replays a past day through every strategy) could not run on the phone because its script was never installed. No other change; you do not need a new setup script, `sekex publish` / `sekex update` is all you need for updates.

## 1.60.0 — 2026-10-01
- Keep the screen on. New setting in Controls, Keep this screen on while SekexBot is open: Off, Only while charging (default), or Always. It uses the browser's screen wake lock, so the screen stays on only while the SekexBot page is showing, never in other apps, and it follows the charger automatically. If the browser or battery saver refuses, the note under the setting says so. Samsung phones also have a system-wide option: Settings, About phone, Software information, tap Build number 7 times, then Settings, Developer options, turn on Stay awake (screen never sleeps while charging).

## 1.59.3 — 2026-10-01
- Closing a BOT trade in extended hours: the first Close tap works the order from the middle of the spread, and a second tap while that order is still open now takes the market price at once (before, the second tap repeated the gentle first try). Closing your own positions already worked this way.

## 1.59.2 — 2026-10-01
- The learned exit-slippage figure (added to the Harvest small % target) now ignores stop-outs, time stops and end-of-day exits, which slip far more than calm exits and would have inflated the target.

## 1.59.1 — 2026-10-01
- Spread filter. New setting Max spread for bot entries (Controls, default 0.15% of the price, 0 = off). The bot skips an entry when bid-ask is wider than that, in every session, and says so in the skip log. On a wide spread you start the trade that far under water and the exit pays it again, which is how a green position closes red. Your manual ticket does not block you but warns: a red banner on the quote when the spread is over the limit, and a heads-up with the dollar cost when you place the order.
- Safer defaults. Overnight trading and Shorts 24/5 are switched back OFF (one time, for existing installs too; new installs start with them off). Overnight quotes are the thinnest and widest of any session. You can turn either back on in Controls once your journal shows it pays.

## 1.59.0 — 2026-10-01
- Patient close, so a win stays a win. On a wide spread (pre-market and after-hours often 0.3-0.5%), the on-screen gain is measured at the last trade but a close fills at the bid (or the ask for a short), so a green position can close red. The Close button now works the order instead of hitting the far side: when the spread is 0.04% or wider it posts a limit on the favourable side of the spread and walks toward the market in three steps (about 14 s each in extended hours, 6 s in regular hours), then takes the market. Tap Close a second time at any point to take the market price immediately. The walk gives up and takes the market by itself if the price runs away from you by more than one spread. Tight spreads still close at once.
- The bot does the same for exits that bank a win or a manual close of a bot trade in extended hours: the first order is half-way across the spread, and the 20-second retry then goes to the marketable price. Stop-loss exits stay immediate.
- Plan closes (the ⏰ close later feature) and stops are unchanged and still immediate.
- Reminder: the "close now ≈ $X" line on each position is what closing at the market would really give. If it is red while the position looks green, the spread is bigger than your gain.

## 1.58.0 — 2026-10-01
- Catching the win, not the loss. A trade can look green yet close red for three reasons, and all three are addressed: (1) Speed: closing a position used to cancel its stop/target orders, then wait for Alpaca to confirm, then send the close, which cost a second or more while price moved. The close now goes out straight after the cancels and only waits if Alpaca says the shares are still held. (2) Real price: the bot's profit decisions (harvest, profit lock, scalp exits) used the last trade price, but a close fills at the bid for longs and the ask for shorts. They now use the live bid/ask, so a trade only counts as a win if it is a win you can actually get. (3) Learning the cost: after every close the bot compares the price it decided at with the fill and remembers the average slippage; the Harvest small % target adds that cost automatically, and the log tells you when an exit was slow or slipped.
- Positions now show "close now ≈ $X", what closing right this second would really fill at, next to the on-screen P&L, so a +$3 that is really -$2 after the spread is visible before you tap Close.
- Applies to regular hours; extended hours already used the bid/ask for its limit orders.

## 1.57.0 — 2026-10-01
- Learn from your own manual trades. New button Analyze my manual trades (Controls, under Harvest small %): it reads your finished orders from Alpaca (last 60 days), pairs them into round trips (trades the bot opened are left out), and shows your win rate and break-even win rate, what a typical winner banks and how fast, what your losers look like, a suggested harvest % and stop %, how you re-enter after a win (how soon, and how far from your exit), and your best hours. One tap applies the suggested % as your harvest.
- New switch Auto (use the % learned from my manual wins): the bot's Harvest small % follows what you actually do, refreshed every 30 minutes in the background. It needs 15 or more finished manual trades; until then it uses the fixed % you set. The % can be changed any time, live, with no restart.
- Needs your real Alpaca account's order history, so it shows nothing on the simulator.

## 1.56.0 — 2026-10-01
- New switch Harvest small % (Controls, OFF by default) so the bot can trade the way a hand-trader does: it banks a quick gain of about 0.1% (adjustable 0.05-1%, never less than 3 cents a share so the spread can't turn it into a loss), then the existing Auto re-entry gets back in on a pullback or a run to a new extreme while the ribbon and VWAP still agree. Works in regular and extended hours. Needs Auto re-entry on. Turn it on for a day and compare the journal with it off; the stop is still the strategy's normal stop, so the win-size vs loss-size ratio is what to watch.

## 1.55.4 — 2026-10-01
- Auto-harvest fixes. (1) A harvest now has to beat the round-trip cost: it sells at the bid but buys back at the ask, so the gain per share must exceed the spread (a fade exit needs 1.5x), otherwise a "harvest" was a small loss. (2) The "banked" total only counted winning harvests and left out the stop-out loss; stops are now included, so the total is the real net. (3) If the stop's exit order failed, auto-harvest switched itself off and left the position with no stop; it now keeps the job and retries.

## 1.55.3 — 2026-10-01
- Day P&L is now explained, not just shown. The halt banner shows the equity the day started at and the equity now, so you can check the loss yourself (Day P&L = equity now minus equity at the 8 PM ET day start, open positions included).

## 1.55.2 — 2026-10-01
- Daily-max-loss halt can now be cleared. The red halt banner has a Resume trading button (with a confirmation, and a LIVE warning on the real account) and shows today's P&L as it is now, not only the figure at the moment it halted. Raising the daily limit so today's loss is back inside it clears a daily-max-loss halt automatically. The halt still resets by itself at the 8 PM ET day rollover, and the bot halts again if the limit is hit again.

## 1.55.1 — 2026-10-01
- Trend predictions on every open position. Each row in Positions & orders and in the bot's Open positions list now shows the trend (green or red ribbon: Trend up / Trend down), any early BUY? or SELL? warning with its confidence and how many candles away it is, marked "against you" in red or "with you" in green, and the direction lean (LONG, SHORT or WAIT with its score, flagged when it leans against your position). It covers your manual positions as well as the bot's, refreshes about every 20 seconds, and works in every session.

## 1.55.0 — 2026-10-01
- 24/5 trading, set up to Alpaca's rules. Alpaca trades 24 hours a day, 5 days a week (Sunday 8 PM to Friday 8 PM ET), not 24/7; weekends are closed for stocks. Overnight is now ON for everyone (one-time switch; you can turn it off in Controls). New switch Shorts 24/5 (on by default): the bot may short in every open session, overnight included, instead of only 7 AM to 8 PM; every short still needs a fresh easy-to-borrow check right before the order. Rules the app already follows and now explains on the Controls card: outside 9:30 AM to 4 PM Alpaca accepts only limit orders with Day (or GTC) time in force, whole shares only, no market, stop, stop-limit or bracket orders, so the bot sends limit orders and watches its own stops, half size, 2 positions max. Overnight prices need Alpaca's overnight data (free overnight feed, or boats with Algo Trader Plus); if Alpaca returns none the app now says so once per night and alerts you. Android note: the app has to stay running overnight because the stops live in the bot.

## 1.54.1 — 2026-09-30
- Fix: Close on a manual position could fail. The app cancelled the position's stop/target orders and waited a fixed half second; if Alpaca had not released the shares yet, the close was refused ("insufficient qty / held for orders") and nothing happened. Now it cancels the orders, waits until Alpaca shows them gone, retries up to 4 times, and as a last resort sends a plain market order the other way. A finished bot trade on the same symbol can no longer hijack a manual close, and an after-hours close with no live quote prices off the position's last price instead of refusing.

## 1.54.0 — 2026-09-30
- Fixes for the benched setups. Self-fix: Fresh start: trades closed before this version are no longer counted when a setup is judged (they were closed under the old exits), so EMA_PULLBACK, RIBBON_FLIP and the others are re-tested on fair data; a benched setup's daily probe trade is now a quarter-size test instead of half. MICRO_SCALP: risk is capped at about 0.6 ATR (was 1.0 ATR) so a scalp no longer risks far more than it can win. FLUSH_SHORT: needs two closes under the broken range low, no chasing an exhausted drop (over 1.5 ATR under the range), and volume of 1.5x. FLUSH_BOUNCE: needs a higher low, and the bounce bar must close over the EMA9 as well as the prior high. Includes everything from 1.53.0.

## 1.53.0 — 2026-09-30
- Profit protection, the bot now banks gains properly. Profit lock: once a trade has been 0.6R green it can never give back more than 40% of its best gain (50% from 1.2R, 60% from 2R, 70% from 3R); the stop follows and the bot closes the trade if it falls to that level, in regular and extended hours. Earlier partials: sells 1/3 at +0.7R and 40% of the rest at +1.5R, break-even at +1R, tighter trail from +1.5R, and the far take-profit order is cancelled when a partial is taken. Reversal exit: if the app's direction call turns 55%+ against a trade that is 0.5R or more green, the bot sells half; if it is still against you on the next check it closes the rest.

## 1.52.1 — 2026-09-30
- Voice commands understand you better: extra words before the command no longer break it ('SpaceX status', 'hey Sekex, what's my balance'), SpaceX/Tesla/Apple and other company names map to their tickers, spoken numbers like 'twenty five' and 'one hundred' work, and 'SPCX status' reads that position's P&L. 'Close half' on a 1-share position now says so instead of closing it all.

## 1.52.0 — 2026-09-30
- Shorts from 7 AM for every setup. New switch (Controls, on by default): shorting turns on by itself at 7:00 AM ET and stays on until 8 PM, pre-market included, no matter what the manual Allow short selling box says (before 7 AM it stays off). Every setup can now short: MEAN_REVERT gets a short side (stretched above VWAP, overbought), the extended-hours micro-scalp can short, and a new FLUSH_FADE setup (short mirror of FLUSH_BOUNCE: fast spike up on volume, first red bar under the prior low) runs in regular hours and pre/after-market. Borrow checks, the 2-loss block and all risk limits still apply.

## 1.51.1 — 2026-09-30
- Two fixes from a code review. (1) Restored the suggested stop-loss / take-profit for manual orders: it had stopped working in v1.33.0 (Protect and Suggest levels returned an error) because a new file replaced the code behind it. (2) Closed a security hole: a web page open in the phone's browser could press bodyless buttons on the local dashboard (Flatten, Start, Reopen last close...) when no dashboard token is set. Local requests now must come from the dashboard itself (Origin/Host checks); curl and the sekex command are unaffected.

## 1.51.0 — 2026-09-29
- Voice + header patch built in (it no longer gets wiped by updates). 🎤 Voice commands: tap the green mic (bottom right; can move it to the left or hide it in ⚙ → Voice) and say 'Close META', 'Close half META', 'Close all', 'Status', 'Buy 5 META' or 'Short 15 SPCX'. Every command is shown and read back, and nothing is sent until you tap CONFIRM (it cancels itself after 20 s). Voice orders are capped at 500 shares; voice closes use the Close button's own logic, so after-hours shorts get the extended-hours limit order. Needs Chrome on http://127.0.0.1 or your https link. Welcome greeting ('Hello Ty-see-key, let's make some money!') on your first tap after opening, while 🔊 is ON; editable, with a Test button and an off switch. Header message: optional passcode lock (⚙ → Header message → Set a passcode; 5 wrong tries = 15-minute wait), and long messages now shrink to fit on two lines.

## 1.50.1 — 2026-09-29
- Header message moved into ⚙ Settings → Header message: type the text, tap a color (White, Green, Red, Gold, Blue, Purple) and a size (Small, Medium, Large), see a live preview, then Save or Remove. A 'Show in the header' switch hides it without deleting it. Tapping the message in the header opens this section; the empty 'Tap to add your message' box no longer shows in the header.

## 1.50.0 — 2026-09-29
- 📊 Review my signals with Claude (⚙ → Help, or the link under the chart): ask Claude about your BUY / SELL alerts in plain words. The app first grades every signal on your real recent prices (watchlist + stocks you traded): how late each confirmed BUY/SELL came (in normal candle ranges), whether price followed through over the next 5 candles, how often the BUY?/SELL? warnings were right and how many candles early, split by 1/3/5-minute chart, session and stock. It tests other early-warning settings on the same data and reads your trade journal, skipped signals and log errors. Claude then explains what it found and suggests warning settings (confidence cutoff, how soon the lines must cross, how much the ribbon must thin, the after-hours penalty) that you apply with one tap, kept within safe limits, with reset to default. It only changes the early warnings and their alerts, never how the bot trades. If a code change is needed, one tap sends it to Fix with Claude.

## 1.49.1 — 2026-09-29
- Your own message in the header: tap the empty space next to the session status (✎ Tap to add your message) to write a big, bold line such as a trading rule, and pick its color. It's saved on the bot, so every device shows it; tap it again to change or remove it.

## 1.49.0 — 2026-09-29
- 🤖 Fix with Claude (⚙ → Help & repair): describe a bug in plain words and Claude reads the relevant code, writes a fix and explains it in plain English with a risk level (and a warning if it changes how orders, stops or exits behave). The app tests every fix on a copy first (Python must compile, the dashboard's JavaScript must parse, the copy must start in simulator mode, load the dashboard and run 8 s without errors); a fix that fails is never applied. You review it (plain summary + the code change) and enter your Live PIN to apply; the changed files are backed up and the app restarts (trading resumes). If a fixed app won't start 3 times, or a patched file won't compile, it rolls back by itself; Undo (PIN) restores the last backup. Never touches keys, .env or data; only on the phone itself, not over the remote link. Uses your Claude API key and credits.

## 1.48.1 — 2026-09-29
- Fixed: auto-harvest (♻) stopped out a position on one bad quote when the overnight session started at 8 PM (TEM, Sep 29). Its protective stop now uses the mid price instead of the bid, ignores the first 3 minutes of each session and any time the spread is too wide, and needs price to stay beyond the stop for 25 seconds (straight away only at twice the stop). Overnight (8 PM - 4 AM) auto-harvest pauses and holds the position as is, then resumes at 4 AM pre-market.

## 1.48.0 — 2026-09-29
- ⏰ Close later: a new button on each of your positions sets a plan that closes the whole position by itself at the first of: a time (presets: tonight 7:55 PM, 4:00 AM pre-market, 9:30 AM open, 3:55 PM, or any time you pick), the trend turning against you (a NEW 3-minute ribbon flip red for a long / green for a short), or a take-profit / stop price. It runs on the phone even with the dashboard closed, is saved across restarts, uses extended-hours limit orders outside 9:30-4:00 and re-prices every minute until filled, and waits for the next session if it triggers while the market is shut. If Alpaca refuses to cover a short overnight it keeps trying and closes at 4 AM pre-market. Alerts with beep + voice when the plan fires and when it fills. Tapping Close yourself removes the plan; setting a plan turns off ♻ auto-harvest for that stock.

## 1.47.2 — 2026-09-29
- More close fixes: closing a BOT short after hours now prices the cover at the ask (was the bid, so it could sit unfilled); tapping Close again re-prices a bot exit that hasn't filled; a bot trade from regular hours that is still open after hours now closes with an extended-hours limit (the market close was being rejected silently); a regular-hours bot close that Alpaca rejects now shows the error instead of 'ok'. A full Close turns off auto-harvest (♻) for that stock so it can't buy back in. Watchlist warnings refresh right away when you add or remove a ticker.

## 1.47.1 — 2026-09-29
- Fixed: Close did nothing for SHORT positions in pre-market / after-hours (it refused with 'Covering a short needs regular hours'). Close now sends an extended-hours limit buy to cover a little above the ask (0.3%), the same way longs are sold; press Close again to re-price if it hasn't filled.

## 1.47.0 — 2026-09-29
- Beep and voice alerts for BUY / SELL on your watchlist, with an ON / OFF speaker button in the top bar (next to the bell) that mutes or unmutes everything in one tap, also from the remote link. Phone (works with the screen off, needs Termux:API): the notification plays a sound and vibrates (BUY = 2 short buzzes, SELL = 1 long, early BUY?/SELL? warning = 3 quick taps), and the phone says it out loud, e.g. 'S P C X. Sell signal. Trend turned down.' or 'M E T A. Buy warning. 74 percent.' Early warnings are a new alert (Settings > Alerts), spoken from 65% confidence by default (Warn me from: 60-80% or Never). Dashboard, while open: a rising two-tone beep for BUY, falling for SELL, three taps for warnings, a spoken alert and a colored banner (tap the screen once so the phone allows sound). While the dashboard is speaking, the phone's own voice stays quiet so you never hear it twice. New Settings switches: Beep on BUY / SELL, Say it out loud (with Test).

## 1.46.0 — 2026-09-29
- Early BUY? / SELL? warnings on the chart, for every watchlist stock. Dashed amber boxes appear when the trend ribbon is about to flip, before the confirmed BUY/SELL (the yellow line closing in on the white line, price crossing the yellow line and VWAP, the white line flattening, volume picking up). Each has a confidence %; past ones are graded ✓ (the flip followed within 6 candles) or ✗ (false alarm), and the chart shows the stock's hit rate, how many candles early, and the average price gained vs waiting. Warnings under 60% are hidden. Display only: the bot never trades on them. Watchlist chips now show each stock's trend dot, an amber ring plus BUY?/SELL? % when a warning is live, and 'no data' when Alpaca sends no prices (e.g. QNT). Tapping a warned chip, the new ⚡ Trade button or 'Open trade popup' opens the quick trade sheet with a live chart (1m/3m/5m/15m) and the warning, and the suggested side is outlined. Plain-English ⓘ popups on every chart term: VWAP, uptrend/downtrend, fast/slow lines, ribbon flips, BUY?/SELL?, O/H/L/C, volume, measure tool, after-hours.

## 1.45.0 — 2026-09-29
- Two safety rails: (1) no single position larger than 25% of your equity (margin buying power is ~4x, so one trade could be the whole account, like the 6,043-share KNDI trade); (2) a setup with fewer than 20 closed trades trades at 35% size (70% if it is already winning), full size only after it proves itself. Switch on the Self-fix card.

## 1.44.0 — 2026-09-29
- Let winners run and pick better: SCALE exit now takes 1/4 at +1R with the stop only to -0.5R (break-even after +2R), wider 1.8 ATR trail, target 8R; scalp profiles no longer bank at +0.15R (switch: Let winners run); ribbon-flip exit needs 3 confirmations. Entry filters: no stocks under $2, no trades against a clear early direction call.

## 1.43.0 — 2026-09-29
- Self-fix: the bot reviews its own last 12 closed trades of every setup. Losing setups are benched (one half-size probe trade a day until they recover); winning setups are promoted (ranked first, up to +30% size). New Self-fix card shows each setup's status; on by default, switchable.

## 1.42.0 — 2026-09-29
- Double-tap any row (pre-market timeline, shortlist, evening candidates, movers, setups) to open the quick BUY / SELL sheet. Single tap still opens the chart. Quantity is remembered from your last quick trade.

## 1.41.3 — 2026-09-29
- Anti-churn block is now only 2 losing closes on the same stock within 30 minutes (replaces the max-trades and wait-time rules). The dashboard shows blocked stocks with a Release button; release also clears the older cooling-off counters.

## 1.41.2 — 2026-09-29
- Stop churning one stock: always-on anti-churn guard read from the trade database (max 4 trades and 2 losses per symbol per day, 8 min between trades, 20 min after a loss). Works across restarts and cannot be switched off.

## 1.41.1 — 2026-09-29
- Pre/after-market trades no longer stop out too early: stop is at least 0.45% (or 1.2 ATR) from entry, price (mid) must stay beyond the stop 25 s before exiting (immediate only at -1.4R), and the ribbon-flip exit waits 6 minutes and never cuts a trade already above +0.9R.

## 1.41.0 — 2026-09-29
- Automatic system now finds and trades BOTH longs and shorts (mode picker: Longs + shorts / Shorts only / Longs only). Borrow check applies to shorts only; hard-to-borrow names stay on the shortlist as long-only candidates.

## 1.40.1 — 2026-09-29
- Fixed pre-market orders being rejected for insufficient buying power (BMNR: needed $5,584, had $5,410). Extended-hours checks did not refresh the account, so sizing used a stale buying-power number. Now the account is re-read before every pre-market or after-hours order, the quantity is capped to 95% of real buying power, and if Alpaca still says insufficient buying power the bot reads the real numbers from the error and retries once with a smaller quantity. Regular-hours orders and the manual auto-harvest re-entry get the same shrink-to-fit.

## 1.40.0 — 2026-09-28
- Auto re-entry that jumps back in. After a profitable exit the bot (all setups, regular hours and pre-market/after-hours) gets back in on the same side in two ways: on a pullback of at least a quarter of the stock's normal range with the latest 1-minute bar turning back, or, if there is no pullback and the stock keeps running, as soon as a completed 1-minute bar closes at a new high (or low, for shorts) at least 0.3 of that range past the exit price, with the ribbon and VWAP agreeing. Up to 3 re-entries per stock in a row, within 90 minutes, never after a loss, a ribbon turn against you, a daily-loss halt or an end-of-day flatten; bought or shorted with the same take-profit-along-the-way exit. The manual auto-harvest (the ♻ button) now does the same: back in on a pullback, or after 45 seconds if it keeps running past the harvest price. Switch: Controls > Advanced > Auto re-entry (on by default). New REENTRY trades show in the journal.

## 1.39.0 — 2026-09-28
- Automatic short system. One tap (Enable automatic short system, on the card near the top) for the selected PAPER or LIVE account: it starts the bot, turns on shorts only, morning reversal, the pre-market plan and (with SIP) late-day overnight shorts, then waits for a fresh, confirmed 1-minute short signal before ordering. LIVE asks for your Live PIN. Before every short it rechecks Alpaca's borrow_status (must be easy_to_borrow and shortable; hard-to-borrow names are skipped). Overnight homework: each night after 4:35 PM the whole market is ranked by volume, trade count and movement (plus your watchlist) into a short shortlist, and from 8:00 AM ET it is rechecked every 15 minutes and added to the live scanner with the new movers. Harvest and re-entry: short-system trades use the exit that takes portions near +1R and +2R and trails the rest, and after a profitable exit the same stock is only traded again on a distinct new signal (a different setup, or a 15-minute pause plus a real bounce). Long signals are ignored while the system is on. Turn it off from the same button.

## 1.38.0 — 2026-09-28
- Pre-market timeline: from 4 AM the bot snapshots the big movers at 4 AM, 7 AM, 8:30 and 9:15 (4 AM needs the SIP feed; you have it) and shows how each one moved (holding, faded, extending) in a new Pre-market timeline card, with a phone alert at the 7 AM and 9:15 checks. Short at open: gappers up 1.5%+ that have faded off their pre-market high and are under VWAP go on a short-at-open list, and the new OPEN_SHORT strategy shorts the first close below the pre-market low between 9:31 and 9:50 (stop above the early high or VWAP). On by default; switch: Controls > Advanced > Pre-market plan. Pre-market and after-hours trading already run from 4 AM once the feed is SIP.

## 1.37.0 — 2026-09-28
- Three new tools, all off by default except the review. (1) Morning reversal (Controls > Advanced): looks for a second rejection of the opening high (the first 5 minutes' high), then waits for a completed 1-minute close below the low since that rejection before it shorts, 9:40-11:30, stop just above the opening high. The opening window is ignored, so a 9:35 poke and fake-out does not count, and a breakout above the high cancels it. (2) Pre-close overnight short (Controls > Advanced): scans 3:10-3:35 PM for a spike that is failing (up 3%+ and faded 40% off the high) or a weak close (down 3%+, near the low), under VWAP with a red ribbon, and shorts shares with a broker-held GTC stop and target placed once filled. Needs the SIP feed and a short-enabled account, skips Fridays and days before holidays, and skips earnings and risky news. The bot covers by 10:15 AM if neither order has hit. A GTC stop can fill far worse if the stock gaps up at the open. Shares only, because Alpaca has no extended-hours options orders. (3) Review evening candidates button and card: lists the prior session's setups; each is a watch item that is scanned the next morning, and no order is placed until a fresh signal confirms. It also runs by itself after 4:30 PM. New command: sekex replay SYMBOL DATE prints when each strategy would have fired on that day using your Alpaca data. Fixed: release zips no longer include the simulator's test data folder.

## 1.36.0 — 2026-09-28
- Automatic direction trading: when a Big mover gets a strong LONG or SHORT call (score 45+, most signals agreeing, not stretched from VWAP), the bot now trades it by itself between 9:33 and 11:00 (new DIR_CALL strategy, ridden with the take-profit-along-the-way exit) and sends one phone alert per stock per day. The call uses pre-market bars, so it works from the opening bell instead of 9:44. It is on in Balanced, Aggressive and Max, and off in Conservative (Controls > Advanced, Trade strong early direction calls). DIR_CALL trades are paused automatically if the overnight study finds that kind of call right less than half the time over 20+ calls. The study also replays DIR_CALL each night so the learner sizes it.

## 1.35.0 — 2026-09-28
- Early direction call: every Big mover and any ticker you type into the manual ticket now shows LONG, SHORT or WAIT with a score and the reasons. It is a weighted vote of price vs VWAP, ribbon, swing structure (higher highs or lower lows), 15-minute momentum, buying vs selling volume, position in the day's range, SPY/QQQ, and how that stock's gaps have behaved (follow through or fade) in the overnight study. It says WAIT when the votes disagree and flags when price is stretched from VWAP. The overnight study scores each 9:40 call against the next hour on past days and shows how often LONG, SHORT and STRONG calls were right.

## 1.34.0 — 2026-09-28
- Catch the morning trend and learn overnight. (1) The ribbon now starts from the pre-market bars, so it is ready at 9:30 instead of about 10:00, which is why early trends were missed. Entries open 2 minutes after the bell (was 5). (2) New PLAN_TREND strategy: a name on the Big movers list that gapped 0.8%+ and breaks its early high (or low, for shorts) with VWAP, ribbon and volume agreeing is bought or shorted right away; PLAN_TREND and GAP_GO trades are ridden with the SCALE exit (take profit along the way, trail the rest) instead of a quick scalp. (3) Overnight study: after 5 PM, overnight and on weekends the bot replays the last few trading days of your stocks minute by minute through every strategy and every exit style and teaches the learner, weighted at 0.3 of a real trade; each day is studied once. New Overnight study card with Study now and an on/off box.

## 1.33.0 — 2026-09-28
- Trading levels: pick Conservative, Balanced, Aggressive or Max in one tap instead of setting many boxes. Auto learns which of the first three works best in each session (pre-market, regular, after-hours) from your own trades, judged by average R per trade once a level has 8 trades in that session, and switches at each session start (it never picks Max on its own, and starts from Balanced/Conservative defaults while it learns). Change any single box under Advanced and the level becomes Custom. Existing setups keep their current switches as Custom. The daily max loss and session on/off boxes are never changed by Auto.

## 1.32.0 — 2026-09-28
- Automatic morning and night setup: the Big movers list now builds itself every 5 minutes in pre-market and after-hours even when the auto-trader is stopped (turn off with Controls > Auto-prep), and the last list stays on screen overnight and after a restart, with an as-of time, so it no longer goes empty. If your Alpaca account has the paid SIP data feed, SekexBot detects it at startup and switches to it, which gives the full 4 AM to 8 PM window (free IEX only covered 8 AM pre-market and after-hours until 5 PM). Positions are still flattened shortly before each session ends.

## 1.31.0 — 2026-09-28
- Auto-harvest: tick the new ♻ box on the manual ticket or quick-trade sheet (or tap ♻ on an open position). It sells for a small quick gain (about half the stock's normal 5-minute range, or when the gain starts to fade), then buys or shorts the same size again on a pullback when the ribbon still agrees. It repeats until you tap Stop, and stops on its own if the ribbon turns against you, the daily loss limit halts trading, or a trade goes 1.2 ranges against you (it closes that one). Works long or short, with the auto-trader on or off.
- Reopen last close: one tap, no confirmation, puts back the position you last closed by hand (same stock, side and size), and turns auto-harvest back on if it was on. Shows under Positions after you close something.

## 1.30.1 — 2026-09-28
- Publish in one command: run `sekex publish` in Termux after saving a new zip to Downloads. It finds the newest zip, writes latest.json (version, checksum, notes), uploads the zip and then latest.json to your GitHub update repo, and sets the app's update link. GitHub repo and token are asked for once and stay on the phone.

## 1.30.0 — 2026-09-28
- Pre-open mode: pre-market and after-hours trading are now ON by default (your existing settings switch on once). The bot scans for movers every 5 minutes, keeps taking pre-market entries until 9:20 instead of stopping at 9:05, and only closes pre-market trades in the last 4 minutes before the open.
- Gap fade: new GAP_FADE strategy for a gap that fails. A gap-up losing the opening-range low and VWAP is shorted (SPCX on Sep 28). A gap-down reclaiming the range high and VWAP is bought. Runs 9:40-10:45. Gap and go now starts at 2% gaps, long or short (META on Sep 28).
- Evening movers: new EXT_TREND strategy trades pre-market and after-hours continuation of 1.2%+ movers, long or short, when the ribbon, VWAP and a fresh break agree.
- Big movers list: new card with the top 10 names moving 1%+ from the last close, each with a plan (GO, FADE or WAIT), side, trigger and target. It works in pre-market, at the open and in after-hours, and sends one alert around 8:55 AM and 4:05 PM.

## 1.29.0 — 2026-09-28
- Shorts on by default: SELL flips and short setups now trade in regular hours, and in pre-market and after-hours when the stock is shortable and your account can short. Overnight stays long-only. Stops, take-profits and exits work for shorts in every session.
- Why no trade?: a new panel lists every signal or ribbon flip the bot saw but skipped, with the exact reason (flip too old, below VWAP, time-of-day filter, cooling off, cannot short, slots full, sizing and more). Filter it by symbol.
- Trade every flip: optional switch that takes each fresh ribbon BUY/SELL flip on your watchlist and picks. It skips the VWAP, learner and time-of-day checks for flips only. The daily loss limit and position sizing still apply.

## 1.28.0 — 2026-09-28
- ✋ One-tap manual trading: no more 'Send this order?', 'Close?' or LIVE-money pop-ups on the order ticket, the quick trade sheet or Close buttons. The order goes straight away. To bring the pop-ups back, tick 'Ask before sending or closing manual trades' in Controls. Opening a short when you don't own the stock still asks once, because losses are unlimited.

## 1.27.0 — 2026-09-28
- 🧊 Cooling off is now optional (Controls). 'Cool off after 3 losses in a row' switches off the 20-minute pause and the half-size penalty. 'Symbol cooldown' switches off the wait before re-trading a stock and the skip after 2 losses in a day. Both are on by default. While the bot is cooling off, a ▶ Resume now button clears the pause, the penalty and today's cooldowns in one tap. The daily loss limit always stays on.

## 1.26.0 — 2026-09-28
- 💰 Quick harvest for scalps (Aggressive and Scalp modes, every session): once a scalp has been green for 2 checks in a row, it doesn't wait for the target. It banks the profit when momentum stalls (0.15R back from its best) or when it's near the target. The stock can be re-entered right away if the setup fires again; otherwise the slot goes to the next best candidate. Bug-check fixes: restoring open trades after a restart or a ↩ Revert no longer fails when versions store different trade fields, and log lines show the size weight rounded.

## 1.25.0 — 2026-09-28
- 🔥 Aggressive scalping (Controls, off by default): many fast trades in every session. It adds a MICRO_SCALP setup (1-minute burst over the last 3 bars on 2× volume, above VWAP) and trades every setup with ½ at +0.5R (the rest moves to break-even) and the rest at +1R, out within 8 minutes. Up to 6 positions at 60% size, checks every 10 s (5 s in extended hours), and shorter cooldowns. The daily loss limit still applies. 🔻 Flush short: a tight range that breaks down hard on 2× volume (like TSLA's drop), when shorting is on. 🔺 Flush bounce: the first strong green bar after a fast 2-ATR drop on a volume spike (in all sessions). Flush setups skip the ribbon wait and the time-of-day filter. 🎯 Setting up now: a live top-15 list of stocks coiling for a fast move before it happens (tight range, volume building, lean from VWAP, ribbon and highs/lows), with the likely direction, trigger price, target, expected move, a 0–100 Ready score and ⚡ breaking now. The stock picker now scans 30 names.

## 1.24.0 — 2026-09-28
- 💰 Profit harvesting in every session. Pre-market, after-hours and overnight trades now take profit along the way like regular hours: ⅓ at +1R (the rest moves to break-even), ⅓ at +2R, then a 1× ATR trail or a ribbon flip. Partial sells are marketable limit orders, the only kind Alpaca allows outside regular hours, and each one sends a 💰 alert. ⚡ New Scalp mode (Controls, off by default): ½ at +0.6R, the rest at +1.2R, out within 20 minutes, in every session. ⬆ Update progress: the update screen shows a progress bar, each install step with a ✓, elapsed time and a details log. The app keeps serving while it installs and only restarts at the end.

## 1.23.0 — 2026-09-27
- 🚀 Opening Drive setup (OPEN_DRIVE), modeled on your best trades (SPCX, VKTX, AMD at 9:30): a +2% gapper that breaks its first-5-minute high above VWAP on a volume surge, 9:35–9:50 (a gap-down short when shorting is on). 💰 Take profit along the way (on by default): the bot sells ⅓ at +1R and moves the stop to break-even, sells another ⅓ at +2R, and rides the rest with a 1× ATR trail or until the ribbon flips. A '💰 Took profit' alert fires each time, and the journal and learner count the whole trade. 🕒 Time-of-day filter from your own history: the bot skips new trades in the time slots where your last 90 days lose money (at least 30 trades; today that's midday, morning after the drive, after-hours and overnight), and still allows opening drives until 9:50. Switches for both are in Controls. ⬆ Updates: SekexBot checks for a new version every hour and, in Ask mode, shows Update now / Later / Skip this version; Manual mode never prompts. Every update saves the version it replaces (the last 3 are kept), and '↩ Revert to vX' in the Update screen (or 'sekex rollback X.Y.Z') goes back while keeping your data.

## 1.22.0 — 2026-09-27
- 🔍 Trend research (Manual tab): type a ticker (for example SPCX), choose 10–90 days and tap Study. It finds every big run up or down in the stock's own minute history. For each run you see the start and end times and prices, the move and how long it lasted, grouped as morning, midday or afternoon. It also shows when morning runs typically start, what was true as runs began (opening drive, opening-range break, above or below VWAP, volume surge) and which exit rule kept the most of each run (ribbon flip, VWAP cross, 2 closes against, 1× or 2× ATR trail). These results will shape the bot's new morning and wave strategies.
- 🔔 3:55 PM overnight test: buy (or short) at 3:55 PM and exit at 8 PM, 11 PM, 2 AM, 4 AM, 8 AM, 9:25, 9:35 or 10 AM. Shows average result, long and short win rates, and worst and best days, and highlights the best combination. It uses real overnight (24-hour session) prices where the stock trades overnight.

## 1.21.0 — 2026-09-27
- 📊 Trading stats (Positions tab): every trade in your Alpaca account, bot and manual, matched from buy to sell. Shows total P&L, win rate, average win and loss, and profit factor. P&L by time of day (pre-market, morning 9:30–11:30, midday, afternoon, after-hours, overnight); tap a time to filter. Your top 5 wins and worst 5 losses, bot vs. manual results, and each bot strategy's results. Covers 7 days to 1 year.
- 📰 Earnings and news: the order ticket shows whether the stock reports earnings today or before the next open, plus the latest headlines, with risky ones flagged (offering, halt, bankruptcy, delisting, investigation, reverse split, downgrade…). The auto-trader skips a stock on its earnings day, doesn't buy after-hours or overnight right before a pre-market report, and waits 30 minutes after a risky headline. It uses the free Nasdaq earnings calendar and Alpaca news. If either is unreachable, trading continues.
- 🛡 Safety net (⚙ Settings): a phone-offline alert through free healthchecks.io. The app pings every minute; if the phone dies, sleeps or loses internet, healthchecks.io alerts you by email, SMS, ntfy or Telegram. Nightly backups at 8:10 PM ET of the journal, learning memory and settings (never API keys or tokens) to Downloads/SekexBot/backups, keeping 14, with optional upload to a private GitHub repo. Back up now and Restore buttons included.

## 1.20.5 — 2026-09-27
- Charts at any hour: the chart now shows the last few days, including pre-market, after-hours and the overnight (24-hour) session, not just 9:30–4:00. Nights and weekends show the most recent real prices, the same as Robinhood's 24 Hour Market chart. It uses Alpaca's overnight feed (BOATS on SIP accounts, Alpaca's overnight feed otherwise). Extended hours are lightly shaded and overnight is shaded blue. When nothing is trading, the header says when the last trade happened.

## 1.20.4 — 2026-09-27
- Take profit after a halt: every winner kept open gets a profit lock, set at break-even or better and then at half of its best gain, rising as the price climbs. If the price falls back to the lock, the position is sold (limit orders in extended hours) and you get a "💰 Took profit" alert. This covers manual positions too. Bot trades also get their stop at Alpaca raised to the lock. Profit locks survive an app restart.

## 1.20.3 — 2026-09-27
- Daily loss limit: when it's hit, the bot now closes only the **losing** positions (bot and manual) and keeps the winners open. Winners keep their stop-loss and the bot keeps trailing them; it just opens no new trades until the next day (8 PM ET). In extended hours the losers are closed with limit orders.

## 1.20.2 — 2026-09-27
- Auto-trade safety fixes: after switching from PAPER to LIVE on the same day, the bot could compare your live balance with the paper account's starting balance, read it as a huge loss, and close all live positions. The start-of-day balance is now kept separately for Paper and Live, and any figure far off your real equity is ignored. Updated for FINRA's retirement of the pattern-day-trader rule (Alpaca's Intraday Margin Framework, since June 4, 2026). No day-trade counting and no $25k minimum: the bot sizes within intraday buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders. The app keeps working after Alpaca removes the old day-trade fields from its API on July 6, 2026. A position the bot can't close now raises an alert instead of failing silently. Saved halts and loss streaks are again restored correctly after a restart (the new always-on balance display could skip them).

## 1.20.1 — 2026-09-27
- Fixes: the account bar and Account card now show your balance, buying power and today's P&L at all times, including nights and weekends (they were blank while the market was closed). Switching the data feed to SIP now works while the auto-trader is running — it checks your account really has SIP, switches, and restarts the bot — instead of silently flipping back to IEX.

## 1.20.0 — 2026-09-27
- Paper / Live switch: tap the PAPER / LIVE badge at the top to switch. Live needs your Live PIN, a real-money confirmation and working live keys (checked first); a running auto-trader stops, switches and restarts by itself. Too many wrong PINs lock the switch for 15 minutes. Live is unmistakable on every screen: a red frame, a '● LIVE — REAL MONEY' bar, a pulsing red badge, 'LIVE ·' on order buttons, a red browser bar and '🔴 LIVE' in the title and alerts. Account bar: balance, today's P&L ($ and %), open P&L, buying power and loss left stay pinned under the header on every screen and layout.

## 1.19.0 — 2026-09-27
- Interactive chart: touch or drag for a crosshair with time, OHLC, volume, trend (uptrend/downtrend), fast/slow lines and VWAP; tap to pin a point and measure the move to the crosshair ($, %, time, ribbon flips); pinch or scroll to zoom, drag to pan, double-tap to reset; 1m / 3m / 5m / 15m timeframes; volume bars and a VWAP line.

## 1.18.0 — 2026-09-27
- Streaming prices: real-time quotes and trades from Alpaca's websocket (up to 30 symbols on the free plan), pushed to the dashboard — the ticket, quick sheet and positions P&L move tick by tick with a STREAMING badge. The bot uses streamed prices too, and its extended-hours stops (watched by the app) now react within about a second instead of 15. Falls back to polling automatically if streaming isn't available. Help & repair now checks whether SIP data works on your account and can switch back to IEX with one tap.

## 1.17.0 — 2026-09-27
- Alerts: phone notifications (with Trade and Close buttons) for bot entries, fills, exits with P&L, stops raised, rejections, daily-loss halt, losing streaks, broker restrictions and stale data; watchlist trend alerts (ribbon flip, new high/low of day, VWAP, volume spike); price alerts; end-of-day summary. Optional copies to ntfy or Telegram, quiet hours, per-type switches, and a bell with the alert history. Faster trading: $1k / $5k / 1R / Max size buttons and a price-alert button in the quick sheet; tapping Trade on a notification opens the quick sheet. Help & repair: run checks, one-tap fixes (reconnect, restart, repair install, update), Ask AI (Claude explains errors in plain steps) and Send report. Fixes: bracket orders rejected while the market is closed are re-anchored on Alpaca's reference price automatically, order errors are explained in plain words, and suggested stops can no longer be unrealistically tight.

## 1.16.0 — 2026-09-26
- Live price everywhere, at any time: the order ticket and quick trade sheet show the price, day change (green/red), bid/ask and a LIVE dot, refreshing every 3 seconds, with the cost worked out as shares × price against your buying power. When the market is closed (nights, weekends, holidays) the price falls back to the last trade or last close, labeled 'as of', so orders can always be prepared. The trend chart shows the most recent session when the market is closed instead of 'Waiting for bars'.

## 1.15.0 — 2026-09-26
- Suggested stop-loss / take-profit: tick Attach stop-loss / take-profit and SekexBot proposes Scalp, Day and Swing levels from real support/resistance and the stock's volatility (ATR), with R multiple, trend check and a size that risks the bot's base amount. The quick trade sheet can protect orders with the Day levels automatically. Fix: prices now work on nights and weekends (last session's close), so orders can be prepared while the market is closed.

## 1.14.1 — 2026-09-26
- Gains show green and losses red everywhere, with a + sign on gains: today's P&L, the summary strip, every position and its %, bot trades (new P&L column), the journal, daily results and averages. Totals for Positions & orders, Open positions and Daily results. sekex status colors the day's P&L too.

## 1.14.0 — 2026-09-26
- New layout with a ⚙ gear: choose Tabs (Auto · Manual · Positions · More at the bottom), an Auto | Manual switch, or the classic one-page layout. Light, dark or follow-the-phone theme. A big Auto-trader on/off switch and an always-visible summary strip (equity, today, loss left, open trades). Your choices are remembered on each device.

## 1.13.0 — 2026-09-26
- Double-tap to trade: double-tap any stock in the picker, the scanner chips or your positions to open a quick trade sheet with the suggested size and big BUY / SELL (or SHORT) buttons. A single tap still opens the chart.

## 1.12.1 — 2026-09-26
- Turn off app button uses an icon every phone font can show.

## 1.12.0 — 2026-09-26
- Full order ticket like Alpaca's: Buy/Sell (Short), Market, Limit, Stop, Stop limit and Trailing stop orders, a quantity stepper, a limit price with tap-to-fill bid/ask, Time in force (Day, GTC, IOC, FOK, At the open, At the close) and Trading session (Market hours, Extended hours, 24 Hour Market). In-app updates: install a new version from the dashboard (⬆ Update) by picking the zip, or from an update link that is checked every 6 hours, with a notification and one-tap install.

## 1.11.0 — 2026-09-26
- Manual trading: a Manual trade ticket with Buy and Sell (market or limit, size in shares or dollars, optional stop-loss and take-profit) and a Positions & orders panel for the whole account with Close, Close ½ and Cancel. The bot stays out of any symbol you trade by hand that day and never flattens your manual positions at the close.

## 1.10.0 — 2026-09-26
- Fully automated install: one-file installer (SekexBot_Setup.sh), optional sekexbot-setup.conf to pre-fill keys and settings and start trading automatically, a non-interactive package install with a log, and 'sekex doctor --fix', which checks the phone and opens the screens that fix problems.

## 1.9.1 — 2026-09-26
- Tap-to-use controls: home-screen Start / Stop / Status / Open buttons (Termux:Widget), Start and Stop buttons in the SekexBot notification, pop-up messages, and a ⏻ Turn off app button on the dashboard.

## 1.9.0 — 2026-09-26 (Android edition)
- 🤖 Runs entirely on an Android phone inside Termux. No PC needed. `install.sh` sets everything up, and the `sekex` command starts, stops and checks the bot.
- Watchdog: if the app crashes or Android kills it, it restarts automatically, and trading **resumes** if it was running (a Stop from the dashboard or `sekex stop` is remembered).
- Open trades, today's halt state, profit-lock peak and losing-streak brakes are saved every tick and restored after a restart, so a restart can't reset your limits.
- Wake lock, start on phone boot (Termux:Boot), and an ongoing notification with an Open button.
- Dashboard shows battery, charging and wake-lock status, with warnings when the phone is on battery or hot.
- After-hours and overnight trading start **off** on Android, because their stops are watched by the app itself.
- "Phone access" becomes "Remote access" for checking the phone's bot from another device (uses Termux's cloudflared).

## 1.8.0 — 2026-09-26
- 📱 Phone access through a Cloudflare Tunnel. You can use a Quick link (no account) or your own domain, with a QR code, and auto-connect on start.
- A login page with a password (hashed), 30-day signed sessions, and a lockout after too many wrong attempts.
- Broker keys and phone-access settings can only be changed on the computer running SekexBot.
- The dashboard fits phone screens and can be installed as an app with the SekexBot icon.
- A version number with this changelog.

## 1.7.2
- Chart read: "Analyze live chart" now uses the most recent session at night, on weekends and before the open.
- Clear error messages for the AI screenshot reader: no API credits, bad key, model not found, image too large, rate limit.
- A "Test AI key" button.

## 1.7.1
- New SekexBot logo, app icon, favicon, Windows .ico, and a desktop-shortcut helper.

## 1.7.0
- Account-size-aware stock picker. It scans about 300 stocks and scores each one for opportunity × fit (daily limit, buying power, liquidity).
- "Scan now" button and a Stock picker table with the reasons for each pick.
- Fix: volume and ATR now come from full-market SIP history instead of IEX-only volume.

## 1.6.0
- 🔑 Broker keys screen: enter, test and save Alpaca paper and live keys, a Live PIN, and a Claude key, all in the dashboard.
- Startup no longer opens Notepad.

## 1.5.1
- Renamed to SekexBot.

## 1.5.0
- BullGPT-style screenshot reader. Drop in or paste a chart and get a game plan: trend, levels, timing, scenarios, lean, and what the bot would do.
- Watchlist of tickers that are always scanned and traded in every session (SPCX added to start).

## 1.4.0
- After-hours (4–8 PM) and overnight (8 PM–4 AM) trading: long-only, limit orders, bot-managed stops, half size.
- The daily loss window runs 8 PM → 8 PM ET. The chart is built from quotes overnight.
- Fixed start_bot.bat when the Python environment was missing pip.

## 1.3.0
- Portable SD card / USB edition with a bundled runtime and self-repairing setup.

## 1.2.0
- AI chart read panel: levels, Fibonacci, RSI, VWAP, bias score, and bull and bear scenarios.

## 1.1.0
- EMA ribbon: RIBBON_FLIP strategy, ride-the-ribbon exit, ribbon trend filter, ribbon chart on the dashboard.

## 1.0.0
- First release: morning scanner, five strategies, a Thompson-sampling learner that picks setups and exits, a daily-max-loss risk manager, bracket orders, the dashboard, and the offline simulator.
