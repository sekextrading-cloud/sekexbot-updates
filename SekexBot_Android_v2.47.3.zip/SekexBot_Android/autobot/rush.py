"""v2.38: Opening Rush autopilot (buy-only, 9:30 to 10:00 AM ET).

Tested on your own chart history (Alpaca 5-minute candles with pre-market volume, 30 stocks, May 12 - Oct 30 2026):
stocks whose pre-market volume (4:00 AM until 9:00) was 8x or more their normal tended to push UP in the first 30 minutes,
even when they gapped down. Buy at the 9:30 open, sell at 10:00: 51 trades, +0.98% average, 65% winners, positive in both
halves of the data (May-Aug +0.76%, Aug-Oct +1.12%). Shorting the same stocks lost in every group, so this only buys.
Tight stops (-1%, -1.5%) got shaken out by the opening swings; a -3% stop kept most of the gain.
Small sample: a few big winners matter. PAPER first; the Reality check pauses it if real results fall short.

This module holds the rules and the saved state; server.py does the scanning, the orders and the alerts."""
import json
import math
import threading
from datetime import datetime

from .config import DATA_DIR

FILE = DATA_DIR / "rush.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": False, "live": False, "per_pick": 25000, "max_picks": 3, "min_rel": 8, "stop_pct": 3.0, "sell_by": "10:00",
               "extend": False, "goal": 500, "min_price": 3.0, "min_pre_dollars": 5_000_000, "max_spread_pct": 0.5,
               "gap_go": True, "gap_min": 2.0, "gap_vol": 2.0}
# v2.45 Gap-and-go (second trigger, 9:35): gap up gap_min%+ at the open, the 9:30 candle closed green, and its volume was gap_vol x the
# stock's normal first 5 minutes. Tested on your history: 70 trades, 57% winners, +0.76%/trade, positive in both halves (buy only;
# shorting gap-downs lost -0.5%/trade). Same stop, sell-by and goal as the volume picks; they share max_picks.
OK = {"per_pick": (5000, 10000, 25000, 40000), "max_picks": (1, 2, 3, 4, 5), "min_rel": (5, 8, 12), "stop_pct": (2.0, 3.0, 4.0),
      "sell_by": ("09:45", "10:00", "10:15"), "goal": (0, 250, 500, 1000), "gap_min": (1.5, 2.0, 3.0), "gap_vol": (1.5, 2.0, 3.0)}
TRAIL_START = 1.5      # extend: only a trade that is up 1.5%+ near the sell-by time, with the 5-min trend green
TRAIL_PCT = 1.0        # trailing stop 1% under the best price since then, never below +0.5%
HARD_END = "10:30"     # an extended trade is sold by 10:30 at the latest
BUY_UNTIL = 585        # v2.44.3: keep trying to buy the picks until 9:45 (spread settles); after that a pick is skipped and logged


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "picks": [], "picked_at": "", "trades": [], "done": "", "log": [], "history": [], "alerted": "",
            "summary": "", "unbought_said": False, "gap_at": "", "goal_hits": 0}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    for k in ("on", "live", "extend", "gap_go"):
        c[k] = bool(c.get(k))
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in ("on", "live", "extend", "gap_go"):
            d["cfg"][k] = bool(v)
        elif k in OK:
            v = float(v) if isinstance(OK[k][0], float) else v
            if v in OK[k]:
                d["cfg"][k] = v
    save(d)
    return load()


def new_day(d, today):
    if d.get("day") != str(today):
        if d.get("trades"):
            d["history"] = ([{"day": d["day"], "pnl": round(day_pnl(d), 2), "n": len([t for t in d["trades"] if t.get("entry")])}]
                            + d.get("history", []))[:30]
        d.update(day=str(today), picks=[], picked_at="", trades=[], done="", log=[], alerted="", unbought_said=False, summary="", gap_at="", goal_hits=0)
    return d


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%-I:%M %p"), "msg": msg})
    del d["log"][60:]


def hm(now):
    return now.hour * 60 + now.minute


def at(s):
    h, m = (int(x) for x in s.split(":"))
    return h * 60 + m


def phase(now, cfg):
    """'scan' 4:00-9:25, 'pick' 9:26-9:29, 'buy' 9:30-9:44 (v2.44.3: was 9:33; a wide spread at the open used to skip the whole day),
    'manage' until the sell-by time (10:30 for extended), 'closed' after."""
    if now.weekday() >= 5:
        return "closed"
    m = hm(now)
    if m < 240:
        return "closed"
    if m < 566:
        return "scan"
    if m < 570:
        return "pick"
    if m < BUY_UNTIL:
        return "buy"
    if m < at(HARD_END) + 1:
        return "manage"
    return "closed"


def pre_volume(df, day, end_min=565):
    """Shares traded 4:00 AM until end_min (9:25 by default, like the test) on `day`. df: bars with a New-York DatetimeIndex and 'volume'."""
    if df is None or not len(df):
        return 0.0
    x = df[df.index.date == day]
    m = x.index.hour * 60 + x.index.minute
    return float(x["volume"][(m >= 240) & (m < end_min)].sum())


def rel_volume(df, today, days=20, end_min=565):
    """Today's pre-market volume divided by the average of the same window over the last `days` trading days.
    Returns (ratio, today's shares, average shares) or (None, today, avg) when there is too little history."""
    if df is None or not len(df):
        return None, 0.0, 0.0
    past = sorted({d for d in df.index.date if d < today})[-days:]
    vols = [pre_volume(df, d, end_min) for d in past]
    vols = [v for v in vols if v > 0]
    now_v = pre_volume(df, today, end_min)
    if len(vols) < 8:
        return None, now_v, 0.0
    avg = sum(vols) / len(vols)
    return (now_v / avg if avg > 0 else None), now_v, avg


def rank(cands, cfg):
    """cands: [{'symbol','rel','price','pre_dollars','gap'}]. Keep the ones that pass the rules, strongest pre-market volume first."""
    out = []
    for c in cands:
        why = ""
        if c.get("rel") is None:
            why = "not enough history"
        elif c["rel"] < cfg["min_rel"]:
            why = f"pre-market volume {c['rel']:.1f}x (needs {cfg['min_rel']}x)"
        elif (c.get("price") or 0) < cfg["min_price"]:
            why = f"price under ${cfg['min_price']:g}"
        elif (c.get("pre_dollars") or 0) < cfg["min_pre_dollars"]:
            why = f"only ${(c.get('pre_dollars') or 0) / 1e6:.1f}M traded pre-market (needs ${cfg['min_pre_dollars'] / 1e6:g}M)"
        out.append(dict(c, ok=not why, why=why))
    out.sort(key=lambda x: (not x["ok"], -(x.get("rel") or 0)))
    return out


def gap_go(cands, cfg, room):
    """cands: [{'symbol','gap','first_green','vol_rel','price','spread_pct'}]. The ones that pass, biggest gap first, at most `room`."""
    out = []
    for c in cands:
        why = ""
        if c.get("gap") is None or c.get("first_green") is None:
            why = "no open yet"
        elif c["gap"] < cfg["gap_min"]:
            why = f"gap {c['gap']:+.1f}% (needs +{cfg['gap_min']:g}%)"
        elif not c["first_green"]:
            why = "first candle red"
        elif (c.get("vol_rel") or 0) < cfg["gap_vol"]:
            why = f"9:30 volume {c.get('vol_rel') or 0:.1f}x (needs {cfg['gap_vol']:g}x)"
        elif (c.get("price") or 0) < cfg["min_price"]:
            why = f"price under ${cfg['min_price']:g}"
        out.append(dict(c, ok=not why, why=why, rel=c.get("vol_rel"), trigger="gap"))
    out.sort(key=lambda x: (not x["ok"], -(x.get("gap") or 0)))
    return [x for x in out if x["ok"]][:max(0, room)], out


def size(cfg, ask, bp):
    """Shares for one pick: the per-pick amount, never more than 30% of buying power."""
    if not ask or ask <= 0:
        return 0
    return max(0, int(math.floor(min(float(cfg["per_pick"]), 0.3 * float(bp or 0)) / ask)))


def manage(t, bid, now, cfg, trend_green=None):
    """What to do with an open trade now: '' (hold) or the reason to sell everything.
    Updates the trailing stop of an extended trade in place."""
    if t.get("state") != "open" or not bid or not t.get("entry"):
        return ""
    e = float(t["entry"])
    gain = (bid / e - 1) * 100
    t["best"] = max(float(t.get("best") or e), bid)
    if bid <= e * (1 - cfg["stop_pct"] / 100):
        return f"stop -{cfg['stop_pct']:g}%"
    if t.get("trail"):
        if bid <= t["trail"]:
            return f"trailing stop (locked {(t['trail'] / e - 1) * 100:+.1f}%)"
        t["trail"] = round(max(t["trail"], t["best"] * (1 - TRAIL_PCT / 100), e * 1.005), 4)
        if hm(now) >= at(HARD_END):
            return f"{HARD_END} latest exit"
        return ""
    if hm(now) >= at(cfg["sell_by"]):
        if cfg["extend"] and gain >= TRAIL_START and trend_green:
            t["trail"] = round(max(t["best"] * (1 - TRAIL_PCT / 100), e * 1.005), 4)
            t["extended"] = True
            return ""
        return f"{cfg['sell_by']} sell-by time"
    return ""


def day_pnl(d, marks=None):
    tot = 0.0
    for t in d.get("trades", []):
        tot += float(t.get("realized") or 0)
        if t.get("state") == "open" and marks and marks.get(t["symbol"]) and t.get("qty_open") and t.get("entry"):
            tot += (marks[t["symbol"]] - float(t["entry"])) * t["qty_open"]
    return tot


BACKTEST = {"trades": 51, "avg_pct": 0.98, "win_pct": 65, "period": "May 12 - Oct 30 2026, 30 stocks"}
BACKTEST_GAP = {"trades": 70, "avg_pct": 0.76, "win_pct": 57, "period": "May 12 - Oct 30 2026, 30 stocks"}


def stamp(now=None):
    return (now or datetime.now()).isoformat()
