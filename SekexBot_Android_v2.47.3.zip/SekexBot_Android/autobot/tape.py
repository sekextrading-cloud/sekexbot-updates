"""v2.47: Tape Autopilot - trade WITH the market on the days it moves as one, by itself (made for days you can't reach a screen).

The reading ("the tape"): SPY vs its 9:30 open, and how many of your watchlist are green vs red.
  * SELLING OFF: SPY down tape_pct% or more from the open AND 70%+ of your list red.  BUYING: the mirror.  Otherwise MIXED.
The trigger: a stock's own structure break (structure.py) in the tape's direction - the FIRST break of a trend leg only
(a 5-min close under the last swing low after a lower high = short; the mirror = long). Enter on that candle's close.
Exit: a 5-min close back across the exit line (the last lower high / higher low), the target (1.5x the risk), or 2:00 PM.
Skips anything already chase_pct% past its open.
Tested on your own history (SPY + 29 stocks, May 12 - Oct 30 2026, 0.03%/side): tape 0.8%, first break only: 80 trades
over 13 days, +0.27%/trade, 50% winners, positive in both halves. Shorts +0.40% (both halves); longs +0.06% on only 3 up
days, so longs start at half size. "Short everything red" with no structure trigger LOST (-0.4%/trade): that is not this.
Window 9:35-2:00 (the tape is rarely readable before 10:00; the first trades usually land 10:00-10:30)."""
import json
import threading
from datetime import datetime

from .config import DATA_DIR

FILE = DATA_DIR / "tape.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": False, "live": False, "per_trade": 25000, "max_open": 3, "tape_pct": 0.8, "breadth": 0.7, "longs": "half",
               "chase_pct": 5.0, "target_r": 1.5, "end": "14:00", "goal": 500}
OK = {"per_trade": (5000, 10000, 25000, 40000), "max_open": (1, 2, 3, 4, 5), "tape_pct": (0.5, 0.8, 1.2), "longs": ("off", "half", "full"),
      "end": ("13:00", "14:00", "15:30"), "goal": (0, 250, 500, 1000)}
WIN_FROM, WIN_TO = 575, 840          # 9:35 - 2:00 PM entries; manage until the end time
BACKTEST = {"trades": 80, "avg_pct": 0.27, "win_pct": 50, "shorts_pct": 0.40, "longs_pct": 0.06, "days": 13, "period": "May 12 - Oct 30 2026"}


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "tape": {}, "trades": [], "log": [], "history": [], "done": "", "said": {}, "taken": [], "goal_hits": 0}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    for k in ("on", "live"):
        c[k] = bool(c.get(k))
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in ("on", "live"):
            d["cfg"][k] = bool(v)
        elif k in OK:
            if isinstance(OK[k][0], float):
                v = float(v)
            elif isinstance(OK[k][0], int):
                v = int(v)
            if v in OK[k]:
                d["cfg"][k] = v
    save(d)
    return load()


def new_day(d, today):
    if d.get("day") != str(today):
        if d.get("trades"):
            d["history"] = ([{"day": d["day"], "pnl": round(day_pnl(d), 2), "n": len([t for t in d["trades"] if t.get("entry")])}]
                            + d.get("history", []))[:30]
        d.update(day=str(today), tape={}, trades=[], log=[], done="", said={}, taken=[], goal_hits=0)
    return d


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%-I:%M %p"), "msg": msg})
    del d["log"][60:]


def hm(now):
    return now.hour * 60 + now.minute


def at(s):
    h, m = (int(x) for x in s.split(":"))
    return h * 60 + m


def read(spy_open, spy_now, moves, cfg):
    """The tape. moves: {sym: % from its own open}. Returns {'state': 'up'|'down'|'mixed', 'spy': %, 'green': n, 'red': n, 'n': n}."""
    n = len(moves)
    green = sum(1 for v in moves.values() if v > 0)
    red = sum(1 for v in moves.values() if v < 0)
    spy = (spy_now / spy_open - 1) * 100 if spy_open and spy_now else 0.0
    st = "mixed"
    if n:
        if spy >= cfg["tape_pct"] and green / n >= cfg["breadth"]:
            st = "up"
        elif spy <= -cfg["tape_pct"] and red / n >= cfg["breadth"]:
            st = "down"
    return {"state": st, "spy": round(spy, 2), "green": green, "red": red, "n": n}


def want(tape, ev, open_px, cfg):
    """Should this structure 'go' event be taken under this tape? Returns (take, why)."""
    if tape["state"] == "mixed":
        return False, "tape mixed"
    side = "long" if tape["state"] == "up" else "short"
    if ev["side"] != side:
        return False, f"against the tape ({'buying' if tape['state'] == 'up' else 'selling off'})"
    if not ev.get("start"):
        return False, "not the first break of the leg"
    if side == "long" and cfg["longs"] == "off":
        return False, "longs off"
    px = float(ev["price"])
    if open_px and abs(px / open_px - 1) * 100 > cfg["chase_pct"]:
        return False, f"already {abs(px / open_px - 1) * 100:.1f}% from its open: too far to chase"
    risk = abs(px - float(ev["line"]))
    if risk <= 0 or risk > 0.03 * px:
        return False, "exit line too far (risk over 3%)"
    return True, ""


def size(cfg, side, px, bp):
    """Shares: per_trade dollars (longs halved when longs='half'), never more than 30% of buying power."""
    if not px or px <= 0:
        return 0
    dollars = float(cfg["per_trade"]) * (0.5 if side == "long" and cfg["longs"] == "half" else 1.0)
    return max(0, int(min(dollars, 0.3 * float(bp or 0)) // px))


def manage(t, d5_close, bid, ask, now, cfg):
    """'' to hold, or why to get out. t: an open tape trade {side, entry, line, target}. d5_close: last CLOSED 5-min candle's close."""
    if t.get("state") != "open":
        return ""
    d_ = 1 if t["side"] == "long" else -1
    mark = bid if d_ > 0 else ask
    if mark and t.get("target") and (mark - t["target"]) * d_ >= 0:
        return f"target ${t['target']:.2f}"
    if d5_close is not None and (d5_close - t["line"]) * d_ < 0:
        return f"5-min close {'under' if d_ > 0 else 'over'} the exit line ${t['line']:.2f}"
    if hm(now) >= at(cfg["end"]):
        return f"{cfg['end']} time exit"
    return ""


def day_pnl(d, marks=None):
    tot = 0.0
    for t in d.get("trades", []):
        tot += float(t.get("realized") or 0)
        if t.get("state") == "open" and marks and marks.get(t["symbol"]) and t.get("qty_open") and t.get("entry"):
            d_ = 1 if t["side"] == "long" else -1
            tot += (marks[t["symbol"]] - float(t["entry"])) * d_ * t["qty_open"]
    return tot


def stamp(now=None):
    return (now or datetime.now()).isoformat()
