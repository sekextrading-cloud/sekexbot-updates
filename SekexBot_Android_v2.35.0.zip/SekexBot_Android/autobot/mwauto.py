"""v2.35: Morning Wave autopilot (4:00 to 10:00 AM ET, longs only).

What it looks for (the up-wave you see on the 5-minute chart, IREN style): the 5-minute trend ribbon turns GREEN (the chart's BUY)
or a JUMP IN pullback buy appears in a green trend, AND
  - price is above today's VWAP (counted from 4 AM),
  - that candle's volume is at least 1.3x the morning's typical 5-minute volume and at least $50k traded (real buyers, not a few prints),
  - price is not stretched: the close is within 3 ATR of the slow line (don't chase),
  - the stock is $2 or more.
Trade: limit buy at the ask (extended hours allow limit orders only). Stop under the last 3 candles' low / the slow line.
Exits it manages itself (stop orders are not allowed before 9:30): half off at +1.5R and the stop moves to break-even;
the rest rides until a 5-minute close under the fast line, the ribbon turns red, +3R, or 10:00 AM.
Day rules: risk per trade (default $250), stop for the day at +$1,000 or -$500 (closes what is open), at most 3 open and 8 a morning,
one trade per stock per wave. PAPER only unless you switch LIVE on (then only on days you arm with your PIN).
No setup wins every time; $1,000 a day is a goal, not a promise."""
import json
import math
import threading
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from .config import DATA_DIR
from .indicators import ribbon

FILE = DATA_DIR / "mwauto.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": False, "live": False, "risk": 250, "goal": 1000, "max_loss": 500, "start": "04:00", "end": "10:00",
               "max_open": 3, "max_trades": 8, "t1_r": 1.5, "t2_r": 3.0, "vol_mult": 1.3, "min_dollar_vol": 50000, "min_price": 2.0,
               "max_spread_pct": 0.4, "jumpin": True, "movers": True, "max_notional": 50000}
OK = {"risk": (100, 150, 250, 400), "goal": (500, 1000, 1500, 0), "max_loss": (300, 500, 1000), "end": ("09:45", "10:00", "10:30"),
      "max_open": (1, 2, 3, 4), "max_trades": (4, 6, 8, 12)}


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "trades": [], "done": "", "log": [], "history": []}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    c["on"], c["live"], c["jumpin"], c["movers"] = bool(c["on"]), bool(c["live"]), bool(c["jumpin"]), bool(c["movers"])
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in ("on", "live", "jumpin", "movers"):
            d["cfg"][k] = bool(v)
        elif k in OK and v in OK[k]:
            d["cfg"][k] = v
    save(d)
    return load()


def new_day(d, today):
    if d.get("day") != str(today):
        if d.get("trades"):
            d["history"] = ([{"day": d["day"], "pnl": round(day_pnl(d), 2), "n": len(d["trades"])}] + d.get("history", []))[:30]
        d.update(day=str(today), trades=[], done="", log=[])
    return d


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%-I:%M %p"), "msg": msg})
    del d["log"][60:]


def in_window(now, cfg):
    hm = now.hour * 60 + now.minute
    sh, sm = (int(x) for x in cfg["start"].split(":"))
    eh, em = (int(x) for x in cfg["end"].split(":"))
    return now.weekday() < 5 and sh * 60 + sm <= hm < eh * 60 + em


def day_pnl(d, marks=None):
    """Realized P&L of today's trades plus open ones at `marks` {sym: bid}."""
    tot = 0.0
    for t in d.get("trades", []):
        tot += float(t.get("realized") or 0)
        if t.get("state") == "open" and marks and marks.get(t["symbol"]) and t.get("qty_open"):
            tot += (marks[t["symbol"]] - t["entry"]) * t["qty_open"]
    return tot


def _vwap_today(d1, start):
    t = d1[d1.index >= start]
    if t.empty:
        return None
    tp = (t["high"] + t["low"] + t["close"]) / 3
    v = t["volume"].clip(lower=0)
    return float((tp * v).sum() / v.sum()) if v.sum() > 0 else float(t["close"].iloc[-1])


def signal(full, now, cfg, jump_up=False):
    """full: 1-minute (today) + 5-minute (earlier days) bars, oldest first. Returns a setup dict or None (with the reason in 'why_not').
    jump_up: a JUMP IN pullback buy is on the latest closed 5-minute candle (from the jump scanner)."""
    out = {"ok": False, "why_not": ""}
    h = ribbon(full, tf="5min")
    if len(h) < 30:
        out["why_not"] = "not enough history"
        return out
    st = h["state"].values
    i = len(h) - 1
    flip = st[i] > 0 and (st[i - 1] <= 0 or (st[i - 2] <= 0 and st[i - 1] > 0))      # the BUY candle, or one candle after it
    kind = "wave start (5-min trend turned green)" if flip else "jump in (pullback buy in a green trend)" if (jump_up and st[i] > 0 and cfg["jumpin"]) else ""
    if not kind:
        out["why_not"] = "no BUY on the 5-minute chart"
        return out
    start = now.replace(hour=4, minute=0, second=0, microsecond=0)
    today5 = h[h.index >= start]
    c, a = float(h["close"].iloc[i]), float(h["atr"].iloc[i] or 0)
    vw = _vwap_today(full, start)
    if c < cfg["min_price"]:
        out["why_not"] = f"price under ${cfg['min_price']:g}"
        return out
    if vw and c <= vw:
        out["why_not"] = f"under VWAP {vw:.2f}"
        return out
    vol = float(h["volume"].iloc[i])
    base = float(np.median(today5["volume"].iloc[:-1].values[-12:])) if len(today5) > 3 else float(np.median(h["volume"].iloc[-13:-1].values))
    if base > 0 and vol < cfg["vol_mult"] * base:
        out["why_not"] = f"volume {vol / base:.1f}x normal (needs {cfg['vol_mult']}x)"
        return out
    if vol * c < cfg["min_dollar_vol"]:
        out["why_not"] = f"only ${vol * c / 1000:.0f}k traded on that candle"
        return out
    slow, fast = float(h["slow"].iloc[i]), float(h["fast"].iloc[i])
    if a > 0 and c - slow > 3.0 * a:
        out["why_not"] = "stretched far above the trend line (don't chase)"
        return out
    low3 = float(h["low"].iloc[i - 2:i + 1].min())
    stop = min(low3, slow) - 0.1 * (a or c * 0.003)
    risk = c - stop
    risk = max(risk, c * 0.004)
    risk = min(risk, c * 0.03)
    stop = round(c - risk, 2)
    return {"ok": True, "kind": kind, "price": round(c, 2), "stop": stop, "risk": round(risk, 4), "t1": round(c + cfg["t1_r"] * risk, 2),
            "t2": round(c + cfg["t2_r"] * risk, 2), "vwap": round(vw, 2) if vw else None, "vol_x": round(vol / base, 1) if base else None,
            "bar_t": str(h.index[i]), "fast": round(fast, 2), "why_not": ""}


def size(cfg, risk_per_share, price, bp, bar_volume=None):
    """Shares so a stop-out loses about cfg['risk'] dollars, capped by buying power (30%), the notional cap and the candle's volume (25%)."""
    if not risk_per_share or risk_per_share <= 0 or not price:
        return 0
    q = math.floor(cfg["risk"] / risk_per_share)
    q = min(q, math.floor(min(0.3 * (bp or 0), cfg["max_notional"]) / price))
    if bar_volume:
        q = min(q, math.floor(0.25 * bar_volume))
    return max(0, int(q))


def manage(t, bid, last5, now, cfg):
    """What to do with an open trade now: [] or a list of ('sell', qty, why). Moves the stop to break-even after the first target.
    last5: the latest closed 5-minute candle {'close','fast','state'}."""
    acts = []
    if t.get("state") != "open" or not bid or not t.get("qty_open"):
        return acts
    q = t["qty_open"]
    if bid <= t["stop"]:
        return [("sell", q, "stop" if not t.get("t1_done") else "break-even stop")]
    if not t.get("t1_done") and bid >= t["t1"]:
        half = max(1, q // 2) if q > 1 else q
        t["t1_done"] = True
        t["stop"] = max(t["stop"], t["entry"])
        acts.append(("sell", half, f"first target +{cfg['t1_r']}R: half off, stop to break-even"))
        q -= half
        if q <= 0:
            return acts
    if bid >= t["t2"]:
        return acts + [("sell", q, f"+{cfg['t2_r']}R target")]
    if last5 is not None and t.get("t1_done"):
        if last5.get("state", 1) < 0:
            return acts + [("sell", q, "5-min trend turned red")]
        if last5.get("close") is not None and last5.get("fast") is not None and last5["close"] < last5["fast"] and last5.get("t") != t.get("entry_bar"):
            return acts + [("sell", q, "5-min close under the fast line")]
    return acts
