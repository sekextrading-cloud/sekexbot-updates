"""v2.29: the VWAP strip: where price sits against today's VWAP, the overnight VWAP, yesterday's VWAP and the opening range, plus a trend word."""
import numpy as np
import pandas as pd


def _v(d):
    if d is None or len(d) == 0 or float(d["volume"].sum()) <= 0:
        return None
    tp = (d["high"] + d["low"] + d["close"]) / 3
    return float((tp * d["volume"]).sum() / d["volume"].sum())


def compute(d1, now):
    """d1: 1-minute bars (extended hours) covering at least yesterday and today. Returns a dict, or None without enough data."""
    if d1 is None or len(d1) < 10:
        return None
    px = float(d1["close"].iloc[-1])
    today = d1[d1.index.date == now.date()]
    prev_days = sorted({x for x in d1.index.date if x < now.date()})
    hm = today.index.hour * 60 + today.index.minute
    reg = today[(hm >= 570) & (hm < 960)]
    pre = today[hm < 570]
    y = None
    if prev_days:
        yd = d1[d1.index.date == prev_days[-1]]
        yh = yd.index.hour * 60 + yd.index.minute
        y = _v(yd[(yh >= 570) & (yh < 960)])
    t_v = _v(reg) if len(reg) else _v(pre)
    o_v = _v(pre)
    orr = None
    rh = reg.index.hour * 60 + reg.index.minute if len(reg) else []
    first = reg[(rh >= 570) & (rh < 600)] if len(reg) else reg
    if len(first):
        hi, lo = float(first["high"].max()), float(first["low"].min())
        done = len(reg) and (reg.index[-1].hour * 60 + reg.index[-1].minute) >= 600
        orr = {"hi": round(hi, 2), "lo": round(lo, 2), "pos": "Above" if px > hi else "Below" if px < lo else "Inside", "forming": not done}
    five = d1.resample("5min").agg({"close": "last"}).dropna()
    trend = "Mixed"
    if len(five) >= 22:
        e9, e20 = five["close"].ewm(span=9, adjust=False).mean().iloc[-1], five["close"].ewm(span=20, adjust=False).mean().iloc[-1]
        op = float(reg["open"].iloc[0]) if len(reg) else float(today["open"].iloc[0]) if len(today) else px
        trend = "Up" if (e9 > e20 and px > op) else "Down" if (e9 < e20 and px < op) else "Mixed"
    f = lambda v: None if v is None else round(v, 2)
    above = lambda v: None if v is None else bool(px > v)
    return {"price": round(px, 2), "today": f(t_v), "overnight": f(o_v), "yesterday": f(y), "today_above": above(t_v), "overnight_above": above(o_v),
            "yesterday_above": above(y), "range": orr, "trend": trend}
