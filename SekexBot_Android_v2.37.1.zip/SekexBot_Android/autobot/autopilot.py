"""v2.12: Radar Autopilot. Decides which Day-drive cards (and 24-hour board cards) the bot may take WITHOUT a tap, by YOUR rules.
This module holds the settings, the rule check and the activity log. Orders go through the bot's normal paths (picks for stocks,
the options module for options), so the daily loss limit, spread, news and borrow checks all still apply. It never changes the
daily loss limit."""
import json
import threading
import time
from pathlib import Path

DEFAULTS = {
    "on": False,                 # master switch (off by default)
    "dry": True,                 # log only: do everything except send the order. Starts ON so the first run is a rehearsal.
    "win": {"overnight": False, "open": True, "lunch": True, "close": True, "board24": False},
    "buys": True, "shorts": False,
    "instr": "stocks",           # stocks | options | both
    "min_score": 70, "min_rate": 60, "min_n": 5,
    "max_day": 3, "max_open": 2, "max_notional": 2000,
    "last_entry": "15:30",       # no new regular-hours entries after this (HH:MM)
    "hold_overnight": False,     # False: autopilot stock trades are closed at flat_by
    "flat_by": "15:55",
    "spy_stop": 1.5,             # pause new entries when SPY is down this % on the day (0 = off)
    "theme_cap": 1,              # at most this many open trades in one theme (crypto miners, semis, ...)
    "disabled": {},              # window -> reason, set automatically after 4 losers in a row
}

THEMES = {
    "crypto/AI-datacenter": {"IREN", "CIFR", "WULF", "CORZ", "MARA", "RIOT", "CLSK", "BTBT", "APLD", "HUT", "BITF", "COIN", "MSTR", "HIVE", "CRWV", "NBIS"},
    "semiconductors": {"NVDA", "AMD", "AVGO", "TSM", "MU", "INTC", "QCOM", "ARM", "SMCI", "MRVL", "AMAT", "LRCX", "TXN"},
    "megacap tech": {"AAPL", "MSFT", "GOOGL", "GOOG", "AMZN", "META", "NFLX", "TSLA"},
    "index ETFs": {"SPY", "QQQ", "IWM", "DIA", "VOO", "IVV"},
    "EV / clean": {"RIVN", "LCID", "NIO", "PLUG", "ENPH", "FSLR", "RUN"},
    "biotech / health": {"TEM", "HIMS", "RXRX", "SDGR", "TXG"},
}


def theme_of(sym):
    for k, v in THEMES.items():
        if sym in v:
            return k
    return sym


def _mins(hhmm, default):
    try:
        h, m = str(hhmm).split(":")
        return int(h) * 60 + int(m)
    except Exception:
        return default


class Autopilot:
    def __init__(self, cfg_path, log_path):
        self.cfg_path, self.log_path = Path(cfg_path), Path(log_path)
        self.lock = threading.Lock()
        self.cfg = json.loads(json.dumps(DEFAULTS))
        self.state = {"day": "", "taken": [], "armed": {}, "results": {}, "summary_sent": ""}
        self.logs = []
        try:
            raw = json.loads(self.cfg_path.read_text())
            self._merge(raw.get("cfg", raw))
            self.state.update(raw.get("state", {}))
        except Exception:
            pass
        try:
            self.logs = json.loads(self.log_path.read_text())[:300]
        except Exception:
            self.logs = []

    def _merge(self, raw):
        for k, v in raw.items():
            if k in ("win", "disabled") and isinstance(v, dict):
                self.cfg[k].update(v)
            elif k in self.cfg:
                self.cfg[k] = v

    def save(self):
        try:
            self.cfg_path.write_text(json.dumps({"cfg": self.cfg, "state": self.state}))
            self.log_path.write_text(json.dumps(self.logs[:300]))
        except Exception:
            pass

    def new_day(self, day):
        if self.state.get("day") != day:
            self.state.update(day=day, taken=[], summary_sent="")
            self.state["armed"] = {k: v for k, v in self.state.get("armed", {}).items() if v.get("day") == day or v.get("result") is None}

    def set_cfg(self, o):
        c = self.cfg
        for k in ("on", "dry", "buys", "shorts", "hold_overnight"):
            if k in o and o[k] is not None:
                c[k] = bool(o[k])
        if o.get("instr") in ("stocks", "options", "both"):
            c["instr"] = o["instr"]
        for k, lo, hi in (("min_score", 40, 98), ("min_rate", 40, 95), ("min_n", 3, 30), ("max_day", 1, 20), ("max_open", 1, 8),
                          ("max_notional", 100, 100000), ("spy_stop", 0, 10), ("theme_cap", 1, 6)):
            if o.get(k) is not None:
                v = float(o[k])
                c[k] = int(min(hi, max(lo, v))) if k not in ("spy_stop",) else round(min(hi, max(lo, v)), 1)
        for k in ("last_entry", "flat_by"):
            if o.get(k):
                s = str(o[k])
                if len(s) == 5 and s[2] == ":" and s[:2].isdigit() and s[3:].isdigit():
                    c[k] = s
        if isinstance(o.get("win"), dict):
            for w, v in o["win"].items():
                if w in c["win"]:
                    c["win"][w] = bool(v)
                    if v:
                        c["disabled"].pop(w, None)
        self.save()

    def log(self, action, text, window="", symbol="", now_txt=""):
        with self.lock:
            self.logs.insert(0, {"t": now_txt or time.strftime("%H:%M"), "day": self.state.get("day", ""), "a": action, "w": window, "s": symbol, "m": text})
            del self.logs[300:]
        self.save()

    def check(self, card, ctx):
        """(ok, reason). ctx: {now_min, taken_n, open_n, spy_move, theme_open: {theme: n}, held: set, shorts_ok: (ok, why), window_on: bool}."""
        c = self.cfg
        w = card.get("window", "")
        if not c["on"]:
            return False, "autopilot is off"
        if w in c["disabled"]:
            return False, f"{w} window paused: {c['disabled'][w]}"
        if not c["win"].get(w, False):
            return False, f"{w} window is on manual"
        up = card.get("side") == "up"
        if up and not c["buys"]:
            return False, "buys are off"
        if not up:
            if not c["shorts"]:
                return False, "shorts are off"
            ok, why = ctx.get("shorts_ok", (True, ""))
            if not ok:
                return False, "can't short: " + why
        if card.get("score", 0) < c["min_score"]:
            return False, f"score {card.get('score')} is under {c['min_score']}"
        if not card.get("has_record"):
            return False, f"only {card.get('n', 0)} past cases, needs {c['min_n']}"
        if card.get("n", 0) < c["min_n"]:
            return False, f"only {card.get('n', 0)} past cases, needs {c['min_n']}"
        if card.get("hit_rate", 0) < c["min_rate"]:
            return False, f"record {card.get('hit_rate')}% is under {c['min_rate']}%"
        nm = ctx.get("now_min", 0)
        if w != "overnight" and nm > _mins(c["last_entry"], 930):
            return False, f"after the last-entry time {c['last_entry']}"
        if ctx.get("taken_n", 0) >= c["max_day"]:
            return False, f"already {ctx.get('taken_n')} autopilot trades today (max {c['max_day']})"
        if ctx.get("open_n", 0) >= c["max_open"]:
            return False, f"{ctx.get('open_n')} autopilot trades open (max {c['max_open']})"
        sym = card.get("symbol", "")
        if sym in ctx.get("held", set()):
            return False, "you already hold it (autopilot leaves your own trades alone)"
        if sym in self.state.get("taken", []):
            return False, "already taken today"
        th = theme_of(sym)
        if ctx.get("theme_open", {}).get(th, 0) >= c["theme_cap"]:
            return False, f"already {ctx['theme_open'][th]} open in the same theme ({th})"
        sp = ctx.get("spy_move")
        if c["spy_stop"] and sp is not None and up and sp <= -c["spy_stop"]:
            return False, f"market is down {abs(sp):.1f}% today: pausing buys"
        if c["spy_stop"] and sp is not None and (not up) and sp >= c["spy_stop"]:
            return False, f"market is up {sp:.1f}% today: pausing shorts"
        return True, ""

    def note_result(self, window, pnl):
        """Record a closed autopilot trade; after 4 losers in a row the window is paused until you switch it on again."""
        res = self.state["results"].setdefault(window, [])
        res.append(round(float(pnl), 2))
        del res[:-8]
        if len(res) >= 4 and all(x < 0 for x in res[-4:]) and window not in self.cfg["disabled"]:
            self.cfg["disabled"][window] = "last 4 trades all lost"
            self.save()
            return True
        self.save()
        return False
