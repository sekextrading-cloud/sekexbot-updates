"""v2.14 profit-peak learner. Every finished trade (bot or yours) leaves one 'trip': how high it went (peak, % of entry)
and where it ended. From those trips we pick the take-profit % that would have banked the most, per stock and session.
Pure functions + a small JSON file; nothing here places orders."""
from __future__ import annotations
import json
import threading
import time
from pathlib import Path

_LOCK = threading.Lock()
MAX_TRIPS = 600


def _load(path) -> list:
    try:
        d = json.loads(Path(path).read_text())
        return d if isinstance(d, list) else []
    except Exception:
        return []


def record(path, sym: str, sess: str, peak_pct: float, final_pct: float, who: str = "bot") -> None:
    """Store one finished trip. Ignores junk (no price movement tracked)."""
    try:
        if peak_pct is None or final_pct is None:
            return
        with _LOCK:
            rows = _load(path)
            rows.append({"t": int(time.time()), "sym": sym.upper(), "sess": sess or "REGULAR",
                         "peak": round(float(max(peak_pct, final_pct, 0.0)), 4), "final": round(float(final_pct), 4), "who": who})
            Path(path).write_text(json.dumps(rows[-MAX_TRIPS:]))
    except Exception:
        pass


def best_target(trips: list, cost_pct: float = 0.0, min_n: int = 8):
    """The take-profit % (of entry) that would have banked the most over these trips.
    A trip whose peak reached the target banks (target - cost); otherwise it ends where it ended.
    Returns {"pct", "gain_avg", "now_avg", "n", "hit"} or None when there are too few trips."""
    if len(trips) < min_n:
        return None
    best = None
    base = sum(x["final"] for x in trips) / len(trips)
    x = 0.08
    while x <= 3.0001:
        tot, hit = 0.0, 0
        for tr in trips:
            if tr["peak"] >= x:
                tot += x - cost_pct
                hit += 1
            else:
                tot += tr["final"]
        avg = tot / len(trips)
        if best is None or avg > best["gain_avg"] + 1e-9:
            best = {"pct": round(x, 2), "gain_avg": round(avg, 4), "hit": hit}
        x += 0.02
    best["now_avg"] = round(base, 4)
    best["n"] = len(trips)
    return best


def suggest(path, sym: str, sess: str, cost_pct: float = 0.0, min_n: int = 8):
    """Most specific scope with enough trips: this stock+session, this stock, this session (needs 2x). None = not enough yet."""
    rows = _load(path)
    sym = sym.upper()
    for scope, sel, need in (
        ("this stock in this session", [r for r in rows if r["sym"] == sym and r["sess"] == sess], min_n),
        ("this stock", [r for r in rows if r["sym"] == sym], min_n),
        ("this session, all stocks", [r for r in rows if r["sess"] == sess], min_n * 2),
    ):
        b = best_target(sel, cost_pct, need)
        if b:
            b["scope"] = scope
            return b
    return None


def stats(path) -> dict:
    rows = _load(path)
    return {"trips": len(rows), "stocks": len({r["sym"] for r in rows})}
