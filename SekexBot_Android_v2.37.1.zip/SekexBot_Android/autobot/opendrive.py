"""v2.11: Open drive. The first minutes after the 9:30 open, a stock that was quiet in pre-market can break above its pre-market high on a
burst of volume and keep running. This finds those breakouts live and shows each stock's own record of such breakouts (kept going / failed).
Information and alerts; the bot trades one only if you switch that on."""
from datetime import time
import statistics as st
import pandas as pd

NY = "America/New_York"
OPEN = time(9, 30)
MIN_N = 4            # past breakouts needed before a hit rate is shown


def _split(d):
    d = d.sort_index()
    d.index = pd.to_datetime(d.index).tz_convert(NY)
    return d


def history(d15):
    """From 45 days of 15-minute bars: (record, baseline).
    record = {n, hit, fail}: past open breakouts (first regular bar closes above the pre-market high, +0.8% or more, 2x+ the usual volume);
    'hit' = it ran at least 1% further within the next 30 minutes, 'fail' = it fell back under the pre-market high.
    baseline = {first, second}: average volume of the 9:30 and 9:45 bars."""
    d = _split(d15)
    days = {}
    for ts, r in d.iterrows():
        days.setdefault(ts.date(), []).append((ts, r))
    firsts, seconds, rows = [], [], []
    for day, bars in days.items():
        pre = [r for ts, r in bars if time(4, 0) <= ts.time() < OPEN]
        reg = [(ts, r) for ts, r in bars if OPEN <= ts.time() < time(16, 0)]
        if len(reg) < 4:
            continue
        pmh = max((r["high"] for r in pre), default=None)
        f, s = reg[0][1], reg[1][1]
        firsts.append(float(f["volume"]))
        seconds.append(float(s["volume"]))
        rows.append((pmh, f, reg[1][1], reg[2][1]))
    if not firsts:
        return {"n": 0, "hit": 0, "fail": 0}, {"first": 0, "second": 0}
    av1, av2 = st.mean(firsts), st.mean(seconds)
    n = hit = fail = 0
    for pmh, f, s, t in rows:
        if pmh is None or av1 <= 0:
            continue
        if f["close"] > pmh * 1.001 and f["close"] >= f["open"] * 1.008 and f["volume"] >= 2 * av1:
            n += 1
            nxt_hi = max(s["high"], t["high"])
            nxt_lo = min(s["low"], t["low"])
            if nxt_hi >= f["close"] * 1.01:
                hit += 1
            elif nxt_lo < pmh:
                fail += 1
    return {"n": n, "hit": hit, "fail": fail}, {"first": av1, "second": av2}


def _expected_cum(base, minutes):
    """Usual volume from the open to `minutes` after it (first 15-min bar, then the second)."""
    f, s = base["first"], base["second"]
    if minutes <= 15:
        return f * minutes / 15
    return f + s * (min(minutes, 30) - 15) / 15 + (s / 15) * max(0, minutes - 30)


def detect(sym, d1, now, rec, base, vol_mult=3.0, min_move=0.8, price=None):
    """d1: today's 1-minute bars from 4:00. Returns a card dict or None."""
    if d1 is None or not len(d1):
        return None
    d1 = _split(d1)
    today = now.date()
    d1 = d1[d1.index.date == today]
    pre = d1[(d1.index.time >= time(4, 0)) & (d1.index.time < OPEN)]
    reg = d1[d1.index.time >= OPEN]
    if len(reg) < 2:
        return None
    minutes = max(1, int((now - reg.index[0]).total_seconds() // 60))
    if minutes > 60:
        return None
    o = float(reg["open"].iloc[0])
    p = float(price or reg["close"].iloc[-1])
    pmh = float(pre["high"].max()) if len(pre) else o
    vol = float(reg["volume"].sum())
    exp = _expected_cum(base, minutes) if base.get("first") else 0
    rvol = vol / exp if exp > 0 else 0
    move = (p / o - 1) * 100
    if not (p > pmh * 1.001 and move >= min_move and rvol >= vol_mult):
        return None
    rng = float((reg["high"] - reg["low"]).mean())
    hi_since = float(reg["high"].max())
    lo_since = float(reg["low"].min())
    stop = round(min(pmh * 0.998, p - max(0.01 * p, 0.04)), 2)
    zlo, zhi = round(max(pmh, p * 0.997), 2), round(p * 1.003, 2)
    mid = (zlo + zhi) / 2
    risk = max(mid - stop, max(0.01 * p, 0.04))
    n, hit, fail = rec.get("n", 0), rec.get("hit", 0), rec.get("fail", 0)
    hit_rate = round(hit / n * 100) if n >= MIN_N else None
    score = 50 + min(25, (rvol - vol_mult) * 4) + min(15, move * 4)
    if hit_rate is not None:
        score += (hit_rate - 50) * 0.3
    score = int(max(40, min(98, round(score))))
    return {"symbol": sym, "side": "up", "kind": "OPEN_DRIVE", "name": "OPEN DRIVE BREAKOUT", "score": score,
            "label": "STRONG" if score >= 75 else "GOOD" if score >= 62 else "WEAK", "price": round(p, 2), "open": round(o, 2),
            "pmh": round(pmh, 2), "move_open_pct": round(move, 2), "rvol": round(rvol, 1), "minutes": minutes,
            "zone": [zlo, zhi], "stop": stop, "tp1": round(mid + 1.5 * risk, 2), "tp2": round(mid + 2.5 * risk, 2),
            "n": n, "hits": hit, "fails": fail, "hit_rate": hit_rate if hit_rate is not None else 0, "has_record": hit_rate is not None,
            "move_pct": 1.0, "atr": round(rng * 5, 2), "window": "now to about 30 minutes", "entry_day": "",
            "high": round(hi_since, 2), "low": round(lo_since, 2)}
