"""v2.36: Edge score. One number per stock from -100 (strong sell) to +100 (strong buy), blended from 5 parts, the way a fund
combines many weak signals into one ranking instead of acting on any single one:
  trend 30%     5-minute ribbon colour and how wide it is, plus the 15-minute trend
  momentum 20%  move since yesterday's close
  VWAP 15%      price above or below today's VWAP (from 4 AM), in ATRs
  volume 15%    last 30 minutes' volume vs the morning's normal, in the direction price moved
  setups 20%    setups firing right now (Morning Wave, Jump in/out, Open sweep, VWAP rejection, Cycle turn)
It ranks and filters; it is not a prediction and not advice."""
import math

import numpy as np

from .indicators import ribbon

W = {"trend": 0.30, "momentum": 0.20, "vwap": 0.15, "volume": 0.15, "setups": 0.20}


def label(s):
    return "STRONG BUY" if s >= 60 else "BUY LEAN" if s >= 30 else "NEUTRAL" if s > -30 else "SELL LEAN" if s > -60 else "STRONG SELL"


def _clip(x, lo=-1.0, hi=1.0):
    return max(lo, min(hi, float(x)))


def score(full, now, hits=None):
    """full: 1-minute bars for today plus 5-minute bars of earlier days, oldest first. hits: [(name, 'up'|'down')] setups firing now.
    Returns None when there is not enough data."""
    if full is None or len(full) < 40:
        return None
    h = ribbon(full, tf="5min")
    if len(h) < 30:
        return None
    c = float(h["close"].iloc[-1])
    a = float(h["atr"].iloc[-1] or 0) or c * 0.003
    st = int(h["state"].iloc[-1])
    width = min(1.0, abs(float(h["fast"].iloc[-1]) - float(h["slow"].iloc[-1])) / a)
    c15 = h["close"].resample("15min").last().dropna()
    htf = 0
    if len(c15) >= 22:
        f, s_ = c15.ewm(span=9, adjust=False).mean().iloc[-2], c15.ewm(span=20, adjust=False).mean().iloc[-2]      # last COMPLETED 15-min bar
        htf = 1 if f > s_ else -1 if f < s_ else 0
    trend = _clip(st * (0.5 + 0.5 * width) * 0.75 + 0.25 * htf)
    start = now.replace(hour=4, minute=0, second=0, microsecond=0)
    before = h[h.index < start]
    prev = before[(before.index.hour * 60 + before.index.minute) < 960]
    pc = float(prev["close"].iloc[-1]) if len(prev) else float(h["close"].iloc[0])
    chg = (c / pc - 1) * 100 if pc else 0.0
    momentum = _clip(math.tanh(chg / 3.0))
    t = full[full.index >= start]
    vw = None
    if len(t) and t["volume"].sum() > 0:
        tp = (t["high"] + t["low"] + t["close"]) / 3
        vw = float((tp * t["volume"]).sum() / t["volume"].sum())
    vwap = _clip(math.tanh((c - vw) / a)) if vw else 0.0
    today5 = h[h.index >= start]
    ref = today5 if len(today5) >= 12 else h.iloc[-60:]
    base = float(np.median(ref["volume"].values[:-6])) if len(ref) > 8 else float(np.median(h["volume"].values[-60:]))
    rv = float(h["volume"].iloc[-6:].mean()) / base if base > 0 else 1.0
    move = c - float(h["close"].iloc[-7]) if len(h) > 7 else 0.0
    volume = _clip((1 if move > 0 else -1 if move < 0 else 0) * max(0.0, min(1.0, (rv - 1) / 2)))
    hits = hits or []
    setups = _clip(0.5 * sum(1 if sd == "up" else -1 for _, sd in hits))
    parts = {"trend": round(trend, 2), "momentum": round(momentum, 2), "vwap": round(vwap, 2), "volume": round(volume, 2), "setups": round(setups, 2)}
    s = int(round(100 * sum(W[k] * v for k, v in parts.items())))
    facts = {"state": st, "chg": round(chg, 2), "rvol": round(rv, 1), "vwap": round(vw, 2) if vw else None, "price": round(c, 2),
             "setups": [n for n, _ in hits]}
    return {"score": s, "label": label(s), "parts": parts, "facts": facts}
