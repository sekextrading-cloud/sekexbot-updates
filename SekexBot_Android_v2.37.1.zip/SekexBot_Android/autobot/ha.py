"""🕯 Heikin Ashi: smoothed candles for a trend filter and a chart view.
Heikin Ashi candle: close = (O+H+L+C)/4, open = midpoint of the previous HA candle. A run of green candles is an uptrend, red a downtrend.
The filter only decides whether a NEW entry is allowed (buy needs green, short needs red). It never touches stops, exits or loss limits.
Fails open: with no data the trade is allowed."""
import json
import threading
import time
from pathlib import Path

import pandas as pd

from .config import DATA_DIR

FILE = DATA_DIR / "ha.json"
_L = threading.Lock()
_CACHE = {}          # sym -> (t, (color, run))
DEFAULT = {"on": False, "n": 3, "stocks": True, "options": True, "auto": True}


def load():
    d = dict(DEFAULT)
    try:
        d.update(json.loads(Path(FILE).read_text()))
    except Exception:
        pass
    d["n"] = min(6, max(2, int(d.get("n", 3))))
    return d


def save(d):
    c = dict(DEFAULT)
    c.update({k: d[k] for k in DEFAULT if k in d})
    c["n"] = min(6, max(2, int(c["n"])))
    try:
        Path(FILE).write_text(json.dumps({k: (bool(v) if k != "n" else int(v)) for k, v in c.items()}))
    except Exception:
        pass
    _CACHE.clear()
    return c


def ha_df(d):
    """OHLC frame -> Heikin Ashi OHLC frame (same index)."""
    o, h, l, c = (d[k].astype(float).values for k in ("open", "high", "low", "close"))
    hc = (o + h + l + c) / 4.0
    ho = hc.copy()
    ho[0] = (o[0] + c[0]) / 2.0
    for i in range(1, len(hc)):
        ho[i] = (ho[i - 1] + hc[i - 1]) / 2.0
    hh = pd.Series(h).combine(pd.Series(ho), max).combine(pd.Series(hc), max).values
    hl = pd.Series(l).combine(pd.Series(ho), min).combine(pd.Series(hc), min).values
    return pd.DataFrame({"open": ho, "high": hh, "low": hl, "close": hc}, index=d.index)


def to5(d1):
    return d1[["open", "high", "low", "close", "volume"]].resample("5min", label="left", closed="left").agg(
        {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna(subset=["open"])


def state(d5, n=3):
    """('green'|'red'|'mixed', run length) from the last CLOSED 5-minute candles."""
    if d5 is None or len(d5) < 8:
        return ("unknown", 0)
    h = ha_df(d5)
    col = ["g" if c > o else "r" if c < o else "x" for o, c in zip(h["open"].values, h["close"].values)]
    last = col[-1]
    if last == "x":
        return ("mixed", 0)
    run = 0
    for x in reversed(col):
        if x != last:
            break
        run += 1
    return (("green" if last == "g" else "red") if run >= n else "mixed", run)


def gate(sym, up, scope, bars_fn, now_ts=None):
    """Reason to block a new entry, or ''. scope: stocks | options | auto. up=True for a buy / call, False for a short / put."""
    c = load()
    if not c["on"] or not c.get(scope, True):
        return ""
    t = time.time() if now_ts is None else now_ts
    with _L:
        hit = _CACHE.get(sym)
    if hit and t - hit[0] < 60:
        st = hit[1]
    else:
        try:
            d1 = bars_fn(sym)
            d5 = to5(d1) if d1 is not None and len(d1) else None
            if d5 is not None and len(d5) > 1:
                d5 = d5.iloc[:-1]                         # the forming candle is not a signal yet
            st = state(d5, c["n"])
        except Exception:
            st = ("unknown", 0)
        with _L:
            _CACHE[sym] = (t, st)
    color, run = st
    if color == "unknown":
        return ""
    if up and color != "green":
        return f"Heikin Ashi is {color} (needs {c['n']}+ green candles to buy)"
    if (not up) and color != "red":
        return f"Heikin Ashi is {color} (needs {c['n']}+ red candles to short)"
    return ""
