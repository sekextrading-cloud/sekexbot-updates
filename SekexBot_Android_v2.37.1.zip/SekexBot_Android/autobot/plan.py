"""📋 Morning plan: for each stock you name, the gap, the key levels and a plain buy / short entry with stop and targets.
Display only. It places no orders and changes no settings. Built from 1-minute bars (with pre-market / after-hours / overnight)."""
import pandas as pd


def _r(x):
    return round(float(x), 2)


def build_plan(sym, d1, now, earnings=""):
    """d1: 1-minute bars (NY time) covering the last few days. Returns a dict for the dashboard."""
    out = {"symbol": sym, "ok": False}
    if d1 is None or len(d1) < 30:
        out["why"] = "Not enough price data yet"
        return out
    d1 = d1.sort_index()
    t = d1.index
    hm = t.hour * 60 + t.minute
    reg = d1[(hm >= 570) & (hm < 960) & (t.dayofweek < 5)]
    if reg.empty:
        out["why"] = "No regular-session bars found"
        return out
    days = sorted(set(reg.index.date))
    # last COMPLETED regular session
    last_day = days[-1]
    if last_day == now.date() and (now.hour * 60 + now.minute) < 960:
        days = days[:-1]
        if not days:
            out["why"] = "Only today's partial session so far"
            return out
        last_day = days[-1]
    ses = reg[reg.index.date == last_day]
    pc, pdh, pdl = float(ses["close"].iloc[-1]), float(ses["high"].max()), float(ses["low"].min())
    end = ses.index[-1]
    after = d1[d1.index > end]
    # daily ranges for a plain "normal move" size
    rng = []
    for d in days[-10:]:
        s = reg[reg.index.date == d]
        if len(s):
            rng.append(float(s["high"].max() - s["low"].min()))
    atr = sum(rng) / len(rng) if rng else (pdh - pdl)
    last = float(d1["close"].iloc[-1])
    if len(after):
        ext_hi, ext_lo = float(after["high"].max()), float(after["low"].min())
        tp = (after["high"] + after["low"] + after["close"]) / 3
        v = after["volume"].replace(0, pd.NA)
        evw = float((tp * after["volume"]).sum() / after["volume"].sum()) if after["volume"].sum() > 0 else last
    else:
        ext_hi, ext_lo, evw = last, last, last
    gap = (last / pc - 1) * 100 if pc else 0.0
    if gap >= 0.5 and last >= evw:
        bias, why = "long", f"Up {gap:+.1f}% from the close and holding above its average price"
    elif gap <= -0.5 and last <= evw:
        bias, why = "short", f"Down {gap:+.1f}% from the close and trading below its average price"
    else:
        bias, why = "wait", f"Only {gap:+.1f}% from the close or mixed: wait for the first 5 to 15 minutes"
    risk = max(0.35 * atr, 0.01 * last * 0.5, 0.03)
    up_t = max(ext_hi, last) + 0.01
    dn_t = min(ext_lo, last) - 0.01
    pull = min(evw, last) if bias == "long" else evw
    plan = {
        "buy_above": {"price": _r(up_t), "stop": _r(up_t - risk), "t1": _r(up_t + 2 * risk), "t2": _r(up_t + 3 * risk)},
        "dip_buy": {"price": _r(pull), "stop": _r(pull - risk * 0.8), "t1": _r(pull + 1.6 * risk)},
        "short_below": {"price": _r(dn_t), "stop": _r(dn_t + risk), "t1": _r(dn_t - 2 * risk), "t2": _r(dn_t - 3 * risk)},
    }
    out.update({
        "ok": True, "last": _r(last), "prev_close": _r(pc), "gap_pct": round(gap, 2), "bias": bias, "why": why,
        "levels": {"prev_high": _r(pdh), "prev_low": _r(pdl), "night_high": _r(ext_hi), "night_low": _r(ext_lo), "night_vwap": _r(evw)},
        "normal_move": _r(atr), "plan": plan, "earnings": earnings or "", "bars": int(len(after)),
    })
    if earnings:
        out["warn"] = earnings + ": SekexBot will not open new trades in this stock today"
    return out
