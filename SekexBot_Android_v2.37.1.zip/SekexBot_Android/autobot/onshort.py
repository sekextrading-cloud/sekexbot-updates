"""🌙 Overnight shorts (v2.24). Alpaca takes no NEW shorts overnight, so the shorts are picked in the evening (4:05-7:45 PM ET) and entered before 8 PM,
held with broker-side GTC stop + target, and covered by the open. Candidates come from (a) a GROUP that is breaking down together (stocks whose daily
returns move together) and (b) optionally earnings tonight (a coin flip on direction, so it has its own switch, OFF by default).
The cap on how much may be short in one group is DYNAMIC: the smaller of 40% of the account and (loss room left today / the group's typical bad overnight
gap), minus what you already hold there, tighter when peers report tonight or the spread is wide. Pure functions here; server.py runs them."""
import json
import math
from pathlib import Path

import numpy as np
import pandas as pd

from .config import DATA_DIR

FILE = DATA_DIR / "onshort.json"
DEFAULT = {"on": False, "mode": "place", "earn": False, "max_each": 5000.0, "max_total": 10000.0}
CEILING = 0.40
CORR = 0.60
MOVE_MIN = 0.8          # percent down on the day for a "weak" stock


def load():
    d = dict(DEFAULT)
    try:
        d.update(json.loads(Path(FILE).read_text()))
    except Exception:
        pass
    d["mode"] = d["mode"] if d["mode"] in ("alert", "place") else "place"
    d["max_each"] = min(50000.0, max(500.0, float(d["max_each"])))
    d["max_total"] = min(100000.0, max(500.0, float(d["max_total"])))
    return d


def save(d):
    c = dict(DEFAULT)
    c.update({k: d[k] for k in DEFAULT if k in d})
    c["on"], c["earn"] = bool(c["on"]), bool(c["earn"])
    try:
        Path(FILE).write_text(json.dumps(c))
    except Exception:
        pass
    return load()


def gap90(daily):
    """Typical BAD overnight gap for a short: the 90th percentile of up-gaps (open vs prior close) over the last 30 days, floor 0.5%."""
    try:
        o, c = daily["open"].astype(float), daily["close"].astype(float)
        g = (o / c.shift(1) - 1).dropna().tail(30).clip(lower=0)
        return max(0.005, float(np.percentile(g, 90))) if len(g) >= 8 else 0.02
    except Exception:
        return 0.02


def groups(daily_close, thresh=CORR):
    """Greedy clusters of symbols whose daily returns correlate >= thresh over the last 40 days. daily_close: {sym: close Series}."""
    syms = [s for s, x in daily_close.items() if x is not None and len(x) >= 25]
    if len(syms) < 2:
        return []
    df = pd.DataFrame({s: daily_close[s].astype(float).pct_change() for s in syms}).dropna().tail(40)
    if len(df) < 15:
        return []
    cm = df.corr()
    left, out = list(syms), []
    while left:
        s = left.pop(0)
        grp = [s] + [t for t in left if cm.loc[s, t] >= thresh]
        for t in grp[1:]:
            left.remove(t)
        if len(grp) >= 2:
            out.append(grp)
    return out


def dyn_cap(equity, loss_left, gap, held_in_group, earnings_peer=False, spread_pct=0.0):
    """Dollars that may still be SHORT in this group tonight, and why."""
    gap_eff = max(0.01, gap) * (1.5 if earnings_peer else 1.0)
    ceiling = CEILING * float(equity)
    room = float(loss_left) / gap_eff
    base = min(ceiling, room)
    if spread_pct and spread_pct > 0.5:
        base *= 0.5
    cap = max(0.0, base - float(held_in_group))
    why = (f"{int(CEILING * 100)}% of account ${ceiling:,.0f}; loss room ${loss_left:,.0f} / bad gap {gap_eff * 100:.1f}% = ${room:,.0f}"
           + ("; peers report tonight (gap x1.5)" if earnings_peer else "") + ("; wide spread (half)" if spread_pct and spread_pct > 0.5 else "")
           + f"; already in group ${held_in_group:,.0f}")
    return round(cap, 2), why


def build(stats, daily, now_earn, cfg, equity, loss_left, held_value, spreads=None):
    """stats: {sym: {last, prev_close, vwap}}; daily: {sym: daily OHLC frame}; now_earn: {sym: 'after'|'pre'|'?'} (tonight);
    held_value: {sym: $ exposure (abs)}. Returns a list of candidate dicts (best first), each with the proposed size, stop, target and cap reason."""
    spreads = spreads or {}
    cl = {s: (d["close"] if d is not None and len(d) else None) for s, d in daily.items()}
    gp = groups(cl)
    cands, used = [], set()
    for grp in gp:
        mv = {s: ((stats[s]["last"] / stats[s]["prev_close"] - 1) * 100) for s in grp if s in stats and stats[s].get("prev_close")}
        below = {s: stats[s]["last"] < stats[s].get("vwap", 0) * 0.998 for s in mv}
        weak = [s for s in mv if mv[s] <= -MOVE_MIN and below[s]]
        if len(weak) < max(2, math.ceil(len(mv) * 2 / 3)):
            continue
        gg = max(gap90(daily[s]) for s in grp if daily.get(s) is not None)
        peer_earn = any(s in now_earn and now_earn[s] == "after" for s in grp)
        held = sum(held_value.get(s, 0.0) for s in grp)
        for s in sorted(weak, key=lambda x: mv[x]):
            e_tonight = now_earn.get(s) == "after"
            if e_tonight and not cfg["earn"]:
                cands.append({"symbol": s, "kind": "blocked", "why": "earnings tonight: 'Shorts into earnings' is off", "group": grp, "move": round(mv[s], 2)})
                continue
            cands.append(_mk(s, "group", f"chip/peer group weak: {', '.join(x for x in weak if x != s)} also down and below their average price" if len(weak) > 1 else "group weak",
                             grp, mv[s], stats[s], gg, peer_earn, held, equity, loss_left, spreads.get(s, 0.0), daily.get(s)))
            used.add(s)
    if cfg["earn"]:
        for s, when in now_earn.items():
            if when != "after" or s in used or s not in stats or not stats[s].get("prev_close"):
                continue
            m = (stats[s]["last"] / stats[s]["prev_close"] - 1) * 100
            if stats[s]["last"] < stats[s].get("vwap", 0) * 0.998:
                cands.append(_mk(s, "earnings", "earnings tonight (a coin flip on direction)", [s], m, stats[s], gap90(daily[s]) if daily.get(s) is not None else 0.04,
                                 True, held_value.get(s, 0.0), equity, loss_left, spreads.get(s, 0.0), daily.get(s)))
    order = {"group": 0, "earnings": 1, "blocked": 2}
    cands.sort(key=lambda c: (order.get(c["kind"], 3), c.get("move", 0)))
    return cands


def _mk(sym, kind, why, grp, move, st, gg, peer_earn, held, equity, loss_left, spread_pct, d):
    last = float(st["last"])
    sgap = gap90(d) if d is not None and len(d) else gg
    dist = max(0.015 * last, 0.6 * sgap * last)
    stop, target = round(last + dist, 2), round(last - 1.5 * dist, 2)
    cap, cap_why = dyn_cap(equity, loss_left, gg, held, peer_earn, spread_pct)
    return {"symbol": sym, "kind": kind, "why": why, "group": grp, "move": round(move, 2), "price": round(last, 2), "stop": stop, "target": target,
            "stop_dist": round(dist, 2), "cap": cap, "cap_why": cap_why, "gap90": round(sgap * 100, 1)}


def size(c, cfg, total_open, loss_left, buying_power):
    """Shares for a candidate: within the per-short and all-overnight limits, the dynamic group cap, half the loss room at the stop, and buying power."""
    px = c["price"]
    dollars = min(cfg["max_each"], max(0.0, cfg["max_total"] - total_open), c["cap"], 0.5 * float(buying_power))
    by_risk = 0.5 * float(loss_left) / max(c["stop_dist"], 0.01)
    q = int(min(dollars / px, by_risk))
    return max(0, q)
