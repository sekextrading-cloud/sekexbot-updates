"""v2.29: Run Hunter. No fixed clock: it watches every minute bar (4 AM pre-market included) for a stock starting a big run on a burst of volume,
joins early, and gets out when the run is over (volume dries up, a lower high, or a close under VWAP) instead of at a fixed time.
Pure functions here (easy to test); server.py does the orders and applies the same safety gates as the jump trader."""
import numpy as np
import pandas as pd

MIN_PRICE = 1.0
MIN_MOVE15 = 3.0        # percent up over the last 15 minutes
MIN_RATIO = 3.0         # last 5 minutes of volume vs the usual 5-minute volume today
MIN_DOLLARS5 = 40_000   # dollars traded in the last 5 minutes: below this the quotes are too thin to trust
BIG_RATIO = 5.0


def _day(d1, now):
    """Today's bars from 4:00 AM on."""
    if d1 is None or len(d1) == 0:
        return None
    t0 = now.replace(hour=4, minute=0, second=0, microsecond=0)
    d = d1[d1.index >= t0]
    return d if len(d) else None


def vwap_of(d):
    tp = (d["high"] + d["low"] + d["close"]) / 3
    v = d["volume"].replace(0, np.nan)
    return float((tp * d["volume"]).cumsum().iloc[-1] / d["volume"].cumsum().iloc[-1]) if d["volume"].sum() > 0 else float("nan")


def vol5(d):
    """Volume in non-overlapping 5-minute buckets (oldest first)."""
    return d["volume"].resample("5min").sum()


def detect(d1, now, min_price=MIN_PRICE):
    """The run in progress on this stock right now, or None. {side, ratio, move15, move5, price, vwap, dollars5, vol5}."""
    d = _day(d1, now)
    if d is None or len(d) < 25:
        return None
    c = d["close"].values
    px = float(c[-1])
    if px < min_price:
        return None
    b = vol5(d)
    if len(b) < 6:
        return None
    last5 = float(d["volume"].iloc[-5:].sum())
    base_b = b.iloc[:-6] if len(b) > 8 else b.iloc[:-1]
    base_b = base_b[base_b > 0]
    if len(base_b) < 3:
        return None
    base = float(base_b.median())
    ratio = last5 / max(base, 1.0)
    move15 = (px / float(c[-16]) - 1) * 100
    move5 = (px / float(c[-6]) - 1) * 100
    hi15 = float(d["high"].iloc[-15:].max())
    vw = vwap_of(d)
    dollars5 = last5 * px
    if not (move15 >= MIN_MOVE15 and ratio >= MIN_RATIO and move5 >= 0.8 and px >= 0.98 * hi15 and dollars5 >= MIN_DOLLARS5):
        return None
    if vw == vw and px < vw:
        return None
    return {"side": "up", "ratio": round(ratio, 1), "move15": round(move15, 1), "move5": round(move5, 1), "price": round(px, 2), "vwap": round(vw, 2) if vw == vw else None,
            "dollars5": int(dollars5), "vol5": last5}


def classify(run, has_news):
    """What to do with a run: 'ride' (join it), 'fade' (wait for a VWAP rejection and short it), or 'watch' (no trade)."""
    if run is None:
        return "none"
    if has_news and run["ratio"] >= BIG_RATIO:
        return "ride"
    if (not has_news) and run["ratio"] >= BIG_RATIO:
        return "ride"
    if (not has_news) and run["move15"] >= 4:
        return "fade"
    return "watch"


def trail_pct(run):
    """How far under the peak the trailing stop sits: wider for a faster run, never under 1.5% or over 5%."""
    return float(min(5.0, max(1.5, 0.4 * float(run.get("move15", 3)))))


def exit_check(d1, now, st):
    """Is the run over? st = {entry, peak, peak_vol5, t_join_min}. Returns (reason, new_peak, new_peak_vol5). reason is '' while the run goes on."""
    d = _day(d1, now)
    if d is None or len(d) < 10:
        return "", st.get("peak", 0), st.get("peak_vol5", 0)
    px = float(d["close"].iloc[-1])
    peak = max(float(st.get("peak") or 0), float(d["high"].iloc[-3:].max()))
    last5 = float(d["volume"].iloc[-5:].sum())
    pv = max(float(st.get("peak_vol5") or 0), last5)
    age = (now - pd.Timestamp(st["t_join"]).tz_convert(now.tzinfo)).total_seconds() / 60 if st.get("t_join") else 99
    why = ""
    tr = float(st.get("trail", 2.0))
    if px <= peak * (1 - tr / 100.0):
        why = f"price fell {tr:g}% from its high (trailing stop)"
    else:
        vw = vwap_of(d)
        five = d.resample("5min").agg({"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna(subset=["open"])
        if age >= 6 and vw == vw and px < vw * 0.998:
            why = "it closed under VWAP"
        elif age >= 10 and len(five) >= 3 and pv > 0 and float(five["volume"].iloc[-2]) < 0.5 * pv and float(five["high"].iloc[-2]) < float(five["high"].iloc[-3]):
            why = "volume dried up to under half of its peak"
        elif age >= 10 and len(five) >= 3 and float(five["high"].iloc[-2]) < float(five["high"].iloc[-3]) and float(five["close"].iloc[-2]) < float(five["open"].iloc[-2]) and px < float(five["close"].iloc[-3]):
            why = "it made a lower high"
    return why, peak, pv


def sess_key(now):
    """Which part of the day: pre (before 9:30), open (9:30-11), mid (11-16), after (16 on)."""
    m = now.hour * 60 + now.minute
    return "pre" if m < 570 else "open" if m < 660 else "mid" if m < 960 else "after"
