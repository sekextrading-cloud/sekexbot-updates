"""v2.32: bad-price guard. A paper fill or a data print can come back at a price that no real trade happened at (in the 2.14.3 journal: a $33.59 stock
"closed" at $3.20 for +$12,339 and a $23.59 stock at $4.40 for -$11,111). One such print would fake a profit or trip the daily loss limit and teach the learner
something false. bad_exit() says when an exit price is not believable so the caller can record the last price it actually saw instead."""


def bad_exit(px, entry, last=None, entry_band=0.35, last_band=0.30, seen_band=0.25):
    """True when `px` is far from where the stock was a moment ago.
    - With a last seen price that itself was near the entry: px must be within `last_band` of it, or it is not believable.
    - With no last price: px must be within 50% of the entry."""
    try:
        px, entry = float(px), float(entry)
    except Exception:
        return False
    if px <= 0 or entry <= 0:
        return True
    try:
        last = float(last) if last else None
    except Exception:
        last = None
    if last and last > 0 and abs(last / entry - 1) <= seen_band:
        return abs(px / last - 1) > last_band and abs(px / entry - 1) > entry_band
    return abs(px / entry - 1) > 0.5
