"""v2.13: Jump in / Jump out signals on 5-minute bars. Pullback-and-retest entries (buy and short), 'don't chase' warnings and exit warnings
for open trades, each with a stop, targets and (from history) that stock's own record of the same setup. Pure functions: no orders here."""
import pandas as pd

KINDS = ("in", "out", "chase")


def to5(d1):
    """1-minute bars -> 5-minute bars (left-labelled). Drops empty buckets."""
    if d1 is None or len(d1) == 0:
        return None
    d = d1[["open", "high", "low", "close", "volume"]].resample("5min", label="left", closed="left").agg(
        {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna(subset=["open"])
    return d


def prep(d5):
    d = d5.copy()
    d["ema9"] = d["close"].ewm(span=9, adjust=False).mean()
    d["ema20"] = d["close"].ewm(span=20, adjust=False).mean()
    pc = d["close"].shift(1)
    tr = pd.concat([d["high"] - d["low"], (d["high"] - pc).abs(), (d["low"] - pc).abs()], axis=1).max(axis=1)
    d["atr"] = tr.rolling(14, min_periods=8).mean()
    d["vavg"] = d["volume"].rolling(20, min_periods=8).mean().shift(1)
    day = d.index.date
    tp = (d["high"] + d["low"] + d["close"]) / 3 * d["volume"]
    d["vwap"] = tp.groupby(day).cumsum() / d["volume"].groupby(day).cumsum().replace(0, float("nan"))
    return d


def _sig(d, i, kind, side, why, name, **kw):
    r = d.iloc[i]
    s = {"i": i, "ts": d.index[i], "t": d.index[i].strftime("%H:%M"), "d": d.index[i].strftime("%a %b %d"), "kind": kind, "side": side,
         "price": round(float(r["close"]), 2 if r["close"] >= 1 else 4), "why": why, "name": name}
    s.update(kw)
    return s


def scan(d5, tail=None):
    """All signals on the series (oldest first). tail=N keeps only signals on the last N bars (fast path for the live scan)."""
    if d5 is None or len(d5) < 32:
        return []
    d = prep(d5)
    n = len(d)
    o, h, l, c, v = (d[k].values for k in ("open", "high", "low", "close", "volume"))
    e9, e20, atr, va, vw = (d[k].values for k in ("ema9", "ema20", "atr", "vavg", "vwap"))
    days = d.index.date
    out, last_in = [], {"up": -99, "down": -99}
    start = 26 if tail is None else max(26, n - tail)
    for i in range(start, n):
        a = atr[i]
        if not (a == a) or a <= 0:
            continue
        same_day = days[i - 6] == days[i]
        # ---- don't chase: a vertical bar far from its average on a volume burst ----
        rng, ext = h[i] - l[i], c[i] - e9[i]
        burst = va[i] == va[i] and va[i] > 0 and v[i] >= 3 * va[i]
        if burst and (rng >= 2.0 * a or abs(ext) >= 1.8 * a) and same_day:
            sd = "up" if c[i] >= o[i] else "down"
            out.append(_sig(d, i, "chase", sd, "Vertical move on a burst of volume, far from its average. These often reverse. Wait for the pullback and a confirmation candle.", "Don't chase"))
        # ---- exits (marked for either side; the caller picks the side it holds) ----
        up_trend = e9[i] > e20[i]
        lost_avg_long = c[i] < e20[i] and c[i - 1] >= e20[i - 1]
        lost_avg_short = c[i] > e20[i] and c[i - 1] <= e20[i - 1]
        wick_up = (h[i] - max(o[i], c[i])) / rng if rng > 0 else 0
        wick_dn = (min(o[i], c[i]) - l[i]) / rng if rng > 0 else 0
        if same_day:
            if lost_avg_long or (vw[i] == vw[i] and c[i] < vw[i] and c[i - 1] >= vw[i - 1] and c[i - 2] >= vw[i - 2]):
                out.append(_sig(d, i, "out", "up", "Price closed back under its moving average / VWAP. The up move is losing its support. Protect your profit.", "Lost the average"))
            elif burst and wick_up >= 0.55 and c[i - 1] > e9[i - 1]:
                out.append(_sig(d, i, "out", "up", "A burst of volume with a long upper wick: buyers got sold into. Often the top of the move.", "Volume climax"))
            if lost_avg_short or (vw[i] == vw[i] and c[i] > vw[i] and c[i - 1] <= vw[i - 1] and c[i - 2] <= vw[i - 2]):
                out.append(_sig(d, i, "out", "down", "Price closed back above its moving average / VWAP. The down move is losing steam. Cover before it squeezes.", "Reclaimed the average"))
            elif burst and wick_dn >= 0.55 and c[i - 1] < e9[i - 1]:
                out.append(_sig(d, i, "out", "down", "A burst of volume with a long lower wick: sellers got bought into. Often the low of the move.", "Selling climax"))
        if not same_day:
            continue
        # ---- jump in, long: uptrend, pullback to the average on lighter volume, green candle back above the fast average ----
        pb = slice(i - 6, i)
        move_vol = v[i - 12:i - 6].mean() if i >= 12 else 0
        pb_vol = v[pb].mean()
        if (up_trend and e20[i] > e20[i - 6] and (vw[i] != vw[i] or c[i] > vw[i]) and i - last_in["up"] > 8):
            touched = (l[pb] <= e20[pb] + 0.15 * a).any()
            depth = h[i - 12:i].max() - l[pb].min()
            if touched and depth >= 0.6 * a and pb_vol <= 0.95 * (move_vol or pb_vol) and c[i] > o[i] and c[i] > e9[i] and c[i] > c[i - 1] and (c[i] - e9[i]) <= 1.5 * a:
                stop = float(l[i - 6:i + 1].min() - 0.1 * a)
                risk = c[i] - stop
                if 0 < risk <= 3 * a:
                    out.append(_sig(d, i, "in", "up", "Uptrend pulled back to its average on lighter volume, then a green candle closed back above the fast average.", "Pullback retest",
                                    zone=[round(float(c[i] - 0.15 * a), 2), round(float(c[i] + 0.1 * a), 2)], stop=round(stop, 2),
                                    tp1=round(float(c[i] + 1.5 * risk), 2), tp2=round(float(c[i] + 2.5 * risk), 2), atr=round(float(a), 3)))
                    last_in["up"] = i
        # ---- jump in, short: downtrend, bounce into the average that fails, red candle closes back under the fast average ----
        if ((not up_trend) and e20[i] < e20[i - 6] and (vw[i] != vw[i] or c[i] < vw[i]) and i - last_in["down"] > 8):
            touched = (h[pb] >= e20[pb] - 0.15 * a).any()
            depth = h[pb].max() - l[i - 12:i].min()
            if touched and depth >= 0.6 * a and pb_vol <= 0.95 * (move_vol or pb_vol) and c[i] < o[i] and c[i] < e9[i] and c[i] < c[i - 1] and (e9[i] - c[i]) <= 1.5 * a:
                stop = float(h[i - 6:i + 1].max() + 0.1 * a)
                risk = stop - c[i]
                if 0 < risk <= 3 * a:
                    out.append(_sig(d, i, "in", "down", "Downtrend bounced into its average on lighter volume and failed: a lower high, then a red candle closed back under the fast average.", "Failed bounce",
                                    zone=[round(float(c[i] - 0.1 * a), 2), round(float(c[i] + 0.15 * a), 2)], stop=round(stop, 2),
                                    tp1=round(float(c[i] - 1.5 * risk), 2), tp2=round(float(c[i] - 2.5 * risk), 2), atr=round(float(a), 3)))
                    last_in["down"] = i
    return out


def record(d5, horizon=24):
    """This stock's own record of 'jump in' signals over the history: after the signal, did price reach target 1 (1.5 R) before the stop,
    within `horizon` bars (2 hours) on the same day? A bar that touches both counts as the stop. Returns {side: {n, hit, fail}}."""
    res = {"up": {"n": 0, "hit": 0, "fail": 0}, "down": {"n": 0, "hit": 0, "fail": 0}}
    if d5 is None or len(d5) < 60:
        return res
    sigs = [s for s in scan(d5) if s["kind"] == "in" and "09:40" <= s["t"] <= "15:30"]
    hi, lo, days = d5["high"].values, d5["low"].values, d5.index.date
    for s in sigs:
        i, up = s["i"], s["side"] == "up"
        done = None
        for j in range(i + 1, min(len(d5), i + 1 + horizon)):
            if days[j] != days[i]:
                break
            hit = hi[j] >= s["tp1"] if up else lo[j] <= s["tp1"]
            stp = lo[j] <= s["stop"] if up else hi[j] >= s["stop"]
            if stp:
                done = False
                break
            if hit:
                done = True
                break
        if done is None:
            continue
        r = res[s["side"]]
        r["n"] += 1
        r["hit" if done else "fail"] += 1
    return res
