"""v2.26: Best times report. Which half-hours of the day (4 AM to 8 PM) had the waves, and what a plain trade started in each would have made.
Pure functions on 15-minute bars (pre-market and after-hours included). Past data only: no promise about what comes next."""
import numpy as np
import pandas as pd

COST = {"pre": 0.30, "reg": 0.10, "after": 0.30}      # assumed round-trip cost in % (spread + slippage); wider outside regular hours


def _sess(m):
    return "pre" if m < 570 else "reg" if m < 960 else "after"


def waves(c, th):
    """Zigzag legs of at least th % on a close series: [(start_i, end_i, +1 up / -1 down)]."""
    n = len(c)
    legs, trend, hi, lo, st = [], 0, 0, 0, 0
    for i in range(1, n):
        if trend == 0:
            if c[i] > c[hi]:
                hi = i
            if c[i] < c[lo]:
                lo = i
            if hi > lo and c[hi] >= c[lo] * (1 + th / 100):
                trend, st = 1, lo
            elif lo > hi and c[lo] <= c[hi] * (1 - th / 100):
                trend, st = -1, hi
        elif trend == 1:
            if c[i] > c[hi]:
                hi = i
            elif c[i] <= c[hi] * (1 - th / 100):
                legs.append((st, hi, 1)); trend, st, lo = -1, hi, i
        else:
            if c[i] < c[lo]:
                lo = i
            elif c[i] >= c[lo] * (1 + th / 100):
                legs.append((st, lo, -1)); trend, st, hi = 1, lo, i
    if trend == 1 and c[hi] >= c[st] * (1 + th / 100):
        legs.append((st, hi, 1))
    elif trend == -1 and c[lo] <= c[st] * (1 - th / 100):
        legs.append((st, lo, -1))
    return legs


def _trade(o, h, l, c, mins, i, side, sp, tp, hold, cost):
    """Enter at the open of bar i. Stop wins a tie. Returns pnl % after cost, or None when there are not enough bars after it."""
    e = o[i]
    last = None
    n = 0
    for j in range(i, len(o)):
        if mins[j] - mins[i] > 15 * hold:
            break
        n += 1
        last = j
        if side == 1:
            if l[j] <= e * (1 - sp / 100):
                return -sp - cost
            if h[j] >= e * (1 + tp / 100):
                return tp - cost
        else:
            if h[j] >= e * (1 + sp / 100):
                return -sp - cost
            if l[j] <= e * (1 - tp / 100):
                return tp - cost
    if n < max(2, hold // 2) or last is None:
        return None
    return side * (c[last] - e) / e * 100 - cost


def analyze(d, th=1.5, rr=2.0, hold=8, size=2500.0, stop=None):
    if d is None or len(d) < 40:
        return {"ok": False, "why": "Not enough history for this stock."}
    d = d.sort_index()
    idx = d.index
    days = sorted(set(idx.date))
    ranges = ((d["high"] - d["low"]) / d["close"] * 100).replace([np.inf, -np.inf], np.nan).dropna()
    sp = float(stop) if stop else max(0.8, round(float(ranges.median()) * 1.2, 2))       # stop = about 1.2x a typical 15-minute range
    tp = sp * rr
    B = {}                                                                               # 30-min bucket -> stats
    ups = downs = early = tot_w = 0

    def bk(m):
        k = m // 30 * 30
        if k not in B:
            B[k] = {"up": 0, "down": 0, "sz": [], "L": [], "S": []}
        return B[k]
    for day in days:
        g = d[idx.date == day]
        if len(g) < 8:
            continue
        o, h, l, c = (g[k].values.astype(float) for k in ("open", "high", "low", "close"))
        mins = (g.index.hour * 60 + g.index.minute).values
        for (a, b, dr) in waves(c, th):
            m = int(mins[a])
            if m < 240 or m >= 1200:
                continue
            x = bk(m)
            x["up" if dr > 0 else "down"] += 1
            x["sz"].append(abs(c[b] - c[a]) / c[a] * 100)
            tot_w += 1
            ups += dr > 0
            downs += dr < 0
            early += m < 630
        for i in range(len(g)):
            m = int(mins[i])
            if m < 240 or m >= 1185:
                continue
            cost = COST[_sess(m)]
            x = bk(m)
            for side, key in ((1, "L"), (-1, "S")):
                r = _trade(o, h, l, c, mins, i, side, sp, tp, hold, cost)
                if r is not None:
                    x[key].append(r)
    price = float(d["close"].median())
    rows = []
    for k in sorted(B):
        x = B[k]
        def agg(v):
            if len(v) < 6:
                return None
            a = np.array(v)
            return {"n": len(v), "win": round(float((a > 0).mean() * 100)), "avg": round(float(a.mean() / 100 * size), 2), "tot": round(float(a.sum() / 100 * size), 2)}
        L, S = agg(x["L"]), agg(x["S"])
        best = None
        if L and L["avg"] > 0 and (not S or L["avg"] >= S["avg"]):
            best = "long"
        elif S and S["avg"] > 0:
            best = "short"
        rows.append({"m": k, "t": f"{(k // 60) % 12 or 12}:{k % 60:02d} {'AM' if k < 720 else 'PM'}", "sess": _sess(k), "up": x["up"], "down": x["down"],
                     "wave_pct": round(float(np.mean(x["sz"])), 2) if x["sz"] else 0.0, "long": L, "short": S, "best": best,
                     "best_avg": max([v["avg"] for v in (L, S) if v] or [0.0])})
    ranked = sorted([r for r in rows if r["best"]], key=lambda r: -r["best_avg"])[:3]
    ses = {}
    for s in ("pre", "reg", "after"):
        rs = [r for r in rows if r["sess"] == s]
        ses[s] = {"waves": sum(r["up"] + r["down"] for r in rs), "long": round(sum(r["long"]["tot"] for r in rs if r["long"]), 2),
                  "short": round(sum(r["short"]["tot"] for r in rs if r["short"]), 2)}
    return {"ok": True, "days": len(days), "th": th, "stop_pct": round(sp, 2), "target_pct": round(tp, 2), "hold_min": hold * 15, "size": size, "price": round(price, 2),
            "waves": tot_w, "up": int(ups), "down": int(downs), "early_pct": round(early / tot_w * 100) if tot_w else 0,
            "rows": rows, "top": ranked, "sessions": ses, "cost": COST}
