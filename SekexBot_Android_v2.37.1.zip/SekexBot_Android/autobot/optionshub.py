"""Options Hub (manual options ticket): strike list for one stock, plus safety checks for a single-contract order.

Long calls / long puts only (buy to open, sell to close what you hold). Never sells naked. Pure helpers so they can be tested
with a stub broker; the server wires them to Alpaca."""
import re
from datetime import date, timedelta

MULT = 100
OCC = re.compile(r"^([A-Z]{1,6})(\d{6})([CP])(\d{8})$")


def parse_occ(sym):
    m = OCC.match((sym or "").upper().strip())
    if not m:
        return None
    u, d, cp, k = m.groups()
    return {"underlying": u, "expiry": date(2000 + int(d[:2]), int(d[2:4]), int(d[4:6])), "kind": "call" if cp == "C" else "put", "strike": int(k) / 1000.0}


def _f(x):
    try:
        return None if x is None else float(x)
    except Exception:
        return None


def rows_for(kind, spot, contracts, snaps, n=16):
    """contracts: [{symbol, strike, oi}] for ONE expiry; snaps: {symbol: {bid, ask, delta, iv, last}}.
    Returns the n strikes nearest the price, highest strike first, with breakeven and flags."""
    near = sorted(contracts, key=lambda c: abs(c["strike"] - spot))[:n]
    out = []
    for c in sorted(near, key=lambda c: -c["strike"]):
        s = snaps.get(c["symbol"]) or {}
        bid, ask = s.get("bid"), s.get("ask")
        ask_ok = ask is not None and ask > 0
        be = (c["strike"] + ask if kind == "call" else c["strike"] - ask) if ask_ok else None
        mid = (bid + ask) / 2 if (ask_ok and bid is not None) else None
        spr = round((ask - bid) / mid * 100, 1) if mid else None
        flags = []
        if spr is not None and spr > 10:
            flags.append("wide spread")
        if (c.get("oi") or 0) < 100:
            flags.append("thin open interest")
        if not ask_ok:
            flags.append("no quote")
        out.append({"symbol": c["symbol"], "strike": c["strike"], "oi": int(c.get("oi") or 0), "bid": bid, "ask": ask,
                    "breakeven": None if be is None else round(be, 2),
                    "to_be_pct": None if be is None or not spot else round((be / spot - 1) * 100, 1),
                    "itm": (c["strike"] < spot) if kind == "call" else (c["strike"] > spot),
                    "spread_pct": spr, "delta": s.get("delta"), "iv": s.get("iv"), "flags": flags})
    return out


def payoff(kind, strike, premium, spot, points=40):
    """Profit/loss per contract at expiry across a price range, plus max loss / breakeven."""
    lo, hi = spot * 0.7, spot * 1.3
    xs = [lo + (hi - lo) * i / (points - 1) for i in range(points)]
    f = (lambda x: max(0.0, x - strike)) if kind == "call" else (lambda x: max(0.0, strike - x))
    be = strike + premium if kind == "call" else strike - premium
    return {"points": [[round(x, 2), round((f(x) - premium) * MULT, 2)] for x in xs], "max_loss": round(premium * MULT, 2),
            "max_profit": None if kind == "call" else round(max(0.0, strike - premium) * MULT, 2), "breakeven": round(be, 2)}


def check_order(*, side, qty, limit, held_qty, bp, level, market_open, halted, live, live_unlocked, pin_given_ok, confirm, managed_by_bot):
    """Return an error message, or '' when the order may go. Pure, so the rules are testable."""
    if side not in ("buy", "sell"):
        return "Side must be buy or sell."
    if not (1 <= int(qty) <= 50):
        return "Contracts must be between 1 and 50."
    if not limit or limit <= 0:
        return "Enter a limit price."
    if not confirm:
        return "Tick the confirm box first."
    if managed_by_bot:
        return "The options bot is managing this contract. Close it from the Options card first."
    if live:
        if not live_unlocked:
            return "Options are locked on LIVE. Unlock them first (Options card → Unlock for LIVE)."
        if not pin_given_ok:
            return "Wrong or missing Live PIN."
    if not market_open:
        return "Options trade in regular hours only (9:30 AM to 4:00 PM ET)."
    if side == "sell":
        if held_qty < qty:
            return f"You hold {held_qty:g} of this contract. Selling here only closes what you own (no naked selling)."
        return ""
    if level is not None and level < 1:
        return "Your Alpaca account is not approved for options yet."
    if halted:
        return "Your daily loss limit stopped trading for today, so no new options orders."
    cost = limit * MULT * qty
    if bp is not None and cost > bp:
        return f"This costs ${cost:,.0f} but your buying power is ${bp:,.0f}."
    return ""
