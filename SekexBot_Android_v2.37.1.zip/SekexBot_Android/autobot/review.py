"""v2.10: one-stock review. Reads the stock's last 45 days of 15-minute bars and answers, from ITS OWN history:
what usually happens overnight and in the morning after a day that looked like this one. A record of the past, not a promise."""
from datetime import time
import statistics as st
from autobot import radar24 as r24

NY = r24.NY
MIN_N = 8


def _loc(r):
    rng = r["h"] - r["l"]
    return (r["c"] - r["l"]) / rng if rng > 0 else 0.5


def _bucket(x):
    return "low" if x < 0.33 else ("high" if x > 0.67 else "mid")


def _pct(a, b):
    return (a / b - 1) * 100 if b else 0.0


def review(sym, d, now, price=None):
    rows = r24._daily(d)
    if len(rows) < 30:
        return {"symbol": sym, "ok": False, "note": "Not enough price history for this symbol (needs about 6 weeks of trading)."}
    i = len(rows) - 1
    if rows[i]["date"] == now.date() and now.time() < time(16, 5):
        i -= 1                                     # today's session is not finished: use the last complete one
    r = rows[i]
    c = r["c"]
    m20 = sum(x["c"] for x in rows[i - 19:i + 1]) / 20
    down2 = rows[i]["c"] < rows[i - 1]["c"] < rows[i - 2]["c"]
    up2 = rows[i]["c"] > rows[i - 1]["c"] > rows[i - 2]["c"]
    streak = 0
    for k in range(i, 1, -1):
        if rows[k]["c"] < rows[k - 1]["c"]:
            streak += 1
        else:
            break
    loc = _loc(r)
    b = _bucket(loc)
    dist = _pct(c, m20)
    atr = st.mean((x["h"] - x["l"]) for x in rows[i - 13:i + 1])
    atr_pct = atr / c * 100 if c else 1.0

    def match(j):
        if j + 1 > i or j < 21:
            return False
        if _bucket(_loc(rows[j])) != b:
            return False
        if down2 and not (rows[j]["c"] < rows[j - 1]["c"] < rows[j - 2]["c"]):
            return False
        if up2 and not (rows[j]["c"] > rows[j - 1]["c"] > rows[j - 2]["c"]):
            return False
        return True
    js = [j for j in range(21, i) if match(j)]
    basis = "a day that closed like this one" + (" after 2+ down days" if down2 else (" after 2+ up days" if up2 else ""))
    if len(js) < MIN_N:
        js = [j for j in range(21, i) if _bucket(_loc(rows[j])) == b]
        basis = "days that closed like this one"
    n = len(js)
    on = [_pct(rows[j + 1]["pm"], rows[j]["c"]) for j in js if rows[j + 1].get("pm")]
    gap = [_pct(rows[j + 1]["o"], rows[j]["c"]) for j in js]
    mrows = [rows[j + 1] for j in js if rows[j + 1].get("wh") and rows[j + 1].get("wl")]
    nxt_low = [_pct(rows[j + 1]["l"], rows[j]["c"]) for j in js]
    nxt_high = [_pct(rows[j + 1]["h"], rows[j]["c"]) for j in js]

    def lean(p_up, n_):
        if n_ < MIN_N:
            return {"lean": "unclear", "conf": 0, "n": n_, "txt": "Not enough similar days to say"}
        p = p_up
        if p >= 0.62:
            lab = "up"
        elif p <= 0.38:
            lab = "down"
        else:
            lab = "mixed"
        conf = round(max(p, 1 - p) * 100)
        return {"lean": lab, "conf": conf, "n": n_, "p_up": round(p * 100)}
    tonight = lean(sum(1 for x in on if x > 0) / len(on), len(on)) if on else lean(0, 0)
    if tonight.get("lean") != "unclear":
        tonight["move"] = round(st.median(on), 2)
    gap_l = lean(sum(1 for x in gap if x > 0) / len(gap), len(gap)) if gap else lean(0, 0)
    first_up = sum(1 for m in mrows if (m["wh"] - m["o"]) > (m["o"] - m["wl"]))
    morning = lean(first_up / len(mrows), len(mrows)) if mrows else lean(0, 0)
    if morning.get("lean") != "unclear":
        morning["gap_up_pct"] = gap_l.get("p_up")
    # levels for someone already in a trade
    low_t = c * (1 + st.quantiles(nxt_low, n=4)[0] / 100) if len(nxt_low) >= 8 else c * (1 - atr_pct / 100)
    high_t = c * (1 + st.quantiles(nxt_high, n=4)[2] / 100) if len(nxt_high) >= 8 else c * (1 + atr_pct / 100)
    px = price or c
    bounce = round(min(3.0, max(0.5, 0.35 * atr_pct)), 2)
    reasons = []
    if streak >= 2:
        reasons.append(f"It has closed lower {streak} days in a row and sits {abs(dist):.1f}% {'below' if dist < 0 else 'above'} its 20-day average.")
    elif abs(dist) >= 3:
        reasons.append(f"It sits {abs(dist):.1f}% {'below' if dist < 0 else 'above'} its 20-day average.")
    reasons.append(f"It closed {'near the bottom' if b == 'low' else 'near the top' if b == 'high' else 'in the middle'} of the day's range ({round(loc * 100)}% of the way up).")
    if tonight.get("n", 0) >= MIN_N:
        reasons.append(f"After {basis} (seen {n} times in 45 days), the overnight move was up {tonight['p_up']}% of the time; typical overnight move {tonight['move']:+.2f}%.")
    if morning.get("n", 0) >= MIN_N:
        reasons.append(f"In the first two hours of the next session it pushed higher before lower {round(first_up / len(mrows) * 100)}% of the time; it opened higher {gap_l.get('p_up')}% of the time.")
    warn = []
    if down2 and dist <= -3:
        warn.append("Oversold after several down days: shorting here, especially into the close, is the riskiest spot. Bounces and squeezes often start here.")
    if b == "low" and not down2:
        warn.append("A weak close often keeps sliding into the evening and then bounces in the morning. Do not assume the slide lasts past the open.")
    if up2 and dist >= 3:
        warn.append("Extended up after several up days: buying here is the riskiest spot. Pullbacks often start overnight.")
    return {"symbol": sym, "ok": True, "close": round(c, 2), "close_date": str(r["date"]), "price": round(px, 2),
            "since_close_pct": round(_pct(px, c), 2), "streak_down": streak, "dist20": round(dist, 1), "close_loc": round(loc * 100),
            "atr_pct": round(atr_pct, 2), "bounce_pct": bounce, "basis": basis, "n": n,
            "tonight": tonight, "morning": morning, "reasons": reasons, "warn": warn,
            "typical_low": round(low_t, 2), "typical_high": round(high_t, 2),
            "cover_zone": [round(low_t * 0.997, 2), round(low_t * 1.004, 2)],
            "short_stop": round(max(px, c) * (1 + 0.5 * atr_pct / 100), 2),
            "long_stop": round(min(px, c) * (1 - 0.5 * atr_pct / 100), 2),
            "note": "A record of what this stock did after similar days. It is not a promise."}
