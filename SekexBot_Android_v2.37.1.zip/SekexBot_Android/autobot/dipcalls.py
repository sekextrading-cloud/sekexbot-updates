"""v2.34: Dip calls. A long-term option setup on quality, fast-moving companies.

The idea (from your video): keep a list of 10 to 20 quality companies that move fast. Write down each one's 52-week high.
When the market or the stock pulls back so the stock sits 15 to 25% under that high, buy a CALL about 6 months out with a strike
about 10% above today's price ("give it 6 months to meet you halfway"). If it keeps falling another 10% (of the 52-week high),
add ONE more call at the new price + 10%, same expiry ("a leg"). Exit (your choice in the app): sell when the stock is back within
5% of its 52-week high, or the call doubled, or 30 days are left before expiry (time decay speeds up at the end).

This module holds the rules and the saved state. server.py does the broker calls, the gates (PAPER / LIVE arming) and the alerts.
Education and automation, not advice: options can lose the whole premium."""
import json
import math
import threading
from datetime import date, datetime

from .config import DATA_DIR

FILE = DATA_DIR / "dipcalls.json"
LOCK = threading.Lock()

SUGGESTED = ["NVDA", "AMZN", "META", "MSFT", "GOOGL", "AAPL", "TSLA", "NFLX", "AVGO", "AMD", "CRM", "ORCL", "NOW", "UBER", "SHOP"]
DEFAULT_CFG = {"on": False, "auto": True, "list": list(SUGGESTED), "zone_lo": 15, "zone_hi": 25, "otm": 10, "months": 6,
               "budget": 500, "leg_step": 10, "max_legs": 2, "exit_near_high": 5, "tp_pct": 100, "exit_dte": 30,
               "max_new_per_day": 2, "max_open": 8}
OK = {"zone_lo": (10, 15, 20), "zone_hi": (20, 25, 30, 35), "otm": (5, 10, 15), "months": (3, 6, 9), "budget": (250, 500, 1000, 2000),
      "leg_step": (5, 10, 15), "max_legs": (1, 2, 3), "exit_near_high": (0, 5, 10), "tp_pct": (0, 50, 100, 200), "exit_dte": (0, 21, 30, 45)}


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "legs": {}, "history": [], "status": {}, "day": "", "new_today": 0, "notes": []}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    c["on"], c["auto"] = bool(c.get("on")), bool(c.get("auto", True))
    c["list"] = [s for s in dict.fromkeys(str(x).upper().strip() for x in (c.get("list") or [])) if s and s.replace(".", "").isalpha() and len(s) <= 6][:30]
    if c["zone_hi"] <= c["zone_lo"]:
        c["zone_lo"], c["zone_hi"] = DEFAULT_CFG["zone_lo"], DEFAULT_CFG["zone_hi"]
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    c = d["cfg"]
    for k, v in kw.items():
        if v is None:
            continue
        if k in ("on", "auto"):
            c[k] = bool(v)
        elif k == "add":
            s = str(v).upper().strip()
            if s and s.replace(".", "").isalpha() and len(s) <= 6 and s not in c["list"] and len(c["list"]) < 30:
                c["list"].append(s)
        elif k == "remove":
            c["list"] = [x for x in c["list"] if x != str(v).upper().strip()]
        elif k == "reset_list":
            if v:
                c["list"] = list(SUGGESTED)
        elif k in OK and v in OK[k]:
            c[k] = v
    if c["zone_hi"] <= c["zone_lo"]:
        c["zone_hi"] = min(x for x in OK["zone_hi"] if x > c["zone_lo"])
    d["cfg"] = c
    save(d)
    return load()


def analyze(daily, price=None, cfg=None):
    """daily: daily bars (oldest first) with 'high' and 'close'. Uses the last 252 trading days (52 weeks).
    Returns the 52-week high, the price, how far under the high it is (%), and the status: 'watch', 'zone' or 'deep'."""
    cfg = cfg or DEFAULT_CFG
    if daily is None or len(daily) < 20:
        return None
    d = daily.iloc[-252:]
    hi = float(d["high"].max())
    px = float(price) if price else float(d["close"].iloc[-1])
    if hi <= 0 or px <= 0:
        return None
    off = (hi - px) / hi * 100.0
    st = "zone" if cfg["zone_lo"] <= off <= cfg["zone_hi"] else "deep" if off > cfg["zone_hi"] else "watch"
    return {"high52": round(hi, 2), "high_date": str(d["high"].idxmax().date()) if hasattr(d["high"].idxmax(), "date") else "",
            "price": round(px, 2), "off": round(off, 1), "status": st}


def pick_contract(spot, contracts, today, cfg=None, expiry=None):
    """contracts: [{'symbol','strike','expiry' (YYYY-MM-DD)}] calls. The expiry closest to `months` (between 4 and 9 months when possible),
    or exactly `expiry` for a leg (same date as the first call). Strike: the one closest to price + otm%. None if nothing fits."""
    cfg = cfg or DEFAULT_CFG
    if not contracts or not spot:
        return None
    by = {}
    for c in contracts:
        by.setdefault(str(c["expiry"]), []).append(c)
    if expiry:
        if expiry not in by:
            return None
        exp = expiry
    else:
        want = cfg["months"] * 30.4
        cands = sorted(by, key=lambda x: abs((date.fromisoformat(x) - today).days - want))
        cands = [x for x in cands if (date.fromisoformat(x) - today).days >= max(60, want * 0.6)]
        if not cands:
            return None
        exp = cands[0]
    target = spot * (1 + cfg["otm"] / 100.0)
    best = min(by[exp], key=lambda c: (abs(c["strike"] - target), c["strike"]))
    if abs(best["strike"] - target) > spot * 0.08:
        return None                                   # no strike anywhere near +10%
    return {"symbol": best["symbol"], "strike": float(best["strike"]), "expiry": exp, "dte": (date.fromisoformat(exp) - today).days,
            "target_strike": round(target, 2)}


def qty_for(ask, budget):
    """Contracts that fit the budget at this ask (1 contract = 100 shares). 0 when even one costs more."""
    if not ask or ask <= 0:
        return 0
    return int(math.floor(budget / (ask * 100.0) + 1e-9))


def next_action(cfg, a, legs, today):
    """What to do for one stock now: ('buy', 1) first call, ('buy', n) a leg, or None.
    a: analyze() result. legs: the filled (or pending) calls held for this stock by this setup."""
    if not a:
        return None
    if not legs:
        return ("buy", 1) if a["status"] == "zone" else None
    if len(legs) >= cfg["max_legs"] or any(l.get("state") == "pending" for l in legs):
        return None
    last = legs[-1]
    # another leg when the price is a further leg_step % of the 52-week high below the last buy (e.g. high 100: first at 80, leg at 70)
    trigger = float(last["stock_px"]) - cfg["leg_step"] / 100.0 * a["high52"]
    if a["price"] <= trigger:
        return ("buy", len(legs) + 1)
    return None


def exit_reason(cfg, a, leg, mid, today):
    """Why to sell this call now, or ''. a: the stock's analysis; mid: the call's current mid price."""
    if leg.get("state") != "open":
        return ""
    if a and cfg["exit_near_high"] and a["off"] <= cfg["exit_near_high"]:
        return f"the stock is back within {cfg['exit_near_high']}% of its 52-week high"
    if cfg["tp_pct"] and mid and leg.get("cost_px") and mid >= leg["cost_px"] * (1 + cfg["tp_pct"] / 100.0):
        return f"the call is up {cfg['tp_pct']}% or more"
    try:
        dte = (date.fromisoformat(leg["expiry"]) - today).days
    except Exception:
        dte = 999
    if cfg["exit_dte"] and dte <= cfg["exit_dte"]:
        return f"{dte} days left before expiry (time decay speeds up at the end)"
    return ""


def new_day(d, today):
    if d.get("day") != str(today):
        d["day"], d["new_today"] = str(today), 0
    return d


def note(d, text, now=None):
    now = now or datetime.now()
    d.setdefault("notes", []).insert(0, {"t": now.strftime("%m-%d %H:%M"), "msg": text})
    del d["notes"][40:]
