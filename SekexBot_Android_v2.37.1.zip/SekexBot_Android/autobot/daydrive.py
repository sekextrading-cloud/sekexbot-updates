"""v2.12: Day drives. Four windows where a stock breaks out (buy) or breaks down (short) on a burst of volume:
  open      9:30-10:30   breaks its pre-market high            (see opendrive.py)
  lunch     1:00-2:30 PM breaks the 11:30-1:00 range
  close     3:00-3:55 PM breaks the day's high / low and the day's average price (VWAP)
  overnight 8 PM-9:30 AM flush-and-reclaim, overnight build, overnight breakdown
Each card carries that stock's OWN record of the same pattern over the last 45 days, built from the same event finder that the
replay uses. A record of the past, not a promise. Information first; Autopilot (server) decides what, if anything, to trade."""
from datetime import time, timedelta
import statistics as st
import pandas as pd
from autobot import opendrive as od

NY = od.NY
MIN_N = od.MIN_N
WINDOWS = ("overnight", "open", "lunch", "close")
LABEL = {"overnight": "Overnight", "open": "Open", "lunch": "After lunch", "close": "Close"}


def window_for(now, close_min=960):
    """Which window is active at `now` (a NY datetime), or ''. close_min = minutes after midnight when the market closes (half days)."""
    m = now.hour * 60 + now.minute
    if 570 <= m <= 630:
        return "open"
    if close_min >= 960 and 780 <= m <= 870:
        return "lunch"
    if 900 <= m <= close_min - 5:
        return "close"
    if m >= 1200 or m < 570:
        return "overnight"
    return ""


def _split(d):
    d = d.sort_index()
    d.index = pd.to_datetime(d.index).tz_convert(NY)
    return d


def slot_avg(d15):
    """Average volume of each 15-minute slot of the day over the history: {(h, m): volume}."""
    d = _split(d15)
    acc = {}
    for ts, v in d["volume"].items():
        acc.setdefault((ts.hour, ts.minute), []).append(float(v))
    return {k: st.mean(v) for k, v in acc.items() if v}


def _slot_per_min(slots, ts):
    k = (ts.hour, (ts.minute // 15) * 15)
    v = slots.get(k, 0.0)
    return v / 15.0


# ------------------------------------------------------------------ history events (45 days of 15-minute bars)
def _day_groups(d15):
    d = _split(d15)
    days = {}
    for ts, r in d.iterrows():
        days.setdefault(ts.date(), []).append((ts, r))
    return days


def events(d15, window, slots=None):
    """Past breakouts of one window: [{date, side, entry, level, after:[(high, low, close), ...]}], oldest first.
    'after' = the bars after the breakout bar, used to say whether it kept going (record) and for the replay."""
    slots = slots or slot_avg(d15)
    out = []
    for day, bars in _day_groups(d15).items():
        pre = [(ts, r) for ts, r in bars if time(4, 0) <= ts.time() < time(9, 30)]
        reg = [(ts, r) for ts, r in bars if time(9, 30) <= ts.time() < time(16, 0)]
        if len(reg) < 8:
            continue

        def big(ts, r, mult=2.0):
            base = slots.get((ts.hour, ts.minute), 0.0)
            return base > 0 and float(r["volume"]) >= mult * base
        if window == "open":
            pmh = max((r["high"] for _, r in pre), default=None)
            ts, f = reg[0]
            if pmh is not None and f["close"] > pmh * 1.001 and f["close"] >= f["open"] * 1.008 and big(ts, f):
                out.append({"date": day, "side": "up", "entry": float(f["close"]), "level": float(pmh),
                            "after": [(float(r["high"]), float(r["low"]), float(r["close"])) for _, r in reg[1:3]]})
        elif window == "lunch":
            rng = [(ts, r) for ts, r in reg if time(11, 30) <= ts.time() < time(13, 0)]
            if len(rng) < 5:
                continue
            rh, rl = max(r["high"] for _, r in rng), min(r["low"] for _, r in rng)
            for k, (ts, r) in enumerate(reg):
                if not (time(13, 0) <= ts.time() <= time(14, 15)):
                    continue
                if r["close"] > rh * 1.001 and r["close"] >= r["open"] and big(ts, r):
                    side, level = "up", rh
                elif r["close"] < rl * 0.999 and r["close"] <= r["open"] and big(ts, r):
                    side, level = "down", rl
                else:
                    continue
                out.append({"date": day, "side": side, "entry": float(r["close"]), "level": float(level),
                            "after": [(float(x["high"]), float(x["low"]), float(x["close"])) for _, x in reg[k + 1:k + 3]]})
                break
        elif window == "close":
            for k, (ts, r) in enumerate(reg):
                if not (time(15, 0) <= ts.time() <= time(15, 30)) or k < 4:
                    continue
                prior = [x for _, x in reg[:k]]
                hod, lod = max(x["high"] for x in prior), min(x["low"] for x in prior)
                if r["close"] > hod * 1.0005 and big(ts, r):
                    side, level = "up", hod
                elif r["close"] < lod * 0.9995 and big(ts, r):
                    side, level = "down", lod
                else:
                    continue
                out.append({"date": day, "side": side, "entry": float(r["close"]), "level": float(level),
                            "after": [(float(x["high"]), float(x["low"]), float(x["close"])) for _, x in reg[k + 1:k + 3]]})
                break
        elif window == "overnight":
            p = [(ts, r) for ts, r in pre if ts.time() < time(9, 15)]
            if len(p) < 10:
                continue
            lows = [float(r["low"]) for _, r in p]
            li = lows.index(min(lows))
            if li < 2 or li > len(p) - 3:
                continue
            hi_b = max(float(r["high"]) for _, r in p[:li])
            low = lows[li]
            if (hi_b - low) / hi_b < 0.015:
                continue
            for k in range(li + 1, len(p)):
                if float(p[k][1]["close"]) >= low * 1.008:
                    out.append({"date": day, "side": "up", "entry": float(p[k][1]["close"]), "level": low,
                                "after": [(float(r["high"]), float(r["low"]), float(r["close"])) for _, r in reg[:2]]})
                    break
    return out


def record(evs, window):
    """{n, hit, fail} from past events: hit = kept going 1% (0.5% in the closing hour); fail = fell back through the breakout level."""
    need = 0.005 if window == "close" else 0.01
    n = hit = fail = 0
    for e in evs:
        if not e["after"]:
            continue
        n += 1
        up = e["side"] == "up"
        best = max(a[0] for a in e["after"]) if up else min(a[1] for a in e["after"])
        worst = min(a[1] for a in e["after"]) if up else max(a[0] for a in e["after"])
        gain = (best / e["entry"] - 1) if up else (1 - best / e["entry"])
        if gain >= need:
            hit += 1
        elif (worst < e["level"]) if up else (worst > e["level"]):
            fail += 1
    return {"n": n, "hit": hit, "fail": fail}


def records_for(d15):
    slots = slot_avg(d15)
    out = {}
    for w in WINDOWS:
        evs = events(d15, w, slots)
        up = [e for e in evs if e["side"] == "up"]
        dn = [e for e in evs if e["side"] == "down"]
        out[w] = {"up": record(up, w), "down": record(dn, w)}
    return out, slots


def replay(d15, window, side_ok=("up", "down"), stop_pct=0.002):
    """Rough replay of one window over the 45 days: enter at the breakout bar close, stop just back through the level, target 1.5 R,
    otherwise out at the last bar. 15-minute bars only, so a bar that touches both stop and target counts as the stop."""
    trades = []
    for e in events(d15, window):
        if e["side"] not in side_ok or not e["after"]:
            continue
        up = e["side"] == "up"
        entry = e["entry"]
        stop = e["level"] * (1 - stop_pct) if up else e["level"] * (1 + stop_pct)
        risk = abs(entry - stop)
        if risk <= 0 or risk / entry > 0.05:
            continue
        tp = entry + 1.5 * risk if up else entry - 1.5 * risk
        r = None
        for hi, lo, cl in e["after"]:
            if (lo <= stop) if up else (hi >= stop):
                r = -1.0
                break
            if (hi >= tp) if up else (lo <= tp):
                r = 1.5
                break
        if r is None:
            last = e["after"][-1][2]
            r = ((last - entry) if up else (entry - last)) / risk
        trades.append({"date": str(e["date"]), "side": e["side"], "r": round(r, 2), "pct": round(r * risk / entry * 100, 2)})
    n = len(trades)
    wins = sum(1 for t in trades if t["r"] > 0)
    return {"window": window, "n": n, "wins": wins, "win_rate": round(wins / n * 100) if n else 0,
            "avg_r": round(sum(t["r"] for t in trades) / n, 2) if n else 0.0, "total_pct": round(sum(t["pct"] for t in trades), 1),
            "trades": trades[-12:]}


# ------------------------------------------------------------------ overnight record after days like today (for the Close window)
def overnight_stats(d15, today_row):
    """What the next overnight looked like after days that closed like today (same third of the day's range, 2+ down / up days).
    today_row = {o, h, l, c}. Returns {n, p_up, median} or {n: 0}."""
    from autobot import radar24 as r24
    d = _split(d15)
    d = d[d.index.date < today_row["date"]]
    rows = r24._daily(d)
    if len(rows) < 25:
        return {"n": 0}
    rng = today_row["h"] - today_row["l"]
    loc = (today_row["c"] - today_row["l"]) / rng if rng > 0 else 0.5
    b = "low" if loc < 0.33 else ("high" if loc > 0.67 else "mid")
    on = []
    for j in range(21, len(rows) - 1):
        r = rows[j]
        rg = r["h"] - r["l"]
        lj = (r["c"] - r["l"]) / rg if rg > 0 else 0.5
        bj = "low" if lj < 0.33 else ("high" if lj > 0.67 else "mid")
        if bj != b or not rows[j + 1].get("pm"):
            continue
        on.append((rows[j + 1]["pm"] / r["c"] - 1) * 100)
    if len(on) < MIN_N:
        return {"n": len(on)}
    return {"n": len(on), "p_up": round(sum(1 for x in on if x > 0) / len(on) * 100), "median": round(st.median(on), 2)}


# ------------------------------------------------------------------ live detection (1-minute bars)
def _today(d1, now):
    d1 = _split(d1)
    return d1[d1.index.date == now.date()]


def _vwap(d):
    tp = (d["high"] + d["low"] + d["close"]) / 3
    v = d["volume"].astype(float)
    return float((tp * v).sum() / v.sum()) if float(v.sum()) > 0 else float(d["close"].iloc[-1])


def _plan(side, p, level, minr):
    """Zone / stop / targets for a breakout at price p through `level`."""
    risk_floor = max(0.01 * p, 0.04)
    if side == "up":
        zlo, zhi = round(max(level, p * 0.997), 2), round(p * 1.003, 2)
        mid = (zlo + zhi) / 2
        stop = round(min(level * 0.998, zlo - risk_floor), 2)
        risk = max(mid - stop, risk_floor)
        return [zlo, zhi], stop, round(mid + 1.5 * risk, 2), round(mid + 2.5 * risk, 2)
    zlo, zhi = round(p * 0.997, 2), round(min(max(level, p * 0.997), p * 1.003), 2)
    if zhi <= zlo:
        zhi = round(zlo * 1.003, 2)
    mid = (zlo + zhi) / 2
    stop = round(max(level * 1.002, zhi + risk_floor), 2)
    risk = max(stop - mid, risk_floor)
    return [zlo, zhi], stop, round(mid - 1.5 * risk, 2), round(mid - 2.5 * risk, 2)


def _score(rvol, vol_mult, move, rate):
    s = 50 + min(25, (rvol - vol_mult) * 4) + min(15, move * 4)
    if rate is not None:
        s += (rate - 50) * 0.3
    return int(max(40, min(98, round(s))))


def _card(sym, window, side, kind, name, p, level, level_txt, move, rvol, rec, vol_mult, extra=None, atr=0.0):
    zone, stop, tp1, tp2 = _plan(side, p, level, 0)
    n, hit, fail = rec.get("n", 0), rec.get("hit", 0), rec.get("fail", 0)
    rate = round(hit / n * 100) if n >= MIN_N else None
    score = _score(rvol, vol_mult, move, rate)
    c = {"symbol": sym, "side": side, "window": window, "kind": kind, "name": name, "score": score,
         "label": "STRONG" if score >= 75 else "GOOD" if score >= 62 else "WEAK", "price": round(p, 2), "level": round(level, 2),
         "level_txt": level_txt, "move_pct_now": round(move, 2), "rvol": round(rvol, 1), "zone": zone, "stop": stop, "tp1": tp1, "tp2": tp2,
         "n": n, "hits": hit, "fails": fail, "hit_rate": rate if rate is not None else 0, "has_record": rate is not None,
         "move_pct": 1.0, "atr": round(atr, 2), "entry_day": "", "warn": [], "window_label": LABEL[window]}
    if extra:
        c.update(extra)
    return c


def detect_open(sym, d1, now, recs, slots, vol_mult=3.0, min_move=0.8, price=None):
    from autobot.opendrive import detect
    base = {"first": slots.get((9, 30), 0.0), "second": slots.get((9, 45), 0.0)}
    rec = (recs or {}).get("open", {}).get("up", {"n": 0, "hit": 0, "fail": 0})
    c = detect(sym, d1, now, rec, base, vol_mult, min_move, price)
    if not c:
        return None
    c.update(window="open", window_label=LABEL["open"], level=c["pmh"], level_txt=f"broke above its pre-market high ${c['pmh']:.2f}",
             move_pct_now=c["move_open_pct"], warn=[])
    return c


def detect_lunch(sym, d1, now, recs, slots, vol_mult=3.0, min_move=0.8, price=None):
    d = _today(d1, now)
    reg = d[d.index.time >= time(9, 30)]
    rng = reg[(reg.index.time >= time(11, 30)) & (reg.index.time < time(13, 0))]
    cur = reg[reg.index.time >= time(13, 0)]
    if len(rng) < 60 or len(cur) < 3:
        return None
    rh, rl = float(rng["high"].max()), float(rng["low"].min())
    p = float(price or cur["close"].iloc[-1])
    ago = float(cur["close"].iloc[max(0, len(cur) - 16)])
    move = (p / ago - 1) * 100
    last10 = cur.tail(10)
    base = _slot_per_min(slots, cur.index[-1]) * len(last10)
    rvol = float(last10["volume"].sum()) / base if base > 0 else 0.0
    if rvol < vol_mult or abs(move) < min_move * 0.5:
        return None
    if p > rh * 1.001 and move > 0:
        side, level, txt = "up", rh, f"broke above the 11:30-1:00 range high ${rh:.2f}"
    elif p < rl * 0.999 and move < 0:
        side, level, txt = "down", rl, f"broke below the 11:30-1:00 range low ${rl:.2f}"
    else:
        return None
    rec = (recs or {}).get("lunch", {}).get(side, {"n": 0, "hit": 0, "fail": 0})
    return _card(sym, "lunch", side, "LUNCH_BREAK", "AFTER-LUNCH BREAKOUT" if side == "up" else "AFTER-LUNCH BREAKDOWN", p, level, txt,
                 abs(move), rvol, rec, vol_mult, atr=float((reg["high"] - reg["low"]).mean()) * 5)


def detect_close(sym, d1, now, recs, slots, vol_mult=3.0, min_move=0.8, price=None, today_row15=None, d15=None, close_min=960):
    d = _today(d1, now)
    reg = d[d.index.time >= time(9, 30)]
    if len(reg) < 90:
        return None
    mins_left = close_min - (now.hour * 60 + now.minute)
    body, tail = reg.iloc[:-10], reg.iloc[-10:]
    hod, lod = float(body["high"].max()), float(body["low"].min())
    p = float(price or reg["close"].iloc[-1])
    vw = _vwap(reg)
    ago = float(reg["close"].iloc[-31]) if len(reg) > 31 else float(reg["open"].iloc[0])
    move = (p / ago - 1) * 100
    base = _slot_per_min(slots, tail.index[-1]) * len(tail)
    rvol = float(tail["volume"].sum()) / base if base > 0 else 0.0
    if rvol < vol_mult or abs(move) < min_move * 0.5:
        return None
    if p > hod * 1.0005 and p > vw and move > 0:
        side, level, txt = "up", hod, f"broke above today's high ${hod:.2f} and is over VWAP ${vw:.2f}"
    elif p < lod * 0.9995 and p < vw and move < 0:
        side, level, txt = "down", lod, f"broke below today's low ${lod:.2f} and is under VWAP ${vw:.2f}"
    else:
        return None
    rec = (recs or {}).get("close", {}).get(side, {"n": 0, "hit": 0, "fail": 0})
    extra = {"mins_left": int(mins_left), "last_call": bool(side == "down" and mins_left <= 15)}
    warn = []
    if d15 is not None:
        try:
            row = {"date": now.date(), "o": float(reg["open"].iloc[0]), "h": float(reg["high"].max()), "l": float(reg["low"].min()), "c": p}
            ov = overnight_stats(d15, row)
            extra["overnight"] = ov
            if side == "down" and ov.get("p_up", 0) >= 55:
                warn.append(f"After days that close like this one, {ov['p_up']}% of {ov['n']} nights opened higher (median {ov['median']:+.1f}%). Cover before the close, or use the reversal watch.")
            if side == "up" and ov.get("p_up", 100) <= 45 and ov.get("n", 0) >= MIN_N:
                warn.append(f"After days that close like this one, only {ov['p_up']}% of {ov['n']} nights were higher. Consider selling before the close.")
        except Exception:
            pass
        try:
            from autobot import radar24 as r24
            rows = r24._daily(_split(d15)[lambda x: x.index.date < now.date()])
            if len(rows) >= 22:
                c0 = rows[-1]["c"]
                m20 = sum(x["c"] for x in rows[-20:]) / 20
                down = sum(1 for k in range(-3, 0) if rows[k]["c"] < rows[k - 1]["c"])
                if side == "down" and down >= 2 and (c0 / m20 - 1) <= -0.03:
                    warn.append("It has fallen several days in a row and sits well under its 20-day average. That is the weakest time to short: squeezes often start overnight.")
                if side == "up" and down == 0 and (c0 / m20 - 1) >= 0.03:
                    warn.append("It is extended after several up days. Pullbacks often start overnight.")
        except Exception:
            pass
    extra["warn"] = warn
    return _card(sym, "close", side, "CLOSE_BREAK", "CLOSING BREAKOUT" if side == "up" else "CLOSING BREAKDOWN", p, level, txt,
                 abs(move), rvol, rec, vol_mult, extra=extra, atr=float((reg["high"] - reg["low"]).mean()) * 5)


def detect_overnight(sym, d1, now, recs, slots, vol_mult=3.0, min_move=0.8, price=None):
    d = _split(d1)
    start = now.replace(hour=20, minute=0, second=0, microsecond=0)
    if now < start:
        start -= timedelta(days=1)
    d = d[(d.index >= start) & (d.index <= now + timedelta(minutes=1))]
    d = d[d["volume"] > 0]
    if len(d) < 20 or (now - d.index[-1]).total_seconds() > 600:
        return None                                   # too thin to say anything
    p = float(price or d["close"].iloc[-1])
    vw = _vwap(d)
    avg = float(d["volume"].mean())
    recent = d[d.index >= now - timedelta(minutes=30)]
    if len(recent) < 4:
        return None
    rvol = float(recent["volume"].mean()) / avg if avg > 0 else 0.0
    lo_i = int(d["low"].values.argmin())
    low = float(d["low"].iloc[lo_i])
    hi_b = float(d["high"].iloc[:max(lo_i, 1)].max())
    first = float(d["open"].iloc[0])
    side = kind = name = txt = None
    level = low
    if lo_i >= 3 and (hi_b - low) / hi_b >= 0.015 and p >= low * 1.008 and p > vw and rvol >= 1.5:
        side, kind, name, level = "up", "ON_FLUSH_RECLAIM", "OVERNIGHT FLUSH AND RECLAIM", low
        txt = f"dropped to ${low:.2f} ({(hi_b - low) / hi_b * 100:.1f}% off its high) and is back above its overnight average ${vw:.2f}"
        move = (p / low - 1) * 100
        rec = (recs or {}).get("overnight", {}).get("up", {"n": 0, "hit": 0, "fail": 0})
    elif (p / first - 1) * 100 >= 1.0 and p >= float(d["high"].max()) * 0.998 and rvol >= 1.5:
        side, kind, name, level = "up", "ON_BUILD", "OVERNIGHT BUILD", float(d["high"].iloc[:-5].max())
        txt = f"climbing steadily overnight, up {(p / first - 1) * 100:.1f}% on above-normal volume"
        move = (p / first - 1) * 100
        rec = {"n": 0, "hit": 0, "fail": 0}
    elif (first / p - 1) * 100 >= 1.0 and p <= float(d["low"].min()) * 1.002 and rvol >= 1.5:
        side, kind, name, level = "down", "ON_BREAKDOWN", "OVERNIGHT BREAKDOWN", float(d["low"].iloc[:-5].min())
        txt = f"sliding overnight, down {(first / p - 1) * 100:.1f}% on above-normal volume"
        move = (first / p - 1) * 100
        rec = {"n": 0, "hit": 0, "fail": 0}
    if not side:
        return None
    if move < min_move:
        return None
    extra = {"thin": True, "warn": ["Overnight trading is thin: wide spreads, limit orders only, and the stop is watched by the app (Alpaca cannot hold it)."]}
    return _card(sym, "overnight", side, kind, name, p, level, txt, move, rvol * vol_mult / 1.5 if rvol else 0, rec, vol_mult, extra=extra,
                 atr=float((d["high"] - d["low"]).mean()) * 8)
