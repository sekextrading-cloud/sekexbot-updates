"""v2.26: what the app's own AI calls cost. Every call that goes through ai_post is counted here (tokens in / out, per feature, per day).
Dollars are an ESTIMATE from public list prices per million tokens; the real bill is in your AI provider's console."""
import json
import os
import threading
import time
from datetime import date

from .config import DATA_DIR

FILE = DATA_DIR / "ai_usage.json"
CFG_FILE = DATA_DIR / "ai_limit.json"        # v2.28: optional daily AI limit (dollars). 0 = off.
_lock = threading.Lock()
# (input $, output $) per million tokens, matched by a word in the model name. Estimates, not a price list.
PRICES = [("haiku", 1.0, 5.0), ("sonnet", 3.0, 15.0), ("opus", 5.0, 25.0), ("gpt-5-mini", 0.25, 2.0), ("gpt-5", 1.25, 10.0), ("gpt-4o-mini", 0.15, 0.6),
          ("gpt-4", 2.5, 10.0), ("o3", 2.0, 8.0), ("o4", 1.1, 4.4)]
FEATURES = {"aihelper": "Ask AI", "helpdesk": "Help & repair", "selffix": "Fix with Claude", "presets": "Strategy builder", "signalaudit": "Signal audit",
            "analyst": "Chart analyst", "plan": "Morning plan"}


def price(model):
    m = (model or "").lower()
    for k, i, o in PRICES:
        if k in m:
            return i, o
    return None


def cost(model, tin, tout, local=False):
    if local:
        return 0.0
    p = price(model)
    return None if p is None else (tin * p[0] + tout * p[1]) / 1e6


def _save(path, obj):
    """Write to a temp file then swap, so a crash or power loss never leaves a half-written (lost) file."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(obj))
    os.replace(tmp, path)


def _load():
    try:
        return json.loads(FILE.read_text())
    except Exception:
        return {}


def record(feature, model, tin, tout, ok=True, local=False):
    try:
        with _lock:
            d = _load()
            day = d.setdefault(str(date.today()), {})
            f = day.setdefault(feature, {"calls": 0, "fail": 0, "in": 0, "out": 0, "usd": 0.0, "unpriced": 0})
            f["calls"] += 1
            if not ok:
                f["fail"] += 1
            f["in"] += int(tin or 0)
            f["out"] += int(tout or 0)
            c = cost(model, int(tin or 0), int(tout or 0), local)
            if c is None:
                f["unpriced"] += 1
            else:
                f["usd"] = round(f["usd"] + c, 6)
            for k in sorted(d)[:-120]:
                d.pop(k, None)
            _save(FILE, d)
    except Exception:
        pass


def summary():
    d = _load()
    today = str(date.today())
    mon = today[:7]
    def tot(days):
        t = {"calls": 0, "in": 0, "out": 0, "usd": 0.0, "unpriced": 0}
        by = {}
        for k in days:
            for feat, f in d[k].items():
                for x in ("calls", "in", "out", "unpriced"):
                    t[x] += f.get(x, 0)
                t["usd"] += f.get("usd", 0.0)
                b = by.setdefault(feat, {"calls": 0, "in": 0, "out": 0, "usd": 0.0})
                for x in ("calls", "in", "out"):
                    b[x] += f.get(x, 0)
                b["usd"] += f.get("usd", 0.0)
        t["usd"] = round(t["usd"], 4)
        return t, [dict(name=n, **{k: (round(v, 4) if k == "usd" else v) for k, v in b.items()}) for n, b in sorted(by.items(), key=lambda kv: -kv[1]["usd"])]
    t_today, by_today = tot([k for k in d if k == today])
    t_month, by_month = tot([k for k in d if k.startswith(mon)])
    t_all, _ = tot(list(d))
    last7 = [{"day": k, "usd": round(sum(f.get("usd", 0.0) for f in d[k].values()), 4), "calls": sum(f.get("calls", 0) for f in d[k].values())} for k in sorted(d)[-7:]]
    return {"limit_state": state(), "today": t_today, "month": t_month, "tracked": t_all, "by_feature_month": by_month, "by_feature_today": by_today, "last7": last7, "since": min(d) if d else ""}


# ---------------- v2.28: optional daily AI limit ----------------
def cfg():
    c = {"limit": 0.0, "warn": 80, "warned": {"day": "", "lvl": 0}}
    try:
        c.update(json.loads(CFG_FILE.read_text()))
    except Exception:
        pass
    return c


def set_cfg(limit=None, warn=None):
    c = cfg()
    if limit is not None:
        c["limit"] = max(0.0, min(1000.0, float(limit)))
        c["warned"] = {"day": "", "lvl": 0}
    if warn is not None:
        c["warn"] = 100 if int(warn) >= 100 else 80
    try:
        _save(CFG_FILE, c)
    except Exception:
        pass
    return c


def today_usd():
    d = _load()
    return round(sum(f.get("usd", 0.0) for f in d.get(str(date.today()), {}).values()), 4)


def state():
    c = cfg()
    t = today_usd()
    lim = float(c.get("limit") or 0)
    pct = round(t / lim * 100) if lim > 0 else 0
    return {"limit": lim, "warn": int(c.get("warn", 80)), "today": t, "pct": pct, "paused": bool(lim > 0 and t >= lim)}


def blocked():
    """A plain message when today's AI spend has reached the limit you set, else ''. Trading never calls this: only the AI features do."""
    st = state()
    if st["paused"]:
        return f"Daily AI limit reached (${st['today']:.2f} of ${st['limit']:.2f}). AI features are paused until tomorrow. Raise or turn off the limit on the AI tab. Trading is not affected."
    return ""


def warn_due():
    """A (title, body) the first time today's spend crosses the warn level (80% or 100% of the limit), else None."""
    st = state()
    if st["limit"] <= 0:
        return None
    c = cfg()
    lvl = 100 if st["pct"] >= 100 else 80 if st["pct"] >= 80 else 0
    if lvl == 0 or lvl < int(c.get("warn", 80)):
        return None
    w = c.get("warned") or {}
    day = str(date.today())
    if w.get("day") == day and int(w.get("lvl", 0)) >= lvl:
        return None
    c["warned"] = {"day": day, "lvl": lvl}
    try:
        _save(CFG_FILE, c)
    except Exception:
        pass
    return (f"AI spend today: {st['pct']}% of your limit", f"${st['today']:.2f} of ${st['limit']:.2f}." + (" AI features are now paused until tomorrow." if lvl >= 100 else ""))
