"""v2.29: Day Playbook. Reads the morning (overnight move, overnight volume, news), labels each stock, picks the setup for it, stops opening NEW trades
at a time you choose (open trades are still managed and closed), checks your idea against the last 45 days, and grades its own calls at the end of the day.
Pure functions here; server.py supplies the data."""
import json
from pathlib import Path

import numpy as np
import pandas as pd

from .config import DATA_DIR

FILE = DATA_DIR / "playbook.json"
DEFAULT = {"on": False, "stop_at": "10:30"}
STOPS = {"10:30": (10, 30), "11:30": (11, 30)}
LABELS = {
    "fade": ("GAP AND FADE", "VWAP rejection short"),
    "run": ("GAP AND RUN", "breakout / jump in, buy"),
    "news": ("NEWS SPIKE", "wait for the first pullback, then decide"),
    "quiet": ("QUIET · SKIP", "no trades"),
    "normal": ("NORMAL", "the usual setups"),
}


def load():
    d = dict(DEFAULT)
    try:
        d.update(json.loads(Path(FILE).read_text()))
    except Exception:
        pass
    d["stop_at"] = d["stop_at"] if d["stop_at"] in ("10:30", "11:30", "off") else "10:30"
    d["on"] = bool(d["on"])
    return d


def save(on=None, stop_at=None):
    d = load()
    if on is not None:
        d["on"] = bool(on)
    if stop_at in ("10:30", "11:30", "off"):
        d["stop_at"] = stop_at
    try:
        Path(FILE).write_text(json.dumps(d))
    except Exception:
        pass
    return d


def blocks_new(now, cfg=None):
    """A plain reason when new regular-hours trades are not allowed any more today, else ''. Pre-market and after-hours are not touched (Run Hunter has its own rules)."""
    c = cfg or load()
    if not c["on"] or c["stop_at"] not in STOPS or now.weekday() >= 5:
        return ""
    h, m = STOPS[c["stop_at"]]
    cur = now.hour * 60 + now.minute
    if h * 60 + m <= cur < 960:
        return f"Day Playbook: no new trades after {h}:{m:02d} AM"
    return ""


def label(gap_pct, ov_ratio, has_news, news_age_h=None, market_up=None):
    """gap_pct: price now vs yesterday's close. ov_ratio: overnight (4-9:30) volume vs this stock's usual. Returns (key, why)."""
    ag = abs(gap_pct)
    if ag < 0.5 and not has_news:
        return "quiet", f"Under 0.5% overnight, {'normal' if ov_ratio < 2 else 'busy'} volume."
    if has_news and (news_age_h is None or news_age_h <= 8) and ag >= 1.5:
        return "news", "A headline came out overnight and the price jumped."
    if gap_pct >= 3 and ov_ratio >= 3:
        mk = "" if market_up is None else (" Market is up." if market_up else " Market is down.")
        return "run", f"Up {gap_pct:.1f}% on {ov_ratio:.0f}x normal overnight volume.{mk}"
    if gap_pct >= 3 and not has_news:
        return "fade", f"Up {gap_pct:.1f}% overnight on thin volume, no news. These often give it back."
    if gap_pct <= -3 and not has_news:
        return "fade", f"Down {abs(gap_pct):.1f}% overnight on {'thin ' if ov_ratio < 3 else ''}volume, no news. These often bounce back."
    return "normal", f"{'Up' if gap_pct >= 0 else 'Down'} {ag:.1f}% overnight."


def read_stock(d15, now, has_news=False, news_age_h=None, market_up=None):
    """d15: 15-minute bars (45 days, pre-market included) for one stock. Returns the morning read, or None."""
    if d15 is None or len(d15) < 60:
        return None
    d = d15
    hm = d.index.hour * 60 + d.index.minute
    today = d[d.index.date == now.date()]
    prev = [x for x in sorted(set(d.index.date)) if x < now.date()]
    if not prev:
        return None
    yd = d[d.index.date == prev[-1]]
    yh = yd.index.hour * 60 + yd.index.minute
    yreg = yd[(yh >= 570) & (yh < 960)]
    if len(yreg) == 0 or len(today) == 0:
        return None
    pc = float(yreg["close"].iloc[-1])
    px = float(today["close"].iloc[-1])
    th = today.index.hour * 60 + today.index.minute
    ov_today = float(today[th < 570]["volume"].sum())
    ovs = []
    for dd in prev[-30:]:
        x = d[d.index.date == dd]
        xh = x.index.hour * 60 + x.index.minute
        ovs.append(float(x[xh < 570]["volume"].sum()))
    ovs = [v for v in ovs if v > 0]
    ov_ratio = ov_today / max(1.0, float(np.median(ovs))) if ovs else 1.0
    gap = (px / pc - 1) * 100
    key, why = label(gap, ov_ratio, has_news, news_age_h, market_up)
    return {"key": key, "label": LABELS[key][0], "plan": LABELS[key][1], "why": why, "gap": round(gap, 1), "ov_ratio": round(ov_ratio, 1), "open_px": round(float(today["open"].iloc[0]), 2), "price": round(px, 2)}


def done_by(d15, cut_h=10, cut_m=30, days=45):
    """Percent of days where at least 70% of the whole regular-hours range (9:30-4:00) was already made by the cut time."""
    if d15 is None or len(d15) < 60:
        return None
    n = ok = 0
    for day in sorted(set(d15.index.date))[-days:]:
        x = d15[d15.index.date == day]
        xm = x.index.hour * 60 + x.index.minute
        r = x[(xm >= 570) & (xm < 960)]
        if len(r) < 20:
            continue
        rm = r.index.hour * 60 + r.index.minute
        full = float(r["high"].max() - r["low"].min())
        early = r[rm < cut_h * 60 + cut_m]
        if full <= 0 or len(early) == 0:
            continue
        n += 1
        ok += 1 if float(early["high"].max() - early["low"].min()) >= 0.7 * full else 0
    return None if n < 10 else round(ok / n * 100)


def replay(sigs, d5, risk_usd=50.0, cut=(10, 30), horizon=24):
    """What the signals would have made: each trade risks risk_usd, wins its target multiple or loses 1R, else is marked at the horizon.
    Returns {'early': dollars for signals before the cut, 'all': dollars for all signals, 'n_early', 'n_all'}. A bar touching both counts as the stop."""
    hi, lo, cl, days = d5["high"].values, d5["low"].values, d5["close"].values, d5.index.date
    early = allv = 0.0
    ne = na = 0
    for s in sigs:
        i, up = s["i"], s["side"] == "up"
        risk = abs(s["price"] - s["stop"]) or 0.01
        rr = abs(s["tp1"] - s["price"]) / risk
        r = None
        end = min(len(d5) - 1, i + horizon)
        last = i
        for j in range(i + 1, end + 1):
            if days[j] != days[i]:
                break
            last = j
            stop_hit = lo[j] <= s["stop"] if up else hi[j] >= s["stop"]
            tp_hit = hi[j] >= s["tp1"] if up else lo[j] <= s["tp1"]
            if stop_hit:
                r = -1.0
                break
            if tp_hit:
                r = rr
                break
        if r is None:
            if last == i:
                continue
            r = ((cl[last] - s["price"]) if up else (s["price"] - cl[last])) / risk
        usd = r * risk_usd
        hh, mm = int(s["t"][:2]), int(s["t"][3:])
        na += 1
        allv += usd
        if (hh, mm) < cut:
            ne += 1
            early += usd
    return {"early": round(early, 2), "all": round(allv, 2), "n_early": ne, "n_all": na}


def grade(reads, moves):
    """reads: {sym: {'key', 'gap'}}; moves: {sym: percent move from today's regular open to now}. A fade is right when the stock moved back against its
    overnight gap, a run when it kept going up, a news spike when it moved 1% or more, quiet when it stayed under 1%. Returns (right, total)."""
    right = tot = 0
    for s, r in reads.items():
        m = moves.get(s)
        if m is None:
            continue
        k, gap = r.get("key"), r.get("gap", 0)
        tot += 1
        if k == "fade":
            right += 1 if abs(m) >= 0.3 and (m < 0) == (gap >= 0) else 0
        elif k == "run":
            right += 1 if m > 0 else 0
        elif k == "news":
            right += 1 if abs(m) >= 1.0 else 0
        elif k == "quiet":
            right += 1 if abs(m) < 1.0 else 0
        else:
            right += 1
    return right, tot
