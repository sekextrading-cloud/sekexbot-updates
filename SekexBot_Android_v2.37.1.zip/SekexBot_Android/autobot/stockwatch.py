"""v2.10: reversal watch. You name a stock you are short (or long) or have marked negative; the app follows its price day and night
and pings your phone when it BOUNCES off the low (so you can cover before it falls again) and again when the bounce fails."""
import json
import threading
import time
from pathlib import Path

MAX_ALERTS = 8        # per watch per day, so a choppy stock cannot flood the phone


class StockWatch:
    def __init__(self, path):
        self.path = Path(path)
        self.lock = threading.Lock()
        self.w = {}
        try:
            self.w = json.loads(self.path.read_text())
        except Exception:
            self.w = {}

    def _save(self):
        try:
            self.path.write_text(json.dumps(self.w))
        except Exception:
            pass

    def list(self):
        with self.lock:
            return {k: dict(v) for k, v in self.w.items()}

    def add(self, sym, side, px, bounce_pct, cover=None, entry=None):
        side = "long" if side == "long" else "short"
        with self.lock:
            self.w[sym] = {"side": side, "start": px, "ext": px, "ext_ts": time.time(), "bounce": bounce_pct, "cover": cover, "entry": entry, "peak": 0.0, "gb": False,
                           "phase": "watching", "alerts": 0, "day": time.strftime("%Y-%m-%d"), "last": px, "msg": "Watching", "t": time.time(), "log": []}
            self._save()
        return self.w[sym]

    def remove(self, sym):
        with self.lock:
            self.w.pop(sym, None)
            self._save()

    def tick(self, sym, px, send):
        """Feed one price. send(title, body) is called for each alert."""
        with self.lock:
            w = self.w.get(sym)
            if not w or not px:
                return
            today = time.strftime("%Y-%m-%d")
            if w.get("day") != today:
                w["day"], w["alerts"] = today, 0
            short = w["side"] == "short"
            b = w["bounce"] / 100.0
            w["last"] = px
            w["t"] = time.time()
            # the extreme is the low for a short (the stock falling in your favour) and the high for a long
            if (short and px < w["ext"]) or (not short and px > w["ext"]):
                w["ext"] = px
            ext = w["ext"]
            moved = (w["start"] - ext) / w["start"] if short else (ext - w["start"]) / w["start"]
            back = (px - ext) / ext if short else (ext - px) / ext        # how far it has come back against that move
            msgs = []
            def fire(title, body):
                if w["alerts"] >= MAX_ALERTS:
                    return
                w["alerts"] += 1
                w["log"] = ([{"t": time.strftime("%H:%M"), "m": title}] + w.get("log", []))[:6]
                msgs.append((title, body))
            ent = w.get("entry")
            if ent:                                           # your own trade: warn when a good chunk of the open profit is handed back
                prof = (ent - px) if short else (px - ent)
                if prof > w.get("peak", 0):
                    w["peak"], w["gb"] = prof, False
                elif w["peak"] >= ent * 0.005 and not w.get("gb") and (w["peak"] - prof) / w["peak"] >= 0.2:
                    w["gb"] = True
                    qn = abs(w.get("qty") or 0)
                    extra = f" (about ${(w['peak'] - prof) * qn:,.0f} given back)" if qn else ""
                    fire(f"💰 {sym}: protect your profit", f"Your best was ${w['peak']:.2f}/share, now ${prof:.2f}{extra}. Consider closing before more slips away.")

            cov = w.get("cover")
            if short and cov and px <= cov and w["phase"] == "watching" and not w.get("zone"):
                w["zone"] = True
                fire(f"{sym} reached your cover zone", f"${px:.2f} is at or below ${cov:.2f}. Bounces often start here, so watch it closely.")
            if w["phase"] == "watching":
                if moved >= b / 2 and back >= b:
                    w["phase"], w["high"] = "bounced", px
                    w["msg"] = f"Bounced {back * 100:.1f}% off the {'low' if short else 'high'} ${ext:.2f}"
                    if short:
                        fire(f"🔔 {sym} bounced {back * 100:.1f}% off its low", f"Low ${ext:.2f}, now ${px:.2f}. Good time to cover the short before it falls again.")
                    else:
                        fire(f"🔔 {sym} slipped {back * 100:.1f}% off its high", f"High ${ext:.2f}, now ${px:.2f}. Consider selling before it falls further.")
                else:
                    w["msg"] = f"Watching · {'low' if short else 'high'} ${ext:.2f}"
            elif w["phase"] == "bounced":
                hi = w["high"]
                w["high"] = max(hi, px) if short else min(hi, px)
                hi = w["high"]
                fade = (hi - px) / hi if short else (px - hi) / hi
                w["msg"] = f"Bounced to ${hi:.2f}"
                if fade >= b * 0.7:
                    fire(f"⚠ {sym} bounce is fading", f"Peaked ${hi:.2f}, now ${px:.2f}. " + ("It is turning back down: cover now if you are still short." if short else "It is turning back up."))
                    w.update(phase="watching", ext=px, start=px, zone=False)
            self._save()
        for t, bdy in msgs:
            try:
                send(t, bdy)
            except Exception:
                pass
