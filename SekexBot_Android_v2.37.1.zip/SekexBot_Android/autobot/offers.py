"""Preset offers from your support person (v2.8.0).

Support can suggest a preset from the Admin AI analysis. It arrives at the normal diagnostics check-in and shows up as
a card; NOTHING changes until the user taps Apply. This module is the phone-side gatekeeper: only the whitelisted
preset settings, each with a safe range, can ever get through. The daily loss limit, API keys, PIN and Live/Paper mode
are NOT in the list, so they cannot be sent or applied, whatever the collector says."""
import re

# key -> (type, low, high)   (bool has no range)
RULES = {
    "auto_direction": ("bool",), "allow_shorts": ("bool",), "trade_all_flips": ("bool",), "scalp_mode": ("bool",),
    "aggressive_scalp": ("bool",), "tod_filter": ("bool",), "cooloff_streak": ("bool",), "cooloff_symbol": ("bool",),
    "scale_out": ("bool",), "ext_premarket": ("bool",), "ext_afterhours": ("bool",), "reentry": ("bool",),
    "pct_harvest": ("bool",),
    "ext_risk_mult": ("float", 0.1, 1.0), "max_positions": ("int", 1, 8), "risk_per_trade_frac": ("float", 0.05, 0.40),
}

LABELS = {"auto_direction": "Auto direction", "allow_shorts": "Shorts", "trade_all_flips": "Trade every flip", "scalp_mode": "Scalp mode",
          "aggressive_scalp": "Aggressive scalp", "tod_filter": "Time-of-day filter", "cooloff_streak": "Cool-off after losses",
          "cooloff_symbol": "Cool-off per symbol", "scale_out": "Scale out", "ext_premarket": "Pre-market trading",
          "ext_afterhours": "After-hours trading", "reentry": "Re-entry", "pct_harvest": "% harvest",
          "ext_risk_mult": "Extended-hours risk", "max_positions": "Max positions", "risk_per_trade_frac": "Risk per trade (share of daily limit)"}


def sanitize(o) -> dict | None:
    """Return a clean offer {id, name, reason, settings} or None if it is unusable. Unknown/out-of-range keys are dropped."""
    if not isinstance(o, dict):
        return None
    oid = re.sub(r"[^0-9a-zA-Z_-]", "", str(o.get("id") or ""))[:40]
    name = re.sub(r"\s+", " ", re.sub(r"[<>]", "", str(o.get("name") or "")).strip())[:24]
    if not oid or not name or not isinstance(o.get("settings"), dict):
        return None
    clean = {}
    for k, v in o["settings"].items():
        r = RULES.get(k)
        if not r:
            continue                                  # not whitelisted (daily loss limit, keys, PIN, live...) -> ignored
        try:
            if r[0] == "bool":
                if not isinstance(v, bool):
                    continue
                clean[k] = v
            else:
                if isinstance(v, bool):
                    continue
                x = int(v) if r[0] == "int" else float(v)
                if r[0] == "int" and x != v:
                    continue
                clean[k] = max(r[1], min(r[2], x))
        except (TypeError, ValueError):
            continue
    if not clean:
        return None
    reason = re.sub(r"\s+", " ", re.sub(r"[<>]", "", str(o.get("reason") or "")).strip())[:400]
    return {"id": oid, "name": name, "reason": reason, "settings": clean}


def diff(clean: dict, current: dict) -> list:
    out = []
    for k, v in clean["settings"].items():
        cur = current.get(k)
        if cur != v:
            out.append({"key": k, "label": LABELS.get(k, k), "from": cur, "to": v})
    return out
