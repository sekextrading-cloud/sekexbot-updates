"""v2.36: Reality check. Is each setup still doing in real trades what it did before?
For every setup with closed real trades (PAPER or LIVE, not the simulator) in the last 60 days it compares the LAST 20 trades
("now") with the trades before them ("before"), or with a test record when one is given. Status:
  TOO FEW   under 8 trades: not enough to judge
  OK        average result now is 0R or better and not far below before
  FADING    now is under 0R and at least 0.3R worse than before: its size is halved where the app controls it (Morning Wave)
  POOR      now is -0.3R or worse over 15+ trades: a warning to switch it off in the Scorecard
Slip: the average gap between the price aimed for and the price filled, per share (Morning Wave records it)."""
import re

NOW_N, MIN_N = 20, 8


def _stats(rs):
    if not rs:
        return None
    rr = [float(r.get("r") or 0) for r in rs]
    pn = [float(r.get("pnl") or 0) for r in rs]
    gw, gl = sum(p for p in pn if p > 0), -sum(p for p in pn if p < 0)
    return {"n": len(rs), "avg_r": round(sum(rr) / len(rr), 2), "win": round(100 * sum(1 for p in pn if p > 0) / len(pn)),
            "pf": round(gw / gl, 2) if gl else None, "pnl": round(sum(pn), 2)}


def check(rows, tests=None):
    """rows: journal trades (newest first, as db.recent gives them). tests: {setup: avg_r} from a test record, optional."""
    tests = tests or {}
    by = {}
    for r in rows:
        if r.get("status") != "closed" or r.get("mode") == "SIM":
            continue
        k = str(r.get("strategy") or "?").split("@")[0]
        if k in ("MANUAL",):
            continue
        by.setdefault(k, []).append(r)
    out = []
    for k, rs in by.items():
        now, before = rs[:NOW_N], rs[NOW_N:]
        sn, sb = _stats(now), _stats(before)
        test = tests.get(k)
        ref = test if test is not None else (sb["avg_r"] if sb and sb["n"] >= 10 else None)
        slips = []
        for r in now:
            m = re.search(r"slip \$?(-?\d+(?:\.\d+)?)", str(r.get("note") or ""))
            if m:
                slips.append(float(m.group(1)))
        st, act = "OK", ""
        if sn["n"] < MIN_N:
            st = "TOO FEW"
        elif sn["avg_r"] <= -0.3 and sn["n"] >= 15:
            st, act = "POOR", "losing: consider switching it off in the Scorecard"
        elif sn["avg_r"] < 0 and ref is not None and sn["avg_r"] < ref - 0.3:
            st, act = "FADING", "half size"
        elif sn["avg_r"] < 0:
            st = "WATCH"
        out.append({"setup": k, "now": sn, "before": sb, "test": test, "ref": ref, "status": st, "action": act,
                    "slip": round(sum(slips) / len(slips), 3) if slips else None})
    order = {"POOR": 0, "FADING": 1, "WATCH": 2, "OK": 3, "TOO FEW": 4}
    out.sort(key=lambda x: (order[x["status"]], -x["now"]["n"]))
    return out


def size_mult(results, setup):
    """0.5 when the setup is FADING or POOR, else 1."""
    for x in results:
        if x["setup"] == setup:
            return 0.5 if x["status"] in ("FADING", "POOR") else 1.0
    return 1.0
