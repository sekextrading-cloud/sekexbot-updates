"""24-hour Radar board (v2.9.0): every setup that could be traded in the next 24 hours, each with a BUY window, a SELL-by time,
a stop, two targets and a hit rate measured on that stock's own history.

It combines the four existing wave families (morning, intraday, after-hours, overnight) with five new setup types that
look at daily structure: OVERSOLD BOUNCE, TREND PULLBACK, RANGE BREAKOUT, VOLUME SURGE and GAP & GO.
Hit rate = how often the window's high reached target 1 on the same stock after the same pattern; stop rate = how often the low
reached the stop (when both happened in one window it counts as the stop, the cautious reading). A past record, not a forecast."""
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

import pandas as pd

from . import morningwave as mw

NY = ZoneInfo("America/New_York")
MIN_N, MIN_SCORE = 8, 55
OPEN, WIN_START, WIN_END = time(9, 30), time(9, 35), time(11, 30)     # the new daily setups are traded in the first two hours

NEW_KINDS = {
    "OVERSOLD_BOUNCE": ("OVERSOLD BOUNCE", "up", "dip"),
    "TREND_PULLBACK": ("TREND PULLBACK", "up", "dip"),
    "RANGE_BREAKOUT": ("RANGE BREAKOUT", "up", "chase"),
    "VOLUME_SURGE": ("VOLUME SURGE", "up", "chase"),
    "GAP_GO": ("GAP & GO", "up", "chase"),
}
WHY = {
    "OVERSOLD_BOUNCE": "Three down closes in a row and the price is well under its 20-day average. Stocks stretched this far down often snap back at the next open.",
    "TREND_PULLBACK": "The 20-day trend is up and the stock has pulled back 1.5-5% from its recent high. Buying the dip in an uptrend is one of the oldest setups.",
    "RANGE_BREAKOUT": "The stock closed above its 10-day high. A close above the recent range often brings follow-through at the next open.",
    "VOLUME_SURGE": "A strong up day on at least 1.8x normal volume. Heavy buying tends to carry into the next morning.",
    "GAP_GO": "The stock is gapping up 1%+ in pre-market. Gaps that hold often keep running during the first two hours of the open.",
}


def next_trading(d, tday_fn, step=1):
    x = d
    for _ in range(10):
        x = x + timedelta(days=step)
        if tday_fn(x):
            return x
    return x + timedelta(days=step)


def _dt(day, t):
    return datetime.combine(day, t).replace(tzinfo=NY)


def _daily(d: pd.DataFrame):
    """Per regular session: o,h,l,c,v, pre-market last close, and the first-two-hours high/low of that same day."""
    d = d.sort_index()
    d.index = pd.to_datetime(d.index).tz_convert(NY)
    t = d.index.time
    reg = d[(t >= OPEN) & (t < time(16, 0))]
    pre = d[(t >= time(4, 0)) & (t < OPEN)]
    pm = {k: float(g["close"].iloc[-1]) for k, g in pre.groupby(pre.index.date)}
    rows = []
    for day, g in reg.groupby(reg.index.date):
        if len(g) < 20:
            continue
        tt = g.index.time
        w = g[(tt >= WIN_START) & (tt < WIN_END)]
        rows.append({"date": day, "o": float(g["open"].iloc[0]), "h": float(g["high"].max()), "l": float(g["low"].min()),
                     "c": float(g["close"].iloc[-1]), "v": float(g["volume"].sum()), "pm": pm.get(day),
                     "wh": float(w["high"].max()) if len(w) else None, "wl": float(w["low"].min()) if len(w) else None})
    return rows


def _flags(rows, i):
    """Which new patterns fire at the close of day i, with a 0-1 strength."""
    out = {}
    if i < 21:
        return out
    c = rows[i]["c"]
    m20 = sum(r["c"] for r in rows[i - 19:i + 1]) / 20
    if rows[i]["c"] < rows[i - 1]["c"] < rows[i - 2]["c"] and c / m20 - 1 <= -0.03:
        out["OVERSOLD_BOUNCE"] = min(1.0, abs(c / m20 - 1) / 0.08)
    m20_5 = sum(r["c"] for r in rows[i - 24:i - 4]) / 20 if i >= 24 else None
    hi5 = max(r["h"] for r in rows[i - 4:i + 1])
    pb = (hi5 - c) / hi5 if hi5 else 0
    if m20_5 and c > m20 and m20 > m20_5 and 0.015 <= pb <= 0.05:
        out["TREND_PULLBACK"] = min(1.0, 0.4 + pb / 0.05 * 0.4)
    hi10 = max(r["h"] for r in rows[i - 10:i])
    if c >= hi10:
        out["RANGE_BREAKOUT"] = min(1.0, 0.5 + (c / hi10 - 1) / 0.01)
    vavg = sum(r["v"] for r in rows[i - 20:i]) / 20
    if vavg and rows[i]["v"] >= 1.8 * vavg and c > rows[i]["o"] and c / rows[i - 1]["c"] - 1 >= 0.008:
        out["VOLUME_SURGE"] = min(1.0, rows[i]["v"] / vavg / 4)
    return out


def _plan(kind, c, atr):
    """Zone / stop / targets around price c (dips buy near the close, chases allow a little room above it)."""
    if NEW_KINDS[kind][2] == "dip":
        lo, hi = c - 0.15 * atr, c + 0.10 * atr
    else:
        lo, hi = c - 0.05 * atr, c + 0.30 * atr
    mid = (lo + hi) / 2
    risk = max(mid - (lo - 0.45 * atr), mw.min_risk(c))
    sl = mid - risk
    return lo, hi, sl, mid + 1.2 * risk, mid + 2.0 * risk


def analyze_new(sym, d, now, tday_fn):
    """List of new-type setups for one symbol (zero to a few)."""
    rows = _daily(d)
    if len(rows) < 30:
        return []
    out = []
    today = now.date()
    done_today = now.time() >= time(16, 5) or rows[-1]["date"] < today
    # ---- daily-structure setups: signal = last COMPLETE session, traded in the next regular session
    i = len(rows) - 1
    if rows[i]["date"] == today and not done_today:
        i -= 1
    flags = _flags(rows, i)
    entry_day = rows[i]["date"]
    sess_day = next_trading(entry_day, tday_fn)
    if _dt(sess_day, WIN_END) <= now:
        sess_day = next_trading(sess_day, tday_fn)
    for kind, strength in flags.items():
        r = _stat(kind, rows, i, strength, lambda j: _next_win(rows, j), sym, sess_day, "daily", now)
        if r:
            out.append(r)
    # ---- gap & go: only when today's pre-market gap exists (4:00-9:30 AM on a trading day)
    if tday_fn(today) and time(4, 0) <= now.time() < OPEN and rows and rows[-1]["date"] < today:
        pm = None
        pre = d[(d.index.date == today)]
        pre = pre[(pre.index.time >= time(4, 0)) & (pre.index.time < OPEN)]
        if len(pre):
            pm = float(pre["close"].iloc[-1])
        pc = rows[-1]["c"]
        if pm and pm / pc - 1 >= 0.01:
            r = _gap_stat(rows, pm, pc, sym, today)
            if r:
                out.append(r)
    return out


def _next_win(rows, j):
    """(entry price ref, window high, window low) of the session after day j; None if there is no next day."""
    if j + 1 >= len(rows) or rows[j + 1]["wh"] is None:
        return None
    return rows[j + 1]["wh"], rows[j + 1]["wl"]


def _atr(rows, i):
    seg = rows[max(0, i - 13):i + 1]
    return sum(r["h"] - r["l"] for r in seg) / len(seg)


def _stat(kind, rows, i, strength, fwd, sym, sess_day, family, now):
    c = rows[i]["c"]
    atr = _atr(rows, i)
    lo, hi, sl, tp1, tp2 = _plan(kind, c, atr)
    if atr <= 0:
        return None
    k1, ks = (tp1 - c) / atr, (c - sl) / atr
    n = hit = stop = hit_only = 0
    for j in range(21, len(rows) - 1):
        if kind not in _flags(rows, j):
            continue
        w = fwd(j)
        if not w:
            continue
        a, cj = _atr(rows, j), rows[j]["c"]
        h = w[0] >= cj + k1 * a
        s = w[1] <= cj - ks * a
        n += 1
        hit += 1 if h else 0
        stop += 1 if s else 0
        hit_only += 1 if (h and not s) else 0
    if n < MIN_N:
        return None
    rate = hit / n
    score = round(100 * (0.55 * rate + 0.25 * min(n, 20) / 20 + 0.20 * min(1.0, max(0.0, strength))))
    if score < MIN_SCORE or rate < 0.5:
        return None
    return _pack(kind, sym, c, lo, hi, sl, tp1, tp2, atr, rate, stop / n, hit_only / n, n, score,
                 _dt(sess_day, WIN_START), _dt(sess_day, time(10, 5)), _dt(sess_day, WIN_END), rows[i]["date"], strength)


def _gap_stat(rows, pm, pc, sym, today):
    n = hit = stop = hit_only = 0
    atr = _atr(rows, len(rows) - 1)
    c = pm
    lo, hi, sl, tp1, tp2 = _plan("GAP_GO", c, atr)
    k1, ks = (tp1 - c) / atr, (c - sl) / atr
    for j in range(1, len(rows)):
        r = rows[j]
        if r["pm"] and r["wh"] is not None and r["pm"] / rows[j - 1]["c"] - 1 >= 0.01:
            a = _atr(rows, j - 1)
            h = r["wh"] >= r["pm"] + k1 * a
            s = r["wl"] <= r["pm"] - ks * a
            n += 1
            hit += 1 if h else 0
            stop += 1 if s else 0
            hit_only += 1 if (h and not s) else 0
    if n < MIN_N:
        return None
    rate = hit / n
    strength = min(1.0, (pm / pc - 1) / 0.04)
    score = round(100 * (0.55 * rate + 0.25 * min(n, 20) / 20 + 0.20 * strength))
    if score < MIN_SCORE or rate < 0.5:
        return None
    return _pack("GAP_GO", sym, c, lo, hi, sl, tp1, tp2, atr, rate, stop / n, hit_only / n, n, score,
                 _dt(today, WIN_START), _dt(today, time(10, 0)), _dt(today, WIN_END), rows[-1]["date"], strength)


def _pack(kind, sym, c, lo, hi, sl, tp1, tp2, atr, rate, stop_rate, hit_only, n, score, e_from, e_to, x_by, bar_date, strength):
    name, side, _ = NEW_KINDS[kind]
    return {"symbol": sym, "side": side, "kind": kind, "name": name, "score": score, "label": "STRONG" if score >= 75 else "WATCH",
            "hit_rate": round(rate * 100), "stop_rate": round(stop_rate * 100), "p_win": round(hit_only * 100), "n": n,
            "move_pct": round((tp1 / c - 1) * 100, 2), "zone": [mw.px_round(lo, c), mw.px_round(hi, c)], "stop": mw.px_round(sl, c),
            "tp1": mw.px_round(tp1, c), "tp2": mw.px_round(tp2, c), "close": mw.px_round(c, c), "atr": round(atr, 4),
            "bar": str(bar_date), "bar_date": str(bar_date), "mode": "DAILY", "window": "first two hours of the open (9:30-11:30 AM)",
            "entry_from": e_from, "entry_to": e_to, "exit_by": x_by, "new": True, "why": WHY[kind]}


def schedule_old(r, now, tday_fn):
    """Entry/exit times for a classic wave setup (mode PRE / REGULAR / AFTER / OVERNIGHT). None when its window is over."""
    cfg = mw.MODES.get(r.get("mode", "PRE"))
    if not cfg:
        return None
    from datetime import date as _d
    bd = _d.fromisoformat(r["bar_date"])
    d0, t0, d1, t1 = cfg["fwd"]
    sd = bd if d0 == 0 else next_trading(bd, tday_fn)
    ed = bd if d1 == 0 else next_trading(bd, tday_fn)
    start, end = _dt(sd, t0), _dt(ed, t1)
    if end <= now:
        return None
    e_from = max(start, now)
    e_to = max(e_from + timedelta(minutes=30), end - timedelta(minutes=60))
    return {"entry_from": e_from, "entry_to": min(e_to, end), "exit_by": end}


def bucket(e_from):
    """Chip bucket for the board filter, by the hour the buy window opens."""
    t = e_from.astimezone(NY).time()
    if t >= time(20, 0) or t < time(4, 0):
        return "NIGHT"
    if t < time(9, 30):
        return "PRE"
    if t < time(11, 30):
        return "OPEN"
    if t < time(16, 0):
        return "MIDDAY"
    return "AFTER"


def fmt(dt, now):
    dt = dt.astimezone(NY)
    day = "Today" if dt.date() == now.date() else "Tomorrow" if dt.date() == now.date() + timedelta(days=1) else dt.strftime("%a %b ") + str(dt.day)
    return f"{day} {dt.strftime('%-I:%M %p')}"
