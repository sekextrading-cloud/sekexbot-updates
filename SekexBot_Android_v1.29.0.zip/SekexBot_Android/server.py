"""Control server + dashboard.

    python server.py            -> real Alpaca (paper by default), dashboard at http://127.0.0.1:8010
    python server.py --sim      -> offline simulated market (no keys needed) to try the dashboard
"""
import argparse
import logging
import os
import sys
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path
from zoneinfo import ZoneInfo

ap = argparse.ArgumentParser()
ap.add_argument("--sim", action="store_true", help="use the offline market simulator")
ap.add_argument("--speed", type=float, default=30, help="sim speed (sim seconds per real second)")
ap.add_argument("--sim-start", default="09:20", help="sim start time HH:MM ET (e.g. 16:30 to try after-hours)")
ap.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"))
ap.add_argument("--port", type=int, default=int(os.getenv("PORT", "8010")))
ARGS = ap.parse_args()
if ARGS.sim:
    os.environ["AUTOBOT_DATA"] = str(Path(__file__).parent / "data_sim")

import uvicorn  # noqa: E402
import pandas as pd  # noqa: E402
from fastapi import FastAPI, HTTPException, Request  # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response  # noqa: E402
from pydantic import BaseModel  # noqa: E402

from autobot import db  # noqa: E402
from autobot.config import DATA_DIR, Settings, api_keys, live_pin, mask, write_env  # noqa: E402
from autobot.engine import Engine, was_running  # noqa: E402
from autobot import android  # noqa: E402
from autobot.alerts import Alerts  # noqa: E402
from autobot.watcher import Watcher  # noqa: E402
from autobot.indicators import ribbon  # noqa: E402
from autobot.analyst import analyze, vision_read  # noqa: E402
from autobot.learner import Learner  # noqa: E402
from autobot import auth  # noqa: E402
from autobot.version import RELEASE_DATE, __version__  # noqa: E402
from autobot.tunnel import Tunnel  # noqa: E402

NY = ZoneInfo("America/New_York")
WEB = Path(__file__).parent / "web"
BASE_DIR_ = Path(__file__).parent
ASSETS = Path(__file__).parent / "assets"
TOKEN = os.getenv("DASH_TOKEN", "")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(sys.stdout),
                              RotatingFileHandler(DATA_DIR / "autobot.log", maxBytes=2_000_000, backupCount=5)])

settings = Settings.load()
learner = Learner()
alerts = Alerts(ARGS.port)
feed = None                     # streaming prices (autobot.stream)
from autobot.events import Events
events = Events()               # earnings calendar + news
guardian = None                 # heartbeat + backups (autobot.guardian), not in the simulator
_interest = {}                  # sym -> last time a dashboard asked for it
engine: Engine | None = None
setup_error = ""


def build_engine():
    global engine, setup_error
    setup_error = ""
    try:
        if ARGS.sim:
            from autobot.sim import SimBroker
            d = datetime.now(NY).date()
            while d.weekday() >= 5:
                d += timedelta(days=1)
            hh, mm = (int(x) for x in ARGS.sim_start.split(":"))
            broker = SimBroker(datetime(d.year, d.month, d.day, hh, mm, tzinfo=NY), speed=ARGS.speed)
            from autobot.stream import SimFeed
            _set_feed(SimFeed(broker))
        else:
            from autobot.broker import AlpacaBroker
            k, s = api_keys(settings.live)
            broker = AlpacaBroker(k, s, paper=not settings.live, feed=settings.data_feed)
            broker.account()  # validate keys now
            if settings.stream_prices:
                from autobot.stream import LiveFeed
                _set_feed(LiveFeed(k, s, settings.data_feed))
                broker.live = feed
            else:
                _set_feed(None)
        engine = Engine(settings, broker, learner)
        engine.alerts = alerts
        if not ARGS.sim:
            events.set_keys(k, s)
            engine.evfilter = events
        if ARGS.sim:
            engine.mode = "SIM"
    except Exception as e:
        engine = None
        setup_error = _friendly(e, settings.live)
        logging.error("Setup error: %s", e)


def _set_feed(f):
    global feed
    if feed is not None and feed is not f:
        feed.stop()
    feed = f


def _feed_loop():
    """Every 2 s: choose what to stream (positions first) and run the fast stop guard every 1 s."""
    import time as _t
    n = 0
    while True:
        _t.sleep(1)
        f, e = feed, engine
        if f is None or e is None:
            continue
        try:
            e.fast_guard(f)
        except Exception as ex:
            logging.debug("fast guard: %s", ex)
        n += 1
        if n % 2:
            continue
        now = _t.time()
        want = list(e.trades) + list((e.positions or {}).keys())
        want += [sym for sym, t0 in sorted(_interest.items(), key=lambda x: -x[1]) if now - t0 < 90]
        want += [w.upper() for w in settings.watchlist] + list(e.universe[:12]) + list(settings.watch_always)
        f.set_symbols(want)


def _friendly(e, live):
    acct = "LIVE" if live else "paper"
    m = str(e)
    low = m.lower()
    if "missing alpaca" in low:
        return f"No {acct} API keys yet — click 🔑 Broker keys to connect your Alpaca account."
    if "unauthorized" in low or "forbidden" in low or "401" in m or "403" in m:
        return f"Alpaca rejected the {acct} API keys — re-enter them in 🔑 Broker keys."
    if "connection" in low or "max retries" in low or "timed out" in low:
        return "Can't reach Alpaca — check your internet connection, then click Reconnect in 🔑 Broker keys."
    return m


build_engine()
import threading as _th  # noqa: E402
_th.Thread(target=_feed_loop, daemon=True, name="feed-loop").start()
watcher = Watcher(lambda: engine, alerts, settings)
if engine and not ARGS.sim and settings.auto_resume and was_running():
    logging.info("SekexBot was trading when it last shut down - resuming automatically")
    engine.start(resumed=True)
app = FastAPI(title="SekexBot", version=__version__)


PUBLIC = {"/login", "/api/login", "/api/version", "/manifest.webmanifest", "/icon.svg", "/icon-192.png", "/icon-512.png",
          "/apple-touch-icon.png", "/favicon.ico"}
LOCAL_ONLY = ("/api/guardian/config", "/api/guardian/restore", "/api/help/fix", "/api/alerts/config", "/api/keys/save", "/api/anthropic_key", "/api/remote/", "/api/reconnect", "/api/app/")


@app.middleware("http")
async def guard(request: Request, call_next):
    path = request.url.path
    if TOKEN and path.startswith("/api") and path not in PUBLIC and not auth.is_remote(request):
        if request.headers.get("x-token") != TOKEN and request.query_params.get("token") != TOKEN:
            return JSONResponse({"detail": "unauthorized"}, status_code=401)
    if auth.is_remote(request) and path not in PUBLIC:
        if not auth.password_set():
            return HTMLResponse("<h3>Remote access is off: set a dashboard password on the device running SekexBot first.</h3>", 403)
        if not auth.valid_session(request.cookies.get(auth.COOKIE)):
            if path.startswith("/api"):
                return JSONResponse({"detail": "Please log in"}, status_code=401)
            return RedirectResponse("/login")
        if any(path.startswith(x) for x in LOCAL_ONLY):
            return JSONResponse({"detail": "For safety, keys and remote-access settings can only be changed "
                                           "on the device running SekexBot."}, status_code=403)
    resp = await call_next(request)
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    return resp


def clean(o):
    """Make numpy scalars JSON-safe."""
    import numpy as np
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.generic):
        return o.item()
    return o


def need_engine() -> Engine:
    if engine is None:
        raise HTTPException(400, setup_error or "Engine not ready")
    return engine


@app.get("/")
def index():
    return FileResponse(WEB / "dashboard.html", headers={"Cache-Control": "no-store"})


# ---------------- phone / remote access ----------------
tunnel = Tunnel(ARGS.port)


@app.get("/api/version")
def version():
    return {"version": __version__, "release_date": RELEASE_DATE}


@app.get("/login")
def login_page():
    return FileResponse(WEB / "login.html")


class LoginReq(BaseModel):
    password: str


@app.post("/api/login")
def login(r: LoginReq, request: Request):
    ip = auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many attempts. Wait 15 minutes.")
    if not auth.password_set() or not auth.check_password(r.password):
        auth.record_fail(ip)
        raise HTTPException(401, "Wrong password")
    logging.info("Remote login from %s", ip)
    resp = JSONResponse({"ok": True})
    resp.set_cookie(auth.COOKIE, auth.make_session(), max_age=auth.SESSION_DAYS * 86400, httponly=True,
                    secure=request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
                    or bool(request.headers.get("cf-ray")), samesite="lax")
    return resp


@app.post("/api/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE)
    return resp


@app.get("/manifest.webmanifest")
def manifest():
    return JSONResponse({"name": "SekexBot", "short_name": "SekexBot", "start_url": "/", "display": "standalone",
                         "background_color": "#07090c", "theme_color": "#07090c",
                         "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png"},
                                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png"},
                                   {"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]},
                        media_type="application/manifest+json")


@app.get("/icon.svg")
def icon_svg():
    return FileResponse(ASSETS / "sekexbot-icon.svg", media_type="image/svg+xml")


@app.get("/icon-192.png")
def icon192():
    return FileResponse(ASSETS / "icon-192.png")


@app.get("/icon-512.png")
def icon512():
    return FileResponse(ASSETS / "icon-512.png")


@app.get("/apple-touch-icon.png")
def apple_icon():
    return FileResponse(ASSETS / "icon-180.png")


@app.get("/api/remote/status")
def remote_status():
    st = tunnel.status()
    st.update({"password_set": auth.password_set(), "token_saved": bool(os.getenv("CF_TUNNEL_TOKEN")),
               "hostname": os.getenv("CF_HOSTNAME", ""), "autostart": os.getenv("REMOTE_AUTOSTART", "") == "1"})
    return st


class PwReq(BaseModel):
    password: str


@app.post("/api/remote/password")
def remote_password(r: PwReq):
    if len(r.password) < 8:
        raise HTTPException(400, "Use at least 8 characters")
    auth.set_password(r.password)
    return {"ok": True}


class TunnelReq(BaseModel):
    mode: str = "quick"          # quick | token
    token: str = ""
    hostname: str = ""
    autostart: bool | None = None


@app.post("/api/remote/start")
def remote_start(r: TunnelReq):
    if not auth.password_set():
        raise HTTPException(400, "Set a dashboard password first — anyone with the link would otherwise control your bot.")
    vals = {}
    if r.mode == "token":
        tok = r.token.strip() or os.getenv("CF_TUNNEL_TOKEN", "")
        tok = tok.split("--token")[-1].strip().split()[-1] if tok else ""    # accept the whole install command too
        if len(tok) < 50:
            raise HTTPException(400, "Paste the tunnel token (or the whole 'cloudflared service install ...' command).")
        host = r.hostname.strip().replace("https://", "").strip("/") or os.getenv("CF_HOSTNAME", "")
        vals.update({"CF_TUNNEL_TOKEN": tok, "CF_HOSTNAME": host})
    if r.autostart is not None:
        vals["REMOTE_AUTOSTART"] = "1" if r.autostart else "0"
        vals["REMOTE_MODE"] = r.mode
    if vals:
        write_env(vals)
    tunnel.start(r.mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))
    return {"ok": True}


@app.post("/api/remote/stop")
def remote_stop():
    tunnel.stop()
    return {"ok": True}


@app.get("/api/qr")
def qr(url: str):
    import qrcode
    import qrcode.image.svg
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    return Response(img.to_string(), media_type="image/svg+xml")


@app.on_event("startup")
def _autostart_tunnel():
    if os.getenv("REMOTE_AUTOSTART") == "1" and auth.password_set():
        mode = os.getenv("REMOTE_MODE", "token" if os.getenv("CF_TUNNEL_TOKEN") else "quick")
        tunnel.start(mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))


@app.on_event("shutdown")
def _stop_tunnel():
    tunnel.stop()


@app.get("/api/status")
def status(request: Request):
    base = {"version": __version__, "release_date": RELEASE_DATE, "settings": {"daily_max_loss": settings.daily_max_loss, "live": settings.live,
                         "allow_shorts": settings.allow_shorts, "trade_all_flips": settings.trade_all_flips, "data_feed": settings.data_feed,
                         "ext_premarket": settings.ext_premarket, "ext_afterhours": settings.ext_afterhours,
                         "ext_overnight": settings.ext_overnight, "watchlist": settings.watchlist,
                         "auto_resume": settings.auto_resume, "stream_prices": settings.stream_prices,
                         "scale_out": settings.scale_out, "tod_filter": settings.tod_filter, "scalp_mode": settings.scalp_mode,
                         "aggressive_scalp": settings.aggressive_scalp,
                         "cooloff_streak": settings.cooloff_streak, "cooloff_symbol": settings.cooloff_symbol,
                         "confirm_trades": settings.confirm_trades},
            "ai_key_set": bool(os.getenv("ANTHROPIC_API_KEY")),
            "remote": auth.is_remote(request), "tunnel": {"state": tunnel.state, "url": tunnel.url},
            "sim": ARGS.sim, "setup_error": setup_error, "edition": android.EDITION,
            "device": android.health(), "update": _upd["info"], "update_prefs": _upd_prefs(),
            "stream": feed.info() if feed else {"status": "off", "error": "", "symbols": 0, "updates": 0}, "live_pin_set": bool(live_pin()),
            "leaderboard": learner.leaderboard()}
    if engine:
        engine.refresh_account(max_age=20)
        base.update(engine.status())
    return clean(base)


@app.post("/api/start")
def start():
    need_engine().start()
    return {"ok": True}


class StopReq(BaseModel):
    flatten: bool = False


@app.post("/api/stop")
def stop(r: StopReq):
    need_engine().stop(flatten=r.flatten)
    return {"ok": True}


@app.post("/api/scan")
def scan_now():
    e = need_engine()
    e._scan()
    try:
        e.refresh_setups()
    except Exception as ex:
        logging.warning("setups: %s", ex)
    return {"ok": True, "count": len(e.scan_info), "setups": len(getattr(e, "setups", []))}


@app.post("/api/cooloff/clear")
def cooloff_clear():
    need_engine().end_cooloff()
    return {"ok": True}


@app.post("/api/flatten")
def flatten():
    e = need_engine()
    e.flatten("manual flatten")
    e.event("Manual flatten of bot positions")
    return {"ok": True}


class LimitReq(BaseModel):
    daily_max_loss: float


@app.post("/api/limit")
def set_limit(r: LimitReq):
    if r.daily_max_loss <= 0:
        raise HTTPException(400, "Daily limit must be > 0")
    settings.daily_max_loss = float(r.daily_max_loss)
    settings.save()
    if engine:
        engine.event(f"Daily max loss set to ${settings.daily_max_loss:,.2f}")
    return {"ok": True}


class OptsReq(BaseModel):
    allow_shorts: bool | None = None
    data_feed: str | None = None
    ext_premarket: bool | None = None
    ext_afterhours: bool | None = None
    ext_overnight: bool | None = None
    auto_resume: bool | None = None
    stream_prices: bool | None = None
    scale_out: bool | None = None
    tod_filter: bool | None = None
    scalp_mode: bool | None = None
    aggressive_scalp: bool | None = None
    cooloff_streak: bool | None = None
    cooloff_symbol: bool | None = None
    confirm_trades: bool | None = None
    trade_all_flips: bool | None = None


@app.post("/api/options")
def options(r: OptsReq):
    for k in ("scale_out", "tod_filter", "scalp_mode", "aggressive_scalp", "cooloff_streak", "cooloff_symbol", "confirm_trades",
              "trade_all_flips", "allow_shorts"):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, k, v)
            if engine and k == "tod_filter" and hasattr(engine, "_tod"):
                del engine._tod
    settings.save()
    if r.allow_shorts is not None:
        settings.allow_shorts = r.allow_shorts
    if r.auto_resume is not None:
        settings.auto_resume = r.auto_resume
    if r.stream_prices is not None and r.stream_prices != settings.stream_prices:
        settings.stream_prices = r.stream_prices
        settings.save()
        if not ARGS.sim and not (engine and engine.running):
            build_engine()
        elif not ARGS.sim:
            if r.stream_prices and engine:
                from autobot.stream import LiveFeed
                k, sec = api_keys(settings.live)
                _set_feed(LiveFeed(k, sec, settings.data_feed))
                engine.broker.live = feed
            elif engine:
                engine.broker.live = None
                _set_feed(None)
    for k in ("ext_premarket", "ext_afterhours", "ext_overnight"):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, k, v)
            if engine:
                engine.event(f"{k.replace('ext_', '').replace('afterhours', 'after-hours')} trading "
                             f"{'ON' if v else 'OFF'}")
    if r.data_feed in ("iex", "sip") and r.data_feed != settings.data_feed:
        if r.data_feed == "sip" and not ARGS.sim:          # make sure the account really has SIP first
            try:
                from alpaca.data.enums import DataFeed
                from alpaca.data.historical import StockHistoricalDataClient
                from alpaca.data.requests import StockLatestQuoteRequest
                k, sec = api_keys(settings.live)
                StockHistoricalDataClient(k, sec).get_stock_latest_quote(
                    StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
            except Exception as ex:
                raise HTTPException(400, "Alpaca says this account can't use SIP data yet "
                                         f"({str(ex)[:120]}). It stays on IEX.")
        was = bool(engine and engine.running)
        if was:
            engine.stop()                  # positions keep their server-side stops
        settings.data_feed = r.data_feed
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        if engine:
            engine.event(f"Data feed switched to {r.data_feed.upper()}" + (" (bot restarted)" if was else ""))
    settings.save()
    return {"ok": True}


class ModeReq(BaseModel):
    live: bool
    pin: str = ""
    restart: bool = False


@app.post("/api/mode")
def mode(r: ModeReq, request: Request):
    """Switch PAPER <-> LIVE. Live needs the PIN and working live keys; if the auto-trader is running it is
    stopped (positions keep their server-side stops), switched, and started again in the new mode."""
    if ARGS.sim:
        raise HTTPException(400, "The simulator has no live mode.")
    if r.live == settings.live:
        return {"ok": True, "live": settings.live}
    was_running = bool(engine and engine.running)
    if was_running and not r.restart:
        raise HTTPException(409, "RUNNING")
    if r.live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(400, "No Live PIN set yet. Add one in ⚙ → Broker keys → Live.")
        if r.pin != live_pin():
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
        k, sec = api_keys(True)
        if not (k and sec):
            raise HTTPException(400, "No LIVE keys saved yet. Add them in ⚙ → Broker keys → Live.")
        test = _test_alpaca(k, sec, paper=False)
        if not test["ok"]:
            raise HTTPException(400, test["error"])
    if was_running:
        engine.stop()
    settings.live = r.live
    settings.save()
    build_engine()
    if engine is None:            # could not connect in the new mode: go back
        err = setup_error
        settings.live = not r.live
        settings.save()
        build_engine()
        raise HTTPException(400, f"Couldn't connect in {'LIVE' if r.live else 'PAPER'} mode: {err}")
    engine.event(f"Switched to {'LIVE — real money' if r.live else 'PAPER'} trading", "warning" if r.live else "info")
    alerts.send("system", "🔴 LIVE trading ON — real money" if r.live else "Back to PAPER trading",
                "Orders now use your real-money account." if r.live else "Orders now use the paper account.")
    if was_running:
        engine.start(resumed=True)
    return {"ok": True, "live": settings.live, "restarted": was_running}


@app.post("/api/reconnect")
def reconnect():
    if engine and engine.running:
        raise HTTPException(400, "Stop the bot first")
    build_engine()
    return {"ok": engine is not None, "error": setup_error}


@app.get("/api/trades")
def trades(limit: int = 200):
    return db.recent(limit)


@app.get("/api/daily")
def daily():
    return db.daily_summary()


@app.post("/api/learner/reset")
def reset_learner():
    learner.reset()
    return {"ok": True}


@app.get("/api/chart/{symbol}")
def chart(symbol: str, tf: int = 3):
    e = need_engine()
    sym = symbol.upper()
    df, as_of = None, "live"
    try:
        df = e.broker.chart_bars(sym)
    except Exception:
        df = None
    if df is None or len(df) < 20:          # fall back to the old sources
        df = e.raw.get(sym)
        if df is None or len(df) < 20:
            try:
                df, as_of = e.broker.analysis_bars(sym)
            except Exception:
                df = None
    if df is not None and len(df):
        age = (e.broker.now() - df.index[-1]).total_seconds()
        if age > 300:
            as_of = "last trade " + df.index[-1].strftime("%a %b %d %I:%M %p").replace(" 0", " ")
    if df is None or df.empty:
        return {"bars": [], "as_of": ""}
    tf = tf if tf in (1, 3, 5, 15) else 3
    from autobot.indicators import vwap as _vwap
    vw = _vwap(df)
    h = ribbon(df, lines=True, tf=f"{tf}min").tail(400)
    cols = ["open", "high", "low", "close", "fast", "slow", "band_hi", "band_lo", "state",
            "e10", "e12", "e14", "e16", "e18"]
    out = []
    for ts, row in h.iterrows():
        d = {"t": ts.strftime("%H:%M"), "d": ts.strftime("%a %b %d")}
        hm = ts.hour * 60 + ts.minute
        d["x"] = 0 if 570 <= hm < 960 else (1 if 240 <= hm < 1200 else 2)   # 0 regular, 1 pre/after, 2 overnight
        d.update({c: (None if row[c] != row[c] else round(float(row[c]), 4)) for c in cols})
        d["v"] = int(row["volume"]) if row["volume"] == row["volume"] else 0
        end = ts + pd.Timedelta(minutes=tf)
        w = vw[vw.index < end]
        d["vwap"] = round(float(w.iloc[-1]), 4) if len(w) else None
        out.append(d)
    trades_ = [t for t in db.recent(300) if t["symbol"] == sym and t["day"] == e.day]
    return clean({"bars": out, "trades": trades_, "as_of": as_of, "tf": tf})


@app.get("/api/analyze/{symbol}")
def analyze_symbol(symbol: str):
    if engine is None:
        return {"error": "The live chart read needs your Alpaca connection: " + (setup_error or "not connected") +
                         " (The screenshot reader works without it.)"}
    e = engine
    sym = symbol.upper().strip()
    if not sym.replace(".", "").isalpha():
        return {"error": "Enter a valid ticker, e.g. NVDA"}
    df, as_of = e.raw.get(sym), "live"
    try:
        if df is None or len(df) < 20:
            df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        return {"error": f"Couldn't load bars for {sym}: {str(ex)[:200]}"}
    if df is None or len(df) < 20:
        return {"error": f"No recent 1-minute data for {sym}. Check the ticker is a US stock/ETF on Alpaca."}
    try:
        res = analyze(sym, df, e.bias, learner)
    except Exception as ex:
        logging.exception("analyze failed")
        return {"error": f"Analysis failed for {sym}: {str(ex)[:200]}"}
    res["as_of"] = as_of
    return clean(res)


class VisionReq(BaseModel):
    image_b64: str
    media_type: str = "image/png"
    question: str = ""


@app.post("/api/vision")
def vision(r: VisionReq):
    if len(r.image_b64) > 7_000_000:
        raise HTTPException(400, "Image too large (max ~5 MB)")
    try:
        plan = vision_read(r.image_b64, r.media_type, r.question)
    except Exception as ex:
        logging.exception("vision failed")
        return {"error": f"Couldn't reach Claude: {str(ex)[:200]}"}
    if plan.get("error"):
        return plan
    sym = (plan.get("symbol") or "").upper().strip()
    if sym and engine and sym.replace(".", "").isalpha():
        try:   # add the live price so you can compare with the screenshot
            q = engine.broker.quotes([sym], engine.session.name if engine.session else "REGULAR").get(sym)
            if q:
                plan["live_price"] = round((q[0] + q[1]) / 2, 2)
        except Exception:
            pass
        plan["on_watchlist"] = sym in [w.upper() for w in settings.watchlist]
    return clean(plan)


class KeyReq(BaseModel):
    key: str


@app.post("/api/anthropic_key")
def set_key(r: KeyReq):
    k = r.key.strip()
    if not k.startswith("sk-"):
        raise HTTPException(400, "That doesn't look like a Claude API key (should start with sk-)")
    write_env({"ANTHROPIC_API_KEY": k})
    return {"ok": True}


# ---------------- broker keys (GUI setup) ----------------
# Keys are written to the local .env file and never sent back to the browser (only a masked hint).
def _test_alpaca(key: str, secret: str, paper: bool) -> dict:
    from alpaca.trading.client import TradingClient
    try:
        a = TradingClient(key, secret, paper=paper).get_account()
        return {"ok": True, "account": str(a.account_number), "equity": float(a.equity),
                "buying_power": float(a.buying_power), "status": str(getattr(a.status, "value", a.status))}
    except Exception as e:
        msg = _friendly(e, not paper)
        if "rejected" in msg:
            msg = (f"Alpaca rejected these keys. Check you copied the full Key ID and Secret from your "
                   f"{'LIVE' if not paper else 'Paper'} account (regenerate them if the secret was lost).")
        return {"ok": False, "error": msg}


@app.get("/api/keys")
def keys_status():
    pk, ps = api_keys(False)
    lk, ls = api_keys(True)
    return {"paper": {"set": bool(pk and ps), "hint": mask(pk)},
            "live": {"set": bool(lk and ls), "hint": mask(lk)},
            "live_pin_set": bool(live_pin()), "anthropic_set": bool(os.getenv("ANTHROPIC_API_KEY")),
            "anthropic_hint": mask(os.getenv("ANTHROPIC_API_KEY", "")),
            "mode": "live" if settings.live else "paper", "connected": engine is not None,
            "error": setup_error, "sim": ARGS.sim}


class KeyTestReq(BaseModel):
    account: str = "paper"      # paper | live
    key: str = ""
    secret: str = ""


def _clean_key(v: str) -> str:
    return v.strip().strip('"').strip("'").replace(" ", "")


@app.post("/api/keys/test")
def keys_test(r: KeyTestReq):
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    if not k or not s_:          # test the saved keys
        k, s_ = api_keys(not paper)
    if not k or not s_:
        raise HTTPException(400, "Enter the API Key ID and Secret first")
    return _test_alpaca(k, s_, paper)


class KeySaveReq(BaseModel):
    account: str = "paper"
    key: str = ""
    secret: str = ""
    live_pin: str = ""


@app.post("/api/keys/save")
def keys_save(r: KeySaveReq):
    if engine and engine.running:
        raise HTTPException(400, "Stop the bot before changing broker keys")
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    vals = {}
    if k or s_:
        if not (k and s_):
            raise HTTPException(400, "Enter both the API Key ID and the Secret")
        if paper and k.startswith("AK"):
            raise HTTPException(400, "That's a LIVE key (starts with AK). Paper keys start with PK — "
                                     "switch Alpaca's dashboard to Paper Trading and generate keys there.")
        if not paper and k.startswith("PK"):
            raise HTTPException(400, "That's a PAPER key (starts with PK). Live keys start with AK.")
        test = _test_alpaca(k, s_, paper)
        if not test["ok"] and not ARGS.sim:
            return {"ok": False, "error": test["error"]}
        pre = "ALPACA_PAPER" if paper else "ALPACA_LIVE"
        vals[f"{pre}_KEY"], vals[f"{pre}_SECRET"] = k, s_
    if r.live_pin:
        if len(r.live_pin) < 4:
            raise HTTPException(400, "Use a PIN of at least 4 characters")
        vals["LIVE_PIN"] = r.live_pin.strip()
    if not vals:
        raise HTTPException(400, "Nothing to save")
    write_env(vals)
    if not ARGS.sim and (paper != settings.live):   # keys for the active mode changed -> reconnect
        build_engine()
    return {"ok": True, "connected": engine is not None, "error": setup_error}


# ---------------- manual trading: your own Buy / Sell / Close ----------------
# Manual positions are yours: the bot never enters, manages or flattens them at the close.
# (The daily-loss halt closes every LOSING position in the account, manual ones included; winners stay open.)
def _session_name(e):
    from autobot.sessions import current_session
    try:
        sess = current_session(e.broker.trading_day, e.broker.now())
        return sess.name if sess else "CLOSED"
    except Exception:
        return "CLOSED"


def _price(e, sym, sess):
    """Always returns something to price an order with (live quote, last trade, or last close)."""
    try:
        return e.broker.price_info(sym, sess)
    except Exception:
        return {"bid": None, "ask": None, "last": None, "prev_close": None, "ts": None, "source": ""}


def _quote(e, sym, sess):
    p = _price(e, sym, sess)
    bid, ask, last = p.get("bid"), p.get("ask"), p.get("last")
    return (bid or last), (ask or last)


def _valid_sym(sym):
    sym = (sym or "").upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker, e.g. AAPL")
    return sym


@app.get("/api/manual/quote/{symbol}")
def manual_quote(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    sess = _session_name(e)
    pr = _price(e, sym, sess)
    last, pc = pr.get("last"), pr.get("prev_close")
    if last is None and not pr.get("bid"):
        raise HTTPException(404, f"No price found for {sym}. Check the ticker is a US stock or ETF on Alpaca.")
    bid, ask = pr.get("bid") or last, pr.get("ask") or last
    ts = pr.get("ts")
    live = sess != "CLOSED" and bool(pr.get("bid")) and bool(ts) and (e.broker.now() - ts).total_seconds() < 900
    pos = e.broker.positions().get(sym)
    return clean({"symbol": sym, "bid": bid, "ask": ask, "last": last or (bid + ask) / 2, "session": sess,
                  "prev_close": pc, "change": (last - pc) if last and pc else None,
                  "change_pct": ((last / pc - 1) * 100) if last and pc else None,
                  "live": live, "source": pr.get("source", ""), "as_of": ts.strftime("%a %b %d %I:%M %p").replace(" 0", " ") if ts else "",
                  "has_book": bool(pr.get("bid")),
                  "position": pos["qty"] if pos else 0, "avg_entry": pos["avg_entry"] if pos else None,
                  "bot": sym in e.trades, "buying_power": (e.acct or e.broker.account()).get("buying_power")})


@app.get("/api/manual/levels/{symbol}")
def manual_levels(symbol: str, side: str = "buy", entry: float | None = None):
    """Suggested stop-loss / take-profit (Scalp / Day / Swing) for a manual order."""
    from autobot.levels import suggest
    e = need_engine()
    sym = _valid_sym(symbol)
    side = "sell" if side.lower() == "sell" else "buy"
    try:
        df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        raise HTTPException(400, f"Couldn't load bars for {sym}: {str(ex)[:160]}")
    if df is None or len(df) < 20:
        raise HTTPException(400, f"Not enough recent data for {sym} to suggest levels yet.")
    if not entry:
        sess = _session_name(e)
        pr = _price(e, sym, sess)
        if sess == "REGULAR" and pr.get("bid"):
            entry = pr["ask"] if side == "buy" else pr["bid"]
        else:                                   # closed / extended: Alpaca prices brackets off the last trade
            entry = pr.get("last") or float(df["close"].iloc[-1])
    daily = None
    if hasattr(e.broker, "_daily_stats"):
        try:
            daily = e.broker._daily_stats([sym]).get(sym)
        except Exception:
            daily = None
    bias = "NEUTRAL"
    try:
        bias = analyze(sym, df, e.bias, learner).get("bias", "NEUTRAL")
    except Exception:
        pass
    acct = e.acct or {}
    res = suggest(side, float(entry), df, daily, bias, settings.daily_max_loss, settings.risk_per_trade_frac,
                  acct.get("buying_power", 0))
    res.update(symbol=sym, as_of=as_of)
    return clean(res)


def _friendly_reject(msg: str) -> str:
    """Turn Alpaca's JSON errors into plain words (the raw text stays in the log)."""
    import json as _j
    logging.warning("Order rejected: %s", msg)
    d = {}
    try:
        d = _j.loads(msg[msg.index("{"):])
        m = d.get("message", msg)
    except Exception:
        m = msg
    low = m.lower()
    if "stop_loss.stop_price must be" in low:
        return f"Stop-loss is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the stop."
    if "take_profit.limit_price must be" in low:
        return f"Take-profit is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the target."
    if "insufficient buying power" in low:
        return "Not enough buying power for this order. Lower the quantity."
    if "not shortable" in low or "cannot be sold short" in low:
        return "This stock can't be shorted right now."
    if "extended hours" in low:
        return "This order type isn't allowed in extended hours. Use a limit order."
    if "margin call" in low or "intraday" in low:
        return "Not enough intraday buying power (Alpaca's intraday margin rules). Use a smaller size or close something first."
    if "pattern day" in low or "day trad" in low:
        return "Blocked by a broker trading restriction. (The old $25k day-trade rule ended June 4, 2026; if you still see this, contact Alpaca.)"
    return "Alpaca rejected the order: " + m[:220]


class ManualOrder(BaseModel):
    symbol: str
    side: str                       # buy | sell
    qty: float = 0
    dollars: float = 0              # alternative to qty: spend about this much
    order_type: str = "market"      # market | limit | stop | stop_limit | trailing_stop
    limit_price: float | None = None
    stop_price: float | None = None     # trigger for stop / stop_limit
    trail_percent: float | None = None  # trailing_stop: trail by % ...
    trail_price: float | None = None    # ... or by $
    tif: str = "day"                # day | gtc | ioc | fok | opg | cls
    session: str = "auto"           # regular | extended | 24h | auto (= the session open now)
    stop: float | None = None       # optional stop-loss leg (regular hours, market/limit)
    target: float | None = None     # optional take-profit leg (regular hours, market/limit)
    confirm_short: bool = False


SESSION_LABEL = {"regular": "Market hours", "extended": "Extended hours", "24h": "24 Hour Market"}
TIF_LABEL = {"day": "Good for day", "gtc": "Good 'til canceled", "ioc": "Immediate or cancel",
             "fok": "Fill or kill", "opg": "At the open", "cls": "At the close"}


@app.post("/api/manual/order")
def manual_order(r: ManualOrder):
    import math
    import uuid
    e = need_engine()
    sym, side = _valid_sym(r.symbol), r.side.lower()
    ot, tif = r.order_type.lower(), r.tif.lower()
    if side not in ("buy", "sell"):
        raise HTTPException(400, "Side must be buy or sell")
    if ot not in ("market", "limit", "stop", "stop_limit", "trailing_stop"):
        raise HTTPException(400, "Unknown order type")
    if tif not in TIF_LABEL:
        raise HTTPException(400, "Unknown time in force")
    if sym in e.trades:
        raise HTTPException(409, f"The bot is managing {sym}. Close it first (Positions → Close) or wait for the bot's exit.")
    now_sess = _session_name(e)
    sess = r.session.lower()
    if sess == "auto":
        sess = {"PRE": "extended", "AFTER": "extended", "OVERNIGHT": "24h"}.get(now_sess, "regular")
    if sess not in SESSION_LABEL:
        raise HTTPException(400, "Unknown trading session")
    ext = sess != "regular"

    # ---- the rules Alpaca applies, checked here first so the message is clear ----
    if ext and ot != "limit":
        raise HTTPException(400, f"{SESSION_LABEL[sess]} accepts limit orders only. Switch the order type to Limit.")
    if ext and tif not in ("day", "gtc"):
        raise HTTPException(400, f"{SESSION_LABEL[sess]} orders must be Good for day or Good 'til canceled.")
    if tif in ("opg", "cls") and ot not in ("market", "limit"):
        raise HTTPException(400, "At the open / At the close work with market or limit orders only.")
    if ot == "trailing_stop" and tif not in ("day", "gtc"):
        raise HTTPException(400, "Trailing stops must be Good for day or Good 'til canceled.")
    legs = bool(r.stop or r.target)
    if legs and (ext or ot not in ("market", "limit") or tif not in ("day", "gtc")):
        raise HTTPException(400, "Stop-loss / take-profit can only be attached to a market or limit order, "
                                 "in Market hours, Good for day or Good 'til canceled.")

    bid, ask = _quote(e, sym, now_sess)
    ref = ask if side == "buy" else bid
    if ot in ("limit", "stop_limit"):
        if not r.limit_price or r.limit_price <= 0:
            raise HTTPException(400, "Enter a limit price")
        ref = r.limit_price
    if ot in ("stop", "stop_limit"):
        if not r.stop_price or r.stop_price <= 0:
            raise HTTPException(400, "Enter a stop price")
        ref = ref if ot == "stop_limit" else r.stop_price
    if ot == "trailing_stop":
        if not (r.trail_percent or r.trail_price) or (r.trail_percent or 0) < 0 or (r.trail_price or 0) < 0:
            raise HTTPException(400, "Enter a trail amount (% or $)")
    if not ref:
        raise HTTPException(400, f"No price available for {sym} right now")
    qty = math.floor(r.qty) if r.qty else (math.floor(r.dollars / ref) if r.dollars else 0)
    if qty < 1:
        raise HTTPException(400, "Enter at least 1 share (or a dollar amount worth at least 1 share)")

    held = (e.broker.positions().get(sym) or {}).get("qty", 0)
    if side == "sell" and held < qty and not r.confirm_short:
        raise HTTPException(409, "SHORT_CONFIRM")
    d = 1 if side == "buy" else -1
    if r.stop and (ref - r.stop) * d <= 0:
        raise HTTPException(400, f"Stop-loss must be {'below' if d > 0 else 'above'} the entry price ({ref:.2f})")
    if r.target and (r.target - ref) * d <= 0:
        raise HTTPException(400, f"Take-profit must be {'above' if d > 0 else 'below'} the entry price ({ref:.2f})")

    notes = []
    open_now = {"regular": now_sess == "REGULAR", "extended": now_sess in ("PRE", "REGULAR", "AFTER"),
                "24h": now_sess != "CLOSED"}[sess]
    if sess == "24h" and tif == "day" and now_sess != "OVERNIGHT":
        notes.append("Good for day ends at 8 PM ET today. Choose Good 'til canceled to keep it working overnight.")
    if not open_now and tif not in ("opg", "cls"):
        notes.append(f"{SESSION_LABEL[sess]} isn't open right now: the order waits and works from the start of the next session.")
    try:
        oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=r.stop or None,
                                    target=r.target or None, extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                    stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                    trail_price=r.trail_price or None, tif=tif)
    except Exception as ex:
        import re
        msg = str(ex)
        m = re.search(r'"base_price"\s*:\s*"?([0-9.]+)', msg)
        if m and (r.stop or r.target):
            # Alpaca checks the stop/target against its reference price (the last trade while closed).
            # Keep the same distances, re-anchor them on that price, and try once more.
            base = float(m.group(1))
            ref = r.limit_price if (ot == "limit" and r.limit_price) else base
            shift = base - (bid if side == "sell" else ask) if ot != "limit" else 0
            new_stop = round(r.stop + shift, 2) if r.stop else None
            new_tgt = round(r.target + shift, 2) if r.target else None
            if new_stop and (ref - new_stop) * (1 if side == "buy" else -1) < 0.01:
                new_stop = round(ref - (0.01 if side == "buy" else -0.01) - abs(r.stop - (ask if side == "buy" else bid)) * (1 if side == "buy" else -1), 2)
            try:
                oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=new_stop, target=new_tgt,
                                            extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                            stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                            trail_price=r.trail_price or None, tif=tif)
                notes.append(f"Auto-fixed: Alpaca prices this order from {base:.2f}, so the stop-loss / take-profit were "
                             f"moved by the same amount to {new_stop or '—'} / {new_tgt or '—'}.")
                r.stop, r.target = new_stop, new_tgt
            except Exception as ex2:
                raise HTTPException(400, _friendly_reject(str(ex2)))
        else:
            raise HTTPException(400, _friendly_reject(msg))
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    px = {"market": "market", "limit": f"limit {r.limit_price:.2f}" if r.limit_price else "limit",
          "stop": f"stop {r.stop_price}", "stop_limit": f"stop {r.stop_price} limit {r.limit_price}",
          "trailing_stop": f"trailing {str(r.trail_percent) + '%' if r.trail_percent else '$' + str(r.trail_price)}"}[ot]
    extra = " ".join(x for x in (f"SL {r.stop:.2f}" if r.stop else "", f"TP {r.target:.2f}" if r.target else "") if x)
    e.event(f"MANUAL {side.upper()} {qty} {sym} {px} · {TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}")
    e.alert("manual", f"You: {side.upper()} {qty} {sym} {px}", f"{TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}",
            symbol=sym, close_btn=True)
    return {"ok": True, "order_id": oid, "qty": qty, "notes": notes}


class ManualClose(BaseModel):
    symbol: str
    pct: float = 100


@app.post("/api/manual/close")
def manual_close(r: ManualClose):
    import math
    import uuid
    e = need_engine()
    sym = _valid_sym(r.symbol)
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    q = abs(pos["qty"])
    qty = q if r.pct >= 100 else max(1, math.floor(q * r.pct / 100))
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    t = e.trades.get(sym)
    if t:                                   # a bot trade: close it the bot's way so the journal/learner stay right
        if qty < q:
            raise HTTPException(400, "Bot trades can only be closed in full")
        t.note = "manual close"
        if t.ext and ext:
            bid, _ = _quote(e, sym, sess)
            e._ext_exit(t, "manual close", bid or t.last_price or t.entry)
        else:
            e.broker.close_position(sym)
        e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy})")
        return {"ok": True, "qty": qty, "notes": []}
    notes = []
    try:
        if ext:
            if pos["qty"] < 0:
                raise HTTPException(400, "Covering a short needs regular hours")
            e.broker.cancel_symbol_orders(sym)
            bid, _ = _quote(e, sym, sess)
            if not bid:
                raise HTTPException(400, f"No {sym} quote right now")
            px = round(bid * 0.997, 2)
            e.broker.manual_order(sym, "sell", qty, "limit", limit_price=px, extended=True,
                                  client_id=f"manx-{uuid.uuid4().hex[:12]}")
            notes.append(f"Extended hours: sent a limit sell at {px:.2f}. If it doesn't fill, press Close again.")
        else:
            e.broker.close_qty(sym, qty)
            if qty < q:
                notes.append("Any stop-loss / take-profit on this position was cancelled - set new ones if you want them.")
            if sess == "CLOSED":
                notes.append("The market is closed: it will close at the open.")
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(400, f"Alpaca rejected the close: {str(ex)[:220]}")
    e.event(f"MANUAL CLOSE {qty:g} {sym}" + (" (partial)" if qty < q else ""))
    return {"ok": True, "qty": qty, "notes": notes}


@app.get("/api/manual/book")
def manual_book():
    """Every position and open order in the account, marked bot or manual."""
    e = need_engine()
    pos = e.broker.positions()
    try:
        orders = e.broker.open_orders()
    except Exception:
        orders = []
    bot_ids = {t.order_id for t in e.trades.values()} | {t.tp_order_id for t in e.trades.values()} | \
              {t.exit_order_id for t in e.trades.values()}
    rows = [{"symbol": s, "qty": p["qty"], "avg": p["avg_entry"], "price": p["price"], "upl": p["upl"],
             "upl_pct": (p["price"] / p["avg_entry"] - 1) * 100 * (1 if p["qty"] > 0 else -1) if p["avg_entry"] else 0,
             "bot": s in e.trades} for s, p in sorted(pos.items())]
    for o in orders:
        o["bot"] = o["id"] in bot_ids or o["client_id"].startswith(("ab-", "abx-", "abt-", "abe-")) or o["symbol"] in e.trades
    return clean({"positions": rows, "orders": orders, "session": _session_name(e), "mode": e.mode})


class CancelReq(BaseModel):
    order_id: str


@app.post("/api/manual/cancel")
def manual_cancel(r: CancelReq):
    e = need_engine()
    e.broker.cancel(r.order_id)
    e.event("MANUAL cancel order " + r.order_id[:8])
    return {"ok": True}


# ---------------- in-app updates (Android edition) ----------------
# Two ways, both from the dashboard on the phone itself (never from Remote access):
#   1. pick a SekexBot_Android_vX.Y.Z.zip file on the phone -> uploaded here -> installed
#   2. an update link (UPDATE_URL in .env) to a latest.json you host -> check -> download -> install
# The zip is checked (it must be a SekexBot Android package, and match the SHA-256 in latest.json)
# before `sekex update` installs it; your keys, settings, learning memory and journal are kept.
UPD_DIR = Path.home() / ".sekexbot"
_upd = {"checked": 0.0, "info": None}


def _zip_version(path: Path) -> str:
    import zipfile
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise HTTPException(400, "That file isn't a zip.")
    names = z.namelist()
    if any(n.startswith("/") or ".." in n.split("/") for n in names):
        raise HTTPException(400, "That zip has unsafe file paths - not installing it.")
    if "SekexBot_Android/install.sh" not in names or "SekexBot_Android/VERSION" not in names:
        raise HTTPException(400, "That zip isn't a SekexBot Android package (SekexBot_Android_vX.Y.Z.zip).")
    return z.read("SekexBot_Android/VERSION").decode().strip()


def _vtuple(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _run_update(path: Path, new_ver: str):
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "In-app updates are for the Android edition. On a PC, replace the files and restart.")
    log = open(Path.home() / "sekexbot-update.log", "w")
    env = dict(os.environ, SEKEX_QUICK="1", SEKEX_QUIET="1")
    env.pop("SEKEX_LOGGING", None)
    subprocess.Popen(["bash", exe, "update", str(path)], stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                     env=env, start_new_session=True)
    if engine:
        engine.event(f"Updating SekexBot {__version__} -> {new_ver}. Back in about a minute.", "warning")
    return {"ok": True, "from": __version__, "to": new_ver}


REL_DIR = UPD_DIR / "releases"


def _releases():
    out = []
    for f in sorted(REL_DIR.glob("SekexBot_Android_v*.zip"), key=lambda p: p.stat().st_mtime, reverse=True):
        v = f.stem.split("_v")[-1]
        if v != __version__:
            out.append({"version": v, "saved": datetime.fromtimestamp(f.stat().st_mtime, NY).strftime("%b %d %I:%M %p")})
    return out


def _upd_prefs():
    return {"mode": os.getenv("UPDATE_MODE", "ask"), "skip": os.getenv("UPDATE_SKIP", "")}


@app.get("/api/app/update/progress")
def update_progress():
    """Live install progress while an update/rollback runs (the old app keeps serving until the restart)."""
    import time as _t
    steps, t0 = [], None
    f = UPD_DIR / "update_progress.log"
    if f.exists():
        for ln in f.read_text().splitlines():
            ts, _, msg = ln.partition("|")
            if ts.isdigit():
                t0 = t0 or int(ts)
                steps.append({"t": int(ts), "msg": msg})
    tail = []
    lg = Path.home() / "sekexbot-update.log"
    if lg.exists():
        import re as _re
        tail = [_re.sub(r"\x1b\[[0-9;]*m", "", x) for x in lg.read_text(errors="ignore").splitlines()[-8:] if x.strip()]
    expected = 7
    done = any(x["msg"] == "DONE" for x in steps)
    failed = any(x["msg"].startswith("FAILED") for x in steps)
    pct = 100 if done else min(95, int(100 * len(steps) / expected))
    return {"current": __version__, "steps": steps, "pct": pct, "done": done, "failed": failed,
            "elapsed": int(_t.time() - t0) if t0 else 0, "log": tail}


@app.get("/api/app/update/status")
def update_status():
    return {"current": __version__, "edition": android.EDITION, "update_url": os.getenv("UPDATE_URL", ""),
            "info": _upd["info"], "prefs": _upd_prefs(), "releases": _releases()}


class UpdPrefsReq(BaseModel):
    mode: str | None = None          # ask | manual
    skip: str | None = None          # a version to stop asking about ("" = clear)


@app.post("/api/app/update/prefs")
def update_prefs(r: UpdPrefsReq):
    vals = {}
    if r.mode in ("ask", "manual"):
        vals["UPDATE_MODE"] = r.mode
    if r.skip is not None:
        vals["UPDATE_SKIP"] = r.skip.strip()
    if vals:
        write_env(vals)
    return {"ok": True, "prefs": _upd_prefs()}


class RollbackReq(BaseModel):
    version: str


@app.post("/api/app/rollback")
def rollback(r: RollbackReq):
    v = r.version.strip()
    if not all(p.isdigit() for p in v.split(".")):
        raise HTTPException(400, "Pick a version from the list")
    path = REL_DIR / f"SekexBot_Android_v{v}.zip"
    if not path.exists():
        raise HTTPException(404, f"No saved copy of v{v} on this phone")
    if _zip_version(path) != v:
        raise HTTPException(400, "That saved copy looks damaged")
    return _run_update(path, v)


@app.post("/api/app/update/upload")
async def update_upload(request: Request, allow_downgrade: bool = False):
    data = await request.body()
    if not data or len(data) > 60_000_000:
        raise HTTPException(400, "Pick the SekexBot_Android_vX.Y.Z.zip file (up to 60 MB).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    path.write_bytes(data)
    ver = _zip_version(path)
    if _vtuple(ver) < _vtuple(__version__) and not allow_downgrade:
        raise HTTPException(409, f"DOWNGRADE:{ver}")
    return _run_update(path, ver)


class UpdUrlReq(BaseModel):
    url: str


@app.post("/api/app/update/url")
def update_set_url(r: UpdUrlReq):
    u = r.url.strip()
    if u and not u.startswith("https://"):
        raise HTTPException(400, "The update link must start with https://")
    write_env({"UPDATE_URL": u})
    _upd.update(checked=0.0, info=None)
    return {"ok": True}


def _check_manifest():
    import time
    from urllib.parse import urljoin
    import requests
    url = os.getenv("UPDATE_URL", "")
    if not url:
        raise HTTPException(400, "Add your update link first (the address of latest.json).")
    try:
        m = requests.get(url, timeout=20, headers={"Cache-Control": "no-cache"}).json()
    except Exception as ex:
        raise HTTPException(400, f"Couldn't read the update link: {str(ex)[:160]}")
    if not m.get("version") or not m.get("url"):
        raise HTTPException(400, "The update link doesn't look like a SekexBot latest.json")
    info = {"latest": m["version"], "url": urljoin(url, m["url"]), "sha256": m.get("sha256", ""),
            "notes": m.get("notes", ""), "available": _vtuple(m["version"]) > _vtuple(__version__)}
    _upd.update(checked=time.time(), info=info)
    return info


@app.get("/api/app/update/check")
def update_check():
    return {"current": __version__, **_check_manifest()}


@app.post("/api/app/update/install")
def update_install():
    import hashlib
    import requests
    info = _check_manifest()
    if not info["available"]:
        raise HTTPException(400, f"You already have the latest version ({__version__}).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    try:
        with requests.get(info["url"], stream=True, timeout=120) as r:
            r.raise_for_status()
            h = hashlib.sha256()
            with open(path, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
                    h.update(chunk)
    except Exception as ex:
        raise HTTPException(400, f"Download failed: {str(ex)[:160]}")
    if not info["sha256"] or h.hexdigest().lower() != info["sha256"].lower():
        path.unlink(missing_ok=True)
        raise HTTPException(400, "The download didn't match the checksum in latest.json - not installing it.")
    ver = _zip_version(path)
    return _run_update(path, ver)


@app.on_event("startup")
def _auto_update_check():
    """Every 6 hours, if an update link is set, look for a new version and notify the phone."""
    import shutil
    import subprocess
    import threading
    import time

    def loop():
        told = ""
        while True:
            time.sleep(90)
            if os.getenv("UPDATE_URL"):
                try:
                    info = _check_manifest()
                    pr = _upd_prefs()
                    if info["available"] and info["latest"] != told and pr["mode"] == "ask" \
                            and info["latest"] != pr["skip"] and shutil.which("termux-notification"):
                        told = info["latest"]
                        subprocess.run(["termux-notification", "--id", "sekexbot-update", "--title",
                                        f"SekexBot {info['latest']} is available",
                                        "--content", "Tap to open SekexBot and choose Update now or Later",
                                        "--action", f"termux-open-url http://127.0.0.1:{ARGS.port}"], timeout=10)
                except Exception:
                    pass
            time.sleep(3600)          # look for a new version every hour
    if android.IS_ANDROID:
        threading.Thread(target=loop, daemon=True, name="update-check").start()


# ---------------- streaming prices to the dashboard (Server-Sent Events) ----------------
@app.get("/api/stream")
async def price_stream(request: Request, symbols: str = ""):
    import asyncio
    import json as _j
    import time as _t
    from fastapi.responses import StreamingResponse
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip()][:30]

    async def gen():
        sent, last_ping = {}, 0.0
        while not await request.is_disconnected():
            now = _t.time()
            for x in syms:
                _interest[x] = now
            f = feed
            out = {}
            if f is not None:
                for x in syms:
                    lv = f.get(x, max_age=30)
                    if lv and lv.get("last"):
                        v = (round(lv["bid"] or 0, 4), round(lv["ask"] or 0, 4), round(lv["last"], 4))
                        if sent.get(x) != v:
                            sent[x] = v
                            out[x] = {"bid": v[0] or None, "ask": v[1] or None, "last": v[2]}
            if out:
                yield f"data: {_j.dumps(out)}\n\n"
            elif now - last_ping > 15:
                last_ping = now
                yield f": ping {int(now)}\n\n"
            await asyncio.sleep(0.25)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})


# ---------------- 🛠 help & repair ----------------
def _diag():
    from autobot import helpdesk
    return helpdesk.diagnose({"engine": engine, "setup_error": setup_error, "settings": settings, "version": __version__,
                              "device": android.health(), "sim": ARGS.sim, "update_info": _upd["info"],
                              "feed": feed})


@app.get("/api/help/diagnose")
def help_diagnose():
    return clean(_diag())


class FixReq(BaseModel):
    action: str


@app.post("/api/help/fix")
def help_fix(r: FixReq):
    import shutil
    import subprocess
    a = r.action
    if a == "reconnect":
        if engine and engine.running:
            engine.stop()
            build_engine()
            if engine:
                engine.start(resumed=True)
        else:
            build_engine()
        return {"ok": engine is not None, "message": "Reconnected." if engine else setup_error}
    if a == "use_iex":
        was = bool(engine and engine.running)
        if engine and engine.running:
            engine.stop()
        settings.data_feed = "iex"
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        return {"ok": engine is not None, "message": "Switched the data feed to IEX (free)."}
    if a == "trade_on":
        need_engine().start()
        return {"ok": True, "message": "Auto-trader started."}
    if a in ("restart", "repair"):
        exe = shutil.which("sekex")
        if not android.IS_ANDROID or not exe:
            raise HTTPException(400, "Restart / repair from the app works on the Android edition.")
        cmd = ["bash", exe, "restart"] if a == "restart" else \
            ["bash", "-c", f"SEKEX_QUICK=1 SEKEX_QUIET=1 bash {BASE_DIR_}/install.sh > $HOME/sekexbot-repair.log 2>&1; bash {exe} restart"]
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return {"ok": True, "restarting": True,
                "message": "Restarting…" if a == "restart" else "Repairing the install, then restarting (1–3 min)…"}
    if a == "update":
        return update_install()
    raise HTTPException(400, "Unknown repair action")


class AskReq(BaseModel):
    question: str = ""
    error: str = ""


@app.post("/api/help/ask")
def help_ask(r: AskReq):
    from autobot import helpdesk
    return helpdesk.ask(r.question[:800], _diag(), __version__, r.error[:600])


@app.post("/api/help/report")
def help_report():
    from autobot import helpdesk
    st = {"mode": engine.mode if engine else "-", "state": engine.state if engine else setup_error,
          "running": bool(engine and engine.running), "edition": android.EDITION,
          "session": engine.session.name if engine and engine.session else "-"}
    text = helpdesk.report(_diag(), __version__, st)
    dl = Path.home() / "storage" / "downloads"
    target = (dl if dl.exists() else DATA_DIR) / f"SekexBot_report_{datetime.now(NY).strftime('%Y%m%d_%H%M')}.txt"
    try:
        target.write_text(text)
    except Exception:
        target = None
    return {"ok": True, "path": str(target) if target else "", "text": text[:20000]}


# ---------------- alerts ----------------
@app.get("/api/alerts")
def alerts_get(since: int = 0):
    items = [a for a in list(alerts.history) if a["id"] > since]
    return {"items": items[:60], "cfg": alerts.public_cfg()}


class AlertCfg(BaseModel):
    enabled: dict | None = None
    phone: bool | None = None
    quiet_start: str | None = None
    quiet_end: str | None = None
    quiet_keep_risk: bool | None = None
    ntfy_topic: str | None = None
    ntfy_server: str | None = None
    tg_token: str | None = None
    tg_chat: str | None = None


@app.post("/api/alerts/config")
def alerts_config(r: AlertCfg):
    import re
    for k, v in r.model_dump(exclude_none=True).items():
        if k == "enabled":
            alerts.cfg["enabled"].update({a: bool(b) for a, b in v.items() if a in alerts.cfg["enabled"]})
        elif k in ("quiet_start", "quiet_end"):
            if v and not re.fullmatch(r"[0-2]\d:[0-5]\d", v):
                raise HTTPException(400, "Quiet hours must look like 22:00")
            alerts.cfg[k] = v
        elif k == "ntfy_topic":
            if v and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", v):
                raise HTTPException(400, "ntfy topic: letters, numbers, - and _ only")
            alerts.cfg[k] = v
        else:
            alerts.cfg[k] = v.strip() if isinstance(v, str) else v
    alerts.save()
    return {"ok": True, "cfg": alerts.public_cfg()}


@app.post("/api/alerts/test")
def alerts_test():
    alerts.test()
    return {"ok": True}


class PriceAlertReq(BaseModel):
    symbol: str = ""
    op: str = "above"
    price: float = 0
    note: str = ""
    remove: str = ""


@app.post("/api/alerts/price")
def alerts_price(r: PriceAlertReq):
    if r.remove:
        watcher.remove_price_alert(r.remove)
    else:
        sym = _valid_sym(r.symbol)
        if r.op not in ("above", "below") or r.price <= 0:
            raise HTTPException(400, "Choose above or below and a price")
        if len(alerts.cfg.get("price_alerts", [])) >= 50:
            raise HTTPException(400, "Up to 50 price alerts")
        watcher.add_price_alert(sym, r.op, r.price, r.note[:60])
    return {"ok": True, "price_alerts": alerts.cfg.get("price_alerts", [])}


@app.post("/api/app/shutdown")
def app_shutdown():
    """Android: turn the whole app off (same as the home-screen Stop button / `sekex stop`)."""
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "Turning the app off from the dashboard is only available on the Android edition.")
    subprocess.Popen(["bash", exe, "stop", "--gui"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
    return {"ok": True}


@app.post("/api/ai_test")
def ai_test():
    from autobot.analyst import ai_ping
    return ai_ping()


class WatchReq(BaseModel):
    symbol: str
    action: str = "add"      # add | remove


@app.post("/api/watchlist")
def watchlist(r: WatchReq):
    sym = r.symbol.upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker")
    wl = [w.upper() for w in settings.watchlist]
    if r.action == "remove":
        wl = [w for w in wl if w != sym]
    elif sym not in wl:
        wl.append(sym)
    settings.watchlist = wl
    settings.save()
    if engine:
        engine.last_scan = None
        engine.ext_last_scan = None
        engine.event(f"Watchlist {'removed' if r.action == 'remove' else 'added'} {sym} — rescanning")
    return {"ok": True, "watchlist": wl}


# ---------------- 📊 stats · 📰 earnings/news · 🛡 heartbeat & backups ----------------
@app.get("/api/stats")
def stats_api(days: int = 90, session: str = ""):
    from autobot import stats as st
    e = need_engine()
    days = max(1, min(int(days), 365))
    try:
        if ARGS.sim:
            trips = []
            for r in db.recent(2000):
                if r.get("status") != "closed" or not r.get("closed_at"):
                    continue
                o, c = datetime.fromisoformat(r["opened_at"]), datetime.fromisoformat(r["closed_at"])
                trips.append({"symbol": r["symbol"], "side": "long" if r["side"] == "buy" else "short", "qty": r["qty"],
                              "entry": r["entry"], "exit": r["exit"], "opened": o.astimezone(NY), "closed": c.astimezone(NY),
                              "pnl": r["pnl"] or 0, "cost": (r["qty"] or 0) * (r["entry"] or 0)})
        else:
            trips = st.round_trips(st.fetch_fills(e.broker, days))
    except Exception as ex:
        raise HTTPException(502, f"Couldn't load your trade history from Alpaca: {str(ex)[:160]}")
    out = st.summarize(trips, db.recent(3000), days, session if session in st.ORDER else None)
    out["mode"] = e.mode
    return clean(out)


_research_cache = {}


@app.get("/api/research/{symbol}")
def research(symbol: str, days: int = 30, min_move: float = 1.5):
    """🔍 Trend legs + 3:55 PM overnight test from the stock's own minute history (runs on your Alpaca data)."""
    import time as _t
    from autobot import trends
    e = need_engine()
    sym = _valid_sym(symbol)
    days = max(5, min(int(days), 90))
    key = (sym, days, e.mode)
    c = _research_cache.get(key)
    if c and _t.time() - c[0] < 600:
        df = c[1]
    else:
        try:
            df = e.broker.chart_bars(sym, days=days + 3)
        except Exception as ex:
            raise HTTPException(502, f"Couldn't load {sym} history: {str(ex)[:150]}")
        if df is None or len(df) < 200:
            raise HTTPException(404, f"Not enough minute history for {sym} yet.")
        _research_cache[key] = (_t.time(), df)
    legs = trends.trend_legs(df, min_move=max(0.3, min(float(min_move), 20)) / 100)
    cb = trends.closing_bell(df)
    return clean({"symbol": sym, "days": days, "from": str(df.index[0].date()), "to": str(df.index[-1].date()),
                  "legs": legs[-80:], "summary": trends.summarize_legs(legs), "closing_bell": cb})


@app.get("/api/skips")
def skips_api(symbol: str = "", limit: int = 80):
    """'Why no trade?' - recent signals/flips the bot saw but did not take, with the reason."""
    e = need_engine()
    sym = symbol.strip().upper()
    rows = [r for r in list(e.skips) if not sym or r["symbol"] in (sym, "(all)")]
    return {"skips": rows[:max(1, min(int(limit), 300))]}


@app.get("/api/events/{symbol}")
def events_api(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    now = e.broker.now()
    news = events.news(sym, max_age=60) if not ARGS.sim else []
    return {"symbol": sym, "earnings": events.earnings_text(sym, now) if not ARGS.sim else "",
            "news": news[:6], "bot_block": events.block_reason(sym, now, _session_name(e)) if not ARGS.sim else "",
            **events.info()}


def _guard_status():
    e = engine
    if e is None:
        return ("NOT CONNECTED", 0, False)
    return (e.mode, len(e.positions or {}), bool(e.running))


def _need_guardian():
    if guardian is None:
        raise HTTPException(400, "Heartbeat and backups aren't available in the simulator.")
    return guardian


@app.get("/api/guardian")
def guardian_get():
    return _need_guardian().public()


class GuardCfg(BaseModel):
    hc_url: str | None = None
    gh_repo: str | None = None
    gh_token: str | None = None
    backup_on: bool | None = None


@app.post("/api/guardian/config")
def guardian_cfg(r: GuardCfg):
    g = _need_guardian()
    d = r.model_dump(exclude_none=True)
    if "hc_url" in d and d["hc_url"] and not d["hc_url"].startswith("https://"):
        raise HTTPException(400, "Paste the full ping URL from healthchecks.io (starts with https://hc-ping.com/…).")
    if "gh_repo" in d and d["gh_repo"] and d["gh_repo"].count("/") != 1:
        raise HTTPException(400, "Repo must look like owner/name, e.g. sekextrading-cloud/SekeXBot-Mobile")
    g.cfg.update(d)
    g.save()
    ok = g.ping() if d.get("hc_url") else None
    return {"ok": True, "ping": ok, **g.public()}


@app.post("/api/guardian/test")
def guardian_test():
    g = _need_guardian()
    if not g.cfg["hc_url"]:
        raise HTTPException(400, "Add your healthchecks.io ping URL first.")
    return {"ok": g.ping(), **g.public()}


@app.post("/api/guardian/backup")
def guardian_backup():
    g = _need_guardian()
    r = g.backup()
    return {**r, **g.public()}


@app.post("/api/guardian/restore")
async def guardian_restore(request: Request):
    g = _need_guardian()
    if engine and engine.running:
        raise HTTPException(409, "Stop the auto-trader before restoring a backup.")
    data = await request.body()
    try:
        n = g.restore(data)
    except Exception as ex:
        raise HTTPException(400, str(ex)[:160])
    learner.__init__()
    return {"ok": True, "files": n, "note": "Restored. Restart the app (⚙ → Turn off app, then open it) to reload everything."}


@app.on_event("startup")
def _start_guardian():
    global guardian
    if not ARGS.sim:
        from autobot.guardian import Guardian
        guardian = Guardian(_guard_status)


if __name__ == "__main__":
    print(f"\n  SekexBot v{__version__} ({RELEASE_DATE}){' - Android edition' if android.IS_ANDROID else ''}")
    print(f"  SekexBot dashboard -> http://{ARGS.host}:{ARGS.port}"
          f"  ({'SIMULATOR' if ARGS.sim else ('LIVE' if settings.live else 'PAPER')})\n")
    uvicorn.run(app, host=ARGS.host, port=ARGS.port, log_level="warning")
