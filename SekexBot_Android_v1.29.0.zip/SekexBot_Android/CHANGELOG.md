# SekexBot changelog

Version numbers are MAJOR.MINOR.PATCH. MAJOR means a breaking change to settings or data, MINOR means a new feature, and PATCH means a fix.
The running version shows in the dashboard header and in the console window when SekexBot starts.

## 1.29.0 — 2026-09-28
- Shorts on by default: SELL flips and short setups now trade in regular hours, and in pre-market and after-hours when the stock is shortable and your account can short. Overnight stays long-only. Stops, take-profits and exits work for shorts in every session.
- Why no trade?: a new panel lists every signal or ribbon flip the bot saw but skipped, with the exact reason (flip too old, below VWAP, time-of-day filter, cooling off, cannot short, slots full, sizing and more). Filter it by symbol.
- Trade every flip: optional switch that takes each fresh ribbon BUY/SELL flip on your watchlist and picks. It skips the VWAP, learner and time-of-day checks for flips only. The daily loss limit and position sizing still apply.

## 1.28.0 — 2026-09-28
- ✋ One-tap manual trading: no more 'Send this order?', 'Close?' or LIVE-money pop-ups on the order ticket, the quick trade sheet or Close buttons. The order goes straight away. To bring the pop-ups back, tick 'Ask before sending or closing manual trades' in Controls. Opening a short when you don't own the stock still asks once, because losses are unlimited.

## 1.27.0 — 2026-09-28
- 🧊 Cooling off is now optional (Controls). 'Cool off after 3 losses in a row' switches off the 20-minute pause and the half-size penalty. 'Symbol cooldown' switches off the wait before re-trading a stock and the skip after 2 losses in a day. Both are on by default. While the bot is cooling off, a ▶ Resume now button clears the pause, the penalty and today's cooldowns in one tap. The daily loss limit always stays on.

## 1.26.0 — 2026-09-28
- 💰 Quick harvest for scalps (Aggressive and Scalp modes, every session): once a scalp has been green for 2 checks in a row, it doesn't wait for the target. It banks the profit when momentum stalls (0.15R back from its best) or when it's near the target. The stock can be re-entered right away if the setup fires again; otherwise the slot goes to the next best candidate. Bug-check fixes: restoring open trades after a restart or a ↩ Revert no longer fails when versions store different trade fields, and log lines show the size weight rounded.

## 1.25.0 — 2026-09-28
- 🔥 Aggressive scalping (Controls, off by default): many fast trades in every session. It adds a MICRO_SCALP setup (1-minute burst over the last 3 bars on 2× volume, above VWAP) and trades every setup with ½ at +0.5R (the rest moves to break-even) and the rest at +1R, out within 8 minutes. Up to 6 positions at 60% size, checks every 10 s (5 s in extended hours), and shorter cooldowns. The daily loss limit still applies. 🔻 Flush short: a tight range that breaks down hard on 2× volume (like TSLA's drop), when shorting is on. 🔺 Flush bounce: the first strong green bar after a fast 2-ATR drop on a volume spike (in all sessions). Flush setups skip the ribbon wait and the time-of-day filter. 🎯 Setting up now: a live top-15 list of stocks coiling for a fast move before it happens (tight range, volume building, lean from VWAP, ribbon and highs/lows), with the likely direction, trigger price, target, expected move, a 0–100 Ready score and ⚡ breaking now. The stock picker now scans 30 names.

## 1.24.0 — 2026-09-28
- 💰 Profit harvesting in every session. Pre-market, after-hours and overnight trades now take profit along the way like regular hours: ⅓ at +1R (the rest moves to break-even), ⅓ at +2R, then a 1× ATR trail or a ribbon flip. Partial sells are marketable limit orders, the only kind Alpaca allows outside regular hours, and each one sends a 💰 alert. ⚡ New Scalp mode (Controls, off by default): ½ at +0.6R, the rest at +1.2R, out within 20 minutes, in every session. ⬆ Update progress: the update screen shows a progress bar, each install step with a ✓, elapsed time and a details log. The app keeps serving while it installs and only restarts at the end.

## 1.23.0 — 2026-09-27
- 🚀 Opening Drive setup (OPEN_DRIVE), modeled on your best trades (SPCX, VKTX, AMD at 9:30): a +2% gapper that breaks its first-5-minute high above VWAP on a volume surge, 9:35–9:50 (a gap-down short when shorting is on). 💰 Take profit along the way (on by default): the bot sells ⅓ at +1R and moves the stop to break-even, sells another ⅓ at +2R, and rides the rest with a 1× ATR trail or until the ribbon flips. A '💰 Took profit' alert fires each time, and the journal and learner count the whole trade. 🕒 Time-of-day filter from your own history: the bot skips new trades in the time slots where your last 90 days lose money (at least 30 trades; today that's midday, morning after the drive, after-hours and overnight), and still allows opening drives until 9:50. Switches for both are in Controls. ⬆ Updates: SekexBot checks for a new version every hour and, in Ask mode, shows Update now / Later / Skip this version; Manual mode never prompts. Every update saves the version it replaces (the last 3 are kept), and '↩ Revert to vX' in the Update screen (or 'sekex rollback X.Y.Z') goes back while keeping your data.

## 1.22.0 — 2026-09-27
- 🔍 Trend research (Manual tab): type a ticker (for example SPCX), choose 10–90 days and tap Study. It finds every big run up or down in the stock's own minute history. For each run you see the start and end times and prices, the move and how long it lasted, grouped as morning, midday or afternoon. It also shows when morning runs typically start, what was true as runs began (opening drive, opening-range break, above or below VWAP, volume surge) and which exit rule kept the most of each run (ribbon flip, VWAP cross, 2 closes against, 1× or 2× ATR trail). These results will shape the bot's new morning and wave strategies.
- 🔔 3:55 PM overnight test: buy (or short) at 3:55 PM and exit at 8 PM, 11 PM, 2 AM, 4 AM, 8 AM, 9:25, 9:35 or 10 AM. Shows average result, long and short win rates, and worst and best days, and highlights the best combination. It uses real overnight (24-hour session) prices where the stock trades overnight.

## 1.21.0 — 2026-09-27
- 📊 Trading stats (Positions tab): every trade in your Alpaca account, bot and manual, matched from buy to sell. Shows total P&L, win rate, average win and loss, and profit factor. P&L by time of day (pre-market, morning 9:30–11:30, midday, afternoon, after-hours, overnight); tap a time to filter. Your top 5 wins and worst 5 losses, bot vs. manual results, and each bot strategy's results. Covers 7 days to 1 year.
- 📰 Earnings and news: the order ticket shows whether the stock reports earnings today or before the next open, plus the latest headlines, with risky ones flagged (offering, halt, bankruptcy, delisting, investigation, reverse split, downgrade…). The auto-trader skips a stock on its earnings day, doesn't buy after-hours or overnight right before a pre-market report, and waits 30 minutes after a risky headline. It uses the free Nasdaq earnings calendar and Alpaca news. If either is unreachable, trading continues.
- 🛡 Safety net (⚙ Settings): a phone-offline alert through free healthchecks.io. The app pings every minute; if the phone dies, sleeps or loses internet, healthchecks.io alerts you by email, SMS, ntfy or Telegram. Nightly backups at 8:10 PM ET of the journal, learning memory and settings (never API keys or tokens) to Downloads/SekexBot/backups, keeping 14, with optional upload to a private GitHub repo. Back up now and Restore buttons included.

## 1.20.5 — 2026-09-27
- Charts at any hour: the chart now shows the last few days, including pre-market, after-hours and the overnight (24-hour) session, not just 9:30–4:00. Nights and weekends show the most recent real prices, the same as Robinhood's 24 Hour Market chart. It uses Alpaca's overnight feed (BOATS on SIP accounts, Alpaca's overnight feed otherwise). Extended hours are lightly shaded and overnight is shaded blue. When nothing is trading, the header says when the last trade happened.

## 1.20.4 — 2026-09-27
- Take profit after a halt: every winner kept open gets a profit lock, set at break-even or better and then at half of its best gain, rising as the price climbs. If the price falls back to the lock, the position is sold (limit orders in extended hours) and you get a "💰 Took profit" alert. This covers manual positions too. Bot trades also get their stop at Alpaca raised to the lock. Profit locks survive an app restart.

## 1.20.3 — 2026-09-27
- Daily loss limit: when it's hit, the bot now closes only the **losing** positions (bot and manual) and keeps the winners open. Winners keep their stop-loss and the bot keeps trailing them; it just opens no new trades until the next day (8 PM ET). In extended hours the losers are closed with limit orders.

## 1.20.2 — 2026-09-27
- Auto-trade safety fixes: after switching from PAPER to LIVE on the same day, the bot could compare your live balance with the paper account's starting balance, read it as a huge loss, and close all live positions. The start-of-day balance is now kept separately for Paper and Live, and any figure far off your real equity is ignored. Updated for FINRA's retirement of the pattern-day-trader rule (Alpaca's Intraday Margin Framework, since June 4, 2026). No day-trade counting and no $25k minimum: the bot sizes within intraday buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders. The app keeps working after Alpaca removes the old day-trade fields from its API on July 6, 2026. A position the bot can't close now raises an alert instead of failing silently. Saved halts and loss streaks are again restored correctly after a restart (the new always-on balance display could skip them).

## 1.20.1 — 2026-09-27
- Fixes: the account bar and Account card now show your balance, buying power and today's P&L at all times, including nights and weekends (they were blank while the market was closed). Switching the data feed to SIP now works while the auto-trader is running — it checks your account really has SIP, switches, and restarts the bot — instead of silently flipping back to IEX.

## 1.20.0 — 2026-09-27
- Paper / Live switch: tap the PAPER / LIVE badge at the top to switch. Live needs your Live PIN, a real-money confirmation and working live keys (checked first); a running auto-trader stops, switches and restarts by itself. Too many wrong PINs lock the switch for 15 minutes. Live is unmistakable on every screen: a red frame, a '● LIVE — REAL MONEY' bar, a pulsing red badge, 'LIVE ·' on order buttons, a red browser bar and '🔴 LIVE' in the title and alerts. Account bar: balance, today's P&L ($ and %), open P&L, buying power and loss left stay pinned under the header on every screen and layout.

## 1.19.0 — 2026-09-27
- Interactive chart: touch or drag for a crosshair with time, OHLC, volume, trend (uptrend/downtrend), fast/slow lines and VWAP; tap to pin a point and measure the move to the crosshair ($, %, time, ribbon flips); pinch or scroll to zoom, drag to pan, double-tap to reset; 1m / 3m / 5m / 15m timeframes; volume bars and a VWAP line.

## 1.18.0 — 2026-09-27
- Streaming prices: real-time quotes and trades from Alpaca's websocket (up to 30 symbols on the free plan), pushed to the dashboard — the ticket, quick sheet and positions P&L move tick by tick with a STREAMING badge. The bot uses streamed prices too, and its extended-hours stops (watched by the app) now react within about a second instead of 15. Falls back to polling automatically if streaming isn't available. Help & repair now checks whether SIP data works on your account and can switch back to IEX with one tap.

## 1.17.0 — 2026-09-27
- Alerts: phone notifications (with Trade and Close buttons) for bot entries, fills, exits with P&L, stops raised, rejections, daily-loss halt, losing streaks, broker restrictions and stale data; watchlist trend alerts (ribbon flip, new high/low of day, VWAP, volume spike); price alerts; end-of-day summary. Optional copies to ntfy or Telegram, quiet hours, per-type switches, and a bell with the alert history. Faster trading: $1k / $5k / 1R / Max size buttons and a price-alert button in the quick sheet; tapping Trade on a notification opens the quick sheet. Help & repair: run checks, one-tap fixes (reconnect, restart, repair install, update), Ask AI (Claude explains errors in plain steps) and Send report. Fixes: bracket orders rejected while the market is closed are re-anchored on Alpaca's reference price automatically, order errors are explained in plain words, and suggested stops can no longer be unrealistically tight.

## 1.16.0 — 2026-09-26
- Live price everywhere, at any time: the order ticket and quick trade sheet show the price, day change (green/red), bid/ask and a LIVE dot, refreshing every 3 seconds, with the cost worked out as shares × price against your buying power. When the market is closed (nights, weekends, holidays) the price falls back to the last trade or last close, labeled 'as of', so orders can always be prepared. The trend chart shows the most recent session when the market is closed instead of 'Waiting for bars'.

## 1.15.0 — 2026-09-26
- Suggested stop-loss / take-profit: tick Attach stop-loss / take-profit and SekexBot proposes Scalp, Day and Swing levels from real support/resistance and the stock's volatility (ATR), with R multiple, trend check and a size that risks the bot's base amount. The quick trade sheet can protect orders with the Day levels automatically. Fix: prices now work on nights and weekends (last session's close), so orders can be prepared while the market is closed.

## 1.14.1 — 2026-09-26
- Gains show green and losses red everywhere, with a + sign on gains: today's P&L, the summary strip, every position and its %, bot trades (new P&L column), the journal, daily results and averages. Totals for Positions & orders, Open positions and Daily results. sekex status colors the day's P&L too.

## 1.14.0 — 2026-09-26
- New layout with a ⚙ gear: choose Tabs (Auto · Manual · Positions · More at the bottom), an Auto | Manual switch, or the classic one-page layout. Light, dark or follow-the-phone theme. A big Auto-trader on/off switch and an always-visible summary strip (equity, today, loss left, open trades). Your choices are remembered on each device.

## 1.13.0 — 2026-09-26
- Double-tap to trade: double-tap any stock in the picker, the scanner chips or your positions to open a quick trade sheet with the suggested size and big BUY / SELL (or SHORT) buttons. A single tap still opens the chart.

## 1.12.1 — 2026-09-26
- Turn off app button uses an icon every phone font can show.

## 1.12.0 — 2026-09-26
- Full order ticket like Alpaca's: Buy/Sell (Short), Market, Limit, Stop, Stop limit and Trailing stop orders, a quantity stepper, a limit price with tap-to-fill bid/ask, Time in force (Day, GTC, IOC, FOK, At the open, At the close) and Trading session (Market hours, Extended hours, 24 Hour Market). In-app updates: install a new version from the dashboard (⬆ Update) by picking the zip, or from an update link that is checked every 6 hours, with a notification and one-tap install.

## 1.11.0 — 2026-09-26
- Manual trading: a Manual trade ticket with Buy and Sell (market or limit, size in shares or dollars, optional stop-loss and take-profit) and a Positions & orders panel for the whole account with Close, Close ½ and Cancel. The bot stays out of any symbol you trade by hand that day and never flattens your manual positions at the close.

## 1.10.0 — 2026-09-26
- Fully automated install: one-file installer (SekexBot_Setup.sh), optional sekexbot-setup.conf to pre-fill keys and settings and start trading automatically, a non-interactive package install with a log, and 'sekex doctor --fix', which checks the phone and opens the screens that fix problems.

## 1.9.1 — 2026-09-26
- Tap-to-use controls: home-screen Start / Stop / Status / Open buttons (Termux:Widget), Start and Stop buttons in the SekexBot notification, pop-up messages, and a ⏻ Turn off app button on the dashboard.

## 1.9.0 — 2026-09-26 (Android edition)
- 🤖 Runs entirely on an Android phone inside Termux. No PC needed. `install.sh` sets everything up, and the `sekex` command starts, stops and checks the bot.
- Watchdog: if the app crashes or Android kills it, it restarts automatically, and trading **resumes** if it was running (a Stop from the dashboard or `sekex stop` is remembered).
- Open trades, today's halt state, profit-lock peak and losing-streak brakes are saved every tick and restored after a restart, so a restart can't reset your limits.
- Wake lock, start on phone boot (Termux:Boot), and an ongoing notification with an Open button.
- Dashboard shows battery, charging and wake-lock status, with warnings when the phone is on battery or hot.
- After-hours and overnight trading start **off** on Android, because their stops are watched by the app itself.
- "Phone access" becomes "Remote access" for checking the phone's bot from another device (uses Termux's cloudflared).

## 1.8.0 — 2026-09-26
- 📱 Phone access through a Cloudflare Tunnel. You can use a Quick link (no account) or your own domain, with a QR code, and auto-connect on start.
- A login page with a password (hashed), 30-day signed sessions, and a lockout after too many wrong attempts.
- Broker keys and phone-access settings can only be changed on the computer running SekexBot.
- The dashboard fits phone screens and can be installed as an app with the SekexBot icon.
- A version number with this changelog.

## 1.7.2
- Chart read: "Analyze live chart" now uses the most recent session at night, on weekends and before the open.
- Clear error messages for the AI screenshot reader: no API credits, bad key, model not found, image too large, rate limit.
- A "Test AI key" button.

## 1.7.1
- New SekexBot logo, app icon, favicon, Windows .ico, and a desktop-shortcut helper.

## 1.7.0
- Account-size-aware stock picker. It scans about 300 stocks and scores each one for opportunity × fit (daily limit, buying power, liquidity).
- "Scan now" button and a Stock picker table with the reasons for each pick.
- Fix: volume and ATR now come from full-market SIP history instead of IEX-only volume.

## 1.6.0
- 🔑 Broker keys screen: enter, test and save Alpaca paper and live keys, a Live PIN, and a Claude key, all in the dashboard.
- Startup no longer opens Notepad.

## 1.5.1
- Renamed to SekexBot.

## 1.5.0
- BullGPT-style screenshot reader. Drop in or paste a chart and get a game plan: trend, levels, timing, scenarios, lean, and what the bot would do.
- Watchlist of tickers that are always scanned and traded in every session (SPCX added to start).

## 1.4.0
- After-hours (4–8 PM) and overnight (8 PM–4 AM) trading: long-only, limit orders, bot-managed stops, half size.
- The daily loss window runs 8 PM → 8 PM ET. The chart is built from quotes overnight.
- Fixed start_bot.bat when the Python environment was missing pip.

## 1.3.0
- Portable SD card / USB edition with a bundled runtime and self-repairing setup.

## 1.2.0
- AI chart read panel: levels, Fibonacci, RSI, VWAP, bias score, and bull and bear scenarios.

## 1.1.0
- EMA ribbon: RIBBON_FLIP strategy, ride-the-ribbon exit, ribbon trend filter, ribbon chart on the dashboard.

## 1.0.0
- First release: morning scanner, five strategies, a Thompson-sampling learner that picks setups and exits, a daily-max-loss risk manager, bracket orders, the dashboard, and the offline simulator.
