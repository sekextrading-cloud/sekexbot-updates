"""The auto-trader loop. Start it once; it waits for the open, scans the morning movers,
trades all session, manages exits, flattens before the close, learns from every trade,
then (if enabled) trades the after-hours and overnight sessions, and sleeps until the next
session. It keeps running day after day until you press Stop."""
import json
import logging
import threading
import traceback
import uuid
from collections import deque
from dataclasses import dataclass, asdict, fields
from datetime import datetime, timedelta

from . import db
from .config import DATA_DIR
from .indicators import enrich, ribbon_state
from .learner import EXIT_PROFILES, Learner, time_bucket
from .quotebars import QuoteBars
from .risk import RiskManager
from .sessions import EXT_NAMES, bot_day, current_session, next_session
from .setups import rank_setups
from .strategies import find_ext_signals, find_signals, market_bias, ribbon_why

log = logging.getLogger("autobot")
MIN_SCORE = 0.10   # learner score a setup must reach before the bot takes it
DB_COLS = {"id", "day", "mode", "symbol", "side", "strategy", "exit_profile", "bucket", "qty", "entry", "stop",
           "target", "risk", "opened_at", "closed_at", "exit", "pnl", "r", "status", "note"}
DAY_STATE = DATA_DIR / "day_state.json"
RUN_STATE = DATA_DIR / "run_state.json"        # was the bot running? (auto-resume after the app is killed)
ENGINE_STATE = DATA_DIR / "engine_state.json"  # open trades + today's halt / brakes, restored on restart


def _dt(v):
    return datetime.fromisoformat(v) if isinstance(v, str) and v else None


def was_running() -> bool:
    try:
        return bool(json.loads(RUN_STATE.read_text()).get("running"))
    except Exception:
        return False


@dataclass
class Trade:
    id: str
    symbol: str
    side: str
    strategy: str
    exit_profile: str
    bucket: str
    qty: float
    entry: float
    stop_init: float
    stop: float
    target: float
    atr: float
    risk: float
    opened_at: datetime
    order_id: str
    status: str = "pending"      # pending -> open -> closed
    last_price: float = 0.0
    note: str = ""
    day: str = ""
    mode: str = ""
    ext: bool = False            # extended-hours trade (bot-managed stop/target)
    session: str = "REGULAR"
    tp_order_id: str = ""
    exit_order_id: str = ""
    exit_tries: int = 0
    exit_sent_at: datetime | None = None
    qty0: float = 0.0            # shares at entry (before any profit-taking)
    scaled: int = 0              # profit-taking steps done
    realized: float = 0.0        # P&L already banked by partial exits
    pos_ticks: int = 0           # scalps: how many checks in a row the trade has been in profit
    peak_r: float = 0.0          # scalps: best R seen
    partial_oid: str = ""        # extended hours: working partial take-profit order
    partial_px: float = 0.0

    @property
    def dir(self):
        return 1 if self.side == "buy" else -1

    def r_now(self, price):
        r0 = abs(self.entry - self.stop_init)
        return (price - self.entry) * self.dir / r0 if r0 else 0.0

    def row(self, **kw):
        d = {k: v for k, v in asdict(self).items() if k in DB_COLS}
        d["stop"] = self.stop_init
        d["opened_at"] = self.opened_at.isoformat()
        d.update(kw)
        return d


class Engine:
    def __init__(self, settings, broker, learner: Learner):
        self.s = settings
        self.broker = broker
        self.learner = learner
        self.risk = RiskManager(settings)
        self.mode = "PAPER" if getattr(broker, "paper", True) else "LIVE"
        self.running = False
        self.thread = None
        self.lock = threading.RLock()
        self.trades: dict[str, Trade] = {}
        self.cooldown: dict[str, datetime] = {}
        self.universe, self.gaps = [], {}
        self.reg_universe = []
        self.last_scan = None
        self.ext_last_scan = None
        self.ext_moves = {}
        self.ext_key = None
        self.qbars = QuoteBars()
        self.stale = set()
        self.scan_info = []
        self.session = None
        self._base = (None, None)
        self.day = ""
        self.state = "STOPPED"
        self.bias = 0
        self.acct = {}
        self.positions = {}
        self.events = deque(maxlen=300)
        self.skips = deque(maxlen=400)          # 'Why no trade?' log: signals that were rejected, and why
        self._skip_seen = {}
        self.entries_blocked_reason = ""
        self.ribbons = {}
        self.raw = {}
        self.loss_streak = 0
        self.pause_until = None
        self.sym_losses: dict[str, int] = {}
        self.exit_lock = threading.Lock()
        self.alerts = None                 # set by the server: autobot.alerts.Alerts
        self.manual_syms: dict = {}
        self.profit_locks: dict = {}
        self.evfilter = None               # autobot.events.Events: earnings / risky-news filter
        self._ev_logged = {}       # after a halt: symbol -> price that banks >= half the open profit        # symbol -> bot day you traded it by hand: the bot keeps out that day

    # ---------------- control ----------------
    def start(self, resumed=False):
        if self.running:
            return
        if self.mode != "SIM":
            self._restore_state()
        self.running = True
        self.state = "STARTING"
        self._set_run_state(True)
        self.thread = threading.Thread(target=self._run, daemon=True, name="autobot")
        self.thread.start()
        self.event(f"Auto-trader {'resumed after a restart' if resumed else 'started'} ({self.mode}), "
                   f"daily max loss ${self.s.daily_max_loss:,.0f}")

    def stop(self, flatten=False):
        self.running = False
        self._set_run_state(False)
        if flatten:
            self.flatten("manual stop")
        self.state = "STOPPED"
        self._save_state()
        self.event("Auto-trader stopped" + (" and flattened" if flatten else " (open positions keep their server-side stop/target)"))

    # ---------------- survive restarts (Android can kill the app) ----------------
    def _set_run_state(self, running):
        if self.mode == "SIM":
            return
        try:
            RUN_STATE.write_text(json.dumps({"running": running, "mode": self.mode,
                                             "at": datetime.now().isoformat(timespec="seconds")}))
        except Exception:
            pass

    def _save_state(self):
        if self.mode == "SIM" or not self.day:
            return
        with self.lock:
            trades = []
            for t in self.trades.values():
                d = asdict(t)
                d["opened_at"] = t.opened_at.isoformat()
                d["exit_sent_at"] = t.exit_sent_at.isoformat() if t.exit_sent_at else None
                trades.append(d)
        st = {"day": self.day, "mode": self.mode, "trades": trades,
              "halted": self.risk.halted, "halt_reason": self.risk.halt_reason, "peak_pnl": self.risk.peak_pnl,
              "loss_streak": self.loss_streak, "sym_losses": self.sym_losses,
              "pause_until": self.pause_until.isoformat() if self.pause_until else None,
              "cooldown": {k: v.isoformat() for k, v in self.cooldown.items()},
              "entries_blocked_reason": self.entries_blocked_reason, "manual_syms": self.manual_syms, "profit_locks": self.profit_locks}
        try:
            tmp = ENGINE_STATE.with_suffix(".tmp")
            tmp.write_text(json.dumps(st))
            tmp.replace(ENGINE_STATE)
        except Exception as e:
            log.warning("Could not save engine state: %s", e)

    def _restore_state(self):
        try:
            st = json.loads(ENGINE_STATE.read_text())
        except Exception:
            return
        if st.get("mode") != self.mode:
            return
        try:
            now = self.broker.now()
            today = bot_day(now)
            if st.get("day") == today and self.day in ("", today) and not getattr(self, "_restored", False):
                self._restored = True
                self.day = today
                self.risk.halted = bool(st.get("halted"))
                self.risk.halt_reason = st.get("halt_reason", "")
                self.risk.peak_pnl = float(st.get("peak_pnl") or 0)
                self.loss_streak = int(st.get("loss_streak") or 0)
                self.sym_losses = dict(st.get("sym_losses") or {})
                self.pause_until = _dt(st.get("pause_until"))
                self.cooldown = {k: _dt(v) for k, v in (st.get("cooldown") or {}).items() if v}
                self.entries_blocked_reason = st.get("entries_blocked_reason", "")
                self.manual_syms.update(st.get("manual_syms") or {})
                self.profit_locks.update(st.get("profit_locks") or {})
            saved = st.get("trades") or []
            if not saved:
                return
            positions = self.broker.positions()
            restored = []
            for d in saved:
                d["opened_at"] = _dt(d.get("opened_at"))
                d["exit_sent_at"] = _dt(d.get("exit_sent_at"))
                known = {f.name for f in fields(Trade)}
                t = Trade(**{k: v for k, v in d.items() if k in known})     # tolerate other versions' fields
                # an open trade is only ours if the position still exists; pending orders get reconciled
                if t.status == "open" and t.symbol not in positions:
                    t.last_price = t.last_price or t.entry   # closed while we were down: reconcile records it
                with self.lock:
                    if t.symbol not in self.trades:
                        self.trades[t.symbol] = t
                        restored.append(t.symbol)
            if restored:
                self.event(f"Restored {len(restored)} bot trade(s) after restart: {', '.join(restored)}", "warning")
        except Exception as e:
            self.event(f"Could not restore saved trades: {e}", "warning")

    def alert(self, kind, title, body="", **kw):
        if self.alerts:
            try:
                tag = {"PAPER": "[PAPER] ", "SIM": "[SIM] ", "LIVE": "🔴 LIVE · "}.get(self.mode, "")
                self.alerts.send(kind, tag + title, body, **kw)
            except Exception:
                pass

    def _skip(self, sym, strategy, side, why, now=None):
        """Remember why a signal did not become a trade (deduplicated: same reason at most every 10 min)."""
        try:
            now = now or self.broker.now()
            k = (sym, strategy, why)
            last = self._skip_seen.get(k)
            if last and (now - last).total_seconds() < 600:
                return
            self._skip_seen[k] = now
            if len(self._skip_seen) > 2000:
                self._skip_seen = {kk: v for kk, v in self._skip_seen.items() if (now - v).total_seconds() < 600}
            self.skips.appendleft({"t": now.strftime("%a %H:%M"), "symbol": sym, "strategy": strategy,
                                   "side": side, "why": why})
        except Exception:
            pass

    def _can_short(self, sym):
        """(ok, reason). Shorting needs the setting on, an account that can short, and a shortable stock."""
        if not self.s.allow_shorts:
            return False, "shorting is switched off in Controls"
        if not self.acct.get("shorting_enabled", True):
            return False, "your Alpaca account can't short (needs a margin account)"
        if not self.broker.shortable(sym):
            return False, "not shortable / hard to borrow at Alpaca"
        return True, ""

    def event(self, msg, level="info"):
        ts = self.broker.now().strftime("%m-%d %H:%M:%S")
        self.events.appendleft({"t": ts, "msg": msg, "level": level})
        getattr(log, level if level in ("info", "warning", "error") else "info")(msg)

    # ---------------- main loop ----------------
    def _run(self):
        while self.running:
            wait = self.s.tick_seconds
            try:
                w = self.tick()
                if w:
                    wait = w
            except Exception as e:
                self.event(f"Loop error: {e}", "error")
                self.alert("system", "Bot error", str(e)[:180])
                log.debug(traceback.format_exc())
                wait = max(self.s.tick_seconds, 30)
            self._save_state()
            # sleep in small slices so Stop is responsive
            slept = 0
            while self.running and slept < wait:
                step = min(5, wait - slept)
                self.broker.sleep(step)
                slept += step

    def _ext_enabled(self, name):
        return {"PRE": self.s.ext_premarket, "AFTER": self.s.ext_afterhours,
                "OVERNIGHT": self.s.ext_overnight}.get(name, False)

    def _ext_window(self, sess):
        """Free IEX data only covers ~8:00 AM - 5:00 PM ET, so on IEX the bot trades pre-market from 8:00
        and after-hours until 5:00 PM only (SIP covers the full 4 AM - 8 PM; overnight uses its own feed)."""
        start, end = sess.start, sess.end
        if self.s.data_feed == "iex":
            if sess.name == "PRE":
                start = max(start, sess.start.replace(hour=8, minute=0))
            elif sess.name == "AFTER":
                end = min(end, sess.start.replace(hour=17, minute=0))
        return start, end

    def _enabled_names(self):
        return ["REGULAR"] + [n for n in EXT_NAMES if self._ext_enabled(n)]

    def tick(self):
        now = self.broker.now()
        bd = bot_day(now)
        if bd != self.day:
            self._new_day(bd)

        sess = current_session(self.broker.trading_day, now)
        self.session = sess
        if sess and sess.name in EXT_NAMES and self._ext_enabled(sess.name):
            win = self._ext_window(sess)
            if win[0] <= now < win[1]:
                return self._ext_tick(sess, now, win[1])
        if any(t.ext for t in list(self.trades.values())):
            self._ext_orphans(now)

        clk = self.broker.clock()
        if not clk["is_open"]:
            mins = (clk["next_open"] - now).total_seconds() / 60
            if self.trades:
                self.positions = self.broker.positions()
                self._reconcile()
            if mins <= 20 and not self.last_scan:
                self.state = "PRE-MARKET SCAN"
                self._scan()
            nxt = next_session(self.broker.trading_day, now, self._enabled_names())
            wait = max(30, min(600, (mins - 19) * 60)) if mins > 20 else 60
            if nxt and nxt.name != "REGULAR":
                wait = max(5, min(wait, (nxt.start - now).total_seconds() + 1))
                self.state = f"WAITING FOR {nxt.label.upper()} ({nxt.start.strftime('%a %H:%M')})"
            else:
                self.state = f"WAITING FOR OPEN ({clk['next_open'].strftime('%a %H:%M')})"
            return wait

        self.acct = self.broker.account()
        self.positions = self.broker.positions()
        if self.risk.update(self.acct["equity"], self._baseline()):
            self.event(f"HALT: {self.risk.halt_reason} — flattening account", "warning")
            n, kept = self.close_losers(self.risk.halt_reason)
            self.alert("halt", "🛑 Trading halted for today",
                       f"{self.risk.halt_reason}. Day P&L ${self.risk.day_pnl:,.2f}. Closed {n} losing position(s)"
                       + (f"; kept winners: {', '.join(kept)}" if kept else "") + ".", level="warning")
        self._reconcile()

        if self.risk.halted:
            self.state = "HALTED: " + self.risk.halt_reason + " (protecting winners, no new trades)"
            self.guard_profits()
            if self.trades:
                symbols = [t.symbol for t in self.trades.values()]
                raw = self.broker.bars(symbols)
                self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
                self._manage({k: enrich(v) for k, v in raw.items() if len(v) >= 3}, now)
                return 30
            return 60
        if self.acct.get("blocked"):
            self.state = "ACCOUNT BLOCKED"
            self.alert("restrict", "Account blocked", "Alpaca reports the account is blocked from trading.")
            return 120

        mins_to_close = (clk["next_close"] - now).total_seconds() / 60
        if mins_to_close <= self.s.flatten_min_before_close:
            if self.trades:
                self.event("End of day: flattening bot positions")
                self.flatten("EOD")
            self.state = "SESSION DONE"
            return 60

        if not self.last_scan or (now - self.last_scan) > timedelta(minutes=30):
            self._scan()

        symbols = list(dict.fromkeys(self.universe + [t.symbol for t in self.trades.values()] + self.s.watch_always))
        raw = self.broker.bars(symbols)
        self.raw = raw
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 3}
        self.bias = market_bias(bars, tuple(self.s.watch_always))
        self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
        try:
            self.setups = rank_setups(bars, self.ribbons, self.scan_info, tuple(self.s.watch_always))
        except Exception:
            pass

        self._manage(bars, now)

        mins_since_open = (now - now.replace(hour=9, minute=30, second=0, microsecond=0)).total_seconds() / 60
        if mins_to_close > self.s.no_new_entries_min_before_close and mins_since_open >= 5:
            self.state = "TRADING"
            self._entries(bars, now)
        else:
            self.state = "MANAGING (no new entries)"
        return 10 if self.aggro else None      # aggressive scalping checks every 10 s

    def _new_day(self, today):
        self.day = today
        self.risk.new_day()
        self.learner.daily_decay(today)
        self.universe, self.gaps, self.last_scan = [], {}, None
        self.ext_last_scan = None
        self.cooldown.clear()
        self.profit_locks.clear()
        self.entries_blocked_reason = ""
        self.loss_streak, self.pause_until, self.sym_losses = 0, None, {}
        self.event(f"New trading day {today} (daily loss limit window runs 8 PM -> 8 PM ET)")

    def _baseline(self):
        """Equity at the start of the bot day (8 PM ET), persisted so restarts don't reset the limit."""
        if self._base[0] == self.day:
            return self._base[1]
        try:
            st = json.loads(DAY_STATE.read_text())
            if st.get("day") == self.day and st.get("mode", self.mode) == self.mode and \
                    self._sane_base(float(st["baseline"])):
                self._base = (self.day, float(st["baseline"]))
                return self._base[1]
        except Exception:
            pass
        sess = self.session.name if self.session else ""
        base = self.acct["last_equity"] if sess in ("PRE", "REGULAR", "AFTER") else self.acct["equity"]
        self._base = (self.day, float(base))
        try:
            DAY_STATE.write_text(json.dumps({"day": self.day, "mode": self.mode, "baseline": self._base[1]}))
        except Exception:
            pass
        return self._base[1]

    def _sane_base(self, base):
        """A saved start-of-day equity from another account (e.g. PAPER $100k after switching to LIVE)
        would look like a huge loss and flatten everything. Reject anything wildly off today's equity."""
        eq = (self.acct or {}).get("equity")
        if not eq or base <= 0:
            return base > 0
        return abs(eq - base) <= max(0.5 * eq, 3 * float(self.s.daily_max_loss))

    def _margin_block(self):
        """FINRA retired the PDT rule on June 4, 2026 (Alpaca: Intraday Margin Framework). There is no
        day-trade count anymore; the limit is intraday buying power, and unmet intraday margin calls
        can restrict the account for 90 days. So pause new bot entries when buying power is nearly gone."""
        a = self.acct or {}
        if self.mode == "SIM" or "buying_power" not in a:
            return False
        low = a["buying_power"] < max(100.0, 0.02 * a.get("equity", 0))
        if low and not self.entries_blocked_reason:
            self.event(f"New entries skipped: buying power is only ${a['buying_power']:,.2f}", "warning")
        return low

    def _scan(self):
        try:
            acct = self.broker.account()
            self.acct = self.acct or acct
        except Exception:
            acct = self.acct or {}
        uni, gaps = self.broker.scan(self.s, acct)
        self.scan_info = getattr(self.broker, "last_scan_info", []) or []
        self.universe, self.gaps = uni, gaps
        self.reg_universe = list(uni)
        self.last_scan = self.broker.now()
        top = ", ".join(f"{u}({gaps.get(u, 0):+.1f}%)" for u in uni[:8])
        self.event(f"Stock picker: {len(uni)} best fits for your account — {top}")

    # ---------------- entries ----------------
    def _entries(self, bars, now):
        with self.lock:
            active = len(self.trades)
        slots = (self.s.max_positions + (2 if self.aggro else 0)) - active
        if slots <= 0 or self.entries_blocked_reason or self._margin_block():
            if self.entries_blocked_reason:
                self._skip("(all)", "-", "", "new entries blocked: " + str(self.entries_blocked_reason), now)
            elif slots > 0:
                self._skip("(all)", "-", "", "margin / buying-power check blocked new entries", now)
            return
        if self.pause_until and not self.s.cooloff_streak:
            self.pause_until = None
        if self.pause_until and now < self.pause_until:
            self.state = f"COOLING OFF until {self.pause_until.strftime('%H:%M')} (loss streak)"
            self._skip("(all)", "-", "", f"cooling off until {self.pause_until.strftime('%H:%M')} after a loss streak", now)
            return
        ctx = {"aggressive": self.aggro, "bias": self.bias, "gap": self.gaps, "shorts": bool(self.s.allow_shorts and self.acct.get("shorting_enabled", True)),
               "index_symbols": set(self.s.watch_always), "ribbon": self.ribbons, "all_flips": self.s.trade_all_flips}
        sigs = find_signals(bars, ctx)
        bucket = time_bucket(now)
        ranked = []
        fired = {(sg.symbol, sg.strategy) for sg in sigs}
        for sym in list(bars):                      # explain ribbon flips that did NOT become a trade
            if sym in ctx["index_symbols"] or (sym, "RIBBON_FLIP") in fired:
                continue
            try:
                w = ribbon_why(sym, bars[sym], ctx)
            except Exception:
                w = None
            if w:
                self._skip(sym, "RIBBON_FLIP", "", w, now)
        for sg in sigs:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, why, now)
            if sg.symbol in self.trades or sg.symbol in self.positions:
                continue
            if self.manual_syms.get(sg.symbol) == self.day:
                no("you traded this symbol manually today — bot leaves it alone")
                continue
            if self.s.cooloff_symbol and self.sym_losses.get(sg.symbol, 0) >= 2:
                no("dropped for today after 2 losses on this symbol (Cooling-off setting)")
                continue
            cd = self.cooldown.get(sg.symbol)
            if cd and now < cd and self.s.cooloff_symbol:
                no(f"symbol cooling off until {cd.strftime('%H:%M')} after a recent trade")
                continue
            if sg.side == "sell":
                ok, why = self._can_short(sg.symbol)
                if not ok:
                    no("short signal skipped — " + why)
                    continue
            ch = self.learner.choose(sg.strategy, bucket, sg.quality)
            force = self.s.trade_all_flips and sg.strategy == "RIBBON_FLIP"
            if force and not ch:
                ch = ("RIBBON", 0.5, 1.0)
            if not ch:
                no("learner: this strategy currently scores too poorly to trade")
                continue
            if ch[1] < (0.0 if (self.aggro or force) else MIN_SCORE):
                no(f"learner score {ch[1]:.2f} is below the minimum {MIN_SCORE:.2f} (strategy is cold)")
                continue
            if not force and self._tod_blocked(now, sg.strategy):
                no(f"time-of-day filter: your own history loses money in this time slot ({time_bucket(now)})")
                continue
            ranked.append((ch[1], sg, ch))
        ranked.sort(key=lambda x: x[0], reverse=True)

        taken = set()
        for score, sg, (ep, _, weight) in ranked:
            if slots <= 0:
                self._skip(sg.symbol, sg.strategy, sg.side, "all position slots are full", now)
                continue
            if sg.symbol in taken:
                continue
            if self._event_block(sg.symbol, now):
                self._skip(sg.symbol, sg.strategy, sg.side, "earnings / risky-news filter", now)
                continue
            open_risk = self._open_risk()
            if self.loss_streak >= 3 and self.s.cooloff_streak:
                weight *= 0.5           # trade smaller while cold
            if self.aggro:
                weight *= 0.6           # more trades -> smaller size each
            dec = self.risk.size(sg.entry, sg.stop, weight, open_risk, self.acct.get("buying_power", 0))
            if dec.qty < 1:
                self._skip(sg.symbol, sg.strategy, sg.side, f"risk sizing gave 0 shares ({dec.reason})", now)
                continue
            ep = self._harvest_profile(ep)
            prof = EXIT_PROFILES[ep]
            r0 = sg.risk_per_share
            d = 1 if sg.side == "buy" else -1
            target = sg.entry + d * prof["target_r"] * r0
            limit = sg.entry * (1 + d * 0.0015)   # marketable limit, max 0.15% slippage
            cid = f"ab-{uuid.uuid4().hex[:12]}"
            try:
                oid = self.broker.submit_bracket(sg.symbol, sg.side, dec.qty, limit, sg.stop, target, cid)
            except Exception as e:
                msg = str(e)
                self.event(f"Order rejected {sg.symbol}: {msg[:160]}", "warning")
                self._skip(sg.symbol, sg.strategy, sg.side, "Alpaca rejected the order: " + msg[:100], now)
                self.alert("reject", f"Order rejected: {sg.symbol}", msg[:160], symbol=sg.symbol)
                low = msg.lower()
                if "pattern day" in low or "day trad" in low or "margin call" in low or "restricted" in low:
                    self.entries_blocked_reason = "Broker restriction (margin / trading rule)"
                    self.event("New entries paused for today (broker restriction: " + msg[:100] + ")", "warning")
                    self.alert("restrict", "New entries paused", "Alpaca restricted new orders: " + msg[:140])
                    return
                continue
            t = Trade(cid, sg.symbol, sg.side, sg.strategy, ep, time_bucket(now), dec.qty, sg.entry, sg.stop,
                      sg.stop, target, sg.atr, dec.risk_dollars, now, oid, day=self.day, mode=self.mode)
            with self.lock:
                self.trades[sg.symbol] = t
            db.upsert(t.row(status="pending"))
            taken.add(sg.symbol)
            slots -= 1
            self.event(f"ENTRY {sg.side.upper()} {dec.qty} {sg.symbol} @{sg.entry:.2f} [{sg.strategy}/{ep}] "
                       f"stop {sg.stop:.2f} target {target:.2f} risk ${dec.risk_dollars:.0f} (w={weight:.2f})")
            self.alert("entry", f"🟢 BOT {'BUY' if sg.side == 'buy' else 'SHORT'} {dec.qty} {sg.symbol} @ {sg.entry:.2f}",
                       f"{sg.strategy} · stop {sg.stop:.2f} · target {target:.2f} · risk ${dec.risk_dollars:.0f}",
                       symbol=sg.symbol, close_btn=True)

    def _event_block(self, sym, now, session="REGULAR"):
        if not self.evfilter:
            return False
        why = self.evfilter.block_reason(sym, now, session)
        if why:
            last = self._ev_logged.get(sym)
            if last is None or (now - last).total_seconds() > 1800:
                self._ev_logged[sym] = now
                self.event(f"Skipping {sym}: {why}")
            return True
        return False

    def _open_risk(self):
        tot = 0.0
        with self.lock:
            for t in self.trades.values():
                px = t.last_price or t.entry
                tot += max(0.0, (px - t.stop) * t.dir) * t.qty
        return tot

    # ---------------- position management ----------------
    def _manage(self, bars, now):
        with self.lock:
            trades = list(self.trades.values())
        for t in trades:
            if t.status != "open" or t.ext:
                continue
            df = bars.get(t.symbol)
            price = float(df["close"].iloc[-1]) if df is not None and len(df) else \
                self.positions.get(t.symbol, {}).get("price", t.entry)
            t.last_price = price
            prof = EXIT_PROFILES[t.exit_profile]
            r = t.r_now(price)
            if self._quick_harvest(t, r):
                self.event(f"💰 HARVEST {t.symbol}: banked at {r:+.2f}R (momentum stalled) — free to re-enter")
                t.note = "harvest"
                self._close(t)
                continue
            steps = prof.get("scale") or []
            if t.scaled < len(steps) and r >= steps[t.scaled][0]:
                self._take_partial(t, price, r, steps[t.scaled][1])
            new_stop = t.stop
            if prof["be_at_r"] is not None and r >= prof["be_at_r"]:
                be = t.entry + t.dir * 0.02 * abs(t.entry - t.stop_init)
                new_stop = max(new_stop, be) if t.dir > 0 else min(new_stop, be)
            if prof["trail_after_r"] is not None and r >= prof["trail_after_r"]:
                atr = float(df["atr"].iloc[-1]) if df is not None else t.atr
                tr = price - t.dir * prof["trail_atr"] * atr
                new_stop = max(new_stop, tr) if t.dir > 0 else min(new_stop, tr)
            if (new_stop - t.stop) * t.dir > 0.001 * t.entry:
                ok = self.broker.update_stop(t.symbol, new_stop)
                t.stop = new_stop
                self.event(f"Stop -> {new_stop:.2f} on {t.symbol} ({r:.1f}R){'' if ok else ' [soft stop]'}")
                self.alert("breakeven", f"Stop raised on {t.symbol} → {new_stop:.2f}", f"Trade is at {r:+.1f}R",
                           symbol=t.symbol, close_btn=True)
            # soft stop (covers trailing stops the server leg couldn't be moved to)
            if (price - t.stop) * t.dir <= 0 and t.stop != t.stop_init:
                self.event(f"EXIT {t.symbol}: trailing/breakeven stop hit @{price:.2f}")
                t.note = "trail stop"
                self._close(t)
                continue
            rb = self.ribbons.get(t.symbol)
            if prof.get("exit_on_flip") and rb and rb["ready"] and rb["state"] == -t.dir:
                self.event(f"EXIT {t.symbol}: ribbon flipped {'red' if t.dir > 0 else 'green'} @{price:.2f} ({r:+.2f}R)")
                t.note = "ribbon flip"
                self._close(t)
                continue
            age = (now - t.opened_at).total_seconds() / 60
            riding = prof.get("exit_on_flip") and rb and rb["state"] == t.dir
            if age >= prof.get("time_stop", self.s.time_stop_minutes) and r < 0.3 and not riding:
                self.event(f"EXIT {t.symbol}: time stop after {age:.0f}m ({r:.2f}R)")
                t.note = "time stop"
                self._close(t)

    @property
    def aggro(self):
        return bool(getattr(self.s, "aggressive_scalp", False))

    def end_cooloff(self):
        """'Resume now': clear the loss-streak pause, the half-size penalty and symbol cooldowns for today."""
        self.pause_until, self.loss_streak = None, 0
        self.cooldown.clear()
        self.sym_losses = {}
        self.event("Cooling off cleared — trading resumes at full size")

    def refresh_setups(self):
        """🎯 On-demand 'Setting up now' list (Scan now), also when the bot is stopped or the market is closed."""
        syms = list(dict.fromkeys(self.universe + list(self.s.watchlist)))[:40]
        raw = self.broker.bars(syms) if syms else {}
        if sum(1 for v in raw.values() if len(v) >= 30) < 3 and hasattr(self.broker, "analysis_bars"):
            raw = {}
            for sm in syms[:30]:                       # market closed: use each stock's latest session
                try:
                    df, _ = self.broker.analysis_bars(sm)
                    if df is not None and len(df) >= 30:
                        raw[sm] = df
                except Exception:
                    continue
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 30}
        rib = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 30}
        self.setups = rank_setups(bars, rib, self.scan_info, tuple(self.s.watch_always))
        return self.setups

    def _harvest_profile(self, ep):
        """Profit harvesting in every session: aggressive scalp, then scalp, then take-profit-along-the-way."""
        if self.aggro:
            return "AGGRO"
        if getattr(self.s, "scalp_mode", False):
            return "SCALP"
        if getattr(self.s, "scale_out", False):
            return "SCALE"
        return ep

    def _quick_harvest(self, t, r):
        """Scalps (AGGRO / SCALP): once a trade has been green for 2+ checks, don't wait for the target —
        bank it as soon as momentum stalls (gives back 0.15R from its best) or it's near the target."""
        if t.exit_profile not in ("AGGRO", "SCALP"):
            return False
        t.peak_r = max(t.peak_r, r)
        t.pos_ticks = t.pos_ticks + 1 if r >= 0.25 else 0
        tgt = EXIT_PROFILES[t.exit_profile]["target_r"]
        return t.pos_ticks >= 2 and (r <= t.peak_r - 0.15 or r >= 0.85 * tgt) and r > 0.1

    def _take_partial(self, t, price, r, frac):
        """💰 Take profit along the way: sell part, move the stop on the rest to break-even or better."""
        q = int(t.qty * frac)
        if q < 1 or q >= t.qty:
            t.scaled += 1
            return
        be = t.entry + t.dir * 0.02 * abs(t.entry - t.stop_init)
        new_stop = max(t.stop, be) if t.dir > 0 else min(t.stop, be)
        try:
            rem = self.broker.partial_exit(t.symbol, q, t.side, new_stop, t.target)
        except Exception as e:
            self.event(f"Partial take-profit on {t.symbol} failed: {str(e)[:140]}", "warning")
            t.scaled += 1
            return
        gain = (price - t.entry) * t.dir * q
        t.realized += gain
        t.qty0 = t.qty0 or t.qty
        t.qty = rem or (t.qty - q)
        t.stop = new_stop
        t.scaled += 1
        self.event(f"💰 TOOK PROFIT {t.symbol}: sold {q} @~{price:.2f} (+{r:.1f}R, ${gain:,.2f}); "
                   f"{t.qty:g} left, stop → {new_stop:.2f}")
        self.alert("profit", f"💰 Took profit {t.symbol} +${gain:,.2f}",
                   f"Sold {q} at +{r:.1f}R · {t.qty:g} left riding · stop {new_stop:.2f}", symbol=t.symbol, close_btn=True)

    def _tod_blocked(self, now, strategy=""):
        """Skip times of day where your own trade history loses money (Positions → Trading stats)."""
        if not getattr(self.s, "tod_filter", False):
            return False
        from . import stats as st
        if not hasattr(self, "_tod") or (now - self._tod[0]).total_seconds() > 6 * 3600:
            by = {}
            try:
                by = st.summarize(st.round_trips(st.fetch_fills(self.broker, 90)), (), 90)["by_bucket"]
            except Exception:
                by = {}
            self._tod = (now, by)
            bad = [b for b, v in by.items() if v["trades"] >= self.s.tod_min_trades and v["pnl"] < 0]
            if bad:
                self.event("Time-of-day filter (from your last 90 days): skipping " + ", ".join(bad))
        b = st.bucket(now)
        v = self._tod[1].get(b)
        if not v or v["trades"] < self.s.tod_min_trades or v["pnl"] >= 0:
            return False
        # your best trades are opening drives: allowed in the first 20 minutes even if the morning loses overall
        if strategy.startswith("OPEN_DRIVE") and now.hour == 9 and now.minute < 50:
            return False
        if strategy.startswith("FLUSH"):          # sudden flushes can happen any time; always allowed
            return False
        return True

    def _close(self, t):
        ok = self.broker.close_position(t.symbol)
        if ok is False and not getattr(t, "_close_warned", False):
            t._close_warned = True
            err = getattr(self.broker, "last_close_error", "")
            self.event(f"Could not close {t.symbol}: {err[:160]}", "error")
            self.alert("reject", f"⚠ Close failed: {t.symbol}", (err[:160] or "") + " — check the position in Alpaca.",
                       symbol=t.symbol, level="warning")

    def _reconcile(self):
        now = self.broker.now()
        with self.lock:
            trades = list(self.trades.values())
        for t in trades:
            pos = self.positions.get(t.symbol)
            if t.status == "pending":
                st, px, fq = self.broker.entry_status(t.order_id)
                if st in ("filled", "partially_filled") or pos:
                    if st == "partially_filled":
                        self.broker.cancel(t.order_id)
                    t.status = "open"
                    if px:
                        t.entry = px
                    if pos:
                        t.qty = abs(pos["qty"])
                    elif fq:
                        t.qty = fq
                    db.upsert(t.row(status="open", entry=t.entry))
                    self.event(f"FILLED {t.symbol} {t.qty:g} @{t.entry:.2f}")
                    self.alert("fill", f"Filled {t.symbol} {t.qty:g} @ {t.entry:.2f}", t.strategy,
                               symbol=t.symbol, close_btn=True)
                elif st in ("canceled", "expired", "rejected", "done_for_day") or \
                        (now - t.opened_at) > timedelta(seconds=90 if t.ext else 120):
                    self.broker.cancel(t.order_id)
                    with self.lock:
                        self.trades.pop(t.symbol, None)
                    db.upsert(t.row(status="cancelled", note=f"entry {st}"))
                    self.event(f"Entry not filled for {t.symbol} ({st}) — cancelled")
                continue
            if t.status == "open" and not pos:
                exit_side = "sell" if t.side == "buy" else "buy"
                px = self.broker.last_exit_price(t.symbol, t.opened_at, exit_side) or t.last_price or t.entry
                pnl = (px - t.entry) * t.dir * t.qty + t.realized
                r0 = abs(t.entry - t.stop_init) * (t.qty0 or t.qty)
                r = pnl / r0 if r0 else t.r_now(px)
                if t.ext:
                    self.broker.cancel_symbol_orders(t.symbol)
                self.learner.record(t.strategy, t.exit_profile, t.bucket, r)
                db.upsert(t.row(status="closed", exit=round(px, 4), pnl=round(pnl, 2), r=round(r, 3),
                                closed_at=now.isoformat(), note=t.note))
                with self.lock:
                    self.trades.pop(t.symbol, None)
                if pnl < 0:
                    self.loss_streak += 1
                    self.sym_losses[t.symbol] = self.sym_losses.get(t.symbol, 0) + 1
                    self.cooldown[t.symbol] = now + timedelta(minutes=10 if self.aggro else 30)
                    if self.loss_streak % 3 == 0 and self.s.cooloff_streak:
                        self.pause_until = now + timedelta(minutes=20)
                        self.event(f"{self.loss_streak} losses in a row — pausing new entries 20 min, half size after", "warning")
                        self.alert("streak", f"{self.loss_streak} losses in a row",
                                   "New entries paused 20 min, then half size.", level="warning")
                else:
                    self.loss_streak = 0
                    self.cooldown[t.symbol] = now + (timedelta(seconds=0) if t.note == "harvest" else
                                                     timedelta(minutes=2 if self.aggro else 10))
                self.event(f"CLOSED {t.symbol} @{px:.2f}  P&L ${pnl:,.2f} ({r:+.2f}R) [{t.strategy}/{t.exit_profile}]",
                           "info" if pnl >= 0 else "warning")
                self.alert("exit", f"{'✅' if pnl >= 0 else '🔻'} BOT CLOSED {t.symbol} {'+' if pnl >= 0 else '-'}${abs(pnl):,.2f} ({r:+.2f}R)",
                           f"Exit {px:.2f} · {t.note or 'target/stop'} · day P&L ${self.risk.day_pnl:,.2f}",
                           symbol=t.symbol, pnl=round(pnl, 2))

    def close_losers(self, reason, sess_name=None):
        """Daily limit hit: close every position that is losing money (bot and manual), keep the winners
        (they keep their stops; bot trades are still managed). Pending bot entries are cancelled."""
        closed, kept = 0, []
        try:
            pos = self.broker.positions()
            with self.lock:
                trades = dict(self.trades)
            for sym, t in trades.items():
                if t.status == "pending":
                    self.broker.cancel(t.order_id)
            ext_q = self.broker.quotes(list(pos), sess_name) if sess_name else {}
            for sym, p in pos.items():
                if p.get("upl", 0) >= 0:
                    kept.append(sym)
                    continue
                t = trades.get(sym)
                if sess_name:            # extended hours: limit orders only
                    q = ext_q.get(sym)
                    if t and t.ext:
                        if not t.exit_order_id:
                            self._ext_exit(t, reason, (q[1] if t.dir < 0 else q[0]) if q else (t.last_price or t.entry))
                    else:
                        self.broker.cancel_symbol_orders(sym)
                        px = (q[0] if p["qty"] > 0 else q[1]) if q else p["price"]
                        side = "sell" if p["qty"] > 0 else "buy"
                        lim = px * (0.995 if side == "sell" else 1.005)
                        self.broker.submit_limit_ext(sym, side, abs(p["qty"]), lim, f"abh-{uuid.uuid4().hex[:12]}")
                else:
                    if t:
                        t.note = reason
                        self._close(t)
                    else:
                        self.broker.close_position(sym)
                closed += 1
                self.event(f"Closed loser {sym} (${p.get('upl', 0):,.2f}) — daily limit")
            for sym in kept:
                self._lock_update(sym, pos[sym])
            if kept:
                self.event(f"Kept winners open with a profit lock (sells if half the gain is given back): "
                           + ", ".join(f"{k} ≥ {self.profit_locks[k]:.2f}" for k in kept if k in self.profit_locks))
        except Exception as e:
            self.event(f"Close-losers error: {e}", "error")
        try:
            self.broker.sleep(2)
            self.positions = self.broker.positions()
            self._reconcile()
        except Exception:
            pass
        return closed, kept

    def _lock_update(self, sym, p):
        """Profit lock = entry + 50% of the best open gain seen (ratchets only in the profit direction)."""
        qty, avg, px = p["qty"], p.get("avg_entry") or 0, p.get("price") or 0
        if not avg or not px:
            return
        d = 1 if qty > 0 else -1
        gain = (px - avg) * d
        if gain <= 0 and sym not in self.profit_locks:
            return
        lock = avg + d * 0.5 * max(gain, 0) + d * 0.001 * avg   # never below break-even (+fees cushion)
        old = self.profit_locks.get(sym)
        self.profit_locks[sym] = lock if old is None else (max(old, lock) if d > 0 else min(old, lock))
        t = self.trades.get(sym)
        if t and t.status == "open" and (self.profit_locks[sym] - t.stop) * t.dir > 0:
            t.stop = self.profit_locks[sym]
            if not t.ext:
                self.broker.update_stop(sym, t.stop)

    def guard_profits(self, sess_name=None):
        """While halted: ratchet each kept winner's lock and take the profit if price falls back to it."""
        if not self.profit_locks:
            return
        try:
            pos = self.broker.positions()
        except Exception:
            return
        q = self.broker.quotes(list(self.profit_locks), sess_name) if sess_name else {}
        for sym in list(self.profit_locks):
            p = pos.get(sym)
            if not p:
                self.profit_locks.pop(sym, None)
                continue
            d = 1 if p["qty"] > 0 else -1
            px = (q[sym][0] if d > 0 else q[sym][1]) if sym in q else p["price"]
            p = dict(p, price=px)
            self._lock_update(sym, p)
            lock = self.profit_locks[sym]
            if (px - lock) * d <= 0:
                gain = (px - p["avg_entry"]) * p["qty"]
                self.event(f"TAKE PROFIT {sym} @{px:.2f} (profit lock {lock:.2f}) ≈ ${gain:,.2f}")
                self.alert("exit", f"💰 Took profit on {sym} ≈ +${gain:,.2f}", f"Price fell back to the profit lock {lock:.2f}",
                           symbol=sym, pnl=round(gain, 2))
                t = self.trades.get(sym)
                if sess_name:
                    if t and t.ext:
                        self._ext_exit(t, "profit lock", px)
                    else:
                        self.broker.cancel_symbol_orders(sym)
                        side = "sell" if d > 0 else "buy"
                        self.broker.submit_limit_ext(sym, side, abs(p["qty"]), px * (0.997 if d > 0 else 1.003),
                                                     f"abp-{uuid.uuid4().hex[:12]}")
                elif t:
                    t.note = "profit lock"
                    self._close(t)
                else:
                    self.broker.close_position(sym)
                self.profit_locks.pop(sym, None)

    def flatten(self, reason, whole_account=False):
        try:
            if whole_account:
                self.broker.close_all()
            else:
                with self.lock:
                    syms = list(self.trades)
                ext_syms = [x for x in syms if self.trades.get(x) and self.trades[x].ext]
                qs = self.broker.quotes(ext_syms, self.session.name if self.session else "AFTER") if ext_syms else {}
                for s in syms:
                    t = self.trades.get(s)
                    if t and t.status == "pending":
                        self.broker.cancel(t.order_id)
                    elif t and t.ext:
                        if not t.exit_order_id:
                            q = qs.get(s)
                            self._ext_exit(t, reason, (q[1] if t.dir < 0 else q[0]) if q else (t.last_price or t.entry))
                    else:
                        if t:
                            t.note = reason
                        self.broker.close_position(s)
        except Exception as e:
            self.event(f"Flatten error: {e}", "error")
        # let the next reconcile pick up exit fills
        try:
            self.broker.sleep(2)
            self.positions = self.broker.positions()
            self._reconcile()
        except Exception:
            pass

    # ================= extended hours: pre-market / after-hours / overnight =================
    # Limit orders only, no server-side brackets -> the bot holds a resting take-profit order
    # and watches the stop itself every few seconds. Long-only, half risk, max 2 positions,
    # and every position is closed before its session ends.
    def _ext_tick(self, sess, now, eff_end=None):
        eff_end = eff_end or sess.end
        key = (sess.name, sess.start)
        if key != self.ext_key:
            self.ext_key = key
            self.qbars.reset()
            self.ext_last_scan = None
            self.event(f"{sess.label} session started (ends {sess.end.strftime('%H:%M')} ET)")

        self.acct = self.broker.account()
        self.positions = self.broker.positions()
        if self.risk.update(self.acct["equity"], self._baseline()):
            self.event(f"HALT: {self.risk.halt_reason} — closing losing positions", "warning")
            n, kept = self.close_losers(self.risk.halt_reason, sess.name)
            self.alert("halt", "🛑 Trading halted for today",
                       f"{self.risk.halt_reason}. Day P&L ${self.risk.day_pnl:,.2f}. Closed {n} losing position(s)"
                       + (f"; kept winners: {', '.join(kept)}" if kept else "") + ".", level="warning")
        self._reconcile()
        self._ext_place_targets()
        if self.acct.get("blocked"):
            self.state = "ACCOUNT BLOCKED"
            return 120
        if self.risk.halted:
            self.state = "HALTED: " + self.risk.halt_reason + " (protecting winners, no new trades)"
            self.guard_profits(sess.name)
            if any(t.ext for t in self.trades.values()):
                symbols = [t.symbol for t in self.trades.values()]
                quotes = self.broker.quotes(symbols, sess.name)
                self._ext_manage({}, quotes, now)
            return 15

        if not self.ext_last_scan or (now - self.ext_last_scan) > timedelta(minutes=15):
            uni, moves = self.broker.ext_scan(self.s, sess.name, extra=self.reg_universe[:10])
            changed = set(uni) != set(self.universe) or self.ext_last_scan is None
            self.universe, self.gaps, self.ext_moves = uni, moves, moves
            self.ext_last_scan = now
            if changed:
                top = ", ".join(f"{u}({moves.get(u, 0):+.1f}%)" for u in uni[:8])
                self.event(f"{sess.label} scanner: {len(uni)} movers — {top or 'none yet'}")

        symbols = list(dict.fromkeys(self.universe + [t.symbol for t in self.trades.values()]))
        quotes = self.broker.quotes(symbols, sess.name)
        self.stale = {sym for sym, (_, _, ts) in quotes.items() if ts and (now - ts).total_seconds() > 300}
        for sym, (b, a, ts) in quotes.items():
            if sym not in self.stale:
                self.qbars.update(sym, b, a, now)
        if sess.name == "OVERNIGHT":
            raw = {sm: f for sm in symbols if (f := self.qbars.frame(sm)) is not None and len(f) >= 3}
        else:
            raw = self.broker.bars(symbols, start=sess.start - timedelta(minutes=60))
        self.raw = raw
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 3}
        self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
        try:
            self.setups = rank_setups(bars, self.ribbons, self.scan_info, tuple(self.s.watch_always))
        except Exception:
            pass

        self._ext_manage(bars, quotes, now)

        mins_left = (eff_end - now).total_seconds() / 60
        if mins_left <= 10:
            if any(t.ext and not t.exit_order_id for t in self.trades.values()):
                self.event(f"{sess.label} trading window ends at {eff_end.strftime('%H:%M')} — closing positions")
                self.flatten(f"{sess.name} session end")
            self.state = f"{sess.label.upper()}: closing out"
        elif mins_left > 25:
            self.state = f"{sess.label.upper()} TRADING"
            self._ext_entries(bars, quotes, now, sess)
        else:
            self.state = f"{sess.label.upper()}: managing (no new entries)"
        return 5 if self.aggro else self.s.ext_tick_seconds

    def _ext_entries(self, bars, quotes, now, sess):
        ext_open = sum(1 for t in self.trades.values() if t.ext)
        slots = (self.s.ext_max_positions + (1 if self.aggro else 0)) - ext_open
        if slots <= 0 or self.entries_blocked_reason or self._margin_block():
            if slots > 0:
                self._skip("(all)", "-", "", "entries blocked: " + str(self.entries_blocked_reason or "margin / buying-power check"), now)
            return
        if self.pause_until and now < self.pause_until and self.s.cooloff_streak:
            self._skip("(all)", "-", "", f"cooling off until {self.pause_until.strftime('%H:%M')} after a loss streak", now)
            return
        # shorts outside regular hours: pre-market / after-hours only (overnight has no reliable borrow)
        can_short = bool(self.s.allow_shorts and self.acct.get("shorting_enabled", True) and sess.name != "OVERNIGHT")
        ctx = {"aggressive": self.aggro, "move": self.ext_moves, "ribbon": self.ribbons, "quote_bars": sess.name == "OVERNIGHT",
               "shorts": can_short, "all_flips": self.s.trade_all_flips}
        ranked = []
        fired = set()
        sigs = find_ext_signals(bars, ctx, sess.start)
        fired = {(sg.symbol, sg.strategy) for sg in sigs}
        for sym, df in bars.items():
            if sym in self.s.watch_always or (sym, "RIBBON_FLIP") in fired:
                continue
            try:
                w = ribbon_why(sym, df[df.index >= sess.start] if len(df[df.index >= sess.start]) >= 6 else df, ctx)
            except Exception:
                w = None
            if w:
                if "SELL flip" in w and sess.name == "OVERNIGHT":
                    w = "SELL flip — shorting isn't available overnight (long-only)"
                self._skip(sym, "RIBBON_FLIP", "", f"{sess.label}: {w}", now)
        for sg in sigs:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, f"{sess.label}: {why}", now)
            if sg.symbol in self.trades or sg.symbol in self.positions:
                continue
            if self.manual_syms.get(sg.symbol) == self.day:
                no("you traded this symbol manually today — bot leaves it alone")
                continue
            if self.s.cooloff_symbol and self.sym_losses.get(sg.symbol, 0) >= 2:
                no("dropped for today after 2 losses on this symbol")
                continue
            cd = self.cooldown.get(sg.symbol)
            if cd and now < cd and self.s.cooloff_symbol:
                no(f"symbol cooling off until {cd.strftime('%H:%M')}")
                continue
            if sg.side == "sell":
                ok, why = self._can_short(sg.symbol)
                if not ok:
                    no("short signal skipped — " + why)
                    continue
            name = f"{sg.strategy}@{sess.name}"
            ch = self.learner.choose(name, sess.name, sg.quality)
            force = self.s.trade_all_flips and sg.strategy == "RIBBON_FLIP"
            if force and not ch:
                ch = ("RIBBON", 0.5, 1.0)
            if not ch or ch[1] < (0.0 if (self.aggro or force) else MIN_SCORE):
                no("learner score too low for this strategy in this session")
                continue
            if not force and self._tod_blocked(now, name):
                no("time-of-day filter: your own history loses money in this slot")
                continue
            ranked.append((ch[1], name, sg, ch))
        ranked.sort(key=lambda x: x[0], reverse=True)
        taken = set()
        for score, name, sg, (ep, _, weight) in ranked:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, f"{sess.label}: {why}", now)
            if sg.symbol in taken:
                continue                    # one order per symbol even if two strategies fire together
            if slots <= 0:
                no("all extended-hours position slots are full")
                continue
            q = quotes.get(sg.symbol)
            if not q:
                no("no live quote")
                continue
            if self._event_block(sg.symbol, now, sess.name):
                no("earnings / risky-news filter")
                continue
            bid, ask, _ = q
            short = sg.side == "sell"
            if sg.symbol in self.stale:
                no("quotes are stale")
                continue
            if (ask - bid) / ask > 0.006:
                no(f"spread too wide ({(ask - bid) / ask * 100:.2f}%)")
                continue
            if (not short and ask > sg.entry * 1.004) or (short and bid < sg.entry * 0.996):
                no("price already ran away from the entry — not chasing")
                continue
            limit = bid * 0.999 if short else ask * 1.001
            weight *= self.s.ext_risk_mult * (0.5 if self.loss_streak >= 3 and self.s.cooloff_streak else 1)
            dec = self.risk.size(limit, sg.stop, weight, self._open_risk(), self.acct.get("buying_power", 0))
            if dec.qty < 1:
                no(f"risk sizing gave 0 shares ({dec.reason})")
                continue
            d = -1 if short else 1
            r0 = abs(limit - sg.stop)
            ep = self._harvest_profile(ep)
            target = limit + d * EXIT_PROFILES[ep]["target_r"] * r0
            cid = f"abx-{uuid.uuid4().hex[:12]}"
            try:
                oid = self.broker.submit_limit_ext(sg.symbol, sg.side, dec.qty, limit, cid)
            except Exception as e:
                self.event(f"{sess.label} order rejected {sg.symbol}: {str(e)[:160]}", "warning")
                self.alert("reject", f"Order rejected: {sg.symbol}", str(e)[:160], symbol=sg.symbol)
                no("Alpaca rejected the order: " + str(e)[:90])
                continue
            t = Trade(cid, sg.symbol, sg.side, name, ep, sess.name, dec.qty, limit, sg.stop, sg.stop, target,
                      sg.atr, dec.risk_dollars, now, oid, day=self.day, mode=self.mode, ext=True, session=sess.name)
            with self.lock:
                self.trades[sg.symbol] = t
            db.upsert(t.row(status="pending"))
            slots -= 1
            taken.add(sg.symbol)
            self.event(f"{sess.label.upper()} ENTRY {sg.side.upper()} {dec.qty} {sg.symbol} limit {limit:.2f} [{name}/{ep}] "
                       f"stop {sg.stop:.2f} target {target:.2f} risk ${dec.risk_dollars:.0f}")
            self.alert("entry", f"🟢 BOT {'SHORT' if short else 'BUY'} {dec.qty} {sg.symbol} @ {limit:.2f} ({sess.label})",
                       f"{name} · stop {sg.stop:.2f} (watched by the app) · target {target:.2f}",
                       symbol=sg.symbol, close_btn=True)

    def _ext_place_targets(self):
        for t in list(self.trades.values()):
            if t.ext and t.status == "open" and not t.tp_order_id and not t.exit_order_id:
                if EXIT_PROFILES[t.exit_profile].get("scale"):
                    t.tp_order_id = "none"        # harvested in steps by the app (see _ext_manage)
                    t.qty0 = t.qty0 or t.qty
                    continue
                try:
                    t.tp_order_id = self.broker.submit_limit_ext(t.symbol, "buy" if t.dir < 0 else "sell", t.qty, t.target,
                                                                 f"abt-{uuid.uuid4().hex[:12]}")
                except Exception as e:
                    t.tp_order_id = "none"
                    self.event(f"Take-profit order failed for {t.symbol} (bot will watch the target): {str(e)[:100]}",
                               "warning")

    def _ext_manage(self, bars, quotes, now):
        for t in list(self.trades.values()):
            if not t.ext or t.status != "open":
                continue
            q = quotes.get(t.symbol)
            df = bars.get(t.symbol)
            short = t.dir < 0
            # the price we would exit at: bid for longs (we sell), ask for shorts (we buy to cover)
            bid = (q[1] if short else q[0]) if q else (float(df["close"].iloc[-1]) if df is not None else t.last_price or t.entry)
            t.last_price = ((q[0] + q[1]) / 2) if q else bid
            if t.exit_order_id:
                # exit working: re-price more aggressively every 20s until filled
                if self.broker.order_open(t.exit_order_id) and t.exit_sent_at and \
                        (now - t.exit_sent_at).total_seconds() > 20:
                    self.broker.cancel(t.exit_order_id)
                    self._ext_exit(t, t.note or "exit", bid, retry=True)
                continue
            prof = EXIT_PROFILES[t.exit_profile]
            r = t.r_now(bid)
            pos = self.positions.get(t.symbol)
            if pos and 0 < abs(pos["qty"]) < t.qty - 1e-9:          # a partial sell filled
                drop = t.qty - abs(pos["qty"])
                t.realized += ((t.partial_px or bid) - t.entry) * t.dir * drop
                t.qty = abs(pos["qty"])
                self.alert("profit", f"💰 Took profit {t.symbol} +${((t.partial_px or bid) - t.entry) * drop:,.2f}",
                           f"Sold {drop:g} ({t.session.lower()}) · {t.qty:g} left · stop {t.stop:.2f}",
                           symbol=t.symbol, close_btn=True)
            if t.partial_oid and not self.broker.order_open(t.partial_oid):
                t.partial_oid = ""
            if not t.partial_oid and self._quick_harvest(t, r):
                self._ext_exit(t, "harvest", bid)
                continue
            steps = prof.get("scale") or []
            if not t.partial_oid and t.scaled < len(steps) and r >= steps[t.scaled][0]:
                q = int(t.qty * steps[t.scaled][1])
                t.qty0 = t.qty0 or t.qty
                t.scaled += 1
                be = t.entry + 0.02 * (t.entry - t.stop_init)
                t.stop = min(t.stop, be) if short else max(t.stop, be)               # rest rides at break-even+
                if 1 <= q < t.qty:
                    px = bid * (1.001 if short else 0.999)                          # marketable limit
                    try:
                        t.partial_oid = self.broker.submit_limit_ext(t.symbol, "buy" if short else "sell", q, px, f"abp-{uuid.uuid4().hex[:12]}")
                        t.partial_px = px
                        self.event(f"💰 {t.session} take-profit {t.symbol}: selling {q} @~{px:.2f} ({r:+.1f}R), stop → {t.stop:.2f}")
                    except Exception as e:
                        self.event(f"Partial take-profit on {t.symbol} failed: {str(e)[:120]}", "warning")
            be = t.entry + 0.02 * (t.entry - t.stop_init)
            if prof["be_at_r"] is not None and r >= prof["be_at_r"]:
                t.stop = min(t.stop, be) if short else max(t.stop, be)
            if prof["trail_after_r"] is not None and r >= prof["trail_after_r"] and df is not None:
                tr = prof["trail_atr"] * float(df["atr"].iloc[-1])
                t.stop = min(t.stop, bid + tr) if short else max(t.stop, bid - tr)
            rb = self.ribbons.get(t.symbol)
            age = (now - t.opened_at).total_seconds() / 60
            reason = None
            hit_stop = bid >= t.stop if short else bid <= t.stop
            hit_tgt = bid <= t.target if short else bid >= t.target
            if t.symbol in self.stale and age > 5:
                reason = "stale data"
            elif hit_stop:
                reason = "stop" if t.stop == t.stop_init else "trail stop"
            elif hit_tgt and t.tp_order_id in ("", "none"):
                reason = "target"
            elif prof.get("exit_on_flip") and rb and rb.get("ready") and (rb["state"] > 0 if short else rb["state"] < 0):
                reason = "ribbon flip"
            elif age >= prof.get("time_stop", self.s.time_stop_minutes) and r < 0.3 and not (rb and rb.get("state") == 1):
                reason = "time stop"
            if reason:
                self._ext_exit(t, reason, bid)

    def _ext_exit(self, t, reason, bid, retry=False):
        with self.exit_lock:
            if not retry and t.exit_order_id:
                return                    # another thread already started this exit
            return self._ext_exit_locked(t, reason, bid, retry)

    def fast_guard(self, feed):
        """Called every second with streamed prices: extended-hours stops (held by the app, not Alpaca)
        react within ~1 s instead of waiting for the next 15-s loop."""
        if not self.running:
            return
        for t in list(self.trades.values()):
            if not t.ext or t.status != "open" or t.exit_order_id:
                continue
            lv = feed.get(t.symbol, max_age=5)
            if not lv or not lv.get("bid"):
                continue
            short = t.dir < 0
            bid = lv["ask"] if short else lv["bid"]
            t.last_price = (lv["bid"] + lv["ask"]) / 2
            if (bid >= t.stop) if short else (bid <= t.stop):
                self.event(f"Fast stop: {t.symbol} {'ask' if short else 'bid'} {bid:.2f} {'≥' if short else '≤'} stop {t.stop:.2f} (streamed)", "warning")
                self._ext_exit(t, "stop" if t.stop == t.stop_init else "trail stop", bid)

    def _ext_exit_locked(self, t, reason, bid, retry=False):
        if not retry:
            self.broker.cancel_symbol_orders(t.symbol)
            self.broker.sleep(0.5)
            t.note = reason
            t.exit_tries = 0
        t.exit_tries += 1
        pos = self.broker.positions().get(t.symbol)
        qty = abs(pos["qty"]) if pos else t.qty
        if not pos:
            return
        short = t.dir < 0
        limit = bid * (1 + 0.002 * t.exit_tries) if short else bid * (1 - 0.002 * t.exit_tries)   # marketable, a bit worse each retry
        try:
            t.exit_order_id = self.broker.submit_limit_ext(t.symbol, "buy" if short else "sell", qty, limit,
                                                           f"abe-{uuid.uuid4().hex[:12]}")
            t.exit_sent_at = self.broker.now()
            if not retry:
                self.event(f"EXIT {t.symbol} ({reason}) limit {limit:.2f} ({t.r_now(bid):+.2f}R)")
                if reason == "stale data":
                    self.alert("stale", f"Exiting {t.symbol}: quotes went stale",
                               "No fresh overnight quotes for 5 minutes.", symbol=t.symbol)
        except Exception as e:
            t.exit_order_id = ""
            self.event(f"Exit order failed for {t.symbol}: {str(e)[:120]}", "error")

    def _ext_orphans(self, now):
        """Extended-hours trades still open outside an enabled session (e.g. bot was paused)."""
        clk = self.broker.clock()
        for t in list(self.trades.values()):
            if not t.ext:
                continue
            if t.status == "pending":
                self.broker.cancel(t.order_id)
                continue
            if clk["is_open"]:
                self.broker.cancel_symbol_orders(t.symbol)
                t.note = t.note or "session ended"
                self._close(t)
                t.ext = False     # now a normal position; reconcile will record the exit
                self.event(f"Closing leftover {t.session} position {t.symbol} at the regular open", "warning")
        self.positions = self.broker.positions()
        self._reconcile()

    def refresh_account(self, max_age=20):
        """Keep balance / buying power / today's P&L current even while the market is closed
        (the trading loop only refreshes them during a session). Display only: never halts."""
        import time as _t
        if _t.time() - getattr(self, "_acct_t", 0) < max_age and self.acct:
            return
        try:
            self.acct = self.broker.account()
            self._acct_t = _t.time()
            if self.running:
                return            # the trading loop owns day P&L while it runs
            bd = bot_day(self.broker.now())
            base = None
            try:
                st = json.loads(DAY_STATE.read_text())
                if st.get("day") == bd and st.get("mode", self.mode) == self.mode and self._sane_base(float(st["baseline"])):
                    base = float(st["baseline"])
            except Exception:
                pass
            base = base or self.acct.get("last_equity")
            if base and not self.risk.halted:
                self.risk.day_pnl = self.acct["equity"] - base
        except Exception:
            pass

    # ---------------- status for the dashboard ----------------
    def status(self):
        with self.lock:
            trades = [{
                "symbol": t.symbol, "side": t.side, "qty": t.qty, "entry": round(t.entry, 2),
                "stop": round(t.stop, 2), "target": round(t.target, 2), "strategy": t.strategy,
                "exit": t.exit_profile, "status": t.status, "price": round(t.last_price, 2),
                "r": round(t.r_now(t.last_price), 2) if t.last_price else 0,
                "risk": t.risk, "opened": t.opened_at.strftime("%H:%M"),
                "session": t.session} for t in self.trades.values()]
        return {
            "running": self.running, "state": self.state, "mode": self.mode,
            "daily_max_loss": self.s.daily_max_loss, "day_pnl": round(self.risk.day_pnl, 2),
            "remaining": round(self.risk.remaining, 2), "halted": self.risk.halted,
            "halt_reason": self.risk.halt_reason, "bias": self.bias, "account": self.acct,
            "universe": [{"symbol": u, "gap": self.gaps.get(u, 0),
                          "ribbon": (self.ribbons.get(u) or {}).get("state", 0)} for u in self.universe],
            "open_trades": trades, "events": list(self.events)[:80],
            "scan_info": self.scan_info[:30],
            "setups": getattr(self, "setups", [])[:15],
            "session": ({"name": self.session.name, "label": self.session.label,
                         "ends": self.session.end.strftime("%a %H:%M"),
                         "enabled": self.session.name == "REGULAR" or self._ext_enabled(self.session.name)}
                        if self.session else {"name": "CLOSED", "label": "Market closed", "ends": "", "enabled": False}),
        }
