"""🎯 Setting up now: find stocks likely to make a fast move SOON, before it happens.

For every scanned stock (top picks + watchlist) on 1-minute bars it measures:
  coil      - how tight the last 20-30 minutes are vs. the stock's normal 1-min range (energy building)
  volume    - is volume building in the last 5 minutes vs. the last 20
  pressure  - which way it leans: side of VWAP, ribbon colour, lower highs / higher lows, distance to the range edge
  range     - how big the stock's daily moves are (ATR %) - a flush in TSLA is worth more than in KO
It predicts the likely direction, the trigger price (range break), the expected move and a 0-100 readiness score.
Scores are a ranking, not a probability of profit."""


def _clip(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def rank_setups(bars: dict, ribbons: dict, scan_info: list, index_symbols=(), top=15) -> list:
    info = {r["symbol"]: r for r in (scan_info or [])}
    out = []
    for sym, d in bars.items():
        if sym in index_symbols or d is None or len(d) < 30:
            continue
        try:
            last = d.iloc[-1]
            a1 = float(last["atr"])
            if a1 <= 0:
                continue
            c = float(last["close"])
            w = d.iloc[-25:-1]
            hi, lo = float(w["high"].max()), float(w["low"].min())
            rng = hi - lo
            coil = _clip(1 - (rng / a1 - 2) / 6)                   # range of ~2 ATR = very coiled, 8+ ATR = none
            v5 = float(d["volume"].iloc[-5:].mean())
            v20 = float(d["volume"].iloc[-25:-5].mean()) or 1.0
            vbuild = _clip((v5 / v20 - 0.8) / 1.7)                  # 2.5x = max
            vwap = float(last["vwap"])
            rb = (ribbons or {}).get(sym) or {}
            rstate = rb.get("state", 0) if rb.get("ready") else 0
            highs = d["high"].iloc[-15:].values
            lows = d["low"].iloc[-15:].values
            lh = sum(highs[i] < highs[i - 5] for i in range(5, 15)) / 10     # lower highs share
            hl = sum(lows[i] > lows[i - 5] for i in range(5, 15)) / 10       # higher lows share
            bear = (c < vwap) * 0.3 + (rstate < 0) * 0.3 + lh * 0.25 + _clip((hi - c) / rng if rng else 0) * 0.15
            bull = (c > vwap) * 0.3 + (rstate > 0) * 0.3 + hl * 0.25 + _clip((c - lo) / rng if rng else 0) * 0.15
            side = "down" if bear > bull else "up"
            lean = abs(bull - bear)
            si = info.get(sym, {})
            atr_pct = si.get("atr_pct") or (a1 * 20 / c * 100)
            s_range = _clip((atr_pct - 1) / 5)
            edge = _clip(1 - (min(c - lo, hi - c) / rng) * 2) if rng else 0   # sitting near an edge of the range
            ready = 100 * (0.30 * coil + 0.22 * vbuild + 0.22 * _clip(lean * 2) + 0.14 * s_range + 0.12 * edge)
            trig = lo - 0.1 * a1 if side == "down" else hi + 0.1 * a1
            exp_move = max(2.5 * a1, rng)
            target = trig - exp_move if side == "down" else trig + exp_move
            why = []
            if coil > 0.6:
                why.append(f"tight {rng / a1:.1f}-ATR range")
            if vbuild > 0.4:
                why.append(f"volume building {v5 / v20:.1f}x")
            why.append("below VWAP" if c < vwap else "above VWAP")
            if rstate:
                why.append("ribbon " + ("red" if rstate < 0 else "green"))
            if side == "down" and lh > 0.5:
                why.append("lower highs")
            if side == "up" and hl > 0.5:
                why.append("higher lows")
            breaking = (c < trig) if side == "down" else (c > trig)
            if breaking:
                ready = min(100, ready + 10)
                trig = c
                target = c - exp_move if side == "down" else c + exp_move
            out.append({"symbol": sym, "status": "breaking" if breaking else "set", "price": round(c, 2), "side": side, "ready": int(round(ready)),
                        "trigger": round(trig, 2), "target": round(target, 2),
                        "move_pct": round(100 * exp_move / c, 2), "dist_pct": round(100 * abs(trig - c) / c, 2),
                        "range_hi": round(hi, 2), "range_lo": round(lo, 2), "watch": bool(si.get("watch")),
                        "why": ", ".join(why)})
        except Exception:
            continue
    out.sort(key=lambda r: r["ready"], reverse=True)
    return out[:top]
