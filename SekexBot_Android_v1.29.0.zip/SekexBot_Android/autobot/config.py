"""Settings: API keys come from .env, everything else from settings.json (editable from the dashboard)."""
import json
import os
from dataclasses import dataclass, asdict, field
from pathlib import Path

from .android import IS_ANDROID

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("AUTOBOT_DATA", str(BASE_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA_DIR / "settings.json"
ENV_FILE = BASE_DIR / ".env"


def load_env():
    """Tiny .env loader (no extra dependency)."""
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()


def write_env(values: dict):
    """Update/insert KEY=value lines in .env (keeps comments and other keys) and apply them now."""
    lines = ENV_FILE.read_text().splitlines() if ENV_FILE.exists() else []
    done = set()
    out = []
    for ln in lines:
        k = ln.split("=", 1)[0].strip() if "=" in ln and not ln.strip().startswith("#") else None
        if k in values:
            out.append(f"{k}={values[k]}")
            done.add(k)
        else:
            out.append(ln)
    for k, v in values.items():
        if k not in done:
            out.append(f"{k}={v}")
    ENV_FILE.write_text("\n".join(out) + "\n")
    for k, v in values.items():
        os.environ[k] = v


def mask(v: str) -> str:
    return (v[:2] + "…" + v[-4:]) if v and len(v) > 8 else ("set" if v else "")


@dataclass
class Settings:
    # ---- The one limit you control ----
    daily_max_loss: float = 200.0          # $ — bot flattens and stops for the day when hit

    # ---- Mode ----
    live: bool = False                      # False = Alpaca paper account
    data_feed: str = "iex"                  # "iex" (free) or "sip" (paid Algo Trader Plus)
    allow_shorts: bool = True               # short whenever the stock/account/session allows it
    trade_all_flips: bool = False           # take every fresh ribbon BUY/SELL flip (risk limits still apply)
    shorts_default_v129: bool = False       # internal: one-time switch of old saved settings to shorts ON

    # ---- Extended hours (long-only, limit orders, bot-managed stops) ----
    ext_premarket: bool = False             # 4:00 - 9:30 AM ET
    # On Android these start OFF: extended-hours stops are watched by the bot itself, and Android
    # can kill a background app at night. Turn them on from the dashboard if you accept that risk.
    ext_afterhours: bool = not IS_ANDROID   # 4:00 - 8:00 PM ET
    ext_overnight: bool = not IS_ANDROID    # 8:00 PM - 4:00 AM ET (Sun-Thu nights)
    ext_risk_mult: float = 0.5              # extended-hours trades risk half as much as regular ones
    ext_max_positions: int = 2
    ext_tick_seconds: int = 15              # faster checks: stops live in the bot, not on the server

    # ---- Resilience ----
    auto_resume: bool = True                # if the app is killed while trading, resume on restart
    stream_prices: bool = True              # real-time websocket prices (falls back to polling)

    # ---- Internal guard rails (sensible defaults, not meant to be tuned daily) ----
    risk_per_trade_frac: float = 0.15       # base $ risk per trade = daily_max_loss * this * strategy weight
    max_positions: int = 4
    max_position_pct_bp: float = 0.25       # max % of buying power in any single position
    min_price: float = 5.0
    max_price: float = 800.0
    min_prev_volume: int = 1_000_000
    universe_size: int = 30
    tick_seconds: int = 30
    no_new_entries_min_before_close: int = 20
    flatten_min_before_close: int = 8
    time_stop_minutes: int = 75
    confirm_trades: bool = False            # ask "Send this order?" / "Close?" before manual trades (off = one tap)
    cooloff_streak: bool = True             # after 3 losses in a row: pause 20 min, then half size
    cooloff_symbol: bool = True             # wait before re-trading a symbol; drop it after 2 losses in a day
    aggressive_scalp: bool = False          # 🔥 many fast trades: momentum bursts, 1/2 at +0.5R, rest +1R, 8-min max
    scalp_mode: bool = False                # quick in-and-out: 1/2 at +0.6R, rest at +1.2R, max 20 min
    scale_out: bool = True                  # take profit along the way (1/3 at +1R, 1/3 at +2R, trail the rest)
    tod_filter: bool = True                 # skip times of day where YOUR trade history loses money
    tod_min_trades: int = 30                # ...once that time slot has at least this many trades
    watch_always: list = field(default_factory=lambda: ["SPY", "QQQ"])   # market-trend reference only
    watchlist: list = field(default_factory=lambda: ["SPCX"])            # your tickers: always scanned & traded

    def save(self):
        SETTINGS_FILE.write_text(json.dumps(asdict(self), indent=2))

    @classmethod
    def load(cls) -> "Settings":
        s = cls()
        if SETTINGS_FILE.exists():
            try:
                data = json.loads(SETTINGS_FILE.read_text())
                for k, v in data.items():
                    if hasattr(s, k):
                        setattr(s, k, v)
                if not data.get("shorts_default_v129"):      # v1.29: shorts are ON by default, once
                    s.allow_shorts, s.shorts_default_v129 = True, True
                    s.save()
            except Exception:
                pass
        return s


def api_keys(live: bool):
    """Separate key pairs for paper and live so you never mix them up."""
    if live:
        return os.getenv("ALPACA_LIVE_KEY", ""), os.getenv("ALPACA_LIVE_SECRET", "")
    return os.getenv("ALPACA_PAPER_KEY", ""), os.getenv("ALPACA_PAPER_SECRET", "")


def live_pin() -> str:
    return os.getenv("LIVE_PIN", "")
