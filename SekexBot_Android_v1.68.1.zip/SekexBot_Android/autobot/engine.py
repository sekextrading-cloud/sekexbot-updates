"""The auto-trader loop. Start it once; it waits for the open, scans the morning movers,
trades all session, manages exits, flattens before the close, learns from every trade,
then (if enabled) trades the after-hours and overnight sessions, and sleeps until the next
session. It keeps running day after day until you press Stop."""
import json
import logging
import re
import threading
import time
import traceback
import uuid
from collections import deque
from dataclasses import dataclass, asdict, fields
from datetime import datetime, timedelta

import pandas as pd

from . import db
from .config import DATA_DIR
from .indicators import enrich, ribbon_state
from .direction import direction
from .autotune import Tuner
from .levels import LEVELS, LevelStats, apply_level
from .learner import EXIT_PROFILES, Learner, time_bucket
from .quotebars import QuoteBars
from .risk import RiskManager
from .sessions import EXT_NAMES, bot_day, current_session, next_session
from .setups import rank_movers, rank_setups
from .strategies import find_ext_signals, find_signals, market_bias, preclose_candidates, ribbon_why

log = logging.getLogger("autobot")
MIN_SCORE = 0.10   # learner score a setup must reach before the bot takes it
DB_COLS = {"id", "day", "mode", "symbol", "side", "strategy", "exit_profile", "bucket", "qty", "entry", "stop",
           "target", "risk", "opened_at", "closed_at", "exit", "pnl", "r", "status", "note"}
DAY_STATE = DATA_DIR / "day_state.json"
RUN_STATE = DATA_DIR / "run_state.json"        # was the bot running? (auto-resume after the app is killed)
ENGINE_STATE = DATA_DIR / "engine_state.json"  # open trades + today's halt / brakes, restored on restart


def _dt(v):
    return datetime.fromisoformat(v) if isinstance(v, str) and v else None


def was_running() -> bool:
    try:
        return bool(json.loads(RUN_STATE.read_text()).get("running"))
    except Exception:
        return False


@dataclass
class Trade:
    id: str
    symbol: str
    side: str
    strategy: str
    exit_profile: str
    bucket: str
    qty: float
    entry: float
    stop_init: float
    stop: float
    target: float
    atr: float
    risk: float
    opened_at: datetime
    order_id: str
    status: str = "pending"      # pending -> open -> closed
    last_price: float = 0.0
    note: str = ""
    day: str = ""
    mode: str = ""
    ext: bool = False            # extended-hours trade (bot-managed stop/target)
    session: str = "REGULAR"
    tp_order_id: str = ""
    exit_order_id: str = ""
    exit_tries: int = 0
    exit_sent_at: datetime | None = None
    qty0: float = 0.0            # shares at entry (before any profit-taking)
    decide_px: float = 0.0       # exit-side price when the bot decided to close (to measure slippage)
    decide_t: float = 0.0
    scaled: int = 0              # profit-taking steps done
    realized: float = 0.0        # P&L already banked by partial exits
    beyond_since: object = None  # extended hours: when price first went beyond the stop
    pos_ticks: int = 0           # scalps: how many checks in a row the trade has been in profit
    peak_r: float = 0.0          # scalps: best R seen
    partial_oid: str = ""        # extended hours: working partial take-profit order
    partial_px: float = 0.0
    hv_pct: float = 0.0          # this trade's own harvest gain in % (0 = use the setting)

    @property
    def dir(self):
        return 1 if self.side == "buy" else -1

    def r_now(self, price):
        r0 = abs(self.entry - self.stop_init)
        return (price - self.entry) * self.dir / r0 if r0 else 0.0

    def row(self, **kw):
        d = {k: v for k, v in asdict(self).items() if k in DB_COLS}
        d["stop"] = self.stop_init
        d["opened_at"] = self.opened_at.isoformat()
        d.update(kw)
        return d


class Engine:
    def __init__(self, settings, broker, learner: Learner):
        self.s = settings
        self.broker = broker
        self.learner = learner
        self.risk = RiskManager(settings)
        self.mode = "PAPER" if getattr(broker, "paper", True) else "LIVE"
        self.running = False
        self._warn_cache, self._warned = {}, {}
        self.thread = None
        self.lock = threading.RLock()
        self.trades: dict[str, Trade] = {}
        self.cooldown: dict[str, datetime] = {}
        self.universe, self.gaps = [], {}
        self.reg_universe = []
        self.last_scan = None
        self.ext_last_scan = None
        self.ext_moves = {}
        self.ext_key = None
        self.qbars = QuoteBars()
        self.stale = set()
        self.scan_info = []
        self.session = None
        self._base = (None, None)
        self.day = ""
        self.state = "STOPPED"
        self.bias = 0
        self.acct = {}
        self.positions = {}
        self.events = deque(maxlen=300)
        self.movers, self.movers_at = [], ""
        self._movers_alerted = None
        self.skips = deque(maxlen=400)          # 'Why no trade?' log: signals that were rejected, and why
        self._skip_seen = {}
        self._load_movers()
        self.levels = LevelStats()
        self.tuner = Tuner()
        self._flip_n = {}
        self.pre_bars, self._pre_day = {}, None
        self._call_seen = set()
        self.overnight, self.evening, self.evening_at = {}, [], ""
        self._pc_scan_at = None
        from . import shortlist as _sl
        _d = _sl.load()
        self.shortlist, self.shortlist_at = _d.get("items", []), (_d.get("at", "") + (" · " + _d["stage"] if _d.get("stage") else ""))
        self.last_win = {}
        self.reentry = {}
        self.pm, self.open_shorts = {"day": "", "snaps": {}}, []
        self._load_pm()
        self._load_overnight()
        self._level_key = None
        self.entries_blocked_reason = ""
        self.ribbons = {}
        self.raw = {}
        self.loss_streak = 0
        self.pause_until = None
        self.sym_losses: dict[str, int] = {}
        self.exit_lock = threading.Lock()
        self.alerts = None                 # set by the server: autobot.alerts.Alerts
        self.manual_syms: dict = {}
        self.profit_locks: dict = {}
        self.evfilter = None               # autobot.events.Events: earnings / risky-news filter
        self._ev_logged = {}       # after a halt: symbol -> price that banks >= half the open profit        # symbol -> bot day you traded it by hand: the bot keeps out that day

    # ---------------- control ----------------
    def start(self, resumed=False):
        if self.running:
            return
        if self.mode != "SIM":
            self._restore_state()
        self.running = True
        self.state = "STARTING"
        self._set_run_state(True)
        self.thread = threading.Thread(target=self._run, daemon=True, name="autobot")
        self.thread.start()
        self.event(f"Auto-trader {'resumed after a restart' if resumed else 'started'} ({self.mode}), "
                   f"daily max loss ${self.s.daily_max_loss:,.0f}")

    def stop(self, flatten=False):
        self.running = False
        self._set_run_state(False)
        if flatten:
            self.flatten("manual stop")
        self.state = "STOPPED"
        self._save_state()
        self.event("Auto-trader stopped" + (" and flattened" if flatten else " (open positions keep their server-side stop/target)"))

    # ---------------- survive restarts (Android can kill the app) ----------------
    def _set_run_state(self, running):
        if self.mode == "SIM":
            return
        try:
            RUN_STATE.write_text(json.dumps({"running": running, "mode": self.mode,
                                             "at": datetime.now().isoformat(timespec="seconds")}))
        except Exception:
            pass

    def _save_state(self):
        if self.mode == "SIM" or not self.day:
            return
        with self.lock:
            trades = []
            for t in self.trades.values():
                d = asdict(t)
                d["opened_at"] = t.opened_at.isoformat()
                d["exit_sent_at"] = t.exit_sent_at.isoformat() if t.exit_sent_at else None
                d.pop("beyond_since", None)
                trades.append(d)
        st = {"day": self.day, "mode": self.mode, "trades": trades,
              "halted": self.risk.halted, "halt_reason": self.risk.halt_reason, "peak_pnl": self.risk.peak_pnl,
              "loss_streak": self.loss_streak, "sym_losses": self.sym_losses,
              "pause_until": self.pause_until.isoformat() if self.pause_until else None,
              "cooldown": {k: v.isoformat() for k, v in self.cooldown.items()},
              "entries_blocked_reason": self.entries_blocked_reason, "manual_syms": self.manual_syms, "profit_locks": self.profit_locks}
        try:
            tmp = ENGINE_STATE.with_suffix(".tmp")
            tmp.write_text(json.dumps(st))
            tmp.replace(ENGINE_STATE)
        except Exception as e:
            log.warning("Could not save engine state: %s", e)

    def _restore_state(self):
        try:
            st = json.loads(ENGINE_STATE.read_text())
        except Exception:
            return
        if st.get("mode") != self.mode:
            return
        try:
            now = self.broker.now()
            today = bot_day(now)
            if st.get("day") == today and self.day in ("", today) and not getattr(self, "_restored", False):
                self._restored = True
                self.day = today
                self.risk.halted = bool(st.get("halted"))
                self.risk.halt_reason = st.get("halt_reason", "")
                self.risk.peak_pnl = float(st.get("peak_pnl") or 0)
                self.loss_streak = int(st.get("loss_streak") or 0)
                self.sym_losses = dict(st.get("sym_losses") or {})
                self.pause_until = _dt(st.get("pause_until"))
                self.cooldown = {k: _dt(v) for k, v in (st.get("cooldown") or {}).items() if v}
                self.entries_blocked_reason = st.get("entries_blocked_reason", "")
                self.manual_syms.update(st.get("manual_syms") or {})
                self.profit_locks.update(st.get("profit_locks") or {})
            saved = st.get("trades") or []
            if not saved:
                return
            positions = self.broker.positions()
            restored = []
            for d in saved:
                d["opened_at"] = _dt(d.get("opened_at"))
                d["exit_sent_at"] = _dt(d.get("exit_sent_at"))
                known = {f.name for f in fields(Trade)}
                t = Trade(**{k: v for k, v in d.items() if k in known})     # tolerate other versions' fields
                # an open trade is only ours if the position still exists; pending orders get reconciled
                if t.status == "open" and t.symbol not in positions:
                    t.last_price = t.last_price or t.entry   # closed while we were down: reconcile records it
                with self.lock:
                    if t.symbol not in self.trades:
                        self.trades[t.symbol] = t
                        restored.append(t.symbol)
            if restored:
                self.event(f"Restored {len(restored)} bot trade(s) after restart: {', '.join(restored)}", "warning")
        except Exception as e:
            self.event(f"Could not restore saved trades: {e}", "warning")

    def alert(self, kind, title, body="", **kw):
        if self.alerts:
            try:
                tag = {"PAPER": "[PAPER] ", "SIM": "[SIM] ", "LIVE": "🔴 LIVE · "}.get(self.mode, "")
                self.alerts.send(kind, tag + title, body, **kw)
            except Exception:
                pass

    def _skip(self, sym, strategy, side, why, now=None):
        """Remember why a signal did not become a trade (deduplicated: same reason at most every 10 min)."""
        try:
            now = now or self.broker.now()
            k = (sym, strategy, why)
            last = self._skip_seen.get(k)
            if last and (now - last).total_seconds() < 600:
                return
            self._skip_seen[k] = now
            if len(self._skip_seen) > 2000:
                self._skip_seen = {kk: v for kk, v in self._skip_seen.items() if (now - v).total_seconds() < 600}
            self.skips.appendleft({"t": now.strftime("%a %H:%M"), "symbol": sym, "strategy": strategy,
                                   "side": side, "why": why})
        except Exception:
            pass

    def shorts_allowed(self, now=None):
        """Shorting switch. With 'Shorts start at 7 AM' on (default) it turns on by itself at 7:00 AM ET for every setup
        and stays on until 8 PM; before 7 AM it is off. With it off, the manual Allow short selling box decides."""
        if getattr(self.s, "shorts_24_5", True):
            return True                                   # every open session; the borrow check before each short is what limits it
        if getattr(self.s, "short_from_7am", True):
            now = now or self.broker.now()
            hm = now.hour * 60 + now.minute
            return 7 * 60 <= hm < 20 * 60
        return bool(self.s.allow_shorts)

    def _can_short(self, sym):
        """(ok, reason). Shorting needs the switch on, an account that can short, and a shortable stock."""
        if not self.shorts_allowed():
            return False, "shorting starts at 7:00 AM ET (Controls: Shorts start at 7 AM)" if getattr(self.s, "short_from_7am", True) else "shorting is switched off in Controls"
        if not self.acct.get("shorting_enabled", True):
            return False, "your Alpaca account can't short (needs a margin account)"
        if hasattr(self.broker, "recheck_borrow"):          # fresh borrow_status check right before ordering
            ok, status = self.broker.recheck_borrow(sym)
            if not ok:
                return False, f"Alpaca borrow_status is {status} (needs to be easy_to_borrow and shortable)"
            return True, ""
        if not self.broker.shortable(sym):
            return False, "not shortable / hard to borrow at Alpaca"
        return True, ""

    def event(self, msg, level="info"):
        ts = self.broker.now().strftime("%m-%d %H:%M:%S")
        self.events.appendleft({"t": ts, "msg": msg, "level": level})
        getattr(log, level if level in ("info", "warning", "error") else "info")(msg)

    # ---------------- main loop ----------------
    def _run(self):
        while self.running:
            wait = self.s.tick_seconds
            try:
                w = self.tick()
                if w:
                    wait = w
            except Exception as e:
                self.event(f"Loop error: {e}", "error")
                self.alert("system", "Bot error", str(e)[:180])
                log.debug(traceback.format_exc())
                wait = max(self.s.tick_seconds, 30)
            self._save_state()
            # sleep in small slices so Stop is responsive
            slept = 0
            while self.running and slept < wait:
                step = min(5, wait - slept)
                self.broker.sleep(step)
                slept += step

    def _ext_enabled(self, name):
        return {"PRE": self.s.ext_premarket, "AFTER": self.s.ext_afterhours,
                "OVERNIGHT": self.s.ext_overnight}.get(name, False)

    def _ext_window(self, sess):
        """Free IEX data only covers ~8:00 AM - 5:00 PM ET, so on IEX the bot trades pre-market from 8:00
        and after-hours until 5:00 PM only (SIP covers the full 4 AM - 8 PM; overnight uses its own feed)."""
        start, end = sess.start, sess.end
        if self.s.data_feed == "iex":
            if sess.name == "PRE":
                start = max(start, sess.start.replace(hour=8, minute=0))
            elif sess.name == "AFTER":
                end = min(end, sess.start.replace(hour=17, minute=0))
        return start, end

    def _enabled_names(self):
        return ["REGULAR"] + [n for n in EXT_NAMES if self._ext_enabled(n)]

    def tick(self):
        now = self.broker.now()
        bd = bot_day(now)
        if bd != self.day:
            self._new_day(bd)

        sess = current_session(self.broker.trading_day, now)
        self.session = sess
        self._auto_level(sess)
        if sess and sess.name in EXT_NAMES and self._ext_enabled(sess.name):
            win = self._ext_window(sess)
            if win[0] <= now < win[1]:
                return self._ext_tick(sess, now, win[1])
        if any(t.ext for t in list(self.trades.values())):
            self._ext_orphans(now)

        clk = self.broker.clock()
        if not clk["is_open"]:
            mins = (clk["next_open"] - now).total_seconds() / 60
            if self.trades:
                self.positions = self.broker.positions()
                self._reconcile()
            if mins <= 20 and not self.last_scan:
                self.state = "PRE-MARKET SCAN"
                self._scan()
            nxt = next_session(self.broker.trading_day, now, self._enabled_names())
            wait = max(30, min(600, (mins - 19) * 60)) if mins > 20 else 60
            if nxt and nxt.name != "REGULAR":
                wait = max(5, min(wait, (nxt.start - now).total_seconds() + 1))
                self.state = f"WAITING FOR {nxt.label.upper()} ({nxt.start.strftime('%a %H:%M')})"
            else:
                self.state = f"WAITING FOR OPEN ({clk['next_open'].strftime('%a %H:%M')})"
            return wait

        self.acct = self.broker.account()
        self.positions = self.broker.positions()
        self._overnight_tick(now, clk)
        if self.risk.update(self.acct["equity"], self._baseline()):
            self.event(f"HALT: {self.risk.halt_reason} — flattening account", "warning")
            n, kept = self.close_losers(self.risk.halt_reason)
            self.alert("halt", "🛑 Trading halted for today",
                       f"{self.risk.halt_reason}. Day P&L ${self.risk.day_pnl:,.2f}. Closed {n} losing position(s)"
                       + (f"; kept winners: {', '.join(kept)}" if kept else "") + ".", level="warning")
        self._reconcile()

        if self.risk.halted:
            self.state = "HALTED: " + self.risk.halt_reason + " (protecting winners, no new trades)"
            self.guard_profits()
            if self.trades:
                symbols = [t.symbol for t in self.trades.values()]
                raw = self.broker.bars(symbols)
                self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
                self._manage({k: enrich(v) for k, v in raw.items() if len(v) >= 3}, now)
                return 30
            return 60
        if self.acct.get("blocked"):
            self.state = "ACCOUNT BLOCKED"
            self.alert("restrict", "Account blocked", "Alpaca reports the account is blocked from trading.")
            return 120

        mins_to_close = (clk["next_close"] - now).total_seconds() / 60
        if mins_to_close <= self.s.flatten_min_before_close:
            if self.trades:
                self.event("End of day: flattening bot positions")
                self.flatten("EOD")
            self.state = "SESSION DONE"
            return 60

        if not self.last_scan or (now - self.last_scan) > timedelta(minutes=30):
            self._scan()

        symbols = list(dict.fromkeys(self.universe + [t.symbol for t in self.trades.values()] + self.s.watch_always
                                     + [w["symbol"] for w in self.evening if w.get("status") == "watch"][:10]
                                     + ([x["symbol"] for x in self.shortlist][:15] if (self.s.auto_short or self.s.auto_prep) else [])))
        raw = self.broker.bars(symbols)
        self.raw = raw
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 3}
        self.bias = market_bias(bars, tuple(self.s.watch_always))
        self.ribbons = self._ribbons_seeded(raw, now)
        try:
            self.setups = rank_setups(bars, self.ribbons, self.scan_info, tuple(self.s.watch_always))
        except Exception:
            pass
        if now.hour < 12:                       # the morning's big gappers, with a plan (GO / FADE / WAIT)
            self._update_movers(bars, {k: g for k, g in self.gaps.items() if abs(g) >= 1.0}, "REGULAR", now)

        self._manage(bars, now)
        self._preclose_scan(bars, now, clk)

        mins_since_open = (now - now.replace(hour=9, minute=30, second=0, microsecond=0)).total_seconds() / 60
        if mins_to_close > self.s.no_new_entries_min_before_close and mins_since_open >= 2:
            self.state = "TRADING"
            self._entries(bars, now)
        else:
            self.state = "MANAGING (no new entries)"
        return 10 if self.aggro else None      # aggressive scalping checks every 10 s

    # ---------------- automatic short system ----------------
    def refresh_shortlist(self, stage):
        """Overnight homework (after the close) or the morning refresh (from 8:00 AM ET): rank the market for shorts."""
        from . import shortlist as sl
        if not hasattr(self.broker, "screener"):
            return 0
        now = self.broker.now()
        rows = sl.build(self.broker, self.s, extra=list(self.reg_universe or self.universe or [])[:20], now=now)
        if not rows:
            return 0
        self.shortlist = rows
        self.shortlist_at = f"{now.strftime('%a %-I:%M %p')} · {stage}"
        sl.save({"at": now.strftime("%a %-I:%M %p"), "stage": stage, "items": rows})
        self.event(f"Short shortlist ({stage}): " + ", ".join(r["symbol"] for r in rows[:8]))
        return len(rows)

    REENTRY_MAX, REENTRY_MINUTES = 3, 90

    def _arm_reentry(self, t, px, now):
        """A profitable exit arms a re-entry: the same side again on a pullback OR a continuation to a new extreme."""
        if not self.s.reentry or t.note in ("EOD", "manual stop", "harvest-manual") or self.risk.halted:
            return
        prev = self.reentry.get(t.symbol)
        n = (prev.get("n", 0) + 1) if (prev and str(t.strategy).startswith("REENTRY")) else 0
        if n >= self.REENTRY_MAX:
            self.reentry.pop(t.symbol, None)
            return
        self.reentry[t.symbol] = {"dir": t.dir, "exit": float(px), "t": now, "n": n, "day": self.day, "strategy": t.strategy}

    def _reentry_ctx(self, now):
        """Drop stale re-entries (90 minutes, a new day, ribbon against, halted) and return the live ones."""
        if not self.s.reentry:
            return {}
        for sym, st in list(self.reentry.items()):
            rb = self.ribbons.get(sym) or {}
            if (st["day"] != self.day or (now - st["t"]).total_seconds() > self.REENTRY_MINUTES * 60 or self.risk.halted
                    or (rb.get("ready") and rb.get("state", 0) * st["dir"] < 0)):
                self.reentry.pop(sym, None)
        return dict(self.reentry)

    HARD_MIN_PRICE = 2.0

    def _spread_block(self, sg, session="REGULAR"):
        """Skip an entry when the bid-ask spread is wider than max_spread_pct of the price: we would start the trade
        that far under water and the exit pays it again."""
        lim = float(getattr(self.s, "max_spread_pct", 0) or 0)
        if lim <= 0:
            return ""
        if getattr(sg, "strategy", "") in self.TREND_STRATS:            # big-target trend setups can afford a wider spread
            lim = max(lim, float(getattr(self.s, "max_spread_trend_pct", 0.4) or 0))
        try:
            q = (self.broker.quotes([sg.symbol], session) or {}).get(sg.symbol)
        except Exception:
            return ""
        if not q or not q[0] or q[1] <= q[0]:
            return ""
        pct = (q[1] - q[0]) / ((q[0] + q[1]) / 2) * 100
        if pct > lim:
            return f"spread {pct:.2f}% is wider than your {lim:g}% limit (bid {q[0]:.2f} / ask {q[1]:.2f}): you would start the trade that far under water"
        return ""

    TREND_STRATS = ("EXT_CONT", "EXT_TREND", "EXT_MOMENTUM", "PLAN_TREND")

    # leveraged / inverse ETF families: every member is the SAME market bet (long TQQQ + short SQQQ = double long)
    ETF_FAMILIES = [
        {"TQQQ", "SQQQ", "QQQ", "QLD", "SQQ", "PSQ", "QID", "NDAQ_"}, {"SOXL", "SOXS", "SOXX", "SMH", "USD"},
        {"SPY", "SPXL", "SPXS", "SPXU", "UPRO", "SSO", "SDS", "SH", "VOO", "IVV"}, {"TNA", "TZA", "IWM", "URTY", "SRTY"},
        {"UDOW", "SDOW", "DIA", "DDM", "DXD"}, {"FNGU", "FNGD"}, {"LABU", "LABD"}, {"TECL", "TECS"}, {"FAS", "FAZ"},
        {"NVDL", "NVDS", "NVDQ"}, {"TSLL", "TSLS", "TSLQ"}, {"BOIL", "KOLD"}, {"ERX", "ERY"}, {"YINN", "YANG"},
        {"NUGT", "DUST", "JNUG", "JDST"}, {"UVXY", "SVXY", "VXX", "SVIX", "UVIX"}, {"BITX", "BITI", "BITO", "BITU", "SBIT"},
    ]

    def _pair_block(self, sym, taken=()):
        """One position per leveraged-ETF family at a time (also against orders placed in the same pass)."""
        if not getattr(self.s, "etf_pair_guard", True):
            return ""
        fam = next((f for f in self.ETF_FAMILIES if sym in f), None)
        if not fam:
            return ""
        held = [x for x in fam if x != sym and (x in self.trades or x in self.positions or x in taken)]
        if held:
            return (f"{held[0]} is already open and {sym} is in the same ETF family: long one + short its inverse is the same bet "
                    f"twice, long one + long its inverse cancels out. One position per family.")
        return ""

    def _harvest_stop(self, limit, stop, side, ext, strategy, hv_pct):
        """v1.65: with Harvest small % on, a trade that exits for ~0.15% must not risk ~0.7%. Pull the stop in to
        harvest_stop_mult x the harvest gain, but never inside the thin-market floor. Trend entries keep their wide stop."""
        if (not getattr(self.s, "harvest_stop", True) or not getattr(self.s, "pct_harvest", False)
                or strategy in ("EXT_CONT", "REENTRY_NOPE")):
            return stop
        mult = float(getattr(self.s, "harvest_stop_mult", 3.0) or 3.0)
        floor = self.EXT_MIN_STOP_PCT if ext else 0.0025
        dist = max(mult * hv_pct / 100.0 * limit, floor * limit)
        if abs(limit - stop) <= dist:
            return stop
        return round(limit + dist if side == "sell" else limit - dist, 2)

    def _pick_veto(self, sg):
        """Better picking: skip sub-$2 stocks (spread eats the edge) and trades that fight a clear early direction call."""
        if sg.entry < self.HARD_MIN_PRICE and sg.symbol not in (self.s.watchlist or []):
            return f"price ${sg.entry:.2f} is under ${self.HARD_MIN_PRICE:.0f}: spread and one-cent moves eat the edge"
        for m in (self.movers or []):
            if m.get("symbol") == sg.symbol and m.get("call") in ("LONG", "SHORT") and abs(m.get("score") or 0) >= 25:
                if (m["call"] == "LONG" and sg.side == "sell") or (m["call"] == "SHORT" and sg.side == "buy"):
                    return f"fights the direction call ({m['call']}, score {m.get('score')}): not trading against it"
        return ""

    CHURN_LOSSES, CHURN_WINDOW_MIN = 2, 30

    def _load_releases(self):
        try:
            d = json.loads((DATA_DIR / "churn_release.json").read_text())
            self.churn_released = d if d.get("day") == self.day else {"day": self.day}
        except Exception:
            self.churn_released = {"day": self.day}

    def blocked_symbols(self, now=None):
        """Symbols blocked today: the last 2 closes were both losses, within CHURN_WINDOW_MIN minutes of each other,
        counted after any manual release. The block stays until the user releases it (or the next day)."""
        now = now or self.broker.now()
        if getattr(self, "churn_released", {}).get("day") != self.day:
            self._load_releases()
        rel = self.churn_released
        try:
            rows = [r for r in db.recent(300) if r.get("day") == self.day and r.get("status") == "closed" and r.get("mode") in (None, self.mode)]
        except Exception:
            return []
        by = {}
        for r in rows:
            by.setdefault(r["symbol"], []).append(r)
        out = []
        for sym, rs in by.items():
            rs.sort(key=lambda r: r.get("closed_at") or "")
            since = rel.get(sym)
            if since:
                rs = [r for r in rs if (r.get("closed_at") or "") > since]
            if len(rs) < self.CHURN_LOSSES:
                continue
            last = rs[-self.CHURN_LOSSES:]
            if not all((r.get("pnl") or 0) < 0 for r in last):
                continue
            try:
                span = (datetime.fromisoformat(last[-1]["closed_at"]) - datetime.fromisoformat(last[0]["closed_at"])).total_seconds() / 60
            except Exception:
                continue
            if span <= self.CHURN_WINDOW_MIN:
                out.append({"symbol": sym, "losses": sum(r["pnl"] for r in last), "since": last[-1]["closed_at"], "n": len(last)})
        return out

    def release_block(self, symbol):
        """Release one symbol (or '*' for all): losses before now no longer count."""
        if getattr(self, "churn_released", {}).get("day") != self.day:
            self._load_releases()
        stamp = self.broker.now().isoformat()
        syms = [b["symbol"] for b in self.blocked_symbols()] if symbol == "*" else [symbol.upper()]
        for s in syms:
            self.churn_released[s] = stamp
            self.sym_losses.pop(s, None)          # the older cooling-off counters too
            self.cooldown.pop(s, None)
        try:
            (DATA_DIR / "churn_release.json").write_text(json.dumps(self.churn_released))
        except Exception:
            pass
        self.event(f"Block released by you: {', '.join(syms) or 'none'}")
        return syms

    def _churn_block(self, sg, now):
        for b in self.blocked_symbols(now):
            if b["symbol"] == sg.symbol:
                return f"blocked after {b['n']} losing trades in a short time (${b['losses']:.2f}); tap Release on the dashboard to allow it again"
        return ""

    def _short_gate(self, sg, bars, now, no):
        """Automatic system rules (longs and/or shorts per auto_mode): a COMPLETED recent 1-minute bar, and after a winning exit only a
        distinct new signal. Returns False (after logging why) when the signal must be skipped."""
        if not self.s.auto_short:
            return True
        mode = getattr(self.s, "auto_mode", "both")
        if sg.side == "sell" and mode == "long":
            no("automatic system is set to longs only: short signal skipped")
            return False
        if sg.side != "sell" and mode == "short":
            no("automatic system is set to shorts only: long signal skipped")
            return False
        df = bars.get(sg.symbol)
        try:
            age = (now - df.index[-1]).total_seconds()
            if age < 60 or age > 240:
                no("automatic short system: waiting for a fresh completed 1-minute bar" if age < 60 else "automatic short system: bar is stale, waiting for fresh data")
                return False
        except Exception:
            pass
        lw = self.last_win.get(sg.symbol)
        if lw and lw["day"] == self.day and sg.strategy != "REENTRY":
            bounce = (sg.entry - lw["exit"]) * (-lw["dir"])          # price moved back against the winning trade
            distinct = sg.strategy != lw["strategy"] or ((now - lw["t"]).total_seconds() >= 900 and bounce >= 0.8 * max(sg.atr, 1e-9))
            if not distinct:
                no(f"after a winning {lw['strategy']} exit: waiting for a distinct new signal (different setup, or a 15-minute pause and a real bounce)")
                return False
        return True

    # ---------------- pre-market timeline: 4 AM, 7 AM, 8:30, 9:15 ----------------
    PM_SLOTS = [("4 AM", 4 * 60 + 10, 7 * 60), ("7 AM", 7 * 60 + 2, 8 * 60 + 30), ("8:30", 8 * 60 + 32, 9 * 60 + 15), ("9:15", 9 * 60 + 17, 9 * 60 + 30)]

    def _save_pm(self):
        try:
            (DATA_DIR / "premkt.json").write_text(json.dumps({"pm": self.pm, "open_shorts": self.open_shorts}))
        except Exception:
            pass

    def _load_pm(self):
        try:
            d = json.loads((DATA_DIR / "premkt.json").read_text())
            self.pm, self.open_shorts = d.get("pm") or {"day": "", "snaps": {}}, d.get("open_shorts") or []
        except Exception:
            pass

    def _pm_checkpoint(self, movers, sess_name, now):
        """Snapshot the movers list at 4 AM, 7 AM, 8:30 and 9:15, keep today's short-at-open list, and alert at 7 AM and 9:15."""
        hm = now.hour * 60 + now.minute
        if sess_name not in ("PRE", "REGULAR") or hm >= 9 * 60 + 30 and sess_name != "PRE":
            return
        if self.pm.get("day") != self.day:
            self.pm = {"day": self.day, "snaps": {}}
            self.open_shorts = []
        # short-at-open list: gapped up, faded off the pre-market high, lost VWAP, call not LONG
        cur = []
        for m in movers:
            rng = (m.get("hi") or 0) - (m.get("lo") or 0)
            if m["move"] >= 1.5 and m["price"] < m["vwap"] and rng > 0 and (m["hi"] - m["price"]) >= 0.4 * rng and m.get("call") != "LONG":
                cur.append({"symbol": m["symbol"], "move": m["move"], "price": m["price"], "trigger": m["lo"], "hi": m["hi"], "vwap": m["vwap"],
                            "call": m.get("call", ""), "why": "gapped up, faded off the pre-market high, under VWAP"})
        if sess_name == "PRE":
            self.open_shorts = cur[:8]
        for label, a, b in self.PM_SLOTS:
            if a <= hm < b and label not in self.pm["snaps"] and sess_name == "PRE":
                self.pm["snaps"][label] = {"at": now.strftime("%-I:%M %p"), "rows": {m["symbol"]: {"move": m["move"], "price": m["price"], "call": m.get("call", ""),
                                                                                                  "plan": m.get("plan", ""), "hi": m.get("hi"), "lo": m.get("lo")} for m in movers}}
                if label in ("7 AM", "9:15"):
                    top = ", ".join(f"{m['symbol']} {m['move']:+.1f}% {m.get('call', '')}" for m in movers[:4])
                    sh = ", ".join(x["symbol"] for x in self.open_shorts[:4])
                    self.event(f"{label} check: {top}" + (f". Short-at-open list: {sh}" if sh else ""))
                    self.alert("movers", f"⏰ {label} pre-market check", top + (f" | short at open: {sh}" if sh else ""))
        self._save_pm()

    def pm_timeline(self):
        snaps = self.pm.get("snaps", {}) if self.pm.get("day") == self.day else {}
        labels = [l for l, _, _ in self.PM_SLOTS if l in snaps]
        syms = list(dict.fromkeys([m["symbol"] for m in (self.movers or [])] + [x for l in labels for x in snaps[l]["rows"]]))[:14]
        rows = []
        osx = {x["symbol"] for x in self.open_shorts}
        for sy in syms:
            series = {l: snaps[l]["rows"].get(sy, {}).get("move") for l in labels}
            cur = next((m for m in (self.movers or []) if m["symbol"] == sy), None)
            vals = [v for v in series.values() if v is not None]
            peak = max(vals, key=abs) if vals else (cur or {}).get("move", 0)
            now_mv = cur["move"] if cur else (vals[-1] if vals else 0)
            trend = ""
            if peak and abs(peak) >= 1.0:
                trend = "faded" if abs(now_mv) < 0.6 * abs(peak) else ("extending" if abs(now_mv) >= abs(peak) * 0.98 and len(vals) > 1 else "holding")
            rows.append({"symbol": sy, "series": series, "now": now_mv, "call": (cur or {}).get("call", ""), "trend": trend, "short_open": sy in osx})
        return {"labels": labels, "rows": rows, "open_shorts": self.open_shorts}

    # ---------------- pre-close overnight short ----------------
    def _save_overnight(self):
        try:
            (DATA_DIR / "overnight.json").write_text(json.dumps({"positions": self.overnight, "evening": self.evening, "at": self.evening_at}))
        except Exception:
            pass

    def _load_overnight(self):
        try:
            d = json.loads((DATA_DIR / "overnight.json").read_text())
            self.overnight, self.evening, self.evening_at = d.get("positions") or {}, d.get("evening") or [], d.get("at") or ""
        except Exception:
            pass

    def _preclose_scan(self, bars, now, clk):
        """3:10-3:35 PM: find a failing spike or a weak close and short it into the close, holding overnight with a
        broker-held GTC stop and target. Off by default; needs SIP data and a short-enabled account."""
        if not self.s.preclose_short or self.risk.halted:
            return
        hm = now.hour * 60 + now.minute
        if not (15 * 60 + 10 <= hm <= 15 * 60 + 35):
            return
        if self._pc_scan_at and (now - self._pc_scan_at).total_seconds() < 240:
            return
        self._pc_scan_at = now
        if self.s.data_feed != "sip":
            self._skip("(all)", "PRECLOSE_SHORT", "sell", "overnight short needs the SIP data feed", now)
            return
        if not self.acct.get("shorting_enabled", True):
            self._skip("(all)", "PRECLOSE_SHORT", "sell", "your Alpaca account can't short", now)
            return
        try:
            nxt = clk["next_open"]
            if (nxt.date() - now.date()).days != 1:
                self._skip("(all)", "PRECLOSE_SHORT", "sell", "no trading day tomorrow: not holding a short over the weekend/holiday", now)
                return
        except Exception:
            return
        held = [x for x, o in self.overnight.items() if o.get("stage") in ("entry", "held")]
        if len(held) >= 2 or self._margin_block():
            return
        ctx = {"index_symbols": set(self.s.watch_always), "ribbon": self.ribbons, "gap": self.gaps}
        for c in preclose_candidates(bars, ctx)[:4]:
            sym = c["symbol"]
            if sym in self.overnight or sym in self.trades or sym in self.positions:
                continue
            ok, why = self._can_short(sym)
            if not ok:
                self._skip(sym, "PRECLOSE_SHORT", "sell", "overnight short skipped: " + why, now)
                continue
            if self.evfilter and self.evfilter.block_reason(sym, now, "AFTER"):
                self._skip(sym, "PRECLOSE_SHORT", "sell", "earnings / risky news around tonight", now)
                continue
            dec = self.risk.size(c["entry"], c["stop"], 0.5, self._open_risk(), self.acct.get("buying_power", 0))
            qty = int(getattr(dec, "qty", 0) or (dec.get("qty", 0) if isinstance(dec, dict) else 0))
            if qty < 1:
                self._skip(sym, "PRECLOSE_SHORT", "sell", "size came out under 1 share", now)
                continue
            bid = (self.broker.quotes([sym], "REGULAR") or {}).get(sym)
            px = round((bid[0] if bid else c["entry"]) * 0.999, 2)
            try:
                oid = self.broker.submit_limit_day(sym, "sell", qty, px, f"onsh-{uuid.uuid4().hex[:12]}")
            except Exception as ex:
                self.event(f"Overnight short {sym} failed: {str(ex)[:150]}", "warning")
                continue
            self.overnight[sym] = {"stage": "entry", "order_id": oid, "qty": qty, "stop": round(c["stop"], 2), "target": round(c["target"], 2),
                                   "entry_ref": round(px, 2), "kind": c["kind"], "opened": now.isoformat(), "day": self.day, "why": c["why"]}
            self._save_overnight()
            self.event(f"Overnight short {sym}: {qty} sh @ {px} ({c['kind']}, {c['why']}); GTC stop {c['stop']:.2f} / target {c['target']:.2f} go on once filled")
            break

    def _overnight_tick(self, now, clk):
        """Follow overnight shorts: place the GTC exits once filled, cancel an unfilled entry at 3:50, and next morning
        record the exit or cover whatever is left at 10:15."""
        if not self.overnight:
            return
        changed = False
        for sym, o in list(self.overnight.items()):
            try:
                hm = now.hour * 60 + now.minute
                if o["stage"] == "entry":
                    if o["day"] != self.day:                       # stale entry from an earlier day
                        self.broker.cancel_symbol_orders(sym)
                        self.overnight.pop(sym)
                        changed = True
                        continue
                    st, px, fq = self.broker.entry_status(o["order_id"])
                    if st == "filled" or (fq and st in ("partially_filled",) and hm >= 15 * 60 + 50):
                        if st != "filled":
                            self.broker.cancel(o["order_id"])
                        qty = int(fq or o["qty"])
                        oid = self.broker.oco_exit(sym, "buy", qty, o["stop"], o["target"], f"onx-{uuid.uuid4().hex[:12]}")
                        o.update(stage="held", qty=qty, entry=px or o["entry_ref"], exit_order=oid)
                        db.upsert({"id": f"ON-{sym}-{o['day']}", "day": o["day"], "mode": self.mode, "symbol": sym, "side": "sell",
                                   "strategy": "PRECLOSE_SHORT", "exit_profile": "GTC", "bucket": "CLOSE", "qty": qty, "entry": o["entry"],
                                   "stop": o["stop"], "target": o["target"], "risk": abs(o["stop"] - o["entry"]) * qty,
                                   "opened_at": o["opened"], "status": "open", "note": o["why"]})
                        self.event(f"Overnight short {sym} filled: {qty} sh @ {o['entry']:.2f}. Broker GTC stop {o['stop']:.2f} / target {o['target']:.2f} set. Stop can gap at the open.")
                        self.alert("movers", f"🌙 Overnight short: {sym}", f"{qty} sh @ {o['entry']:.2f}, stop {o['stop']:.2f}, target {o['target']:.2f}. Bot covers by 10:15 AM if neither hits.")
                        changed = True
                    elif hm >= 15 * 60 + 50 or st in ("canceled", "expired", "rejected"):
                        if st not in ("filled",):
                            self.broker.cancel(o["order_id"])
                        self.overnight.pop(sym)
                        self.event(f"Overnight short {sym} not filled: cancelled")
                        changed = True
                elif o["stage"] == "held" and o["day"] != self.day:
                    pos = self.positions.get(sym)
                    if not pos:                                       # stop or target hit at the open (or earlier)
                        px = self.broker.last_exit_price(sym, datetime.fromisoformat(o["opened"]), "buy") or o["entry"]
                        pnl = (o["entry"] - px) * o["qty"]
                        db.upsert({"id": f"ON-{sym}-{o['day']}", "day": o["day"], "mode": self.mode, "symbol": sym, "side": "sell",
                                   "strategy": "PRECLOSE_SHORT", "exit_profile": "GTC", "bucket": "CLOSE", "qty": o["qty"], "entry": o["entry"],
                                   "stop": o["stop"], "target": o["target"], "risk": abs(o["stop"] - o["entry"]) * o["qty"],
                                   "opened_at": o["opened"], "closed_at": now.isoformat(), "exit": round(px, 4), "pnl": round(pnl, 2),
                                   "r": round(pnl / max(abs(o["stop"] - o["entry"]) * o["qty"], 0.01), 3), "status": "closed", "note": o["why"]})
                        self.event(f"Overnight short {sym} closed at {px:.2f}: {pnl:+,.2f}")
                        self.alert("movers", f"🌙 Overnight short closed: {sym}", f"Exit {px:.2f}, P&L {pnl:+,.2f}")
                        self.overnight.pop(sym)
                        changed = True
                    elif hm >= 10 * 60 + 15 and clk.get("is_open"):
                        self.broker.cancel_symbol_orders(sym)
                        self.broker.close_position(sym)
                        self.event(f"Overnight short {sym}: 10:15 AM cover")
                        o["stage"] = "covering"
                        changed = True
                elif o["stage"] == "covering":
                    if sym not in self.positions:
                        px = self.broker.last_exit_price(sym, datetime.fromisoformat(o["opened"]), "buy") or o["entry"]
                        pnl = (o["entry"] - px) * o["qty"]
                        db.upsert({"id": f"ON-{sym}-{o['day']}", "day": o["day"], "mode": self.mode, "symbol": sym, "side": "sell",
                                   "strategy": "PRECLOSE_SHORT", "exit_profile": "GTC", "bucket": "CLOSE", "qty": o["qty"], "entry": o["entry"],
                                   "stop": o["stop"], "target": o["target"], "risk": abs(o["stop"] - o["entry"]) * o["qty"],
                                   "opened_at": o["opened"], "closed_at": now.isoformat(), "exit": round(px, 4), "pnl": round(pnl, 2),
                                   "r": round(pnl / max(abs(o["stop"] - o["entry"]) * o["qty"], 0.01), 3), "status": "closed", "note": "10:15 cover"})
                        self.event(f"Overnight short {sym} covered at {px:.2f}: {pnl:+,.2f}")
                        self.overnight.pop(sym)
                        changed = True
            except Exception as ex:
                log.warning("overnight %s: %s", sym, ex)
        if changed:
            self._save_overnight()

    # ---------------- evening candidates (prior-session review) ----------------
    def evening_review(self):
        """Replay the last session's final 90 minutes for your stocks and list the setups that fired or were forming.
        They become WATCH items: tomorrow morning they are scanned, but nothing is ordered until a fresh signal appears."""
        from datetime import time as _t
        syms = list(dict.fromkeys(list(self.s.watchlist) + [m["symbol"] for m in (self.movers or [])]
                                  + list(self.reg_universe or []) + list(self.universe or [])))[:30]
        items, seen = [], set()
        for sym in syms:
            if sym in self.s.watch_always:
                continue
            try:
                df, label = self.broker.analysis_bars(sym)
            except Exception:
                continue
            if df is None or len(df) < 120:
                continue
            e = enrich(df)
            day = e.index[-1].date()
            gap = self.gaps.get(sym, 0.0)
            ctx = {"aggressive": False, "bias": 0, "shorts": True, "index_symbols": set(self.s.watch_always), "gap": {sym: 0.0},
                   "all_flips": True, "morning_reversal": True}
            for i in range(len(e) - 90, len(e) + 1, 6):
                sl = e.iloc[:i]
                if len(sl) < 60:
                    continue
                ctx["ribbon"] = {sym: ribbon_state(df.iloc[:i])}
                try:
                    for sg in find_signals({sym: sl}, ctx):
                        k = (sym, sg.strategy)
                        if k in seen:
                            continue
                        seen.add(k)
                        items.append({"symbol": sym, "kind": sg.strategy, "side": "short" if sg.side == "sell" else "long",
                                      "price": round(sg.entry, 2), "at": sl.index[-1].strftime("%-I:%M %p"), "note": "signal fired in the last session"})
                except Exception:
                    pass
            try:
                ctx["ribbon"] = {sym: ribbon_state(df)}
                for c in preclose_candidates({sym: e}, ctx):
                    items.append({"symbol": sym, "kind": c["kind"], "side": "short", "price": round(c["entry"], 2), "at": "close",
                                  "note": c["why"] + " (overnight-short shape)"})
            except Exception:
                pass
        for it in items:
            it["status"] = "watch"
        self.evening = items[:40]
        self.evening_at = self.broker.now().strftime("%a %-I:%M %p")
        self._save_overnight()
        self.event(f"Evening review: {len(self.evening)} watch item(s) for tomorrow. Nothing is ordered until a fresh signal confirms.")
        return len(self.evening)

    def _dir_frame(self, sym, bars):
        """Bars for the direction call: today's bars with the pre-market bars in front, so it works from 9:30."""
        d = bars.get(sym)
        try:
            pre = self.pre_bars.get(sym)
            raw = self.raw.get(sym)
            if pre is not None and len(pre) and raw is not None and len(raw) and (d is None or len(d) < 60):
                pre = pre[pre.index < raw.index[0]]
                return enrich(pd.concat([pre.tail(90), raw]))
        except Exception:
            pass
        return d

    def _call_alert(self, m, now):
        """One phone alert per stock per day when a strong LONG/SHORT call appears."""
        try:
            if m.get("call") in ("LONG", "SHORT") and abs(m.get("score", 0)) >= 45 and not m.get("stretched"):
                key = (self.day, m["symbol"], m["call"])
                if key not in self._call_seen:
                    self._call_seen.add(key)
                    why = ", ".join(m.get("reasons", [])[:3])
                    self.event(f"Direction call: {m['symbol']} {m['call']} ({m['score']:+d}) {why}")
                    self.alert("movers", f"🧭 {m['symbol']}: {m['call']} call", f"{m['move']:+.1f}% move. {why}.")
        except Exception:
            pass

    def _calls_ok(self, side):
        """Stop auto-trading calls that the overnight study shows are wrong more often than right."""
        try:
            from .study import summary
            c = summary().get("calls", {}).get("LONG" if side == "buy" else "SHORT")
            return not (c and c["n"] >= 20 and c["hit"] < 50)
        except Exception:
            return True

    def _prior(self, sym):
        try:
            from .study import gap_prior
            return gap_prior(sym)
        except Exception:
            return None

    def direction_for(self, sym):
        """Direction call for any ticker, on demand (pre-market, open, any time)."""
        now = self.broker.now()
        df = self.broker.chart_bars(sym, days=6)
        if df is None or df.empty:
            return {"call": "WAIT", "score": 0, "agree": 0, "reasons": ["no recent bars"], "stretched": False}
        today = df[df.index.date == df.index[-1].date()]
        prev = df[df.index.date < df.index[-1].date()]
        prev = prev[(prev.index.time >= datetime.min.time().replace(hour=9, minute=30)) & (prev.index.time < datetime.min.time().replace(hour=16))]
        move = 0.0
        if len(prev):
            pc = float(prev["close"].iloc[-1])
            move = 100 * (float(today["close"].iloc[-1]) - pc) / pc if pc else 0.0
        e = enrich(today)
        rb = ribbon_state(today)
        r = direction(e, move, rb, self.bias, self._prior(sym))
        r.update(symbol=sym, move=round(move, 2), price=round(float(today["close"].iloc[-1]), 2), as_of=today.index[-1].strftime("%a %-I:%M %p"))
        return r

    def study_night(self, budget_s=900):
        """Overnight study: replay the last few trading days through every strategy and exit, teach the learner."""
        from .study import study
        if not hasattr(self.broker, "history"):
            return {"days": 0, "trades": 0, "note": "no history source"}
        now = self.broker.now()
        syms = list(dict.fromkeys(list(self.s.watchlist) + [m["symbol"] for m in (self.movers or [])]
                                  + list(self.reg_universe or []) + list(self.universe or [])))[:30]
        if not syms:
            return {"days": 0, "trades": 0, "note": "no symbols yet (run a scan first)"}
        hist = self.broker.history(syms, days=9)
        r = study(hist, self.learner, self.s, now, budget_s=budget_s)
        if r.get("trades"):
            b = ", ".join(f"{k} {n} trades {a:+.2f}R" for k, n, a in r.get("best", []))
            self.event(f"Overnight study: {r['note']}. Best: {b}")
        return r

    def _ribbons_seeded(self, raw, now):
        """Ribbon on today's bars with the pre-market bars in front of them, so it is ready at 9:30 instead of ~10:00."""
        try:
            if self._pre_day != self.day:
                self._pre_day, self.pre_bars = self.day, {}
            need = [k for k in raw if k not in self.pre_bars][:40]
            if need and now.hour < 14:
                got = self.broker.bars(need, start=now.replace(hour=8, minute=0, second=0, microsecond=0))
                for k in need:
                    v = got.get(k)
                    self.pre_bars[k] = v[v.index.time < datetime.min.time().replace(hour=9, minute=30)] if v is not None else None
        except Exception:
            pass
        out = {}
        for k, v in raw.items():
            if len(v) < 3:
                continue
            pre = self.pre_bars.get(k)
            try:
                if pre is not None and len(pre):
                    pre = pre[pre.index < v.index[0]]
                    v = pd.concat([pre.tail(150), v])
            except Exception:
                pass
            out[k] = ribbon_state(v)
        return out

    def _auto_level(self, sess):
        """Level = Auto: at the start of each session pick the level that has worked best in that session."""
        if not getattr(self.s, "level_auto", False) or not sess:
            return
        key = (self.day, sess.name)
        if self._level_key == key:
            return
        self._level_key = key
        lv, why = self.levels.pick(sess.name)
        apply_level(self.s, lv, sessions=False)
        self.s.level_active = lv
        self.s.save()
        self.event(f"Auto level for {sess.label}: {LEVELS[lv]['label']} ({why})")

    def _new_day(self, today):
        self.day = today
        self.risk.new_day()
        self.learner.daily_decay(today)
        self.universe, self.gaps, self.last_scan = [], {}, None
        self.ext_last_scan = None
        self.cooldown.clear()
        self.profit_locks.clear()
        self.entries_blocked_reason = ""
        self.loss_streak, self.pause_until, self.sym_losses = 0, None, {}
        self.event(f"New trading day {today} (daily loss limit window runs 8 PM -> 8 PM ET)")

    def _baseline(self):
        """Equity at the start of the bot day (8 PM ET), persisted so restarts don't reset the limit."""
        if self._base[0] == self.day:
            return self._base[1]
        try:
            st = json.loads(DAY_STATE.read_text())
            if st.get("day") == self.day and st.get("mode", self.mode) == self.mode and \
                    self._sane_base(float(st["baseline"])):
                self._base = (self.day, float(st["baseline"]))
                return self._base[1]
        except Exception:
            pass
        sess = self.session.name if self.session else ""
        base = self.acct["last_equity"] if sess in ("PRE", "REGULAR", "AFTER") else self.acct["equity"]
        self._base = (self.day, float(base))
        try:
            DAY_STATE.write_text(json.dumps({"day": self.day, "mode": self.mode, "baseline": self._base[1]}))
        except Exception:
            pass
        return self._base[1]

    def reset_day_baseline(self):
        """You asked for a fresh day: today's P&L starts again at $0 from the account's equity right now.
        Clears a daily-loss halt too. The journal and daily results keep every trade; the next 8 PM ET rollover is normal."""
        try:
            self._fresh_account(0)
        except Exception:
            pass
        eq = float(self.acct.get("equity") or 0)
        if eq <= 0:
            raise ValueError("no account equity yet")
        before = float(self.risk.day_pnl)
        was_halted = bool(self.risk.halted)
        self._base = (self.day, eq)
        try:
            DAY_STATE.write_text(json.dumps({"day": self.day, "mode": self.mode, "baseline": eq, "reset_by_user": True}))
        except Exception:
            pass
        self.risk.new_day()
        self.risk.equity = eq
        self.event(f"Daily P&L reset by you: today's P&L ${before:+,.2f} -> $0.00 (new baseline equity ${eq:,.2f})"
                   + ("; the daily-loss halt was cleared" if was_halted else ""), "warning")
        return {"before": round(before, 2), "baseline": round(eq, 2), "was_halted": was_halted}

    def _sane_base(self, base):
        """A saved start-of-day equity from another account (e.g. PAPER $100k after switching to LIVE)
        would look like a huge loss and flatten everything. Reject anything wildly off today's equity."""
        eq = (self.acct or {}).get("equity")
        if not eq or base <= 0:
            return base > 0
        return abs(eq - base) <= max(0.5 * eq, 3 * float(self.s.daily_max_loss))

    def _fit_qty(self, msg, qty, price):
        """Alpaca said 'insufficient buying power' (code 40310000) and told us the real buying_power and the order's
        cost_basis. Return a smaller quantity that fits (0 if none does or the error is something else)."""
        try:
            if "insufficient buying power" not in str(msg).lower():
                return 0
            m = re.search(r"\{.*\}", str(msg), re.S)
            d = json.loads(m.group(0)) if m else {}
            bp, cost = float(d.get("buying_power", 0)), float(d.get("cost_basis", 0))
            if bp > 0 and cost > 0:
                q = int(qty * bp * 0.96 / cost)
            elif bp > 0 and price > 0:
                q = int(bp * 0.96 / price)
            else:
                return 0
            return q if 1 <= q < qty else 0
        except Exception:
            return 0

    def _fresh_account(self, max_age=20):
        """Extended-hours ticks don't refresh the account like regular hours do: re-read it so sizing uses today's
        real buying power, not a stale number."""
        try:
            now = self.broker.now()
            last = getattr(self, "_acct_at", None)
            if last is None or (now - last).total_seconds() >= max_age:
                self.acct = self.broker.account()
                self._acct_at = now
        except Exception:
            pass

    def _margin_block(self):
        """FINRA retired the PDT rule on June 4, 2026 (Alpaca: Intraday Margin Framework). There is no
        day-trade count anymore; the limit is intraday buying power, and unmet intraday margin calls
        can restrict the account for 90 days. So pause new bot entries when buying power is nearly gone."""
        a = self.acct or {}
        if self.mode == "SIM" or "buying_power" not in a:
            return False
        low = a["buying_power"] < max(100.0, 0.02 * a.get("equity", 0))
        if low and not self.entries_blocked_reason:
            self.event(f"New entries skipped: buying power is only ${a['buying_power']:,.2f}", "warning")
        return low

    def _scan(self):
        try:
            acct = self.broker.account()
            self.acct = self.acct or acct
        except Exception:
            acct = self.acct or {}
        uni, gaps = self.broker.scan(self.s, acct)
        self.scan_info = getattr(self.broker, "last_scan_info", []) or []
        self.universe, self.gaps = uni, gaps
        self.reg_universe = list(uni)
        self.last_scan = self.broker.now()
        top = ", ".join(f"{u}({gaps.get(u, 0):+.1f}%)" for u in uni[:8])
        self.event(f"Stock picker: {len(uni)} best fits for your account — {top}")

    # ---------------- entries ----------------
    def _entries(self, bars, now):
        with self.lock:
            active = len(self.trades)
        slots = (self.s.max_positions + (2 if self.aggro else 0)) - active
        if slots <= 0 or self.entries_blocked_reason or self._margin_block():
            if self.entries_blocked_reason:
                self._skip("(all)", "-", "", "new entries blocked: " + str(self.entries_blocked_reason), now)
            elif slots > 0:
                self._skip("(all)", "-", "", "margin / buying-power check blocked new entries", now)
            return
        if self.pause_until and not self.s.cooloff_streak:
            self.pause_until = None
        if self.pause_until and now < self.pause_until:
            self.state = f"COOLING OFF until {self.pause_until.strftime('%H:%M')} (loss streak)"
            self._skip("(all)", "-", "", f"cooling off until {self.pause_until.strftime('%H:%M')} after a loss streak", now)
            return
        ctx = {"aggressive": self.aggro, "bias": self.bias, "gap": self.gaps, "shorts": bool(self.shorts_allowed(now) and self.acct.get("shorting_enabled", True)),
               "index_symbols": set(self.s.watch_always), "ribbon": self.ribbons, "all_flips": self.s.trade_all_flips,
               "morning_reversal": self.s.morning_reversal, "reentry": self._reentry_ctx(now),
               "open_shorts": ({m["symbol"]: m for m in self.open_shorts} if (self.s.pre_plan and self.pm.get("day") == self.day) else {}),
               "calls": ({m["symbol"]: m for m in (self.movers or []) if m.get("call") in ("LONG", "SHORT")} if self.s.auto_direction else {}),
               "plan": {m["symbol"]: m for m in (self.movers or [])
                        if abs(self.gaps.get(m["symbol"], 0.0)) >= 0.8 and (self.gaps.get(m["symbol"], 0.0) > 0) == (m.get("move", 0) > 0)}}
        sigs = find_signals(bars, ctx)
        bucket = time_bucket(now)
        ranked = []
        fired = {(sg.symbol, sg.strategy) for sg in sigs}
        for sym in list(bars):                      # explain ribbon flips that did NOT become a trade
            if sym in ctx["index_symbols"] or (sym, "RIBBON_FLIP") in fired:
                continue
            try:
                w = ribbon_why(sym, bars[sym], ctx)
            except Exception:
                w = None
            if w:
                self._skip(sym, "RIBBON_FLIP", "", w, now)
        for sg in sigs:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, why, now)
            if sg.symbol in self.trades or sg.symbol in self.positions:
                continue
            if self.manual_syms.get(sg.symbol) == self.day:
                no("you traded this symbol manually today — bot leaves it alone")
                continue
            why_c = self._churn_block(sg, now)
            if why_c:
                no(why_c)
                continue
            why_v = self._pick_veto(sg) or self._pair_block(sg.symbol) or self._spread_block(sg, "REGULAR")
            if why_v:
                no(why_v)
                continue
            if not self._short_gate(sg, bars, now, no):
                continue
            if self.s.cooloff_symbol and self.sym_losses.get(sg.symbol, 0) >= 2:
                no("dropped for today after 2 losses on this symbol (Cooling-off setting)")
                continue
            cd = self.cooldown.get(sg.symbol)
            if cd and now < cd and self.s.cooloff_symbol and sg.strategy != "REENTRY":
                no(f"symbol cooling off until {cd.strftime('%H:%M')} after a recent trade")
                continue
            if sg.side == "sell":
                ok, why = self._can_short(sg.symbol)
                if not ok:
                    no("short signal skipped — " + why)
                    continue
            ch = self.learner.choose(sg.strategy, bucket, sg.quality)
            force = self.s.trade_all_flips and sg.strategy == "RIBBON_FLIP"
            if force and not ch:
                ch = ("RIBBON", 0.5, 1.0)
            if not ch:
                no("learner: this strategy currently scores too poorly to trade")
                continue
            if self.s.auto_short and ch[0] not in ("SCALE", "RIBBON") and not self.s.scalp_mode and not self.aggro:
                ch = ("SCALE", ch[1], ch[2])          # short system: take portions near +1R and +2R, trail the rest
            if sg.strategy == "DIR_CALL" and not self._calls_ok(sg.side):
                no("direction calls of this kind have been right less than half the time in the overnight study")
                continue
            if sg.strategy in ("PLAN_TREND", "GAP_GO", "DIR_CALL", "REENTRY") and ch[0] in ("QUICK", "SCALP", "AGGRO") and not self.s.scalp_mode and not self.aggro:
                ch = ("SCALE", ch[1], ch[2])          # a morning trend is ridden (profit along the way), not scalped
            if ch[1] < (0.0 if (self.aggro or force) else MIN_SCORE):
                no(f"learner score {ch[1]:.2f} is below the minimum {MIN_SCORE:.2f} (strategy is cold)")
                continue
            if not force and self._tod_blocked(now, sg.strategy):
                no(f"time-of-day filter: your own history loses money in this time slot ({time_bucket(now)})")
                continue
            if self.s.auto_tune:
                okt, m, rk, why = self.tuner.gate(sg.strategy, self.day, getattr(self.s, 'proven_only', True))
                if not okt:
                    no(why)
                    continue
                if why and why.startswith("probe"):
                    self.event(f"Self-fix: {sg.strategy} {why}", "info")
                ch = (ch[0], ch[1], ch[2] * m)
                ranked.append((ch[1] * rk, sg, ch))
                continue
            ranked.append((ch[1], sg, ch))
        ranked.sort(key=lambda x: x[0], reverse=True)

        taken = set()
        for score, sg, (ep, _, weight) in ranked:
            if slots <= 0:
                self._skip(sg.symbol, sg.strategy, sg.side, "all position slots are full", now)
                continue
            if sg.symbol in taken:
                continue
            why_p = self._pair_block(sg.symbol, taken)
            if why_p:
                self._skip(sg.symbol, sg.strategy, sg.side, why_p, now)
                continue
            if self._event_block(sg.symbol, now):
                self._skip(sg.symbol, sg.strategy, sg.side, "earnings / risky-news filter", now)
                continue
            _hv = float(getattr(self.s, "pct_harvest_pct", 0.10)) + self._slip_pct()
            _ns = self._harvest_stop(sg.entry, sg.stop, sg.side, False, sg.strategy, _hv)
            if _ns != sg.stop:
                sg.stop = _ns
            open_risk = self._open_risk()
            if self.loss_streak >= 3 and self.s.cooloff_streak:
                weight *= 0.5           # trade smaller while cold
            if self.aggro:
                weight *= 0.6           # more trades -> smaller size each
            dec = self.risk.size(sg.entry, sg.stop, weight, open_risk, self.acct.get("buying_power", 0))
            if dec.qty < 1:
                self._skip(sg.symbol, sg.strategy, sg.side, f"risk sizing gave 0 shares ({dec.reason})", now)
                continue
            ep = self._harvest_profile(ep)
            prof = EXIT_PROFILES[ep]
            r0 = sg.risk_per_share
            d = 1 if sg.side == "buy" else -1
            target = sg.entry + d * prof["target_r"] * r0
            limit = sg.entry * (1 + d * 0.0015)   # marketable limit, max 0.15% slippage
            cid = f"ab-{uuid.uuid4().hex[:12]}"
            try:
                try:
                    oid = self.broker.submit_bracket(sg.symbol, sg.side, dec.qty, limit, sg.stop, target, cid)
                except Exception as e1:
                    q2 = self._fit_qty(e1, dec.qty, limit)
                    if not q2:
                        raise
                    self.event(f"{sg.symbol}: buying power short for {dec.qty} sh, retrying with {q2}", "warning")
                    dec = type(dec)(q2, round(q2 * r0, 2), dec.reason)
                    cid = f"ab-{uuid.uuid4().hex[:12]}"
                    oid = self.broker.submit_bracket(sg.symbol, sg.side, dec.qty, limit, sg.stop, target, cid)
            except Exception as e:
                msg = str(e)
                self.event(f"Order rejected {sg.symbol}: {msg[:160]}", "warning")
                self._skip(sg.symbol, sg.strategy, sg.side, "Alpaca rejected the order: " + msg[:100], now)
                self.alert("reject", f"Order rejected: {sg.symbol}", msg[:160], symbol=sg.symbol)
                low = msg.lower()
                if "pattern day" in low or "day trad" in low or "margin call" in low or "restricted" in low:
                    self.entries_blocked_reason = "Broker restriction (margin / trading rule)"
                    self.event("New entries paused for today (broker restriction: " + msg[:100] + ")", "warning")
                    self.alert("restrict", "New entries paused", "Alpaca restricted new orders: " + msg[:140])
                    return
                continue
            t = Trade(cid, sg.symbol, sg.side, sg.strategy, ep, time_bucket(now), dec.qty, sg.entry, sg.stop,
                      sg.stop, target, sg.atr, dec.risk_dollars, now, oid, day=self.day, mode=self.mode)
            if sg.strategy == "REENTRY":
                t.note = f"re-entry ({sg.extra.get('kind', '')})"
                self.event(f"RE-ENTRY {sg.symbol} {sg.side} ({sg.extra.get('kind', '')})")
                st_ = self.reentry.get(sg.symbol)
                if st_:
                    st_["taken"] = True          # keep n for the chain, but no second order until this trade closes
            with self.lock:
                self.trades[sg.symbol] = t
            self.tuner.used(sg.strategy, self.day)
            db.upsert(t.row(status="pending"))
            taken.add(sg.symbol)
            slots -= 1
            self.event(f"ENTRY {sg.side.upper()} {dec.qty} {sg.symbol} @{sg.entry:.2f} [{sg.strategy}/{ep}] "
                       f"stop {sg.stop:.2f} target {target:.2f} risk ${dec.risk_dollars:.0f} (w={weight:.2f})")
            self.alert("entry", f"🟢 BOT {'BUY' if sg.side == 'buy' else 'SHORT'} {dec.qty} {sg.symbol} @ {sg.entry:.2f}",
                       f"{sg.strategy} · stop {sg.stop:.2f} · target {target:.2f} · risk ${dec.risk_dollars:.0f}",
                       symbol=sg.symbol, close_btn=True)

    def _event_block(self, sym, now, session="REGULAR"):
        if not self.evfilter:
            return False
        why = self.evfilter.block_reason(sym, now, session)
        if why:
            last = self._ev_logged.get(sym)
            if last is None or (now - last).total_seconds() > 1800:
                self._ev_logged[sym] = now
                self.event(f"Skipping {sym}: {why}")
            return True
        return False

    def _open_risk(self):
        tot = 0.0
        with self.lock:
            for t in self.trades.values():
                px = t.last_price or t.entry
                tot += max(0.0, (px - t.stop) * t.dir) * t.qty
        return tot

    # ---------------- position management ----------------
    def _manage(self, bars, now):
        with self.lock:
            trades = list(self.trades.values())
        try:                                    # live bid/ask: what a close would REALLY fill at (bid for longs, ask for shorts)
            qs = self.broker.quotes([t.symbol for t in trades if t.status == "open" and not t.ext], "REGULAR") or {}
        except Exception:
            qs = {}
        for t in trades:
            if t.status != "open" or t.ext:
                continue
            df = bars.get(t.symbol)
            price = float(df["close"].iloc[-1]) if df is not None and len(df) else \
                self.positions.get(t.symbol, {}).get("price", t.entry)
            t.last_price = price
            prof = EXIT_PROFILES[t.exit_profile]
            r = t.r_now(price)
            q = qs.get(t.symbol)
            xp = None
            if q and q[0] and q[1] and (self.broker.now() - q[2]).total_seconds() < 20:
                xp = q[0] if t.dir > 0 else q[1]
                r = t.r_now(xp)                  # banking decisions use the price we can actually get, not the last trade
            t.exit_px_seen = xp or price
            if self._pct_take(t, xp or price):
                self.event(f"💰 HARVEST {t.symbol}: +{self.s.pct_harvest_pct:g}% banked ({r:+.2f}R) — re-entering while the trend holds")
                t.note = "harvest"
                self._close(t)
                continue
            if self._quick_harvest(t, r):
                self.event(f"💰 HARVEST {t.symbol}: banked at {r:+.2f}R (momentum stalled) — free to re-enter")
                t.note = "harvest"
                self._close(t)
                continue
            lvl, giveback = self._gain_lock(t, r)
            if giveback:
                self.event(f"💰 PROFIT LOCK {t.symbol}: banked {r:+.2f}R (best was {t.peak_r:+.2f}R)")
                t.note = "profit lock"
                self._close(t)
                continue
            if self._turn_warn(t, r, bars):
                n = self._warned.get(t.id, 0) + 1
                self._warned[t.id] = n
                if n == 1 and t.qty >= 2 and t.scaled < 3 and r >= 0.5:
                    self.event(f"⚠️ {t.symbol} direction turning against the trade at {r:+.2f}R — banking half")
                    self._take_partial(t, price, r, 0.5)
                    t.scaled = max(t.scaled, 1)
                elif n >= 2 and r >= 0.3:
                    self.event(f"💰 REVERSAL EXIT {t.symbol}: direction turned against the trade, banked {r:+.2f}R")
                    t.note = "reversal exit"
                    self._close(t)
                    continue
            else:
                self._warned[t.id] = 0
            steps = prof.get("scale") or []
            if t.scaled < len(steps) and r >= steps[t.scaled][0]:
                self._take_partial(t, price, r, steps[t.scaled][1])
            new_stop = t.stop
            if lvl is not None:
                new_stop = max(new_stop, lvl) if t.dir > 0 else min(new_stop, lvl)
            if prof["be_at_r"] is not None and r >= prof["be_at_r"]:
                be = t.entry + t.dir * 0.02 * abs(t.entry - t.stop_init)
                new_stop = max(new_stop, be) if t.dir > 0 else min(new_stop, be)
            if prof["trail_after_r"] is not None and r >= prof["trail_after_r"]:
                atr = float(df["atr"].iloc[-1]) if df is not None else t.atr
                tr = price - t.dir * prof["trail_atr"] * atr
                new_stop = max(new_stop, tr) if t.dir > 0 else min(new_stop, tr)
            if (new_stop - t.stop) * t.dir > 0.001 * t.entry:
                ok = self.broker.update_stop(t.symbol, new_stop)
                t.stop = new_stop
                self.event(f"Stop -> {new_stop:.2f} on {t.symbol} ({r:.1f}R){'' if ok else ' [soft stop]'}")
                self.alert("breakeven", f"Stop raised on {t.symbol} → {new_stop:.2f}", f"Trade is at {r:+.1f}R",
                           symbol=t.symbol, close_btn=True)
            # soft stop (covers trailing stops the server leg couldn't be moved to)
            if (price - t.stop) * t.dir <= 0 and t.stop != t.stop_init:
                self.event(f"EXIT {t.symbol}: trailing/breakeven stop hit @{price:.2f}")
                t.note = "trail stop"
                self._close(t)
                continue
            rb = self.ribbons.get(t.symbol)
            flipped = bool(prof.get("exit_on_flip") and rb and rb["ready"] and rb["state"] == -t.dir)
            self._flip_n[t.id] = (self._flip_n.get(t.id, 0) + 1) if flipped else 0
            if flipped and self._flip_n[t.id] >= (3 if getattr(self.s, "let_run", True) else 1):
                self.event(f"EXIT {t.symbol}: ribbon flipped {'red' if t.dir > 0 else 'green'} @{price:.2f} ({r:+.2f}R)")
                t.note = "ribbon flip"
                self._close(t)
                continue
            age = (now - t.opened_at).total_seconds() / 60
            riding = prof.get("exit_on_flip") and rb and rb["state"] == t.dir
            if age >= prof.get("time_stop", self.s.time_stop_minutes) and r < 0.3 and not riding:
                self.event(f"EXIT {t.symbol}: time stop after {age:.0f}m ({r:.2f}R)")
                t.note = "time stop"
                self._close(t)

    @property
    def aggro(self):
        return bool(getattr(self.s, "aggressive_scalp", False))

    def end_cooloff(self):
        """'Resume now': clear the loss-streak pause, the half-size penalty and symbol cooldowns for today."""
        self.pause_until, self.loss_streak = None, 0
        self.cooldown.clear()
        self.sym_losses = {}
        self.event("Cooling off cleared — trading resumes at full size")

    def _update_movers(self, bars, moves, sess_name, now):
        """Big-mover list (pre-market gap / after-hours news) + one phone alert per session."""
        try:
            new = rank_movers(bars, self.ribbons, moves, tuple(self.s.watch_always), self.s.watchlist)
        except Exception:
            new = []
        for m in new:                                 # early direction call for each mover
            try:
                m.update({k: v for k, v in direction(self._dir_frame(m["symbol"], bars), m["move"], (self.ribbons or {}).get(m["symbol"]),
                                                     self.bias, self._prior(m["symbol"])).items() if k != "parts"})
                self._call_alert(m, now)
            except Exception:
                pass
        if new and self.s.pre_plan:
            try:
                self._pm_checkpoint(new, sess_name, now)
            except Exception as ex:
                log.warning("pre-market checkpoint: %s", ex)
        if new:                                   # keep the last good list when a scan comes back empty
            self.movers = new
            lab = {"PRE": "Pre-market", "AFTER": "After-hours", "REGULAR": "Morning gaps", "MANUAL": "Scan"}.get(sess_name, sess_name)
            self.movers_at = f"{now.strftime('%a %-I:%M %p')} · {lab}"
            self._save_movers()
        try:
            if not self.movers or sess_name not in ("PRE", "AFTER"):
                return
            key = (self.day, sess_name)
            hhmm = now.strftime("%H:%M")
            due = (sess_name == "PRE" and hhmm >= "08:55") or (sess_name == "AFTER" and hhmm >= "16:05")
            if due and self._movers_alerted != key:
                self._movers_alerted = key
                top = self.movers[:4]
                line = " · ".join(f"{m['symbol']} {m['move']:+.1f}% {m['plan']} {m['side']}" for m in top)
                title = "🌅 Morning movers" if sess_name == "PRE" else "🌙 Evening movers"
                self.event(f"{title}: {line}")
                self.alert("movers", title, line + " — tap the app for triggers and targets")
        except Exception:
            pass

    def _save_movers(self):
        try:
            (DATA_DIR / "prep.json").write_text(json.dumps({"movers": self.movers, "at": self.movers_at}))
        except Exception:
            pass

    def _load_movers(self):
        try:
            d = json.loads((DATA_DIR / "prep.json").read_text())
            self.movers, self.movers_at = d.get("movers") or [], d.get("at") or ""
        except Exception:
            pass

    def prep_movers(self, sess):
        """Build the pre-market / after-hours movers list on demand. Used by the timer while the bot is stopped,
        so the morning and night setup is ready without pressing anything."""
        now = self.broker.now()
        uni, moves = self.broker.ext_scan(self.s, sess.name, extra=list(dict.fromkeys([x['symbol'] for x in self.shortlist][:15] + list((self.reg_universe or self.universe or [])[:10]))))
        if not moves:
            return 0
        syms = list(dict.fromkeys(list(self.s.watchlist) + [u for u in uni if u not in self.s.watch_always]))[:40]
        raw = self.broker.bars(syms, start=sess.start - timedelta(minutes=60)) if syms else {}
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 8}
        self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
        self.ext_moves = moves
        try:
            self.setups = rank_setups(bars, self.ribbons, self.scan_info, tuple(self.s.watch_always))
        except Exception:
            pass
        self._update_movers(bars, moves, sess.name, now)
        return len(self.movers)

    def refresh_setups(self):
        """🎯 On-demand 'Setting up now' list (Scan now), also when the bot is stopped or the market is closed."""
        syms = list(dict.fromkeys(self.universe + list(self.s.watchlist)))[:40]
        raw = self.broker.bars(syms) if syms else {}
        if sum(1 for v in raw.values() if len(v) >= 30) < 3 and hasattr(self.broker, "analysis_bars"):
            raw = {}
            for sm in syms[:30]:                       # market closed: use each stock's latest session
                try:
                    df, _ = self.broker.analysis_bars(sm)
                    if df is not None and len(df) >= 30:
                        raw[sm] = df
                except Exception:
                    continue
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 30}
        rib = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 30}
        self.setups = rank_setups(bars, rib, self.scan_info, tuple(self.s.watch_always))
        try:
            self._update_movers(bars, {k: g for k, g in self.gaps.items() if abs(g) >= 1.0}, "MANUAL", self.broker.now())
        except Exception:
            pass
        return self.setups

    def _harvest_profile(self, ep):
        """Profit harvesting in every session: aggressive scalp, then scalp, then take-profit-along-the-way."""
        if getattr(self.s, "let_run", True) and getattr(self.s, "scale_out", True):
            return "SCALE"                         # let winners run: no scalp profiles
        if self.aggro:
            return "AGGRO"
        if getattr(self.s, "scalp_mode", False):
            return "SCALP"
        if getattr(self.s, "scale_out", False):
            return "SCALE"
        return ep

    SLIP_FILE = DATA_DIR / "slippage.json"

    def _slip_pct(self):
        """Average % lost between the moment the bot decides to close and the actual fill (learned, persisted)."""
        v = getattr(self, "_slip", None)
        if v is None:
            try:
                v = float(json.loads(self.SLIP_FILE.read_text()).get("ema", 0.0))
            except Exception:
                v = 0.0
            self._slip = v
        return v

    def _note_slip(self, t, fill_px):
        """Compare the price we decided at with the fill. Positive = the exit got worse (delay / spread)."""
        if not t.decide_px or not t.entry or not fill_px or not t.decide_t:
            return
        if t.note in ("stop", "trail stop", "time stop", "EOD") or str(t.note).startswith("Daily"):
            return          # stop-outs slip far more than calm exits; learning from them would bloat the harvest target
        slip = (t.decide_px - fill_px) * t.dir / t.entry * 100
        lat = max(0.0, time.time() - t.decide_t)
        cur = self._slip_pct()
        self._slip = max(0.0, min(0.5, 0.8 * cur + 0.2 * max(slip, 0.0)))     # only the cost side; capped at 0.5%
        try:
            self.SLIP_FILE.write_text(json.dumps({"ema": round(self._slip, 4), "last": round(slip, 4), "lat": round(lat, 1)}))
        except Exception:
            pass
        if abs(slip) >= 0.03 or lat >= 5:
            self.event(f"Exit {t.symbol}: decided @{t.decide_px:.2f}, filled @{fill_px:.2f} ({-slip:+.3f}%), took ~{lat:.0f}s. "
                       f"Harvest targets now add {self._slip:.3f}% for this slippage.")

    def _learned_pct(self):
        """The harvest % learned from the user's own manual wins; refreshed in the background every 30 minutes."""
        ml = getattr(self, "_ml", None)
        if ml is None:
            ml = self._ml = {"t": 0.0, "pct": None, "busy": False}
        if time.time() - ml["t"] > 1800 and not ml["busy"] and hasattr(self.broker, "trading"):
            ml["busy"] = True
            def run():
                try:
                    from . import manuallearn
                    r = manuallearn.learn(self.broker, 60)
                    self.manual_learn = r
                    ml["pct"] = r.get("suggest_harvest_pct") if r.get("ready") else None
                except Exception as ex:
                    log.warning("manual learn: %s", ex)
                finally:
                    ml["t"], ml["busy"] = time.time(), False
            threading.Thread(target=run, daemon=True, name="manual-learn").start()
        return ml["pct"]

    def _pct_take(self, t, price):
        """Hand-trader style harvest (Controls: Harvest small %): once the trade is up pct_harvest_pct % of the entry
        (never less than 3 cents a share, so the spread can't turn it into a loss), bank it. The re-entry logic then
        gets back in on a pullback or a run to a new extreme while the ribbon and VWAP still agree."""
        if not getattr(self.s, "pct_harvest", False) or t.qty <= 0:
            return False
        pct = float(getattr(self.s, "pct_harvest_pct", 0.10))
        if getattr(self.s, "pct_harvest_auto", False):
            pct = self._learned_pct() or pct
        pct = max(pct, float(getattr(t, "hv_pct", 0) or 0))             # wide-spread / trend trades bank a bigger gain
        need = max((pct + self._slip_pct()) / 100.0 * t.entry, 0.03)     # + what exits have been costing us
        return (price - t.entry) * t.dir >= need - 1e-9

    def _quick_harvest(self, t, r):
        """Scalps (AGGRO / SCALP): once a trade has been green for 2+ checks, don't wait for the target —
        bank it as soon as momentum stalls (gives back 0.15R from its best) or it's near the target."""
        if t.exit_profile not in ("AGGRO", "SCALP") or getattr(self.s, "let_run", True):
            return False
        t.peak_r = max(t.peak_r, r)
        t.pos_ticks = t.pos_ticks + 1 if r >= 0.25 else 0
        tgt = EXIT_PROFILES[t.exit_profile]["target_r"]
        return t.pos_ticks >= 2 and (r <= t.peak_r - 0.15 or r >= 0.85 * tgt) and r > 0.1

    def _gain_lock(self, t, r):
        """Give-back lock for EVERY trade: once it has been green 0.6R+, never hand back more than 40% of the best
        gain (50% from 1.2R, 60% from 2R, 70% from 3R). Returns (stop_level, exit_now)."""
        t.peak_r = max(t.peak_r, r)
        pk = t.peak_r
        if pk < 0.6:
            return None, False
        frac = 0.4 if pk < 1.2 else 0.5 if pk < 2 else 0.6 if pk < 3 else 0.7
        lock_r = pk * frac
        lvl = t.entry + t.dir * lock_r * abs(t.entry - t.stop_init)
        return lvl, r <= lock_r

    def _turn_warn(self, t, r, bars):
        """The app's early 'turning against you' call (direction vote) on a trade that is green. Cached 30 s per symbol."""
        if r < 0.4:
            return False
        try:
            now = self.broker.now()
            c = self._warn_cache.get(t.symbol)
            if not c or (now - c[0]).total_seconds() > 30:
                d = self._dir_frame(t.symbol, bars)
                res = direction(d, 0.0, (self.ribbons or {}).get(t.symbol), self.bias, None) if d is not None else {}
                c = (now, res)
                self._warn_cache[t.symbol] = c
            res = c[1]
            call, sc = res.get("call"), abs(res.get("score", 0))
            against = (call == "SHORT" and t.dir > 0) or (call == "LONG" and t.dir < 0)
            return bool(against and sc >= 55)
        except Exception:
            return False

    def _take_partial(self, t, price, r, frac):
        """💰 Take profit along the way: sell part, move the stop on the rest to break-even or better."""
        q = int(t.qty * frac)
        if q < 1 or q >= t.qty:
            t.scaled += 1
            return
        lock = -0.5 if (t.scaled == 0 and getattr(self.s, "let_run", True)) else 0.02      # first partial: stop only to -0.5R, so a normal pullback doesn't end the run
        be = t.entry + t.dir * lock * abs(t.entry - t.stop_init)
        new_stop = max(t.stop, be) if t.dir > 0 else min(t.stop, be)
        try:
            rem = self.broker.partial_exit(t.symbol, q, t.side, new_stop, t.target)
        except Exception as e:
            self.event(f"Partial take-profit on {t.symbol} failed: {str(e)[:140]}", "warning")
            t.scaled += 1
            return
        gain = (price - t.entry) * t.dir * q
        t.realized += gain
        t.qty0 = t.qty0 or t.qty
        t.qty = rem or (t.qty - q)
        t.stop = new_stop
        t.scaled += 1
        self.event(f"💰 TOOK PROFIT {t.symbol}: sold {q} @~{price:.2f} (+{r:.1f}R, ${gain:,.2f}); "
                   f"{t.qty:g} left, stop → {new_stop:.2f}")
        self.alert("profit", f"💰 Took profit {t.symbol} +${gain:,.2f}",
                   f"Sold {q} at +{r:.1f}R · {t.qty:g} left riding · stop {new_stop:.2f}", symbol=t.symbol, close_btn=True)

    def _tod_blocked(self, now, strategy=""):
        """Skip times of day where your own trade history loses money (Positions → Trading stats)."""
        if not getattr(self.s, "tod_filter", False):
            return False
        from . import stats as st
        if not hasattr(self, "_tod") or (now - self._tod[0]).total_seconds() > 6 * 3600:
            by = {}
            try:
                by = st.summarize(st.round_trips(st.fetch_fills(self.broker, 90)), (), 90)["by_bucket"]
            except Exception:
                by = {}
            self._tod = (now, by)
            bad = [b for b, v in by.items() if v["trades"] >= self.s.tod_min_trades and v["pnl"] < 0]
            if bad:
                self.event("Time-of-day filter (from your last 90 days): skipping " + ", ".join(bad))
        b = st.bucket(now)
        v = self._tod[1].get(b)
        if not v or v["trades"] < self.s.tod_min_trades or v["pnl"] >= 0:
            return False
        # your best trades are opening drives: allowed in the first 20 minutes even if the morning loses overall
        if strategy.startswith("OPEN_DRIVE") and now.hour == 9 and now.minute < 50:
            return False
        if strategy.startswith("FLUSH"):          # sudden flushes can happen any time; always allowed
            return False
        return True

    def _close(self, t):
        t.decide_px = float(getattr(t, "exit_px_seen", 0) or t.last_price or 0)
        t.decide_t = time.time()
        ok = self.broker.close_position(t.symbol)
        if ok is False and not getattr(t, "_close_warned", False):
            t._close_warned = True
            err = getattr(self.broker, "last_close_error", "")
            self.event(f"Could not close {t.symbol}: {err[:160]}", "error")
            self.alert("reject", f"⚠ Close failed: {t.symbol}", (err[:160] or "") + " — check the position in Alpaca.",
                       symbol=t.symbol, level="warning")

    def _reconcile(self):
        now = self.broker.now()
        with self.lock:
            trades = list(self.trades.values())
        for t in trades:
            pos = self.positions.get(t.symbol)
            if t.status == "pending":
                st, px, fq = self.broker.entry_status(t.order_id)
                if st in ("filled", "partially_filled") or pos:
                    if st == "partially_filled":
                        self.broker.cancel(t.order_id)
                    t.status = "open"
                    if px:
                        t.entry = px
                    if pos:
                        t.qty = abs(pos["qty"])
                    elif fq:
                        t.qty = fq
                    db.upsert(t.row(status="open", entry=t.entry))
                    self.event(f"FILLED {t.symbol} {t.qty:g} @{t.entry:.2f}")
                    self.alert("fill", f"Filled {t.symbol} {t.qty:g} @ {t.entry:.2f}", t.strategy,
                               symbol=t.symbol, close_btn=True)
                elif st in ("canceled", "expired", "rejected", "done_for_day") or \
                        (now - t.opened_at) > timedelta(seconds=90 if t.ext else 120):
                    self.broker.cancel(t.order_id)
                    with self.lock:
                        self.trades.pop(t.symbol, None)
                    db.upsert(t.row(status="cancelled", note=f"entry {st}"))
                    self.event(f"Entry not filled for {t.symbol} ({st}) — cancelled")
                continue
            if t.status == "open" and not pos:
                exit_side = "sell" if t.side == "buy" else "buy"
                px = self.broker.last_exit_price(t.symbol, t.opened_at, exit_side) or t.last_price or t.entry
                pnl = (px - t.entry) * t.dir * t.qty + t.realized
                self._note_slip(t, px)
                r0 = abs(t.entry - t.stop_init) * (t.qty0 or t.qty)
                r = pnl / r0 if r0 else t.r_now(px)
                if t.ext:
                    self.broker.cancel_symbol_orders(t.symbol)
                self.learner.record(t.strategy, t.exit_profile, t.bucket, r)
                try:
                    self.levels.record(t.session or "REGULAR", (self.s.level_active if self.s.level_auto else self.s.level), r)
                except Exception:
                    pass
                db.upsert(t.row(status="closed", exit=round(px, 4), pnl=round(pnl, 2), r=round(r, 3),
                                closed_at=now.isoformat(), note=t.note))
                with self.lock:
                    self.trades.pop(t.symbol, None)
                if pnl < 0:
                    self.reentry.pop(t.symbol, None)               # no chasing after a loss
                    self.loss_streak += 1
                    self.sym_losses[t.symbol] = self.sym_losses.get(t.symbol, 0) + 1
                    self.cooldown[t.symbol] = now + timedelta(minutes=10 if self.aggro else 30)
                    if self.loss_streak % 3 == 0 and self.s.cooloff_streak:
                        self.pause_until = now + timedelta(minutes=20)
                        self.event(f"{self.loss_streak} losses in a row — pausing new entries 20 min, half size after", "warning")
                        self.alert("streak", f"{self.loss_streak} losses in a row",
                                   "New entries paused 20 min, then half size.", level="warning")
                else:
                    self.loss_streak = 0
                    if pnl > 0:
                        self.last_win[t.symbol] = {"t": now, "exit": px, "dir": t.dir, "strategy": t.strategy, "day": self.day}
                        self._arm_reentry(t, px, now)
                    self.cooldown[t.symbol] = now + (timedelta(seconds=0) if t.note == "harvest" else
                                                     timedelta(minutes=2 if self.aggro else 10))
                self.event(f"CLOSED {t.symbol} @{px:.2f}  P&L ${pnl:,.2f} ({r:+.2f}R) [{t.strategy}/{t.exit_profile}]",
                           "info" if pnl >= 0 else "warning")
                self.alert("exit", f"{'✅' if pnl >= 0 else '🔻'} BOT CLOSED {t.symbol} {'+' if pnl >= 0 else '-'}${abs(pnl):,.2f} ({r:+.2f}R)",
                           f"Exit {px:.2f} · {t.note or 'target/stop'} · day P&L ${self.risk.day_pnl:,.2f}",
                           symbol=t.symbol, pnl=round(pnl, 2))

    def close_losers(self, reason, sess_name=None):
        """Daily limit hit: close every position that is losing money (bot and manual), keep the winners
        (they keep their stops; bot trades are still managed). Pending bot entries are cancelled."""
        closed, kept = 0, []
        try:
            pos = self.broker.positions()
            with self.lock:
                trades = dict(self.trades)
            for sym, t in trades.items():
                if t.status == "pending":
                    self.broker.cancel(t.order_id)
            ext_q = self.broker.quotes(list(pos), sess_name) if sess_name else {}
            for sym, p in pos.items():
                if p.get("upl", 0) >= 0:
                    kept.append(sym)
                    continue
                t = trades.get(sym)
                if sess_name:            # extended hours: limit orders only
                    q = ext_q.get(sym)
                    if t and t.ext:
                        if not t.exit_order_id:
                            self._ext_exit(t, reason, (q[1] if t.dir < 0 else q[0]) if q else (t.last_price or t.entry))
                    else:
                        self.broker.cancel_symbol_orders(sym)
                        px = (q[0] if p["qty"] > 0 else q[1]) if q else p["price"]
                        side = "sell" if p["qty"] > 0 else "buy"
                        lim = px * (0.995 if side == "sell" else 1.005)
                        self.broker.submit_limit_ext(sym, side, abs(p["qty"]), lim, f"abh-{uuid.uuid4().hex[:12]}")
                else:
                    if t:
                        t.note = reason
                        self._close(t)
                    else:
                        self.broker.close_position(sym)
                closed += 1
                self.event(f"Closed loser {sym} (${p.get('upl', 0):,.2f}) — daily limit")
            for sym in kept:
                self._lock_update(sym, pos[sym])
            if kept:
                self.event(f"Kept winners open with a profit lock (sells if half the gain is given back): "
                           + ", ".join(f"{k} ≥ {self.profit_locks[k]:.2f}" for k in kept if k in self.profit_locks))
        except Exception as e:
            self.event(f"Close-losers error: {e}", "error")
        try:
            self.broker.sleep(2)
            self.positions = self.broker.positions()
            self._reconcile()
        except Exception:
            pass
        return closed, kept

    def _lock_update(self, sym, p):
        """Profit lock = entry + 50% of the best open gain seen (ratchets only in the profit direction)."""
        qty, avg, px = p["qty"], p.get("avg_entry") or 0, p.get("price") or 0
        if not avg or not px:
            return
        d = 1 if qty > 0 else -1
        gain = (px - avg) * d
        if gain <= 0 and sym not in self.profit_locks:
            return
        lock = avg + d * 0.5 * max(gain, 0) + d * 0.001 * avg   # never below break-even (+fees cushion)
        old = self.profit_locks.get(sym)
        self.profit_locks[sym] = lock if old is None else (max(old, lock) if d > 0 else min(old, lock))
        t = self.trades.get(sym)
        if t and t.status == "open" and (self.profit_locks[sym] - t.stop) * t.dir > 0:
            t.stop = self.profit_locks[sym]
            if not t.ext:
                self.broker.update_stop(sym, t.stop)

    def guard_profits(self, sess_name=None):
        """While halted: ratchet each kept winner's lock and take the profit if price falls back to it."""
        if not self.profit_locks:
            return
        try:
            pos = self.broker.positions()
        except Exception:
            return
        q = self.broker.quotes(list(self.profit_locks), sess_name) if sess_name else {}
        for sym in list(self.profit_locks):
            p = pos.get(sym)
            if not p:
                self.profit_locks.pop(sym, None)
                continue
            d = 1 if p["qty"] > 0 else -1
            px = (q[sym][0] if d > 0 else q[sym][1]) if sym in q else p["price"]
            p = dict(p, price=px)
            self._lock_update(sym, p)
            lock = self.profit_locks[sym]
            if (px - lock) * d <= 0:
                gain = (px - p["avg_entry"]) * p["qty"]
                self.event(f"TAKE PROFIT {sym} @{px:.2f} (profit lock {lock:.2f}) ≈ ${gain:,.2f}")
                self.alert("exit", f"💰 Took profit on {sym} ≈ +${gain:,.2f}", f"Price fell back to the profit lock {lock:.2f}",
                           symbol=sym, pnl=round(gain, 2))
                t = self.trades.get(sym)
                if sess_name:
                    if t and t.ext:
                        self._ext_exit(t, "profit lock", px)
                    else:
                        self.broker.cancel_symbol_orders(sym)
                        side = "sell" if d > 0 else "buy"
                        self.broker.submit_limit_ext(sym, side, abs(p["qty"]), px * (0.997 if d > 0 else 1.003),
                                                     f"abp-{uuid.uuid4().hex[:12]}")
                elif t:
                    t.note = "profit lock"
                    self._close(t)
                else:
                    self.broker.close_position(sym)
                self.profit_locks.pop(sym, None)

    def flatten(self, reason, whole_account=False):
        try:
            if whole_account:
                self.broker.close_all()
            else:
                with self.lock:
                    syms = list(self.trades)
                ext_syms = [x for x in syms if self.trades.get(x) and self.trades[x].ext]
                qs = self.broker.quotes(ext_syms, self.session.name if self.session else "AFTER") if ext_syms else {}
                for s in syms:
                    t = self.trades.get(s)
                    if t and t.status == "pending":
                        self.broker.cancel(t.order_id)
                    elif t and t.ext:
                        if not t.exit_order_id:
                            q = qs.get(s)
                            self._ext_exit(t, reason, (q[1] if t.dir < 0 else q[0]) if q else (t.last_price or t.entry))
                    else:
                        if t:
                            t.note = reason
                        self.broker.close_position(s)
        except Exception as e:
            self.event(f"Flatten error: {e}", "error")
        # let the next reconcile pick up exit fills
        try:
            self.broker.sleep(2)
            self.positions = self.broker.positions()
            self._reconcile()
        except Exception:
            pass

    # ================= extended hours: pre-market / after-hours / overnight =================
    # Limit orders only, no server-side brackets -> the bot holds a resting take-profit order
    # and watches the stop itself every few seconds. Long-only, half risk, max 2 positions,
    # and every position is closed before its session ends.
    def _ext_tick(self, sess, now, eff_end=None):
        eff_end = eff_end or sess.end
        key = (sess.name, sess.start)
        if key != self.ext_key:
            self.ext_key = key
            self.qbars.reset()
            self.ext_last_scan = None
            self.event(f"{sess.label} session started (ends {sess.end.strftime('%H:%M')} ET)")

        self.acct = self.broker.account()
        self.positions = self.broker.positions()
        if self.risk.update(self.acct["equity"], self._baseline()):
            self.event(f"HALT: {self.risk.halt_reason} — closing losing positions", "warning")
            n, kept = self.close_losers(self.risk.halt_reason, sess.name)
            self.alert("halt", "🛑 Trading halted for today",
                       f"{self.risk.halt_reason}. Day P&L ${self.risk.day_pnl:,.2f}. Closed {n} losing position(s)"
                       + (f"; kept winners: {', '.join(kept)}" if kept else "") + ".", level="warning")
        self._reconcile()
        self._ext_place_targets()
        if self.acct.get("blocked"):
            self.state = "ACCOUNT BLOCKED"
            return 120
        if self.risk.halted:
            self.state = "HALTED: " + self.risk.halt_reason + " (protecting winners, no new trades)"
            self.guard_profits(sess.name)
            if any(t.ext for t in self.trades.values()):
                symbols = [t.symbol for t in self.trades.values()]
                quotes = self.broker.quotes(symbols, sess.name)
                self._ext_manage({}, quotes, now)
            return 15

        if not self.ext_last_scan or (now - self.ext_last_scan) > timedelta(minutes=max(1, int(self.s.ext_scan_minutes))):
            uni, moves = self.broker.ext_scan(self.s, sess.name, extra=list(dict.fromkeys([x['symbol'] for x in self.shortlist][:15] + list(self.reg_universe[:10]))))
            changed = set(uni) != set(self.universe) or self.ext_last_scan is None
            self.universe, self.gaps, self.ext_moves = uni, moves, moves
            self.ext_last_scan = now
            if changed:
                top = ", ".join(f"{u}({moves.get(u, 0):+.1f}%)" for u in uni[:8])
                self.event(f"{sess.label} scanner: {len(uni)} movers — {top or 'none yet'}")

        symbols = list(dict.fromkeys(self.universe + [t.symbol for t in self.trades.values()]))
        quotes = self.broker.quotes(symbols, sess.name)
        if sess.name == "OVERNIGHT" and symbols and not quotes and getattr(self, "_nq_key", None) != key:
            self._nq_key = key
            self.event("Overnight: Alpaca returned no overnight quotes. Overnight data needs the overnight feed "
                       "(free 'overnight' feed, or 'boats' with Algo Trader Plus). The bot will keep checking.", "warning")
            self.alert("system", "No overnight quotes", "Alpaca returned no overnight prices; check your data subscription.", level="warning")
        self.stale = {sym for sym, (_, _, ts) in quotes.items() if ts and (now - ts).total_seconds() > 300}
        for sym, (b, a, ts) in quotes.items():
            if sym not in self.stale:
                self.qbars.update(sym, b, a, now)
        if sess.name == "OVERNIGHT":
            raw = {sm: f for sm in symbols if (f := self.qbars.frame(sm)) is not None and len(f) >= 3}
        else:
            raw = self.broker.bars(symbols, start=sess.start - timedelta(minutes=60))
        self.raw = raw
        bars = {k: enrich(v) for k, v in raw.items() if len(v) >= 3}
        self.ribbons = {k: ribbon_state(v) for k, v in raw.items() if len(v) >= 3}
        try:
            self.setups = rank_setups(bars, self.ribbons, self.scan_info, tuple(self.s.watch_always))
        except Exception:
            pass
        self._update_movers(bars, self.ext_moves, sess.name, now)

        self._ext_manage(bars, quotes, now)

        mins_left = (eff_end - now).total_seconds() / 60
        # pre-market: the 9:00-9:30 move is the prize, so keep hunting until 9:20 and only get out in the last 4 minutes
        stop_new, flat_at = (10, 4) if sess.name == "PRE" else (25, 10)
        if mins_left <= flat_at:
            if any(t.ext and not t.exit_order_id for t in self.trades.values()):
                self.event(f"{sess.label} trading window ends at {eff_end.strftime('%H:%M')} — closing positions")
                self.flatten(f"{sess.name} session end")
            self.state = f"{sess.label.upper()}: closing out"
        elif mins_left > stop_new:
            self.state = f"{sess.label.upper()} TRADING"
            self._ext_entries(bars, quotes, now, sess)
        else:
            self.state = f"{sess.label.upper()}: managing (no new entries)"
        return 5 if self.aggro else self.s.ext_tick_seconds

    def _ext_entries(self, bars, quotes, now, sess):
        ext_open = sum(1 for t in self.trades.values() if t.ext)
        slots = (self.s.ext_max_positions + (1 if self.aggro else 0)) - ext_open
        if slots <= 0 or self.entries_blocked_reason or self._margin_block():
            if slots > 0:
                self._skip("(all)", "-", "", "entries blocked: " + str(self.entries_blocked_reason or "margin / buying-power check"), now)
            return
        if self.pause_until and now < self.pause_until and self.s.cooloff_streak:
            self._skip("(all)", "-", "", f"cooling off until {self.pause_until.strftime('%H:%M')} after a loss streak", now)
            return
        # shorts outside regular hours: Alpaca treats short sales the same in every session; overnight only when the
        # 24/5 shorts switch is on (default), and every short still needs a fresh easy_to_borrow check at entry
        can_short = bool(self.shorts_allowed(now) and self.acct.get("shorting_enabled", True)
                         and (sess.name != "OVERNIGHT" or getattr(self.s, "shorts_24_5", True)))
        ctx = {"aggressive": self.aggro, "move": self.ext_moves, "ribbon": self.ribbons, "quote_bars": sess.name == "OVERNIGHT",
               "shorts": can_short, "all_flips": self.s.trade_all_flips, "pm_cont": getattr(self.s, "pm_trend", True), "reentry": self._reentry_ctx(now)}
        ranked = []
        fired = set()
        sigs = find_ext_signals(bars, ctx, sess.start)
        fired = {(sg.symbol, sg.strategy) for sg in sigs}
        for sym, df in bars.items():
            if sym in self.s.watch_always or (sym, "RIBBON_FLIP") in fired:
                continue
            try:
                w = ribbon_why(sym, df[df.index >= sess.start] if len(df[df.index >= sess.start]) >= 6 else df, ctx)
            except Exception:
                w = None
            if w:
                if "SELL flip" in w and sess.name == "OVERNIGHT" and not getattr(self.s, "shorts_24_5", True):
                    w = "SELL flip — overnight shorting is switched off (Controls: Shorts 24/5)"
                self._skip(sym, "RIBBON_FLIP", "", f"{sess.label}: {w}", now)
        for sg in sigs:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, f"{sess.label}: {why}", now)
            if sg.symbol in self.trades or sg.symbol in self.positions:
                continue
            if self.manual_syms.get(sg.symbol) == self.day:
                no("you traded this symbol manually today — bot leaves it alone")
                continue
            why_c = self._churn_block(sg, now)
            if why_c:
                no(why_c)
                continue
            why_v = self._pick_veto(sg) or self._pair_block(sg.symbol) or self._spread_block(sg, sess.name)
            if why_v:
                no(why_v)
                continue
            if not self._short_gate(sg, bars, now, no):
                continue
            if self.s.cooloff_symbol and self.sym_losses.get(sg.symbol, 0) >= 2:
                no("dropped for today after 2 losses on this symbol")
                continue
            cd = self.cooldown.get(sg.symbol)
            if cd and now < cd and self.s.cooloff_symbol and sg.strategy != "REENTRY":
                no(f"symbol cooling off until {cd.strftime('%H:%M')}")
                continue
            if sg.side == "sell":
                ok, why = self._can_short(sg.symbol)
                if not ok:
                    no("short signal skipped — " + why)
                    continue
            name = f"{sg.strategy}@{sess.name}"
            ch = self.learner.choose(name, sess.name, sg.quality)
            force = (self.s.trade_all_flips and sg.strategy == "RIBBON_FLIP") or (sg.strategy == "EXT_CONT" and getattr(self.s, "pm_trend", True))
            if force and not ch:
                ch = ("RIBBON", 0.5, 1.0)
            if not ch or ch[1] < (0.0 if (self.aggro or force) else MIN_SCORE):
                no("learner score too low for this strategy in this session")
                continue
            if not force and self._tod_blocked(now, name):
                no("time-of-day filter: your own history loses money in this slot")
                continue
            if self.s.auto_tune:
                okt, m, rk, why = self.tuner.gate(name, self.day, getattr(self.s, 'proven_only', True))
                if not okt:
                    no(why)
                    continue
                if why and why.startswith("probe"):
                    self.event(f"Self-fix: {name} {why}", "info")
                ch = (ch[0], ch[1], ch[2] * m)
                ranked.append((ch[1] * rk, name, sg, ch))
                continue
            ranked.append((ch[1], name, sg, ch))
        ranked.sort(key=lambda x: x[0], reverse=True)
        taken = set()
        for score, name, sg, (ep, _, weight) in ranked:
            def no(why, sg=sg):
                self._skip(sg.symbol, sg.strategy, sg.side, f"{sess.label}: {why}", now)
            if sg.symbol in taken:
                continue                    # one order per symbol even if two strategies fire together
            why_p = self._pair_block(sg.symbol, taken)
            if why_p:
                no(why_p)
                continue
            if slots <= 0:
                no("all extended-hours position slots are full")
                continue
            q = quotes.get(sg.symbol)
            if not q:
                no("no live quote")
                continue
            if self._event_block(sg.symbol, now, sess.name):
                no("earnings / risky-news filter")
                continue
            bid, ask, _ = q
            short = sg.side == "sell"
            if sg.symbol in self.stale:
                no("quotes are stale")
                continue
            if (ask - bid) / ask > 0.006:
                no(f"spread too wide ({(ask - bid) / ask * 100:.2f}%)")
                continue
            if (not short and ask > sg.entry * 1.004) or (short and bid < sg.entry * 0.996):
                no("price already ran away from the entry — not chasing")
                continue
            limit = bid * 0.999 if short else ask * 1.001
            min_d = max(1.2 * float(sg.atr or 0), self.EXT_MIN_STOP_PCT * limit)     # thin pre/after-market prices wobble: never a hair-thin stop
            if abs(limit - sg.stop) < min_d:
                sg.stop = round(limit + min_d if short else limit - min_d, 2)
            spr_pct = (ask - bid) / ask * 100 if ask else 0.0
            hv = max(float(getattr(self.s, "pct_harvest_pct", 0.10)), 2 * spr_pct)          # never bank less than the spread costs twice
            if sg.strategy == "EXT_CONT":
                hv = max(hv, float(getattr(self.s, "trend_harvest_pct", 0.5)))
            new_stop = self._harvest_stop(limit, sg.stop, sg.side, True, sg.strategy, hv)
            if new_stop != sg.stop:
                sg.stop = new_stop
            self._fresh_account()
            weight *= self.s.ext_risk_mult * (0.5 if self.loss_streak >= 3 and self.s.cooloff_streak else 1)
            dec = self.risk.size(limit, sg.stop, weight, self._open_risk(), self.acct.get("buying_power", 0))
            if dec.qty < 1:
                no(f"risk sizing gave 0 shares ({dec.reason})")
                continue
            d = -1 if short else 1
            r0 = abs(limit - sg.stop)
            ep = self._harvest_profile(ep)
            target = limit + d * EXIT_PROFILES[ep]["target_r"] * r0
            cid = f"abx-{uuid.uuid4().hex[:12]}"
            bp_now = float(self.acct.get("buying_power", 0) or 0)
            qty = dec.qty
            if bp_now > 0 and qty * limit > 0.95 * bp_now:            # never ask for more than the account can afford
                qty = max(int(0.95 * bp_now / limit), 0)
                if qty < 1:
                    no(f"not enough buying power (${bp_now:,.0f}) for even one share")
                    continue
                dec = type(dec)(qty, round(qty * r0, 2), dec.reason)
            try:
                try:
                    oid = self.broker.submit_limit_ext(sg.symbol, sg.side, dec.qty, limit, cid)
                except Exception as e1:
                    q2 = self._fit_qty(e1, dec.qty, limit)          # adjust the quantity to what Alpaca says fits
                    if not q2:
                        raise
                    self.event(f"{sess.label} {sg.symbol}: buying power short for {dec.qty} sh, retrying with {q2}", "warning")
                    dec = type(dec)(q2, round(q2 * r0, 2), dec.reason)
                    cid = f"abx-{uuid.uuid4().hex[:12]}"
                    oid = self.broker.submit_limit_ext(sg.symbol, sg.side, dec.qty, limit, cid)
            except Exception as e:
                self.event(f"{sess.label} order rejected {sg.symbol}: {str(e)[:160]}", "warning")
                self.alert("reject", f"Order rejected: {sg.symbol}", str(e)[:160], symbol=sg.symbol)
                no("Alpaca rejected the order: " + str(e)[:90])
                continue
            t = Trade(cid, sg.symbol, sg.side, name, ep, sess.name, dec.qty, limit, sg.stop, sg.stop, target,
                      sg.atr, dec.risk_dollars, now, oid, day=self.day, mode=self.mode, ext=True, session=sess.name)
            t.hv_pct = round(hv, 3)
            with self.lock:
                self.trades[sg.symbol] = t
            self.tuner.used(name, self.day)
            db.upsert(t.row(status="pending"))
            slots -= 1
            taken.add(sg.symbol)
            self.event(f"{sess.label.upper()} ENTRY {sg.side.upper()} {dec.qty} {sg.symbol} limit {limit:.2f} [{name}/{ep}] "
                       f"stop {sg.stop:.2f} target {target:.2f} risk ${dec.risk_dollars:.0f}")
            self.alert("entry", f"🟢 BOT {'SHORT' if short else 'BUY'} {dec.qty} {sg.symbol} @ {limit:.2f} ({sess.label})",
                       f"{name} · stop {sg.stop:.2f} (watched by the app) · target {target:.2f}",
                       symbol=sg.symbol, close_btn=True)

    def _ext_place_targets(self):
        for t in list(self.trades.values()):
            if t.ext and t.status == "open" and not t.tp_order_id and not t.exit_order_id:
                if EXIT_PROFILES[t.exit_profile].get("scale"):
                    t.tp_order_id = "none"        # harvested in steps by the app (see _ext_manage)
                    t.qty0 = t.qty0 or t.qty
                    continue
                try:
                    t.tp_order_id = self.broker.submit_limit_ext(t.symbol, "buy" if t.dir < 0 else "sell", t.qty, t.target,
                                                                 f"abt-{uuid.uuid4().hex[:12]}")
                except Exception as e:
                    t.tp_order_id = "none"
                    self.event(f"Take-profit order failed for {t.symbol} (bot will watch the target): {str(e)[:100]}",
                               "warning")

    EXT_MIN_STOP_PCT = 0.0045     # extended-hours stop is at least 0.45% away from entry
    EXT_STOP_CONFIRM = 25         # seconds price must stay beyond the stop (mid price) before we exit
    EXT_HARD_R = 1.4              # ...unless the loss reaches this many R: then exit at once

    def _ext_stop_hit(self, t, mid, now):
        """Extended-hours stops are held by the app. One thin-book tick must not stop us out: the MID price has to stay
        beyond the stop for EXT_STOP_CONFIRM seconds; a real breakdown (loss >= EXT_HARD_R) exits immediately."""
        beyond = mid >= t.stop if t.dir < 0 else mid <= t.stop
        if not beyond:
            t.beyond_since = None
            return False
        if t.r_now(mid) <= -self.EXT_HARD_R:
            return True
        if t.beyond_since is None:
            t.beyond_since = now
            return False
        return (now - t.beyond_since).total_seconds() >= self.EXT_STOP_CONFIRM

    def _ext_manage(self, bars, quotes, now):
        for t in list(self.trades.values()):
            if not t.ext or t.status != "open":
                continue
            q = quotes.get(t.symbol)
            df = bars.get(t.symbol)
            short = t.dir < 0
            # the price we would exit at: bid for longs (we sell), ask for shorts (we buy to cover)
            bid = (q[1] if short else q[0]) if q else (float(df["close"].iloc[-1]) if df is not None else t.last_price or t.entry)
            t.last_price = ((q[0] + q[1]) / 2) if q else bid
            if t.exit_order_id:
                # exit working: re-price more aggressively every 20s until filled
                if self.broker.order_open(t.exit_order_id) and t.exit_sent_at and \
                        (now - t.exit_sent_at).total_seconds() > 20:
                    self.broker.cancel(t.exit_order_id)
                    self._ext_exit(t, t.note or "exit", bid, retry=True)
                continue
            prof = EXIT_PROFILES[t.exit_profile]
            r = t.r_now(bid)
            pos = self.positions.get(t.symbol)
            if pos and 0 < abs(pos["qty"]) < t.qty - 1e-9:          # a partial sell filled
                drop = t.qty - abs(pos["qty"])
                t.realized += ((t.partial_px or bid) - t.entry) * t.dir * drop
                t.qty = abs(pos["qty"])
                self.alert("profit", f"💰 Took profit {t.symbol} +${((t.partial_px or bid) - t.entry) * drop:,.2f}",
                           f"Sold {drop:g} ({t.session.lower()}) · {t.qty:g} left · stop {t.stop:.2f}",
                           symbol=t.symbol, close_btn=True)
            if t.partial_oid and not self.broker.order_open(t.partial_oid):
                t.partial_oid = ""
            if not t.partial_oid and (self._pct_take(t, bid) or self._quick_harvest(t, r)):
                self._ext_exit(t, "harvest", bid)
                continue
            lvl, giveback = self._gain_lock(t, r)
            if giveback:
                self._ext_exit(t, "profit lock", bid)
                continue
            if self._turn_warn(t, r, bars):
                self._warned[t.id] = self._warned.get(t.id, 0) + 1
                if self._warned[t.id] >= 2 and r >= 0.3:
                    self._ext_exit(t, "reversal exit", bid)
                    continue
            else:
                self._warned[t.id] = 0
            if lvl is not None:
                t.stop = min(t.stop, lvl) if short else max(t.stop, lvl)
            steps = prof.get("scale") or []
            if not t.partial_oid and t.scaled < len(steps) and r >= steps[t.scaled][0]:
                q = int(t.qty * steps[t.scaled][1])
                t.qty0 = t.qty0 or t.qty
                t.scaled += 1
                lock = -0.5 if (t.scaled == 1 and getattr(self.s, "let_run", True)) else 0.02
                be = t.entry + lock * (t.entry - t.stop_init)
                t.stop = min(t.stop, be) if short else max(t.stop, be)               # rest rides with room (-0.5R after the first take, break-even after the second)
                if 1 <= q < t.qty:
                    px = bid * (1.001 if short else 0.999)                          # marketable limit
                    try:
                        t.partial_oid = self.broker.submit_limit_ext(t.symbol, "buy" if short else "sell", q, px, f"abp-{uuid.uuid4().hex[:12]}")
                        t.partial_px = px
                        self.event(f"💰 {t.session} take-profit {t.symbol}: selling {q} @~{px:.2f} ({r:+.1f}R), stop → {t.stop:.2f}")
                    except Exception as e:
                        self.event(f"Partial take-profit on {t.symbol} failed: {str(e)[:120]}", "warning")
            be = t.entry + 0.02 * (t.entry - t.stop_init)
            if prof["be_at_r"] is not None and r >= prof["be_at_r"]:
                t.stop = min(t.stop, be) if short else max(t.stop, be)
            if prof["trail_after_r"] is not None and r >= prof["trail_after_r"] and df is not None:
                tr = prof["trail_atr"] * float(df["atr"].iloc[-1])
                t.stop = min(t.stop, bid + tr) if short else max(t.stop, bid - tr)
            rb = self.ribbons.get(t.symbol)
            age = (now - t.opened_at).total_seconds() / 60
            reason = None
            mid = t.last_price or bid
            hit_stop = self._ext_stop_hit(t, mid, now)
            hit_tgt = bid <= t.target if short else bid >= t.target
            if t.symbol in self.stale and age > 5:
                reason = "stale data"
            elif hit_stop:
                reason = "stop" if t.stop == t.stop_init else "trail stop"
            elif hit_tgt and t.tp_order_id in ("", "none"):
                reason = "target"
            elif prof.get("exit_on_flip") and rb and rb.get("ready") and (rb["state"] > 0 if short else rb["state"] < 0) and age >= 6 and r < 0.9:
                reason = "ribbon flip"
            elif age >= prof.get("time_stop", self.s.time_stop_minutes) and r < 0.3 and not (rb and rb.get("state") == 1):
                reason = "time stop"
            if reason:
                self._ext_exit(t, reason, bid)

    def _ext_exit(self, t, reason, bid, retry=False):
        with self.exit_lock:
            if not retry and t.exit_order_id:
                return                    # another thread already started this exit
            return self._ext_exit_locked(t, reason, bid, retry)

    def fast_guard(self, feed):
        """Called every second with streamed prices: extended-hours stops (held by the app, not Alpaca)
        react within ~1 s instead of waiting for the next 15-s loop."""
        if not self.running:
            return
        for t in list(self.trades.values()):
            if not t.ext or t.status != "open" or t.exit_order_id:
                continue
            lv = feed.get(t.symbol, max_age=5)
            if not lv or not lv.get("bid"):
                continue
            short = t.dir < 0
            bid = lv["ask"] if short else lv["bid"]
            t.last_price = (lv["bid"] + lv["ask"]) / 2
            if self._ext_stop_hit(t, t.last_price, self.broker.now()):
                self.event(f"Fast stop: {t.symbol} mid {t.last_price:.2f} held beyond stop {t.stop:.2f} (streamed)", "warning")
                self._ext_exit(t, "stop" if t.stop == t.stop_init else "trail stop", bid)

    def _ext_exit_locked(self, t, reason, bid, retry=False):
        if not retry:
            self.broker.cancel_symbol_orders(t.symbol)
            self.broker.sleep(0.5)
            t.note = reason
            t.exit_tries = 0
        t.exit_tries += 1
        pos = self.broker.positions().get(t.symbol)
        qty = abs(pos["qty"]) if pos else t.qty
        if not pos:
            return
        short = t.dir < 0
        limit = bid * (1 + 0.002 * t.exit_tries) if short else bid * (1 - 0.002 * t.exit_tries)   # marketable, a bit worse each retry
        if t.exit_tries == 1 and t.note in ("manual close", "harvest", "profit lock", "reversal exit") and bid:
            # A win being banked (or a calm manual close): first try the favourable half of the spread, not the far side.
            # The 20-second retry then drops to the marketable price, so a wide spread can't turn the win into a loss.
            try:
                q = (self.broker.quotes([t.symbol], t.session if t.session in ("PRE", "AFTER", "OVERNIGHT") else "AFTER") or {}).get(t.symbol)
                if q and q[1] > q[0] and (q[1] - q[0]) / ((q[0] + q[1]) / 2) * 100 >= 0.04:
                    limit = round(q[0] + 0.5 * (q[1] - q[0]), 2) if not short else round(q[1] - 0.5 * (q[1] - q[0]), 2)
            except Exception:
                pass
        try:
            t.exit_order_id = self.broker.submit_limit_ext(t.symbol, "buy" if short else "sell", qty, limit,
                                                           f"abe-{uuid.uuid4().hex[:12]}")
            t.exit_sent_at = self.broker.now()
            if not retry:
                self.event(f"EXIT {t.symbol} ({reason}) limit {limit:.2f} ({t.r_now(bid):+.2f}R)")
                if reason == "stale data":
                    self.alert("stale", f"Exiting {t.symbol}: quotes went stale",
                               "No fresh overnight quotes for 5 minutes.", symbol=t.symbol)
        except Exception as e:
            t.exit_order_id = ""
            self.event(f"Exit order failed for {t.symbol}: {str(e)[:120]}", "error")

    def _ext_orphans(self, now):
        """Extended-hours trades still open outside an enabled session (e.g. bot was paused)."""
        clk = self.broker.clock()
        for t in list(self.trades.values()):
            if not t.ext:
                continue
            if t.status == "pending":
                self.broker.cancel(t.order_id)
                continue
            if clk["is_open"]:
                self.broker.cancel_symbol_orders(t.symbol)
                t.note = t.note or "session ended"
                self._close(t)
                t.ext = False     # now a normal position; reconcile will record the exit
                self.event(f"Closing leftover {t.session} position {t.symbol} at the regular open", "warning")
        self.positions = self.broker.positions()
        self._reconcile()

    def refresh_account(self, max_age=20):
        """Keep balance / buying power / today's P&L current even while the market is closed
        (the trading loop only refreshes them during a session). Display only: never halts."""
        import time as _t
        if _t.time() - getattr(self, "_acct_t", 0) < max_age and self.acct:
            return
        try:
            self.acct = self.broker.account()
            self._acct_t = _t.time()
            if self.running:
                return            # the trading loop owns day P&L while it runs
            bd = bot_day(self.broker.now())
            base = None
            try:
                st = json.loads(DAY_STATE.read_text())
                if st.get("day") == bd and st.get("mode", self.mode) == self.mode and self._sane_base(float(st["baseline"])):
                    base = float(st["baseline"])
            except Exception:
                pass
            base = base or self.acct.get("last_equity")
            if base and not self.risk.halted:
                self.risk.day_pnl = self.acct["equity"] - base
        except Exception:
            pass

    # ---------------- status for the dashboard ----------------
    def _mover_bot(self, m, now):
        """One plain-English line per mover: what the bot will do or why it has not."""
        sym = m["symbol"]
        if sym in self.trades:
            return "IN TRADE"
        if sym in self.positions:
            return "position open (not a bot trade)"
        if self.manual_syms.get(sym) == self.day:
            return "yours today, bot leaves it alone"
        if m.get("side") == "short":
            if not self.shorts_allowed(now):
                return "short starts at 7:00 AM ET" if getattr(self.s, "short_from_7am", True) else "shorts are off in Controls"
            if not self.acct.get("shorting_enabled", True):
                return "your account can't short"
        for r in list(self.skips):
            if r["symbol"] == sym:
                return f"skipped {r['t']}: {r['why'][:110]}"
        return "watching for its trigger"

    def _movers_view(self):
        try:
            now = self.broker.now()
            return [dict(m, bot=self._mover_bot(m, now)) for m in getattr(self, "movers", [])[:25]]
        except Exception:
            return getattr(self, "movers", [])[:25]

    def status(self):
        with self.lock:
            trades = [{
                "symbol": t.symbol, "side": t.side, "qty": t.qty, "entry": round(t.entry, 2),
                "stop": round(t.stop, 2), "target": round(t.target, 2), "strategy": t.strategy,
                "exit": t.exit_profile, "status": t.status, "price": round(t.last_price, 2),
                "r": round(t.r_now(t.last_price), 2) if t.last_price else 0,
                "risk": t.risk, "opened": t.opened_at.strftime("%H:%M"),
                "session": t.session} for t in self.trades.values()]
        return {
            "running": self.running, "state": self.state, "mode": self.mode,
            "daily_max_loss": self.s.daily_max_loss, "day_pnl": round(self.risk.day_pnl, 2),
            "day_base": round(float(self._base[1]), 2) if self._base[0] == self.day else None,
            "day_equity": round(float((self.acct or {}).get("equity") or 0), 2),
            "remaining": round(self.risk.remaining, 2), "halted": self.risk.halted,
            "halt_reason": self.risk.halt_reason, "bias": self.bias, "account": self.acct,
            "universe": [{"symbol": u, "gap": self.gaps.get(u, 0),
                          "ribbon": (self.ribbons.get(u) or {}).get("state", 0)} for u in self.universe],
            "open_trades": trades, "events": list(self.events)[:80],
            "scan_info": self.scan_info[:30],
            "setups": getattr(self, "setups", [])[:15],
            "movers": self._movers_view(), "movers_at": getattr(self, "movers_at", ""),
            "session": ({"name": self.session.name, "label": self.session.label,
                         "ends": self.session.end.strftime("%a %H:%M"),
                         "enabled": self.session.name == "REGULAR" or self._ext_enabled(self.session.name)}
                        if self.session else {"name": "CLOSED", "label": "Market closed", "ends": "", "enabled": False}),
        }
