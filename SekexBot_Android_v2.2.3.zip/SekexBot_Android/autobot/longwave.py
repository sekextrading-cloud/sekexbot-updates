"""Long-wave planner: finds the slow up/down swings a stock makes over hours (like SPCX overnight, 167.6 <-> 168.6),
measures their typical size and timing, and projects the next few legs: where to BUY before the turn up, when to
SELL, and where to buy again. Everything is computed from 5-minute bars (extended hours included).

This is a plan from past rhythm, not a promise: waves stop repeating. Each plan carries a confidence and the walk-forward
hit-rate on the same stock, and `backtest()` lets you check it before trusting it."""
from __future__ import annotations

import numpy as np
import pandas as pd

MAX_LEGS = 5
MIN_PIVOTS = 5
MIN_REG = 0.6


def pivots(df: pd.DataFrame, thr: float):
    """Zig-zag turning points. A turn counts once price has moved `thr` (fraction) back from the extreme.
    Returns [(index, price, 'H'|'L')], the last one being the still-open extreme."""
    h, l = df["high"].values, df["low"].values
    n = len(df)
    if n < 10:
        return []
    out = []
    d = 0                                   # 1 = rising leg, -1 = falling leg
    hi_i, hi = 0, h[0]
    lo_i, lo = 0, l[0]
    for i in range(1, n):
        if h[i] > hi:
            hi_i, hi = i, h[i]
        if l[i] < lo:
            lo_i, lo = i, l[i]
        if d >= 0 and hi > 0 and (hi - l[i]) / hi >= thr and hi_i >= (out[-1][0] if out else 0):
            if d == 0 and lo_i < hi_i:
                out.append((lo_i, float(lo), "L"))
            out.append((hi_i, float(hi), "H"))
            d, lo_i, lo = -1, i, l[i]
        elif d <= 0 and lo > 0 and (h[i] - lo) / lo >= thr and lo_i >= (out[-1][0] if out else 0):
            if d == 0 and hi_i < lo_i:
                out.append((hi_i, float(hi), "H"))
            out.append((lo_i, float(lo), "L"))
            d, hi_i, hi = 1, i, h[i]
    if d == 1:
        out.append((hi_i, float(hi), "H"))      # open extreme of the current rise
    elif d == -1:
        out.append((lo_i, float(lo), "L"))
    return out


def _thr(df, spread_pct=0.0):
    rng = ((df["high"] - df["low"]) / df["close"]).replace([np.inf, -np.inf], np.nan).dropna()
    med = float(rng.median()) if len(rng) else 0.001
    return max(0.0025, 3.0 * med, 3.0 * spread_pct)


def _legs(df, piv):
    legs = []
    idx = df.index
    for a, b in zip(piv[:-1], piv[1:]):
        mins = max(5.0, (idx[b[0]] - idx[a[0]]).total_seconds() / 60.0)
        amp = abs(b[1] - a[1]) / a[1]
        legs.append({"dir": 1 if b[2] == "H" else -1, "amp": amp, "mins": mins, "from": a, "to": b})
    return legs


def analyse(df: pd.DataFrame, spread_pct: float = 0.0):
    """Wave rhythm of this stock from the bars given: typical up/down size and duration, and how regular it is."""
    if df is None or len(df) < 40:
        return None
    thr = _thr(df, spread_pct)
    piv = pivots(df, thr)
    if len(piv) < MIN_PIVOTS:
        return {"ok": False, "reason": "No clear repeating waves in this window (too few turns).", "thr": thr, "pivots": piv}
    legs = _legs(df, piv)
    done = legs[:-1] if len(legs) > 1 else legs        # the last leg is still open
    ups = [x for x in done if x["dir"] == 1]
    dns = [x for x in done if x["dir"] == -1]
    if len(ups) < 2 or len(dns) < 2:
        return {"ok": False, "reason": "Waves aren't regular enough yet.", "thr": thr, "pivots": piv}
    up_amp, dn_amp = float(np.median([x["amp"] for x in ups])), float(np.median([x["amp"] for x in dns]))
    up_m, dn_m = float(np.median([x["mins"] for x in ups])), float(np.median([x["mins"] for x in dns]))
    cv = lambda v: float(np.std(v) / np.mean(v)) if np.mean(v) else 9.0
    reg = 1.0 - min(1.0, 0.5 * (cv([x["amp"] for x in done]) + cv([x["mins"] for x in done])))   # 1 = very regular
    if reg < MIN_REG:
        return {"ok": False, "reason": f"The swings aren't regular enough to plan (regularity {max(0.0, reg):.2f}, needs {MIN_REG}).", "thr": thr, "pivots": piv}
    return {"ok": True, "thr": thr, "pivots": piv, "legs": legs, "up_amp": up_amp, "dn_amp": dn_amp, "up_mins": up_m, "dn_mins": dn_m,
            "regularity": round(max(0.0, reg), 2), "n_legs": len(done)}


def plan(df: pd.DataFrame, symbol: str = "", spread_pct: float = 0.0005, allow_short: bool = False, max_legs: int = MAX_LEGS):
    """Project the next legs from the last turn. Returns stats plus up to `max_legs` planned trades:
    entry (before the turn), exit (before the old extreme, not at it), stop, re-entry, with time windows."""
    a = analyse(df, spread_pct)
    if a is None:
        return {"symbol": symbol, "ok": False, "reason": "Not enough 5-minute bars yet.", "legs": []}
    if not a["ok"]:
        return {"symbol": symbol, "ok": False, "reason": a["reason"], "legs": []}
    piv, idx = a["pivots"], df.index
    px = float(df["close"].iloc[-1])
    last = piv[-1]                                    # open extreme: the leg in progress runs from piv[-2] to here
    in_up = last[2] == "H"
    now_t = idx[-1]
    steps = []
    # leg in progress: where is it expected to end?
    cur_price, cur_t = last[1], idx[last[0]]
    side_dir = 1 if in_up else -1
    start_pivot = piv[-2]
    prog_amp = abs(px - start_pivot[1]) / start_pivot[1]
    exp_amp = a["up_amp"] if in_up else a["dn_amp"]
    exp_m = a["up_mins"] if in_up else a["dn_mins"]
    # price level of next turns, built outward from the current open extreme
    turn_px = start_pivot[1] * (1 + exp_amp) if in_up else start_pivot[1] * (1 - exp_amp)
    turn_t = idx[start_pivot[0]] + pd.Timedelta(minutes=exp_m)
    if (in_up and px >= turn_px) or ((not in_up) and px <= turn_px) or turn_t < now_t:
        # this leg already ran its usual course: the turn is due now, anchor on the real extreme
        turn_px, turn_t = cur_price, max(now_t, cur_t + pd.Timedelta(minutes=5))
    # future turns, alternating H/L, each built from the previous one with the stock's typical size and timing
    turns = []
    t_px, t_t, t_k = turn_px, turn_t, ("H" if in_up else "L")
    for _ in range(2 * max_legs + 2):
        turns.append((t_px, t_t, t_k))
        if t_k == "H":
            t_px, t_t, t_k = t_px * (1 - a["dn_amp"]), t_t + pd.Timedelta(minutes=a["dn_mins"]), "L"
        else:
            t_px, t_t, t_k = t_px * (1 + a["up_amp"]), t_t + pd.Timedelta(minutes=a["up_mins"]), "H"
    legs = []
    for (p0, t0, k0), (p1, t1, k1) in zip(turns[:-1], turns[1:]):
        if k0 == "L":
            legs.append({"kind": "LONG", "entry": p0, "entry_t": t0, "exit": p1, "exit_t": t1, "amp": a["up_amp"]})
        elif allow_short:
            legs.append({"kind": "SHORT", "entry": p0, "entry_t": t0, "exit": p1, "exit_t": t1, "amp": a["dn_amp"]})
    # keep only legs that start in the future, ordered, trim to max
    out = []
    seen = set()
    for g in sorted(legs, key=lambda x: x["entry_t"]):
        if g["entry_t"] < now_t - pd.Timedelta(minutes=10):
            continue
        key = (g["kind"], g["entry_t"])
        if key in seen:
            continue
        seen.add(key)
        move = abs(g["exit"] - g["entry"])
        take = g["entry"] + 0.85 * (g["exit"] - g["entry"])           # bank before the old extreme, not at it
        stop = g["entry"] - 0.5 * move if g["kind"] == "LONG" else g["entry"] + 0.5 * move
        cost = g["entry"] * spread_pct * 2
        net = abs(take - g["entry"]) - cost
        rr = net / max(abs(g["entry"] - stop), 1e-9)
        if net <= 0 or abs(take - g["entry"]) / g["entry"] < 3 * spread_pct:
            continue
        g.update({"n": len(out) + 1, "take": take, "stop": stop, "rr": round(rr, 2), "net_pct": round(net / g["entry"] * 100, 2),
                  "window": (g["entry_t"] - pd.Timedelta(minutes=10), g["entry_t"] + pd.Timedelta(minutes=10))})
        out.append(g)
        if len(out) >= max_legs:
            break
    conf = int(round(100 * min(1.0, 0.25 + 0.6 * a["regularity"] + 0.03 * min(a["n_legs"], 5))))
    fmt = lambda t: t.strftime("%a %-I:%M %p")
    legs_out = [{"n": g["n"], "kind": g["kind"], "entry": round(g["entry"], 2), "entry_at": fmt(g["entry_t"]),
                 "window": f'{g["window"][0].strftime("%-I:%M")}–{g["window"][1].strftime("%-I:%M %p")}',
                 "take": round(g["take"], 2), "exit_at": fmt(g["exit_t"]), "stop": round(g["stop"], 2),
                 "rr": g["rr"], "net_pct": g["net_pct"],
                 "reentry": (f'Buy again near {round(g["exit"] * (1 - a["dn_amp"]), 2)} around {fmt(g["exit_t"] + pd.Timedelta(minutes=a["dn_mins"]))}'
                             if g["kind"] == "LONG" else "")} for g in out]
    return {"symbol": symbol, "ok": True, "price": round(px, 2), "state": "rising" if last[2] == "H" else "falling",
            "up_pct": round(a["up_amp"] * 100, 2), "down_pct": round(a["dn_amp"] * 100, 2),
            "up_mins": round(a["up_mins"]), "down_mins": round(a["dn_mins"]), "cycle_mins": round(a["up_mins"] + a["dn_mins"]),
            "regularity": a["regularity"], "confidence": conf, "turns": [(idx[i].strftime("%m-%d %H:%M"), round(p, 2), k) for i, p, k in piv[-8:]],
            "legs": legs_out, "harvest_pct": round(0.85 * min(a["up_amp"], a["dn_amp"]) * 100, 2),
            "note": "A plan from the stock's recent rhythm, not a prediction. Waves stop repeating: use the stops."}


def backtest(df: pd.DataFrame, spread_pct: float = 0.0005, warm: int = 150):
    """Walk-forward check: at each confirmed turn, predict the next leg from only the bars before it, then see whether
    price reached 85% of the predicted move before falling through the stop. Returns hit-rate and average net %."""
    res = []
    if df is None or len(df) < warm + 60:
        return {"n": 0, "hit": 0.0, "avg_net_pct": 0.0}
    thr = _thr(df.iloc[:warm], spread_pct)
    piv_all = pivots(df, thr)
    for j in range(3, len(piv_all) - 1):
        p0 = piv_all[j]
        if p0[2] != "L" or p0[0] < warm:
            continue
        # we only know the turn once price has moved thr off it
        known = p0[0] + 6
        hist = df.iloc[:known]
        a = analyse(hist, spread_pct)
        if not a or not a["ok"]:
            continue
        entry = float(hist["close"].iloc[-1])
        take = entry + 0.85 * (a["up_amp"] * p0[1] - (entry - p0[1]))
        stop = p0[1] - 0.5 * a["up_amp"] * p0[1]
        fut = df.iloc[known:known + int(max(24, 2.5 * a["up_mins"] / 5))]
        outcome = None
        for h, l in zip(fut["high"].values, fut["low"].values):
            if l <= stop:
                outcome = (stop - entry) / entry; break
            if h >= take:
                outcome = (take - entry) / entry; break
        if outcome is None:
            outcome = (float(fut["close"].iloc[-1]) - entry) / entry if len(fut) else 0.0
        res.append(outcome - 2 * spread_pct)
    n = len(res)
    return {"n": n, "hit": round(sum(1 for r in res if r > 0) / n, 2) if n else 0.0, "avg_net_pct": round(100 * float(np.mean(res)), 3) if n else 0.0}
