"""Self check-up (v1.98): the bot looks over its own day and tells you in plain words.

After each regular session (and any time you tap Run check-up) it reads the recent event log, today's closed trades,
the options fill record and the settings, and writes a short report: what ran fine, what repeats, what to watch.
  * It only ever READS. Auto-tune of option fills happens in options.py (logged); loss limits are never touched.
  * If the same code-level error repeats, it can ask Claude (Find & fix) to DRAFT a fix. A draft changes nothing:
    you read it and approve it with your Live PIN, exactly like a fix you asked for yourself."""
import json
import re
import threading
import time
from collections import Counter

from . import db
from .config import DATA_DIR

FILE = DATA_DIR / "checkups.json"
CODE_ERR = re.compile(r"(Loop error|Wave trader error|tick failed|Traceback|TypeError|KeyError|AttributeError|ValueError|NameError|IndexError|"
                      r"unpack|not subscriptable|has no attribute|can't be used|object is not)", re.I)


def _norm(msg: str) -> str:
    m = re.sub(r"\$?\d[\d,.:%]*", "#", str(msg))
    m = re.sub(r"\b[A-Z]{1,5}\b(?=[ :])", "SYM", m)
    return re.sub(r"\s+", " ", m).strip()[:140]


def history():
    try:
        return json.loads(FILE.read_text())
    except Exception:
        return []


def run(engine, opts=None, selffix=None, trigger="auto"):
    s = engine.s
    now = engine.broker.now()
    items, stats = [], {}
    ev = list(engine.events)                                   # newest first
    # 1. repeating warnings / errors
    bad = [e for e in ev if e.get("level") in ("warning", "error")]
    groups = Counter(_norm(e["msg"]) for e in bad)
    code_hits = []
    for g, n in groups.most_common(6):
        if n >= 3:
            sample = next(e["msg"] for e in bad if _norm(e["msg"]) == g)
            code = bool(CODE_ERR.search(sample))
            items.append({"level": "attention" if code else "watch", "title": ("Repeating error: " if code else "Repeating warning: ") + sample[:110],
                          "detail": f"Seen {n} times in the recent log." + (" This looks like a code problem." if code else "")})
            if code:
                code_hits.append((n, sample))
    # 2. duplicate consecutive lines
    dups = sum(1 for a, b in zip(ev, ev[1:]) if a["msg"] == b["msg"] and a["t"] == b["t"])
    if dups >= 3:
        items.append({"level": "info", "title": f"{dups} log lines were printed twice", "detail": "Cosmetic only; trading is not affected."})
    # 3. today's trades
    try:
        today = str(engine.day or now.date())
        rows = [r for r in db.recent(300) if r.get("status") == "closed" and str(r.get("day") or "") == today and r.get("mode") != "SIM"]
    except Exception:
        rows = []
    pnl = round(sum(float(r.get("pnl") or 0) for r in rows), 2)
    wins = sum(1 for r in rows if float(r.get("pnl") or 0) > 0)
    stats.update(trades=len(rows), wins=wins, pnl=pnl)
    by = {}
    for r in rows:
        by.setdefault(r.get("strategy") or "?", []).append(float(r.get("pnl") or 0))
    for name, v in by.items():
        if len(v) >= 3 and sum(v) < 0 and sum(1 for x in v if x > 0) / len(v) < 0.34:
            items.append({"level": "watch", "title": f"{name} is losing today ({sum(v):+.2f} on {len(v)} trades)",
                          "detail": "The built-in tuner benches a setup that keeps losing, so no action is needed from you."})
    # 4. loss limit usage
    lim = float(s.daily_max_loss)
    try:
        dp = float(engine.risk.day_pnl)
    except Exception:
        dp = pnl
    stats.update(day_pnl=round(dp, 2), loss_limit=lim)
    if lim > 0 and dp < 0 and -dp >= 0.8 * lim:
        items.append({"level": "attention", "title": f"{-dp / lim:.0%} of today's loss limit was used", "detail": "The bot stops for the day at 100%."})
    try:
        eq = float((engine.acct or {}).get("equity") or 0)
        if eq and lim > 0.5 * eq:
            items.append({"level": "watch", "title": f"Your daily loss limit (${lim:,.0f}) is over half of the account (${eq:,.0f})",
                          "detail": "Nothing was changed. A limit this large will not stop a bad day early; lower it if that is not what you want."})
    except Exception:
        pass
    # 5. options fills + auto-tune
    if opts is not None and getattr(opts, "fills", None):
        f = opts.fills[-20:]
        rate = sum(f) / len(f)
        stats["opt_fill_rate"] = round(rate * 100)
        items.append({"level": "ok" if rate >= 0.5 else "watch", "title": f"Options fill rate {rate:.0%} (last {len(f)} entries)",
                      "detail": f"Wait {int(s.options_fill_wait_s)} s, up to {int(s.opt_reprice_max)} re-prices of {float(s.opt_reprice_step_pct):.0f}% each. "
                                + ("Auto-tune adjusts these when the rate stays low." if s.opt_autotune else "Auto-tune is off.")})
    tuned = [t["text"] for t in (s.tune_log or [])[-5:] if str(t.get("day")) == str(engine.day or now.date())]
    if tuned:
        items.append({"level": "info", "title": "Auto-tune changed settings today", "detail": " · ".join(tuned)})
    # 6. rejected orders
    rej = [e for e in ev if "rejected" in str(e.get("msg", "")).lower()]
    if len(rej) >= 2:
        items.append({"level": "watch", "title": f"{len(rej)} orders were rejected by the broker", "detail": rej[0]["msg"][:140]})
    # 7. optional code-fix draft (approval still needed)
    drafted = ""
    if code_hits and getattr(s, "auto_fix_draft", True) and selffix is not None:
        try:
            last = next((h for h in history() if h.get("drafted")), None)
            if not (last and last.get("day") == str(now.date())):
                n, sample = max(code_hits)
                selffix.start(f"The bot's own check-up saw this error {n} times in its log: {sample[:300]}. Find the cause and fix it without changing any trading rules or loss limits.",
                              "\n".join(e["msg"] for e in ev[:60])[:1800])
                drafted = "A fix was drafted for your approval (More > Fix with Claude)."
                items.append({"level": "attention", "title": "A fix was drafted", "detail": drafted + " Nothing changes until you approve it with your Live PIN."})
                try:
                    engine.alert("system", "Check-up: a fix is ready for your OK", sample[:120])
                except Exception:
                    pass
        except Exception as ex:
            items.append({"level": "info", "title": "Could not draft a fix", "detail": str(ex)[:140]})
    lv = {"attention": 2, "watch": 1}
    grade = ["ok", "watch", "attention"][max([lv.get(i["level"], 0) for i in items] + [0])]
    if not any(i["level"] in ("attention", "watch") for i in items):
        items.insert(0, {"level": "ok", "title": "Nothing needs your attention", "detail": f"{len(rows)} trade(s) closed today, net {pnl:+.2f}."})
    rep = {"at": now.strftime("%Y-%m-%d %H:%M"), "day": str(now.date()), "trigger": trigger, "grade": grade, "items": items, "stats": stats, "drafted": bool(drafted)}
    h = [rep] + [x for x in history() if not (x.get("day") == rep["day"] and x.get("trigger") == "auto" and trigger == "auto")]
    try:
        FILE.write_text(json.dumps(h[:14]))
    except Exception:
        pass
    if grade != "ok" and trigger == "auto":
        try:
            engine.alert("system", f"Check-up: {len([i for i in items if i['level'] in ('attention', 'watch')])} thing(s) to look at", items[0]["title"][:120])
        except Exception:
            pass
    return rep


def start_scheduler(get_engine, get_opts, get_selffix, settings):
    """One check-up per trading day, a few minutes after the close."""
    def loop():
        time.sleep(90)
        while True:
            try:
                e = get_engine()
                if e and getattr(settings, "auto_checkup", True) and e.mode != "SIM":
                    now = e.broker.now()
                    done = any(h.get("day") == str(now.date()) and h.get("trigger") == "auto" for h in history())
                    if now.weekday() < 5 and now.hour * 60 + now.minute >= 16 * 60 + 10 and not done:
                        run(e, get_opts(), get_selffix(), "auto")
            except Exception:
                pass
            time.sleep(300)
    threading.Thread(target=loop, daemon=True, name="checkup").start()
