"""AI Helper (v1.99): one chat for every AI tool in SekexBot.

You talk (or type) in plain words. The helper decides which tool it needs, runs it on your own data, and explains the result.
Tools it can use (all read-only; none can place an order or change a setting):
  scan_trends     biggest historical rises / falls inside a time window (morning, after lunch, before the close...)
  read_chart      the live AI chart read for one symbol
  predictions     the Predict-tab Potential Rise / Fall cards
  my_day          account, today's result, loss-limit use and open positions
  check_up        the bot's self check-up (log, trades, option fills)
  health          the Help & repair checks
  propose_fix     turns a problem you describe into a one-tap 'draft a fix' button (the fix still needs your PIN to apply)
Uses your own Claude or ChatGPT key. Everything it says about the market is a statistic from past bars, not advice."""
import json
import re

from .analyst import _api_error, _pick_model, ai_key, ai_name, ai_post

SYSTEM = """You are the AI Helper inside SekexBot, a stock trading bot app used on a phone. The user may be a beginner. Talk plainly, briefly, no jargon without a quick explanation.
You have tools. To use one, reply with ONLY a JSON object: {"tool": "<name>", "args": {...}}. After the tool result comes back you may call another tool or answer.
To answer, reply with ONLY: {"answer": "<your reply in plain text, short paragraphs, may use simple dashes for lists>"}.

TOOLS
- scan_trends {"window": "premarket|open|morning|midday|afterlunch|close|afterhours", "threshold_pct": 1.0, "symbols": ["NVDA"] (optional), "top": 8}
    Ranks stocks by how often and how far they rose or fell inside that part of the day over the last ~45 days, plus today's move so far. Use it for questions like "what could jump this morning", "big drops before the close", "after lunch trends".
- read_chart {"symbol": "NVDA"}   live technical read of one stock (trend, levels, plan)
- predictions {"mode": "PRE|REGULAR|AFTER|OVERNIGHT" (optional)}   the app's Potential Rise / Fall setups with entry zone, stop and targets
- my_day {}   account value, today's profit/loss, loss-limit used, open positions
- check_up {}   the bot's self check-up report
- health {}   technical health checks of the app
- propose_fix {"problem": "..."}   when the user reports something broken: offers a one-tap button to draft a code fix (needs their PIN to apply). Do not promise it is fixed.

RULES
- Numbers about the market come from tool results only. Never invent prices, percentages or hit rates. If a tool returns nothing useful, say so.
- A scan shows what HAPPENED in past days (frequency and size of moves). Say it is history, not a prediction or advice. Mention the sample size when it is small.
- You cannot place orders, change settings or touch loss limits. If asked to trade, explain which screen to use (Manual tab, or tap a Predict card).
- Time windows are Eastern Time. If the user says morning / after lunch / before close, pick the matching window and name it in your answer.
- Keep answers under about 180 words unless asked for more. End with one useful next step when it helps.
- If no tool is needed (a general question about how something works), just answer."""


def _parse(text: str):
    t = (text or "").strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    i = t.find("{")
    if i < 0:
        return {"answer": t}
    try:
        obj, _ = json.JSONDecoder().raw_decode(t[i:])
        return obj if isinstance(obj, dict) else {"answer": t}
    except Exception:
        return {"answer": t}


def chat(messages, tools: dict, now_text: str = "", max_rounds: int = 3):
    """messages: [{role: user|assistant, content: str}] (newest last). tools: {name: callable(args)->dict}."""
    key = ai_key()
    if not key:
        return {"error": f"Add a Claude or ChatGPT API key in More > App & account > Broker keys to use the AI Helper."}
    model = _pick_model(key)
    convo = [{"role": m["role"], "content": str(m["content"])[:1500]} for m in (messages or [])[-10:] if m.get("role") in ("user", "assistant") and m.get("content")]
    if not convo or convo[-1]["role"] != "user":
        return {"error": "Ask a question first."}
    cards, system = [], SYSTEM + (f"\n\nNow: {now_text}." if now_text else "")
    for rnd in range(max_rounds + 1):
        try:
            r = ai_post(90, {"model": model, "max_tokens": 900, "system": system, "messages": convo})
        except Exception as ex:
            return {"error": f"Couldn't reach {ai_name()}: {str(ex)[:150]}", "cards": cards}
        if r.status_code != 200:
            return {"error": _api_error(r.status_code, r.text), "cards": cards}
        text = "".join(b.get("text", "") for b in r.json().get("content", []))
        obj = _parse(text)
        name = obj.get("tool")
        if name and rnd < max_rounds:
            fn = tools.get(str(name))
            args = obj.get("args") if isinstance(obj.get("args"), dict) else {}
            if not fn:
                res = {"error": f"unknown tool {name}"}
            else:
                try:
                    res = fn(args)
                except Exception as ex:
                    res = {"error": str(ex)[:200]}
            cards.append({"tool": str(name), "args": args, "result": res})
            convo.append({"role": "assistant", "content": json.dumps({"tool": name, "args": args})})
            convo.append({"role": "user", "content": "TOOL RESULT " + str(name) + ": " + json.dumps(res, default=str)[:7000]})
            continue
        return {"answer": str(obj.get("answer") or text).strip(), "cards": cards, "model": model}
    return {"answer": "I couldn't finish that one. Try asking it a different way.", "cards": cards, "model": model}
