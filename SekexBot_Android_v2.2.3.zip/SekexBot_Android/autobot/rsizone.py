"""RSI zone read (v2.1): where does RSI sit for the current trend, and does a pullback entry have a record of working?

The idea is the widely taught "RSI range shift": in an uptrend RSI tends to live between about 40 and 80 (dips to the 40s that hold are
pullbacks), in a downtrend between about 20 and 60 (bounces into the 50s that fail are rallies to sell). This module is SekexBot's own
reading of that idea, not a copy of any commercial indicator.

For every stock it reports the trend (EMA20 vs EMA50), the RSI(14) zone, a plain note, whether a continuation signal fired on the latest bar
(RSI dipped toward 50 but held, then turned back with the trend), and the REAL record of that same signal on the last ~45 days of the
stock's own 15-minute bars (how often price was higher/lower 6 bars later). It is information only and never places an order."""
import numpy as np
import pandas as pd

from .indicators import ema, rsi

HOLD_UP = 38.0      # an uptrend dip may go down to here and still count as "held"
HOLD_DN = 62.0      # a downtrend bounce may go up to here and still count as "failed"
LOOK = 4            # bars to look back for the dip
FWD = 6             # bars ahead to judge the outcome (6 x 15 min = 1.5 hours)
MIN_CASES = 8


def _frame(close: pd.Series):
    c = close.astype(float)
    r = rsi(c, 14)
    e1, e2 = ema(c, 20), ema(c, 50)
    trend = pd.Series(np.where((e1 > e2) & (c > e2), 1, np.where((e1 < e2) & (c < e2), -1, 0)), index=c.index)
    return c, r, trend


def _signal_at(r: pd.Series, trend: pd.Series, i: int):
    """+1 / -1 if a continuation signal fires on bar i, else 0."""
    if i < LOOK + 1:
        return 0
    win = r.iloc[i - LOOK:i]
    if trend.iloc[i] > 0 and win.min() <= 50 and win.min() >= HOLD_UP and r.iloc[i - 1] <= 50 < r.iloc[i]:
        return 1
    if trend.iloc[i] < 0 and win.max() >= 50 and win.max() <= HOLD_DN and r.iloc[i - 1] >= 50 > r.iloc[i]:
        return -1
    return 0


def _zone(t: int, v: float):
    if t > 0:
        if v > 80:
            return "stretched", "RSI is above 80: strong, but stretched. Chasing here is risky; wait for a dip."
        if v >= 50:
            return "strong", "Uptrend and RSI is in its strong zone (50 to 80): buyers are in control."
        if v >= 40:
            return "pullback", "Uptrend pulling back. RSI is in the 40s; if it holds and turns up, that is the classic continuation entry."
        return "doubt", "RSI fell below 40 in an uptrend: the trend is in doubt. Do not treat this as a normal dip."
    if t < 0:
        if v < 20:
            return "stretched", "RSI is below 20: weak, but stretched. Chasing a short here is risky; wait for a bounce."
        if v <= 50:
            return "weak", "Downtrend and RSI is in its weak zone (20 to 50): sellers are in control."
        if v <= 60:
            return "bounce", "Downtrend bouncing. RSI is in the 50s; if it fails and turns down, that is the classic continuation short."
        return "doubt", "RSI rose above 60 in a downtrend: the trend is in doubt."
    return "flat", "No clear trend (EMA20 and EMA50 disagree with price). RSI zones do not apply well here."


def backtest(df: pd.DataFrame):
    """Past cases of the continuation signal on this stock's own bars."""
    c, r, trend = _frame(df["close"])
    idx = pd.to_datetime(df.index)
    out = {1: [], -1: []}
    last = -99
    for i in range(55, len(c) - FWD):
        if i - last < LOOK:
            continue
        s = _signal_at(r, trend, i)
        if not s:
            continue
        if idx[i].date() != idx[i + FWD].date():        # keep the outcome inside the same day
            continue
        last = i
        out[s].append((float(c.iloc[i + FWD]) / float(c.iloc[i]) - 1) * 100 * s)     # +ve = the signal's direction was right
    return out


def _evidence(res, side):
    v = res.get(side, [])
    n = len(v)
    if n < MIN_CASES:
        return {"n": n, "ok": False, "text": f"Only {n} past cases in ~45 days. Too few to judge."}
    win = sum(1 for x in v if x > 0) / n * 100
    avg = sum(v) / n
    d = "higher" if side > 0 else "lower"
    return {"n": n, "ok": True, "win": round(win), "avg": round(avg, 2),
            "text": f"In the last ~45 days this setup showed up {n} times on this stock. About 1.5 hours later price was {d} {round(win)}% of the time (average {avg:+.2f}% in the signal's direction)."}


def analyze(sym: str, df: pd.DataFrame, with_history: bool = True):
    if df is None or len(df) < 60:
        return {"symbol": sym, "ok": False, "note": "Not enough bars yet."}
    d = df.sort_index()
    c, r, trend = _frame(d["close"])
    t, v = int(trend.iloc[-1]), float(r.iloc[-1])
    zone, note = _zone(t, v)
    s = _signal_at(r, trend, len(c) - 1)
    res = backtest(d) if with_history else {1: [], -1: []}
    ev = _evidence(res, s) if (s and with_history) else None
    return {"symbol": sym, "ok": True, "trend": {1: "UP", -1: "DOWN", 0: "FLAT"}[t], "rsi": round(v, 1), "zone": zone, "note": note,
            "signal": ({1: "BUY", -1: "SELL"}[s] if s else None), "evidence": ev,
            "history": {"buy": _evidence(res, 1), "sell": _evidence(res, -1)} if with_history else None,
            "tf": "15-minute bars"}
