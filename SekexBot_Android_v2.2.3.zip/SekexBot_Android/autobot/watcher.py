"""Background watcher: trend alerts on your watchlist, your price alerts, and the end-of-day summary.

Runs whether or not the auto-trader is on. Trend checks use 1-minute bars while a session is open;
each condition alerts once when it CHANGES (first look only records the state, so no alert storm)."""
import logging
import threading
import time
import uuid
from datetime import datetime

from . import db
from .alerts import spell
from .indicators import enrich, ribbon_state
from .predict import MIN_CONF, chip_status
from .sessions import NY, bot_day, current_session

log = logging.getLogger("autobot")


class Watcher:
    def __init__(self, get_engine, alerts, settings):
        self.get_engine, self.alerts, self.s = get_engine, alerts, settings
        self.state = {}          # sym -> last seen conditions
        self.day = ""
        self.summary_day = ""
        self.last_trend = 0.0
        threading.Thread(target=self._loop, daemon=True, name="watcher").start()

    # ---------- price alerts you set ----------
    def add_price_alert(self, sym, op, price, note=""):
        pa = self.alerts.cfg.setdefault("price_alerts", [])
        pa.append({"id": uuid.uuid4().hex[:8], "symbol": sym, "op": op, "price": float(price), "note": note,
                   "created": datetime.now(NY).strftime("%m-%d %H:%M")})
        self.alerts.save()
        return pa

    def remove_price_alert(self, aid):
        self.alerts.cfg["price_alerts"] = [a for a in self.alerts.cfg.get("price_alerts", []) if a["id"] != aid]
        self.alerts.save()

    def _check_prices(self, e):
        pa = list(self.alerts.cfg.get("price_alerts", []))
        if not pa:
            return
        sess = e.session.name if e.session else "REGULAR"
        fired = []
        for a in pa:
            try:
                p = e.broker.price_info(a["symbol"], sess)
            except Exception:
                continue
            px = p.get("last") if not p.get("bid") else (p["bid"] + p["ask"]) / 2
            if px is None:
                continue
            if (a["op"] == "above" and px >= a["price"]) or (a["op"] == "below" and px <= a["price"]):
                self.alerts.send("price", f"🎯 {a['symbol']} {'above' if a['op'] == 'above' else 'below'} {a['price']:.2f}",
                                 f"Now {px:.2f}" + (f" · {a['note']}" if a.get("note") else ""), symbol=a["symbol"])
                fired.append(a["id"])
        if fired:
            self.alerts.cfg["price_alerts"] = [a for a in self.alerts.cfg["price_alerts"] if a["id"] not in fired]
            self.alerts.save()

    # ---------- trend alerts on the watchlist ----------
    def _check_trends(self, e):
        syms = [w.upper() for w in (self.s.watchlist or [])][:20]
        if not syms:
            return
        try:
            now = e.broker.now()
            bars = e.broker.bars(syms, start=now.replace(hour=4, minute=0, second=0, microsecond=0))
        except Exception:
            return
        for sym, df in bars.items():
            if df is None or len(df) < 25:
                continue
            d = enrich(df)
            last = d.iloc[-1]
            rb = ribbon_state(df)
            px = float(last["close"])
            hod, lod = float(d["high"].iloc[:-1].max()), float(d["low"].iloc[:-1].min())
            vol_avg = float(last["vol_avg"]) if last["vol_avg"] == last["vol_avg"] else 0
            cur = {"ribbon": rb["state"] if rb.get("ready") else 0, "above_vwap": px > float(last["vwap"]),
                   "hod": hod, "lod": lod, "pred": None}
            try:
                o = chip_status(df, 3).get("outlook") if len(df) >= 60 else None
                if o and o["conf"] >= max(MIN_CONF, int(self.alerts.cfg.get("predict_min", 65))):
                    cur["pred"] = (o["side"], o["t"], o["conf"])
            except Exception:
                pass
            try:
                from . import rsizone
                rz = rsizone.analyze(sym, df, with_history=False)
                cur["rz"] = rz.get("signal") if rz.get("ok") else None
                cur["rz_rsi"] = rz.get("rsi")
            except Exception:
                cur["rz"] = None
            prev = self.state.get(sym)
            self.state[sym] = cur
            if prev is None:
                continue
            if cur["ribbon"] and prev["ribbon"] and cur["ribbon"] != prev["ribbon"]:
                up = cur["ribbon"] > 0
                self.alerts.send("ribbon", f"{'🟩' if up else '🟥'} {sym} {'BUY' if up else 'SELL'} · ribbon flipped {'GREEN' if up else 'RED'}",
                                 f"{sym} {px:.2f} · trend turning {'up' if up else 'down'}", symbol=sym,
                                 speak=f"{spell(sym)}. {'Buy' if up else 'Sell'} signal. Trend turned {'up' if up else 'down'}.")
            if cur["pred"] and cur["pred"][:2] != (prev.get("pred") or (None, None))[:2]:
                side, _, conf = cur["pred"]
                self.alerts.send("predict", f"⚠ {sym} {'BUY?' if side == 'buy' else 'SELL?'} {conf}% · early warning",
                                 f"{sym} {px:.2f} · trend may flip {'up' if side == 'buy' else 'down'} soon. Not confirmed yet.",
                                 symbol=sym, speak=f"{spell(sym)}. {'Buy' if side == 'buy' else 'Sell'} warning. {conf} percent.")
            if cur.get("rz") and cur["rz"] != prev.get("rz"):
                buy = cur["rz"] == "BUY"
                self.alerts.send("rsizone", f"{'🟩' if buy else '🟥'} {sym} RSI zone {'pullback held' if buy else 'bounce failed'} · {cur['rz']}?",
                                 f"{sym} {px:.2f} · RSI {cur.get('rz_rsi')} turned back with the trend. Tap for the past record.", symbol=sym)
            if float(last["high"]) > prev["hod"] and px > prev["hod"]:
                self.alerts.send("range", f"⬆ {sym} new high of day", f"{px:.2f} broke {prev['hod']:.2f}", symbol=sym)
            elif float(last["low"]) < prev["lod"] and px < prev["lod"]:
                self.alerts.send("range", f"⬇ {sym} new low of day", f"{px:.2f} broke {prev['lod']:.2f}", symbol=sym)
            if cur["above_vwap"] != prev["above_vwap"]:
                self.alerts.send("vwap", f"{sym} {'reclaimed' if cur['above_vwap'] else 'lost'} VWAP",
                                 f"{px:.2f} vs VWAP {float(last['vwap']):.2f}", symbol=sym)
            if vol_avg and float(last["volume"]) > 3 * vol_avg and float(last["volume"]) > 20000:
                self.alerts.send("volume", f"📊 {sym} volume spike", f"{float(last['volume'])/vol_avg:.1f}× normal · {px:.2f}",
                                 symbol=sym)

    # ---------- end-of-day summary ----------
    def _summary(self, e, now):
        today = now.date().isoformat()
        if self.summary_day == today or now.hour < 16 or (now.hour == 16 and now.minute < 5) or now.weekday() >= 5:
            return
        self.summary_day = today
        rows = [r for r in db.daily_summary(5) if r["day"] == bot_day(now)]
        if not rows:
            self.alerts.send("summary", "📋 SekexBot day summary", "No bot trades today.")
            return
        r = rows[0]
        pnl = r["pnl"] or 0
        best = e.learner.leaderboard()[:1]
        tip = f" · best setup: {best[0]['strategy']}/{best[0]['exit']}" if best else ""
        self.alerts.send("summary", f"📋 Day summary {'+' if pnl >= 0 else '-'}${abs(pnl):,.2f}",
                         f"{r['trades']} trades · {r['win_rate']}% wins · avg {r['avg_r']}R{tip}", pnl=pnl)

    def _loop(self):
        time.sleep(20)
        while True:
            try:
                e = self.get_engine()
                if e is not None:
                    now = e.broker.now()
                    if bot_day(now) != self.day:
                        self.day, self.state = bot_day(now), {}
                    self._check_prices(e)
                    sess = current_session(e.broker.trading_day, now)
                    if sess and time.time() - self.last_trend >= 55:
                        self.last_trend = time.time()
                        self._check_trends(e)
                    self._summary(e, now)
            except Exception as ex:
                log.debug("watcher: %s", ex)
            time.sleep(15)
