"""Time-of-day trend scan (v1.99): for each stock, how big have the moves been inside one part of the trading day?

For a window (open, morning, midday, after lunch, before close, pre-market, after-hours) it measures, over the last ~45 days of
15-minute bars, the biggest rise and the biggest fall measured from the window's own open. From that: how often the stock rose
(or fell) by at least THRESHOLD %, how big those moves were typically (average and the 9th decile), and today's move so far.
It is a record of what happened, not a forecast. Display / research only; it never places an order."""
from datetime import time
from zoneinfo import ZoneInfo

import pandas as pd

NY = ZoneInfo("America/New_York")
WINDOWS = {
    "premarket": ("Pre-market", time(4, 0), time(9, 30)),
    "open": ("The open (first hour)", time(9, 30), time(10, 30)),
    "morning": ("Morning", time(9, 30), time(11, 30)),
    "midday": ("Midday", time(11, 30), time(13, 30)),
    "afterlunch": ("After lunch", time(12, 30), time(14, 30)),
    "close": ("Before the close (last hour)", time(15, 0), time(16, 0)),
    "afterhours": ("After-hours", time(16, 0), time(20, 0)),
}
ALIASES = {"pre": "premarket", "pre-market": "premarket", "premarket": "premarket", "open": "open", "opening": "open", "first hour": "open",
           "morning": "morning", "am": "morning", "midday": "midday", "noon": "midday", "lunch": "midday", "after lunch": "afterlunch",
           "afternoon": "afterlunch", "afterlunch": "afterlunch", "close": "close", "closing": "close", "before close": "close", "power hour": "close",
           "end of day": "close", "afterhours": "afterhours", "after-hours": "afterhours", "after hours": "afterhours", "evening": "afterhours"}


def window_key(name: str) -> str:
    n = str(name or "").strip().lower()
    return n if n in WINDOWS else ALIASES.get(n, "")


def _pct(a, b):
    return (b / a - 1) * 100 if a else 0.0


def _q(vals, q):
    v = sorted(vals)
    return v[min(len(v) - 1, int(q * len(v)))] if v else 0.0


def scan_one(sym: str, d: pd.DataFrame, win: str, thr: float = 1.0):
    label, t0, t1 = WINDOWS[win]
    d = d.sort_index()
    d.index = pd.to_datetime(d.index).tz_convert(NY)
    w = d[(d.index.time >= t0) & (d.index.time < t1)]
    ups, dns, nets, today = [], [], [], None
    last_day = d.index[-1].date() if len(d) else None
    for day, g in w.groupby(w.index.date):
        if len(g) < 2:
            continue
        o = float(g["open"].iloc[0])
        up, dn, net = _pct(o, float(g["high"].max())), _pct(o, float(g["low"].min())), _pct(o, float(g["close"].iloc[-1]))
        if day == last_day and d.index[-1].time() < t1 and d.index[-1].time() >= t0:    # window still running today
            today = {"up": round(up, 2), "down": round(dn, 2), "net": round(net, 2), "partial": True}
            continue
        ups.append(up), dns.append(dn), nets.append(net)
        if day == last_day:
            today = {"up": round(up, 2), "down": round(dn, 2), "net": round(net, 2), "partial": False}
    n = len(ups)
    if n < 10:
        return None
    pu = sum(1 for x in ups if x >= thr) / n
    pd_ = sum(1 for x in dns if x <= -thr) / n
    au = sum(x for x in ups if x >= thr) / max(1, sum(1 for x in ups if x >= thr))
    ad = sum(x for x in dns if x <= -thr) / max(1, sum(1 for x in dns if x <= -thr))
    return {"symbol": sym, "n": n, "p_up": round(pu * 100), "p_down": round(pd_ * 100), "avg_up": round(au, 2), "avg_down": round(ad, 2),
            "p90_up": round(_q(ups, .9), 2), "p90_down": round(_q(dns, .1), 2), "max_up": round(max(ups), 2), "max_down": round(min(dns), 2),
            "bias": round(sum(nets) / n, 3), "avg_range": round(sum(a - b for a, b in zip(ups, dns)) / n, 2), "today": today,
            "score_up": round(pu * au, 3), "score_down": round(pd_ * abs(ad), 3)}


def scan(bars: dict, window: str, thr: float = 1.0, top: int = 8):
    win = window_key(window) or "morning"
    rows = []
    for sym, d in (bars or {}).items():
        try:
            r = scan_one(sym, d, win, thr)
        except Exception:
            r = None
        if r:
            rows.append(r)
    gains = sorted(rows, key=lambda r: -r["score_up"])[:top]
    drops = sorted(rows, key=lambda r: -r["score_down"])[:top]
    return {"window": win, "label": WINDOWS[win][0], "hours": f"{WINDOWS[win][1].strftime('%-I:%M %p')}-{WINDOWS[win][2].strftime('%-I:%M %p')} ET",
            "threshold_pct": thr, "scanned": len(rows), "gains": gains, "drops": drops}
