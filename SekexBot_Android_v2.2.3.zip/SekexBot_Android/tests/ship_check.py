"""sekex clean / ship against a mock GitHub and a fake phone Downloads folder. Prints OK on success."""
import base64, json, os, subprocess, sys, tempfile, threading, zipfile
from http.server import BaseHTTPRequestHandler, HTTPServer
ROOT = sys.argv[1]
files = {n: b"x" for n in ["SekexBot_Android_v1.90.0.zip", "SekexBot_Android_v1.92.0.zip", "SekexBot_Android_v1.93.2.zip", "SekexBot_Android_v1.93.3.zip",
                           "admin_v1.92.0.enc", "admin_v1.93.2.enc", "admin_v1.93.3.enc", "README.md"]}
files["latest.json"] = json.dumps({"version": "1.93.3", "url": "SekexBot_Android_v1.93.3.zip"}).encode()
log = {"del": [], "put": []}


class H(BaseHTTPRequestHandler):
    def log_message(s, *a): pass
    def _send(s, code, obj):
        b = json.dumps(obj).encode(); s.send_response(code); s.send_header("Content-Type", "application/json"); s.end_headers(); s.wfile.write(b)
    def do_GET(s):
        p = s.path.split("?")[0]
        if p.endswith("/contents/") or p.endswith("/contents"): return s._send(200, [{"name": n, "sha": "sha-" + n} for n in files])
        if p.startswith("/repos/o/r") and "/contents/" not in p: return s._send(200, {"private": False, "default_branch": "main"})
        n = p.split("/contents/")[1]
        if n in files: return s._send(200, {"name": n, "sha": "sha-" + n, "content": base64.b64encode(files[n]).decode()})
        return s._send(404, {})
    def do_PUT(s):
        n = s.path.split("/contents/")[1]; body = json.loads(s.rfile.read(int(s.headers["Content-Length"])))
        files[n] = base64.b64decode(body["content"]); log["put"].append(n); s._send(201, {})
    def do_DELETE(s):
        n = s.path.split("/contents/")[1]; body = json.loads(s.rfile.read(int(s.headers["Content-Length"])))
        assert body["sha"] == "sha-" + n; files.pop(n); log["del"].append(n); s._send(200, {})


srv = HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
home = tempfile.mkdtemp(); dl = os.path.join(home, "storage", "downloads"); os.makedirs(dl)
for f in ["SekexBot_Android_v1.91.0.zip", "SekexBot_Android_v1.93.0.zip", "SekexBot_Android_v1.93.1.zip", "SekexBot_Android_v1.93.2.zip", "SekexBot_Android_v1.93.3.zip",
          "SekexBot_Admin_v1.93.0.zip", "SekexBot_Admin_v1.93.3.zip", "SekexBot_Android_Release_Notes_and_Install_v1.93.0.pdf", "SekexBot_Android_Release_Notes_and_Install_v1.93.1.pdf",
          "SekexBot_Android_Release_Notes_and_Install_v1.93.2.pdf", "SekexBot_Android_Release_Notes_and_Install_v1.93.3.pdf",
          "SekexBot_Setup.sh", "sekexbot-setup.conf", "latest.json", "mine.txt"]:
    open(os.path.join(dl, f), "w").write("x")
# the newest zip must be a real SekexBot zip for ship
with zipfile.ZipFile(os.path.join(dl, "SekexBot_Android_v1.94.0.zip"), "w") as z:
    z.writestr("SekexBot_Android/VERSION", "1.94.0\n"); z.writestr("SekexBot_Android/install.sh", "#"); z.writestr("SekexBot_Android/CHANGELOG.md", "## 1.94.0 — x\n- New thing: yes\n")
for i in range(5):
    p = os.path.join(dl, f"SekexBot_backup_2026100{i}_1200.zip"); open(p, "w").write("k"); os.utime(p, (1000 + i, 1000 + i))
rel = os.path.join(home, ".sekexbot", "releases"); os.makedirs(rel)
for v in ["1.93.0", "1.93.1", "1.93.2", "1.93.3"]: open(os.path.join(rel, f"SekexBot_Android_v{v}.zip"), "w").write("x")
os.makedirs(os.path.join(home, ".sekexbot_setup_tmp")); os.makedirs(os.path.join(home, "sekexbot", "data")); open(os.path.join(home, "sekexbot", ".env"), "w").write("KEY")
json.dump({"repo": "o/r", "token": "t", "branch": "main"}, open(os.path.join(home, ".sekexbot", "github.json"), "w"))
env = dict(os.environ, HOME=home, SEKEX_GITHUB_API=f"http://127.0.0.1:{srv.server_port}", PORT="1")


def run(*a, inp="n\n"):
    r = subprocess.run([sys.executable, os.path.join(ROOT, "bin", "sekex_ship.py"), *a], env=env, capture_output=True, text=True, input=inp, timeout=60)
    return r.returncode, r.stdout + r.stderr


rc, out = run("ship", "--dry-run"); assert rc == 0, out
assert not log["put"] and not log["del"] and os.path.exists(os.path.join(dl, "SekexBot_Android_v1.91.0.zip")), "dry run must change nothing\n" + out
rc, out = run("ship", inp="n\n"); assert "Cancelled" in out and not log["put"] and not log["del"], out          # answering no changes nothing
rc, out = run("ship", "--yes"); print(out); assert rc == 0, out
left = sorted(os.listdir(dl))
for must in ["SekexBot_Setup.sh", "sekexbot-setup.conf", "latest.json", "mine.txt", "SekexBot_Android_v1.94.0.zip", "SekexBot_Android_v1.93.3.zip", "SekexBot_Android_v1.93.2.zip"]:
    assert must in left, must
for gone in ["SekexBot_Android_v1.91.0.zip", "SekexBot_Android_v1.93.0.zip", "SekexBot_Android_v1.93.1.zip"]:
    assert gone not in left, gone
assert sum(f.startswith("SekexBot_Android_v") for f in left) == 3 and sum("Release_Notes" in f for f in left) == 3 and sum(f.startswith("SekexBot_backup") for f in left) == 3
assert sorted(os.listdir(rel)) == ["SekexBot_Android_v1.93.1.zip", "SekexBot_Android_v1.93.2.zip", "SekexBot_Android_v1.93.3.zip"]
assert not os.path.exists(os.path.join(home, ".sekexbot_setup_tmp")) and os.path.exists(os.path.join(home, "sekexbot", ".env")) and os.path.isdir(os.path.join(home, "sekexbot", "data"))
assert "SekexBot_Android_v1.94.0.zip" in log["put"] and log["put"][-1] == "latest.json", log          # zip first, latest.json last
gh = sorted(n for n in files if n.startswith("SekexBot_Android_v"))
assert gh == ["SekexBot_Android_v1.93.2.zip", "SekexBot_Android_v1.93.3.zip", "SekexBot_Android_v1.94.0.zip"], gh
assert "README.md" in files and "latest.json" in files and json.loads(files["latest.json"])["version"] == "1.94.0"
print("OK")
