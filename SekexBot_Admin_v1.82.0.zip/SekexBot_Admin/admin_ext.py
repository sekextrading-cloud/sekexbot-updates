"""SekexBot support-admin add-on (server side). Installed only on the admin's phone, never part of the public app.

Registers /api/admin/* routes that forward to the support collector. The passcode is checked by the collector."""
import json
import urllib.error
import urllib.request

from fastapi import Header, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel


def register(app, settings, telemetry):
    def collector_call(method, path, body=None, token=None):
        base = telemetry.collector_url(settings)
        if not base:
            raise HTTPException(400, "Set the collector address first.")
        req = urllib.request.Request(base + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                     headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + token} if token else {})})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read() or b"{}")
        except urllib.error.HTTPError as ex:
            try:
                detail = json.loads(ex.read()).get("detail", "")
            except Exception:
                detail = ""
            raise HTTPException(ex.code, detail or f"Collector said {ex.code}")
        except Exception as ex:
            raise HTTPException(502, f"Couldn't reach the collector: {str(ex)[:100]}")

    class AdminLogin(BaseModel):
        passcode: str
        collector_url: str | None = None

    @app.post("/api/admin/login")
    def admin_login(r: AdminLogin):
        if r.collector_url is not None and r.collector_url.strip():
            u = r.collector_url.strip().rstrip("/")
            if not telemetry.valid_url(u):
                raise HTTPException(400, "The collector address must start with https://")
            settings.collector_url = u
            settings.save()
        return collector_call("POST", "/v1/admin/login", {"passcode": r.passcode})

    @app.get("/api/admin/devices")
    def admin_devices(x_admin_token: str | None = Header(None)):
        return collector_call("GET", "/v1/admin/devices", token=x_admin_token)

    @app.get("/api/admin/device/{iid}")
    def admin_device(iid: str, hours: int = 6, x_admin_token: str | None = Header(None)):
        return collector_call("GET", f"/v1/admin/device/{iid}?hours={int(hours)}", token=x_admin_token)

    @app.delete("/api/admin/device/{iid}")
    def admin_device_delete(iid: str, x_admin_token: str | None = Header(None)):
        return collector_call("DELETE", f"/v1/admin/device/{iid}", token=x_admin_token)

    def collector_bytes(path, token):
        base = telemetry.collector_url(settings)
        if not base:
            raise HTTPException(400, "Set the collector address first.")
        req = urllib.request.Request(base + path, headers={"Authorization": "Bearer " + (token or "")})
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                return resp.read()
        except urllib.error.HTTPError as ex:
            raise HTTPException(ex.code, f"Collector said {ex.code}")
        except Exception as ex:
            raise HTTPException(502, f"Couldn't reach the collector: {str(ex)[:100]}")

    @app.get("/api/admin/logs")
    def admin_logs(x_admin_token: str | None = Header(None)):
        return collector_call("GET", "/v1/admin/logs", token=x_admin_token)

    @app.get("/api/admin/logs/all.zip")
    def admin_logs_all(x_admin_token: str | None = Header(None)):
        return Response(collector_bytes("/v1/admin/logs/all.zip", x_admin_token), media_type="application/zip",
                        headers={"Content-Disposition": 'attachment; filename="sekexbot_all_logs.zip"'})

    @app.get("/api/admin/logs/{iid}/summary")
    def admin_log_summary(iid: str, x_admin_token: str | None = Header(None)):
        return collector_call("GET", f"/v1/admin/logs/{iid}/summary", token=x_admin_token)

    @app.get("/api/admin/logs/{iid}/zip")
    def admin_log_zip(iid: str, x_admin_token: str | None = Header(None)):
        return Response(collector_bytes(f"/v1/admin/logs/{iid}/zip", x_admin_token), media_type="application/zip",
                        headers={"Content-Disposition": f'attachment; filename="sekexbot_logs_{iid[:8]}.zip"'})

    class AnalyzeReq(BaseModel):
        question: str = ""

    @app.post("/api/admin/logs/{iid}/analyze")
    def admin_log_analyze(iid: str, r: AnalyzeReq, x_admin_token: str | None = Header(None)):
        """AI helper: reads the numbers summary of one install's journal and suggests strategy changes."""
        import os
        import requests
        from autobot.analyst import _api_error, _pick_model, ai_key, ai_name, ai_post
        key = ai_key()
        if not key:
            return {"error": "Add a Claude or ChatGPT API key in Settings > Broker keys > AI to use the AI helper."}
        j = collector_call("GET", f"/v1/admin/logs/{iid}/summary", token=x_admin_token)
        system = ("You are the strategy analyst for SekexBot, an Alpaca day-trading bot (longs and shorts, pre-market, regular and after-hours). "
                  "You get a numbers-only summary of one user's closed trades: by strategy, session, side, exit note, time of day, the worst trades, "
                  "the most common reasons trades were skipped, and key settings. Find where the money is lost and say what to change. Rules: be concrete "
                  "(name the strategy, session or setting and a number), separate what the data proves from what is only a hint, state sample sizes and "
                  "never draw a firm conclusion from fewer than ~15 trades, compare average win to average loss (payoff ratio) not just win rate, and do "
                  "not suggest raising the daily loss limit. Reply in short plain paragraphs, then a numbered list of at most 5 changes, most valuable first.")
        user = (f"SekexBot v{j.get('version')}. Install label: {j.get('label') or 'none'}.\n"
                f"Question: {r.question.strip() or 'Why is this install losing, and what should change?'}\n\nSummary:\n"
                + json.dumps(j.get("summary"), indent=1)[:14000])
        model = _pick_model(key)
        try:
            resp = ai_post(120, {"model": model, "max_tokens": 1500, "system": system, "messages": [{"role": "user", "content": user}]})
        except Exception as ex:
            return {"error": f"Couldn't reach {ai_name()}: {str(ex)[:150]}"}
        if resp.status_code != 200:
            return {"error": _api_error(resp.status_code, resp.text)}
        return {"answer": "".join(b.get("text", "") for b in resp.json().get("content", [])).strip(), "model": model}

    @app.get("/api/admin/overview")
    def admin_overview(x_admin_token: str | None = Header(None)):
        return collector_call("GET", "/v1/admin/overview", token=x_admin_token)

    @app.post("/api/admin/ai/group")
    def admin_ai_group(r: AnalyzeReq, x_admin_token: str | None = Header(None)):
        """AI helper over the combined results of everyone who shares logs, plus fleet health."""
        import os
        import requests
        from autobot.analyst import _api_error, _pick_model, ai_key, ai_name, ai_post
        key = ai_key()
        if not key:
            return {"error": "Add a Claude or ChatGPT API key in Settings > Broker keys > AI to use the AI helper."}
        j = collector_call("GET", "/v1/admin/overview", token=x_admin_token)
        fl = j.get("fleet", {})
        data = {"fleet": {k: fl.get(k) for k in ("installs", "online", "latest", "versions", "behind", "problems", "flags")}, "trading": j.get("trading")}
        system = ("You are the strategy and operations analyst for SekexBot, an Alpaca day-trading bot used by several people. You get combined, "
                  "numbers-only results of every install that shares logs (by strategy, session, side, exit type, time of day, daily P&L, top skip reasons) "
                  "and fleet health (versions, problems). Say where money is lost across the group and what to change in the bot, then what to fix in the fleet. "
                  "Be concrete (name the strategy, session or setting and a number), separate what the data proves from hints, state sample sizes and never draw a firm "
                  "conclusion from fewer than ~15 trades, judge by payoff ratio (average win vs average loss), not win rate alone, and never suggest raising a daily "
                  "loss limit. Reply in short plain paragraphs, then a numbered list of at most 6 changes, most valuable first.")
        user = f"Question: {r.question.strip() or 'What are the biggest problems and the best changes?'}\n\nData:\n" + json.dumps(data, indent=1)[:14000]
        model = _pick_model(key)
        try:
            resp = ai_post(120, {"model": model, "max_tokens": 1800, "system": system, "messages": [{"role": "user", "content": user}]})
        except Exception as ex:
            return {"error": f"Couldn't reach {ai_name()}: {str(ex)[:150]}"}
        if resp.status_code != 200:
            return {"error": _api_error(resp.status_code, resp.text)}
        return {"answer": "".join(b.get("text", "") for b in resp.json().get("content", [])).strip(), "model": model}
