"""v2.43: Market Core - the market right now, at the top of the Auto tab.

  * Session: pre-market / opening rush / lunch chop / power hour / closed.
  * SPY, QQQ (vs yesterday's close and VWAP), VIX, and how many of your watchlist are green (breadth).
  * Market lean 0-100 (50 = neutral). It is LOGGED, not used for trading: every 5 minutes it saves the reading with SPY's
    price, and the card shows how often the lean called SPY's next 30 minutes right. Only if that proves useful should it
    ever steer the bot.
  * Today's big news: US economic releases (jobs report, CPI, Fed...) from the free ForexFactory weekly calendar, plus a
    built-in list of Fed (FOMC) days and the jobs-report Friday as a backup, and earnings for your watchlist.
  * News gate: no NEW bot trades from 15 minutes before to 5 minutes after a HIGH-impact release (open trades keep their stops).
Every source fails open: if it can't be reached, nothing is blocked and the card says so."""
import json
import threading
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import requests

from .config import DATA_DIR

NY = ZoneInfo("America/New_York")
LOG = DATA_DIR / "marketcore_log.jsonl"
CFG = DATA_DIR / "marketcore.json"
FF_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) SekexBot", "Accept": "application/json"}
GATE_BEFORE, GATE_AFTER = 15, 5          # minutes
# Fed decision days (2:00 PM ET statement). Backup for when the calendar feed can't be reached.
FOMC = ("2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17", "2026-07-29", "2026-09-16", "2026-10-28", "2026-12-09")
_lock = threading.Lock()
_ff = {"t": 0.0, "rows": [], "err": ""}

SESSIONS = [("pre", 240, 570, "Pre-market"), ("rush", 570, 630, "Opening rush"), ("morning", 630, 690, "Late morning"),
            ("lunch", 690, 840, "Lunch chop"), ("afternoon", 840, 900, "Afternoon"), ("power", 900, 960, "Power hour"),
            ("after", 960, 1200, "After-hours")]
SESSION_TIP = {"pre": "Thin trading: wide spreads, use limit orders.", "rush": "Biggest moves and fakeouts of the day. Opening Rush trades now.",
               "morning": "Trends from the open either keep going or stall here.", "lunch": "Slow and choppy: smaller size or sit out.",
               "afternoon": "Volume starts to come back.", "power": "Big funds trade into the close; the Pullback Buyer acts at 3:55.",
               "after": "Earnings moves; limit orders only.", "closed": "Market closed."}


def cfg():
    try:
        c = json.loads(CFG.read_text())
    except Exception:
        c = {}
    return {"gate": bool(c.get("gate", True))}


def set_cfg(gate=None):
    c = cfg()
    if gate is not None:
        c["gate"] = bool(gate)
    CFG.write_text(json.dumps(c))
    return c


LONDON = ZoneInfo("Europe/London")


def london_open(day):
    """v2.47.5: 08:00 London on `day`, as a New York datetime. Computed from London's own clock, so it is right through BOTH
    countries' daylight-saving changes: 3:00 AM ET most of the year, 4:00 AM ET for the week in late Oct / early Nov when
    only one side has changed."""
    from datetime import time as _time
    return datetime.combine(day, _time(8, 0), tzinfo=LONDON).astimezone(NY)


def session(now):
    m = now.hour * 60 + now.minute
    lo = london_open(now.date())
    lo_m = lo.hour * 60 + lo.minute
    extra = {"london_at": lo.strftime("%-I:%M %p"), "london_min": lo_m}
    if now.weekday() >= 5:
        return {"key": "closed", "name": "Weekend", "tip": SESSION_TIP["closed"], **extra}
    if lo_m <= m < 240:
        return {"key": "london", "name": "London open", "tip": f"Europe is trading US stocks from {lo.strftime('%-I:%M %p')} ET; the first turn of the day often happens here. Thin: limit orders only.", "left_min": 240 - m, **extra}
    for k, a, b, nm in SESSIONS:
        if a <= m < b:
            return {"key": k, "name": nm, "tip": SESSION_TIP[k], "left_min": b - m, **extra}
    return {"key": "closed", "name": "Overnight" if m >= 1200 or m < 240 else "Closed", "tip": SESSION_TIP["closed"], **extra}


def first_friday(y, mo):
    d = date(y, mo, 1)
    return d + timedelta(days=(4 - d.weekday()) % 7)


def builtin_events(day):
    out = []
    if str(day) in FOMC:
        out.append({"t": datetime(day.year, day.month, day.day, 14, 0, tzinfo=NY), "title": "Fed rate decision (FOMC)", "impact": "HIGH", "src": "built-in"})
    if day == first_friday(day.year, day.month):
        out.append({"t": datetime(day.year, day.month, day.day, 8, 30, tzinfo=NY), "title": "Jobs report (estimated date)", "impact": "HIGH", "src": "built-in"})
    return out


def _ff_rows(fetch=True):
    with _lock:
        fresh = time.time() - _ff["t"] < 6 * 3600 and (_ff["rows"] or _ff["err"])
        if fresh or not fetch:
            return _ff["rows"], _ff["err"]
    rows, err = [], ""
    try:
        r = requests.get(FF_URL, headers=UA, timeout=8)
        r.raise_for_status()
        for x in r.json():
            if (x.get("country") or "").upper() != "USD":
                continue
            imp = (x.get("impact") or "").upper()
            if imp not in ("HIGH", "MEDIUM"):
                continue
            try:
                t = datetime.fromisoformat(x["date"]).astimezone(NY)
            except Exception:
                continue
            rows.append({"t": t, "title": x.get("title") or "?", "impact": "HIGH" if imp == "HIGH" else "MED", "src": "calendar",
                         "forecast": x.get("forecast") or "", "previous": x.get("previous") or ""})
    except Exception as ex:
        err = f"Economic calendar unreachable ({str(ex)[:60]}); using the built-in Fed / jobs-report dates."
    with _lock:
        _ff.update(t=time.time(), rows=rows, err=err)
    return rows, err


def events_for(day, fetch=True, rows=None):
    if rows is None:
        rows, err = _ff_rows(fetch)
    else:
        err = ""
    got = [r for r in rows if r["t"].date() == day]
    if not rows:                                   # feed not available: the built-in backup
        got = builtin_events(day)
    elif not any("FOMC" in r["title"] or "Federal Funds" in r["title"] for r in got):
        got += [b for b in builtin_events(day) if "FOMC" in b["title"]]
    got.sort(key=lambda r: r["t"])
    return got, err


def macro_block(now, rows=None):
    """'' or why the bot should not open a NEW trade right now (a HIGH-impact release is close)."""
    try:
        if not cfg()["gate"]:
            return ""
        evs, _ = events_for(now.date(), fetch=False, rows=rows)
        for ev in evs:
            if ev["impact"] != "HIGH":
                continue
            dm = (now - ev["t"]).total_seconds() / 60
            if -GATE_BEFORE <= dm <= GATE_AFTER:
                return f"big news: {ev['title']} at {ev['t'].strftime('%-I:%M %p')}"
    except Exception:
        pass
    return ""


def lean(spy_chg, qqq_chg, spy_vwap, qqq_vwap, breadth, vix_chg):
    """0-100. spy/qqq_chg: % vs yesterday's close; *_vwap: % above (+) / below (-) today's VWAP; breadth: share of the
    watchlist that is green (0-1); vix_chg: % change in VIX (up = fear). Each part adds or takes away up to its weight."""
    def clip(x, s):
        return max(-1.0, min(1.0, (x or 0) / s))
    parts = {"SPY vs yesterday": 15 * clip(spy_chg, 1.0), "QQQ vs yesterday": 15 * clip(qqq_chg, 1.2),
             "SPY vs VWAP": 7.5 * clip(spy_vwap, 0.3), "QQQ vs VWAP": 7.5 * clip(qqq_vwap, 0.35),
             "Watchlist breadth": 15 * clip(((breadth if breadth is not None else 0.5) - 0.5) * 2, 1.0),
             "VIX": -10 * clip(vix_chg, 5.0)}
    sc = round(max(0, min(100, 50 + sum(parts.values()))))
    word = "Buyers" if sc >= 60 else "Sellers" if sc <= 40 else "Mixed"
    return sc, word, {k: round(v, 1) for k, v in parts.items()}


def log_reading(now, score, spy):
    try:
        with open(LOG, "a") as f:
            f.write(json.dumps({"t": now.isoformat(), "score": score, "spy": spy}) + "\n")
    except Exception:
        pass


def track_record(lines=None, horizon=30):
    """How often a lean of 60+ (or 40-) was followed by SPY going the same way over the next `horizon` minutes."""
    if lines is None:
        try:
            lines = [json.loads(x) for x in LOG.read_text().splitlines()[-6000:] if x.strip()]
        except Exception:
            lines = []
    rows = []
    for x in lines:
        try:
            rows.append((datetime.fromisoformat(x["t"]), float(x["score"]), float(x["spy"])))
        except Exception:
            continue
    n = right = 0
    j = 0
    for i, (t, s, p) in enumerate(rows):
        if 40 < s < 60 or not p:
            continue
        j = max(j, i + 1)
        while j < len(rows) and (rows[j][0] - t).total_seconds() < horizon * 60:
            j += 1
        if j >= len(rows) or rows[j][0].date() != t.date() or (rows[j][0] - t).total_seconds() > (horizon + 15) * 60:
            continue
        n += 1
        if (rows[j][2] - p) * (1 if s >= 60 else -1) > 0:
            right += 1
    days = len({r[0].date() for r in rows})
    return {"n": n, "right": right, "pct": round(100 * right / n) if n else None, "days": days}
