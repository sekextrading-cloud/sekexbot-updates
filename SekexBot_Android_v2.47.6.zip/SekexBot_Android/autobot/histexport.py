"""v2.37: Chart history for Claude. One zip with the last N days of 5-minute (or 1-minute) candles, pre-market and after-hours
included, for the stocks you pick, plus a per-day summary and your trade journal, so you can attach it in your Claude chat and
Claude can study the patterns that repeat day after day. Never includes keys, PINs, tokens or the account number."""
import csv
import io
import zipfile
from datetime import datetime

import pandas as pd

README = """SekexBot chart history
======================
Made {made} by SekexBot v{ver}. {n} stocks, {days} days of {tf}-minute candles, New York time, all sessions including overnight (8 PM - 4 AM).

Attach this zip in your Claude chat and ask, for example:
  "Find the patterns that happen almost every day on these stocks between 4 AM and 10 AM."

Files
  bars/<SYMBOL>.csv     time, open, high, low, close, volume, session (overnight 8PM-4AM / pre / regular / after)
  daily_summary.csv     one row per stock per day: previous close, pre-market high/low and when, open, regular-hours
                        high/low and when, close, volume by session, and the % moves between them
  journal_trades.csv    your closed trades in the same period (bot and your own), if any
Nothing secret is inside: no API keys, PINs, tokens or account number.
"""


def _sess(m):
    return "pre" if m < 570 else "regular" if m < 960 else "after"


def daily_rows(sym, d):
    """One summary row per day for one stock (d: candles with a New York DatetimeIndex)."""
    out = []
    if d is None or d.empty:
        return out
    m = d.index.hour * 60 + d.index.minute
    d = d.assign(_m=m)
    prev_close = None
    for day, g in d.groupby(d.index.date):
        pre, reg, aft = g[g["_m"] < 570], g[(g["_m"] >= 570) & (g["_m"] < 960)], g[g["_m"] >= 960]
        def hl(x):
            if x.empty:
                return (None, None, None, None)
            return (round(float(x["high"].max()), 4), x["high"].idxmax().strftime("%H:%M"), round(float(x["low"].min()), 4), x["low"].idxmin().strftime("%H:%M"))
        ph, pht, pl, plt_ = hl(pre)
        rh, rht, rl, rlt = hl(reg)
        o = round(float(reg["open"].iloc[0]), 4) if len(reg) else None
        c = round(float(reg["close"].iloc[-1]), 4) if len(reg) else None
        pct = lambda a, b: round((a / b - 1) * 100, 2) if (a and b) else None
        out.append({"symbol": sym, "day": str(day), "weekday": pd.Timestamp(day).day_name()[:3], "prev_close": prev_close,
                    "pre_high": ph, "pre_high_time": pht, "pre_low": pl, "pre_low_time": plt_, "open": o,
                    "gap_pct": pct(o, prev_close), "reg_high": rh, "reg_high_time": rht, "reg_low": rl, "reg_low_time": rlt, "close": c,
                    "day_pct": pct(c, prev_close), "open_to_close_pct": pct(c, o), "pre_range_pct": pct(ph, pl), "reg_range_pct": pct(rh, rl),
                    "vol_pre": int(pre["volume"].sum()), "vol_regular": int(reg["volume"].sum()), "vol_after": int(aft["volume"].sum())})
        if c:
            prev_close = c
    return out


def build(frames, days, tf, version, journal=None):
    """frames: {symbol: DataFrame of candles}. Returns (zip bytes, stats)."""
    buf = io.BytesIO()
    rows_total, summary = 0, []
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for sym, d in sorted(frames.items()):
            if d is None or d.empty:
                continue
            d = d.sort_index()
            mm = d.index.hour * 60 + d.index.minute          # v2.47.5: keep the overnight session too (8 PM - 4 AM), so the 3 AM London open is in the file
            out = pd.DataFrame({"time": d.index.strftime("%Y-%m-%d %H:%M"), "open": d["open"].round(4).values, "high": d["high"].round(4).values,
                                "low": d["low"].round(4).values, "close": d["close"].round(4).values, "volume": d["volume"].astype("int64").values,
                                "session": ["overnight" if (x < 240 or x >= 1200) else "pre" if x < 570 else "regular" if x < 960 else "after" for x in mm]})
            s = io.StringIO()
            out.to_csv(s, index=False)
            z.writestr(f"bars/{sym}.csv", s.getvalue())
            rows_total += len(d)
            summary += daily_rows(sym, d)
        if summary:
            s = io.StringIO()
            w = csv.DictWriter(s, fieldnames=list(summary[0].keys()))
            w.writeheader()
            w.writerows(summary)
            z.writestr("daily_summary.csv", s.getvalue())
        if journal:
            cols = ["day", "mode", "symbol", "side", "strategy", "bucket", "qty", "entry", "stop", "target", "opened_at", "closed_at", "exit", "pnl", "r", "status", "note"]
            s = io.StringIO()
            w = csv.DictWriter(s, fieldnames=cols, extrasaction="ignore")
            w.writeheader()
            w.writerows(journal)
            z.writestr("journal_trades.csv", s.getvalue())
        z.writestr("README.txt", README.format(made=datetime.now().strftime("%Y-%m-%d %H:%M"), ver=version, n=len(frames), days=days, tf=tf))
    return buf.getvalue(), {"stocks": len([1 for d in frames.values() if d is not None and not d.empty]), "candles": rows_total, "days": days}
