"""v2.48: Scalp one stock - you pick the stock, the bot takes quick trades both ways, one at a time. PAPER ONLY until the scoreboard earns LIVE.

The idea (1-minute candles, regular hours 9:45 - 3:45):
  * BUY a break up: a 1-min candle closes above the highest high of the previous 5 candles AND above VWAP.  SHORT the mirror.
  * Take profit at tp_pct (default 0.15%), stop at sl_pct (default 0.10%), out after 3 minutes with no progress, 10 minutes at the most.
  * AUTO-SWITCH: if a candle closes back through the break line AND the next candle confirms the other way (closes lower than the failed
    one), it closes the trade and flips to the other side by itself.  Max 3 switches per 10 minutes (each switch pays the spread twice).
  * Guards: skip when the spread is over a quarter of the target, 3 losses in a row = 10-minute breather, stop for the day at a set loss.

HONEST WARNING: every scalp variant tested on your 5-minute history (May 12 - Oct 30 2026) lost after costs, and 5-minute data cannot
test second-by-second scalping.  So this is a PAPER experiment with a live scoreboard (net AFTER spreads).  LIVE stays locked until it has
100+ trades over 14+ days AND the net is positive, and then still needs the PIN arming."""
import json
import re
import threading
from datetime import datetime

from .config import DATA_DIR

FILE = DATA_DIR / "scalp.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": False, "live": False, "symbol": "", "dir": "both", "tp_pct": 0.15, "sl_pct": 0.10, "size": 10000, "skip_wide": True,
               "day_stop": 200, "cooldown": True, "switch": True}
OK = {"dir": ("both", "up", "down"), "tp_pct": (0.10, 0.15, 0.25), "sl_pct": (0.07, 0.10, 0.15), "size": (5000, 10000, 25000),
      "day_stop": (100, 200, 400)}
BOOLS = ("on", "live", "skip_wide", "cooldown", "switch")
WIN_FROM, WIN_TO = 585, 945          # entries 9:45 AM - 3:45 PM; everything is closed at 3:45
LOOKBACK = 5                         # the break line = the high / low of the previous 5 one-minute candles
NO_PROGRESS_S, MAX_HOLD_S = 180, 600
SWITCH_MAX, SWITCH_WINDOW_S = 3, 600
NEED_TRADES, NEED_DAYS = 100, 14
LEDGER_CAP = 3000
SYM_RE = re.compile(r"^[A-Z][A-Z.]{0,7}$")


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "trades": [], "log": [], "history": [], "done": "", "cool_until": "", "streak": 0,
            "switches": [], "bar": "", "pending": None, "ledger": [], "hold_bar": ""}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    for k in BOOLS:
        c[k] = bool(c.get(k))
    c["symbol"] = c["symbol"] if SYM_RE.match(str(c.get("symbol") or "")) else ""
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in BOOLS:
            d["cfg"][k] = bool(v)
        elif k == "symbol":
            s = str(v).upper().strip()
            if SYM_RE.match(s):
                d["cfg"]["symbol"] = s
        elif k in OK:
            if isinstance(OK[k][0], float):
                v = float(v)
            elif isinstance(OK[k][0], int):
                v = int(v)
            if v in OK[k]:
                d["cfg"][k] = v
    save(d)
    return load()


def new_day(d, today):
    if d.get("day") != str(today):
        done = [t for t in d.get("trades", []) if t.get("entry")]
        if done:
            d["history"] = ([{"day": d["day"], "pnl": round(day_pnl(d), 2), "n": len(done)}] + d.get("history", []))[:30]
        d.update(day=str(today), trades=[], log=[], done="", cool_until="", streak=0, switches=[], bar="", pending=None, hold_bar="")
    return d


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%-I:%M %p"), "msg": msg})
    del d["log"][80:]


def hm(now):
    return now.hour * 60 + now.minute


def signal(df):
    """df: today's CLOSED 1-min candles (open, high, low, close, volume), newest last. Returns the reading for the newest candle."""
    if df is None or len(df) < LOOKBACK + 2:
        return None
    r = df[(df.index.hour * 60 + df.index.minute) >= 570]
    if len(r) < LOOKBACK + 2:
        return None
    last, prior = r.iloc[-1], r.iloc[-1 - LOOKBACK:-1]
    vol = r["volume"].astype(float)
    typ = (r["high"] + r["low"] + r["close"]) / 3
    vwap = float((typ * vol).sum() / vol.sum()) if float(vol.sum()) > 0 else float(r["close"].mean())
    hi, lo, cl = float(prior["high"].max()), float(prior["low"].min()), float(last["close"])
    up = cl > hi and cl > vwap
    dn = cl < lo and cl < vwap
    text = (f"last 1-min candle {'up' if cl >= float(last['open']) else 'down'}, {'above' if cl >= vwap else 'below'} VWAP "
            f"${vwap:.2f}; waiting for a close over ${hi:.2f} (buy) or under ${lo:.2f} (short)")
    return {"ts": r.index[-1], "close": cl, "hi": hi, "lo": lo, "vwap": round(vwap, 4), "long": up, "short": dn,
            "side": "long" if up else "short" if dn else "", "line": hi if up else lo if dn else None, "text": text}


def allowed(cfg, side):
    return cfg["dir"] == "both" or (cfg["dir"] == "up") == (side == "long")


def levels(cfg, side, entry):
    d_ = 1 if side == "long" else -1
    return round(entry * (1 + d_ * cfg["tp_pct"] / 100), 2), round(entry * (1 - d_ * cfg["sl_pct"] / 100), 2)


def size(cfg, px, bp):
    """Shares: size dollars, never more than 30% of buying power."""
    if not px or px <= 0:
        return 0
    return max(0, int(min(float(cfg["size"]), 0.3 * float(bp or 0)) // px))


def spread_ok(cfg, bid, ask):
    """The spread must be under a quarter of the take-profit distance, or it eats the profit."""
    if not (bid and ask) or ask <= 0 or ask < bid:
        return False, "no good quote"
    pct = (ask - bid) / ask * 100
    if cfg["skip_wide"] and pct > 0.25 * cfg["tp_pct"]:
        return False, f"spread {pct:.2f}% (over a quarter of the {cfg['tp_pct']:g}% target)"
    if pct > 0.5:
        return False, f"spread {pct:.2f}%"
    return True, ""


def switches_left(d, now):
    recent = [s for s in d.get("switches", []) if (now - datetime.fromisoformat(s)).total_seconds() <= SWITCH_WINDOW_S]
    return SWITCH_MAX - len(recent)


def manage(t, bar, bid, ask, now, cfg, switch_ok=True):
    """('', '') hold, ('exit', why) get out, ('switch', why) get out and flip.  t: an open scalp trade.  bar: {'ts', 'close'} of the newest CLOSED 1-min candle (or None)."""
    if t.get("state") != "open":
        return "", ""
    d_ = 1 if t["side"] == "long" else -1
    mark = bid if d_ > 0 else ask
    if hm(now) >= WIN_TO:
        return "exit", "3:45 close-out"
    if mark and t.get("target") and (mark - t["target"]) * d_ >= 0:
        return "exit", f"target ${t['target']:.2f}"
    if mark and t.get("stop") and (mark - t["stop"]) * d_ <= 0:
        return "exit", f"stop ${t['stop']:.2f}"
    filled = datetime.fromisoformat(t["filled_at"])
    if bar is not None and str(bar["ts"]) > str(t.get("last_bar") or "") and bar["ts"] >= filled.replace(second=0, microsecond=0):
        t["last_bar"] = str(bar["ts"])
        c = float(bar["close"])
        if (c - t["line"]) * d_ < 0:                                  # closed back through the break line
            if not (cfg["switch"] and switch_ok):
                return "exit", f"1-min close back through ${t['line']:.2f}"
            f = t.get("fail")
            if f and (c - float(f["close"])) * d_ < 0:
                return "switch", f"break failed: two closes through ${t['line']:.2f}, the second lower"
            t["fail"] = {"ts": str(bar["ts"]), "close": c}
        else:
            t["fail"] = None
    held = (now - filled).total_seconds()
    if held >= MAX_HOLD_S:
        return "exit", "10 minutes is the longest it holds"
    if held >= NO_PROGRESS_S and mark and t.get("entry") and t.get("target"):
        if (mark - t["entry"]) * d_ < 0.25 * abs(t["target"] - t["entry"]):
            return "exit", "no progress in 3 minutes"
    return "", ""


def day_pnl(d, marks=None):
    tot = 0.0
    for t in d.get("trades", []):
        tot += float(t.get("realized") or 0)
        if t.get("state") == "open" and marks and marks.get(t["symbol"]) and t.get("qty_open") and t.get("entry"):
            d_ = 1 if t["side"] == "long" else -1
            tot += (marks[t["symbol"]] - float(t["entry"])) * d_ * t["qty_open"]
    return tot


def record(d, t, now):
    """A closed trade goes on the permanent ledger (the scoreboard reads it)."""
    row = {"day": str(now.date()), "t": now.isoformat(), "sym": t["symbol"], "side": t["side"], "pnl": round(float(t.get("realized") or 0), 2),
           "spread": round(float(t.get("spread") or 0), 2), "mode": t.get("mode", "PAPER"), "why": t.get("last_why", ""), "how": t.get("how", "break")}
    d.setdefault("ledger", []).append(row)
    del d["ledger"][:-LEDGER_CAP]
    if row["pnl"] < 0:
        d["streak"] = int(d.get("streak") or 0) + 1
    else:
        d["streak"] = 0
    return row


def board(d, today=None):
    """The honest scoreboard: PAPER trades only, net after spreads."""
    rows = [r for r in d.get("ledger", []) if r.get("mode", "PAPER") != "LIVE"]
    n = len(rows)
    wins = [r["pnl"] for r in rows if r["pnl"] > 0]
    loss = [r["pnl"] for r in rows if r["pnl"] <= 0]
    net = round(sum(r["pnl"] for r in rows), 2)
    days = 0
    if rows and today is not None:
        try:
            days = (today - datetime.fromisoformat(rows[0]["day"]).date()).days + 1
        except Exception:
            days = 0
    ready = n >= NEED_TRADES and days >= NEED_DAYS
    verdict = ("working" if net > 0 else "not working") if ready else "collecting"
    return {"n": n, "net": net, "win": round(100 * len(wins) / n) if n else None, "avg_win": round(sum(wins) / len(wins), 2) if wins else 0.0,
            "avg_loss": round(sum(loss) / len(loss), 2) if loss else 0.0, "spread": round(sum(r.get("spread", 0) for r in rows), 2),
            "days": days, "need_n": NEED_TRADES, "need_days": NEED_DAYS, "ready": ready, "verdict": verdict,
            "unlocked": bool(ready and net > 0)}
