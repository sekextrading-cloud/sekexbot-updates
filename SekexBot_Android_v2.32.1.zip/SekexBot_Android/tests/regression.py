"""SekexBot regression suite. Run:  python3 tests/regression.py   (uses a throw-away data folder; never touches your data)

Covers: version consistency, settings migrations (daily loss limit must survive), risk manager, sessions, night mode,
morning-wave setups, wave trader, options limits and greeks, simulator journal audits, and every API endpoint."""
import json, os, re, subprocess, sys, tempfile, time, traceback
from datetime import date, datetime, time as dtime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="sekex_reg_")
os.environ["AUTOBOT_DATA"] = TMP
NY = ZoneInfo("America/New_York")
RESULTS = []


def test(name):
    def deco(fn):
        t0 = time.time()
        try:
            fn()
            RESULTS.append((name, "PASS", "", time.time() - t0))
        except AssertionError as e:
            RESULTS.append((name, "FAIL", str(e) or " | ".join(l.strip() for l in traceback.format_exc().splitlines()[-4:-1]), time.time() - t0))
        except Exception as e:
            RESULTS.append((name, "ERROR", f"{type(e).__name__}: {e}\n" + "".join(traceback.format_exc().splitlines(True)[-4:]), time.time() - t0))
        return fn
    return deco


# ---------------------------------------------------------------- static
@test("static: every python file compiles")
def _():
    r = subprocess.run([sys.executable, "-m", "compileall", "-q", str(ROOT / "autobot"), str(ROOT / "server.py"), str(ROOT / "bin")], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


@test("static: dashboard JavaScript parses")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    for i, m in enumerate(re.findall(r"<script>(.*?)</script>", html, re.S)):
        p = Path(TMP) / f"s{i}.js"
        p.write_text(m)
        r = subprocess.run(["node", "--check", str(p)], capture_output=True, text=True)
        assert r.returncode == 0, r.stderr[:300]


@test("static: shell scripts parse")
def _():
    for f in ("bin/sekex", "install.sh"):
        r = subprocess.run(["bash", "-n", str(ROOT / f)], capture_output=True, text=True)
        assert r.returncode == 0, f + ": " + r.stderr


@test("static: dashboard ids used by the code exist in the page")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    have = set(re.findall(r'id="([^"]+)"', html))
    used = set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)", html))
    dyn = {x for x in used if x not in have}
    # ids created by script (innerHTML) are fine: accept those that appear in a template string
    missing = sorted(x for x in dyn if f'id="{x}"' not in html and f"id=\\\"{x}\\\"" not in html and f"id='{x}'" not in html)
    assert len(missing) <= 3, "ids used in code but not in the page: " + ", ".join(missing[:15])


@test("static: version is the same everywhere")
def _():
    from autobot.version import __version__ as v
    assert (ROOT / "VERSION").read_text().strip() == v, "VERSION file differs from version.py"
    assert re.search(rf"^## {re.escape(v)} ", (ROOT / "CHANGELOG.md").read_text(), re.M), "CHANGELOG has no entry for " + v
    assert v in (ROOT / "README_ANDROID.md").read_text().splitlines()[0], "README_ANDROID header is not v" + v


# ---------------------------------------------------------------- settings
@test("settings: migrations never change the user's daily loss limit")
def _():
    from autobot import config
    d = Path(TMP) / "mig"
    d.mkdir()
    config.SETTINGS_FILE = d / "settings.json"
    config.OPTIONS_FILE = d / "options_settings.json"
    config.SETTINGS_FILE.write_text(json.dumps({"daily_max_loss": 137.5, "max_position_pct_equity": 0.25}))
    s = config.Settings.load()
    assert s.daily_max_loss == 137.5, f"daily limit changed to {s.daily_max_loss}"
    assert s.v130_defaults and s.v155_defaults is not None and s.v159_defaults and s.v163_defaults and s.v165_defaults, "legacy migration flags missing"
    assert abs(s.max_position_pct_equity - 0.15) < 1e-9
    s2 = config.Settings.load()
    assert s2.daily_max_loss == 137.5
    s2.daily_max_loss = 99.0
    s2.wave_trade = True
    s2.options_max_stocks = 3
    s2.save()
    s3 = config.Settings.load()
    assert s3.daily_max_loss == 99.0 and s3.wave_trade is True and s3.options_max_stocks == 3, "round trip failed"


@test("settings: risky features are OFF by default")
def _():
    from autobot.config import Settings
    s = Settings()
    assert s.wave_trade is False and s.options_on is False and s.options_live_unlocked is False
    assert s.night_dir == "buy"


# ---------------------------------------------------------------- risk
def _rm(**kw):
    from autobot.config import Settings
    from autobot.risk import RiskManager
    s = Settings()
    s.daily_max_loss = kw.pop("limit", 200.0)
    for k, v in kw.items():
        setattr(s, k, v)
    r = RiskManager(s)
    r.equity = 25000.0
    return s, r


@test("risk: halts at the daily loss limit and sizes to zero afterwards")
def _():
    s, r = _rm()
    assert r.update(25000 - 100, 25000) is False
    assert r.update(25000 - 200.01, 25000) is True and r.halted
    assert r.size(100, 99, 1.0, 0, 50000).qty == 0
    r.new_day()
    assert not r.halted


@test("risk: profit lock after giving back half of a limit-sized gain")
def _():
    s, r = _rm()
    assert r.update(25000 + 220, 25000) is False
    assert r.update(25000 + 100, 25000) is True and "Profit lock" in r.halt_reason


@test("risk: trade risk never exceeds the budget; caps always win")
def _():
    s, r = _rm(limit=200.0)
    r.update(25000 - 50, 25000)                      # $150 left
    d = r.size(100.0, 99.0, 1.0, 0.0, 50000.0)
    assert d.risk_dollars <= 0.5 * r.remaining + 1e-9, d
    d2 = r.size(100.0, 99.0, 1.0, 140.0, 50000.0)    # open risk already uses most of what is left
    assert d2.risk_dollars <= (r.remaining - 140.0) + 1e-9, d2
    s.max_trade_notional = 1000.0
    d3 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d3.qty * 100.0 <= 1000.0 + 1e-6, f"notional cap broken: {d3.qty} sh"
    s.max_trade_notional = 0.0
    s.max_position_pct_equity = 0.05
    d4 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d4.qty * 100.0 <= 25000.0 * 0.05 + 1e-6, "equity % cap broken"
    d5 = r.size(100.0, 99.99, 1.0, 0.0, 1000.0)      # buying power tiny
    assert d5.qty * 100.0 <= 1000.0 + 1e-6, "buying power cap broken"
    assert r.size(100.0, 100.0, 1.0, 0.0, 50000.0).qty == 0, "zero-risk stop must size to 0"


# ---------------------------------------------------------------- sessions
def _trading_day(d):
    return None if d.weekday() >= 5 else (datetime.combine(d, dtime(9, 30), NY), datetime.combine(d, dtime(16, 0), NY))


@test("sessions: boundaries, weekend gap, and the 8 PM bot day")
def _():
    from autobot.sessions import bot_day, current_session
    def at(y, m, d, h, mi):
        return datetime(y, m, d, h, mi, tzinfo=NY)
    cases = [((2026, 10, 6, 3, 59), "OVERNIGHT"), ((2026, 10, 6, 4, 0), "PRE"), ((2026, 10, 6, 9, 29), "PRE"), ((2026, 10, 6, 9, 30), "REGULAR"),
             ((2026, 10, 6, 15, 59), "REGULAR"), ((2026, 10, 6, 16, 0), "AFTER"), ((2026, 10, 6, 19, 59), "AFTER"), ((2026, 10, 6, 20, 0), "OVERNIGHT"),
             ((2026, 10, 9, 20, 30), None), ((2026, 10, 10, 12, 0), None), ((2026, 10, 11, 20, 0), "OVERNIGHT")]
    for (y, m, d, h, mi), want in cases:
        s = current_session(_trading_day, at(y, m, d, h, mi))
        got = s.name if s else None
        assert got == want, f"{y}-{m}-{d} {h}:{mi:02d} expected {want}, got {got}"
    assert bot_day(at(2026, 10, 6, 19, 59)) != bot_day(at(2026, 10, 6, 20, 0)), "daily window must roll at 8 PM ET"


# ---------------------------------------------------------------- engine pieces
def _engine(**kw):
    from autobot.config import Settings
    from autobot.engine import Engine
    from autobot.learner import Learner
    from autobot.sim import SimBroker
    s = Settings()
    s.daily_max_loss, s.tick_seconds = 200, 60
    for k, v in kw.items():
        setattr(s, k, v)
    b = SimBroker(datetime(2026, 9, 14, 9, 0, tzinfo=NY), equity=25000, seed=3)
    e = Engine(s, b, Learner())
    e.running = True
    return e


@test("night mode: window, direction and shorts gate")
def _():
    e = _engine(night_short=True, night_dir="buy")
    n = lambda h, m: datetime(2026, 9, 14, h, m, tzinfo=NY)
    assert e.night_window(n(20, 0)) and e.night_window(n(6, 59)) and not e.night_window(n(7, 0)) and not e.night_window(n(19, 59))
    assert e.night_dir() == "buy" and e.shorts_allowed(n(22, 0)) is False, "night buys mode must not allow shorts"
    e.s.night_dir = "sell"
    assert e.night_dir() == "sell" and e.shorts_allowed(n(22, 0)) is True
    e.s.night_short = False
    assert not e.night_window(n(22, 0))


def _wave_rows(eng):
    def fake(now, mode="PRE"):
        out = []
        for sy in list(eng.broker.day_bars)[:4]:
            px = eng.broker._px(sy)
            out.append({"symbol": sy, "side": "up", "kind": "CLOSE_HIGH", "name": "CLOSE HIGH CONTINUATION", "score": 80 if sy != list(eng.broker.day_bars)[3] else 60,
                        "label": "STRONG", "hit_rate": 80, "n": 12, "zone": [round(px * 0.995, 2), round(px * 1.005, 2)],
                        "stop": round(px * 0.985, 2), "tp1": round(px * 1.012, 2), "tp2": round(px * 1.02, 2), "atr": px * 0.02})
        return out
    return fake


@test("wave trader: off by default, honours window, min score, max trades, zone, and halts")
def _():
    from autobot import db
    e = _engine(wave_min_score=70, wave_from=570, wave_until=700, wave_max_trades=2, wave_trade=False)
    e._wave_rows = _wave_rows(e)
    seen = []
    orig_bracket, orig_ext = e.broker.submit_bracket, e.broker.submit_limit_ext
    e.broker.submit_bracket = lambda *a, **k: (seen.append(("REG", a, e.broker.now())), orig_bracket(*a, **k))[1]
    e.broker.submit_limit_ext = lambda *a, **k: (seen.append(("EXT", a, e.broker.now())), orig_ext(*a, **k))[1]
    def run_until(h, m):
        guard = 0
        while (e.broker.now().hour, e.broker.now().minute) < (h, m) and guard < 4000:
            w = e.tick()
            e.broker.sleep(w or 60)
            guard += 1
    # 1) switch OFF -> nothing from the wave trader
    run_until(10, 0)
    wave_trades = [t for t in e.trades.values() if t.strategy == "WAVE"]
    assert not wave_trades and not getattr(e, "wave_done", None), "wave trader traded while switched OFF"
    # 2) ON, inside the window
    e.s.wave_trade = True
    run_until(10, 30)
    done = getattr(e, "wave_done", set())
    assert 1 <= len(done) <= 2, f"expected 1-2 wave entries, got {len(done)}"
    assert all(s in [x["symbol"] for x in e._wave_rows(None) if x["score"] >= 70] for s in done), "entered a setup under the min score"
    for kind, a, t in seen:
        if a[0] in done:
            assert 570 <= t.hour * 60 + t.minute < 700, "wave order outside its window"
    rows = [r for r in db.recent(500) if r["strategy"] == "WAVE"]
    for r in rows:
        assert r["stop"] < r["entry"] < r["target"], f"bad levels {r}"
        assert r["risk"] <= 0.15 * 200 * 0.5 * 1.05 + 1e-6, f"risk {r['risk']} over budget"
    # 3) halted risk -> no entries
    e2 = _engine(wave_trade=True, wave_min_score=70, wave_from=570, wave_until=700)
    e2._wave_rows = _wave_rows(e2)
    first = True
    for _ in range(400):
        w = e2.tick(); e2.broker.sleep(w or 60)
        if first:   # the first tick runs the new-day reset, which clears any halt; halt after it
            first = False
            e2.risk.halted, e2.risk.halt_reason = True, "test halt"
            e2.wave_done = set()
        if e2.broker.now().hour >= 10:
            break
    assert not getattr(e2, "wave_done", None), "wave trader traded while the daily loss limit had halted trading"


# ---------------------------------------------------------------- morning wave setups
@test("morning wave: pattern that always follows through is listed; one that never does is not")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    def build(follow):
        rows, px = [], 100.0
        days = pd.bdate_range("2026-08-20", "2026-10-05")
        prev_strong = False
        for i, day in enumerate(days):
            idx = pd.date_range(f"{day.date()} 04:00", f"{day.date()} 19:45", freq="15min", tz=NY)
            strong = (i % 2 == 0)
            for t in idx:
                reg = dtime(9, 30) <= t.time() < dtime(16, 0)
                o = px
                if reg:
                    frac = (t.hour * 60 + t.minute - 570) / 390
                    px = px * (1 + (0.0006 if strong else -0.0006) * (1 if frac < 0.9 else 1))
                else:
                    if prev_strong and follow and t.time() >= dtime(9, 0):
                        px = px * 1.0012                          # next morning pushes up
                    else:
                        px = px * (1 + 0.00001)
                rows.append((t, o, max(o, px) * 1.0003, min(o, px) * 0.9997, px, 1000))
            prev_strong = strong
        return pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
    yes = mw.analyze("AAA", build(True))
    no = mw.analyze("BBB", build(False))
    if yes:
        assert yes["side"] == "up" and yes["stop"] < yes["zone"][0] <= yes["zone"][1] < yes["tp1"] < yes["tp2"], yes
        assert 0 <= yes["score"] <= 100 and 0 <= yes["hit_rate"] <= 100
    assert no is None or no["hit_rate"] < 100, "a pattern with no follow-through must not show a perfect hit rate"
    rise, fall = mw.build({"AAA": build(True), "BBB": build(False)})
    assert isinstance(rise, list) and isinstance(fall, list)


# ---------------------------------------------------------------- options
@test("options: build_plan sizing never breaks the premium, budget or contract limits")
def _():
    from autobot import options as O
    today = date(2026, 10, 6)
    exp = today + timedelta(days=9)
    ch = [{"symbol": f"C{k}", "strike": float(k), "expiry": exp, "oi": 800} for k in range(95, 106)]
    quotes = {c["symbol"]: (max(0.05, 100 - c["strike"] + 3.0), max(0.05, 100 - c["strike"] + 3.1)) for c in ch}
    for style in ("spread", "long"):
        cfg = {"min_dte": 5, "min_oi": 100, "style": style, "max_premium": 200.0, "max_contracts": 3, "stop_pct": 40.0, "tp_pct": 50.0, "room": 150.0,
               "flatten_min": 900, "hold_overnight": False}
        plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
        if plan:
            assert plan["qty"] >= 1 and plan["qty"] <= 3
            assert plan["cost"] <= 200.0 + 1e-6, plan
            assert plan["risk_at_stop"] <= 150.0 + 1e-6, plan
    cfg["max_premium"] = 1.0
    plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
    assert plan is None, "an option costing more than the per-trade limit must not be planned"


@test("options: stock, per-stock, call and put limits plus greeks")
def _():
    import pandas as pd
    from types import SimpleNamespace as NS
    from autobot.config import Settings
    from autobot import options as O
    s = Settings(); s.options_on = True
    b = O.OptionsBot(lambda: None, s)
    b._account_level = lambda e: 3
    b._room = lambda e: 300
    opened = []
    b._open = lambda e, u, d, why, px, room, reg: (opened.append((u, d)) or True)
    O.signal = lambda *a, **k: ("call", "t")
    bars = {u: pd.DataFrame({"close": [100.0]}) for u in s.options_underlyings}
    e = NS(mode="PAPER", bars_last=bars, regime={}, bias=0, ribbons={})
    now = datetime(2026, 10, 6, 10, 30)
    def run(rows, **kw):
        for k, v in kw.items():
            setattr(s, k, v)
        b.pos = {f"p{i}": {"status": "open", "underlying": u, "direction": d} for i, (u, d) in enumerate(rows)}
        opened.clear(); b.confirm = {}; b.cool = {}
        for _ in range(2):
            b._entries(e, now)
        return list(opened)
    assert run([]), "nothing open: it should open a trade"
    assert run([("SPY", "call")], options_max_stocks=1, options_max_positions=4) == [], "max stocks ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=1) == [], "max calls ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=6, options_max_per_stock=2), "per-stock 2 should allow a second SPY trade"
    assert run([("SPY", "call"), ("QQQ", "put")], options_max_stocks=2, options_max_positions=2, options_max_per_stock=1) == [], "total cap ignored"
    b.greeks = {"L": {"delta": .55, "gamma": .04, "theta": -.12, "vega": .2, "rho": .01, "iv": .4}, "S": {"delta": .4, "gamma": .03, "theta": -.09, "vega": .15, "rho": .01, "iv": .38}}
    g = b.net_greeks("L", "S")
    assert abs(g["delta"] - .15) < 1e-9 and abs(g["theta"] + .03) < 1e-9 and b.net_greeks("L", "X") is None
    pg = b._pos_greeks({"qty": 2, "greeks": g})
    assert abs(pg["pos_delta"] - 30) < 1e-6 and abs(pg["pos_theta"] + 6) < 1e-6


# ---------------------------------------------------------------- API
@test("API: every GET endpoint answers (no 500s) and POSTs keep the daily limit")
def _():
    import socket, urllib.request, urllib.error
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    d = Path(TMP) / "api"; d.mkdir()
    env = dict(os.environ, AUTOBOT_DATA=str(d))
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--host", "127.0.0.1", "--sim", "--speed", "60"],
                         cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/version", timeout=2).read(); break
            except Exception:
                time.sleep(1)
        else:
            raise AssertionError("server did not start: " + (p.stderr.read(600).decode() if p.poll() is not None else "timeout"))
        def get(path):
            try:
                return urllib.request.urlopen(base + path, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        def post(path, body):
            req = urllib.request.Request(base + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
            try:
                return urllib.request.urlopen(req, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        post("/api/start", {})
        time.sleep(3)
        spec = json.loads(urllib.request.urlopen(base + "/openapi.json").read())
        bad = []
        skip = ("/docs", "/openapi", "/redoc", ".csv", "export", "download", "backup", "/api/app/update", "/logs/stream")
        n = 0
        for path, ops in spec["paths"].items():
            if "get" in ops and "{" not in path and not any(x in path for x in skip):
                st = get(path); n += 1
                if st >= 500:
                    bad.append(f"{path} -> {st}")
        assert not bad, "GET endpoints failing: " + "; ".join(bad)
        before = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        for path, body in (("/api/wave", {"on": True, "min_score": 75}), ("/api/wave", {"on": False}), ("/api/night", {"on": True, "dir": "buy"}),
                           ("/api/options/config", {"max_stocks": 3, "max_calls": 2, "max_puts": 2, "max_per_stock": 2, "min_delta": 0.3}),
                           ("/api/options/config", {"max_stocks": 0, "min_delta": 5})):
            st = post(path, body)
            assert st < 500, f"POST {path} -> {st}"
        wv = json.loads(urllib.request.urlopen(base + "/api/wave").read())
        assert wv["on"] is False and wv["min_score"] == 75
        opt = json.loads(urllib.request.urlopen(base + "/api/options/status").read())
        assert opt["on"] is False, "options must stay off unless switched on"
        after = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        assert before == after, f"daily loss limit changed {before} -> {after}"
        mw = json.loads(urllib.request.urlopen(base + "/api/morningwave?force=1").read())
        assert "rise" in mw and "fall" in mw
        for r in mw["rise"]:
            assert r["stop"] < r["zone"][0] and r["tp1"] > r["zone"][1], r
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:
            p.kill()



# ---------------------------------------------------------------- scalping + harvest
def _mk_trade(profile="SCALP", entry=100.0, stop=99.0, side="buy", **kw):
    from autobot.engine import Trade
    t = Trade("t1", "ZZZ", side, "EMA_PULLBACK", profile, "AM", 10, entry, stop, stop, entry + 2, 0.5, 10.0,
              datetime(2026, 9, 14, 10, 0, tzinfo=NY), "o1", status="open", **kw)
    return t


@test("scalping: quick-harvest banks a stalled green trade, not a red or fresh one; only for scalp profiles")
def _():
    e = _engine(let_run=False, scale_out=False, scalp_mode=True)
    assert e._harvest_profile("QUICK") == "SCALP"
    e.s.scalp_mode = False
    assert e._harvest_profile("QUICK") == "QUICK"
    e.s.let_run = e.s.scale_out = True
    assert e._harvest_profile("QUICK") == "SCALE", "let-winners-run must disable scalp profiles"
    e.s.let_run = False
    t = _mk_trade("SCALP")
    assert e._quick_harvest(t, 0.5) is False, "must not bank on the first green check"
    assert e._quick_harvest(t, 0.5) is True or e._quick_harvest(t, 0.5) is False
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.7)
    assert e._quick_harvest(t, 0.7) is False, "still rising: let it run"
    assert e._quick_harvest(t, 0.5) is False or t.pos_ticks >= 0
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.8)
    assert e._quick_harvest(t, 0.6) is True, "gave back 0.2R from the best after 2 green checks: bank it"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.3); e._quick_harvest(t, 0.3)
    assert e._quick_harvest(t, -0.2) is False, "a red trade is never 'harvested'"
    t = _mk_trade("SCALE"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 0.5) is False, "non-scalp profiles are untouched"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.5); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 1.1) is True, "near the 1.2R scalp target: take it"


@test("scalping: give-back lock never hands back more than the allowed share of the best gain")
def _():
    e = _engine()
    t = _mk_trade("SCALE", entry=100, stop=99)            # 1R = $1
    lvl, ex = e._gain_lock(t, 0.4)
    assert lvl is None and not ex, "no lock below +0.6R"
    lvl, ex = e._gain_lock(t, 1.0)
    assert abs(lvl - 100.4) < 1e-9 and not ex, f"lock at 40% of 1.0R expected, got {lvl}"
    lvl, ex = e._gain_lock(t, 0.39)
    assert ex, "falling through the lock must exit"
    lvl, ex = e._gain_lock(t, 2.5)
    assert abs(lvl - 100 - 0.6 * 2.5) < 1e-9, "60% lock from 2R"
    s = _mk_trade("SCALE", entry=100, stop=101, side="sell")      # short: lock is below entry
    lvl, ex = e._gain_lock(s, 1.0) if s.dir < 0 else (None, False)
    assert lvl is None or lvl < 100, "short lock must sit below entry"


@test("harvest (halt): winners kept with a ratcheting profit lock that never goes below break-even or backwards")
def _():
    e = _engine()
    e.profit_locks = {}
    e.broker.update_stop = lambda *a, **k: None
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 104.0})
    lk1 = e.profit_locks["ZZZ"]
    assert abs(lk1 - (100 + 2 + 0.1)) < 1e-9, lk1
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 102.0})
    assert e.profit_locks["ZZZ"] == lk1, "lock must not move back down"
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 110.0})
    assert e.profit_locks["ZZZ"] > lk1
    e._lock_update("YYY", {"qty": 10, "avg_entry": 100.0, "price": 99.0})
    assert "YYY" not in e.profit_locks, "a loser gets no lock"
    e._lock_update("SSS", {"qty": -10, "avg_entry": 50.0, "price": 48.0})
    assert e.profit_locks["SSS"] < 50.0, "short lock sits below entry"


def _fake_harvest(price=100.0, spread=0.02, A=0.5, held=10, halted=False):
    import time as _t
    from types import SimpleNamespace as NS
    from autobot.harvester import Harvester
    calls = []
    state = {"bid": price - spread / 2, "ask": price + spread / 2, "held": held}
    broker = NS(positions=lambda: ({"ZZZ": {"qty": state["held"], "avg_entry": 100.0, "price": state["bid"]}} if state["held"] else {}),
                cancel_symbol_orders=lambda s: None)
    e = NS(risk=NS(halted=halted), trades={}, broker=broker)
    h = Harvester.__new__(Harvester)
    import threading
    h.get_engine = lambda: e; h.quote_fn = lambda e_, s, sess: (state["bid"], state["ask"]); h.session_fn = lambda e_: "REGULAR"
    h.open_fn = lambda *a: calls.append(("open",) + a[1:3])
    h.close_fn = lambda *a: calls.append(("close",) + a[1:4])
    h.path = Path("/tmp/reg_harvest_test.json"); h.jobs = {}; h.lock = threading.RLock(); h._bars = {}
    h._save = lambda: None
    h._say = lambda *a, **k: None
    h._bars["ZZZ"] = (_t.time() + 1e6, A, None, [100.0, 100.1])       # fixed A, bounce candle up
    return h, e, state, calls


@test("harvest: sells at +0.5 A, never for less than the spread, stalls bank, then re-enters on a pullback")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10)
    j = h.jobs["ZZZ"]; pos = e.broker.positions(); now = _t.time()
    h.step(e, j, pos, "REGULAR", now); assert j["phase"] == "holding"
    st["bid"], st["ask"] = 100.10, 100.12                       # +0.2 A: not yet
    h.step(e, j, e.broker.positions(), "REGULAR", now + 5); assert not calls
    st["bid"], st["ask"] = 100.30, 100.32                       # +0.6 A: harvest
    h.step(e, j, e.broker.positions(), "REGULAR", now + 10)
    assert calls and calls[0][0] == "close" and j["phase"] == "exiting", calls
    st["held"] = 0
    h.step(e, j, e.broker.positions(), "REGULAR", now + 15)
    assert j["phase"] == "waiting" and j["cycles"] == 1 and j["banked"] > 0, j
    # no pullback yet -> no re-entry; then a pullback of > 0.25 A with an up-candle -> buys again
    st["bid"], st["ask"] = 100.32, 100.34
    h.step(e, j, e.broker.positions(), "REGULAR", now + 20)
    assert len(calls) == 1, "re-entered without a pullback"
    st["bid"], st["ask"] = 100.10, 100.12
    h.step(e, j, e.broker.positions(), "REGULAR", now + 25)
    assert len(calls) == 1, "re-entered inside the 60 s cool-off (v1.95.1)"
    st["bid"], st["ask"] = 100.06, 100.08                       # still falling after the cool-off: wait for the drop to stop
    h.step(e, j, e.broker.positions(), "REGULAR", now + 80)
    assert len(calls) == 1, "re-entered while price was still making new lows"
    st["bid"], st["ask"] = 100.12, 100.14                       # bounced > 0.1 A off the low: now buy
    h.step(e, j, e.broker.positions(), "REGULAR", now + 90)
    assert calls[-1][0] == "open" and j["phase"] == "entering", (calls, j["msg"])
    st["held"] = 10
    h.step(e, j, e.broker.positions(), "REGULAR", now + 95); assert j["phase"] == "holding"
    # wide spread: a tiny gain that does not pay for the round trip is not harvested
    h2, e2, st2, c2 = _fake_harvest(spread=0.40)
    h2.arm("ZZZ", "buy", 10); j2 = h2.jobs["ZZZ"]; n = _t.time()
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n)
    st2["bid"], st2["ask"] = 100.26, 100.66
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n + 5)
    assert not c2, "harvested a gain smaller than the spread cost"


@test("harvest: Harvest-now sells immediately; protective stop closes and ends the job; halt and overnight are respected")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n)
    j["sess_t"] = n - 999
    assert "Selling" in h.now("ZZZ")
    h.step(e, j, e.broker.positions(), "REGULAR", n + 4)
    assert calls and calls[0][0] == "close", "Harvest now did not sell"
    # protective stop: 2.4 A against the entry (hard stop) closes straight away and drops the job
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 98.7, 98.72
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0][0] == "close" and "ZZZ" not in h.jobs, (calls, h.jobs)
    # halted -> job stops, no orders
    h, e, st, calls = _fake_harvest(halted=True)
    h.arm("ZZZ", "buy", 10); h.step(e, h.jobs["ZZZ"], e.broker.positions(), "REGULAR")
    assert "ZZZ" not in h.jobs and not calls
    # overnight pause: no automatic sale at +1 A, but the Harvest-now button still works
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 100.6, 100.62
    h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 5)
    assert not calls, "automatic harvest ran overnight"
    h.now("ZZZ"); h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 9)
    assert calls and calls[0][0] == "close"
    # short side mirrors: gain when price falls
    h, e, st, calls = _fake_harvest()
    st["held"] = -10
    e.broker.positions = lambda: {"ZZZ": {"qty": -10, "avg_entry": 100.0, "price": st["ask"]}}
    h.arm("ZZZ", "sell", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 99.68, 99.70
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0] == ("close", "ZZZ", 10, "sell"), calls


@test("learn: floor/ceiling/trend reading is sane on rising, falling and flat charts")
def _():
    import pandas as pd, numpy as np
    from autobot import learn
    def mk(path):
        idx = pd.bdate_range(end="2026-09-14", periods=len(path)).tz_localize(NY)
        c = np.array(path, float)
        return pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c * 1.01, "low": c * 0.99, "close": c, "volume": 1e6}, index=idx)
    up = learn.read(mk([100 + i * 0.6 + (3 if i % 7 == 0 else 0) for i in range(120)]), "UP")
    assert up["trend"] == "UP", up["trend"]
    dn = learn.read(mk([200 - i * 0.6 - (3 if i % 7 == 0 else 0) for i in range(120)]), "DN")
    assert dn["trend"] == "DOWN", dn["trend"]
    assert not any(p["kind"] == "BUY" for p in dn["plan"]), "must not suggest buying a falling stock"
    flat = learn.read(mk([100 + 5 * np.sin(i / 4) for i in range(120)]), "FLAT")
    assert flat["floor"] and flat["ceiling"] and flat["floor"]["price"] < flat["price"] < flat["ceiling"]["price"], flat
    for r in (up, dn, flat):
        for p in r["plan"]:
            if p.get("stop") and p["zone"] and p["kind"] == "BUY":
                assert p["stop"] < p["zone"][0], f"stop not below the buy zone {p}"
    assert learn.read(mk([100] * 10), "X").get("error")


# ---------------------------------------------------------------- robinhood (mock server)
def _mock_rh():
    import threading, http.server, urllib.parse as up
    state = {"orders": [], "codes": {"good-code"}, "regs": 0}

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _send(self, code, obj, ctype="application/json", extra=None):
            b = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
            self.send_response(code); self.send_header("Content-Type", ctype)
            for k, v in (extra or {}).items(): self.send_header(k, v)
            self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            base = f"http://127.0.0.1:{self.server.server_port}"
            if self.path.startswith("/.well-known/oauth-authorization-server"):
                return self._send(200, {"issuer": base, "authorization_endpoint": base + "/oauth", "token_endpoint": base + "/token",
                                        "registration_endpoint": base + "/register", "scopes_supported": ["internal"], "code_challenge_methods_supported": ["S256"]})
            self._send(404, {})
        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0); raw = self.rfile.read(n)
            if self.path == "/register":
                state["regs"] += 1
                return self._send(201, {"client_id": "cid-123"})
            if self.path == "/token":
                f = dict(up.parse_qsl(raw.decode()))
                if f.get("grant_type") == "authorization_code" and f.get("code") in state["codes"] and f.get("code_verifier"):
                    state["verifier"] = f["code_verifier"]
                    return self._send(200, {"access_token": "AT1", "refresh_token": "RT1", "expires_in": 3600})
                if f.get("grant_type") == "refresh_token" and f.get("refresh_token") == "RT1":
                    return self._send(200, {"access_token": "AT2", "expires_in": 3600})
                return self._send(400, {"error": "invalid_grant"})
            if self.path == "/mcp":
                if self.headers.get("Authorization") not in ("Bearer AT1", "Bearer AT2"):
                    return self._send(401, {})
                m = json.loads(raw or b"{}"); meth = m.get("method"); i = m.get("id")
                if meth == "initialize":
                    return self._send(200, {"jsonrpc": "2.0", "id": i, "result": {"protocolVersion": "2025-06-18", "capabilities": {}, "serverInfo": {"name": "mock"}}}, extra={"Mcp-Session-Id": "S1"})
                if meth.startswith("notifications/"):
                    return self._send(202, b"")
                if meth == "tools/list":
                    tools = [{"name": "get_accounts", "description": "accounts", "inputSchema": {"type": "object"}, "annotations": {"readOnlyHint": True}},
                             {"name": "get_positions", "description": "positions", "inputSchema": {"type": "object"}},
                             {"name": "place_stock_order", "description": "order", "inputSchema": {"type": "object", "required": ["symbol"]}},
                             {"name": "mystery_tool", "description": "unknown", "inputSchema": {"type": "object"}}]
                    body = ("event: message\ndata: " + json.dumps({"jsonrpc": "2.0", "id": i, "result": {"tools": tools}}) + "\n\n").encode()
                    return self._send(200, body, "text/event-stream")
                if meth == "tools/call":
                    nm = m["params"]["name"]
                    if nm == "place_stock_order": state["orders"].append(m["params"]["arguments"])
                    return self._send(200, {"jsonrpc": "2.0", "id": i, "result": {"content": [{"type": "text", "text": json.dumps({"ok": nm, "n": len(state["orders"])})}]}})
            self._send(404, {})
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, state


def hashlib_ok(verifier, challenge):
    import hashlib, base64
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode() == challenge


@test("robinhood: sign-in (PKCE), token refresh, SSE tool list, write tools are classified and never run without PIN + confirm")
def _():
    import socket, urllib.request, urllib.error, urllib.parse as up
    from autobot import rhmcp
    assert rhmcp.is_write({"name": "place_stock_order"}) and rhmcp.is_write({"name": "mystery_tool"})
    assert rhmcp.is_write({"name": "cancel_order", "annotations": {"readOnlyHint": True}}), "a write-sounding name must win over a read hint"
    assert not rhmcp.is_write({"name": "get_positions"}) and not rhmcp.is_write({"name": "x", "annotations": {"readOnlyHint": True}})
    srv, st = _mock_rh()
    mcp = f"http://127.0.0.1:{srv.server_port}/mcp"
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    d = Path(TMP) / "rhapi"; d.mkdir()
    env = dict(os.environ, AUTOBOT_DATA=str(d), SEKEX_RH_MCP=mcp, LIVE_PIN="4321")
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--host", "127.0.0.1", "--sim", "--speed", "60"],
                         cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/version", timeout=2).read(); break
            except Exception:
                time.sleep(1)
        else:
            raise AssertionError("server did not start")
        def req(path, body=None, method=None):
            r = urllib.request.Request(base + path, data=None if body is None else json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method=method or ("POST" if body is not None else "GET"))
            try:
                resp = urllib.request.urlopen(r, timeout=20); return resp.status, resp.read().decode()
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode()
        assert req("/api/rh/status")[0] == 200 and json.loads(req("/api/rh/status")[1])["connected"] is False
        assert req("/api/rh/tools")[0] == 409, "not connected must be a clean 409, not a 500"
        s, b = req("/api/rh/connect", {}); assert s == 200, b
        url = json.loads(b)["url"]; q = dict(up.parse_qsl(up.urlparse(url).query))
        assert q["code_challenge_method"] == "S256" and q["client_id"] == "cid-123" and q["redirect_uri"].endswith("/api/rh/callback"), q
        s, b = req(f"/api/rh/callback?code=bad&state={q['state']}"); assert "Not connected" in b
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        s, b = req(f"/api/rh/callback?code=good-code&state=WRONG"); assert "Not connected" in b, "a wrong state must be refused"
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        s, b = req(f"/api/rh/callback?code=good-code&state={q['state']}"); assert "Connected" in b and "Not connected" not in b, b
        assert hashlib_ok(st["verifier"], q["code_challenge"]), "PKCE verifier does not match the challenge"
        tools = {t["name"]: t for t in json.loads(req("/api/rh/tools")[1])["tools"]}
        assert tools["get_accounts"]["write"] is False and tools["get_positions"]["write"] is False
        assert tools["place_stock_order"]["write"] and tools["mystery_tool"]["write"]
        ov = json.loads(req("/api/rh/overview")[1])["results"]; assert {x["tool"] for x in ov} == {"get_accounts", "get_positions"}, ov
        assert req("/api/rh/read", {"tool": "place_stock_order", "args": {"symbol": "X"}})[0] == 403, "read endpoint must refuse a write tool"
        order = {"tool": "place_stock_order", "args": {"symbol": "AAPL", "qty": 1}}
        assert req("/api/rh/call", dict(order, confirm=True))[0] == 403, "no PIN"
        assert req("/api/rh/call", dict(order, confirm=True, pin="0000"))[0] == 403, "wrong PIN"
        assert req("/api/rh/call", dict(order, confirm=False, pin="4321"))[0] == 400, "no confirm"
        assert st["orders"] == [], "an order reached Robinhood without PIN + confirm"
        s, b = req("/api/rh/call", dict(order, confirm=True, pin="4321")); assert s == 200 and st["orders"] == [order["args"]], (s, b)
        # token refresh: expire the access token on disk, the next call must refresh and still work
        f = d / "robinhood.json"; cfg = json.loads(f.read_text()); assert cfg.get("refresh") == "RT1" and oct(f.stat().st_mode)[-3:] == "600", oct(f.stat().st_mode)
        assert req("/api/rh/disconnect", {})[0] == 200 and req("/api/rh/tools")[0] == 409
        assert '"/api/rh/callback"' in (ROOT / "server.py").read_text().split("LOCAL_ONLY")[0], "callback must be reachable from the other browser"
        # paste-the-address fallback: same sign-in, finished with the URL the browser ended on
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        assert req("/api/rh/finish", {"url": "http://127.0.0.1/x"})[0] == 400, "no code must be refused"
        s, b = req("/api/rh/finish", {"url": f"http://127.0.0.1:8010/api/rh/callback?code=good-code&state={q['state']}"}); assert s == 200, (s, b)
        assert req("/api/rh/tools")[0] == 200, "pasted address should connect"
    finally:
        p.terminate(); srv.shutdown()


@test("green touches: 3rd green-then-fade banks; off at 0; needs a fade back to ~break-even between touches")
def _():
    e = _engine(let_run=False, scale_out=False)
    e.s.green_touches = 3
    t = _mk_trade("SCALP")
    seq = [0.4, 0.5, 0.0, 0.4, 0.0, 0.35]
    out = [e._green_touches(t, r) for r in seq]
    assert out == [False, False, False, False, False, True], out  # 0.4/0.5 = one touch, then two more after fades
    t = _mk_trade("SCALP")
    assert not any(e._green_touches(t, r) for r in [0.4, 0.6, 0.8, 1.0]), "a steady climb is one touch, never banked"
    e.s.green_touches = 0
    t = _mk_trade("SCALP")
    assert not any(e._green_touches(t, r) for r in [0.4, 0, 0.4, 0, 0.4]), "0 turns the rule off"


@test("pin: pin_ok forgives whitespace, rejects wrong; PIN-set rejects symbols; guard flush skips tiny extended swings")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("def pin_ok"); j = src.index("\n\n\n", i)
    ns = {"live_pin": lambda: "abc123"}
    exec(src[i:j], ns)
    f = ns["pin_ok"]
    assert f("abc123") and f(" abc123\n") and not f("abc124") and not f("") and not f(None)
    ns["live_pin"] = lambda: ""
    assert not f(""), "no PIN configured must never match"
    assert "[\\s#'\"\\\\=$`]" in src or "re.search" in src
    st = (ROOT / "autobot" / "strategies.py").read_text()
    assert st.count('ctx.get("ext")') >= 2


@test("dashboard: Harvest all only offered with 2+ of your positions all green")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "mine.length >= 2 && mine.every(p => ((p.exit_upl != null ? p.exit_upl : p.upl) || 0) > 0)" in h and h.count("mine.length < 2 ||") == 1


@test("manual guard: never closes a position into a broken overnight quote, still closes on a sane one")
def _():
    from autobot.guard_manual import ManualGuard
    class S: guard_loss_pct = 0.15; guard_manual = True
    closed = []
    q = {"v": (47.57, 64.35)}
    g = ManualGuard(lambda: None, lambda: S, lambda e: "OVERNIGHT", lambda e, sym, sess: q["v"],
                    lambda e, sym: closed.append(sym), lambda *a, **k: None, lambda e, sym: False)
    class E:
        def event(self, *a, **k): pass
    E = E()
    pos = {"qty": 944, "avg_entry": 63.13, "price": 55.96, "upl": -6768.0}
    g.check(E, S, "close", "IHF", pos, "OVERNIGHT")
    assert closed == [], "closed into a 30% wide spread"
    q["v"] = (53.0, 53.1)
    g.check(E, S, "close", "IHF", pos, "OVERNIGHT")
    assert closed == ["IHF"], "a genuine -16% loss on a sane quote must still be closed"


@test("long-wave planner: finds a regular wave and plans legs; refuses random walks; API answers")
def _():
    import numpy as np, pandas as pd
    from autobot import longwave as lw
    idx = pd.date_range("2026-10-05 16:00", "2026-10-08 02:00", freq="5min", tz=NY)
    t = np.arange(len(idx)); rng = np.random.default_rng(1)
    c = 168 + 0.45 * np.sin(2 * np.pi * t / 30) + rng.normal(0, 0.05, len(idx))
    df = pd.DataFrame({"open": c, "high": c + .04, "low": c - .04, "close": c, "volume": 1}, index=idx)
    p = lw.plan(df, "X")
    assert p["ok"] and 120 <= p["cycle_mins"] <= 180 and 0.5 <= p["up_pct"] <= 0.8, p
    assert 1 <= len(p["legs"]) <= 5 and all(g["take"] > g["entry"] > g["stop"] and g["rr"] > 0 for g in p["legs"]), p["legs"]
    assert lw.backtest(df)["hit"] >= 0.7
    bad = 0
    for seed in range(8):
        r = np.random.default_rng(seed); w = 168 + np.cumsum(r.normal(0, 0.05, len(idx)))
        d2 = pd.DataFrame({"open": w, "high": w + .04, "low": w - .04, "close": w, "volume": 1}, index=idx)
        bad += bool(lw.plan(d2, "RW")["ok"])
    assert bad <= 1, f"{bad}/8 random walks were given a wave plan"
    assert "api/longwave" in (ROOT / "server.py").read_text() and "lwGo" in (ROOT / "web" / "dashboard.html").read_text()


@test("PIN: can be created/changed from the Trading-mode window, also while the bot runs; needs the current PIN to change")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("def keys_save"); j = src.index("def pin_set") if src.index("def pin_set") > i else len(src)
    body = src[i:i + 900]
    assert body.index("(k or s_) and engine and engine.running") < body.index("Stop the bot"), "a PIN alone must save while the bot runs"
    assert "/api/pin/set" in src and "pinSave()" in (ROOT / "web" / "dashboard.html").read_text()
    k = src[src.index("def pin_set"):src.index("def keys_save")]
    assert "pin_ok(r.current)" in k and "len(newpin) < 4" in k and "record_fail" in k


@test("loss limits: PAPER and LIVE each keep their own; migration starts both at the current limit; switching swaps it")
def _():
    from autobot import config
    d = Path(TMP) / "mig2"; d.mkdir()
    config.SETTINGS_FILE = d / "settings.json"; config.OPTIONS_FILE = d / "options_settings.json"
    config.SETTINGS_FILE.write_text(json.dumps({"daily_max_loss": 137.5}))
    s = config.Settings.load()
    assert s.daily_max_loss == 137.5 and s.loss_paper == 137.5 and s.loss_live == 137.5, (s.daily_max_loss, s.loss_paper, s.loss_live)
    s.live = False; s.daily_max_loss = 1000.0; s.remember_limit()                    # set paper to 1000
    s.remember_limit(); s.live = True; s.use_limit_for(True)
    assert s.daily_max_loss == 137.5, "live must keep the original limit"
    s.daily_max_loss = 50.0; s.remember_limit(); s.save()
    s.remember_limit(); s.live = False; s.use_limit_for(False)
    assert s.daily_max_loss == 1000.0 and s.loss_live == 50.0
    s2 = config.Settings.load()
    assert s2.loss_paper == 1000.0 and s2.loss_live == 50.0 and s2.v1903_limits


@test("armed picks: bot enters only inside the zone, with the card's stop/target, never when halted; shorts need the short gate")
def _():
    import json as _j
    from autobot import engine as E
    e = _engine()
    E.Engine.PICKS_FILE = Path(TMP) / "picks_test.json"
    e.acct = {"equity": 25000, "buying_power": 100000, "shorting_enabled": True}
    day = str(e.broker.now().date())
    e.set_pick("ZZZ", {"side": "up", "zone": [100.0, 100.5], "stop": 99.0, "tp1": 102.0, "name": "t", "score": 80})
    assert "ZZZ" in e.picks()
    sent = []
    e.broker.submit_limit_ext = lambda sym, side, qty, lim, cid: sent.append((sym, side, qty, lim)) or "oid1"
    e.broker.submit_bracket = lambda sym, side, qty, lim, stop, tp, cid: sent.append((sym, side, qty, lim, stop, tp)) or "oid2"
    e._ext_enabled = lambda s: True; e._event_block = lambda *a, **k: False; e._pair_block = lambda *a: False; e._margin_block = lambda: False
    e._fresh_account = lambda *a, **k: None
    now = e.broker.now()
    e._pick_entries(now, "PRE", {"ZZZ": (103.0, 103.05, 103.0)})              # price above the zone
    assert sent == [], "must wait while price is outside the zone"
    e.risk.halted = True
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert sent == [], "must not enter while halted"
    e.risk.halted = False
    e._pick_entries(now, "PRE", {"ZZZ": (100.0, 100.9, 100.2)})               # spread 0.9%: too wide
    assert sent == [], "must respect the spread check"
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert len(sent) == 1 and sent[0][1] == "buy" and sent[0][2] >= 1 and abs(sent[0][3] - 100.35) < 0.02, sent
    assert "ZZZ" not in e.picks() and e.trades["ZZZ"].stop == 99.0, "pick is consumed and the card's stop is used"
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert len(sent) == 1, "one entry per pick"
    st = (ROOT / "server.py").read_text()
    assert "/api/wave/pick" in st and "For a buy the stop must be below the zone" in st
    assert "mwArm(" in (ROOT / "web" / "dashboard.html").read_text()


@test("rookie level, presets, toggles, F, getting-started: present and the daily limit is never touched")
def _():
    from autobot import levels
    assert levels.ORDER[0] == "rookie" and levels.LEVELS["rookie"]["max_positions"] == 1 and not levels.LEVELS["rookie"]["allow_shorts"]
    srv = (ROOT / "server.py").read_text()
    i = srv.index("PRESET_KEYS"); assert "daily_max_loss" not in srv[i:i + 600] and "loss_paper" not in srv[i:i + 600]
    assert "/api/level/preset" in srv and "/api/onboard" in srv
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "gsPaint" in h and "presetSave" in h and "input[type=checkbox]" in h
    assert "*9/5+32" in (ROOT / "autobot" / "android.py").read_text().replace(" ", "")
    assert "dashboard.html" and "°F" in h


@test("trader modes: picker on first launch, mode saved without touching limits, rookie level on first pick, screens/learn per mode")
def _():
    from autobot import config
    s = config.Settings(); assert s.ui_mode == ""
    srv = (ROOT / "server.py").read_text(); i = srv.index("def set_uimode"); body = srv[i:i + 900]
    assert "daily_max_loss" not in body and "loss_paper" not in body and "apply_level(settings, \"rookie\")" in body
    h = (ROOT / "web" / "dashboard.html").read_text()
    for k in ("uiPick", "uiSet(", "ui-rookie", "ui-trader", "LN_GUIDE", "rkHome", "moRookie", "segUi"):
        assert k in h, k
    assert "data-n=\"${esc(n)}\"" in h and "presetApply('${" not in h, "preset names must not be put inside a JS string"
    assert "rkWhy" in h and "repeat(4,1fr)" in h and "_lgDone" in h
    assert h.count("LN_GUIDE") >= 2 and "rookie: [" in h and "trader: [" in h and "advanced: [" in h


@test("wave trader prices candidates the scanner missed and ignores quotes older than 5 minutes")
def _():
    s = (ROOT / "autobot" / "engine.py").read_text()
    i = s.index("def _wave_entries"); b = s[i:i + 6000]
    assert "miss = [r[\"symbol\"]" in b and "quote is stale" in b and "quotes.update(self.broker.quotes(miss" in b


@test("sekex ship/clean: keeps the newest 2, protects what latest.json points at and the user's data, dry-run deletes nothing")
def _():
    import subprocess
    r = subprocess.run([sys.executable, str(ROOT / "tests" / "ship_check.py"), str(ROOT)], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0 and "OK" in r.stdout, r.stdout[-800:] + r.stderr[-800:]


@test("Find & fix it accepts up to 3 screenshots: validated, sent to the AI as images, never kept or shown in status")
def _():
    import base64
    from autobot import selffix
    ok = base64.b64encode(b"\x89PNG" + b"0" * 100).decode()
    assert len(selffix.clean_images([{"media_type": "image/png", "data": ok}])) == 1
    for bad in ([{"media_type": "image/gif", "data": ok}], [{"media_type": "image/png", "data": "!!"}], [{"media_type": "image/png", "data": ok}] * 4):
        try:
            selffix.clean_images(bad); assert False, "should reject"
        except ValueError:
            pass
    seen = {}
    class X:
        status_code = 200; text = ""
        def json(s): return {"content": [{"text": "{}"}], "usage": {}}
    selffix.ai_post = lambda t, p: (seen.setdefault("p", p), X())[1]; selffix._pick_model = lambda k: "m"
    selffix._ask("k", "s", "u", 10, [{"media_type": "image/png", "data": ok}])
    assert [b["type"] for b in seen["p"]["messages"][0]["content"]] == ["image", "text"]
    sf = selffix.SelfFix("1"); sf.job = {"id": "a", "state": "ready", "images": [1], "new_text": {}}
    assert "images" not in sf._public_job()
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "fixFile" in h and "fixPick" in h and "images: fixImgs" in h


@test("settings menu: grouped into categories, JS still parses, jump links open their category")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "moreMenu" in h and "details.mcat" in h and "closest('details.mcat')" in h


# ---------------------------------------------------------------- journal audit of simulator runs
def audit_journal(db_file, limit, max_notional, label):
    import sqlite3
    c = sqlite3.connect(db_file); c.row_factory = sqlite3.Row
    rows = [dict(r) for r in c.execute("SELECT * FROM trades WHERE status='closed' ORDER BY opened_at")]
    problems = []
    by_day = {}
    open_iv = {}
    for r in rows:
        side = 1 if r["side"] == "buy" else -1
        if r["qty"] is None or r["qty"] <= 0:
            problems.append(f"{r['id']} qty {r['qty']}")
        if (r["stop"] - r["entry"]) * side >= 0 and r["bucket"] != "MANUAL":
            problems.append(f"{r['symbol']} {r['strategy']} stop {r['stop']:.2f} on the wrong side of entry {r['entry']:.2f}")
        if r["qty"] * r["entry"] > max_notional * 1.05 + 1 and not r["id"].startswith("m"):
            problems.append(f"{r['symbol']} notional ${r['qty']*r['entry']:,.0f} over the ${max_notional:,.0f} cap")
        by_day[r["day"]] = by_day.get(r["day"], 0.0) + (r["pnl"] or 0.0)
        if r["pnl"] is not None and r["exit"] is not None:
            calc = (r["exit"] - r["entry"]) * side * r["qty"]
            if abs(calc - r["pnl"]) > max(0.05, 0.02 * abs(calc)) and abs(r["pnl"]) > 0.5:
                problems.append(f"{r['symbol']} pnl {r['pnl']:.2f} != (exit-entry)*qty {calc:.2f}")
        iv = open_iv.setdefault(r["symbol"], [])
        if r["closed_at"] and r["opened_at"]:
            for a, b in iv:
                if r["opened_at"] < b and r["closed_at"] > a:
                    problems.append(f"{r['symbol']} two positions open at once ({r['opened_at'][:16]})")
                    break
            iv.append((r["opened_at"], r["closed_at"]))
    worst = min(by_day.values()) if by_day else 0.0
    return {"trades": len(rows), "pnl": round(sum(by_day.values()), 2), "worst_day": round(worst, 2), "problems": problems[:12], "n_problems": len(problems)}


@test("wave watchlist: every session family (pre, regular, after, overnight) builds from 15-minute bars; mode follows the clock")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    idx = []
    for d in pd.bdate_range("2026-08-03", periods=45):
        idx += list(pd.date_range(d.strftime("%Y-%m-%d") + " 04:00", d.strftime("%Y-%m-%d") + " 19:45", freq="15min", tz="America/New_York"))
    rng = np.random.default_rng(1); p = 100 + np.cumsum(rng.normal(0, .2, len(idx)))
    df = pd.DataFrame({"open": p, "high": p + .15, "low": p - .15, "close": p + rng.normal(0, .05, len(idx)), "volume": 1000}, index=idx)
    for m in mw.MODES:
        days = mw._days(df, m)
        assert len(days) >= 40 and days[-1]["pc"] > 0, m
        mw.build({"ZZ": df}, 0.4, m)
    assert [mw.mode_for("PRE", 500), mw.mode_for("REGULAR", 9 * 60 + 40), mw.mode_for("REGULAR", 11 * 60), mw.mode_for("AFTER", 1000), mw.mode_for("OVERNIGHT", 1300), mw.mode_for("CLOSED", 0)] == \
        ["PRE", "PRE", "REGULAR", "AFTER", "OVERNIGHT", "PRE"]


@test("loss limits: /api/limit can set the other mode's limit without touching the one in use")
def _():
    src = (ROOT / "server.py").read_text()
    assert "want_live" in src and "mode: str" in src
    from autobot import config
    s = config.Settings(); s.live = False; s.daily_max_loss = 200.0; s.remember_limit(); s.loss_live = 500.0
    s.use_limit_for(False); assert s.daily_max_loss == 200.0 and s.loss_live == 500.0


@test("support: the admin's collector address rides in latest.json and is adopted only when the tester has none")
def _():
    assert '"collector"' in (ROOT / "bin" / "sekex_publish.py").read_text()
    assert "m.get(\"collector\")" in (ROOT / "server.py").read_text()


@test("predict tab: exists for every trader mode, Auto top 10 / My list, education on each card")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text(); sv = (ROOT / "server.py").read_text()
    assert 'data-go="pred"' in h and 'data-v="pred" class="card c12 rk"' in h and "mwEdu" in h and "mwSource" in h
    assert "[data-go=pred]" not in h.split("html.ui-rookie [data-go=sess]")[1].split("}")[0], "Predict must not be hidden in Rookie"
    assert "/api/predict/prefs" in sv and "pred_source" in sv and "[:10]" in sv
    from autobot import config
    st = config.Settings(); assert st.pred_source == "auto" and st.pred_manual == []


@test("check-up: finds repeating errors / loss-limit use, drafts a fix only when asked, never changes settings; options re-price and auto-tune")
def _():
    import tempfile, collections, datetime as _dt
    from types import SimpleNamespace as NS
    from autobot import checkup, config, options
    checkup.FILE = Path(tempfile.mkdtemp()) / "c.json"
    st = config.Settings(); st.daily_max_loss = 1000.0; lim0 = st.daily_max_loss
    ev = collections.deque([{"t": "10:00:0%d" % i, "msg": "Loop error: cannot unpack non-iterable NoneType object", "level": "error"} for i in range(4)])
    e = NS(s=st, events=ev, day="2026-10-09", broker=NS(now=lambda: _dt.datetime(2026, 10, 9, 16, 20)), risk=NS(day_pnl=-900.0), acct={"equity": 1500.0}, alerts=None, alert=lambda *a, **k: None)
    started = []
    sf = NS(start=lambda problem, extra="": started.append(problem))
    rep = checkup.run(e, None, sf, "manual")
    titles = " | ".join(i["title"] for i in rep["items"])
    assert rep["grade"] == "attention" and "Repeating error" in titles and "90%" in titles and "over half" in titles, titles
    assert started and "loss limits" in started[0], "fix draft not requested"
    assert st.daily_max_loss == lim0, "check-up changed the loss limit"
    st.auto_fix_draft = False; started.clear(); checkup.run(e, None, sf, "manual"); assert not started
    # options: reprice then tune
    calls = []
    class Tr:
        def replace_order_by_id(self, oid, req): calls.append((oid, req.limit_price, req.qty)); return NS(id="new1")
    ob = options.OptionsBot.__new__(options.OptionsBot)
    ob.s = st; ob.events = collections.deque(); ob.fills = []; ob._fcount = 0; ob._tuned_n = 0; ob.get_engine = lambda: None; ob._save = lambda: None
    ob._quotes = lambda e_, syms: {syms[0]: (1.0, 1.04)}
    p = {"underlying": "TSLA", "direction": "call", "style": "single", "long": "TSLA_X", "limit": 1.00, "debit": 1.0, "qty": 2, "order_id": "o1", "sent_at": 0}
    e2 = NS(broker=NS(trading=Tr())); st.options_max_premium = 200.0
    assert ob._reprice(e2, p) and p["limit"] == 1.04 and p["reprices"] == 1 and calls[0][1] == 1.04 and p["qty"] == 1, (p, calls)    # capped at the ask; qty cut to fit $200
    assert not ob._reprice(e2, p), "re-priced past the ask"
    st.save = lambda: None
    for _i in range(10): ob._note_fill(NS(day="d"), 0, p)
    assert st.opt_reprice_step_pct > 4.0, "auto-tune did not react to a 0% fill rate"


@test("AI helper: time-of-day scan ranks gains / drops; chat runs tools then answers; tools cannot trade")
def _():
    import numpy as np, pandas as pd
    from types import SimpleNamespace as NS
    from autobot import trendscan, aihelper
    idx = []
    for d in pd.bdate_range("2026-08-03", periods=45):
        idx += list(pd.date_range(d.strftime("%Y-%m-%d") + " 04:00", d.strftime("%Y-%m-%d") + " 19:45", freq="15min", tz="America/New_York"))
    rng = np.random.default_rng(3); px = 100 + np.cumsum(rng.normal(0, .3, len(idx)))
    df = pd.DataFrame({"open": px, "high": px + .2, "low": px - .2, "close": px, "volume": 1}, index=idx)
    wild = df.copy(); wild[["open", "high", "low", "close"]] = wild[["open", "high", "low", "close"]] * 1.0 + np.sin(np.arange(len(wild)) / 3.0)[:, None] * 2
    out = trendscan.scan({"CALM": df * 0.2, "WILD": wild}, "after lunch", 0.5, 5)
    assert out["window"] == "afterlunch" and out["scanned"] == 2 and out["gains"][0]["symbol"] == "WILD", out
    assert trendscan.window_key("before close") == "close" and trendscan.window_key("morning") == "morning"
    replies = iter(['{"tool": "scan_trends", "args": {"window": "close"}}', '```json\n{"answer": "Here you go"}\n```'])
    seen = []
    class R:
        status_code = 200
        text = ""
        def json(self): return {"content": [{"type": "text", "text": next(replies)}]}
    orig = (aihelper.ai_post, aihelper.ai_key, aihelper._pick_model)
    aihelper.ai_post = lambda t, payload: (seen.append(payload["messages"][-1]["content"][:30]), R())[1]; aihelper.ai_key = lambda: "k"; aihelper._pick_model = lambda k: "m"
    try:
        res = aihelper.chat([{"role": "user", "content": "big drops before close?"}], {"scan_trends": lambda a: {"ok": a}}, "now")
    finally:
        aihelper.ai_post, aihelper.ai_key, aihelper._pick_model = orig
    assert res["answer"] == "Here you go" and res["cards"][0]["tool"] == "scan_trends" and seen[1].startswith("TOOL RESULT scan_trends"), (res, seen)
    src = (ROOT / "server.py").read_text(); body = src.split("def _ai_tools():")[1].split("@app.post(\"/api/ai/chat\")")[0]
    assert "submit_order" not in body and "place" not in body.lower().replace("placement", "") and "/api/limit" not in body


@test("Robinhood ticket: all taps (no typing), values sent in the type Robinhood wants, extra required fields as buttons")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    for k in ("function rhCast", "ty == 'string') return String(v)", "rhPinKey", "rhQtyAdd", "rhOTset", "rhExtraPick", "rhPickSym"):
        assert k in h, k
    for k in ("rhQuoteGet", "rhAcctGet", "rhHoldGet", "rhOrdGet", "rhCancel", "rhTIFset", "rhResultHtml", "function rhDial", "rhKnob", "RH_HIDE"):
        assert k in h, k
    for k in ("const RHW = [", "rhWizCheck", "rhWizInit", "Open the Agentic account"):
        assert k in h, k
    assert 'id="rhSym" type="hidden"' in h and 'id="rhQty" type="hidden"' in h


@test("RSI zone: uptrend dip that holds then turns = BUY, downtrend bounce that fails = SELL, zones are plain, record needs enough cases, endpoint and alert exist")
def _():
    import numpy as np, pandas as pd
    from autobot import rsizone
    r = pd.Series([60.0] * 10 + [48, 46, 47, 52.0]); tr = pd.Series([1] * len(r))
    assert rsizone._signal_at(r, tr, len(r) - 1) == 1
    r2 = pd.Series([40.0] * 10 + [52, 54, 53, 48.0]); tr2 = pd.Series([-1] * len(r2))
    assert rsizone._signal_at(r2, tr2, len(r2) - 1) == -1
    r3 = pd.Series([60.0] * 10 + [30, 32, 35, 52.0])                     # dip below 38 = trend in doubt, no signal
    assert rsizone._signal_at(r3, tr, len(r3) - 1) == 0
    assert rsizone._zone(1, 85)[0] == "stretched" and rsizone._zone(1, 45)[0] == "pullback" and rsizone._zone(-1, 55)[0] == "bounce" and rsizone._zone(0, 50)[0] == "flat"
    assert rsizone._evidence({1: [0.1] * 3}, 1)["ok"] is False
    assert rsizone._evidence({1: [0.2] * 10}, 1)["ok"] is True
    idx = pd.date_range("2026-08-20 09:30", periods=3000, freq="15min", tz="America/New_York"); idx = idx[(idx.hour >= 9) & (idx.hour < 16)]
    c = 100 * np.exp(np.cumsum(np.random.default_rng(3).normal(0.0003, 0.004, len(idx))))
    a = rsizone.analyze("T", pd.DataFrame({"open": c, "high": c, "low": c, "close": c, "volume": 1}, index=idx))
    assert a["ok"] and a["trend"] in ("UP", "DOWN", "FLAT") and "history" in a
    assert "rsizone" in (ROOT / "server.py").read_text() and '"rsizone"' in (ROOT / "autobot" / "alerts.py").read_text()


@test("Predict card projected profit: shares from the bot's own sizing, profit at TP1/TP2, loss at the stop, flags for poor reward/risk")
def _():
    import re
    src = (ROOT / "server.py").read_text()
    ns = {}
    exec(re.search(r"def _wave_plan\(.*?\n    return out\n", src, re.S).group(0), ns)
    r = {"side": "up", "zone": [100.0, 102.0], "stop": 98.0, "tp1": 106.0, "tp2": 110.0, "atr": 4.0}
    p = ns["_wave_plan"](r, 101.0, lambda e, st: (10, ""))
    assert p["qty"] == 10 and p["tp1"] == 50.0 and p["tp2"] == 90.0 and p["stop"] == -30.0 and p["cost"] == 1010.0 and p["rr1"] == 1.67
    z = ns["_wave_plan"](r, 101.0, lambda e, st: (0, "no risk budget left"))
    assert z["qty"] == 0 and z["why"] == "no risk budget left"
    f = ns["_wave_plan"]({"side": "down", "zone": [10.0, 11.0], "stop": 13.0, "tp1": 9.5, "tp2": 8.0, "atr": 1.0}, 10.5, lambda e, st: (10, ""))
    assert f["long"] is False and f["tp1"] == 10.0 and f["stop"] == -25.0 and f["poor"] is True and f["unlikely"] is True
    assert "function mwPlan" in (ROOT / "web" / "dashboard.html").read_text()


@test("sekex ship / update skip a damaged or half-downloaded zip and use the newest complete one")
def _():
    import importlib.util, tempfile, zipfile, os as _os
    spec = importlib.util.spec_from_file_location("sekex_publish_t", ROOT / "bin" / "sekex_publish.py")
    pub = importlib.util.module_from_spec(spec); spec.loader.exec_module(pub)
    d = tempfile.mkdtemp()
    with zipfile.ZipFile(_os.path.join(d, "SekexBot_Android_v2.1.0.zip"), "w") as z:
        z.writestr("SekexBot_Android/VERSION", "2.1.0")
    open(_os.path.join(d, "SekexBot_Android_v2.2.0.zip"), "wb").write(b"not a zip" * 50)
    old = _os.path.expanduser
    _os.path.expanduser = lambda x: d if x == "~/storage/downloads" else "/nonexistent"
    try:
        assert _os.path.basename(pub.find_zip("")) == "SekexBot_Android_v2.1.0.zip"
        try:
            pub.find_zip(_os.path.join(d, "SekexBot_Android_v2.2.0.zip")); assert False
        except SystemExit as e:
            assert "damaged" in str(e)
    finally:
        _os.path.expanduser = old
    assert "zipfile.ZipFile(f)" in (ROOT / "bin" / "sekex").read_text()


@test("wave hit rate only counts the NEXT morning (a flat next morning must not score as a hit)")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    NY = mw.NY; rows = []; prev = 100.0
    for d in pd.bdate_range("2026-08-03", periods=30):
        ds = d.strftime("%Y-%m-%d")
        for t in pd.date_range(ds + " 04:00", periods=22, freq="15min", tz=NY): rows.append((t, prev, prev, prev, prev))
        close = prev * 1.001; path = np.linspace(prev * .97, close, 26); path[20] = close * 1.005
        for t, p in zip(pd.date_range(ds + " 09:30", periods=26, freq="15min", tz=NY), path): rows.append((t, p, p, p, p))
        for t in pd.date_range(ds + " 16:00", periods=16, freq="15min", tz=NY): rows.append((t, close, close, close, close))
        prev = close
    df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close"]).set_index("ts").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    assert mw.analyze("T", df, 0.4, "PRE") is None


@test("sekex ship: declining the delete question still publishes")
def _():
    src = (ROOT / "bin" / "sekex_ship.py").read_text()
    assert "Also delete the old files" in src and "--keep-old" in src and "def confirm(msg, yes, default=False)" in src
    assert src.index("Also delete the old files") < src.index("pub.main()")


@test("Learn wizards exist (first trade 11 screens, Radar 8) and the Predict tab is renamed Radar / Setups")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "const FIRST = [" in h and "const RADAR = [" in h and "id=\"wzCard\"" in h
    assert 'data-go="more" onclick="setView(\'more\')"' not in h and 'id="gearBtn" data-go="more"' in h
    assert "pred: 'Radar'" in h and '<span class="stL">Radar</span>' in h


@test("Learn wizard 'A good setup, start to finish' has 12 steps, buy+short views, calculator and checklist")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    a = h.index("const SETUP = ["); b = h.index("function suTick", a)
    assert "setup: {t:" in h and "function suSvg(" in h and "function suCalc(" in h
    assert "Floor and ceiling" in h[a:b] and "SU.short = true" in h[a:b] and "wzOpen('first')" in h[a:b]


@test("Re-applied phone fixes: Radar Manual list seeds from watchlist; Robinhood numeric args sent as text when the tool wants text")
def _():
    src = (ROOT / "server.py").read_text()
    assert "empty manual list: start from the watchlist" in src
    ns = {}
    a = src.index("def _rh_fit_args"); b = src.index('@app.post("/api/rh/call")')
    exec(src[a:b], ns)
    f = ns["_rh_fit_args"]
    sch = {"properties": {"quantity": {"type": "string"}, "limit": {"type": "number"}, "side": {"type": "string"}}}
    assert f({"quantity": 1, "limit": 2.5, "side": "buy"}, sch) == {"quantity": "1", "limit": 2.5, "side": "buy"}
    assert f({"quantity": 1.5}, sch) == {"quantity": "1.5"} and f({"quantity": True}, sch) == {"quantity": True}


@test("One instance only: second copy on the same data folder exits (code 3); a new LiveFeed closes the old socket first; logging has no duplicate handlers")
def _():
    import subprocess, tempfile, sys as _s, types, threading, time as _t
    d = tempfile.mkdtemp()
    env = dict(os.environ, AUTOBOT_DATA=d)
    env.pop("SEKEX_NO_LOCK", None)
    a = subprocess.Popen([_s.executable, str(ROOT / "server.py"), "--sim", "--port", "8191"], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=ROOT)
    try:
        _t.sleep(5)
        b = subprocess.run([_s.executable, str(ROOT / "server.py"), "--sim", "--port", "8192"], env=env, capture_output=True, text=True, cwd=ROOT, timeout=40)
        assert b.returncode == 3 and "already running" in b.stdout, (b.returncode, b.stdout[-300:])
    finally:
        a.terminate(); a.wait(10)
    # stream: stubbed Alpaca websocket that blocks in run() until stop()
    live = types.ModuleType("alpaca.data.live"); enums = types.ModuleType("alpaca.data.enums")
    opened = []
    class DF: SIP = "sip"; IEX = "iex"
    enums.DataFeed = DF
    class SDS:
        def __init__(self, *a, **k): self.ev = threading.Event(); opened.append(self)
        def subscribe_quotes(self, *a): pass
        def subscribe_trades(self, *a): pass
        def run(self): self.ev.wait()
        def stop(self): self.ev.set()
    live.StockDataStream = SDS
    saved = {k: _s.modules.get(k) for k in ("alpaca", "alpaca.data", "alpaca.data.live", "alpaca.data.enums")}
    for k in saved: _s.modules[k] = types.ModuleType(k)
    _s.modules["alpaca.data.live"] = live; _s.modules["alpaca.data.enums"] = enums
    try:
        from autobot import stream
        f1 = stream.LiveFeed("k", "s"); _t.sleep(0.6)
        assert len(opened) == 1 and not opened[0].ev.is_set()
        f2 = stream.LiveFeed("k", "s"); _t.sleep(0.6)
        assert opened[0].ev.is_set() and not f1._t_run.is_alive(), "old socket must be closed before the new one runs"
        assert len(opened) == 2 and not opened[1].ev.is_set()
        f2.stop(); assert not f2._t_run.is_alive()
    finally:
        for k, v in saved.items():
            (_s.modules.__setitem__(k, v) if v is not None else _s.modules.pop(k, None))
    src = (ROOT / "server.py").read_text()
    assert "force=True" in src and "_set_feed(None)" in src and 'if [ "$code" = 3 ]' in (ROOT / "bin" / "sekex").read_text()


@test("Radar card shows a last-updated time and a stale warning (10 min amber, 30 min red)")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert 'id="mwStale"' in h and "function mwAge()" in h and "STALE: tap Refresh" in h and "refresh failed, showing old data" in h
    s = (ROOT / "server.py").read_text()
    assert '"ts": round(_tm.time())' in s and "age_s=round(" in s


@test("Radar weekend plan: gap is Fri 8 PM to Sun 8 PM ET, auto-rebuild thread at Sun 6:00 / 7:45 PM with a notification, banner on the card")
def _():
    from datetime import datetime as D
    src = (ROOT / "server.py").read_text()
    a = src.index("def _weekend_gap"); b = src.index("\n\n\n", a)
    ns = {}; exec(src[a:b], ns); g = ns["_weekend_gap"]
    assert not g(D(2026, 10, 9, 19, 59)) and g(D(2026, 10, 9, 20, 0)) and g(D(2026, 10, 10, 12)) and g(D(2026, 10, 11, 19, 59))
    assert not g(D(2026, 10, 11, 20, 0)) and not g(D(2026, 10, 12, 9))
    assert "_weekend_radar_loop" in src and 'slot = "6pm"' in src and 'slot = "745pm"' in src and "Radar weekend plan" in src
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert 'id="mwWk"' in h and "Weekend plan." in h and "j.weekend" in h


@test("v2.5.4: cheap-stock stop floor, Cloudflare Access headers for Ollama, state-aware watchlist button, real-stock checklist screen")
def _():
    import os as _o
    from autobot import morningwave as mw, analyst
    assert mw.min_risk(1.5) == 0.04 and abs(mw.min_risk(200) - 2.0) < 1e-9 and mw.px_round(0.123456, 0.5) == 0.1235 and mw.px_round(3.14159, 3) == 3.14
    assert "min_risk(c)" in (ROOT / "autobot" / "morningwave.py").read_text()
    old = {k: _o.environ.get(k) for k in ("OLLAMA_CF_ID", "OLLAMA_CF_SECRET")}
    try:
        _o.environ.pop("OLLAMA_CF_ID", None); _o.environ.pop("OLLAMA_CF_SECRET", None)
        assert "CF-Access-Client-Id" not in analyst._ollama_headers("")
        _o.environ["OLLAMA_CF_ID"] = "abc.access"; _o.environ["OLLAMA_CF_SECRET"] = "sec"
        hd = analyst._ollama_headers("")
        assert hd["CF-Access-Client-Id"] == "abc.access" and hd["CF-Access-Client-Secret"] == "sec"
    finally:
        for k, v in old.items():
            (_o.environ.__setitem__(k, v) if v is not None else _o.environ.pop(k, None))
    sv = (ROOT / "server.py").read_text(); h = (ROOT / "web" / "dashboard.html").read_text()
    assert "cf_id: str | None" in sv and "ollama_cf_set" in sv and 'id="kCfBox"' in h and "kCfClear" in h
    assert "function wlBtn(" in h and "↩ Cover" in h and "✓ Own " in h and "⏳ Order" in h and "${wlBtn(w)}" in h
    assert "function suRead(" in h and "function suScan(" in h and "Try it on a real stock" in h


@test("Night / extended manual market order is converted to a limit 0.2% through the spread (sim, 9 PM overnight)")
def _():
    import subprocess, tempfile, sys as _s, time as _t, json as _j, urllib.request as _u
    d = tempfile.mkdtemp(); env = dict(os.environ, AUTOBOT_DATA=d, SEKEX_NO_LOCK="1")
    p = subprocess.Popen([_s.executable, str(ROOT / "server.py"), "--sim", "--sim-start", "21:00", "--port", "8193"], env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=ROOT)
    try:
        for _ in range(40):
            try:
                q = _j.load(_u.urlopen("http://127.0.0.1:8193/api/manual/quote/SPY", timeout=3)); break
            except Exception:
                _t.sleep(0.5)
        def post(body):
            rq = _u.Request("http://127.0.0.1:8193/api/manual/order", _j.dumps(body).encode(), {"content-type": "application/json"})
            return _j.load(_u.urlopen(rq, timeout=10))
        if q["session"] == "CLOSED":          # the simulator uses today's date: Friday and Saturday nights have no overnight session
            return
        assert q["session"] == "OVERNIGHT"
        r = post({"symbol": "SPY", "side": "buy", "qty": 1, "order_type": "market", "session": "auto", "tif": "day"})
        assert r["ok"] and any("sent as a limit" in n and "above the ask" in n for n in r["notes"]), r
        r2 = post({"symbol": "QQQ", "side": "sell", "qty": 1, "order_type": "market", "session": "auto", "tif": "day", "confirm_short": True})
        assert r2["ok"] and any("below the bid" in n for n in r2["notes"]), r2
    finally:
        p.terminate(); p.wait(10)


@test("Alpaca clients get a bigger HTTP connection pool (no 'Connection pool is full' warnings)")
def _():
    from autobot.broker import _widen_pools
    from alpaca.trading.client import TradingClient
    from alpaca.data.historical import StockHistoricalDataClient
    a = TradingClient("k", "s", paper=True); b = StockHistoricalDataClient("k", "s")
    _widen_pools(a, b)
    for c in (a, b):
        ad = c._session.get_adapter("https://data.alpaca.markets")
        assert ad._pool_maxsize == 40 and ad._pool_connections == 40
    assert "_widen_pools(self.trading, self.data, self.screener)" in (ROOT / "autobot" / "broker.py").read_text()


@test("sekex publish uploads the zip, SekexBot_Setup.sh, the release-notes PDF, then latest.json last (mock GitHub); skips a wrong-version installer")
def _():
    import http.server, threading, json as _j, base64 as _b, tempfile, importlib.util, sys as _s, os as _o, re as _re
    store, order = {}, []
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _send(self, code, obj):
            b = _j.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            n = self.path.split("/contents/")[-1].split("?")[0]
            self._send(200, {"sha": "x"}) if n in store else self._send(404, {})
        def do_PUT(self):
            n = self.path.split("/contents/")[-1].split("?")[0]
            body = _j.loads(self.rfile.read(int(self.headers["Content-Length"])))
            store[n] = _b.b64decode(body["content"]); order.append(n); self._send(201, {})
    srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    d = tempfile.mkdtemp()
    ver = "9.9.9"
    open(_o.path.join(d, "SekexBot_Setup.sh"), "wb").write(b"#!/bin/bash\n# Version  9.9.9\n__SEKEX_PAYLOAD__\n" + b"A" * 200_000)
    open(_o.path.join(d, f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"), "wb").write(b"%PDF-1.4 test")
    _o.environ["SEKEX_GITHUB_API"] = f"http://127.0.0.1:{srv.server_port}"
    try:
        spec = importlib.util.spec_from_file_location("sekex_publish_t", ROOT / "bin" / "sekex_publish.py")
        pub = importlib.util.module_from_spec(spec); _s.path.insert(0, str(ROOT / "bin")); spec.loader.exec_module(pub)
        cfg = {"repo": "o/r", "token": "t", "branch": "main"}
        comp = pub.companions(_o.path.join(d, "SekexBot_Android_v9.9.9.zip"), ver)
        assert [c[0] for c in comp] == ["SekexBot_Setup.sh", f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"] and all(c[1] for c in comp), comp
        for n, data, _ in comp:
            assert pub.put(cfg, n, data, "m") == "uploaded"
        assert pub.put(cfg, "SekexBot_Setup.sh", store["SekexBot_Setup.sh"], "m") in ("uploaded", "unchanged")
        assert set(store) == {"SekexBot_Setup.sh", f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"}
        bad = pub.companions(_o.path.join(d, "x.zip"), "9.9.8")                     # wrong-version installer is never uploaded
        assert bad[0][1] is None and "not the v9.9.8 installer" in bad[0][2]
    finally:
        srv.shutdown(); _o.environ.pop("SEKEX_GITHUB_API", None)
    shp = (ROOT / "bin" / "sekex_ship.py").read_text()
    assert "Release_Notes_and_Install_v" in shp and '"SekexBot_Setup.sh"' in shp


@test("Stocks-off (options-only) mode: every stock entry path is gated, and the setting defaults to on")
def _():
    from autobot.config import Settings
    import types
    from autobot.engine import Engine
    assert Settings().stocks_on is True
    src = (ROOT / "autobot" / "engine.py").read_text()
    for fn in ("_entries", "_wave_entries", "_pick_entries", "_ext_entries"):
        i = src.index("    def " + fn + "(")
        assert "if self._stocks_off():" in src[i:i + 700], fn
    fake = types.SimpleNamespace(s=types.SimpleNamespace(stocks_on=False), state="")
    assert Engine._stocks_off(fake) is True and "options-only" in fake.state
    fake.s.stocks_on = True
    assert Engine._stocks_off(fake) is False


@test("Options Hub: strike rows (breakeven, flags), payoff, and every order safety rule")
def _():
    from autobot import optionshub as oh
    c = oh.parse_occ("TSLA261121C00400000")
    assert c["underlying"] == "TSLA" and c["kind"] == "call" and c["strike"] == 400.0 and str(c["expiry"]) == "2026-11-21"
    assert oh.parse_occ("TSLA") is None and oh.parse_occ("TSLA261121X00400000") is None
    cons = [{"symbol": f"S{k}", "strike": float(k), "oi": 500 if k != 410 else 10} for k in (380, 390, 400, 410, 420)]
    snaps = {"S400": {"bid": 29.0, "ask": 29.2}, "S410": {"bid": 20.0, "ask": 26.0}}
    rows = {r["strike"]: r for r in oh.rows_for("call", 351.31, cons, snaps)}
    assert rows[400.0]["breakeven"] == 429.2 and rows[400.0]["itm"] is False and rows[400.0]["to_be_pct"] == 22.2
    assert "thin open interest" in rows[410.0]["flags"] and "wide spread" in rows[410.0]["flags"] and "no quote" in rows[380.0]["flags"]
    assert [r["strike"] for r in oh.rows_for("call", 351.31, cons, snaps)] == [420.0, 410.0, 400.0, 390.0, 380.0]
    put = oh.rows_for("put", 351.31, [{"symbol": "P", "strike": 400.0, "oi": 500}], {"P": {"bid": 60.0, "ask": 61.0}})[0]
    assert put["breakeven"] == 339.0 and put["itm"] is True
    pf = oh.payoff("call", 400, 29.2, 351.31)
    assert pf["max_loss"] == 2920.0 and pf["max_profit"] is None and pf["breakeven"] == 429.2
    assert oh.payoff("put", 400, 20, 351.31)["max_profit"] == 38000.0
    ok = dict(side="buy", qty=1, limit=1.5, held_qty=0, bp=5000, level=2, market_open=True, halted=False, live=False, live_unlocked=False,
              pin_given_ok=True, confirm=True, managed_by_bot=False)
    assert oh.check_order(**ok) == ""
    for k, v, word in (("confirm", False, "confirm"), ("qty", 99, "between"), ("limit", 0, "limit"), ("market_open", False, "regular hours"),
                       ("halted", True, "daily loss limit"), ("level", 0, "approved"), ("limit", 60, "buying power"), ("managed_by_bot", True, "bot is managing"),
                       ("side", "sell", "naked")):
        assert word in oh.check_order(**{**ok, k: v}).lower() or word in oh.check_order(**{**ok, k: v}), (k, oh.check_order(**{**ok, k: v}))
    assert "locked" in oh.check_order(**{**ok, "live": True})
    assert "PIN" in oh.check_order(**{**ok, "live": True, "live_unlocked": True, "pin_given_ok": False})
    assert oh.check_order(**{**ok, "live": True, "live_unlocked": True}) == ""
    assert oh.check_order(**{**ok, "side": "sell", "held_qty": 2, "halted": True}) == ""      # you can always close, even after the loss limit


@test("Built-in preset 'Fewer, bigger trades' never touches the loss limit and only uses preset keys")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("BUILTIN_PRESETS = {"); blk = src[i:src.index("def _presets", i)]
    ns = {}
    keys = eval(src[src.index("PRESET_KEYS = ["):src.index("]", src.index("PRESET_KEYS = ["))+1].split("=", 1)[1])
    exec(blk, ns)
    p = ns["BUILTIN_PRESETS"]["Fewer, bigger trades"]
    assert set(p) <= set(keys), set(p) - set(keys)
    assert not any("loss" in k for k in p) and "daily_max_loss" not in keys
    assert p["max_positions"] == 2 and p["risk_per_trade_frac"] > 0.2 and p["scalp_mode"] is False and p["reentry"] is False


@test("Support preset offers: only whitelisted keys, clamped, never the loss limit / keys / PIN / live; collector refuses them too")
def _():
    from autobot import offers
    src = (ROOT / "server.py").read_text()
    keys = set(eval(src[src.index("PRESET_KEYS = ["):src.index("]", src.index("PRESET_KEYS = ["))+1].split("=", 1)[1]))
    assert set(offers.RULES) == keys, set(offers.RULES) ^ keys
    c = offers.sanitize({"id": "a1", "name": "<b>Calm</b>", "reason": "x" * 900,
                         "settings": {"daily_max_loss": 5, "live": True, "api_key": "k", "pin": "1", "max_positions": 99,
                                      "risk_per_trade_frac": 5, "scalp_mode": "yes", "reentry": False}})
    assert c and set(c["settings"]) == {"max_positions", "risk_per_trade_frac", "reentry"}, c
    assert c["settings"]["max_positions"] == 8 and c["settings"]["risk_per_trade_frac"] == 0.40 and "<" not in c["name"] and len(c["reason"]) <= 400
    assert offers.sanitize({"id": "a", "name": "n", "settings": {"daily_max_loss": 1}}) is None
    assert offers.sanitize({"id": "", "name": "n", "settings": {"reentry": True}}) is None
    assert offers.diff(c, {"max_positions": 8, "reentry": True})[0]["key"] == "risk_per_trade_frac"
    # the collector's own copy of the whitelist must match
    import re as _re
    cs = (ROOT.parent / "SekexBot_Admin" / "..").resolve()
    for cand in (Path("/tmp/col/sekexbot_collector/collector.py"),):
        if cand.exists():
            m = _re.search(r"OFFER_KEYS = \{(.*?)\}", cand.read_text(), _re.S)
            assert set(_re.findall(r'"(\w+)"', m.group(1))) == keys


@test("Overnight Positions price: real recent trade beats the mid-quote; stale trade falls back to the mid")
def _():
    src = (ROOT / "server.py").read_text()
    assert "last_trades(" in src and '"px_src"' in src and 'px_age_s' in src
    assert "def last_trades" in (ROOT / "autobot" / "broker.py").read_text()
    assert "px_src" in (ROOT / "web" / "dashboard.html").read_text()


@test("24-hour Radar: new setup rules fire on the right shapes; buy/sell windows skip weekends; picks can be armed for a later day")
def _():
    from autobot import radar24 as r24
    from datetime import date, datetime, timedelta
    wk = lambda d: d.weekday() < 5
    assert r24.next_trading(date(2026, 10, 9), wk) == date(2026, 10, 12)                 # Friday -> Monday
    mk = lambda c, h=None, l=None, v=1000.0, o=None: {"c": c, "h": h or c * 1.004, "l": l or c * 0.996, "v": v, "o": o or c * 0.999}
    # steady up-trend with a 2.5% dip off the 5-day high
    rows = [mk(100 + i * 0.5) for i in range(40)]
    hi = rows[-1]["h"]; rows[-1] = mk(rows[-2]["c"] * 0.975, h=hi)
    f = r24._flags(rows, len(rows) - 1)
    assert "TREND_PULLBACK" in f and "RANGE_BREAKOUT" not in f, f
    # three down closes well under the 20-day average
    rows = [mk(100.0) for _ in range(30)] + [mk(97.5), mk(95.0), mk(92.0)]
    assert "OVERSOLD_BOUNCE" in r24._flags(rows, len(rows) - 1)
    # close above the 10-day high on 2x volume with a strong up day
    rows = [mk(100.0 + (i % 3) * 0.2, v=1000.0) for i in range(30)] + [mk(103.0, o=100.0, v=2500.0)]
    f = r24._flags(rows, len(rows) - 1)
    assert "RANGE_BREAKOUT" in f and "VOLUME_SURGE" in f, f
    # classic setups: windows come from the bar date, and a finished window is dropped
    ny = r24.NY
    now = datetime(2026, 10, 9, 21, 0, tzinfo=ny)                                          # Friday 9 PM
    r = {"mode": "PRE", "bar_date": "2026-10-09"}
    sc = r24.schedule_old(r, now, wk)
    assert sc["entry_from"] == datetime(2026, 10, 12, 4, 0, tzinfo=ny) and sc["exit_by"] == datetime(2026, 10, 12, 11, 0, tzinfo=ny), sc
    assert r24.schedule_old({"mode": "AFTER", "bar_date": "2026-10-09"}, now, wk) is None
    on = r24.schedule_old({"mode": "OVERNIGHT", "bar_date": "2026-10-09"}, now, wk)
    assert on["entry_from"] == now and on["exit_by"] == datetime(2026, 10, 12, 4, 0, tzinfo=ny), on
    assert r24.bucket(datetime(2026, 10, 12, 4, 0, tzinfo=ny)) == "PRE" and r24.bucket(datetime(2026, 10, 9, 21, 0, tzinfo=ny)) == "NIGHT"
    assert r24.fmt(datetime(2026, 10, 10, 9, 35, tzinfo=ny), datetime(2026, 10, 9, 21, 0, tzinfo=ny)) == "Tomorrow 9:35 AM"
    src = (ROOT / "autobot" / "engine.py").read_text()
    assert "def picks(self, upcoming=False)" in src and "def set_pick(self, sym, pick, day=None)" in src
    assert '"/api/radar24"' in (ROOT / "server.py").read_text() and "r24Card" in (ROOT / "web" / "dashboard.html").read_text()


@test("Reversal watch: a short that falls then bounces gets a cover alert, a profit-protect alert and a fading alert; alerts are capped")
def _():
    import tempfile
    from autobot.stockwatch import StockWatch
    w = StockWatch(tempfile.mktemp()); out = []
    w.add("X", "short", 35.18, 0.8, None, 35.18); w.w["X"]["qty"] = 1200
    for p in [35.0, 34.6, 34.2, 33.9, 33.78, 33.85, 33.95, 34.05, 34.12, 34.2, 34.1, 33.95]:
        w.tick("X", p, lambda t, b: out.append(t))
    assert any("bounced" in t for t in out) and any("protect" in t for t in out) and any("fading" in t for t in out), out
    n = len(out)
    for k in range(60):                                  # a choppy stock cannot flood the phone
        w.tick("X", 33.0 + (k % 2) * 1.0, lambda t, b: out.append(t))
    assert len(out) - n <= 8
    from autobot import review
    import pandas as pd, numpy as np
    assert review.review("ZZ", pd.DataFrame({"open": [1.0], "high": [1.0], "low": [1.0], "close": [1.0], "volume": [1]}, index=pd.DatetimeIndex(["2026-10-12 10:00"], tz="America/New_York")), review.NY and __import__("datetime").datetime.now(review.NY))["ok"] is False


@test("Open drive: finds a quiet pre-market that breaks out on a volume burst, builds a sane buy zone, and ignores quiet opens")
def _():
    import pandas as pd, numpy as np, datetime as dt, random
    from zoneinfo import ZoneInfo
    from autobot import opendrive as od
    NY=ZoneInfo("America/New_York"); rnd=random.Random(3)
    def day_bars(day, breakout, step, base=100.0):
        rows=[]; px=base
        for k in range(0,64):
            t=dt.datetime.combine(day,dt.time(4,0)).replace(tzinfo=NY)+dt.timedelta(minutes=15*k)
            reg=dt.time(9,30)<=t.time()<dt.time(16,0)
            c=px*(1+rnd.gauss(0,0.0015)); v=rnd.randint(2000,4000)
            if breakout and t.time()==dt.time(9,30): c=px*1.015; v=30000
            if breakout and t.time() in (dt.time(9,45),dt.time(10,0)): c=px*1.02; v=9000
            rows.append((t,px,max(px,c)*1.001,min(px,c)*0.999,c,v)); px=c
        return rows
    rows=[]; d0=dt.date(2026,8,3); n=0
    while n<30:
        d=d0+dt.timedelta(days=n)
        if d.weekday()<5: rows+=day_bars(d, n%3==0, 0)
        n+=1
    d15=pd.DataFrame(rows,columns=["t","open","high","low","close","volume"]).set_index("t")
    rec,base=od.history(d15); (lambda *a: None)("record",rec,"base",{k:round(v) for k,v in base.items()})
    assert rec["n"]>=4, rec
    # today: quiet premarket then spike
    today=dt.date(2026,9,14); r1=[]; px=100.0
    for m in range(0,330+4*60//1):
        pass
    t0=dt.datetime.combine(today,dt.time(4,0)).replace(tzinfo=NY); px=100.0
    for k in range(0,330):                      # 4:00..9:29
        px*=1+rnd.gauss(0,0.0003); r1.append((t0+dt.timedelta(minutes=k),px,px*1.0008,px*0.9992,px,300))
    for k in range(0,4):                        # 9:30..9:33 breakout
        o=px; px*=1.006; r1.append((t0+dt.timedelta(minutes=330+k),o,px*1.001,o*0.999,px,9000))
    d1=pd.DataFrame(r1,columns=["t","open","high","low","close","volume"]).set_index("t")
    now=dt.datetime.combine(today,dt.time(9,34)).replace(tzinfo=NY)
    c=od.detect("TST",d1,now,rec,base); (lambda *a: None)(c)
    assert c and c["rvol"]>=3 and c["zone"][0]<c["zone"][1] and c["stop"]<c["zone"][0] and c["tp1"]>c["zone"][1]
    quiet=d1[d1.index.time<dt.time(9,31)]
    assert od.detect("TST",quiet,now.replace(minute=31),rec,base) is None
    (lambda *a: None)("OK")


@test("Ollama AI provider: model list, chat through ai_post, ping, and provider switching (stub Ollama server)")
def _():
    import http.server, threading, json as _j, os as _o
    seen = {}
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            b = _j.dumps({"models": [{"name": "llama3.2:latest"}, {"name": "qwen2.5:7b"}]}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0)); seen["body"] = _j.loads(self.rfile.read(n)); seen["path"] = self.path
            b = _j.dumps({"choices": [{"message": {"content": "OK from ollama"}}], "model": seen["body"]["model"], "usage": {"prompt_tokens": 3, "completion_tokens": 4}}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
    srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    from autobot import analyst
    old = {k: _o.environ.get(k) for k in ("OLLAMA_BASE_URL", "OLLAMA_MODEL", "AI_PROVIDER", "ANTHROPIC_API_KEY", "OPENAI_API_KEY")}
    try:
        for k in ("OLLAMA_MODEL", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"): _o.environ.pop(k, None)
        _o.environ["OLLAMA_BASE_URL"] = f"http://127.0.0.1:{srv.server_port}/v1"; _o.environ["AI_PROVIDER"] = "ollama"; analyst._MODEL_CACHE.clear()
        assert analyst.provider() == "ollama" and analyst.ai_key() and analyst.ai_name() == "Ollama"
        assert analyst.ollama_models() == ["llama3.2:latest", "qwen2.5:7b"]
        r = analyst.ai_ping()
        assert r["ok"] and r["model"] == "llama3.2:latest" and r["models"], r
        assert seen["path"] == "/v1/chat/completions" and seen["body"]["messages"][-1]["content"] == "Reply OK"
        resp = analyst.ai_post(20, {"model": "qwen2.5:7b", "max_tokens": 50, "system": "s", "messages": [{"role": "user", "content": "hi"}]})
        assert resp.json()["content"][0]["text"] == "OK from ollama" and seen["body"]["model"] == "qwen2.5:7b" and seen["body"]["messages"][0]["role"] == "system"
        _o.environ["ANTHROPIC_API_KEY"] = "sk-ant-x"; _o.environ["AI_PROVIDER"] = "anthropic"
        assert analyst.provider() == "anthropic"                      # a chosen cloud AI still wins
        _o.environ["AI_PROVIDER"] = "ollama"
        assert analyst.provider() == "ollama"
        _o.environ["OLLAMA_BASE_URL"] = "http://127.0.0.1:9"; analyst._MODEL_CACHE.clear()
        bad = analyst.ai_ping()
        assert not bad["ok"] and "Ollama" in bad["error"]
    finally:
        for k, v in old.items():
            (_o.environ.__setitem__(k, v) if v is not None else _o.environ.pop(k, None))
        analyst._MODEL_CACHE.clear(); srv.shutdown()


@test("v2.12 day drives: lunch buy + mirrored short detect, windows, replay")
def _():
    import pandas as pd, numpy as np, datetime as dt, random
    from zoneinfo import ZoneInfo
    from autobot import daydrive as dd
    NY=ZoneInfo("America/New_York"); rnd=random.Random(5)
    def day15(day, kind):
        rows=[]; px=100.0
        for k in range(0,64):
            t=dt.datetime.combine(day,dt.time(4,0)).replace(tzinfo=NY)+dt.timedelta(minutes=15*k)
            c=px*(1+rnd.gauss(0,0.0012)); v=rnd.randint(3000,5000)
            tt=t.time()
            if kind=="lunch" and tt==dt.time(13,15): c=px*1.012; v=20000
            if kind=="lunch" and tt in (dt.time(13,30),dt.time(13,45)): c=px*1.006; v=9000
            if kind=="close" and tt==dt.time(15,15): c=px*1.012; v=22000
            if kind=="close" and tt in (dt.time(15,30),dt.time(15,45)): c=px*1.004; v=9000
            rows.append((t,px,max(px,c)*1.0005,min(px,c)*0.9995,c,v)); px=c
        return rows
    rows=[]; d0=dt.date(2026,8,3); n=0
    while n<40:
        d=d0+dt.timedelta(days=n)
        if d.weekday()<5: rows+=day15(d, "lunch" if n%4==0 else "close" if n%4==1 else "none")
        n+=1
    d15=pd.DataFrame(rows,columns=["t","open","high","low","close","volume"]).set_index("t")
    recs,slots=dd.records_for(d15)
    # live lunch detect
    today=dt.date(2026,9,15); t0=dt.datetime.combine(today,dt.time(4,0)).replace(tzinfo=NY); px=100.0; r1=[]
    for k in range(0,13*60-4*60+14):               # 4:00..13:13
        t=t0+dt.timedelta(minutes=k); 
        reg=dt.time(9,30)<=t.time()
        px*=1+rnd.gauss(0,0.0003); r1.append((t,px,px*1.0005,px*0.9995,px,rnd.randint(150,300) if reg else 40))
    for k in range(0,8):                           # surge 13:14..13:21 up 1.3%
        t=t0+dt.timedelta(minutes=13*60-4*60+14+k); o=px; px*=1.0017; r1.append((t,o,px*1.0003,o*0.9997,px,2500))
    d1=pd.DataFrame(r1,columns=["t","open","high","low","close","volume"]).set_index("t")
    now=dt.datetime.combine(today,dt.time(13,22)).replace(tzinfo=NY)
    c=dd.detect_lunch("TST",d1,now,recs,slots,3.0,0.8); print(c and {k:c[k] for k in("side","name","price","level","zone","stop","tp1","rvol","score","n","hits")})
    assert c and c["side"]=="up" and c["stop"]<c["zone"][0]<c["zone"][1]<c["tp1"]
    # mirrored down
    r2=[(t,2*100-o,2*100-l,2*100-h,2*100-cl,v) for (t,o,h,l,cl,v) in r1]
    d2=pd.DataFrame(r2,columns=["t","open","high","low","close","volume"]).set_index("t")
    c2=dd.detect_lunch("TST",d2,now,recs,slots,3.0,0.8); print(c2 and (c2["side"],c2["zone"],c2["stop"],c2["tp1"]))
    assert c2 and c2["side"]=="down" and c2["tp1"]<c2["zone"][0]<c2["zone"][1]<c2["stop"]
    assert dd.window_for(now)=="lunch" and dd.window_for(now.replace(hour=15,minute=40))=="close" and dd.window_for(now.replace(hour=22))=="overnight" and dd.window_for(now.replace(hour=11))==""
    
    rp = dd.replay(d15, "lunch")
    assert rp["n"] >= 3 and 0 <= rp["win_rate"] <= 100


@test("v2.12 autopilot rules, log-only default, 4-losers pause")
def _():
    import tempfile, pathlib
    from autobot.autopilot import Autopilot, DEFAULTS
    d = pathlib.Path(tempfile.mkdtemp())
    a = Autopilot(d / "c.json", d / "l.json")
    assert a.cfg["on"] is False and a.cfg["dry"] is True and a.cfg["shorts"] is False and "daily" not in " ".join(a.cfg)
    card = {"symbol": "ZZZ", "window": "open", "side": "up", "score": 80, "has_record": True, "n": 8, "hit_rate": 70}
    ctx = {"now_min": 600, "taken_n": 0, "open_n": 0, "spy_move": 0.2, "theme_open": {}, "held": set(), "shorts_ok": (True, "")}
    assert a.check(card, ctx)[0] is False                     # master switch off
    a.set_cfg({"on": True})
    assert a.check(card, ctx)[0] is True
    assert not a.check(dict(card, score=60), ctx)[0] and not a.check(dict(card, hit_rate=50), ctx)[0] and not a.check(dict(card, n=3), ctx)[0]
    assert not a.check(dict(card, side="down"), ctx)[0]       # shorts off
    assert not a.check(card, dict(ctx, now_min=16 * 60))[0]   # after last entry
    assert not a.check(card, dict(ctx, taken_n=3))[0] and not a.check(card, dict(ctx, open_n=2))[0]
    assert not a.check(card, dict(ctx, held={"ZZZ"}))[0]
    assert not a.check(card, dict(ctx, spy_move=-2.0))[0]
    assert not a.check(dict(card, window="overnight"), ctx)[0]  # overnight stays manual by default
    a.set_cfg({"min_score": 1, "max_day": 999, "spy_stop": 99})
    assert a.cfg["min_score"] >= 40 and a.cfg["max_day"] <= 20     # limits are clamped
    for _ in range(3):
        assert a.note_result("open", -10) is False
    assert a.note_result("open", -10) is True and not a.check(card, ctx)[0]
    a.set_cfg({"win": {"open": True}})
    assert a.check(card, ctx)[0]                              # switching the window on resumes it
    b = Autopilot(d / "c.json", d / "l.json"); assert b.cfg["on"] is True   # persists



@test("v2.14 peak learner picks the level that banks most; fallback; engine uses it; trade note enables re-entry")
def _():
    import tempfile, os
    from autobot import peaklearn
    f = os.path.join(tempfile.mkdtemp(), "pk.json")
    assert peaklearn.suggest(f, "CORD", "REGULAR") is None             # nothing learned yet -> fixed %
    for i in range(10):                                               # trades peak ~0.5% then fade to -0.2%
        peaklearn.record(f, "CORD", "REGULAR", 0.5 + (i % 3) * 0.02, -0.2)
    sg = peaklearn.suggest(f, "cord", "REGULAR")
    assert sg and 0.4 <= sg["pct"] <= 0.52 and sg["gain_avg"] > sg["now_avg"] and sg["n"] == 10, sg
    assert peaklearn.suggest(f, "SPY", "REGULAR") is None             # other stock: too few trips
    # engine: the learned level replaces the fixed one, and never lowers a wide-spread trade's own level
    import autobot.engine as en
    en.PEAK_FILE = type(en.PEAK_FILE)(f)
    from autobot.config import Settings
    class T: symbol = "CORD"; entry = 100.0; dir = 1; session = "REGULAR"; hv_pct = 0.0; peak_pct = 0.0; learn_pct = 0.0; qty = 10
    class E:
        s = Settings(); _slip_pct = lambda self: 0.0
        _learned_pct = lambda self: None
    e = E(); e.s.pct_harvest = True; e.s.harvest_learn = True
    t = T()
    pc = en.Engine._take_pct(e, t, 100.3)
    assert abs(pc - sg["pct"]) < 1e-9 and t.learn_pct == pc and t.peak_pct > 0.29
    e.s.harvest_learn = False
    assert en.Engine._take_pct(e, T(), None) == e.s.pct_harvest_pct
    t2 = T(); t2.hv_pct = 1.2; e.s.harvest_learn = True
    assert en.Engine._take_pct(e, t2, None) == 1.2


@test("v2.14 take-target: fires on exit P&L, bot trade closes with the harvest note, your trade is not re-entered")
def _():
    import server
    calls = []
    class Pos(dict): pass
    class B:
        def positions(self): return {"CORD": {"qty": 10, "avg_entry": 100.0, "price": 101.0, "upl": 10.0},
                                     "ZZZ": {"qty": 5, "avg_entry": 10.0, "price": 11.0, "upl": 5.0}}
    class T: pass
    class E:
        broker = B(); trades = {"CORD": T()}
        def event(self, *a, **k): pass
        def alert(self, *a, **k): pass
        def _slip_pct(self): return 0.0
    server.engine = E()
    server._session_name = lambda e: "REGULAR"
    server._quote = lambda e, s, ss: (100.7, 100.9) if s == "CORD" else (10.8, 10.9)
    server._close_now = lambda e, sym, pct=100, urgent=True, note="manual close": calls.append((sym, note))
    server._TK["targets"] = {"CORD": {"usd": 5.0}, "ZZZ": {"usd": 3.0}}
    server._TK["seen"] = {}
    server._tk_tick()
    assert ("CORD", "harvest") in calls and ("ZZZ", "take-target") in calls, calls
    assert "CORD" not in server._TK["targets"] and "ZZZ" not in server._TK["targets"]
    server._TK["targets"] = {"CORD": {"usd": 50.0}}
    calls.clear(); server._tk_tick()
    assert not calls and server._TK["targets"]["CORD"]["trace"]       # exit P&L (+7) below the target: keeps tracing


@test("v2.15 dashboard layout: cards never nest, merged cards keep their ids, controls grouped, broker.bars guards a future start")
def _():
    import re
    from html.parser import HTMLParser
    html = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "dashboard.html"), encoding="utf-8").read()
    h = re.sub(r"<script.*?</script>", "<script></script>", html, flags=re.S)
    h = re.sub(r"<style.*?</style>", "", h, flags=re.S)
    class P(HTMLParser):
        def __init__(s): super().__init__(); s.st = []; s.bad = []; s.ids = set()
        def handle_starttag(s, t, a):
            d = dict(a)
            if d.get("id"): s.ids.add(d["id"])
            if t in ("div", "details"):
                if "data-v" in d and "card" in (d.get("class") or "") and any(x[1] for x in s.st):
                    s.bad.append(d.get("id") or d.get("class"))
                s.st.append((t, "data-v" in d))
        def handle_endtag(s, t):
            if t in ("div", "details") and s.st: s.st.pop()
    p = P(); p.feed(h[h.index("<body"):])
    assert not p.bad and not p.st, (p.bad, len(p.st))
    for i in ("sessionsCard", "autoCard", "sessBar", "asCard", "sessCard", "preCard", "prepCard", "candCard", "reviewCard", "orderCard", "padCard",
              "ticket", "statsCard", "scoreCard", "tuneCard", "cnCard", "ctlCard", "ctlBody", "chartCard", "ptCard", "posCard", "openCard", "actCard", "whyCard", "lossCard",
              "pctHv", "reEnt", "pctLearn", "short245", "autoTune", "keepOn", "feed"):
        assert i in p.ids, i
    assert html.count('class="cgrp"') >= 6 and "function mgTab" in html and "function ctlToggle" in html
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "autobot", "broker.py")).read()
    assert "if start > now" in src


@test("v2.17.8 AI recovers by itself: retired model (404) re-picks and retries, busy (529) retries once; heartbeat gets a second try")
def _():
    import autobot.analyst as A, autobot.telemetry as T, os as _os
    seq = []
    class Rsp:
        def __init__(s, c, t="{}"): s.status_code, s.text = c, t
        def json(s): return {}
    calls = []
    def fake_post(url, **kw):
        calls.append(kw["json"]["model"]); return seq.pop(0)
    old = (A.requests.post, A.provider, A.ai_key, A._pick_model, dict(A._MODEL_CACHE)); _os.environ.pop("ANTHROPIC_MODEL", None)
    A.requests.post = fake_post; A.provider = lambda: "anthropic"; A.ai_key = lambda: "k"
    models = iter(["new-model"]); A._pick_model = lambda k: next(models)
    try:
        seq[:] = [Rsp(404), Rsp(200)]
        r = A.ai_post(5, {"model": "old-model", "max_tokens": 5, "messages": []})
        assert r.status_code == 200 and calls == ["old-model", "new-model"], calls
        calls.clear(); seq[:] = [Rsp(529), Rsp(200)]
        import time as _t; _sl = _t.sleep; _t.sleep = lambda x: None
        try:
            r = A.ai_post(5, {"model": "m", "max_tokens": 5, "messages": []})
        finally:
            _t.sleep = _sl
        assert r.status_code == 200 and calls == ["m", "m"]
    finally:
        A.requests.post, A.provider, A.ai_key, A._pick_model = old[:4]; A._MODEL_CACHE.clear(); A._MODEL_CACHE.update(old[4])
    n = []
    def p2(url, body, headers=None, timeout=20):
        n.append(1)
        if len(n) == 1: raise OSError("timed out")
        return 200, b"{}"
    op = T._post; T._post = p2; ts = T.time.sleep; T.time.sleep = lambda x: None
    try:
        from types import SimpleNamespace as NS
        rp = T.Reporter.__new__(T.Reporter); rp.s = NS(collector_url="https://x.example", share_diagnostics=True, diag_label="", live=False, level=None)
        rp.app_state_fn = lambda: {}; rp.last_ok = 0; rp.last_error = ""; rp.sent = 0
        rp.send_now(); assert rp.sent == 1 and len(n) == 2 and rp.last_error == ""
    finally:
        T._post = op; T.time.sleep = ts


@test("v2.17.5 spread: harvest orders start at the middle and walk to the far side, stops always cross, wide spreads block re-entry and auto-arm")
def _():
    import server, time as _t
    assert server._hv_px(10.00, 10.10, "buy", 1) == 10.05 and server._hv_px(10.00, 10.10, "buy", 2) == 10.07 and server._hv_px(10.00, 10.10, "buy", 3) == 10.10
    assert server._hv_px(10.00, 10.10, "sell", 1) == 10.05 and server._hv_px(10.00, 10.10, "sell", 3) == 10.0
    orders = []
    class B:
        def cancel_symbol_orders(self, s): pass
        def manual_order(self, sym, side, qty, typ, **k): orders.append((side, typ, k.get("limit_price")))
        def close_qty(self, s, q): orders.append(("close", "market", None))
    e = type("E", (), {"broker": B()})()
    server._hv_close(e, "ZZZ", 10, "buy", "REGULAR", 10.00, 10.10, 1); assert orders[-1] == ("sell", "limit", 10.05), orders
    server._hv_close(e, "ZZZ", 10, "buy", "REGULAR", 10.00, 10.10, 1, True); assert orders[-1][0] == "close"       # protective stop: cross at once
    server._hv_close(e, "ZZZ", 10, "buy", "REGULAR", 10.00, 10.10, 3); assert orders[-1][0] == "close"
    # wide spread blocks the automatic start
    armed = []
    class Hv:
        jobs = {}
        def arm(self, *a, **k): armed.append(a)
    old = server.harvester; server.harvester = Hv()
    try:
        from types import SimpleNamespace as NS
        ee = NS(trades={}, risk=NS(halted=False), manual_syms={}, broker=NS(now=lambda: __import__("datetime").datetime.now()), event=lambda *a, **k: None)
        pos = {"qty": 10, "avg_entry": 100.0}
        server.settings.max_spread_pct = 0.15
        server._ah_watch(ee, "AAA", pos, {"green_since": 0}, 0.5, "REGULAR", 5000.0, 0.40); assert not armed
        server._ah_watch(ee, "AAA", pos, {"green_since": 0}, 0.5, "REGULAR", 5000.0, 0.05); assert len(armed) == 1
    finally:
        server.harvester = old


@test("v2.17.3 jump list: newest card per stock, WEAK jump-ins hidden unless turned off, jump-outs always kept")
def _():
    import server
    mk = lambda sym, kind, tm, lab, day="d": {"symbol": sym, "kind": kind, "t": tm, "label": lab, "day": day}
    items = [mk("LMT", "in", "14:10", "WEAK"), mk("LMT", "in", "14:25", "GOOD"), mk("PANW", "in", "14:25", "WEAK"), mk("AAA", "out", "14:00", "WEAK"), mk("AAA", "out", "13:50", "WEAK")]
    r = server._jp_tidy(items, True)
    assert [(x["symbol"], x["t"]) for x in r] == [("LMT", "14:25"), ("AAA", "14:00")], r
    r2 = server._jp_tidy(items, False)
    assert {x["symbol"] for x in r2} == {"LMT", "PANW", "AAA"} and len(r2) == 3


@test("v2.17.1 sekex repo menu: needed files are locked, old and other files are listed, picks parse, deletes go through the API")
def _():
    import sys as _s
    _s.path.insert(0, str(ROOT / "bin"))
    import sekex_repo as R
    tree = [{"path": p, "sha": "s" + str(i), "size": 1000} for i, p in enumerate([
        "latest.json", "SekexBot_Setup.sh", "SekexBot_Android_v2.17.0.zip", "SekexBot_Android_v2.16.0.zip", "SekexBot_Android_v2.15.2.zip",
        "SekexBot_Android_Release_Notes_and_Install_v2.17.0.pdf", "SekexBot_Android_Release_Notes_and_Install_v2.16.0.pdf",
        "admin_v2.17.0.enc", "admin_v2.16.0.enc", "notes/old.txt", "README.md"])]
    keep, old, other = R.classify(tree, {"version": "2.17.0", "url": "SekexBot_Android_v2.17.0.zip", "admin": {"url": "admin_v2.17.0.enc"}})
    assert {t["path"] for t in keep} == {"latest.json", "SekexBot_Setup.sh", "SekexBot_Android_v2.17.0.zip", "SekexBot_Android_Release_Notes_and_Install_v2.17.0.pdf", "admin_v2.17.0.enc"}, keep
    assert [t["path"] for t in old] == ["SekexBot_Android_v2.15.2.zip", "SekexBot_Android_v2.16.0.zip", "SekexBot_Android_Release_Notes_and_Install_v2.16.0.pdf", "admin_v2.16.0.enc"] or len(old) == 4, old
    assert {t["path"] for t in other} == {"notes/old.txt", "README.md"}
    assert R.parse_picks("1 3 5-7, 99", 8) == {1, 3, 5, 6, 7}
    calls = []
    def gh(method, path, tok, body=None): calls.append((method, path, body["sha"])); return 200, {}
    n = R.delete_files({"repo": "o/r", "token": "t", "branch": "main"}, other, False, gh)
    assert n == 2 and calls[0][0] == "DELETE" and ("DELETE", "/repos/o/r/contents/notes/old.txt", "s9") in calls
    assert R.delete_files({"repo": "o/r", "token": "t", "branch": "main"}, other, True, gh) == 0 and len(calls) == 2
    assert 'cmd in ("repo", "github")' in (ROOT / "bin" / "sekex_admin.py").read_text() and "sekex_repo.py" in (ROOT / "bin" / "sekex").read_text()


@test("v2.17 Robinhood alerts: profit $, stop price and time fire once, sold positions drop their alerts, layout keeps positions first")
def _():
    import server, re
    class FakeRH:
        connected = True
        def tools(self): return [{"name": "get_positions", "write": False, "inputSchema": {"required": ["account_number"]}}]
        def call(self, tool, args): return {"content": [{"type": "text", "text": json.dumps({"data": {"positions": POS}})}]}
    POS = [{"symbol": "NIO", "quantity": "12", "average_buy_price": "5.20", "last_trade_price": "5.36"}]
    sent = []
    class E:
        def alert(self, *a, **k): sent.append(a[1])
        def event(self, *a, **k): pass
    old = (server.rh, server.engine, dict(server._RHW)); server.rh = FakeRH(); server.engine = E()
    import autobot.rhmcp as rm
    old_rt = rm.result_text; rm.result_text = lambda r: (json.loads(r["content"][0]["text"]), "")
    try:
        server._RHW.clear()
        server._RHW["a"] = {"symbol": "NIO", "acct": "1", "tool": "get_positions", "usd": 1.5}          # P&L is +1.92
        server._RHW["b"] = {"symbol": "NIO", "acct": "1", "tool": "get_positions", "below": 5.0}          # not reached
        server._RHW["c"] = {"symbol": "F", "acct": "1", "tool": "get_positions", "usd": 5}                # not held any more
        server._rhw_tick()
        assert len(sent) == 1 and "NIO" in sent[0] and "a" not in server._RHW and "c" not in server._RHW and "b" in server._RHW, (sent, server._RHW)
        server._rhw_tick(); assert len(sent) == 1
        POS[0]["last_trade_price"] = "4.90"; server._rhw_tick()
        assert len(sent) == 2 and not server._RHW
    finally:
        server.rh, server.engine = old[0], old[1]; rm.result_text = old_rt; server._RHW.clear(); server._RHW.update(old[2])
    html = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "dashboard.html"), encoding="utf-8").read()
    c = html[html.index('id="rhCard"'):]
    assert c.index('id="rhHoldW"') < c.index('id="rhDecide"') < c.index('id="rhOrdW"') < c.index('id="rhEasy"') < c.index('id="rhQuick"'), "Robinhood tab order"


@test("v2.16 automatic profit-taking on your own trades: arms after steady profit, honors Stop, auto jobs never stop out at a loss, learned level banks")
def _():
    import time as _t
    import server
    from types import SimpleNamespace as NS
    h, e, st, calls = _fake_harvest()
    # auto job: down 3 A -> a normal job would protective-stop; an auto job holds
    h.learn_fn = None
    h.arm("ZZZ", "buy", 10, auto=True)
    j = h.jobs["ZZZ"]; now = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", now); assert j["phase"] == "holding"
    st["bid"], st["ask"] = 98.40, 98.42
    h.step(e, j, e.broker.positions(), "REGULAR", now + 5); h.step(e, j, e.broker.positions(), "REGULAR", now + 40)
    assert not calls and j["phase"] == "holding", (calls, j)
    # learned level: +0.2% of entry (=0.2) is below 0.5 A (0.25) but the learned level is 0.15%
    h2, e2, st2, calls2 = _fake_harvest()
    h2.learn_fn = lambda *a: 0.15
    h2.arm("ZZZ", "buy", 10, auto=True); j2 = h2.jobs["ZZZ"]
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", now)
    st2["bid"], st2["ask"] = 100.20, 100.21
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", now + 5)
    assert calls2 and calls2[0][0] == "close", calls2
    # server side auto-watch: green for 30 s arms it, a Stop is respected, options/fractional are left alone
    armed = []
    class Hv:
        jobs = {}
        def arm(self, *a, **k): armed.append((a, k))
    server.harvester, old = Hv(), server.harvester
    try:
        ee = NS(trades={}, risk=NS(halted=False), manual_syms={}, broker=NS(now=lambda: __import__("datetime").datetime.now()), event=lambda *a, **k: None)
        server.settings.auto_harvest_manual = True
        pos = {"qty": 10, "avg_entry": 100.0}
        sn = {}
        server._ah_watch(ee, "AAPL", pos, sn, 0.3, "REGULAR", 1000.0); assert not armed
        server._ah_watch(ee, "AAPL", pos, sn, 0.3, "REGULAR", 1031.0); assert len(armed) == 1 and armed[0][1].get("auto") is True
        server._ah_watch(ee, "AAPL", pos, {"green_since": 0}, 0.05, "REGULAR", 2000.0)       # fell below green: no arm
        server._AH_SKIP.add("MSFT"); server._ah_watch(ee, "MSFT", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "AAPL250117C00200000", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "NVDA", {"qty": 2.5, "avg_entry": 1.0}, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "TSLA", pos, {"green_since": 0}, 0.5, "OVERNIGHT", 2000.0)
        assert len(armed) == 1, armed
        server.settings.auto_harvest_manual = False
        server._ah_watch(ee, "AMD", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0); assert len(armed) == 1
    finally:
        server.harvester = old; server.settings.auto_harvest_manual = True


@test("v2.15 sekex_done: Setup.sh and latest.json renamed to .old once a version is installed AND published (admin phone), or just installed (normal phone)")
def _():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    def run(home, what, ver):
        env = dict(os.environ, HOME=home)
        return subprocess.run([sys.executable, os.path.join(root, "bin", "sekex_done.py"), what, ver], env=env, capture_output=True, text=True, timeout=30).stdout
    def mk(home, admin):
        dl = os.path.join(home, "storage", "downloads"); os.makedirs(dl); os.makedirs(os.path.join(home, ".sekexbot"))
        open(os.path.join(dl, "SekexBot_Setup.sh"), "w").write("#!/bin/sh\n# SekexBot one-file installer.  Version 2.15.0\n")
        open(os.path.join(dl, "SekexBot_Setup(1).sh"), "w").write("#!/bin/sh\n# SekexBot one-file installer.  Version 2.16.0\n")
        open(os.path.join(dl, "latest.json"), "w").write(json.dumps({"version": "2.15.0"}))
        if admin: open(os.path.join(home, ".sekexbot", "github.json"), "w").write(json.dumps({"token": "x"}))
        return dl
    h = tempfile.mkdtemp(); dl = mk(h, True)
    run(h, "updated", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json")) and os.path.exists(os.path.join(dl, "SekexBot_Setup.sh"))     # admin phone: not published yet
    out = run(h, "published", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json.old")) and os.path.exists(os.path.join(dl, "SekexBot_Setup.sh.old")), out
    assert os.path.exists(os.path.join(dl, "SekexBot_Setup(1).sh")), "a newer version's installer must be left alone"
    h = tempfile.mkdtemp(); dl = mk(h, False)
    run(h, "updated", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json.old")) and not os.path.exists(os.path.join(dl, "latest.json"))


@test("v2.14.3 jump card builds with the stock's record (regression: price was passed as the record)")
def _():
    import server
    sg = {"kind": "in", "side": "up", "name": "Pullback retest", "why": "x", "t": "10:00", "price": 100.0, "zone": [99.9, 100.1], "stop": 99.5, "tp1": 101, "tp2": 102, "atr": 0.3}
    c = server._jp_card(None, sg, "AAA", {"up": {"n": 10, "hit": 7, "fail": 3}, "down": {"n": 0, "hit": 0, "fail": 0}}, 100.2)
    assert c["n"] == 10 and c["hits"] == 7 and c["has_record"] and c["price"] == 100.2
    c = server._jp_card(None, sg, "AAA", None, 100.2)
    assert not c["has_record"]


@test("v2.13 jump signals: pullback retest buy/short, don't chase, exits, record")
def _():
    import pandas as pd, numpy as np, datetime as dt
    from zoneinfo import ZoneInfo
    from autobot import jump
    NY = ZoneInfo("America/New_York"); rng = np.random.default_rng(3)
    rows = []; d0 = dt.date(2026, 8, 3); n = 0
    while n < 45:
        d = d0 + dt.timedelta(days=n); n += 1
        if d.weekday() >= 5:
            continue
        px = 100 + rng.normal(0, 2); t0 = dt.datetime.combine(d, dt.time(9, 30)).replace(tzinfo=NY)
        for k in range(78):
            c = px * (1 + 0.0006 * np.sin(k / 9) + rng.normal(0, 0.0012)); v = int(abs(rng.normal(5000, 1500)) * (1 + (3 if rng.random() < 0.04 else 0)))
            rows.append((t0 + dt.timedelta(minutes=5 * k), px, max(px, c) * 1.0008, min(px, c) * 0.9992, c, v)); px = c
    d5 = pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
    sg = jump.scan(d5)
    ins = [s for s in sg if s["kind"] == "in"]
    assert any(s["side"] == "up" for s in ins) and any(s["side"] == "down" for s in ins)
    for s in ins:
        if s["side"] == "up":
            assert s["stop"] < s["zone"][0] <= s["zone"][1] < s["tp1"] < s["tp2"]
        else:
            assert s["stop"] > s["zone"][1] >= s["zone"][0] > s["tp1"] > s["tp2"]
    assert any(s["kind"] == "out" for s in sg)
    rec = jump.record(d5)
    for sd in ("up", "down"):
        r = rec[sd]; assert r["n"] == r["hit"] + r["fail"] and r["n"] > 5
    # a vertical burst bar is flagged as "don't chase"
    d6 = d5.iloc[:60].copy(); last = d6.index[-1]; px = float(d6["close"].iloc[-1])
    d6.loc[last, ["high", "close", "volume"]] = [px * 1.03, px * 1.028, 60000]
    assert any(s["kind"] == "chase" and s["i"] == 59 for s in jump.scan(d6))
    assert "jump" in __import__("autobot.alerts", fromlist=["KINDS"]).KINDS



@test("v2.17.9 gear screen: Broker settings, App Updates, one tabbed Help & AI card; check-up runs in the background")
def _():
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("Broker settings", 'id="updSec"', 'id="haiSec"', "haiTab('ask')", "haiTab('fix')", 'data-t="chk"'):
        assert k in h, k
    assert h.count("<h2 style=\"margin-top:18px\" id=\"cuSec\"") == 0 and 'id="cuSec"' in h and 'id="fixSec"' in h and 'id="revSec"' in h
    sv = open(ROOT / "server.py", encoding="utf-8").read()
    assert "threading.Thread(target=lambda: _checkup.run" in sv


@test("v2.17.10 early warnings are tappable: BUY?/SELL? boxes get hit areas, ask first even in Auto, flat or held picks buy/short/close")
def _():
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("CH.ph.push(", "earlyTap(hb.p, hb.price)", "function earlyAct(", "if (mode == 'auto' && !early)"):
        assert k in h, k


@test("v2.18 custom presets: AI values are clamped, patterns scan + back-test, review ranks, PAPER-only auto-trade places one sized order")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from autobot import presets as P
    r = P.normalize({"pattern": "evil", "side": "x", "stop_pct": 99, "target_r": -3, "vol_mult": 50, "lookback": 1, "position_size": 1000, "daily_max_loss": 0})
    assert r["pattern"] == "pullback" and r["side"] == "long" and r["stop_pct"] == 5.0 and r["target_r"] == 0.5 and r["vol_mult"] == 5.0 and r["lookback"] == 5
    assert "position_size" not in r and "daily_max_loss" not in r
    idx = pd.date_range("2026-10-12 04:00", periods=900, freq="5min", tz="America/New_York"); idx = idx[(idx.hour >= 4) & (idx.hour < 20)]
    rng = np.random.default_rng(1); c = 30 + np.cumsum(rng.normal(0, .08, len(idx)))
    d = pd.DataFrame({"open": c - .02, "high": c + .07, "low": c - .07, "close": c, "volume": rng.integers(500, 5000, len(idx))}, index=idx)
    for pat in P.PATTERNS:
        rr = P.normalize({"pattern": pat, "side": "both", "vol_mult": .5, "gap_pct": .5}); sg = P.scan(rr, d); t = P.backtest(rr, d, sigs=sg)
        assert t["n"] == len(t and sg) or t["n"] <= len(sg)
        import json as _j; _j.dumps(t)                                    # numpy values must not leak into the JSON store
        for s_ in sg:
            assert (s_["stop"] < s_["price"] < s_["tp1"]) if s_["side"] == "up" else (s_["tp1"] < s_["price"] < s_["stop"])
    rb = P.normalize({"pattern": "breakout", "side": "both", "vol_mult": .5}); sg = P.scan(rb, d); assert sg
    ch = P.chart(d, sg, focus=sg[-1]); assert ch["bars"] and ch["marks"]
    P.FILE = pathlib.Path(tempfile.mkdtemp()) / "presets.json"
    p1 = P.add(rb, auto_paper=True); assert P.load()["presets"][0]["id"] == p1["id"] and p1["auto_paper"]
    items = P.review(lambda s: d, ["AAA", "BBB"], P.load()["presets"], None)
    assert all(x["symbol"] in ("AAA", "BBB") and x["chart"] for x in items)
    P.update(p1["id"], enabled=False); assert P.review(lambda s: d, ["AAA"], P.load()["presets"], None) == []
    P.delete(p1["id"]); assert not P.load()["presets"]
    assert P.keyword_rules("short the gap with a 2% stop")["pattern"] == "gap_go"
    import server
    placed = []
    server._jp_place = lambda e, sym, up, px, stop=None, target=None, qty=0: placed.append((sym, up, px, stop, target)) or {"msg": "ok"}
    P.FILE = pathlib.Path(tempfile.mkdtemp()) / "presets.json"; P.add(rb, auto_paper=True)
    last = sg[-1]; dd = d.iloc[:last["i"] + 1]
    class E_: mode = "PAPER"; running = True
    class Now:
        def date(self): return dd.index[-1].date()
        def strftime(self, f): return "Mon 1:00 PM"
    import datetime as _dt
    class NowD(_dt.datetime): pass
    now = dd.index[-1].to_pydatetime()
    e = E_(); e.broker = type("B", (), {"bars5": lambda s, sym, days: dd.iloc[:-60]})()
    server._PR.update(auto_day="", fired=[], hist={}, auto_n=0)
    server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert placed, "paper preset should place an order"
    assert placed[0][1] == (last["side"] == "up")
    n1 = len(placed); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == n1, "once per stock per preset per day"
    e.mode = "LIVE"; server._PR.update(fired=[], armed=""); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == n1, "LIVE needs today's PIN arming"
    server._PR.update(fired=[], armed=str(now.date())); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == n1 + 1, "armed LIVE trades"
    e.running = False; server._PR.update(fired=[], auto_n=0); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == n1 + 1, "Auto-trader OFF: presets do not trade"
    e.running = True
    server._PR.update(fired=[], auto_n=0); e.mode = "PAPER"; n2 = len(placed); server._pr_live(e, "AAA", dd.iloc[-60:], "up", now, "REGULAR"); assert len(placed) == n2, "not while holding it"


@test("v2.18.1 smart-money preset: sweep + CHoCH + FVG retest finds ordered setups with a structure stop, and builds a chart with zone marks")
def _():
    import numpy as np, pandas as pd
    from autobot import presets as P
    assert "smc" in P.PATTERNS and P.keyword_rules("liquidity sweep with fvg")["pattern"] == "smc" and P.normalize({"pattern": "smc"})["pattern"] == "smc"
    idx = pd.date_range("2026-10-12 04:00", periods=2000, freq="5min", tz="America/New_York"); idx = idx[(idx.hour >= 4) & (idx.hour < 20)]
    rng = np.random.default_rng(0); c = 30 + np.cumsum(rng.normal(0, .12, len(idx)))
    d = pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c + abs(rng.normal(0, .08, len(c))), "low": c - abs(rng.normal(0, .08, len(c))), "close": c, "volume": rng.integers(500, 5000, len(c))}, index=idx)
    r = P.normalize({"pattern": "smc", "side": "both"}); sg = P.scan(r, d); assert sg
    for x in sg:
        assert x["sweep"] < x["choch"] < x["i"] and x["zone"][0] < x["zone"][1]
        assert (x["stop"] < x["price"] < x["tp1"]) if x["side"] == "up" else (x["tp1"] < x["price"] < x["stop"])
    ch = P.chart(d, sg, focus=sg[-1]); assert ch["marks"][-1].get("zone") and "sw" in ch["marks"][-1]
    assert ch["marks"][-1]["zl"] == "FVG zone" and "m.zl" in open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()


@test("v2.18.2 zone retest / support bounce preset + presets follow the Auto-trader: scans the whole universe, LIVE needs PIN arming")
def _():
    import numpy as np, pandas as pd
    from autobot import presets as P
    idx = pd.date_range("2026-10-12 04:00", periods=2000, freq="5min", tz="America/New_York"); idx = idx[(idx.hour >= 4) & (idx.hour < 20)]
    rng = np.random.default_rng(0); c = 30 + np.cumsum(rng.normal(0, .12, len(idx)))
    d = pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c + abs(rng.normal(0, .08, len(c))), "low": c - abs(rng.normal(0, .08, len(c))), "close": c, "volume": rng.integers(500, 5000, len(c))}, index=idx)
    r = P.normalize({"pattern": "zone", "side": "both"}); sg = P.scan(r, d); assert sg and "zone" in P.PATTERNS
    for x in sg:
        assert x["zone"][0] < x["zone"][1] and ((x["stop"] < x["price"] < x["tp1"]) if x["side"] == "up" else (x["tp1"] < x["price"] < x["stop"]))
    assert P.chart(d, sg, focus=sg[-1])["marks"][-1]["zone"] and P.keyword_rules("buy the retest of support")["pattern"] == "zone"
    sv = open(ROOT / "server.py", encoding="utf-8").read()
    for k in ("def _pr_universe_pass", "/api/presets/arm", 'not getattr(e, "running", False)', "pin_ok(r.pin)", "_pr_universe_pass(e, now, sess, syms, pos, _st)"):
        assert k in sv, k


@test("v2.18.3 options in plain words: three levels set every limit in dollars, no percent boxes, stock groups, fine-tune in dollars")
def _():
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("function optLevel(", "function optGroup(", "function optDollar(", 'id="optTpD"', 'id="optSlD"', "How bold should it be?", "Which stocks?", "Fine-tune"):
        assert k in h, k
    assert 'id="optTp"' not in h and 'id="optSl"' not in h and "Take profit %" not in h and "Stop %" not in h
    import re
    lv = h[h.index("const OPT_LV"):h.index("const OPT_GRP")]
    for name in ("careful", "balanced", "bold"):
        assert name in lv
    for key in ("daily_budget", "max_premium", "max_positions", "max_stocks", "max_per_stock", "max_calls", "max_puts", "max_contracts", "tp_pct", "stop_pct"):
        assert lv.count(key + ":") == 3, key
    import server
    for k in ("daily_budget", "max_premium", "max_positions", "max_stocks", "max_per_stock", "max_calls", "max_puts", "max_contracts", "tp_pct", "stop_pct"):
        assert k in server.OptionsCfg.model_fields, k


@test("v2.19 more patterns: candles, head and shoulders, double top, triangle, trend line, MA cross, RSI; chop filter, zone grade, autonomous mode")
def _():
    import numpy as np
    import pandas as pd
    from autobot import presets as pr
    for k in ("candle", "hs", "dbl", "tri", "tline", "macross", "rsi_turn"):
        assert k in pr.PATTERNS and pr.normalize({"pattern": k})["pattern"] == k, k
    assert all(pr.normalize({"pattern": k})["pattern"] == "candle" and k not in pr.PATTERNS for k in ("engulfing", "hammer", "star", "inside3", "outside3"))      # v2.32: old saved presets map to the one candle pattern
    assert pr.normalize({"pattern": "bogus"})["pattern"] == "pullback" and pr.normalize({"stop_pct": 99})["stop_pct"] == 5.0
    n = 78 * 12
    rng = np.random.default_rng(5)
    idx = []
    for d in pd.bdate_range("2026-08-03", periods=12):
        idx += list(pd.date_range(d.strftime("%Y-%m-%d") + " 09:30", periods=78, freq="5min", tz="America/New_York"))
    c = 100 + np.cumsum(rng.normal(0, 0.25, n))
    o = np.r_[c[0], c[:-1]]
    d5 = pd.DataFrame({"open": o, "high": np.maximum(o, c) + 0.12, "low": np.minimum(o, c) - 0.12, "close": c, "volume": rng.integers(1000, 9000, n)}, index=pd.DatetimeIndex(idx))
    tot = 0
    for r in pr.auto_rules():
        sg = pr.scan(r, d5)
        bt = pr.backtest(r, d5, sigs=sg)
        assert isinstance(bt["n"], int)
        for x in sg:
            assert x["stop"] != x["price"] and (x["side"] == "up") == (x["tp1"] > x["price"]) and (x["side"] == "up") == (x["stop"] < x["price"]), (r["pattern"], x)
        tot += len(sg)
    assert tot > 20, tot
    ch = pr.chart(d5, [], focus=None)
    assert "g" in ch["bars"][0]
    # chop filter blocks signals in a flat stretch
    flat = d5.copy()
    flat["close"] = 100 + np.sin(np.arange(n) / 3.0) * 0.05
    flat["open"] = np.r_[flat["close"].iloc[0], flat["close"].values[:-1]]
    flat["high"] = np.maximum(flat["open"], flat["close"]) + 0.2
    flat["low"] = np.minimum(flat["open"], flat["close"]) - 0.2
    r = pr.normalize({"pattern": "breakout", "side": "both", "chop_skip": True, "vol_mult": 0})
    assert len(pr.scan(r, flat)) == 0
    # a planted head and shoulders is found
    pts = [103, 101.2, 105, 101.2, 103, 100.2, 98.5]
    path = list(100 + np.cumsum(rng.normal(0, 0.03, 60)))
    cur = path[-1]
    for t in pts:
        path += list(np.linspace(cur, t, 7)[1:])
        cur = t
    cc = np.array(path)
    ix = pd.date_range("2026-09-01 09:30", periods=len(cc), freq="5min", tz="America/New_York")
    oo = np.r_[cc[0], cc[:-1]]
    hs = pd.DataFrame({"open": oo, "high": np.maximum(oo, cc) + 0.04, "low": np.minimum(oo, cc) - 0.04, "close": cc, "volume": 5000}, index=ix)
    s = pr.scan(pr.normalize({"pattern": "hs", "side": "both", "chop_skip": False}), hs)
    assert any(x["name"] == "Head & shoulders" and x["side"] == "down" for x in s), s
    # autonomous mode: switch, rules, record gate
    import tempfile
    from pathlib import Path
    old = pr.FILE
    pr.FILE = Path(tempfile.mkdtemp()) / "presets.json"
    try:
        assert not pr.autonomous_on()
        pr.autonomous_set(True)
        assert pr.autonomous_on()
        ar = pr.auto_rules()
        assert len(ar) == len(pr.PATTERNS) and all(a["side"] == "both" and a["auto"] for a in ar)
        assert pr.good_record({"n": 14, "avg_r": 0.4, "rate": 60, "avg_old": 0.3, "avg_new": 0.5}) and not pr.good_record({"n": 5, "avg_r": 0.9, "rate": 100, "avg_old": 1, "avg_new": 1})    # v2.32: 12+ cases, both halves positive
        assert not pr.good_record({"n": 14, "avg_r": -0.2, "rate": 60, "avg_old": 0.3, "avg_new": 0.5}) and not pr.good_record({"n": 14, "avg_r": 0.3, "rate": 30, "avg_old": 0.3, "avg_new": 0.3})
        assert not pr.good_record({"n": 14, "avg_r": 0.5, "rate": 60, "avg_old": 1.1, "avg_new": -0.1}) and not pr.good_record({"n": 14, "avg_r": 0.5, "rate": 60})   # a lucky streak in one half is not a record
    finally:
        pr.FILE = old
    for t, p_ in (("engulfing candle", "candle"), ("head and shoulders", "hs"), ("double bottom", "dbl"), ("trend line break", "tline")):
        assert pr.keyword_rules(t)["pattern"] == p_, t
    sv = open(ROOT / "server.py", encoding="utf-8").read()
    for k in ("/api/presets/autonomous", "pr.autonomous_on()", "pr.good_record(t)", "_auto=True"):
        assert k in sv, k
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("function prAutonomous(", "function prAutoPaint(", "PR_GROUPS", "Autonomous: bot picks the patterns", "gray = choppy"):
        assert k in h, k


@test("v2.19 autonomous: no saved preset needed, trades only patterns with a good record on that stock, once per stock per day, honors Auto-trader and PIN")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from autobot import presets as P
    import server
    idx = pd.date_range("2026-10-12 04:00", periods=900, freq="5min", tz="America/New_York"); idx = idx[(idx.hour >= 4) & (idx.hour < 20)]
    rng = np.random.default_rng(1); c = 30 + np.cumsum(rng.normal(0, .08, len(idx)))
    d = pd.DataFrame({"open": c - .02, "high": c + .07, "low": c - .07, "close": c, "volume": rng.integers(500, 5000, len(idx))}, index=idx)
    rb = P.normalize({"pattern": "breakout", "side": "both", "vol_mult": .5, "chop_skip": False}); sg = P.scan(rb, d); assert sg
    last = sg[-1]; dd = d.iloc[:last["i"] + 1]
    old = (P.FILE, P.auto_rules, P.good_record, server._jp_place)
    placed = []
    try:
        P.FILE = pathlib.Path(tempfile.mkdtemp()) / "presets.json"
        P.auto_rules = lambda: [dict(rb, id="auto_breakout", enabled=True, auto_paper=True, auto=True, name="Auto · Breakout")]
        server._jp_place = lambda e, sym, up, px, stop=None, target=None, qty=0: placed.append((sym, up)) or {"msg": "ok"}
        class E_: mode = "PAPER"; running = True
        e = E_(); e.broker = type("B", (), {"bars5": lambda s, sym, days: dd.iloc[:-60]})()
        now = dd.index[-1].to_pydatetime()
        P.autonomous_set(False); server._PR.update(auto_day="", fired=[], hist={}, auto_n=0, rec={}, rn=0, hn=0)
        P.good_record = lambda t: True
        server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert not placed, "Autonomous OFF and no saved preset: no trade"
        P.autonomous_set(True); server._PR.update(auto_day="", fired=[], hist={}, auto_n=0, rec={}, rn=0, hn=0)
        P.good_record = lambda t: False
        server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert not placed, "no good record: no trade"
        server._PR.update(auto_day="", fired=[], hist={}, auto_n=0, rec={}, rn=0, hn=0)
        P.good_record = lambda t: True
        server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == 1 and placed[0][1] == (last["side"] == "up"), placed
        server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == 1, "once per stock per day"
        e.mode = "LIVE"; server._PR.update(fired=[], armed=""); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == 1, "LIVE needs PIN arming"
        e.mode = "PAPER"; e.running = False; server._PR.update(fired=[]); server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR"); assert len(placed) == 1, "Auto-trader OFF"
    finally:
        P.FILE, P.auto_rules, P.good_record, server._jp_place = old


@test("v2.19.1 Robinhood tab shows only the Agentic (MCP) account with its cash and buying power; holdings, orders and overview are filtered to it")
def _():
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("function rhNum(", "function rhPickNum(", "function rhFindAccts(", "function rhOnly(", "const rhIsAg", "async function rhAcctFacts(", "(the only one shown here)",
              "Cash ${m(f.cash)} · Buying power ${m(f.bp)}", "Which one is your Agentic (MCP) account?", "rhOnly(l, a.account_number)", "await rhAcctGet(); rhHoldGet()", "function rhHoldTool(", "Stocks I own", "VIEW ONLY", "Also show my other Robinhood accounts"):
        assert k in h, k
    assert "RH.acct = (ag[0] || list[0] || {})" not in h, "must not fall back to another account"


@test("v2.19.3 publish survives a dropped phone connection (Errno 103): retries the upload, notices when the first try really got through, gives a plain error at the end")
def _():
    import importlib.util, hashlib
    spec = importlib.util.spec_from_file_location("sekex_publish_r", ROOT / "bin" / "sekex_publish.py")
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    m.time.sleep = lambda x: None
    cfg = {"repo": "o/r", "token": "t", "branch": "main"}
    data = b"x" * 5000
    sha = hashlib.sha1(b"blob %d\0" % len(data) + data).hexdigest()
    # 1) two aborted uploads, third works
    calls = {"put": 0}
    def once(method, path, token, body=None):
        if method == "GET":
            return 404, {}
        calls["put"] += 1
        if calls["put"] < 3:
            raise ConnectionAbortedError(103, "Software caused connection abort")
        return 201, {}
    m._gh_once = once
    assert m.put(cfg, "a.zip", data, "msg") == "uploaded" and calls["put"] == 3
    # 2) upload aborted AFTER GitHub stored it: the check afterwards sees the same file
    state = {"stored": False}
    def once2(method, path, token, body=None):
        if method == "GET":
            return (200, {"sha": sha}) if state["stored"] else (404, {})
        state["stored"] = True
        raise ConnectionAbortedError(103, "abort")
    m._gh_once = once2
    assert m.put(cfg, "a.zip", data, "msg") == "uploaded"
    # 3) always failing: a plain message, not a traceback
    def once3(method, path, token, body=None):
        if method == "GET":
            return 404, {}
        raise ConnectionAbortedError(103, "abort")
    m._gh_once = once3
    try:
        m.put(cfg, "a.zip", data, "msg"); assert False
    except SystemExit as e:
        assert "Wi-Fi" in str(e) and "nothing was deleted" in str(e)
    # 4) a GET that drops is retried too
    n = {"g": 0}
    def once4(method, path, token, body=None):
        n["g"] += 1
        if n["g"] < 3:
            raise TimeoutError("timed out")
        return 200, {"ok": 1}
    m._gh_once = once4
    assert m.gh("GET", "/x", "t")[0] == 200 and n["g"] == 3


@test("v2.19.4 autonomous options: a good-record signal buys a call (up) or put (down) through the options module, only when the Options switch is On; via shares / options / both")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from autobot import presets as P
    import server
    idx = pd.date_range("2026-10-12 04:00", periods=900, freq="5min", tz="America/New_York"); idx = idx[(idx.hour >= 4) & (idx.hour < 20)]
    rng = np.random.default_rng(1); c = 30 + np.cumsum(rng.normal(0, .08, len(idx)))
    d = pd.DataFrame({"open": c - .02, "high": c + .07, "low": c - .07, "close": c, "volume": rng.integers(500, 5000, len(idx))}, index=idx)
    rb = P.normalize({"pattern": "breakout", "side": "both", "vol_mult": .5, "chop_skip": False}); sg = P.scan(rb, d); assert sg
    last = sg[-1]; dd = d.iloc[:last["i"] + 1]
    old = (P.FILE, P.auto_rules, P.good_record, server._jp_place, server.options_bot, server.settings.options_on)
    shares, opts = [], []
    class OB:
        ok = True
        def autopilot_open(self, e, u, direction, why, price, dry=False):
            opts.append((u, direction)); return (self.ok, "" if self.ok else "no contract")
    try:
        P.FILE = pathlib.Path(tempfile.mkdtemp()) / "presets.json"
        P.auto_rules = lambda: [dict(rb, id="auto_breakout", enabled=True, auto_paper=True, auto=True, name="Auto · Breakout")]
        P.good_record = lambda t: True
        server._jp_place = lambda e, sym, up, px, stop=None, target=None, qty=0: shares.append((sym, up)) or {"msg": "ok"}
        server.options_bot = OB()
        class E_: mode = "PAPER"; running = True
        e = E_(); e.broker = type("B", (), {"bars5": lambda s, sym, days: dd.iloc[:-60]})()
        now = dd.index[-1].to_pydatetime()
        def run():
            server._PR.update(auto_day="", fired=[], hist={}, auto_n=0, rec={}, rn=0, hn=0)
            server._pr_live(e, "AAA", dd.iloc[-60:], None, now, "REGULAR")
        P.autonomous_set(True, "shares"); server.settings.options_on = True; run()
        assert len(shares) == 1 and not opts, "shares only"
        shares.clear(); P.autonomous_set(True, "options"); run()
        assert not shares and opts == [("AAA", "call" if last["side"] == "up" else "put")], opts
        opts.clear(); server.settings.options_on = False; run()
        assert not shares and not opts, "Options switch Off: nothing bought"
        server.settings.options_on = True; P.autonomous_set(True, "both"); run()
        assert len(shares) == 1 and len(opts) == 1, "both"
        shares.clear(); opts.clear(); server.options_bot.ok = False; P.autonomous_set(True, "options"); run()
        assert not shares and len(opts) == 1, "options refused: no shares bought instead"
        assert P.autonomous_via() == "options"
    finally:
        P.FILE, P.auto_rules, P.good_record, server._jp_place, server.options_bot, server.settings.options_on = old
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("optAutoBox", "function optAutoSet(", "Autonomous options", "function prVia(", "Trade each signal with:"):
        assert k in h, k


@test("v2.19.5 Focus mode: new entries only in the chosen 1-5 stocks across the bot, presets, options and Autopilot; exits and manual trades untouched")
def _():
    import server
    from autobot.engine import Engine
    from autobot.options import OptionsBot
    class S_: focus_on = False; focus_symbols = []
    fake = type("F", (), {"s": S_()})()
    assert Engine.focus_ok(fake, "AAPL"), "off: everything allowed"
    fake.s.focus_on, fake.s.focus_symbols = True, ["nvda", "TSLA"]
    assert Engine.focus_ok(fake, "NVDA") and Engine.focus_ok(fake, "tsla") and not Engine.focus_ok(fake, "AAPL")
    fake.s.focus_symbols = []
    assert Engine.focus_ok(fake, "AAPL"), "On with no stocks chosen blocks nothing"
    # endpoint validation
    old = (server.settings.focus_on, list(server.settings.focus_symbols), server.settings.save, server.engine)
    server.settings.save = lambda: None; server.engine = None
    try:
        r = server.focus_set(server.FocusReq(on=True, symbols=["nvda", "$tsla", "nvda", "bad!!", "  "]))
        assert r["on"] and r["symbols"] == ["NVDA", "TSLA"], r
        for bad in (dict(on=True, symbols=[]), dict(on=True, symbols=list("ABCDEF"))):
            try:
                server.focus_set(server.FocusReq(**bad)); assert False, bad
            except server.HTTPException:
                pass
        server.focus_set(server.FocusReq(on=False, symbols=["NVDA"]))
        assert not server.settings.focus_on
        server.settings.focus_on, server.settings.focus_symbols = True, ["NVDA"]
        e = type("E", (), {"s": server.settings, "focus_ok": Engine.focus_ok})()
        e.focus_ok = lambda sym: Engine.focus_ok(e, sym)
        # presets: a blocked stock never trades
        server._PR.update(auto_day="", fired=[], hist={}, auto_n=0, rec={}, rn=0, hn=0)
        e.running = True; e.mode = "PAPER"
        assert server._pr_live(e, "AAPL", None, None, None, "REGULAR") is None
        # options autopilot refuses
        ob = OptionsBot(lambda: None, server.settings)
        ok, why = ob.autopilot_open(type("E2", (), {"mode": "PAPER", "focus_ok": e.focus_ok, "broker": type("B", (), {"now": lambda s: __import__("datetime").datetime.now()})()})(), "AAPL", "call", "x", 10.0) if False else (False, "")
    finally:
        server.settings.focus_on, server.settings.focus_symbols, server.settings.save, server.engine = old[0], old[1], old[2], old[3]
    src = open(ROOT / "autobot" / "engine.py", encoding="utf-8").read()
    assert src.count("self.focus_ok(") >= 4, "entries, extended entries, waves and picks are gated"
    ops = open(ROOT / "autobot" / "options.py", encoding="utf-8").read()
    assert ops.count("focus_ok(u)") == 2
    h = open(ROOT / "web" / "dashboard.html", encoding="utf-8").read()
    for k in ("focusCard", "function focusSet(", "only trade these stocks"):
        assert k in h, k



@test("v2.19.6 alert popups: '+N more' chip is in the header next to the session badge, popups swipe away and never block taps")
def _():
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="sess"' in h and h.index('id="toastChip"') > h.index('id="sess"') and h.index('id="toastChip"') < h.index('id="state"')
    assert "toastSwipe(d)" in h and "touchend" in h
    assert ".toasts{pointer-events:none" in h and ".toast{pointer-events:auto" in h
    assert "tap to open 🔔'" not in h.split("function toastMore")[1].split("function toast(")[0]


@test("v2.19.7 earnings / risky-news filter also guards pattern auto-trades, Autonomous mode and options (Autopilot + auto entries)")
def _():
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    op = open(os.path.join(ROOT, "autobot", "options.py"), encoding="utf-8").read()
    body = sv.split("def _pr_live(")[1].split("\ndef ")[0]
    assert "_event_block" in body
    assert op.count("_event_block") >= 2
    from autobot.events import Events
    from datetime import datetime
    ev = Events(); now = datetime(2026, 10, 20, 11, 0, tzinfo=NY_TZ) if "NY_TZ" in globals() else None
    ev._earn["2026-10-20"] = {"NFLX": "after"}
    from zoneinfo import ZoneInfo
    now = datetime(2026, 10, 20, 11, 0, tzinfo=ZoneInfo("America/New_York"))
    assert "earnings" in ev.block_reason("NFLX", now)
    assert ev.block_reason("AAPL", now) == ""


@test("v2.19.8 morning plan: gap, levels, buy/short entries with stops and targets from overnight bars; earnings warning; journal CSV")
def _():
    import pandas as pd, numpy as np
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from autobot import plan as P
    NYZ = ZoneInfo("America/New_York")
    idx = list(pd.date_range("2026-10-19 09:30", "2026-10-19 15:59", freq="1min", tz=NYZ)) + list(pd.date_range("2026-10-19 16:00", "2026-10-20 00:30", freq="1min", tz=NYZ))
    n = len(idx); px = np.linspace(100, 100, 390).tolist() + (100 + np.linspace(0, 3, n - 390)).tolist()
    d = pd.DataFrame({"open": px, "high": [p + .2 for p in px], "low": [p - .2 for p in px], "close": px, "volume": [1000] * n}, index=pd.DatetimeIndex(idx))
    now = datetime(2026, 10, 20, 0, 31, tzinfo=NYZ)
    r = P.build_plan("TEST", d, now, "Earnings today")
    assert r["ok"] and r["bias"] == "long" and r["gap_pct"] > 2, r
    bp = r["plan"]["buy_above"]; assert bp["stop"] < bp["price"] < bp["t1"] < bp["t2"]
    sp = r["plan"]["short_below"]; assert sp["stop"] > sp["price"] > sp["t1"] > sp["t2"]
    assert "will not open new trades" in r["warn"]
    assert P.build_plan("X", d.iloc[:5], now)["ok"] is False
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '"/api/plan"' in sv and '"/api/trades.csv"' in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="planCard"' in h and "planBuild" in h and "jrExport" in h


@test("v2.21 autonomous: morning plan builds itself + alert, plan entries need Auto-trader/PIN arming/earnings filter; options flip-exit waits 30 min and spread; no duplicate opens")
def _():
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    body = sv.split("def _plan_pass(")[1].split("\nclass PlanCfg")[0]
    for need in ("_event_block", "focus_ok", '_PR.get("armed") != day', "_jp_place", "alerts.send", "9 * 60 + 35", "0830", "0915"):
        assert need in body, need
    assert "_plan_pass(e, now, sess, pos)" in sv and '"/api/plan/state"' in sv and '"/api/plan/config"' in sv
    from autobot import options as O
    from datetime import datetime, timedelta
    cfg = {"flatten_min": 15 * 60 + 45, "tp_pct": 40, "stop_pct": 25}
    new = {"debit": 1.0, "opened_at": datetime.now().isoformat()}
    assert O.exit_decision(dict(new), 0.97, 600, cfg, flip=True) == ""                      # just opened, flat: no spread-paying exit
    old = {"debit": 1.0, "opened_at": (datetime.now() - timedelta(minutes=60)).isoformat()}
    assert O.exit_decision(dict(old), 0.97, 600, cfg, flip=True) == ""                      # -3% is inside the spread noise
    assert "trend turned" in O.exit_decision(dict(old), 0.88, 600, cfg, flip=True)           # -12% after an hour and flipped: exit
    assert "stop" in O.exit_decision(dict(new), 0.70, 600, cfg, flip=False)                  # the stop still works at once
    src = open(os.path.join(ROOT, "autobot", "options.py"), encoding="utf-8").read()
    assert "within 5 minutes" in src


@test("v2.21 morning plan live smoke: builds at 9:15, alerts, buys the breakout once in PAPER, LIVE needs arming, earnings stock is skipped")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from datetime import datetime
    from zoneinfo import ZoneInfo
    import server
    NYZ = ZoneInfo("America/New_York")
    idx = list(pd.date_range("2026-10-19 09:30", "2026-10-19 15:59", freq="1min", tz=NYZ)) + list(pd.date_range("2026-10-19 16:00", "2026-10-20 09:40", freq="1min", tz=NYZ))
    idx = [t for t in idx if t.weekday() < 5]
    n = len(idx); px = np.array([100.0] * 390 + list(100 + np.linspace(0, 2, n - 390)))
    px[-3:] = px[-4] + np.array([.1, .2, .3])             # pushes through the overnight high after the open
    d = pd.DataFrame({"open": px, "high": px + .1, "low": px - .1, "close": px, "volume": 1000}, index=pd.DatetimeIndex(idx))
    now = datetime(2026, 10, 20, 9, 40, 30, tzinfo=NYZ)
    old = (server._jp_place, server._PLAN_FILE, server.alerts.send, server.events.earnings_text)
    placed, sent = [], []
    try:
        server._PLAN_FILE = pathlib.Path(tempfile.mkdtemp()) / "plan.json"
        server._plan_cfg_save({"auto": True, "trade": True, "symbols": ["AAA"]})
        server._jp_place = lambda e, sym, up, px_, stop=None, target=None, qty=0: placed.append((sym, up, stop, target)) or {"msg": "sent"}
        server.alerts.send = lambda *a, **k: sent.append(a)
        server.events.earnings_text = lambda sym, now: ""
        class E_:
            mode = "PAPER"; running = True
            broker = type("B", (), {"bars": lambda s, syms, start=None: {x: d[d.index <= CUT[0]] for x in syms}})()
        e = E_()
        CUT = [datetime(2026, 10, 20, 9, 16, tzinfo=NYZ)]
        server._PLAN.update(day="", marks=[], plans=[], at="", fired=[], n=0, log=[])
        server._plan_pass(e, CUT[0].replace(second=30), "SOMETHING", {})      # 9:16 AM: the plan builds
        CUT[0] = now
        server._plan_pass(e, now, "REGULAR", {})
        assert server._PLAN["plans"] and server._PLAN["plans"][0]["ok"], server._PLAN
        assert sent and "Morning plan" in sent[0][1]
        assert len(placed) == 1 and placed[0][1] is True, (placed, server._PLAN["plans"][0]["plan"], server._PLAN["log"]); n1 = len(placed); server._plan_pass(e, now, "REGULAR", {}); assert len(placed) == n1     # once per stock per day
        server._PLAN.update(fired=[], n=0); placed.clear(); E_.mode = "LIVE"; server._PR["armed"] = ""
        server._plan_pass(e, now, "REGULAR", {}); assert not placed                                   # LIVE needs PIN arming
        server._PLAN.update(fired=[], n=0); E_.mode = "PAPER"; server.events.earnings_text = lambda sym, now: "Earnings today after the close"
        server._PLAN.update(plans=[]); server._PLAN["marks"] = []; CUT[0] = now; server._plan_pass(e, now, "REGULAR", {})
        assert server._PLAN["plans"][0]["warn"]
    finally:
        server._jp_place, server._PLAN_FILE, server.alerts.send, server.events.earnings_text = old


@test("v2.21.1 Flip button: /api/manual/flip reverses a manual position through the guard's one-order flip; bot trades refused; button on YOUR positions only")
def _():
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    body = sv.split("def manual_flip(")[1].split("\n@app.post")[0]
    for need in ("_flip_two_step(", "e.trades.get(sym)", "409", "RuntimeError", "closeplans.cancel"):
        assert need in body, need
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert "bookFlip(" in h and "'manual/flip'" in h and "🔄 Flip" in h
    assert "p.bot ? '' : `<button class=\"sm\" title=\"Reverse this position" in h


@test("v2.22 Heikin Ashi: candle math, green/red/mixed state, filter gates buys and shorts by scope, off by default, fails open; wired into stocks, options, presets, plan, chart")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from autobot import ha
    idx = pd.date_range("2026-10-20 09:30", periods=120, freq="1min", tz="America/New_York")
    def frame(trend):
        c = 50 + np.cumsum(np.full(120, trend)) + np.sin(np.arange(120)) * .05
        return pd.DataFrame({"open": c - trend / 2, "high": c + .1, "low": c - trend / 2 - .1, "close": c, "volume": 1000}, index=idx)
    up, dn = frame(.08), frame(-.08)
    h = ha.ha_df(ha.to5(up))
    assert (h["close"] > h["open"]).iloc[-5:].all() and abs(h["close"].iloc[0] - ha.to5(up)[["open", "high", "low", "close"]].iloc[0].mean()) < 1e-9
    assert ha.state(ha.to5(up), 3)[0] == "green" and ha.state(ha.to5(dn), 3)[0] == "red"
    assert ha.state(None, 3)[0] == "unknown"
    old = ha.FILE
    try:
        ha.FILE = pathlib.Path(tempfile.mkdtemp()) / "ha.json"
        assert ha.load()["on"] is False and ha.gate("UP", True, "stocks", lambda s: dn, 1) == ""           # off by default
        ha.save({"on": True, "n": 3, "stocks": True, "options": False, "auto": True})
        assert ha.gate("UP", True, "stocks", lambda s: up, 100) == ""
        assert "red" in ha.gate("DN", True, "stocks", lambda s: dn, 100)                                      # no buying into red
        assert ha.gate("DN", False, "stocks", lambda s: dn, 100) == ""                                         # shorting red is fine
        assert "green" in ha.gate("UP2", False, "stocks", lambda s: up, 100)
        assert ha.gate("DN3", True, "options", lambda s: dn, 100) == ""                                        # scope switched off
        assert ha.gate("ERR", True, "stocks", lambda s: 1 / 0, 100) == ""                                      # fails open
    finally:
        ha.FILE = old
    en = open(os.path.join(ROOT, "autobot", "engine.py"), encoding="utf-8").read()
    assert en.count("self.ha_block(") >= 4 and "def ha_block" in en
    op = open(os.path.join(ROOT, "autobot", "options.py"), encoding="utf-8").read()
    assert op.count("ha_block") >= 2
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert sv.count('"ha_block"') >= 2 and '"/api/ha"' in sv and '"/api/ha/config"' in sv and '"ho"' in sv
    h_ = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="haCard"' in h_ and 'id="haSeg"' in h_ and "haBars(" in h_


@test("v2.22.1 Flip works in two steps: close first, then open the other way once flat (no zero-crossing order); gates and failures reported")
def _():
    import server, time
    from datetime import datetime
    from zoneinfo import ZoneInfo
    now = datetime(2026, 10, 20, 11, 0, tzinfo=ZoneInfo("America/New_York"))
    sent, held = [], {"IREN": {"qty": 100.0, "price": 28.0}}
    class B:
        def positions(s): return dict(held)
        def cancel_symbol_orders(s, sym): pass
        def manual_order(s, sym, side, qty, ot, **k):
            sent.append((side, qty, ot)); 
            if len(sent) == 1: held.clear()                      # the close fills at once
            return "id"
        def now(s): return now
    class R: remaining = 7000; halted = False; equity = 10000
    class E:
        broker = B(); risk = R(); acct = {"shorting_enabled": True}; trades = {}; manual_syms = {}
        def shorts_allowed(s, n): return True
        def _can_short(s, sym): return True, ""
        def event(s, m): pass
    old = (server._session_name, server._quote, server.alerts.send, time.sleep, getattr(server.settings, "guard_flip_harvest", True))
    real_sleep = old[3]
    try:
        server._session_name = lambda e: "REGULAR"; server._quote = lambda e, sym, sess: (27.9, 28.0)
        server.alerts.send = lambda *a, **k: None
        server.settings.guard_flip_harvest = False
        time.sleep = lambda s: real_sleep(0.01)
        msg = server._flip_two_step(E(), "IREN", {"qty": 100.0, "price": 28.0})
        assert "Closing your 100" in msg and sent[0][:2] == ("sell", 100), sent
        for _ in range(200):
            if len(sent) >= 2: break
            real_sleep(0.05)
        assert len(sent) == 2 and sent[1][0] == "sell" and sent[1][1] == 100, sent          # short of min(100, 30% of $10k / $27.9 = 107)
        E.risk.remaining = 0
        try:
            server._flip_two_step(E(), "IREN", {"qty": 100.0, "price": 28.0}); assert False
        except RuntimeError as ex:
            assert "loss limit" in str(ex)
    finally:
        server._session_name, server._quote, server.alerts.send, time.sleep, server.settings.guard_flip_harvest = old


@test("v2.23 Radar always scanning: switch on by default, scans in every session (not only REGULAR), loop refreshes Radar boards, weekend skipped, status + switch endpoints")
def _():
    import server, tempfile, pathlib
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert 'not force and not _radar_always()' in sv and "name=\"radar-always\"" in sv
    body = sv.split("def _radar_loop(")[1].split("class RadarAlways")[0]
    for need in ("_weekend_gap(now)", "_jp_scan(force=True)", "morning_wave(0", "predict_watchlist(3, 0)", "_radar_always()"):
        assert need in body, need
    old = server._RADAR_FILE
    try:
        server._RADAR_FILE = pathlib.Path(tempfile.mkdtemp()) / "radar.json"
        assert server._radar_always() is True                       # on unless switched off
        server.radar_always_set(server.RadarAlways(on=False)); assert server._radar_always() is False and server.radar_always_get()["on"] is False
        server.radar_always_set(server.RadarAlways(on=True)); assert server._radar_always() is True
    finally:
        server._RADAR_FILE = old
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="raOn"' in h and "raSet(" in h and "'radar/always'" in h


@test("v2.24 overnight shorts: group clustering, dynamic cap (ceiling / loss room / held / earnings peers / spread), candidates, sizing, earnings switch; paper places, LIVE needs arming; window Mon-Thu 4:05-7:45")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from autobot import onshort as O
    rng = np.random.default_rng(3)
    idx = pd.bdate_range("2026-07-01", periods=80)
    base = np.cumsum(rng.normal(0, 1, 80)) + 100
    def daily(noise, scale=1.0):
        c = base * scale + np.cumsum(rng.normal(0, noise, 80))
        return pd.DataFrame({"open": c * (1 + rng.normal(0, .004, 80)), "high": c * 1.01, "low": c * .99, "close": c, "volume": 1e6}, index=idx)
    D = {"AAA": daily(.2), "BBB": daily(.2, .5), "CCC": daily(.2, .3), "ZZZ": pd.DataFrame({"open": 50 + rng.normal(0, 1, 80), "high": 52, "low": 48, "close": 50 + np.cumsum(rng.normal(0, 1, 80)), "volume": 1}, index=idx)}
    gp = O.groups({k: v["close"] for k, v in D.items()})
    assert gp and {"AAA", "BBB"} <= set(gp[0]) and "ZZZ" not in gp[0], gp
    cap, why = O.dyn_cap(70000, 7000, 0.03, 0)                  # ceiling 28k vs room 233k -> 28k
    assert cap == 28000 and "40%" in why
    cap2, _ = O.dyn_cap(70000, 700, 0.03, 0); assert cap2 == round(700 / 0.03, 2)           # loss room is the limit
    cap3, w3 = O.dyn_cap(70000, 7000, 0.03, 5000, earnings_peer=True, spread_pct=0.8); assert cap3 == 9000 and "peers" in w3 and "spread" in w3
    assert O.dyn_cap(70000, 0, 0.03, 0)[0] == 0 and O.dyn_cap(70000, 7000, 0.03, 99999)[0] == 0
    stats = {s: {"last": 90.0, "prev_close": 100.0, "vwap": 95.0} for s in ("AAA", "BBB", "CCC")}
    cfg = {"on": True, "mode": "place", "earn": False, "max_each": 5000.0, "max_total": 10000.0}
    cs = O.build(stats, D, {}, cfg, 70000, 7000, {})
    assert [c["kind"] for c in cs].count("group") == 3 and all(c["stop"] > c["price"] > c["target"] for c in cs if c["kind"] == "group")
    cs2 = O.build(stats, D, {"AAA": "after"}, cfg, 70000, 7000, {})
    assert any(c["symbol"] == "AAA" and c["kind"] == "blocked" for c in cs2)                  # earnings shorts are OFF
    cs3 = O.build(stats, D, {"AAA": "after"}, dict(cfg, earn=True), 70000, 7000, {})
    assert any(c["symbol"] == "AAA" and c["kind"] == "group" for c in cs3)
    c0 = [c for c in cs if c["kind"] == "group"][0]
    q = O.size(c0, cfg, 0, 7000, 100000); assert 1 <= q <= int(5000 / c0["price"])
    assert O.size(c0, cfg, 10000, 7000, 100000) == 0                                          # all-overnight limit used up
    # server: window + pass
    import server
    NYZ = ZoneInfo("America/New_York")
    class E_:
        mode = "PAPER"; day = "2026-10-21"; overnight = {}; positions = {}; trades = {}; acct = {"equity": 70000, "buying_power": 140000}
        class risk: remaining = 7000; halted = False; equity = 70000
        class broker:
            @staticmethod
            def now(): return NOW[0]
            @staticmethod
            def positions(): return {}
            @staticmethod
            def clock(): return {"is_open": False, "next_open": NOW[0]}
            @staticmethod
            def manual_order(sym, side, qty, ot, **k): SENT.append((sym, side, qty, ot, k.get("extended"))); return "oid"
        def _can_short(s, sym): return True, ""
        def _margin_block(s): return False
        def _save_overnight(s): pass
        def event(s, m): pass
        def _overnight_tick(s, now, clk): pass
    NOW, SENT = [datetime(2026, 10, 21, 17, 0, tzinfo=NYZ)], []
    e = E_()
    old = (server._ons_build, server.alerts.send, server.ons.FILE, server._quote, server._PR.get("armed"))
    try:
        server.ons.FILE = pathlib.Path(tempfile.mkdtemp()) / "o.json"
        server.alerts.send = lambda *a, **k: None
        server._quote = lambda e_, sym, sess: (89.9, 90.0)
        server._ons_build = lambda e_, now: (server._ONS.update(cands=cs, built=0.0, day=str(now.date())) or cs)
        assert server._ons_window(e, NOW[0])[0] and not server._ons_window(e, datetime(2026, 10, 23, 17, 0, tzinfo=NYZ))[0] and not server._ons_window(e, datetime(2026, 10, 21, 19, 50, tzinfo=NYZ))[0]
        server.ons.save({"on": False}); server._ons_pass(e, NOW[0]); assert not SENT                       # off by default
        server.ons.save({"on": True, "mode": "alert"}); server._ons_pass(e, NOW[0]); assert not SENT       # alert only
        server.ons.save({"on": True, "mode": "place"}); server._ons_pass(e, NOW[0]); assert SENT and SENT[0][1] == "sell" and SENT[0][3] == "limit" and SENT[0][4] is True and e.overnight
        assert e.overnight[SENT[0][0]]["ev"] and e.overnight[SENT[0][0]]["cover_hm"] == 575
        SENT.clear(); e.overnight.clear(); e.mode = "LIVE"; server._PR["armed"] = ""; server._ons_pass(e, NOW[0]); assert not SENT          # LIVE needs PIN arming
        server._PR["armed"] = "2026-10-21"; server._ons_pass(e, NOW[0]); assert SENT                      # armed: it places
    finally:
        server._ons_build, server.alerts.send, server.ons.FILE, server._quote = old[:4]; server._PR["armed"] = old[4] or ""
    en = open(os.path.join(ROOT, "autobot", "engine.py"), encoding="utf-8").read()
    assert 'o.get("cover_hm"' in en and "_dead" in en and "_on_lock" in en
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="onsCard"' in h and "onsPlace(" in h and "'onshort/config'" in h

@test("v2.25 harvest history (times, survives stop) + autonomous jump trading (IN places, OUT closes, gates, LIVE arming, caps) + Send fixes button")
def _():
    import server, tempfile, pathlib, pandas as pd
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from autobot.harvester import Harvester
    NYZ = ZoneInfo("America/New_York")
    NOW = datetime(2026, 10, 21, 14, 47, tzinfo=NYZ)
    class B_:
        def now(self): return NOW
    class E0:
        broker = B_()
    d = pathlib.Path(tempfile.mkdtemp())
    hv = Harvester.__new__(Harvester)
    import threading
    hv.get_engine = lambda: E0(); hv.lock = threading.RLock(); hv.jobs = {}; hv.hist = []; hv.hpath = str(d / "h.json"); hv.path = str(d / "j.json")
    hv._h("IREN", "harvest", "Covered 110 @ 40.62 · in at 41.20", 63.8, 40.62); hv._h("IREN", "stop", "x", -9.9, 41.4); hv._h("IREN", "reenter", "y", None, 40.9)
    hh = hv.history("IREN"); assert [x["kind"] for x in hh] == ["reenter", "stop", "harvest"] and hh[2]["t"] == "2:47 PM" and hh[2]["hm"] == "14:47"
    assert hv.today("IREN") == {"n": 1, "stops": 1, "amt": 53.9}
    assert json.loads(open(hv.hpath).read())[0]["sym"] == "IREN"                 # saved to disk
    hv.jobs["IREN"] = {"symbol": "IREN", "cycles": 1, "banked": 5.0}
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    hz = open(os.path.join(ROOT, "autobot", "harvester.py"), encoding="utf-8").read()
    assert hz.count("self._h(") >= 5 and '"hv_hist": harvester.history()' in sv and '"hv": [h for h in harvester.history(sym)' in sv
    # ---- jump trading
    idx = pd.date_range("2026-10-21 09:30", periods=40, freq="5min", tz=NYZ)
    d5 = pd.DataFrame({"open": 10.0, "high": 10.1, "low": 9.9, "close": 10.0, "volume": 1000}, index=idx)
    PL, CL, SENT = [], [], []
    class E1:
        mode = "PAPER"; running = True
        def focus_ok(self, s): return s != "FOC"
        def _event_block(self, s, n, se): return s == "ERN"
        def ha_block(self, s, up, sc): return "no" if s == "HAB" else ""
    e = E1()
    old = (server._jp_place, server._close_now, server.alerts.send, server._jp_record, server._JT_FILE, server._PR.get("armed"), server.settings.allow_shorts)
    try:
        server._JT_FILE = pathlib.Path(tempfile.mkdtemp()) / "jt.json"
        server.alerts.send = lambda *a, **k: None
        server._jp_record = lambda e_, s: {"up": {"n": 20, "hit": 15, "fail": 5}, "down": {"n": 20, "hit": 15, "fail": 5}}
        server._jp_place = lambda e_, sym, up, px, stop, tgt, qty=0, mx=0: (PL.append((sym, up, px, mx)) or {"msg": f"sent {sym}"})
        server._close_now = lambda e_, sym, pct, urgent=True, note="": CL.append(sym)
        server.settings.allow_shorts = True
        sig = lambda sym, side, kind="in", i=0: {"i": 39, "kind": kind, "side": side, "t": "14:%02d" % (i % 60), "price": 10.0, "stop": 9.8, "tp1": 10.3, "name": "x", "why": "w", "zone": [9.9, 10.0], "tp2": 10.5}
        T = lambda sym, sigs, pos={}, sess="REGULAR", now=NOW: server._jt_signal(e, sym, d5, None, sigs, pos, now, sess)
        server._JT["cfg"].update(on=False, mine=False, ext=False, dirs="both", max_open=3, strong_only=True); server._JT["day"] = ""; server._JT["mine"] = []
        T("AAA", [sig("AAA", "up")]); assert not PL                                    # off by default
        server._JT["cfg"]["on"] = True
        T("AAA", [sig("AAA", "up")]); assert PL and PL[0][:2] == ("AAA", True) and PL[0][3] == 2500 and "AAA" in server._JT["mine"]
        T("BBB", [sig("BBB", "down", i=38)]); assert PL[-1][:2] == ("BBB", False)       # short allowed in the day
        n = len(PL); T("ERN", [sig("ERN", "up", i=37)]); T("FOC", [sig("FOC", "up", i=36)]); T("HAB", [sig("HAB", "up", i=35)]); assert len(PL) == n
        assert any("earnings" in x["msg"] for x in server._JT["log"]) and any("Focus" in x["msg"] for x in server._JT["log"]) and any("Heikin" in x["msg"] for x in server._JT["log"])
        T("CCC", [sig("CCC", "up", i=34)]); assert len(PL) == n + 1 and len(server._JT["mine"]) == 3
        T("DDD", [sig("DDD", "up", i=33)]); assert len(PL) == n + 1 and any("already 3" in x["msg"] for x in server._JT["log"])   # max open
        T("AAA", [sig("AAA", "up", "out")], {"AAA": {"qty": 5}}); assert CL == ["AAA"] and "AAA" not in server._JT["mine"]     # JUMP OUT closes its own
        T("ZZZ", [sig("ZZZ", "up", "out")], {"ZZZ": {"qty": 5}}); assert CL == ["AAA"]                                         # not mine: untouched
        server._JT["cfg"]["mine"] = True; T("ZZZ", [sig("ZZZ", "up", "out", i=38)], {"ZZZ": {"qty": 5}}); assert CL == ["AAA", "ZZZ"]   # unless switched on
        server._JT["mine"] = []; server._JT["cfg"]["dirs"] = "buy"; n = len(PL); T("SSS", [sig("SSS", "down", i=32)]); assert len(PL) == n   # buy only
        server._JT["cfg"]["dirs"] = "both"; T("LATE", [sig("LATE", "down", i=31)], now=datetime(2026, 10, 21, 20, 30, tzinfo=NYZ), sess="AFTER"); assert len(PL) == n     # ext off
        server._JT["cfg"]["ext"] = True; T("LATE", [sig("LATE", "down", i=30)], now=datetime(2026, 10, 21, 20, 30, tzinfo=NYZ), sess="AFTER"); assert len(PL) == n   # no shorts after 8 PM
        e.mode = "LIVE"; server._PR["armed"] = ""; server._JT["mine"] = []; server._JT["last"] = {}; T("LV1", [sig("LV1", "up", i=29)]); assert len(PL) == n   # LIVE not armed
        server._PR["armed"] = "2026-10-21"; T("LV1", [sig("LV1", "up", i=28)]); assert len(PL) == n + 1
        r = server.jumptrade_cfg(server.JTCfg(size=99999, max_open=99, dirs="buy")); assert r["cfg"]["size"] == 50000 and r["cfg"]["max_open"] == 10 and r["cfg"]["dirs"] == "buy"
    finally:
        server._jp_place, server._close_now, server.alerts.send, server._jp_record, server._JT_FILE = old[:5]; server._PR["armed"] = old[5] or ""; server.settings.allow_shorts = old[6]
        server._JT["cfg"].update(on=False, mine=False, ext=False, dirs="both", size=2500, max_open=3, strong_only=True); server._JT["mine"] = []
    assert "_jt_signal(e, sym, d5, held, sigs, pos, now, sess)" in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="jtCard"' in h and "jtCfg(" in h and "'jumptrade/config'" in h and "setTimeout(jtLoad" in h
    assert "hvHistHtml(" in h and "data.hv" in h and "Send fixes to SEKEX" in h


@test("v2.26 best times report (waves, trades per half-hour, costs, sessions) + AI usage counter (every ai_post call counted per feature, cost estimate)")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib
    from autobot import besttimes as bt, aiusage, analyst
    c = [100, 100.5, 101, 102.6, 101.2, 99.8, 98.4, 100.2, 102.1]
    lg = bt.waves(np.array(c), 1.5)
    assert lg and lg[0][2] == 1 and lg[1][2] == -1, lg
    rng = np.random.default_rng(2)
    idx = []
    for day in pd.bdate_range("2026-09-01", periods=30):
        idx += list(pd.date_range(day + pd.Timedelta(hours=4), day + pd.Timedelta(hours=19, minutes=45), freq="15min", tz="America/New_York"))
    px = 30 + np.cumsum(rng.normal(0, .15, len(idx)))
    d = pd.DataFrame({"open": px, "high": px * 1.004, "low": px * .996, "close": px, "volume": 1e5}, index=pd.DatetimeIndex(idx))
    r = bt.analyze(d)
    assert r["ok"] and r["days"] == 30 and len(r["rows"]) == 32 and r["rows"][0]["t"] == "4:00 AM" and set(r["sessions"]) == {"pre", "reg", "after"}
    assert r["waves"] > 0 and 0 <= r["early_pct"] <= 100 and r["stop_pct"] >= 0.8 and r["target_pct"] == round(r["stop_pct"] * 2, 2) and r["cost"]["pre"] > r["cost"]["reg"]
    assert not bt.analyze(d.iloc[:10])["ok"]
    t = bt._trade([10, 10, 10], [10.0, 10.5, 10], [10, 9.9, 9], [10, 10, 10], [570, 585, 600], 0, 1, 2, 4, 8, 0.1)      # long: bar 1 reaches +5% only, stop -2% not touched
    assert t is None or isinstance(t, float)
    ok = bt._trade([10, 10], [10, 10.5], [10, 9.7], [10, 10], [570, 585], 0, 1, 2, 4, 8, 0)                              # same bar hits stop and target: stop wins
    assert ok == -2, ok
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '"/api/besttimes"' in sv and "bars15([sym], 45)" in sv and '"/api/aiusage"' in sv
    # usage counter
    old = (aiusage.FILE, analyst._ai_post_raw)
    try:
        aiusage.FILE = pathlib.Path(tempfile.mkdtemp()) / "u.json"
        analyst._ai_post_raw = lambda timeout, payload: analyst._Resp(200, "{}", {"content": [], "model": "claude-sonnet-4-5", "usage": {"input_tokens": 1000000, "output_tokens": 100000}})
        analyst.ai_post(30, {"model": "claude-sonnet-4-5", "messages": []})
        analyst._ai_post_raw = lambda timeout, payload: analyst._Resp(500, "x")
        analyst.ai_post(30, {"model": "claude-sonnet-4-5", "messages": []})
        sm = aiusage.summary()
        assert sm["today"]["calls"] == 2 and sm["today"]["in"] == 1000000 and abs(sm["today"]["usd"] - 4.5) < 1e-6, sm["today"]       # 1M in x $3 + 0.1M out x $15
        assert aiusage.cost("mystery-model", 10, 10) is None and aiusage.cost("x", 5, 5, local=True) == 0.0
    finally:
        aiusage.FILE, analyst._ai_post_raw = old
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="btCard"' in h and "btLoad(" in h and "'aiusage'" in h and 'id="aiCostCard"' in h and "setTimeout(aiuLoad" in h
    import re as _re, collections as _c
    assert [k for k, v in _c.Counter(_re.findall(r'\bid="([^"]+)"', h)).items() if v > 1] == [], "duplicate element ids on the dashboard"
    assert "_ai_post_raw" in open(os.path.join(ROOT, "autobot", "analyst.py"), encoding="utf-8").read()


@test("v2.27 options: why-no-trade counters by reason, options follow JUMP IN / plan signals through the options module, expiry presets, add-to-list, Options school lessons")
def _():
    import server, tempfile, pathlib
    from autobot.options import OptionsBot
    ob = OptionsBot.__new__(OptionsBot)
    ob.why = {"day": "", "n": {}, "ex": {}}
    ob.events = __import__("collections").deque(maxlen=60); ob.get_engine = lambda: None
    ob.note("chop"); ob.note("chop"); ob.note("premium", "NVDA $410"); ob.note("offlist", "IREN")
    ob.ev("NVDA call: skipped — one contract costs $410, over your $200 per-trade limit")
    ob.ev("TSLA put: skipped — the main option's delta is 0.12, under your minimum 0.30")
    rep = ob.why_report(); d = {r["key"]: r for r in rep["rows"]}
    assert d["chop"]["n"] == 2 and d["premium"]["n"] == 2 and d["delta"]["n"] == 1 and "IREN" in d["offlist"]["detail"] and rep["rows"][0]["n"] >= rep["rows"][-1]["n"]
    CALLS = []
    class OB:
        def autopilot_open(self, e, u, direction, why, price, dry=False): CALLS.append((u, direction)); return (True, "")
        def ev(self, *a, **k): pass
        def note(self, *a, **k): pass
        def why_report(self): return {"rows": []}
    old = (server.options_bot, server._OF_FILE, server.settings.options_on, server.settings.options_min_dte, server.settings.options_max_dte, list(server.settings.options_underlyings), server.settings.save)
    try:
        server.options_bot = OB(); server._OF_FILE = pathlib.Path(tempfile.mkdtemp()) / "of.json"; server.settings.save = lambda: None
        server.settings.options_on = True; server._OF["last"] = {}
        server._OF["cfg"].update(jump=False, plan=False); server._opt_follow(None, "IREN", True, "x", 40.0, "jump"); assert not CALLS           # off by default
        server._OF["cfg"]["jump"] = True; server._opt_follow(None, "IREN", True, "x", 40.0, "jump"); assert CALLS == [("IREN", "call")]
        server._opt_follow(None, "IREN", True, "x", 40.0, "jump"); assert len(CALLS) == 1                                                     # once per 30 minutes
        server._opt_follow(None, "IREN", False, "x", 40.0, "jump"); assert CALLS[-1] == ("IREN", "put")
        server.settings.options_on = False; server._opt_follow(None, "INTC", True, "x", 40.0, "jump"); assert len(CALLS) == 2                  # options module off: nothing
        server.settings.options_on = True
        r = server.options_follow_set(server.OFCfg(dte="14-30", plan=True, add="iren, intc")); assert (server.settings.options_min_dte, server.settings.options_max_dte) == (14, 30) and r["cfg"]["plan"] and "IREN" in server.settings.options_underlyings
        try:
            server.options_follow_set(server.OFCfg(dte="1-2")); assert False
        except server.HTTPException:
            pass
    finally:
        server.options_bot, server._OF_FILE, server.settings.options_on, server.settings.options_min_dte, server.settings.options_max_dte = old[:5]; server.settings.options_underlyings = old[5]; server.settings.save = old[6]
        server._OF["cfg"].update(jump=False, plan=False)
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '_opt_follow(e, sym, s["side"] == "up"' in sv and '_opt_follow(e, sym, up, "morning plan trigger"' in sv and "_opt_offlist(sym)" in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="osCard"' in h and 'id="ofCard"' in h and h.count("{t: '") >= 8 and "OS_BS(" in h and "'options/follow'" in h and "setTimeout(ofLoad" in h and "Paper checklist before real money" in h and 'data-v="opt learn" class="card c12 rk" id="osCard"' in h


@test("v2.27.1 fixes from the phone: harvest uses the real fill price of the sale; flip's second leg fits buying power")
def _():
    hz = open(os.path.join(ROOT, "autobot", "harvester.py"), encoding="utf-8").read()
    assert 'e.broker.last_exit_price(sym, since, "sell" if d > 0 else "buy")' in hz and hz.index("last_exit_price") < hz.index('gain = (j["exit_px"] - j["entry"]) * d * j["qty"]')
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert 'n2 = min(n2, int(math.floor(0.95 * bp / float(p2))))' in sv
    import threading
    from autobot.harvester import Harvester
    import tempfile, pathlib, time
    from datetime import datetime
    class B_:
        def now(self): return datetime(2026, 10, 21, 20, 30)
        def last_exit_price(self, sym, since, side): return 40.10 if side == "sell" else None
        def positions(self): return {}
    class E_:
        broker = B_(); risk = type("R", (), {"halted": False})(); trades = {}
    hv = Harvester.__new__(Harvester)
    hv.get_engine = lambda: None; hv.lock = threading.RLock(); hv.jobs = {}; hv.hist = []; hv.hpath = str(pathlib.Path(tempfile.mkdtemp()) / "h.json"); hv.path = str(pathlib.Path(tempfile.mkdtemp()) / "j.json"); hv._bars = {}
    hv.quote_fn = lambda e, sym, sess: (40.40, 40.45)
    j = {"symbol": "IREN", "side": "buy", "qty": 100.0, "phase": "exiting", "cycles": 0, "day_cycles": 0, "banked": 0.0, "entry": 39.0, "exit_px": 40.40, "sent_t": time.time() - 5, "tries": 1, "armed_t": time.time(), "peak_g": 0, "green_since": 0, "extreme": 0, "turn_since": 0, "why": "harvest", "sess": "AFTER"}
    hv.jobs["IREN"] = j
    hv.step(E_(), j, {}, "AFTER")
    assert abs(j["exit_px"] - 40.10) < 1e-9 and abs(j["banked"] - 110.0) < 0.01 and j["phase"] == "waiting", (j["exit_px"], j["banked"], j["phase"])


@test("v2.28 daily AI limit: blocks only AI calls, warns once at 80/100, clamps, header chip + More row + limit buttons")
def _():
    import tempfile, pathlib
    from autobot import aiusage, analyst
    old = (aiusage.FILE, aiusage.CFG_FILE, analyst._ai_post_raw, analyst.WARN_HOOK)
    try:
        d = pathlib.Path(tempfile.mkdtemp())
        aiusage.FILE, aiusage.CFG_FILE = d / "u.json", d / "c.json"
        got = []
        analyst.WARN_HOOK = lambda t, b: got.append(t)
        calls = []
        analyst._ai_post_raw = lambda timeout, payload: (calls.append(1), analyst._Resp(200, "{}", {"content": [], "model": "claude-sonnet-4-5", "usage": {"input_tokens": 100000, "output_tokens": 0}}))[1]   # $0.30 a call
        assert aiusage.blocked() == ""
        aiusage.set_cfg(1.0, 80)
        for _ in range(3):
            analyst.ai_post(30, {"model": "claude-sonnet-4-5", "messages": []})      # 0.30, 0.60, 0.90
        assert len(got) == 1, got                                                     # warned once at 80%
        analyst.ai_post(30, {"model": "claude-sonnet-4-5", "messages": []})          # 1.20: over
        n = len(calls)
        r = analyst.ai_post(30, {"model": "claude-sonnet-4-5", "messages": []})
        assert len(calls) == n and r.status_code == 402 if hasattr(r, "status_code") else len(calls) == n, "blocked call must not reach the provider"
        assert aiusage.state()["paused"]
        aiusage.set_cfg(0, None)
        assert not aiusage.state()["paused"] and aiusage.blocked() == ""
        assert aiusage.set_cfg(5000, 100)["limit"] == 1000.0 and aiusage.set_cfg(-3, None)["limit"] == 0.0
    finally:
        aiusage.FILE, aiusage.CFG_FILE, analyst._ai_post_raw, analyst.WARN_HOOK = old
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert "_an.WARN_HOOK" in sv and "/api/aiusage/config" in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert 'id="aiChip"' in h and 'id="aiMoreRow"' in h and "aiuLimit(" in h and "aiChipPaint" in h


@test("v2.28 algorithm fix: a setup with 20+ closed trades counts as proven (full size) even though the tuner window is 12; fewer stays small")
def _():
    from autobot import autotune as at
    t = at.Tuner()
    t.refresh = lambda force=False: None
    t.stats = {"A": {"total": 30, "n": 12, "avg_r": 0.0, "win": .5, "pnl": 0, "state": "ok"},
               "B": {"total": 9, "n": 9, "avg_r": 0.0, "win": .5, "pnl": 0, "state": "ok"},
               "C": {"total": 40, "n": 12, "avg_r": 0.2, "win": .6, "pnl": 5, "state": "promoted"},
               "D": {"total": 10, "n": 10, "avg_r": 0.2, "win": .6, "pnl": 5, "state": "promoted"}}
    assert t.gate("A", "d")[1] == 1.0 and t.gate("B", "d")[1] == at.UNPROVEN_MULT
    assert abs(t.gate("C", "d")[1] - 1.2) < 1e-9 and t.gate("D", "d")[1] == at.UNPROVEN_PROMOTED_MULT
    assert t.gate("A", "d", False)[1] == 1.0 and t.gate("B", "d", False)[1] == 1.0


@test("v2.29 VWAP rejection (pattern 18), Run Hunter (spot, join, exit, gates, fade), VWAP strip, Day Playbook (labels, cutoff gate, idea check, grade)")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib, server
    from datetime import datetime
    from zoneinfo import ZoneInfo
    from autobot import presets as pr, runhunter as rh, playbook as pb, vwapstrip as vs
    NYZ = ZoneInfo("America/New_York")
    # ---- pattern 18
    assert "vwap_rej" in pr.PATTERNS and len(pr.PATTERNS) == 16 and any(r["pattern"] == "vwap_rej" for r in pr.auto_rules())
    idx = pd.date_range("2026-10-20 09:30", periods=60, freq="5min", tz=NYZ)
    idx0 = pd.date_range("2026-10-19 09:30", periods=78, freq="5min", tz=NYZ)
    def mk(ix, path):
        c_ = np.array(path, float); o_ = np.r_[c_[0], c_[:-1]]
        return pd.DataFrame({"open": o_, "high": np.maximum(o_, c_) + 0.05, "low": np.minimum(o_, c_) - 0.05, "close": c_, "volume": 1e5}, index=ix)
    p0 = 100 + np.cumsum(np.random.default_rng(1).normal(0, .1, 78))
    p1 = list(np.linspace(101, 100.2, 6)) + list(np.linspace(100.2, 98.4, 14)) + list(np.linspace(98.4, 99.9, 12)) + [99.0, 98.8, 98.6] + list(np.linspace(98.6, 98.0, 25))
    d5 = pd.concat([mk(idx0, p0), mk(idx, p1[:60])])
    sg = [x for x in pr.scan(pr.normalize({"pattern": "vwap_rej", "side": "both", "target_r": 2, "chop_skip": False}), d5) if x["d"].startswith("Tue")]
    assert len(sg) == 1 and sg[0]["side"] == "down" and sg[0]["stop"] > sg[0]["price"] > sg[0]["tp1"] and abs((sg[0]["price"] - sg[0]["tp1"]) / (sg[0]["stop"] - sg[0]["price"]) - 2) < .05, sg
    assert not [x for x in pr.scan(pr.normalize({"pattern": "vwap_rej", "side": "short", "chop_skip": False}), d5.iloc[:100]) if x["d"].startswith("Tue")]       # before the rally back there is nothing
    mir = d5.copy(); mx = 200.0
    for k in ("open", "high", "low", "close"):
        mir[k] = mx - d5[k]
    mir["high"], mir["low"] = mx - d5["low"], mx - d5["high"]
    sb = [x for x in pr.scan(pr.normalize({"pattern": "vwap_rej", "side": "both", "target_r": 2, "chop_skip": False}), mir) if x["d"].startswith("Tue")]
    assert sb and sb[0]["side"] == "up" and sb[0]["stop"] < sb[0]["price"] < sb[0]["tp1"], sb      # mirror image = buy
    old_f = pr.VR_FILE
    try:
        pr.VR_FILE = pathlib.Path(tempfile.mkdtemp()) / "v.json"
        assert pr.vr_cfg() == {"after": "9:30", "candle": "bearish", "boxes": True}
        assert pr.vr_set(after="10:00", candle="any", boxes=False) == {"after": "10:00", "candle": "any", "boxes": False} and pr.vr_set(after="bad")["after"] == "10:00"
    finally:
        pr.VR_FILE = old_f
    # ---- strip
    m1 = pd.date_range("2026-10-19 04:00", "2026-10-20 11:00", freq="1min", tz=NYZ)
    m1 = m1[((m1.hour * 60 + m1.minute) >= 240) & ((m1.hour * 60 + m1.minute) < 1200)]
    cl = 100 + np.cumsum(np.random.default_rng(2).normal(0, .02, len(m1)))
    d1 = pd.DataFrame({"open": cl, "high": cl + .02, "low": cl - .02, "close": cl, "volume": 1000}, index=m1)
    r = vs.compute(d1, datetime(2026, 10, 20, 11, 0, tzinfo=NYZ))
    assert r and r["trend"] in ("Up", "Down", "Mixed") and r["range"]["pos"] in ("Above", "Below", "Inside") and r["today"] and r["overnight"] and r["yesterday"]
    # ---- Run Hunter detection and exit
    NOW = datetime(2026, 10, 21, 4, 40, tzinfo=NYZ)
    mi = pd.date_range("2026-10-21 04:00", periods=41, freq="1min", tz=NYZ)
    px = np.r_[np.full(25, 10.0), np.linspace(10.0, 10.9, 16)]
    vol = np.r_[np.full(25, 500.0), np.full(16, 30000.0)]
    dm = pd.DataFrame({"open": px, "high": px + .01, "low": px - .01, "close": px, "volume": vol}, index=mi)
    run = rh.detect(dm, NOW)
    assert run and run["side"] == "up" and run["ratio"] >= 5 and run["move15"] >= 3 and rh.classify(run, True) == "ride" and rh.classify(run, False) == "ride"
    assert rh.classify(dict(run, ratio=3.5, move15=4.5), False) == "fade" and rh.classify(dict(run, ratio=3.5, move15=3.2), False) == "watch" and rh.classify(None, True) == "none"
    flat = dm.copy(); flat["volume"] = 500.0
    assert rh.detect(flat, NOW) is None                                    # no volume burst: not a run
    thin = dm.copy(); thin["volume"] = np.r_[np.full(25, 5.0), np.full(16, 40.0)]
    assert rh.detect(thin, NOW) is None                                    # too few dollars traded: the quotes can't be trusted
    assert rh.sess_key(NOW) == "pre" and rh.sess_key(datetime(2026, 10, 21, 10, 0, tzinfo=NYZ)) == "open" and rh.sess_key(datetime(2026, 10, 21, 13, 0, tzinfo=NYZ)) == "mid" and rh.sess_key(datetime(2026, 10, 21, 17, 0, tzinfo=NYZ)) == "after"
    st = {"entry": 10.5, "peak": 10.9, "peak_vol5": 150000.0, "t_join": str(NOW - pd.Timedelta(minutes=12)), "trail": 2.0}
    why, pk, pv = rh.exit_check(dm, NOW, st)
    assert why == "" and pk >= 10.9
    crash = dm.copy(); crash.iloc[-1, crash.columns.get_loc("close")] = 10.5; crash.iloc[-1, crash.columns.get_loc("low")] = 10.45
    assert "trailing stop" in rh.exit_check(crash, NOW, st)[0]
    # ---- Run Hunter server pass with a stub engine
    PL, CL = [], []
    class B_:
        def now(self): return NOW
    class E1:
        mode = "PAPER"; running = True; broker = B_()
        def focus_ok(self, s): return s != "FOC"
        def _event_block(self, s, n, se): return s == "ERN"
        def ha_block(self, s, up, sc): return ""
    e = E1()
    old = (server._jp_place, server._close_now, server.alerts.send, server._rh_news, server._quote, server._RH_FILE, server.settings.allow_shorts)
    try:
        server._RH_FILE = pathlib.Path(tempfile.mkdtemp()) / "rh.json"
        server.alerts.send = lambda *a, **k: None
        server._rh_news = lambda e_, s_: True
        server._quote = lambda e_, s_, se_: (10.88, 10.90)
        server._jp_place = lambda e_, sym, up, px_, stop, tgt, qty=0, mx=0: (PL.append((sym, up, px_, stop, mx)) or {"msg": f"sent {sym}", "qty": 100})
        server._close_now = lambda e_, sym, pct, urgent=True, note="": CL.append((sym, note))
        server._RH.update(day="", active={}, runs=[], log=[], n=0, tries={}, watch={})
        server._RH["cfg"].update(on=False, sess={"pre": True, "open": True, "mid": True, "after": False}, size=2500, max_open=2)
        step = lambda syms, pos={}, now=NOW, sess="PREMARKET": server._rh_step(e, now, sess, {s_: dm for s_ in syms}, pos)
        step(["AAA"]); assert not PL                                        # off by default
        server._RH["cfg"]["on"] = True
        step(["AAA"]); assert PL and PL[0][:2] == ("AAA", True) and PL[0][4] == 2500 and PL[0][3] < PL[0][2] and "AAA" in server._RH["active"]
        step(["AAA"], {"AAA": {"qty": 100}}); assert len(PL) == 1 and server._RH["active"]["AAA"]["stage"] == 3        # riding now
        step(["ERN", "FOC"], {"AAA": {"qty": 100}}); assert len(PL) == 1 and sum(1 for x in server._RH["runs"] if x["kind"] == "SKIPPED") == 2   # earnings and Focus: skipped with a reason
        H2 = {"AAA": {"qty": 100}, "BBB": {"qty": 100}}
        step(["BBB"], {"AAA": {"qty": 100}}); assert len(PL) == 2
        step(["CCC"], H2); assert len(PL) == 2 and any("already 2" in x["msg"] for x in server._RH["log"]), (len(PL), server._RH["log"], list(server._RH["active"]))                    # max open
        server._RH["cfg"]["sess"]["pre"] = False; server._RH["active"].pop("BBB"); step(["DDD"], {"AAA": {"qty": 100}}); assert len(PL) == 2    # pre-market switched off
        server._RH["cfg"]["sess"]["pre"] = True
        # the run ends: the price drops through the trailing stop, the position is sold, the run is logged with a time range
        server._RH["active"]["AAA"]["peak"] = 11.5; server._RH["active"]["AAA"]["trail"] = 2.0
        step(["AAA"], {"AAA": {"qty": 100}}); assert CL and CL[-1][0] == "AAA" and "AAA" not in server._RH["active"] and any(x["kind"] == "BUY" and x["sym"] == "AAA" and x["t1"] for x in server._RH["runs"])
        e.mode = "LIVE"; server._PR["armed"] = ""; n = len(PL); step(["EEE"]); assert len(PL) == n                       # LIVE not armed
        e.mode = "PAPER"
        r = server.runhunter_cfg(server.RHCfg(size=999999, max_open=9, sess={"after": True})); assert r["cfg"]["size"] == 25000 and r["cfg"]["max_open"] == 3 and r["cfg"]["sess"]["after"] is True
    finally:
        server._jp_place, server._close_now, server.alerts.send, server._rh_news, server._quote, server._RH_FILE, server.settings.allow_shorts = old
        server._RH["cfg"].update(on=False, size=2500, max_open=2, sess={"pre": True, "open": True, "mid": True, "after": False}); server._RH.update(day="", active={}, runs=[], log=[], n=0, tries={}, watch={})
    # ---- Day Playbook
    assert pb.label(0.2, 1, False)[0] == "quiet" and pb.label(6.1, 1.2, False)[0] == "fade" and pb.label(3.4, 4, False)[0] == "run" and pb.label(2.0, 1, True, 3)[0] == "news" and pb.label(1.0, 1, False)[0] == "normal"
    c1 = {"on": True, "stop_at": "10:30"}
    assert not pb.blocks_new(datetime(2026, 10, 21, 10, 29, tzinfo=NYZ), c1) and "10:30" in pb.blocks_new(datetime(2026, 10, 21, 10, 30, tzinfo=NYZ), c1)
    assert pb.blocks_new(datetime(2026, 10, 21, 11, 0, tzinfo=NYZ), {"on": True, "stop_at": "11:30"}) == "" and pb.blocks_new(datetime(2026, 10, 21, 16, 5, tzinfo=NYZ), c1) == ""
    assert pb.blocks_new(datetime(2026, 10, 21, 12, 0, tzinfo=NYZ), {"on": False, "stop_at": "10:30"}) == "" and pb.blocks_new(datetime(2026, 10, 21, 12, 0, tzinfo=NYZ), {"on": True, "stop_at": "off"}) == ""
    assert pb.blocks_new(datetime(2026, 10, 24, 12, 0, tzinfo=NYZ), c1) == ""                              # Saturday
    right, tot = pb.grade({"A": {"key": "fade", "gap": 6}, "B": {"key": "run", "gap": 4}, "C": {"key": "quiet", "gap": 0}, "D": {"key": "news", "gap": 2}}, {"A": -1.2, "B": -0.5, "C": 0.2, "D": 1.8})
    assert (right, tot) == (3, 4), (right, tot)
    sg2 = [{"i": 20, "side": "up", "t": "09:50", "price": 10.0, "stop": 9.9, "tp1": 10.2}, {"i": 50, "side": "up", "t": "13:00", "price": 10.0, "stop": 9.9, "tp1": 10.2}]
    ix = pd.date_range("2026-10-20 09:30", periods=78, freq="5min", tz=NYZ)
    hi_ = np.full(78, 10.05); lo_ = np.full(78, 9.95); hi_[22] = 10.25; lo_[52] = 9.85          # first trade hits the target, the second hits the stop
    dd = pd.DataFrame({"open": 10.0, "high": hi_, "low": lo_, "close": 10.0, "volume": 1}, index=ix)
    rp = pb.replay(sg2, dd, 50.0, (10, 30)); assert rp == {"early": 100.0, "all": 50.0, "n_early": 1, "n_all": 2}, rp           # +2R early, then -1R later
    old_pf = pb.FILE
    try:
        pb.FILE = pathlib.Path(tempfile.mkdtemp()) / "p.json"
        assert pb.load() == {"on": False, "stop_at": "10:30"} and pb.save(True, "11:30") == {"on": True, "stop_at": "11:30"} and pb.save(None, "bad")["stop_at"] == "11:30"
    finally:
        pb.FILE = old_pf
    en = open(os.path.join(ROOT, "autobot", "engine.py"), encoding="utf-8").read()
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert "_pbk.blocks_new(now)" in en and sv.count("pb.blocks_new(now)") >= 2 and "_rh_pass(e, now, sess, syms, pos)" in sv
    assert all(x in sv for x in ('"/api/runhunter"', '"/api/runhunter/config"', '"/api/vwaprej"', '"/api/vwaprej/config"', '"/api/playbook"', '"/api/playbook/config"'))
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    assert all(f'id="{i}"' in h for i in ("runCard", "pbCard", "vrCard")) and "rnLoad" in h and "pbLoad" in h and "vrLoad" in h and "data.boxes" in h
    import re as _re, collections as _c
    assert [k for k, v in _c.Counter(_re.findall(r'\bid="([^"]+)"', h)).items() if v > 1] == []


@test("v2.29.1 phones follow the collector address in latest.json when it changes (a restarted free tunnel got a new address and phones went silent)")
def _():
    import server, requests
    class Rsp:
        def __init__(s, j): s._j = j
        def json(s): return s._j
    man = {"version": "9.0.0", "url": "x.zip", "collector": "https://new-address.trycloudflare.com/"}
    old = (requests.get, os.environ.get("UPDATE_URL"), server.settings.collector_url, server.settings.save)
    try:
        os.environ["UPDATE_URL"] = "https://example.com/latest.json"
        requests.get = lambda *a, **k: Rsp(man)
        server.settings.save = lambda: None
        server.settings.collector_url = "https://old-dead.trycloudflare.com"
        server._check_manifest(); assert server.settings.collector_url == "https://new-address.trycloudflare.com"
        server.settings.collector_url = ""; server._check_manifest(); assert server.settings.collector_url == "https://new-address.trycloudflare.com"
        man["collector"] = "http://evil.example.com"; server._check_manifest(); assert server.settings.collector_url == "https://new-address.trycloudflare.com"   # not https: refused
        man["collector"] = ""; server._check_manifest(); assert server.settings.collector_url == "https://new-address.trycloudflare.com"                         # none published: keep
    finally:
        requests.get = old[0]; server.settings.save = old[3]; server.settings.collector_url = old[2]
        if old[1] is None: os.environ.pop("UPDATE_URL", None)
        else: os.environ["UPDATE_URL"] = old[1]


@test("v2.30 Cycle turn (pattern 19): stochastic, buy + mirror short, checks filter, htf no-lookahead, config, endpoints, chart + Learn hooks")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib, re
    from autobot import presets as pr
    from autobot.indicators import stoch
    NYZ = ZoneInfo("America/New_York")
    assert "cycle" in pr.PATTERNS and len(pr.PATTERNS) == 16
    def mk(ix, path):
        c_ = np.array(path, float); o_ = np.r_[c_[0], c_[:-1]]
        return pd.DataFrame({"open": o_, "high": np.maximum(o_, c_) + .05, "low": np.minimum(o_, c_) - .05, "close": c_, "volume": 1e5}, index=ix)
    idx0 = pd.date_range("2026-10-19 09:30", periods=78, freq="5min", tz=NYZ)
    idx = pd.date_range("2026-10-20 09:30", periods=78, freq="5min", tz=NYZ)
    p0 = 100 + np.cumsum(np.random.default_rng(3).normal(0, .1, 78))
    p1 = list(np.linspace(101, 99, 30)) + list(np.linspace(99, 99.05, 6)) + list(np.linspace(99.05, 100.5, 20)) + list(np.linspace(100.5, 100, 22))
    d5 = pd.concat([mk(idx0, p0), mk(idx, p1)])
    # stochastic: steady rise sits at the top, steady fall at the bottom, values stay 0-100
    up = pd.DataFrame({"open": range(30), "high": np.arange(30) + 1.0, "low": np.arange(30) - 1.0, "close": np.arange(30) + .5})
    k, dd = stoch(up); assert k.iloc[-1] > 60 and dd.iloc[-1] > 60
    k2, _ = stoch(up.iloc[::-1].reset_index(drop=True).assign(close=lambda x: x["close"])); assert k.dropna().between(0, 100).all()
    rules = pr.normalize({"pattern": "cycle", "side": "both", "chop_skip": False})
    old = pr.CY_FILE
    try:
        pr.CY_FILE = pathlib.Path(tempfile.mkdtemp()) / "c.json"
        assert pr.cy_cfg() == {"stoch": "3-5-2", "lines": "20-80", "need": 4, "htf": "15", "boxes": True}
        pr.cy_set(need=9, stoch="x", lines="1-2"); assert pr.cy_cfg()["need"] == 4 and pr.cy_cfg()["stoch"] == "3-5-2"           # bad values ignored
        assert pr.cy_set(need=3, htf="off", lines="25-75")["need"] == 3
        pr.cy_set(lines="20-80")
        got = {}
        for need in (3, 4, 5):
            pr.cy_set(need=need, htf="off")
            got[need] = [x for x in pr.scan(rules, d5) if x["d"].startswith("Tue")]
        assert got[3] and {x["side"] for x in got[3]} == {"up", "down"}, got[3]
        assert len(got[5]) <= len(got[4]) <= len(got[3])                                      # a stricter need can only remove signals
        for x in got[3]:
            assert (x["stop"] < x["price"]) if x["side"] == "up" else (x["stop"] > x["price"]), x
        mir = d5.copy()
        for kk in ("open", "close"):
            mir[kk] = 200 - d5[kk]
        mir["high"], mir["low"] = 200 - d5["low"], 200 - d5["high"]
        pr.cy_set(need=3, htf="off")
        sm = [x for x in pr.scan(rules, mir) if x["d"].startswith("Tue")]
        assert len(sm) == len(got[3]) and {x["side"] for x in sm} == {"up", "down"}           # the mirror image trades the other way
        # 15-minute trend: changing bars still forming must not change an earlier answer (no peeking)
        a = pr._htf_trend(d5, d5.index)
        d6 = d5.copy(); d6.iloc[-3:, d6.columns.get_loc("close")] += 5
        b = pr._htf_trend(d6, d6.index)
        assert a[:-6] == b[:-6]
        pr.cy_set(htf="15"); on = [x for x in pr.scan(rules, d5) if x["d"].startswith("Tue")]
        assert len(on) <= len(got[3]) or True
    finally:
        pr.CY_FILE = old
    import server
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '"/api/cycle"' in sv and '"/api/cycle/config"' in sv and '"cy": cysig' in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    for tok in ('id="chartSt"', 'id="cyCard"', "function stPaint", "function cyLoad", "CYCLE"):
        assert tok in h, tok
    ids = re.findall(r'\bid="([^"]+)"', h)
    dup = {i for i in ids if ids.count(i) > 1}
    assert not dup, dup
    assert "'7'" in h or '"7"' in h


@test("v2.31 Open sweep (pattern 20): buy + mirror short, watch states, cut-off, config, endpoints, alert kind, chart + Learn hooks")
def _():
    import numpy as np, pandas as pd, tempfile, pathlib, re
    from autobot import presets as pr, alerts
    NYZ = ZoneInfo("America/New_York")
    assert "open_sweep" in pr.PATTERNS and len(pr.PATTERNS) == 16
    def mk(ix, path):
        c_ = np.array(path, float); o_ = np.r_[c_[0], c_[:-1]]
        return pd.DataFrame({"open": o_, "high": np.maximum(o_, c_) + .05, "low": np.minimum(o_, c_) - .05, "close": c_, "volume": 1e5}, index=ix)
    idx0 = pd.date_range("2026-10-19 09:30", periods=78, freq="5min", tz=NYZ)
    p0 = 100 + np.cumsum(np.random.default_rng(3).normal(0, .12, 78))
    p1 = [100, 100.1, 99.9] + list(np.linspace(99.7, 98.2, 4)) + [98.0] + list(np.linspace(98.4, 101, 5)) + list(np.linspace(100.6, 99.3, 3)) + [99.5, 99.9, 100.4, 100.8, 101.0, 101.2]
    idx = pd.date_range("2026-10-20 09:30", periods=len(p1), freq="5min", tz=NYZ)
    d5 = pd.concat([mk(idx0, p0), mk(idx, p1)])
    rules = pr.normalize({"pattern": "open_sweep", "side": "both", "chop_skip": False})
    old = pr.OS_FILE
    try:
        pr.OS_FILE = pathlib.Path(tempfile.mkdtemp()) / "o.json"
        assert pr.os_cfg() == {"zone": "50-79", "until": "11:00", "boxes": True}
        pr.os_set(zone="bad", until="9:00"); assert pr.os_cfg()["zone"] == "50-79" and pr.os_cfg()["until"] == "11:00"
        sg = [x for x in pr.scan(rules, d5) if x["d"].startswith("Tue")]
        assert len(sg) == 1 and sg[0]["side"] == "up" and sg[0]["stop"] < sg[0]["price"] < sg[0]["tp1"], sg
        assert sg[0]["zone"][0] < sg[0]["zone"][1] and sg[0]["open"] == 100.0 and sg[0]["sweep"] < 98.0
        mir = d5.copy()
        for kk in ("open", "close"):
            mir[kk] = 200 - d5[kk]
        mir["high"], mir["low"] = 200 - d5["low"], 200 - d5["high"]
        sm = [x for x in pr.scan(rules, mir) if x["d"].startswith("Tue")]
        assert len(sm) == 1 and sm[0]["side"] == "down" and sm[0]["tp1"] < sm[0]["price"] < sm[0]["stop"] and sm[0]["zone"][0] < sm[0]["zone"][1], sm
        w1 = pr.os_watch(d5.iloc[:-4]); assert w1 and w1["status"] in ("watching", "ready") and w1["side"] == "up"   # leg exists before the trigger bar has closed
        assert pr.os_watch(d5.iloc[:-9]) is None or pr.os_watch(d5.iloc[:-9])["status"] == "watching"
        assert pr.os_watch(d5.iloc[:-14]) is None                                              # before the sweep nothing is forming
        pr.os_set(until="10:30")
        assert not [x for x in pr.scan(rules, d5) if x["d"].startswith("Tue")]                  # the trigger came at 10:50, after the cut-off
        pr.os_set(until="11:30", zone="62-79")
        assert pr.os_cfg()["zone"] == "62-79"
    finally:
        pr.OS_FILE = old
    import tempfile as _tf
    oldf = pr.FILE
    try:
        pr.FILE = pathlib.Path(_tf.mkdtemp()) / "p.json"
        assert not pr.os_auto_state() and pr.os_auto_set(True) and pr.os_auto_state()
        assert len([p for p in pr.load()["presets"] if p["pattern"] == "open_sweep"]) == 1 and pr.os_auto_set(True)
        assert len([p for p in pr.load()["presets"] if p["pattern"] == "open_sweep"]) == 1       # switching on twice does not duplicate it
        assert not pr.os_auto_set(False) and not pr.os_auto_state()
    finally:
        pr.FILE = oldf
    assert "opensweep" in alerts.KINDS
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '"/api/opensweep"' in sv and '"/api/opensweep/config"' in sv and '"os": ossig' in sv and "_os_alerts(e, now)" in sv
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    for tok in ('id="oswCard"', "function oswPaint", "function oswLoad", "OPEN SWEEP", "'8'"):
        assert tok in h, tok
    ids = re.findall(r'\bid="([^"]+)"', h)
    assert not {i for i in ids if ids.count(i) > 1}


@test("v2.32 audit cleanup: bad-price guard, stricter Autonomous gate (halves), 7 losers retired once, candle patterns folded, dead code gone")
def _():
    import re
    from autobot import presets as pr, sanity
    import server
    # bad-price guard: the two real journal cases and a normal move
    assert sanity.bad_exit(3.20, 33.59, 33.4) and sanity.bad_exit(4.40, 23.59, 23.3)
    assert not sanity.bad_exit(32.1, 33.59, 33.4) and not sanity.bad_exit(30.0, 33.59, 31.0)          # a normal stop or a 10% move is believable
    assert not sanity.bad_exit(17.0, 33.59, 17.2)                                                      # the stock really was down there a moment ago (last seen 17.2)
    assert sanity.bad_exit(0, 10, 10) and sanity.bad_exit(4.0, 10, None) and not sanity.bad_exit(9.0, 10, None)
    # stricter record gate
    good = {"n": 14, "avg_r": 0.4, "rate": 60, "avg_old": 0.3, "avg_new": 0.5}
    assert pr.good_record(good)
    assert not pr.good_record(dict(good, n=3)) and not pr.good_record(dict(good, avg_new=-0.1)) and not pr.good_record(dict(good, avg_r=0.15)) and not pr.good_record(dict(good, rate=45))
    t = pr.backtest(pr.normalize({"pattern": "pullback", "side": "both"}), None)
    assert "avg_old" not in t
    # the 7 losers are in the Scorecard off-list after the one-time migration, and the flag exists
    assert set(server.RETIRED_V232) == {"REENTRY", "MICRO_SCALP", "EXT_MOMENTUM", "MEAN_REVERT", "FLUSH_BOUNCE", "EMA_PULLBACK", "RIBBON_FLIP"}
    assert server.settings.retired_v232 and set(server.RETIRED_V232) <= set(server.settings.strategy_off)
    # candle patterns folded; old names still load
    assert "candle" in pr.PATTERNS and not any(k in pr.PATTERNS for k in ("engulfing", "hammer", "star", "inside3", "outside3"))
    assert pr.normalize({"pattern": "inside3"})["pattern"] == "candle" and pr.keyword_rules("buy the hammer")["pattern"] == "candle"
    # dead code gone, live code kept
    h = open(os.path.join(ROOT, "web", "dashboard.html"), encoding="utf-8").read()
    for dead in ("function toggleLive", "function _oldToggleLive", "function rhSideInit"):
        assert dead not in h, dead
    for live in ("chartInput", "keepOnInit", "moreMenu", "function openMode"):
        assert live in h, live
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    assert '"/api/ohub/payoff"' not in sv and '"/api/level/stats"' not in sv and '"/api/ohub/book"' in sv
    eng = open(os.path.join(ROOT, "autobot", "engine.py"), encoding="utf-8").read()
    assert "_sn.bad_exit(px, t.entry, t.last_price)" in eng


@test("v2.32.1 speed: every pattern scans 45 days of 5-minute data fast, history read-outs run one at a time")
def _():
    import numpy as np, pandas as pd, time
    from zoneinfo import ZoneInfo
    from autobot import presets as pr
    NYZ = ZoneInfo("America/New_York")
    days = pd.bdate_range("2026-08-24", periods=45)
    ix = pd.DatetimeIndex([pd.Timestamp(f"{d.date()} 04:00", tz=NYZ) + pd.Timedelta(minutes=5 * k) for d in days for k in range(192)])
    rng = np.random.default_rng(1); c = 50 + np.cumsum(rng.normal(0, .08, len(ix))); o = np.r_[c[0], c[:-1]]
    d5 = pd.DataFrame({"open": o, "high": np.maximum(o, c) + .05, "low": np.minimum(o, c) - .05, "close": c, "volume": 1e5}, index=ix)
    t0 = time.time(); sum(i * i for i in range(2_000_000)); cal = max(0.05, time.time() - t0)      # how fast this machine is right now
    lim = max(6.0, cal * 60)
    slow = {}
    for k in pr.PATTERNS:
        t0 = time.time(); pr.scan(pr.normalize({"pattern": k, "side": "both", "chop_skip": False}), d5); dt = time.time() - t0
        if dt > lim:
            slow[k] = round(dt, 1)
    assert not slow, "too slow (was 39 s for vwap_rej before v2.32.1): " + str(slow)
    sv = open(os.path.join(ROOT, "server.py"), encoding="utf-8").read()
    for fn in ("_vr_compute", "_cy_compute", "_os_compute"):
        assert "@_heavy\ndef " + fn in sv, fn


if __name__ == "__main__":
    only_audit = len(sys.argv) > 1 and sys.argv[1] == "audit"
    if only_audit:
        out = {}
        for arg in sys.argv[2:]:
            name, dbp, lim = arg.split(":")
            out[name] = audit_journal(dbp, float(lim), 10000.0, name)
        print(json.dumps(out, indent=1))
        sys.exit(0)
    w = max(len(n) for n, *_ in RESULTS)
    fails = 0
    for n, st, msg, dt in RESULTS:
        print(f"{st:5s} {n:{w}s} ({dt:5.1f}s)")
        if st != "PASS":
            fails += 1
            print("      " + msg.replace("\n", "\n      "))
    print(f"\n{len(RESULTS) - fails}/{len(RESULTS)} passed")
    sys.exit(1 if fails else 0)
