import base64, json, os, sys, threading, subprocess, tempfile, hashlib, zipfile, re
from http.server import BaseHTTPRequestHandler, HTTPServer
ROOT=sys.argv[1]
files={n:b'x' for n in ['SekexBot_Android_v1.90.0.zip','SekexBot_Android_v1.92.0.zip','SekexBot_Android_v1.93.2.zip','SekexBot_Android_v1.93.3.zip','admin_v1.92.0.enc','admin_v1.93.2.enc','admin_v1.93.3.enc','latest.json','README.md']}
files['latest.json']=json.dumps({'version':'1.92.0','url':'SekexBot_Android_v1.92.0.zip'}).encode()  # latest points at an OLD file: must be protected
deleted=[]
class H(BaseHTTPRequestHandler):
    def log_message(s,*a): pass
    def _send(s,code,obj):
        b=json.dumps(obj).encode(); s.send_response(code); s.send_header('Content-Type','application/json'); s.end_headers(); s.wfile.write(b)
    def do_GET(s):
        p=s.path.split('?')[0]
        if p.endswith('/contents/') or p.endswith('/contents'): return s._send(200,[{'name':n,'sha':'sha-'+n} for n in files])
        n=p.split('/contents/')[1]
        if n in files: return s._send(200,{'name':n,'sha':'sha-'+n,'content':base64.b64encode(files[n]).decode()})
        return s._send(404,{})
    def do_DELETE(s):
        n=s.path.split('/contents/')[1]; body=json.loads(s.rfile.read(int(s.headers['Content-Length'])))
        assert body['sha']=='sha-'+n; files.pop(n); deleted.append(n); s._send(200,{})
srv=HTTPServer(('127.0.0.1',0),H); threading.Thread(target=srv.serve_forever,daemon=True).start()
home=tempfile.mkdtemp(); dl=os.path.join(home,'storage','downloads'); os.makedirs(dl)
for f in ['SekexBot_Android_v1.91.0.zip','SekexBot_Android_v1.93.1.zip','SekexBot_Android_v1.93.2.zip','SekexBot_Android_v1.93.3.zip','SekexBot_Admin_v1.93.0.zip','SekexBot_Admin_v1.93.3.zip','SekexBot_Android_Release_Notes_and_Install_v1.93.1.pdf','SekexBot_Android_Release_Notes_and_Install_v1.93.2.pdf','SekexBot_Android_Release_Notes_and_Install_v1.93.3.pdf','SekexBot_Setup.sh','sekexbot-setup.conf','latest.json','mine.txt']:
    open(os.path.join(dl,f),'w').write('x')
for i in range(3): 
    p=os.path.join(dl,f'SekexBot_backup_2026100{i}_1200.zip'); open(p,'w').write('k'); os.utime(p,(1000+i,1000+i))
rel=os.path.join(home,'.sekexbot','releases'); os.makedirs(rel)
for v in ['1.93.1','1.93.2','1.93.3']: open(os.path.join(rel,f'SekexBot_Android_v{v}.zip'),'w').write('x')
os.makedirs(os.path.join(home,'.sekexbot_setup_tmp')); os.makedirs(os.path.join(home,'sekexbot','data')); open(os.path.join(home,'sekexbot','.env'),'w').write('KEY')
json.dump({'repo':'o/r','token':'t','branch':'main'},open(os.path.join(home,'.sekexbot','github.json'),'w'))
env=dict(os.environ,HOME=home,SEKEX_GITHUB_API=f'http://127.0.0.1:{srv.server_port}')
def run(*a): 
    r=subprocess.run([sys.executable,os.path.join(ROOT,'bin','sekex_ship.py'),*a],env=env,capture_output=True,text=True,input='n\n'); return r.stdout+r.stderr
out=run('clean','--dry-run'); print(out)
assert deleted==[] and os.path.exists(os.path.join(dl,'SekexBot_Android_v1.91.0.zip')), 'dry run must not delete'
out=run('clean','--yes'); print(out)
left=sorted(os.listdir(dl)); print(left)
for must in ['SekexBot_Setup.sh','sekexbot-setup.conf','latest.json','mine.txt','SekexBot_Android_v1.93.3.zip','SekexBot_Android_v1.93.2.zip']: assert must in left, must

assert 'SekexBot_Android_v1.91.0.zip' not in left and 'SekexBot_Android_v1.93.1.zip' not in left
assert sum(1 for f in left if f.startswith('SekexBot_backup'))==2 and sum(1 for f in left if 'Release_Notes' in f)==2
assert sorted(os.listdir(rel))==['SekexBot_Android_v1.93.2.zip','SekexBot_Android_v1.93.3.zip']
assert not os.path.exists(os.path.join(home,'.sekexbot_setup_tmp')) and os.path.exists(os.path.join(home,'sekexbot','.env')) and os.path.isdir(os.path.join(home,'sekexbot','data'))
print('deleted on GitHub:',sorted(deleted)); assert sorted(deleted)==['SekexBot_Android_v1.90.0.zip','admin_v1.92.0.enc']
assert 'SekexBot_Android_v1.92.0.zip' not in deleted, 'file latest.json points at must be protected'
assert 'latest.json' in files and 'README.md' in files and 'SekexBot_Android_v1.93.3.zip' in files and 'SekexBot_Android_v1.93.2.zip' in files
print('OK')
