"""SekexBot support-admin add-on (server side). Installed only on the admin's phone, never part of the public app.

Registers /api/admin/* routes that forward to the support collector. The passcode is checked by the collector."""
import json
import urllib.error
import urllib.request

from fastapi import Header, HTTPException
from pydantic import BaseModel


def register(app, settings, telemetry):
    def collector_call(method, path, body=None, token=None):
        base = telemetry.collector_url(settings)
        if not base:
            raise HTTPException(400, "Set the collector address first.")
        req = urllib.request.Request(base + path, method=method, data=json.dumps(body).encode() if body is not None else None,
                                     headers={"Content-Type": "application/json", **({"Authorization": "Bearer " + token} if token else {})})
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                return json.loads(resp.read() or b"{}")
        except urllib.error.HTTPError as ex:
            try:
                detail = json.loads(ex.read()).get("detail", "")
            except Exception:
                detail = ""
            raise HTTPException(ex.code, detail or f"Collector said {ex.code}")
        except Exception as ex:
            raise HTTPException(502, f"Couldn't reach the collector: {str(ex)[:100]}")

    class AdminLogin(BaseModel):
        passcode: str
        collector_url: str | None = None

    @app.post("/api/admin/login")
    def admin_login(r: AdminLogin):
        if r.collector_url is not None and r.collector_url.strip():
            u = r.collector_url.strip().rstrip("/")
            if not telemetry.valid_url(u):
                raise HTTPException(400, "The collector address must start with https://")
            settings.collector_url = u
            settings.save()
        return collector_call("POST", "/v1/admin/login", {"passcode": r.passcode})

    @app.get("/api/admin/devices")
    def admin_devices(x_admin_token: str | None = Header(None)):
        return collector_call("GET", "/v1/admin/devices", token=x_admin_token)

    @app.get("/api/admin/device/{iid}")
    def admin_device(iid: str, hours: int = 6, x_admin_token: str | None = Header(None)):
        return collector_call("GET", f"/v1/admin/device/{iid}?hours={int(hours)}", token=x_admin_token)

    @app.delete("/api/admin/device/{iid}")
    def admin_device_delete(iid: str, x_admin_token: str | None = Header(None)):
        return collector_call("DELETE", f"/v1/admin/device/{iid}", token=x_admin_token)
