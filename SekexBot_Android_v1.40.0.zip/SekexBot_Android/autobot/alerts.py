"""Alerts: tell you instantly what the bot did, when risk rules fire, and when your watchlist moves.

Delivery (each optional, set on the dashboard):
  * phone notification (Termux:API) with buttons: Trade (opens the quick-trade sheet) and Close
  * ntfy.sh topic  - push to any phone/PC with the free ntfy app (no account)
  * Telegram bot   - message to your chat
Every alert is also kept in a short history the dashboard shows under the bell.
"""
import json
import logging
import shutil
import subprocess
import threading
import time
from collections import deque
from datetime import datetime
from zoneinfo import ZoneInfo

import requests

from .config import DATA_DIR

log = logging.getLogger("autobot")
NY = ZoneInfo("America/New_York")
CFG_FILE = DATA_DIR / "alerts.json"

# kind -> (group, label, default on)
KINDS = {
    "entry":      ("trades", "Bot entries", True),
    "fill":       ("trades", "Fills", False),
    "exit":       ("trades", "Bot exits (with P&L)", True),
    "profit":     ("trades", "Took profit (partial sells)", True),
    "breakeven":  ("trades", "Stop moved to breakeven / trailing", False),
    "reject":     ("trades", "Orders rejected", True),
    "manual":     ("trades", "Your manual orders", False),
    "halt":       ("risk", "Daily loss halt / profit lock", True),
    "streak":     ("risk", "Losing streak pause", True),
    "restrict":   ("risk", "Broker restriction / account blocked", True),
    "stale":      ("risk", "Stale data exit (overnight)", True),
    "system":     ("risk", "App restarted / errors", True),
    "movers":     ("trend", "Morning / evening big-movers list", True),
    "ribbon":     ("trend", "Ribbon flip (watchlist)", True),
    "range":      ("trend", "New high / low of day (watchlist)", True),
    "vwap":       ("trend", "VWAP reclaim / loss (watchlist)", False),
    "volume":     ("trend", "Volume spike (watchlist)", False),
    "price":      ("price", "Price alerts you set", True),
    "summary":    ("summary", "End-of-day summary", True),
}
DEFAULTS = {"enabled": {k: v[2] for k, v in KINDS.items()},
            "phone": True, "quiet_start": "", "quiet_end": "", "quiet_keep_risk": True,
            "ntfy_topic": "", "ntfy_server": "https://ntfy.sh", "tg_token": "", "tg_chat": "",
            "price_alerts": []}


class Alerts:
    def __init__(self, port=8010):
        self.port = port
        self.lock = threading.Lock()
        self.history = deque(maxlen=150)
        self.cfg = json.loads(json.dumps(DEFAULTS))
        self._recent = {}
        self._nid = 0
        self.load()

    # ---------- settings ----------
    def load(self):
        try:
            data = json.loads(CFG_FILE.read_text())
            for k, v in data.items():
                if k == "enabled":
                    self.cfg["enabled"].update({a: bool(b) for a, b in v.items() if a in KINDS})
                elif k in self.cfg:
                    self.cfg[k] = v
        except Exception:
            pass

    def save(self):
        try:
            tmp = CFG_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.cfg, indent=1))
            tmp.replace(CFG_FILE)
        except Exception as e:
            log.warning("Could not save alert settings: %s", e)

    def public_cfg(self):
        c = {k: v for k, v in self.cfg.items() if k not in ("tg_token",)}
        c["tg_token_set"] = bool(self.cfg.get("tg_token"))
        c["kinds"] = [{"kind": k, "group": g, "label": lbl} for k, (g, lbl, _) in KINDS.items()]
        c["phone_available"] = bool(shutil.which("termux-notification"))
        return c

    # ---------- quiet hours ----------
    def _quiet(self, kind):
        qs, qe = self.cfg.get("quiet_start"), self.cfg.get("quiet_end")
        if not qs or not qe:
            return False
        if self.cfg.get("quiet_keep_risk", True) and KINDS.get(kind, ("",))[0] == "risk":
            return False
        now = datetime.now(NY).strftime("%H:%M")
        return (qs <= now < qe) if qs < qe else (now >= qs or now < qe)

    # ---------- send ----------
    def send(self, kind, title, body="", symbol=None, pnl=None, close_btn=False, level="info"):
        if kind not in KINDS or not self.cfg["enabled"].get(kind, False):
            return False
        key = (kind, symbol, title)
        now = time.time()
        if now - self._recent.get(key, 0) < 45:            # de-duplicate bursts
            return False
        self._recent[key] = now
        item = {"t": datetime.now(NY).strftime("%m-%d %H:%M:%S"), "kind": kind, "group": KINDS[kind][0],
                "title": title, "body": body, "symbol": symbol, "pnl": pnl, "level": level, "id": int(now * 1000)}
        with self.lock:
            self.history.appendleft(item)
        if self._quiet(kind):
            return True
        threading.Thread(target=self._deliver, args=(item, close_btn), daemon=True).start()
        return True

    def _deliver(self, it, close_btn):
        text = it["title"] + (("\n" + it["body"]) if it["body"] else "")
        if self.cfg.get("phone") and shutil.which("termux-notification"):
            try:
                self._nid = (self._nid + 1) % 50
                url = f"http://127.0.0.1:{self.port}/"
                args = ["termux-notification", "--id", f"sekex-a{self._nid}", "--group", "sekexbot-alerts",
                        "--title", it["title"], "--content", it["body"] or it["title"],
                        "--priority", "high" if it["group"] in ("risk", "trades") else "default",
                        "--action", f"termux-open-url {url}"]
                if it["group"] == "risk":
                    args += ["--vibrate", "300,150,300"]
                if it["symbol"]:
                    args += ["--button1", "Trade", "--button1-action", f"termux-open-url {url}#trade={it['symbol']}"]
                    if close_btn:
                        args += ["--button2", "Close", "--button2-action", f"sekex close {it['symbol']} --gui"]
                subprocess.run(args, timeout=10, capture_output=True)
            except Exception as e:
                log.debug("phone alert failed: %s", e)
        if self.cfg.get("ntfy_topic"):
            try:
                srv = (self.cfg.get("ntfy_server") or "https://ntfy.sh").rstrip("/")
                tags = {"risk": "warning", "trades": "chart_with_upwards_trend", "trend": "bell",
                        "price": "dart", "summary": "memo"}.get(it["group"], "bell")
                requests.post(f"{srv}/{self.cfg['ntfy_topic']}", data=(it["body"] or it["title"]).encode(),
                              headers={"Title": it["title"].encode("ascii", "ignore").decode() or "SekexBot",
                                       "Tags": tags, "Priority": "high" if it["group"] == "risk" else "default"},
                              timeout=10)
            except Exception as e:
                log.debug("ntfy alert failed: %s", e)
        if self.cfg.get("tg_token") and self.cfg.get("tg_chat"):
            try:
                requests.post(f"https://api.telegram.org/bot{self.cfg['tg_token']}/sendMessage",
                              json={"chat_id": self.cfg["tg_chat"], "text": text}, timeout=10)
            except Exception as e:
                log.debug("telegram alert failed: %s", e)

    def test(self):
        self._recent.clear()
        on = self.cfg["enabled"].get("system")
        self.cfg["enabled"]["system"] = True
        self.send("system", "SekexBot test alert", "If you can read this, alerts work.", symbol="SPY")
        self.cfg["enabled"]["system"] = on
