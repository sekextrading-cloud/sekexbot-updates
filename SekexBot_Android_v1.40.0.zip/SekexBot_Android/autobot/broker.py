"""Alpaca broker adapter (alpaca-py). The engine only talks to this small interface,
so the same engine runs against the offline simulator in sim.py."""
import time as _time
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

import pandas as pd

from alpaca.data.enums import DataFeed, MostActivesBy
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.historical.screener import ScreenerClient
from alpaca.data.requests import (MarketMoversRequest, MostActivesRequest, StockBarsRequest,
                                  StockLatestQuoteRequest, StockSnapshotRequest)
from alpaca.data.timeframe import TimeFrame
from alpaca.trading.client import TradingClient
from alpaca.trading.enums import AssetClass, AssetStatus, OrderClass, OrderSide, QueryOrderStatus, TimeInForce
from alpaca.trading.requests import (ClosePositionRequest, GetAssetsRequest, GetCalendarRequest, GetOrdersRequest,
                                     LimitOrderRequest, MarketOrderRequest, ReplaceOrderRequest, StopLimitOrderRequest,
                                     StopLossRequest, StopOrderRequest, TakeProfitRequest, TrailingStopOrderRequest)

NY = ZoneInfo("America/New_York")


def _px(x: float) -> float:
    """Alpaca price increments: 2 decimals >= $1, 4 decimals below."""
    return round(x, 2) if x >= 1 else round(x, 4)


import logging as _logging
log = _logging.getLogger("autobot")

class AlpacaBroker:
    def __init__(self, key: str, secret: str, paper: bool, feed: str = "iex"):
        if not key or not secret:
            raise ValueError("Missing Alpaca API key/secret for " + ("paper" if paper else "LIVE") + " mode (.env)")
        self.paper = paper
        self.trading = TradingClient(key, secret, paper=paper)
        self.data = StockHistoricalDataClient(key, secret)
        self.screener = ScreenerClient(key, secret)
        self.feed = DataFeed.SIP if feed.lower() == "sip" else DataFeed.IEX
        self._asset_cache = {}
        self._cal = {}
        self._overnight_ok = {}
        self.live = None            # autobot.stream.LiveFeed, set by the server
        self._pc = {}               # sym -> (prev_close, fetched_at)

    # ---- time ----
    def now(self) -> datetime:
        return datetime.now(NY)

    def sleep(self, seconds: float):
        _time.sleep(seconds)

    def clock(self) -> dict:
        c = self.trading.get_clock()
        return {"is_open": c.is_open,
                "next_open": c.next_open.astimezone(NY),
                "next_close": c.next_close.astimezone(NY)}

    # ---- account ----
    def account(self) -> dict:
        a = self.trading.get_account()
        return {"equity": float(a.equity), "last_equity": float(a.last_equity),
                "buying_power": float(a.buying_power), "cash": float(a.cash),
                "daytrade_count": int(getattr(a, "daytrade_count", 0) or 0),        # retired Jun 2026 (always 0)
                "pattern_day_trader": bool(getattr(a, "pattern_day_trader", False)),  # removed from API Jul 2026
                "blocked": bool(getattr(a, 'trading_blocked', False) or getattr(a, 'account_blocked', False)),
                "shorting_enabled": bool(a.shorting_enabled)}

    def positions(self) -> dict:
        out = {}
        for p in self.trading.get_all_positions():
            q = float(p.qty)
            out[p.symbol] = {"qty": q, "avg_entry": float(p.avg_entry_price),
                             "price": float(p.current_price or 0), "upl": float(p.unrealized_pl or 0)}
        return out

    # ---- market data ----
    def _tradable(self, sym: str, need_short: bool) -> bool:
        a = self._asset_cache.get(sym)
        if a is None:
            try:
                a = self.trading.get_asset(sym)
            except Exception:
                a = False
            self._asset_cache[sym] = a
        if not a or not a.tradable:
            return False
        return (a.shortable and a.easy_to_borrow) if need_short else True

    def recheck_borrow(self, sym: str):
        """Fresh (uncached) borrow check right before a short. Alpaca reports borrow_status:
        'easy_to_borrow' (no locate needed) or 'hard_to_borrow' (needs a locate: we skip those). Returns (ok, status)."""
        try:
            raw = self.trading.get(f"/assets/{sym}")
            if isinstance(raw, dict):
                status = raw.get("borrow_status") or ("easy_to_borrow" if raw.get("easy_to_borrow") else "hard_to_borrow")
                ok = bool(raw.get("tradable")) and bool(raw.get("shortable")) and status == "easy_to_borrow"
                self._asset_cache.pop(sym, None)
                return ok, status
        except Exception:
            pass
        try:                                                     # fallback: the SDK model
            a = self.trading.get_asset(sym)
            self._asset_cache[sym] = a
            status = "easy_to_borrow" if a.easy_to_borrow else "hard_to_borrow"
            return bool(a.tradable and a.shortable and a.easy_to_borrow), status
        except Exception:
            return False, "unknown"

    def _tradable_set(self):
        today = self.now().date()
        if getattr(self, "_assets_day", None) != today:
            try:
                assets = self.trading.get_all_assets(GetAssetsRequest(status=AssetStatus.ACTIVE,
                                                                      asset_class=AssetClass.US_EQUITY))
                self._assets = {a.symbol for a in assets if a.tradable}
                self._assets_day = today
            except Exception:
                self._assets = getattr(self, "_assets", set())
        return self._assets

    def _daily_stats(self, symbols) -> dict:
        """20-day stats from SIP daily bars (free plan allows SIP history older than 15 minutes)."""
        now = self.now()
        out = {}
        for i in range(0, len(symbols), 200):
            chunk = symbols[i:i + 200]
            try:
                df = self.data.get_stock_bars(StockBarsRequest(
                    symbol_or_symbols=chunk, timeframe=TimeFrame.Day, start=now - timedelta(days=45),
                    end=now - timedelta(minutes=16), feed=DataFeed.SIP, adjustment="split")).df
            except Exception:
                try:   # fall back to the account's own feed
                    df = self.data.get_stock_bars(StockBarsRequest(
                        symbol_or_symbols=chunk, timeframe=TimeFrame.Day, start=now - timedelta(days=45),
                        end=now - timedelta(minutes=16), feed=self.feed)).df
                except Exception:
                    continue
            if df is None or df.empty:
                continue
            for sym in df.index.get_level_values(0).unique():
                d = df.xs(sym, level=0).copy()
                d.index = pd.to_datetime(d.index).tz_convert(NY)
                today_vol = None
                if len(d) and d.index[-1].date() == now.date():
                    today_vol = float(d["volume"].iloc[-1])
                    d = d.iloc[:-1]
                if len(d) < 5:
                    continue
                last = d.iloc[-20:]
                pc = d["close"].shift()
                tr = pd.concat([d["high"] - d["low"], (d["high"] - pc).abs(), (d["low"] - pc).abs()], axis=1).max(axis=1)
                out[sym] = {"prev_close": float(d["close"].iloc[-1]), "adv": float(last["volume"].mean()),
                            "atr": float(tr.iloc[-14:].mean()), "sma20": float(last["close"].mean()),
                            "hi20": float(last["high"].max()), "lo20": float(last["low"].min()),
                            "today_vol": today_vol}
        return out

    def scan(self, s, acct=None) -> tuple[list, dict]:
        """Picks the best stocks for this account: most-active + movers + a liquid core list + your
        watchlist, scored for opportunity (gap, RVOL, ATR%, trend) x fit (size, buying power, liquidity)."""
        from .scanner import CORE, score_candidates, volume_day_fraction
        mine = [w.upper() for w in getattr(s, "watchlist", [])]
        cands, mover = set(CORE), set()
        for by in (MostActivesBy.VOLUME, MostActivesBy.TRADES):
            try:
                for m in self.screener.get_most_actives(MostActivesRequest(top=100, by=by)).most_actives:
                    cands.add(m.symbol)
            except Exception:
                pass
        try:
            mv = self.screener.get_market_movers(MarketMoversRequest(top=50))
            for m in list(mv.gainers) + list(mv.losers):
                cands.add(m.symbol)
                mover.add(m.symbol)
        except Exception:
            pass
        tradable = self._tradable_set()
        pool = [c for c in dict.fromkeys(mine + sorted(cands))
                if (c.isalpha() or "." in c) and (not tradable or c in tradable or c in mine)]
        stats = self._daily_stats(pool)
        snaps = {}
        for i in range(0, len(pool), 100):
            try:
                snaps.update(self.data.get_stock_snapshot(StockSnapshotRequest(symbol_or_symbols=pool[i:i + 100],
                                                                               feed=self.feed)))
            except Exception:
                pass
        rows = []
        for sym in pool:
            st, sn = stats.get(sym), snaps.get(sym)
            if not st:
                continue
            price, spread = None, None
            try:
                q = sn.latest_quote if sn else None
                if q and q.bid_price and q.ask_price:
                    mid = (q.bid_price + q.ask_price) / 2
                    spread = (q.ask_price - q.bid_price) / mid * 100 if mid else None
                if sn and sn.latest_trade:
                    price = float(sn.latest_trade.price)
                elif q and q.bid_price and q.ask_price:
                    price = mid
            except Exception:
                pass
            rows.append(dict(st, sym=sym, price=price or st["prev_close"], spread_pct=spread,
                             mover=sym in mover, watch=sym in mine))
        now = self.now()
        mins = (now - now.replace(hour=9, minute=30, second=0, microsecond=0)).total_seconds() / 60 - 16
        acct = acct or self.account()
        ranked = score_candidates(rows, acct, s, volume_day_fraction(mins) if mins > 0 else None)
        top = [r for r in ranked if r["watch"]] + [r for r in ranked if not r["watch"]][: s.universe_size]
        self.last_scan_info = top
        return [r["symbol"] for r in top], {r["symbol"]: r["gap"] for r in ranked}

    def bars(self, symbols: list, start: datetime | None = None) -> dict:
        if not symbols:
            return {}
        now = self.now()
        if start is None:
            start = now.replace(hour=9, minute=30, second=0, microsecond=0) - timedelta(minutes=1)
        req = StockBarsRequest(symbol_or_symbols=symbols, timeframe=TimeFrame.Minute,
                               start=start, feed=self.feed)
        df = self.data.get_stock_bars(req).df
        out = {}
        if df is None or df.empty:
            return out
        for sym in df.index.get_level_values(0).unique():
            d = df.xs(sym, level=0)[["open", "high", "low", "close", "volume"]].copy()
            d.index = pd.to_datetime(d.index).tz_convert(NY)
            out[sym] = d
        return out

    def history(self, symbols: list, days: int = 8) -> dict:
        """Several days of 1-minute bars (pre-market included) for the overnight study."""
        out = {}
        now = self.now()
        for i in range(0, len(symbols), 15):
            chunk = symbols[i:i + 15]
            df = None
            for end in (None, now - timedelta(minutes=16)):     # free plans: recent SIP-style data must be 15 min old
                try:
                    df = self.data.get_stock_bars(StockBarsRequest(symbol_or_symbols=chunk, timeframe=TimeFrame.Minute,
                                                                   start=now - timedelta(days=days), end=end, feed=self.feed)).df
                    if df is not None and not df.empty:
                        break
                except Exception:
                    df = None
            if df is None or df.empty:
                continue
            for sym in df.index.get_level_values(0).unique():
                d = df.xs(sym, level=0)[["open", "high", "low", "close", "volume"]].copy()
                d.index = pd.to_datetime(d.index).tz_convert(NY)
                out[sym] = d
        return out

    def analysis_bars(self, sym: str):
        """1-minute bars for the chart read: today's if there are enough, otherwise the most recent
        completed session (nights, weekends, holidays, or early in the morning)."""
        try:
            today = self.bars([sym]).get(sym)
        except Exception:
            today = None
        if today is not None and len(today) >= 20:
            return today, "live"
        now = self.now()
        df = None
        for feed in (DataFeed.SIP, self.feed):    # free plan: SIP history is fine if older than 15 min
            try:
                df = self.data.get_stock_bars(StockBarsRequest(
                    symbol_or_symbols=sym, timeframe=TimeFrame.Minute, start=now - timedelta(days=7),
                    end=now - timedelta(minutes=16), feed=feed)).df
                if df is not None and not df.empty:
                    break
            except Exception:
                df = None
        if df is None or df.empty:
            return today, "live"
        d = df.xs(sym, level=0)[["open", "high", "low", "close", "volume"]].copy()
        d.index = pd.to_datetime(d.index).tz_convert(NY)
        reg = d[(d.index.time >= datetime.min.time().replace(hour=9, minute=30)) &
                (d.index.time < datetime.min.time().replace(hour=16))]
        if reg.empty:
            return today, "live"
        last_day = reg.index[-1].date()
        out = reg[reg.index.date == last_day]
        return out, f"last session {last_day.strftime('%a %b %d')}"

    def chart_bars(self, sym: str, days: int = 4):
        """1-minute bars for the chart at ANY time: the last few days including pre-market, after-hours
        and the overnight (24-hour) session, so nights and weekends show the most recent real prices."""
        now = self.now()
        frames = []
        feeds = [(self.feed, None)]
        if self.feed != DataFeed.SIP:
            feeds.append((DataFeed.SIP, now - timedelta(minutes=16)))   # free plans: SIP history older than 15 min
        for feed, end in feeds:
            try:
                df = self.data.get_stock_bars(StockBarsRequest(symbol_or_symbols=sym, timeframe=TimeFrame.Minute,
                                                               start=now - timedelta(days=days), end=end, feed=feed)).df
                if df is not None and not df.empty:
                    frames.append(df)
                    break
            except Exception:
                continue
        for feed in ((DataFeed.BOATS, DataFeed.OVERNIGHT) if self.feed == DataFeed.SIP else (DataFeed.OVERNIGHT,)):
            try:
                df = self.data.get_stock_bars(StockBarsRequest(symbol_or_symbols=sym, timeframe=TimeFrame.Minute,
                                                               start=now - timedelta(days=days), feed=feed)).df
                if df is not None and not df.empty:
                    frames.append(df)
                    break
            except Exception:
                continue
        if not frames:
            return None
        d = pd.concat(frames)
        d = d.xs(sym, level=0)[["open", "high", "low", "close", "volume"]].copy()
        d.index = pd.to_datetime(d.index).tz_convert(NY)
        d = d[~d.index.duplicated(keep="first")].sort_index()
        return d

    def shortable(self, sym: str) -> bool:
        return self._tradable(sym, need_short=True)

    # ---- orders ----
    def submit_bracket(self, sym, side, qty, limit_price, stop, target, client_id) -> str:
        req = LimitOrderRequest(
            symbol=sym, qty=qty, side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
            time_in_force=TimeInForce.DAY, limit_price=_px(limit_price),
            order_class=OrderClass.BRACKET,
            take_profit=TakeProfitRequest(limit_price=_px(target)),
            stop_loss=StopLossRequest(stop_price=_px(stop)),
            client_order_id=client_id)
        return str(self.trading.submit_order(req).id)

    def oco_exit(self, sym, side, qty, stop, target, client_id) -> str:
        """Broker-held GTC exit for a position we keep overnight: one order, a target and a stop, cancel-each-other.
        side is the EXIT side ('buy' to cover a short)."""
        req = LimitOrderRequest(
            symbol=sym, qty=qty, side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
            time_in_force=TimeInForce.GTC, limit_price=_px(target), order_class=OrderClass.OCO,
            take_profit=TakeProfitRequest(limit_price=_px(target)),
            stop_loss=StopLossRequest(stop_price=_px(stop)),
            client_order_id=client_id)
        return str(self.trading.submit_order(req).id)

    def submit_limit_day(self, sym, side, qty, limit_price, client_id) -> str:
        req = LimitOrderRequest(symbol=sym, qty=qty, side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
                                time_in_force=TimeInForce.DAY, limit_price=_px(limit_price), client_order_id=client_id)
        return str(self.trading.submit_order(req).id)

    def entry_status(self, order_id) -> tuple:
        o = self.trading.get_order_by_id(order_id)
        st = str(o.status.value if hasattr(o.status, "value") else o.status)
        px = float(o.filled_avg_price) if o.filled_avg_price else None
        return st, px, float(o.filled_qty or 0)

    def cancel(self, order_id):
        try:
            self.trading.cancel_order_by_id(order_id)
        except Exception:
            pass

    def _open_orders(self, sym):
        orders = self.trading.get_orders(GetOrdersRequest(status=QueryOrderStatus.OPEN, symbols=[sym], nested=True))
        flat = []
        for o in orders:
            flat.append(o)
            flat.extend(o.legs or [])
        return flat

    def update_stop(self, sym, new_stop) -> bool:
        try:
            for o in self._open_orders(sym):
                t = str(o.order_type.value if hasattr(o.order_type, "value") else o.order_type)
                if t in ("stop", "stop_limit") and o.stop_price is not None:
                    self.trading.replace_order_by_id(str(o.id), ReplaceOrderRequest(stop_price=_px(new_stop)))
                    return True
        except Exception:
            return False
        return False

    def partial_exit(self, sym, qty, side, new_stop, target=None):
        """Take profit on part of a position: cancel its bracket legs, sell `qty` at market, then protect
        what's left with a new stop order at `new_stop`. Returns the shares still held."""
        exit_side = OrderSide.SELL if side == "buy" else OrderSide.BUY
        for o in self._open_orders(sym):
            self.cancel(str(o.id))
        _time.sleep(0.6)
        self.trading.submit_order(MarketOrderRequest(symbol=sym, qty=qty, side=exit_side, time_in_force=TimeInForce.DAY))
        rem = 0.0
        for _ in range(6):
            _time.sleep(0.5)
            try:
                rem = abs(float(self.trading.get_open_position(sym).qty))
            except Exception:
                rem = 0.0
            if rem > 0:
                break
        if rem > 0:
            try:
                self.trading.submit_order(StopOrderRequest(symbol=sym, qty=rem, side=exit_side,
                                                           time_in_force=TimeInForce.DAY, stop_price=_px(new_stop)))
            except Exception as e:
                log.warning("Protective stop after partial exit on %s failed: %s (bot will watch it)", sym, e)
        return rem

    def close_position(self, sym):
        try:
            for o in self._open_orders(sym):
                self.cancel(str(o.id))
            _time.sleep(0.5)
            self.trading.close_position(sym)
            return True
        except Exception as e:
            log.warning("Close %s failed: %s", sym, e)
            self.last_close_error = f"{sym}: {e}"
            return False

    def close_all(self):
        self.trading.close_all_positions(cancel_orders=True)

    def last_exit_price(self, sym, since: datetime, exit_side: str):
        try:
            orders = self.trading.get_orders(GetOrdersRequest(
                status=QueryOrderStatus.CLOSED, symbols=[sym], after=since - timedelta(minutes=1),
                nested=True, limit=50))
            fills = []
            for o in orders:
                for x in [o] + list(o.legs or []):
                    side = str(x.side.value if hasattr(x.side, "value") else x.side)
                    if side == exit_side and x.filled_avg_price and x.filled_at:
                        fills.append((x.filled_at, float(x.filled_avg_price)))
            return max(fills)[1] if fills else None
        except Exception:
            return None

    # ================= extended hours (pre-market / after-hours / overnight) =================
    def trading_day(self, d):
        """(open, close) datetimes for date d, or None if the market is closed that day."""
        key = (d.year, d.month)
        if key not in self._cal:
            first = d.replace(day=1)
            last = (first + timedelta(days=40)).replace(day=1) - timedelta(days=1)
            try:
                cal = self.trading.get_calendar(GetCalendarRequest(start=first, end=last))
                m = {}
                for c in cal:
                    op, cl = c.open, c.close
                    if op.tzinfo is None:
                        op, cl = op.replace(tzinfo=NY), cl.replace(tzinfo=NY)
                    m[c.date] = (op.astimezone(NY), cl.astimezone(NY))
                self._cal[key] = m
            except Exception:
                # fall back to weekdays with normal hours if the calendar call fails
                return (datetime.combine(d, datetime.min.time(), NY).replace(hour=9, minute=30),
                        datetime.combine(d, datetime.min.time(), NY).replace(hour=16)) if d.weekday() < 5 else None
        return self._cal[key].get(d)

    def _quote_feed(self, session):
        if session == "OVERNIGHT":
            return DataFeed.BOATS if self.feed == DataFeed.SIP else DataFeed.OVERNIGHT
        return self.feed

    def quotes(self, symbols, session="AFTER") -> dict:
        out = {}
        if not symbols:
            return out
        if self.live and session != "OVERNIGHT":
            rest = []
            for sym in symbols:
                lv = self.live.get(sym, max_age=10)
                if lv and lv.get("bid"):
                    out[sym] = (lv["bid"], lv["ask"], self.now() - timedelta(seconds=lv["age"]))
                else:
                    rest.append(sym)
            symbols = rest
            if not symbols:
                return out
        try:
            q = self.data.get_stock_latest_quote(StockLatestQuoteRequest(symbol_or_symbols=list(symbols),
                                                                         feed=self._quote_feed(session)))
            for sym, v in q.items():
                if v.bid_price and v.ask_price:
                    out[sym] = (float(v.bid_price), float(v.ask_price), v.timestamp.astimezone(NY))
        except Exception:
            pass
        return out

    def price_info(self, sym, session="REGULAR") -> dict:
        """Best available price at ANY time (day, night, weekend, holiday):
        live quote -> latest trade -> today's / previous daily close. Never raises."""
        out = {"bid": None, "ask": None, "last": None, "prev_close": None, "ts": None, "source": ""}
        lv = self.live.get(sym) if self.live and session != "OVERNIGHT" else None
        pc = self._pc.get(sym)
        if lv and lv.get("last") and pc and _time.time() - pc[1] < 600:
            out.update(bid=lv["bid"], ask=lv["ask"], last=lv["last"], prev_close=pc[0],
                       ts=self.now() - timedelta(seconds=lv["age"]), source="live stream")
            return out
        snap = None
        for feed in ([self.feed, DataFeed.IEX] if self.feed != DataFeed.IEX else [DataFeed.IEX]):
            try:
                snap = self.data.get_stock_snapshot(StockSnapshotRequest(symbol_or_symbols=sym, feed=feed)).get(sym)
                if snap:
                    break
            except Exception:
                snap = None
        if snap:
            q, t = snap.latest_quote, snap.latest_trade
            if q and q.bid_price and q.ask_price and q.ask_price >= q.bid_price:
                out.update(bid=float(q.bid_price), ask=float(q.ask_price))
            if t and t.price:
                out.update(last=float(t.price), ts=t.timestamp.astimezone(NY), source="last trade")
            db, pdb = snap.daily_bar, snap.previous_daily_bar
            # change is measured against the session before the latest one (Friday's change on a weekend)
            if pdb and pdb.close:
                out["prev_close"] = float(pdb.close)
                self._pc[sym] = (out["prev_close"], _time.time())
            if out["last"] is None and db:
                out.update(last=float(db.close), ts=db.timestamp.astimezone(NY), source="last close")
        if session in ("OVERNIGHT", "PRE", "AFTER"):
            q = self.quotes([sym], session).get(sym)
            if q:
                out.update(bid=q[0], ask=q[1])
                out["source"] = "overnight quote" if session == "OVERNIGHT" else "extended-hours quote"
        if out["last"] is None:          # data API gave nothing: fall back to minute/daily history
            try:
                df, _ = self.analysis_bars(sym)
                if df is not None and len(df):
                    out.update(last=float(df["close"].iloc[-1]), ts=df.index[-1], source="last close")
            except Exception:
                pass
        if lv:                                   # fresher streamed values beat the snapshot
            out.update(bid=lv["bid"] or out["bid"], ask=lv["ask"] or out["ask"], last=lv["last"] or out["last"],
                       source="live stream")
        if out["bid"] and out["last"] and abs(out["bid"] - out["last"]) / out["last"] > 0.2:
            out.update(bid=None, ask=None)   # a stale/odd quote far from the last trade: ignore it
        return out

    def overnight_tradable(self, sym) -> bool:
        if sym not in self._overnight_ok:
            try:
                a = self.trading.get(f"/assets/{sym}")
                self._overnight_ok[sym] = bool(a.get("overnight_tradable")) and bool(a.get("tradable"))
            except Exception:
                self._overnight_ok[sym] = False
        return self._overnight_ok[sym]

    def ext_scan(self, s, session: str, extra: list = ()) -> tuple[list, dict]:
        """Movers since the regular-session close (earnings / news), filtered for liquidity."""
        mine = [w.upper() for w in getattr(s, "watchlist", [])]
        cands = set(extra) | set(mine)
        try:
            for m in self.screener.get_most_actives(MostActivesRequest(top=50, by=MostActivesBy.VOLUME)).most_actives:
                cands.add(m.symbol)
            mv = self.screener.get_market_movers(MarketMoversRequest(top=40))
            for m in list(mv.gainers) + list(mv.losers):
                cands.add(m.symbol)
        except Exception:
            pass
        cands = [c for c in cands if c.isalpha()]
        snaps = {}
        for i in range(0, len(cands), 100):
            try:
                snaps.update(self.data.get_stock_snapshot(
                    StockSnapshotRequest(symbol_or_symbols=cands[i:i + 100], feed=self.feed)))
            except Exception:
                pass
        today = self.now().date()
        refs = {}
        for sym, sn in snaps.items():
            try:
                db_, pdb = sn.daily_bar, sn.previous_daily_bar
                if not db_:
                    continue
                if session == "PRE" and db_.timestamp.astimezone(NY).date() == today:
                    ref = pdb   # shouldn't happen pre-market, but be safe
                else:
                    ref = db_   # last completed regular session
                vol_ref = pdb if session == "AFTER" and pdb else db_
                if not ref or (float(vol_ref.volume) < s.min_prev_volume and sym not in mine):
                    continue
                refs[sym] = float(ref.close)
            except Exception:
                continue
        qs = self.quotes(list(refs), session)
        rows, moves = [], {}
        for sym, (bid, ask, _) in qs.items():
            mid = (bid + ask) / 2
            if not (s.min_price <= mid <= s.max_price) or (ask - bid) / mid > 0.006:
                continue
            if session == "OVERNIGHT" and not self.overnight_tradable(sym):
                continue
            mv_ = (mid / refs[sym] - 1) * 100
            moves[sym] = round(mv_, 2)
            if sym in mine:
                rows.append((1e6, sym))
            elif abs(mv_) >= 1.5:
                rows.append((abs(mv_), sym))
        rows.sort(reverse=True)
        return [x for _, x in rows[:15 + len(mine)]], moves

    def submit_limit_ext(self, sym, side, qty, limit_price, client_id) -> str:
        req = LimitOrderRequest(symbol=sym, qty=qty, side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
                                time_in_force=TimeInForce.DAY, limit_price=_px(limit_price),
                                extended_hours=True, client_order_id=client_id)
        return str(self.trading.submit_order(req).id)

    # ---- manual trading (dashboard Buy / Sell / Close) ----
    def manual_order(self, sym, side, qty, order_type="market", limit_price=None, stop=None, target=None,
                     extended=False, client_id=None, stop_price=None, trail_percent=None, trail_price=None,
                     tif="day") -> str:
        """An order you place yourself (dashboard ticket).
        order_type: market | limit | stop | stop_limit | trailing_stop
        tif:        day | gtc | ioc | fok | opg | cls
        extended:   True = eligible outside regular hours (Extended hours / 24 Hour Market: limit only).
        stop / target: optional stop-loss / take-profit legs (regular hours, market or limit only)."""
        kw = dict(symbol=sym, qty=qty, side=OrderSide.BUY if side == "buy" else OrderSide.SELL,
                  time_in_force=TimeInForce(tif), client_order_id=client_id)
        if extended:
            kw["extended_hours"] = True
        if order_type in ("market", "limit") and not extended:
            if stop and target:
                kw.update(order_class=OrderClass.BRACKET, take_profit=TakeProfitRequest(limit_price=_px(target)),
                          stop_loss=StopLossRequest(stop_price=_px(stop)))
            elif stop:
                kw.update(order_class=OrderClass.OTO, stop_loss=StopLossRequest(stop_price=_px(stop)))
            elif target:
                kw.update(order_class=OrderClass.OTO, take_profit=TakeProfitRequest(limit_price=_px(target)))
        if order_type == "limit":
            req = LimitOrderRequest(limit_price=_px(limit_price), **kw)
        elif order_type == "stop":
            req = StopOrderRequest(stop_price=_px(stop_price), **kw)
        elif order_type == "stop_limit":
            req = StopLimitOrderRequest(stop_price=_px(stop_price), limit_price=_px(limit_price), **kw)
        elif order_type == "trailing_stop":
            req = TrailingStopOrderRequest(**({"trail_percent": trail_percent} if trail_percent
                                              else {"trail_price": trail_price}), **kw)
        else:
            req = MarketOrderRequest(**kw)
        return str(self.trading.submit_order(req).id)

    def close_qty(self, sym, qty):
        """Close all or part of a position with a market order (regular hours). Raises on error."""
        for o in self._open_orders(sym):
            self.cancel(str(o.id))
        _time.sleep(0.5)
        self.trading.close_position(sym, ClosePositionRequest(qty=str(qty)))

    def open_orders(self) -> list:
        out = []
        for o in self.trading.get_orders(GetOrdersRequest(status=QueryOrderStatus.OPEN, nested=True)):
            for x in [o] + list(o.legs or []):
                st = str(x.status.value if hasattr(x.status, "value") else x.status)
                if st in ("held",):          # bracket legs waiting for the entry to fill
                    continue
                out.append({"id": str(x.id), "symbol": x.symbol,
                            "side": str(x.side.value if hasattr(x.side, "value") else x.side),
                            "qty": float(x.qty or 0), "filled": float(x.filled_qty or 0),
                            "type": str(x.order_type.value if hasattr(x.order_type, "value") else x.order_type),
                            "limit": float(x.limit_price) if x.limit_price else None,
                            "stop": float(x.stop_price) if x.stop_price else None,
                            "status": st, "ext": bool(getattr(x, "extended_hours", False)),
                            "tif": str(x.time_in_force.value if hasattr(x.time_in_force, "value") else x.time_in_force),
                            "trail": (f"{float(x.trail_percent):g}%" if getattr(x, "trail_percent", None)
                                      else (f"${float(x.trail_price):g}" if getattr(x, "trail_price", None) else "")),
                            "client_id": str(x.client_order_id or ""),
                            "at": x.submitted_at.astimezone(NY).strftime("%m-%d %H:%M") if x.submitted_at else ""})
        return out

    def cancel_symbol_orders(self, sym):
        try:
            for o in self._open_orders(sym):
                self.cancel(str(o.id))
        except Exception:
            pass

    def order_open(self, order_id) -> bool:
        try:
            st = self.entry_status(order_id)[0]
            return st in ("new", "accepted", "pending_new", "partially_filled", "held", "pending_replace")
        except Exception:
            return False
