"""SQLite trade journal."""
import sqlite3
import threading

from .config import DATA_DIR

DB_FILE = DATA_DIR / "trades.db"
_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS trades (
  id TEXT PRIMARY KEY, day TEXT, mode TEXT, symbol TEXT, side TEXT, strategy TEXT, exit_profile TEXT,
  bucket TEXT, qty REAL, entry REAL, stop REAL, target REAL, risk REAL, opened_at TEXT,
  closed_at TEXT, exit REAL, pnl REAL, r REAL, status TEXT, note TEXT
);
"""


def _conn():
    c = sqlite3.connect(DB_FILE, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


with _lock:
    _c = _conn()
    _c.executescript(SCHEMA)
    _c.commit()
    _c.close()


def upsert(t: dict):
    cols = ["id", "day", "mode", "symbol", "side", "strategy", "exit_profile", "bucket", "qty", "entry", "stop",
            "target", "risk", "opened_at", "closed_at", "exit", "pnl", "r", "status", "note"]
    vals = [t.get(k) for k in cols]
    with _lock:
        c = _conn()
        c.execute(f"INSERT OR REPLACE INTO trades ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
        c.commit()
        c.close()


def recent(limit=100):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY opened_at DESC LIMIT ?", (limit,))]
        c.close()
    return rows


def daily_summary(limit=30):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute(
            "SELECT day, mode, COUNT(*) trades, ROUND(SUM(pnl),2) pnl, "
            "ROUND(100.0*SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END)/COUNT(*),1) win_rate, ROUND(AVG(r),2) avg_r "
            "FROM trades WHERE status='closed' GROUP BY day, mode ORDER BY day DESC LIMIT ?", (limit,))]
        c.close()
    return rows
