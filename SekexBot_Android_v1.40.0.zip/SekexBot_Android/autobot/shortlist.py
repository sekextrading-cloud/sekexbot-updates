"""Overnight homework and morning refresh: rank the whole market for short candidates.

Sources: Alpaca's most-active lists (by volume and by trade count), the market movers (gainers and losers), your watchlist,
and the stocks the scanner already likes. Each name gets points for its rank in every list and for how far it has moved.
Only names that are tradable, priced above your minimum and (when the bot may short) shortable and easy to borrow are kept."""
import json
from datetime import datetime

from .config import DATA_DIR

FILE = DATA_DIR / "shortlist.json"


def load():
    try:
        return json.loads(FILE.read_text())
    except Exception:
        return {"at": "", "stage": "", "items": []}


def save(d):
    try:
        FILE.write_text(json.dumps(d))
    except Exception:
        pass


def build(broker, s, extra=(), top=25, now=None):
    """Returns a list of dicts: symbol, score, tags, change, borrow. Needs an Alpaca broker (screener)."""
    from alpaca.data.enums import MostActivesBy
    from alpaca.data.requests import MarketMoversRequest, MostActivesRequest
    pts, tags, chg = {}, {}, {}

    def add(sym, p, tag):
        pts[sym] = pts.get(sym, 0.0) + p
        tags.setdefault(sym, []).append(tag)

    for by, tag in ((MostActivesBy.VOLUME, "volume"), (MostActivesBy.TRADES, "trades")):
        try:
            rows = broker.screener.get_most_actives(MostActivesRequest(top=100, by=by)).most_actives
            n = max(len(rows), 1)
            for i, m in enumerate(rows):
                add(m.symbol, (n - i) / n, f"{tag} #{i + 1}")
        except Exception:
            pass
    try:
        mv = broker.screener.get_market_movers(MarketMoversRequest(top=50))
        for m in list(mv.gainers) + list(mv.losers):
            c = float(getattr(m, "percent_change", 0) or 0)
            chg[m.symbol] = c
            add(m.symbol, min(abs(c) / 10.0, 1.0) + 0.3, f"mover {c:+.1f}%")
    except Exception:
        pass
    mine = [w.upper() for w in getattr(s, "watchlist", [])]
    for w in mine:
        add(w, 1.0, "watchlist")
    for x in extra:
        add(x, 0.4, "scanner")
    out = []
    for sym, p in sorted(pts.items(), key=lambda kv: kv[1], reverse=True):
        if not (sym.isalpha() or "." in sym):
            continue
        if len(out) >= top * 2:
            break
        out.append((sym, p))
    rows = []
    for sym, p in out:
        try:
            ok, status = broker.recheck_borrow(sym)
        except Exception:
            ok, status = True, "unknown"
        if not ok and sym not in mine:
            continue
        rows.append({"symbol": sym, "score": round(p, 2), "tags": tags[sym][:4], "change": chg.get(sym), "borrow": status,
                     "watch": sym in mine})
        if len(rows) >= top:
            break
    return rows
