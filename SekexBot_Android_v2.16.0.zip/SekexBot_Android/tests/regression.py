"""SekexBot regression suite. Run:  python3 tests/regression.py   (uses a throw-away data folder; never touches your data)

Covers: version consistency, settings migrations (daily loss limit must survive), risk manager, sessions, night mode,
morning-wave setups, wave trader, options limits and greeks, simulator journal audits, and every API endpoint."""
import json, os, re, subprocess, sys, tempfile, time, traceback
from datetime import date, datetime, time as dtime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
TMP = tempfile.mkdtemp(prefix="sekex_reg_")
os.environ["AUTOBOT_DATA"] = TMP
NY = ZoneInfo("America/New_York")
RESULTS = []


def test(name):
    def deco(fn):
        t0 = time.time()
        try:
            fn()
            RESULTS.append((name, "PASS", "", time.time() - t0))
        except AssertionError as e:
            RESULTS.append((name, "FAIL", str(e) or traceback.format_exc().splitlines()[-2], time.time() - t0))
        except Exception as e:
            RESULTS.append((name, "ERROR", f"{type(e).__name__}: {e}\n" + "".join(traceback.format_exc().splitlines(True)[-4:]), time.time() - t0))
        return fn
    return deco


# ---------------------------------------------------------------- static
@test("static: every python file compiles")
def _():
    r = subprocess.run([sys.executable, "-m", "compileall", "-q", str(ROOT / "autobot"), str(ROOT / "server.py"), str(ROOT / "bin")], capture_output=True, text=True)
    assert r.returncode == 0, r.stdout + r.stderr


@test("static: dashboard JavaScript parses")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    for i, m in enumerate(re.findall(r"<script>(.*?)</script>", html, re.S)):
        p = Path(TMP) / f"s{i}.js"
        p.write_text(m)
        r = subprocess.run(["node", "--check", str(p)], capture_output=True, text=True)
        assert r.returncode == 0, r.stderr[:300]


@test("static: shell scripts parse")
def _():
    for f in ("bin/sekex", "install.sh"):
        r = subprocess.run(["bash", "-n", str(ROOT / f)], capture_output=True, text=True)
        assert r.returncode == 0, f + ": " + r.stderr


@test("static: dashboard ids used by the code exist in the page")
def _():
    html = (ROOT / "web" / "dashboard.html").read_text()
    have = set(re.findall(r'id="([^"]+)"', html))
    used = set(re.findall(r"\$\('([A-Za-z0-9_]+)'\)", html))
    dyn = {x for x in used if x not in have}
    # ids created by script (innerHTML) are fine: accept those that appear in a template string
    missing = sorted(x for x in dyn if f'id="{x}"' not in html and f"id=\\\"{x}\\\"" not in html and f"id='{x}'" not in html)
    assert len(missing) <= 3, "ids used in code but not in the page: " + ", ".join(missing[:15])


@test("static: version is the same everywhere")
def _():
    from autobot.version import __version__ as v
    assert (ROOT / "VERSION").read_text().strip() == v, "VERSION file differs from version.py"
    assert re.search(rf"^## {re.escape(v)} ", (ROOT / "CHANGELOG.md").read_text(), re.M), "CHANGELOG has no entry for " + v
    assert v in (ROOT / "README_ANDROID.md").read_text().splitlines()[0], "README_ANDROID header is not v" + v


# ---------------------------------------------------------------- settings
@test("settings: migrations never change the user's daily loss limit")
def _():
    from autobot import config
    d = Path(TMP) / "mig"
    d.mkdir()
    config.SETTINGS_FILE = d / "settings.json"
    config.OPTIONS_FILE = d / "options_settings.json"
    config.SETTINGS_FILE.write_text(json.dumps({"daily_max_loss": 137.5, "max_position_pct_equity": 0.25}))
    s = config.Settings.load()
    assert s.daily_max_loss == 137.5, f"daily limit changed to {s.daily_max_loss}"
    assert s.v130_defaults and s.v155_defaults is not None and s.v159_defaults and s.v163_defaults and s.v165_defaults, "legacy migration flags missing"
    assert abs(s.max_position_pct_equity - 0.15) < 1e-9
    s2 = config.Settings.load()
    assert s2.daily_max_loss == 137.5
    s2.daily_max_loss = 99.0
    s2.wave_trade = True
    s2.options_max_stocks = 3
    s2.save()
    s3 = config.Settings.load()
    assert s3.daily_max_loss == 99.0 and s3.wave_trade is True and s3.options_max_stocks == 3, "round trip failed"


@test("settings: risky features are OFF by default")
def _():
    from autobot.config import Settings
    s = Settings()
    assert s.wave_trade is False and s.options_on is False and s.options_live_unlocked is False
    assert s.night_dir == "buy"


# ---------------------------------------------------------------- risk
def _rm(**kw):
    from autobot.config import Settings
    from autobot.risk import RiskManager
    s = Settings()
    s.daily_max_loss = kw.pop("limit", 200.0)
    for k, v in kw.items():
        setattr(s, k, v)
    r = RiskManager(s)
    r.equity = 25000.0
    return s, r


@test("risk: halts at the daily loss limit and sizes to zero afterwards")
def _():
    s, r = _rm()
    assert r.update(25000 - 100, 25000) is False
    assert r.update(25000 - 200.01, 25000) is True and r.halted
    assert r.size(100, 99, 1.0, 0, 50000).qty == 0
    r.new_day()
    assert not r.halted


@test("risk: profit lock after giving back half of a limit-sized gain")
def _():
    s, r = _rm()
    assert r.update(25000 + 220, 25000) is False
    assert r.update(25000 + 100, 25000) is True and "Profit lock" in r.halt_reason


@test("risk: trade risk never exceeds the budget; caps always win")
def _():
    s, r = _rm(limit=200.0)
    r.update(25000 - 50, 25000)                      # $150 left
    d = r.size(100.0, 99.0, 1.0, 0.0, 50000.0)
    assert d.risk_dollars <= 0.5 * r.remaining + 1e-9, d
    d2 = r.size(100.0, 99.0, 1.0, 140.0, 50000.0)    # open risk already uses most of what is left
    assert d2.risk_dollars <= (r.remaining - 140.0) + 1e-9, d2
    s.max_trade_notional = 1000.0
    d3 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d3.qty * 100.0 <= 1000.0 + 1e-6, f"notional cap broken: {d3.qty} sh"
    s.max_trade_notional = 0.0
    s.max_position_pct_equity = 0.05
    d4 = r.size(100.0, 99.99, 1.0, 0.0, 500000.0)
    assert d4.qty * 100.0 <= 25000.0 * 0.05 + 1e-6, "equity % cap broken"
    d5 = r.size(100.0, 99.99, 1.0, 0.0, 1000.0)      # buying power tiny
    assert d5.qty * 100.0 <= 1000.0 + 1e-6, "buying power cap broken"
    assert r.size(100.0, 100.0, 1.0, 0.0, 50000.0).qty == 0, "zero-risk stop must size to 0"


# ---------------------------------------------------------------- sessions
def _trading_day(d):
    return None if d.weekday() >= 5 else (datetime.combine(d, dtime(9, 30), NY), datetime.combine(d, dtime(16, 0), NY))


@test("sessions: boundaries, weekend gap, and the 8 PM bot day")
def _():
    from autobot.sessions import bot_day, current_session
    def at(y, m, d, h, mi):
        return datetime(y, m, d, h, mi, tzinfo=NY)
    cases = [((2026, 10, 6, 3, 59), "OVERNIGHT"), ((2026, 10, 6, 4, 0), "PRE"), ((2026, 10, 6, 9, 29), "PRE"), ((2026, 10, 6, 9, 30), "REGULAR"),
             ((2026, 10, 6, 15, 59), "REGULAR"), ((2026, 10, 6, 16, 0), "AFTER"), ((2026, 10, 6, 19, 59), "AFTER"), ((2026, 10, 6, 20, 0), "OVERNIGHT"),
             ((2026, 10, 9, 20, 30), None), ((2026, 10, 10, 12, 0), None), ((2026, 10, 11, 20, 0), "OVERNIGHT")]
    for (y, m, d, h, mi), want in cases:
        s = current_session(_trading_day, at(y, m, d, h, mi))
        got = s.name if s else None
        assert got == want, f"{y}-{m}-{d} {h}:{mi:02d} expected {want}, got {got}"
    assert bot_day(at(2026, 10, 6, 19, 59)) != bot_day(at(2026, 10, 6, 20, 0)), "daily window must roll at 8 PM ET"


# ---------------------------------------------------------------- engine pieces
def _engine(**kw):
    from autobot.config import Settings
    from autobot.engine import Engine
    from autobot.learner import Learner
    from autobot.sim import SimBroker
    s = Settings()
    s.daily_max_loss, s.tick_seconds = 200, 60
    for k, v in kw.items():
        setattr(s, k, v)
    b = SimBroker(datetime(2026, 9, 14, 9, 0, tzinfo=NY), equity=25000, seed=3)
    e = Engine(s, b, Learner())
    e.running = True
    return e


@test("night mode: window, direction and shorts gate")
def _():
    e = _engine(night_short=True, night_dir="buy")
    n = lambda h, m: datetime(2026, 9, 14, h, m, tzinfo=NY)
    assert e.night_window(n(20, 0)) and e.night_window(n(6, 59)) and not e.night_window(n(7, 0)) and not e.night_window(n(19, 59))
    assert e.night_dir() == "buy" and e.shorts_allowed(n(22, 0)) is False, "night buys mode must not allow shorts"
    e.s.night_dir = "sell"
    assert e.night_dir() == "sell" and e.shorts_allowed(n(22, 0)) is True
    e.s.night_short = False
    assert not e.night_window(n(22, 0))


def _wave_rows(eng):
    def fake(now, mode="PRE"):
        out = []
        for sy in list(eng.broker.day_bars)[:4]:
            px = eng.broker._px(sy)
            out.append({"symbol": sy, "side": "up", "kind": "CLOSE_HIGH", "name": "CLOSE HIGH CONTINUATION", "score": 80 if sy != list(eng.broker.day_bars)[3] else 60,
                        "label": "STRONG", "hit_rate": 80, "n": 12, "zone": [round(px * 0.995, 2), round(px * 1.005, 2)],
                        "stop": round(px * 0.985, 2), "tp1": round(px * 1.012, 2), "tp2": round(px * 1.02, 2), "atr": px * 0.02})
        return out
    return fake


@test("wave trader: off by default, honours window, min score, max trades, zone, and halts")
def _():
    from autobot import db
    e = _engine(wave_min_score=70, wave_from=570, wave_until=700, wave_max_trades=2, wave_trade=False)
    e._wave_rows = _wave_rows(e)
    seen = []
    orig_bracket, orig_ext = e.broker.submit_bracket, e.broker.submit_limit_ext
    e.broker.submit_bracket = lambda *a, **k: (seen.append(("REG", a, e.broker.now())), orig_bracket(*a, **k))[1]
    e.broker.submit_limit_ext = lambda *a, **k: (seen.append(("EXT", a, e.broker.now())), orig_ext(*a, **k))[1]
    def run_until(h, m):
        guard = 0
        while (e.broker.now().hour, e.broker.now().minute) < (h, m) and guard < 4000:
            w = e.tick()
            e.broker.sleep(w or 60)
            guard += 1
    # 1) switch OFF -> nothing from the wave trader
    run_until(10, 0)
    wave_trades = [t for t in e.trades.values() if t.strategy == "WAVE"]
    assert not wave_trades and not getattr(e, "wave_done", None), "wave trader traded while switched OFF"
    # 2) ON, inside the window
    e.s.wave_trade = True
    run_until(10, 30)
    done = getattr(e, "wave_done", set())
    assert 1 <= len(done) <= 2, f"expected 1-2 wave entries, got {len(done)}"
    assert all(s in [x["symbol"] for x in e._wave_rows(None) if x["score"] >= 70] for s in done), "entered a setup under the min score"
    for kind, a, t in seen:
        if a[0] in done:
            assert 570 <= t.hour * 60 + t.minute < 700, "wave order outside its window"
    rows = [r for r in db.recent(500) if r["strategy"] == "WAVE"]
    for r in rows:
        assert r["stop"] < r["entry"] < r["target"], f"bad levels {r}"
        assert r["risk"] <= 0.15 * 200 * 0.5 * 1.05 + 1e-6, f"risk {r['risk']} over budget"
    # 3) halted risk -> no entries
    e2 = _engine(wave_trade=True, wave_min_score=70, wave_from=570, wave_until=700)
    e2._wave_rows = _wave_rows(e2)
    first = True
    for _ in range(400):
        w = e2.tick(); e2.broker.sleep(w or 60)
        if first:   # the first tick runs the new-day reset, which clears any halt; halt after it
            first = False
            e2.risk.halted, e2.risk.halt_reason = True, "test halt"
            e2.wave_done = set()
        if e2.broker.now().hour >= 10:
            break
    assert not getattr(e2, "wave_done", None), "wave trader traded while the daily loss limit had halted trading"


# ---------------------------------------------------------------- morning wave setups
@test("morning wave: pattern that always follows through is listed; one that never does is not")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    def build(follow):
        rows, px = [], 100.0
        days = pd.bdate_range("2026-08-20", "2026-10-05")
        prev_strong = False
        for i, day in enumerate(days):
            idx = pd.date_range(f"{day.date()} 04:00", f"{day.date()} 19:45", freq="15min", tz=NY)
            strong = (i % 2 == 0)
            for t in idx:
                reg = dtime(9, 30) <= t.time() < dtime(16, 0)
                o = px
                if reg:
                    frac = (t.hour * 60 + t.minute - 570) / 390
                    px = px * (1 + (0.0006 if strong else -0.0006) * (1 if frac < 0.9 else 1))
                else:
                    if prev_strong and follow and t.time() >= dtime(9, 0):
                        px = px * 1.0012                          # next morning pushes up
                    else:
                        px = px * (1 + 0.00001)
                rows.append((t, o, max(o, px) * 1.0003, min(o, px) * 0.9997, px, 1000))
            prev_strong = strong
        return pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
    yes = mw.analyze("AAA", build(True))
    no = mw.analyze("BBB", build(False))
    if yes:
        assert yes["side"] == "up" and yes["stop"] < yes["zone"][0] <= yes["zone"][1] < yes["tp1"] < yes["tp2"], yes
        assert 0 <= yes["score"] <= 100 and 0 <= yes["hit_rate"] <= 100
    assert no is None or no["hit_rate"] < 100, "a pattern with no follow-through must not show a perfect hit rate"
    rise, fall = mw.build({"AAA": build(True), "BBB": build(False)})
    assert isinstance(rise, list) and isinstance(fall, list)


# ---------------------------------------------------------------- options
@test("options: build_plan sizing never breaks the premium, budget or contract limits")
def _():
    from autobot import options as O
    today = date(2026, 10, 6)
    exp = today + timedelta(days=9)
    ch = [{"symbol": f"C{k}", "strike": float(k), "expiry": exp, "oi": 800} for k in range(95, 106)]
    quotes = {c["symbol"]: (max(0.05, 100 - c["strike"] + 3.0), max(0.05, 100 - c["strike"] + 3.1)) for c in ch}
    for style in ("spread", "long"):
        cfg = {"min_dte": 5, "min_oi": 100, "style": style, "max_premium": 200.0, "max_contracts": 3, "stop_pct": 40.0, "tp_pct": 50.0, "room": 150.0,
               "flatten_min": 900, "hold_overnight": False}
        plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
        if plan:
            assert plan["qty"] >= 1 and plan["qty"] <= 3
            assert plan["cost"] <= 200.0 + 1e-6, plan
            assert plan["risk_at_stop"] <= 150.0 + 1e-6, plan
    cfg["max_premium"] = 1.0
    plan, why = O.build_plan("call", 100.0, ch, quotes, cfg, today)
    assert plan is None, "an option costing more than the per-trade limit must not be planned"


@test("options: stock, per-stock, call and put limits plus greeks")
def _():
    import pandas as pd
    from types import SimpleNamespace as NS
    from autobot.config import Settings
    from autobot import options as O
    s = Settings(); s.options_on = True
    b = O.OptionsBot(lambda: None, s)
    b._account_level = lambda e: 3
    b._room = lambda e: 300
    opened = []
    b._open = lambda e, u, d, why, px, room, reg: (opened.append((u, d)) or True)
    O.signal = lambda *a, **k: ("call", "t")
    bars = {u: pd.DataFrame({"close": [100.0]}) for u in s.options_underlyings}
    e = NS(mode="PAPER", bars_last=bars, regime={}, bias=0, ribbons={})
    now = datetime(2026, 10, 6, 10, 30)
    def run(rows, **kw):
        for k, v in kw.items():
            setattr(s, k, v)
        b.pos = {f"p{i}": {"status": "open", "underlying": u, "direction": d} for i, (u, d) in enumerate(rows)}
        opened.clear(); b.confirm = {}; b.cool = {}
        for _ in range(2):
            b._entries(e, now)
        return list(opened)
    assert run([]), "nothing open: it should open a trade"
    assert run([("SPY", "call")], options_max_stocks=1, options_max_positions=4) == [], "max stocks ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=1) == [], "max calls ignored"
    assert run([("SPY", "call")], options_max_stocks=5, options_max_calls=6, options_max_per_stock=2), "per-stock 2 should allow a second SPY trade"
    assert run([("SPY", "call"), ("QQQ", "put")], options_max_stocks=2, options_max_positions=2, options_max_per_stock=1) == [], "total cap ignored"
    b.greeks = {"L": {"delta": .55, "gamma": .04, "theta": -.12, "vega": .2, "rho": .01, "iv": .4}, "S": {"delta": .4, "gamma": .03, "theta": -.09, "vega": .15, "rho": .01, "iv": .38}}
    g = b.net_greeks("L", "S")
    assert abs(g["delta"] - .15) < 1e-9 and abs(g["theta"] + .03) < 1e-9 and b.net_greeks("L", "X") is None
    pg = b._pos_greeks({"qty": 2, "greeks": g})
    assert abs(pg["pos_delta"] - 30) < 1e-6 and abs(pg["pos_theta"] + 6) < 1e-6


# ---------------------------------------------------------------- API
@test("API: every GET endpoint answers (no 500s) and POSTs keep the daily limit")
def _():
    import socket, urllib.request, urllib.error
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    d = Path(TMP) / "api"; d.mkdir()
    env = dict(os.environ, AUTOBOT_DATA=str(d))
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--host", "127.0.0.1", "--sim", "--speed", "60"],
                         cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/version", timeout=2).read(); break
            except Exception:
                time.sleep(1)
        else:
            raise AssertionError("server did not start: " + (p.stderr.read(600).decode() if p.poll() is not None else "timeout"))
        def get(path):
            try:
                return urllib.request.urlopen(base + path, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        def post(path, body):
            req = urllib.request.Request(base + path, data=json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method="POST")
            try:
                return urllib.request.urlopen(req, timeout=20).status
            except urllib.error.HTTPError as e:
                return e.code
        post("/api/start", {})
        time.sleep(3)
        spec = json.loads(urllib.request.urlopen(base + "/openapi.json").read())
        bad = []
        skip = ("/docs", "/openapi", "/redoc", ".csv", "export", "download", "backup", "/api/app/update", "/logs/stream")
        n = 0
        for path, ops in spec["paths"].items():
            if "get" in ops and "{" not in path and not any(x in path for x in skip):
                st = get(path); n += 1
                if st >= 500:
                    bad.append(f"{path} -> {st}")
        assert not bad, "GET endpoints failing: " + "; ".join(bad)
        before = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        for path, body in (("/api/wave", {"on": True, "min_score": 75}), ("/api/wave", {"on": False}), ("/api/night", {"on": True, "dir": "buy"}),
                           ("/api/options/config", {"max_stocks": 3, "max_calls": 2, "max_puts": 2, "max_per_stock": 2, "min_delta": 0.3}),
                           ("/api/options/config", {"max_stocks": 0, "min_delta": 5})):
            st = post(path, body)
            assert st < 500, f"POST {path} -> {st}"
        wv = json.loads(urllib.request.urlopen(base + "/api/wave").read())
        assert wv["on"] is False and wv["min_score"] == 75
        opt = json.loads(urllib.request.urlopen(base + "/api/options/status").read())
        assert opt["on"] is False, "options must stay off unless switched on"
        after = json.loads(urllib.request.urlopen(base + "/api/status").read())["settings"]["daily_max_loss"]
        assert before == after, f"daily loss limit changed {before} -> {after}"
        mw = json.loads(urllib.request.urlopen(base + "/api/morningwave?force=1").read())
        assert "rise" in mw and "fall" in mw
        for r in mw["rise"]:
            assert r["stop"] < r["zone"][0] and r["tp1"] > r["zone"][1], r
    finally:
        p.terminate()
        try:
            p.wait(10)
        except Exception:
            p.kill()



# ---------------------------------------------------------------- scalping + harvest
def _mk_trade(profile="SCALP", entry=100.0, stop=99.0, side="buy", **kw):
    from autobot.engine import Trade
    t = Trade("t1", "ZZZ", side, "EMA_PULLBACK", profile, "AM", 10, entry, stop, stop, entry + 2, 0.5, 10.0,
              datetime(2026, 9, 14, 10, 0, tzinfo=NY), "o1", status="open", **kw)
    return t


@test("scalping: quick-harvest banks a stalled green trade, not a red or fresh one; only for scalp profiles")
def _():
    e = _engine(let_run=False, scale_out=False, scalp_mode=True)
    assert e._harvest_profile("QUICK") == "SCALP"
    e.s.scalp_mode = False
    assert e._harvest_profile("QUICK") == "QUICK"
    e.s.let_run = e.s.scale_out = True
    assert e._harvest_profile("QUICK") == "SCALE", "let-winners-run must disable scalp profiles"
    e.s.let_run = False
    t = _mk_trade("SCALP")
    assert e._quick_harvest(t, 0.5) is False, "must not bank on the first green check"
    assert e._quick_harvest(t, 0.5) is True or e._quick_harvest(t, 0.5) is False
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.7)
    assert e._quick_harvest(t, 0.7) is False, "still rising: let it run"
    assert e._quick_harvest(t, 0.5) is False or t.pos_ticks >= 0
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.8)
    assert e._quick_harvest(t, 0.6) is True, "gave back 0.2R from the best after 2 green checks: bank it"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.3); e._quick_harvest(t, 0.3)
    assert e._quick_harvest(t, -0.2) is False, "a red trade is never 'harvested'"
    t = _mk_trade("SCALE"); e._quick_harvest(t, 0.6); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 0.5) is False, "non-scalp profiles are untouched"
    t = _mk_trade("SCALP"); e._quick_harvest(t, 0.5); e._quick_harvest(t, 0.9)
    assert e._quick_harvest(t, 1.1) is True, "near the 1.2R scalp target: take it"


@test("scalping: give-back lock never hands back more than the allowed share of the best gain")
def _():
    e = _engine()
    t = _mk_trade("SCALE", entry=100, stop=99)            # 1R = $1
    lvl, ex = e._gain_lock(t, 0.4)
    assert lvl is None and not ex, "no lock below +0.6R"
    lvl, ex = e._gain_lock(t, 1.0)
    assert abs(lvl - 100.4) < 1e-9 and not ex, f"lock at 40% of 1.0R expected, got {lvl}"
    lvl, ex = e._gain_lock(t, 0.39)
    assert ex, "falling through the lock must exit"
    lvl, ex = e._gain_lock(t, 2.5)
    assert abs(lvl - 100 - 0.6 * 2.5) < 1e-9, "60% lock from 2R"
    s = _mk_trade("SCALE", entry=100, stop=101, side="sell")      # short: lock is below entry
    lvl, ex = e._gain_lock(s, 1.0) if s.dir < 0 else (None, False)
    assert lvl is None or lvl < 100, "short lock must sit below entry"


@test("harvest (halt): winners kept with a ratcheting profit lock that never goes below break-even or backwards")
def _():
    e = _engine()
    e.profit_locks = {}
    e.broker.update_stop = lambda *a, **k: None
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 104.0})
    lk1 = e.profit_locks["ZZZ"]
    assert abs(lk1 - (100 + 2 + 0.1)) < 1e-9, lk1
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 102.0})
    assert e.profit_locks["ZZZ"] == lk1, "lock must not move back down"
    e._lock_update("ZZZ", {"qty": 10, "avg_entry": 100.0, "price": 110.0})
    assert e.profit_locks["ZZZ"] > lk1
    e._lock_update("YYY", {"qty": 10, "avg_entry": 100.0, "price": 99.0})
    assert "YYY" not in e.profit_locks, "a loser gets no lock"
    e._lock_update("SSS", {"qty": -10, "avg_entry": 50.0, "price": 48.0})
    assert e.profit_locks["SSS"] < 50.0, "short lock sits below entry"


def _fake_harvest(price=100.0, spread=0.02, A=0.5, held=10, halted=False):
    import time as _t
    from types import SimpleNamespace as NS
    from autobot.harvester import Harvester
    calls = []
    state = {"bid": price - spread / 2, "ask": price + spread / 2, "held": held}
    broker = NS(positions=lambda: ({"ZZZ": {"qty": state["held"], "avg_entry": 100.0, "price": state["bid"]}} if state["held"] else {}),
                cancel_symbol_orders=lambda s: None)
    e = NS(risk=NS(halted=halted), trades={}, broker=broker)
    h = Harvester.__new__(Harvester)
    import threading
    h.get_engine = lambda: e; h.quote_fn = lambda e_, s, sess: (state["bid"], state["ask"]); h.session_fn = lambda e_: "REGULAR"
    h.open_fn = lambda *a: calls.append(("open",) + a[1:3])
    h.close_fn = lambda *a: calls.append(("close",) + a[1:4])
    h.path = Path("/tmp/reg_harvest_test.json"); h.jobs = {}; h.lock = threading.RLock(); h._bars = {}
    h._save = lambda: None
    h._say = lambda *a, **k: None
    h._bars["ZZZ"] = (_t.time() + 1e6, A, None, [100.0, 100.1])       # fixed A, bounce candle up
    return h, e, state, calls


@test("harvest: sells at +0.5 A, never for less than the spread, stalls bank, then re-enters on a pullback")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10)
    j = h.jobs["ZZZ"]; pos = e.broker.positions(); now = _t.time()
    h.step(e, j, pos, "REGULAR", now); assert j["phase"] == "holding"
    st["bid"], st["ask"] = 100.10, 100.12                       # +0.2 A: not yet
    h.step(e, j, e.broker.positions(), "REGULAR", now + 5); assert not calls
    st["bid"], st["ask"] = 100.30, 100.32                       # +0.6 A: harvest
    h.step(e, j, e.broker.positions(), "REGULAR", now + 10)
    assert calls and calls[0][0] == "close" and j["phase"] == "exiting", calls
    st["held"] = 0
    h.step(e, j, e.broker.positions(), "REGULAR", now + 15)
    assert j["phase"] == "waiting" and j["cycles"] == 1 and j["banked"] > 0, j
    # no pullback yet -> no re-entry; then a pullback of > 0.25 A with an up-candle -> buys again
    st["bid"], st["ask"] = 100.32, 100.34
    h.step(e, j, e.broker.positions(), "REGULAR", now + 20)
    assert len(calls) == 1, "re-entered without a pullback"
    st["bid"], st["ask"] = 100.10, 100.12
    h.step(e, j, e.broker.positions(), "REGULAR", now + 25)
    assert len(calls) == 1, "re-entered inside the 60 s cool-off (v1.95.1)"
    st["bid"], st["ask"] = 100.06, 100.08                       # still falling after the cool-off: wait for the drop to stop
    h.step(e, j, e.broker.positions(), "REGULAR", now + 80)
    assert len(calls) == 1, "re-entered while price was still making new lows"
    st["bid"], st["ask"] = 100.12, 100.14                       # bounced > 0.1 A off the low: now buy
    h.step(e, j, e.broker.positions(), "REGULAR", now + 90)
    assert calls[-1][0] == "open" and j["phase"] == "entering", (calls, j["msg"])
    st["held"] = 10
    h.step(e, j, e.broker.positions(), "REGULAR", now + 95); assert j["phase"] == "holding"
    # wide spread: a tiny gain that does not pay for the round trip is not harvested
    h2, e2, st2, c2 = _fake_harvest(spread=0.40)
    h2.arm("ZZZ", "buy", 10); j2 = h2.jobs["ZZZ"]; n = _t.time()
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n)
    st2["bid"], st2["ask"] = 100.26, 100.66
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", n + 5)
    assert not c2, "harvested a gain smaller than the spread cost"


@test("harvest: Harvest-now sells immediately; protective stop closes and ends the job; halt and overnight are respected")
def _():
    import time as _t
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n)
    j["sess_t"] = n - 999
    assert "Selling" in h.now("ZZZ")
    h.step(e, j, e.broker.positions(), "REGULAR", n + 4)
    assert calls and calls[0][0] == "close", "Harvest now did not sell"
    # protective stop: 2.4 A against the entry (hard stop) closes straight away and drops the job
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 98.7, 98.72
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0][0] == "close" and "ZZZ" not in h.jobs, (calls, h.jobs)
    # halted -> job stops, no orders
    h, e, st, calls = _fake_harvest(halted=True)
    h.arm("ZZZ", "buy", 10); h.step(e, h.jobs["ZZZ"], e.broker.positions(), "REGULAR")
    assert "ZZZ" not in h.jobs and not calls
    # overnight pause: no automatic sale at +1 A, but the Harvest-now button still works
    h, e, st, calls = _fake_harvest()
    h.arm("ZZZ", "buy", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 100.6, 100.62
    h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 5)
    assert not calls, "automatic harvest ran overnight"
    h.now("ZZZ"); h.step(e, j, e.broker.positions(), "OVERNIGHT", n + 9)
    assert calls and calls[0][0] == "close"
    # short side mirrors: gain when price falls
    h, e, st, calls = _fake_harvest()
    st["held"] = -10
    e.broker.positions = lambda: {"ZZZ": {"qty": -10, "avg_entry": 100.0, "price": st["ask"]}}
    h.arm("ZZZ", "sell", 10); j = h.jobs["ZZZ"]; n = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", n); j["sess_t"] = n - 999
    st["bid"], st["ask"] = 99.68, 99.70
    h.step(e, j, e.broker.positions(), "REGULAR", n + 5)
    assert calls and calls[0] == ("close", "ZZZ", 10, "sell"), calls


@test("learn: floor/ceiling/trend reading is sane on rising, falling and flat charts")
def _():
    import pandas as pd, numpy as np
    from autobot import learn
    def mk(path):
        idx = pd.bdate_range(end="2026-09-14", periods=len(path)).tz_localize(NY)
        c = np.array(path, float)
        return pd.DataFrame({"open": np.r_[c[0], c[:-1]], "high": c * 1.01, "low": c * 0.99, "close": c, "volume": 1e6}, index=idx)
    up = learn.read(mk([100 + i * 0.6 + (3 if i % 7 == 0 else 0) for i in range(120)]), "UP")
    assert up["trend"] == "UP", up["trend"]
    dn = learn.read(mk([200 - i * 0.6 - (3 if i % 7 == 0 else 0) for i in range(120)]), "DN")
    assert dn["trend"] == "DOWN", dn["trend"]
    assert not any(p["kind"] == "BUY" for p in dn["plan"]), "must not suggest buying a falling stock"
    flat = learn.read(mk([100 + 5 * np.sin(i / 4) for i in range(120)]), "FLAT")
    assert flat["floor"] and flat["ceiling"] and flat["floor"]["price"] < flat["price"] < flat["ceiling"]["price"], flat
    for r in (up, dn, flat):
        for p in r["plan"]:
            if p.get("stop") and p["zone"] and p["kind"] == "BUY":
                assert p["stop"] < p["zone"][0], f"stop not below the buy zone {p}"
    assert learn.read(mk([100] * 10), "X").get("error")


# ---------------------------------------------------------------- robinhood (mock server)
def _mock_rh():
    import threading, http.server, urllib.parse as up
    state = {"orders": [], "codes": {"good-code"}, "regs": 0}

    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _send(self, code, obj, ctype="application/json", extra=None):
            b = obj if isinstance(obj, bytes) else json.dumps(obj).encode()
            self.send_response(code); self.send_header("Content-Type", ctype)
            for k, v in (extra or {}).items(): self.send_header(k, v)
            self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            base = f"http://127.0.0.1:{self.server.server_port}"
            if self.path.startswith("/.well-known/oauth-authorization-server"):
                return self._send(200, {"issuer": base, "authorization_endpoint": base + "/oauth", "token_endpoint": base + "/token",
                                        "registration_endpoint": base + "/register", "scopes_supported": ["internal"], "code_challenge_methods_supported": ["S256"]})
            self._send(404, {})
        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0); raw = self.rfile.read(n)
            if self.path == "/register":
                state["regs"] += 1
                return self._send(201, {"client_id": "cid-123"})
            if self.path == "/token":
                f = dict(up.parse_qsl(raw.decode()))
                if f.get("grant_type") == "authorization_code" and f.get("code") in state["codes"] and f.get("code_verifier"):
                    state["verifier"] = f["code_verifier"]
                    return self._send(200, {"access_token": "AT1", "refresh_token": "RT1", "expires_in": 3600})
                if f.get("grant_type") == "refresh_token" and f.get("refresh_token") == "RT1":
                    return self._send(200, {"access_token": "AT2", "expires_in": 3600})
                return self._send(400, {"error": "invalid_grant"})
            if self.path == "/mcp":
                if self.headers.get("Authorization") not in ("Bearer AT1", "Bearer AT2"):
                    return self._send(401, {})
                m = json.loads(raw or b"{}"); meth = m.get("method"); i = m.get("id")
                if meth == "initialize":
                    return self._send(200, {"jsonrpc": "2.0", "id": i, "result": {"protocolVersion": "2025-06-18", "capabilities": {}, "serverInfo": {"name": "mock"}}}, extra={"Mcp-Session-Id": "S1"})
                if meth.startswith("notifications/"):
                    return self._send(202, b"")
                if meth == "tools/list":
                    tools = [{"name": "get_accounts", "description": "accounts", "inputSchema": {"type": "object"}, "annotations": {"readOnlyHint": True}},
                             {"name": "get_positions", "description": "positions", "inputSchema": {"type": "object"}},
                             {"name": "place_stock_order", "description": "order", "inputSchema": {"type": "object", "required": ["symbol"]}},
                             {"name": "mystery_tool", "description": "unknown", "inputSchema": {"type": "object"}}]
                    body = ("event: message\ndata: " + json.dumps({"jsonrpc": "2.0", "id": i, "result": {"tools": tools}}) + "\n\n").encode()
                    return self._send(200, body, "text/event-stream")
                if meth == "tools/call":
                    nm = m["params"]["name"]
                    if nm == "place_stock_order": state["orders"].append(m["params"]["arguments"])
                    return self._send(200, {"jsonrpc": "2.0", "id": i, "result": {"content": [{"type": "text", "text": json.dumps({"ok": nm, "n": len(state["orders"])})}]}})
            self._send(404, {})
    srv = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv, state


def hashlib_ok(verifier, challenge):
    import hashlib, base64
    return base64.urlsafe_b64encode(hashlib.sha256(verifier.encode()).digest()).rstrip(b"=").decode() == challenge


@test("robinhood: sign-in (PKCE), token refresh, SSE tool list, write tools are classified and never run without PIN + confirm")
def _():
    import socket, urllib.request, urllib.error, urllib.parse as up
    from autobot import rhmcp
    assert rhmcp.is_write({"name": "place_stock_order"}) and rhmcp.is_write({"name": "mystery_tool"})
    assert rhmcp.is_write({"name": "cancel_order", "annotations": {"readOnlyHint": True}}), "a write-sounding name must win over a read hint"
    assert not rhmcp.is_write({"name": "get_positions"}) and not rhmcp.is_write({"name": "x", "annotations": {"readOnlyHint": True}})
    srv, st = _mock_rh()
    mcp = f"http://127.0.0.1:{srv.server_port}/mcp"
    sock = socket.socket(); sock.bind(("127.0.0.1", 0)); port = sock.getsockname()[1]; sock.close()
    d = Path(TMP) / "rhapi"; d.mkdir()
    env = dict(os.environ, AUTOBOT_DATA=str(d), SEKEX_RH_MCP=mcp, LIVE_PIN="4321")
    p = subprocess.Popen([sys.executable, str(ROOT / "server.py"), "--port", str(port), "--host", "127.0.0.1", "--sim", "--speed", "60"],
                         cwd=str(ROOT), env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    try:
        base = f"http://127.0.0.1:{port}"
        for _ in range(60):
            try:
                urllib.request.urlopen(base + "/api/version", timeout=2).read(); break
            except Exception:
                time.sleep(1)
        else:
            raise AssertionError("server did not start")
        def req(path, body=None, method=None):
            r = urllib.request.Request(base + path, data=None if body is None else json.dumps(body).encode(), headers={"Content-Type": "application/json"}, method=method or ("POST" if body is not None else "GET"))
            try:
                resp = urllib.request.urlopen(r, timeout=20); return resp.status, resp.read().decode()
            except urllib.error.HTTPError as e:
                return e.code, e.read().decode()
        assert req("/api/rh/status")[0] == 200 and json.loads(req("/api/rh/status")[1])["connected"] is False
        assert req("/api/rh/tools")[0] == 409, "not connected must be a clean 409, not a 500"
        s, b = req("/api/rh/connect", {}); assert s == 200, b
        url = json.loads(b)["url"]; q = dict(up.parse_qsl(up.urlparse(url).query))
        assert q["code_challenge_method"] == "S256" and q["client_id"] == "cid-123" and q["redirect_uri"].endswith("/api/rh/callback"), q
        s, b = req(f"/api/rh/callback?code=bad&state={q['state']}"); assert "Not connected" in b
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        s, b = req(f"/api/rh/callback?code=good-code&state=WRONG"); assert "Not connected" in b, "a wrong state must be refused"
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        s, b = req(f"/api/rh/callback?code=good-code&state={q['state']}"); assert "Connected" in b and "Not connected" not in b, b
        assert hashlib_ok(st["verifier"], q["code_challenge"]), "PKCE verifier does not match the challenge"
        tools = {t["name"]: t for t in json.loads(req("/api/rh/tools")[1])["tools"]}
        assert tools["get_accounts"]["write"] is False and tools["get_positions"]["write"] is False
        assert tools["place_stock_order"]["write"] and tools["mystery_tool"]["write"]
        ov = json.loads(req("/api/rh/overview")[1])["results"]; assert {x["tool"] for x in ov} == {"get_accounts", "get_positions"}, ov
        assert req("/api/rh/read", {"tool": "place_stock_order", "args": {"symbol": "X"}})[0] == 403, "read endpoint must refuse a write tool"
        order = {"tool": "place_stock_order", "args": {"symbol": "AAPL", "qty": 1}}
        assert req("/api/rh/call", dict(order, confirm=True))[0] == 403, "no PIN"
        assert req("/api/rh/call", dict(order, confirm=True, pin="0000"))[0] == 403, "wrong PIN"
        assert req("/api/rh/call", dict(order, confirm=False, pin="4321"))[0] == 400, "no confirm"
        assert st["orders"] == [], "an order reached Robinhood without PIN + confirm"
        s, b = req("/api/rh/call", dict(order, confirm=True, pin="4321")); assert s == 200 and st["orders"] == [order["args"]], (s, b)
        # token refresh: expire the access token on disk, the next call must refresh and still work
        f = d / "robinhood.json"; cfg = json.loads(f.read_text()); assert cfg.get("refresh") == "RT1" and oct(f.stat().st_mode)[-3:] == "600", oct(f.stat().st_mode)
        assert req("/api/rh/disconnect", {})[0] == 200 and req("/api/rh/tools")[0] == 409
        assert '"/api/rh/callback"' in (ROOT / "server.py").read_text().split("LOCAL_ONLY")[0], "callback must be reachable from the other browser"
        # paste-the-address fallback: same sign-in, finished with the URL the browser ended on
        s, b = req("/api/rh/connect", {}); q = dict(up.parse_qsl(up.urlparse(json.loads(b)["url"]).query))
        assert req("/api/rh/finish", {"url": "http://127.0.0.1/x"})[0] == 400, "no code must be refused"
        s, b = req("/api/rh/finish", {"url": f"http://127.0.0.1:8010/api/rh/callback?code=good-code&state={q['state']}"}); assert s == 200, (s, b)
        assert req("/api/rh/tools")[0] == 200, "pasted address should connect"
    finally:
        p.terminate(); srv.shutdown()


@test("green touches: 3rd green-then-fade banks; off at 0; needs a fade back to ~break-even between touches")
def _():
    e = _engine(let_run=False, scale_out=False)
    e.s.green_touches = 3
    t = _mk_trade("SCALP")
    seq = [0.4, 0.5, 0.0, 0.4, 0.0, 0.35]
    out = [e._green_touches(t, r) for r in seq]
    assert out == [False, False, False, False, False, True], out  # 0.4/0.5 = one touch, then two more after fades
    t = _mk_trade("SCALP")
    assert not any(e._green_touches(t, r) for r in [0.4, 0.6, 0.8, 1.0]), "a steady climb is one touch, never banked"
    e.s.green_touches = 0
    t = _mk_trade("SCALP")
    assert not any(e._green_touches(t, r) for r in [0.4, 0, 0.4, 0, 0.4]), "0 turns the rule off"


@test("pin: pin_ok forgives whitespace, rejects wrong; PIN-set rejects symbols; guard flush skips tiny extended swings")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("def pin_ok"); j = src.index("\n\n\n", i)
    ns = {"live_pin": lambda: "abc123"}
    exec(src[i:j], ns)
    f = ns["pin_ok"]
    assert f("abc123") and f(" abc123\n") and not f("abc124") and not f("") and not f(None)
    ns["live_pin"] = lambda: ""
    assert not f(""), "no PIN configured must never match"
    assert "[\\s#'\"\\\\=$`]" in src or "re.search" in src
    st = (ROOT / "autobot" / "strategies.py").read_text()
    assert st.count('ctx.get("ext")') >= 2


@test("dashboard: Harvest all only offered with 2+ of your positions all green")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "mine.length >= 2 && mine.every(p => ((p.exit_upl != null ? p.exit_upl : p.upl) || 0) > 0)" in h and h.count("mine.length < 2 ||") == 1


@test("manual guard: never closes a position into a broken overnight quote, still closes on a sane one")
def _():
    from autobot.guard_manual import ManualGuard
    class S: guard_loss_pct = 0.15; guard_manual = True
    closed = []
    q = {"v": (47.57, 64.35)}
    g = ManualGuard(lambda: None, lambda: S, lambda e: "OVERNIGHT", lambda e, sym, sess: q["v"],
                    lambda e, sym: closed.append(sym), lambda *a, **k: None, lambda e, sym: False)
    class E:
        def event(self, *a, **k): pass
    E = E()
    pos = {"qty": 944, "avg_entry": 63.13, "price": 55.96, "upl": -6768.0}
    g.check(E, S, "close", "IHF", pos, "OVERNIGHT")
    assert closed == [], "closed into a 30% wide spread"
    q["v"] = (53.0, 53.1)
    g.check(E, S, "close", "IHF", pos, "OVERNIGHT")
    assert closed == ["IHF"], "a genuine -16% loss on a sane quote must still be closed"


@test("long-wave planner: finds a regular wave and plans legs; refuses random walks; API answers")
def _():
    import numpy as np, pandas as pd
    from autobot import longwave as lw
    idx = pd.date_range("2026-10-05 16:00", "2026-10-08 02:00", freq="5min", tz=NY)
    t = np.arange(len(idx)); rng = np.random.default_rng(1)
    c = 168 + 0.45 * np.sin(2 * np.pi * t / 30) + rng.normal(0, 0.05, len(idx))
    df = pd.DataFrame({"open": c, "high": c + .04, "low": c - .04, "close": c, "volume": 1}, index=idx)
    p = lw.plan(df, "X")
    assert p["ok"] and 120 <= p["cycle_mins"] <= 180 and 0.5 <= p["up_pct"] <= 0.8, p
    assert 1 <= len(p["legs"]) <= 5 and all(g["take"] > g["entry"] > g["stop"] and g["rr"] > 0 for g in p["legs"]), p["legs"]
    assert lw.backtest(df)["hit"] >= 0.7
    bad = 0
    for seed in range(8):
        r = np.random.default_rng(seed); w = 168 + np.cumsum(r.normal(0, 0.05, len(idx)))
        d2 = pd.DataFrame({"open": w, "high": w + .04, "low": w - .04, "close": w, "volume": 1}, index=idx)
        bad += bool(lw.plan(d2, "RW")["ok"])
    assert bad <= 1, f"{bad}/8 random walks were given a wave plan"
    assert "api/longwave" in (ROOT / "server.py").read_text() and "lwGo" in (ROOT / "web" / "dashboard.html").read_text()


@test("PIN: can be created/changed from the Trading-mode window, also while the bot runs; needs the current PIN to change")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("def keys_save"); j = src.index("def pin_set") if src.index("def pin_set") > i else len(src)
    body = src[i:i + 900]
    assert body.index("(k or s_) and engine and engine.running") < body.index("Stop the bot"), "a PIN alone must save while the bot runs"
    assert "/api/pin/set" in src and "pinSave()" in (ROOT / "web" / "dashboard.html").read_text()
    k = src[src.index("def pin_set"):src.index("def keys_save")]
    assert "pin_ok(r.current)" in k and "len(newpin) < 4" in k and "record_fail" in k


@test("loss limits: PAPER and LIVE each keep their own; migration starts both at the current limit; switching swaps it")
def _():
    from autobot import config
    d = Path(TMP) / "mig2"; d.mkdir()
    config.SETTINGS_FILE = d / "settings.json"; config.OPTIONS_FILE = d / "options_settings.json"
    config.SETTINGS_FILE.write_text(json.dumps({"daily_max_loss": 137.5}))
    s = config.Settings.load()
    assert s.daily_max_loss == 137.5 and s.loss_paper == 137.5 and s.loss_live == 137.5, (s.daily_max_loss, s.loss_paper, s.loss_live)
    s.live = False; s.daily_max_loss = 1000.0; s.remember_limit()                    # set paper to 1000
    s.remember_limit(); s.live = True; s.use_limit_for(True)
    assert s.daily_max_loss == 137.5, "live must keep the original limit"
    s.daily_max_loss = 50.0; s.remember_limit(); s.save()
    s.remember_limit(); s.live = False; s.use_limit_for(False)
    assert s.daily_max_loss == 1000.0 and s.loss_live == 50.0
    s2 = config.Settings.load()
    assert s2.loss_paper == 1000.0 and s2.loss_live == 50.0 and s2.v1903_limits


@test("armed picks: bot enters only inside the zone, with the card's stop/target, never when halted; shorts need the short gate")
def _():
    import json as _j
    from autobot import engine as E
    e = _engine()
    E.Engine.PICKS_FILE = Path(TMP) / "picks_test.json"
    e.acct = {"equity": 25000, "buying_power": 100000, "shorting_enabled": True}
    day = str(e.broker.now().date())
    e.set_pick("ZZZ", {"side": "up", "zone": [100.0, 100.5], "stop": 99.0, "tp1": 102.0, "name": "t", "score": 80})
    assert "ZZZ" in e.picks()
    sent = []
    e.broker.submit_limit_ext = lambda sym, side, qty, lim, cid: sent.append((sym, side, qty, lim)) or "oid1"
    e.broker.submit_bracket = lambda sym, side, qty, lim, stop, tp, cid: sent.append((sym, side, qty, lim, stop, tp)) or "oid2"
    e._ext_enabled = lambda s: True; e._event_block = lambda *a, **k: False; e._pair_block = lambda *a: False; e._margin_block = lambda: False
    e._fresh_account = lambda *a, **k: None
    now = e.broker.now()
    e._pick_entries(now, "PRE", {"ZZZ": (103.0, 103.05, 103.0)})              # price above the zone
    assert sent == [], "must wait while price is outside the zone"
    e.risk.halted = True
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert sent == [], "must not enter while halted"
    e.risk.halted = False
    e._pick_entries(now, "PRE", {"ZZZ": (100.0, 100.9, 100.2)})               # spread 0.9%: too wide
    assert sent == [], "must respect the spread check"
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert len(sent) == 1 and sent[0][1] == "buy" and sent[0][2] >= 1 and abs(sent[0][3] - 100.35) < 0.02, sent
    assert "ZZZ" not in e.picks() and e.trades["ZZZ"].stop == 99.0, "pick is consumed and the card's stop is used"
    e._pick_entries(now, "PRE", {"ZZZ": (100.2, 100.25, 100.2)})
    assert len(sent) == 1, "one entry per pick"
    st = (ROOT / "server.py").read_text()
    assert "/api/wave/pick" in st and "For a buy the stop must be below the zone" in st
    assert "mwArm(" in (ROOT / "web" / "dashboard.html").read_text()


@test("rookie level, presets, toggles, F, getting-started: present and the daily limit is never touched")
def _():
    from autobot import levels
    assert levels.ORDER[0] == "rookie" and levels.LEVELS["rookie"]["max_positions"] == 1 and not levels.LEVELS["rookie"]["allow_shorts"]
    srv = (ROOT / "server.py").read_text()
    i = srv.index("PRESET_KEYS"); assert "daily_max_loss" not in srv[i:i + 600] and "loss_paper" not in srv[i:i + 600]
    assert "/api/level/preset" in srv and "/api/onboard" in srv
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "gsPaint" in h and "presetSave" in h and "input[type=checkbox]" in h
    assert "*9/5+32" in (ROOT / "autobot" / "android.py").read_text().replace(" ", "")
    assert "dashboard.html" and "°F" in h


@test("trader modes: picker on first launch, mode saved without touching limits, rookie level on first pick, screens/learn per mode")
def _():
    from autobot import config
    s = config.Settings(); assert s.ui_mode == ""
    srv = (ROOT / "server.py").read_text(); i = srv.index("def set_uimode"); body = srv[i:i + 900]
    assert "daily_max_loss" not in body and "loss_paper" not in body and "apply_level(settings, \"rookie\")" in body
    h = (ROOT / "web" / "dashboard.html").read_text()
    for k in ("uiPick", "uiSet(", "ui-rookie", "ui-trader", "LN_GUIDE", "rkHome", "moRookie", "segUi"):
        assert k in h, k
    assert "data-n=\"${esc(n)}\"" in h and "presetApply('${" not in h, "preset names must not be put inside a JS string"
    assert "rkWhy" in h and "repeat(4,1fr)" in h and "_lgDone" in h
    assert h.count("LN_GUIDE") >= 2 and "rookie: [" in h and "trader: [" in h and "advanced: [" in h


@test("wave trader prices candidates the scanner missed and ignores quotes older than 5 minutes")
def _():
    s = (ROOT / "autobot" / "engine.py").read_text()
    i = s.index("def _wave_entries"); b = s[i:i + 6000]
    assert "miss = [r[\"symbol\"]" in b and "quote is stale" in b and "quotes.update(self.broker.quotes(miss" in b


@test("sekex ship/clean: keeps the newest 2, protects what latest.json points at and the user's data, dry-run deletes nothing")
def _():
    import subprocess
    r = subprocess.run([sys.executable, str(ROOT / "tests" / "ship_check.py"), str(ROOT)], capture_output=True, text=True, timeout=60)
    assert r.returncode == 0 and "OK" in r.stdout, r.stdout[-800:] + r.stderr[-800:]


@test("Find & fix it accepts up to 3 screenshots: validated, sent to the AI as images, never kept or shown in status")
def _():
    import base64
    from autobot import selffix
    ok = base64.b64encode(b"\x89PNG" + b"0" * 100).decode()
    assert len(selffix.clean_images([{"media_type": "image/png", "data": ok}])) == 1
    for bad in ([{"media_type": "image/gif", "data": ok}], [{"media_type": "image/png", "data": "!!"}], [{"media_type": "image/png", "data": ok}] * 4):
        try:
            selffix.clean_images(bad); assert False, "should reject"
        except ValueError:
            pass
    seen = {}
    class X:
        status_code = 200; text = ""
        def json(s): return {"content": [{"text": "{}"}], "usage": {}}
    selffix.ai_post = lambda t, p: (seen.setdefault("p", p), X())[1]; selffix._pick_model = lambda k: "m"
    selffix._ask("k", "s", "u", 10, [{"media_type": "image/png", "data": ok}])
    assert [b["type"] for b in seen["p"]["messages"][0]["content"]] == ["image", "text"]
    sf = selffix.SelfFix("1"); sf.job = {"id": "a", "state": "ready", "images": [1], "new_text": {}}
    assert "images" not in sf._public_job()
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "fixFile" in h and "fixPick" in h and "images: fixImgs" in h


@test("settings menu: grouped into categories, JS still parses, jump links open their category")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "moreMenu" in h and "details.mcat" in h and "closest('details.mcat')" in h


# ---------------------------------------------------------------- journal audit of simulator runs
def audit_journal(db_file, limit, max_notional, label):
    import sqlite3
    c = sqlite3.connect(db_file); c.row_factory = sqlite3.Row
    rows = [dict(r) for r in c.execute("SELECT * FROM trades WHERE status='closed' ORDER BY opened_at")]
    problems = []
    by_day = {}
    open_iv = {}
    for r in rows:
        side = 1 if r["side"] == "buy" else -1
        if r["qty"] is None or r["qty"] <= 0:
            problems.append(f"{r['id']} qty {r['qty']}")
        if (r["stop"] - r["entry"]) * side >= 0 and r["bucket"] != "MANUAL":
            problems.append(f"{r['symbol']} {r['strategy']} stop {r['stop']:.2f} on the wrong side of entry {r['entry']:.2f}")
        if r["qty"] * r["entry"] > max_notional * 1.05 + 1 and not r["id"].startswith("m"):
            problems.append(f"{r['symbol']} notional ${r['qty']*r['entry']:,.0f} over the ${max_notional:,.0f} cap")
        by_day[r["day"]] = by_day.get(r["day"], 0.0) + (r["pnl"] or 0.0)
        if r["pnl"] is not None and r["exit"] is not None:
            calc = (r["exit"] - r["entry"]) * side * r["qty"]
            if abs(calc - r["pnl"]) > max(0.05, 0.02 * abs(calc)) and abs(r["pnl"]) > 0.5:
                problems.append(f"{r['symbol']} pnl {r['pnl']:.2f} != (exit-entry)*qty {calc:.2f}")
        iv = open_iv.setdefault(r["symbol"], [])
        if r["closed_at"] and r["opened_at"]:
            for a, b in iv:
                if r["opened_at"] < b and r["closed_at"] > a:
                    problems.append(f"{r['symbol']} two positions open at once ({r['opened_at'][:16]})")
                    break
            iv.append((r["opened_at"], r["closed_at"]))
    worst = min(by_day.values()) if by_day else 0.0
    return {"trades": len(rows), "pnl": round(sum(by_day.values()), 2), "worst_day": round(worst, 2), "problems": problems[:12], "n_problems": len(problems)}


@test("wave watchlist: every session family (pre, regular, after, overnight) builds from 15-minute bars; mode follows the clock")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    idx = []
    for d in pd.bdate_range("2026-08-03", periods=45):
        idx += list(pd.date_range(d.strftime("%Y-%m-%d") + " 04:00", d.strftime("%Y-%m-%d") + " 19:45", freq="15min", tz="America/New_York"))
    rng = np.random.default_rng(1); p = 100 + np.cumsum(rng.normal(0, .2, len(idx)))
    df = pd.DataFrame({"open": p, "high": p + .15, "low": p - .15, "close": p + rng.normal(0, .05, len(idx)), "volume": 1000}, index=idx)
    for m in mw.MODES:
        days = mw._days(df, m)
        assert len(days) >= 40 and days[-1]["pc"] > 0, m
        mw.build({"ZZ": df}, 0.4, m)
    assert [mw.mode_for("PRE", 500), mw.mode_for("REGULAR", 9 * 60 + 40), mw.mode_for("REGULAR", 11 * 60), mw.mode_for("AFTER", 1000), mw.mode_for("OVERNIGHT", 1300), mw.mode_for("CLOSED", 0)] == \
        ["PRE", "PRE", "REGULAR", "AFTER", "OVERNIGHT", "PRE"]


@test("loss limits: /api/limit can set the other mode's limit without touching the one in use")
def _():
    src = (ROOT / "server.py").read_text()
    assert "want_live" in src and "mode: str" in src
    from autobot import config
    s = config.Settings(); s.live = False; s.daily_max_loss = 200.0; s.remember_limit(); s.loss_live = 500.0
    s.use_limit_for(False); assert s.daily_max_loss == 200.0 and s.loss_live == 500.0


@test("support: the admin's collector address rides in latest.json and is adopted only when the tester has none")
def _():
    assert '"collector"' in (ROOT / "bin" / "sekex_publish.py").read_text()
    assert "m.get(\"collector\")" in (ROOT / "server.py").read_text()


@test("predict tab: exists for every trader mode, Auto top 10 / My list, education on each card")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text(); sv = (ROOT / "server.py").read_text()
    assert 'data-go="pred"' in h and 'data-v="pred" class="card c12 rk"' in h and "mwEdu" in h and "mwSource" in h
    assert "[data-go=pred]" not in h.split("html.ui-rookie [data-go=sess]")[1].split("}")[0], "Predict must not be hidden in Rookie"
    assert "/api/predict/prefs" in sv and "pred_source" in sv and "[:10]" in sv
    from autobot import config
    st = config.Settings(); assert st.pred_source == "auto" and st.pred_manual == []


@test("check-up: finds repeating errors / loss-limit use, drafts a fix only when asked, never changes settings; options re-price and auto-tune")
def _():
    import tempfile, collections, datetime as _dt
    from types import SimpleNamespace as NS
    from autobot import checkup, config, options
    checkup.FILE = Path(tempfile.mkdtemp()) / "c.json"
    st = config.Settings(); st.daily_max_loss = 1000.0; lim0 = st.daily_max_loss
    ev = collections.deque([{"t": "10:00:0%d" % i, "msg": "Loop error: cannot unpack non-iterable NoneType object", "level": "error"} for i in range(4)])
    e = NS(s=st, events=ev, day="2026-10-09", broker=NS(now=lambda: _dt.datetime(2026, 10, 9, 16, 20)), risk=NS(day_pnl=-900.0), acct={"equity": 1500.0}, alerts=None, alert=lambda *a, **k: None)
    started = []
    sf = NS(start=lambda problem, extra="": started.append(problem))
    rep = checkup.run(e, None, sf, "manual")
    titles = " | ".join(i["title"] for i in rep["items"])
    assert rep["grade"] == "attention" and "Repeating error" in titles and "90%" in titles and "over half" in titles, titles
    assert started and "loss limits" in started[0], "fix draft not requested"
    assert st.daily_max_loss == lim0, "check-up changed the loss limit"
    st.auto_fix_draft = False; started.clear(); checkup.run(e, None, sf, "manual"); assert not started
    # options: reprice then tune
    calls = []
    class Tr:
        def replace_order_by_id(self, oid, req): calls.append((oid, req.limit_price, req.qty)); return NS(id="new1")
    ob = options.OptionsBot.__new__(options.OptionsBot)
    ob.s = st; ob.events = collections.deque(); ob.fills = []; ob._fcount = 0; ob._tuned_n = 0; ob.get_engine = lambda: None; ob._save = lambda: None
    ob._quotes = lambda e_, syms: {syms[0]: (1.0, 1.04)}
    p = {"underlying": "TSLA", "direction": "call", "style": "single", "long": "TSLA_X", "limit": 1.00, "debit": 1.0, "qty": 2, "order_id": "o1", "sent_at": 0}
    e2 = NS(broker=NS(trading=Tr())); st.options_max_premium = 200.0
    assert ob._reprice(e2, p) and p["limit"] == 1.04 and p["reprices"] == 1 and calls[0][1] == 1.04 and p["qty"] == 1, (p, calls)    # capped at the ask; qty cut to fit $200
    assert not ob._reprice(e2, p), "re-priced past the ask"
    st.save = lambda: None
    for _i in range(10): ob._note_fill(NS(day="d"), 0, p)
    assert st.opt_reprice_step_pct > 4.0, "auto-tune did not react to a 0% fill rate"


@test("AI helper: time-of-day scan ranks gains / drops; chat runs tools then answers; tools cannot trade")
def _():
    import numpy as np, pandas as pd
    from types import SimpleNamespace as NS
    from autobot import trendscan, aihelper
    idx = []
    for d in pd.bdate_range("2026-08-03", periods=45):
        idx += list(pd.date_range(d.strftime("%Y-%m-%d") + " 04:00", d.strftime("%Y-%m-%d") + " 19:45", freq="15min", tz="America/New_York"))
    rng = np.random.default_rng(3); px = 100 + np.cumsum(rng.normal(0, .3, len(idx)))
    df = pd.DataFrame({"open": px, "high": px + .2, "low": px - .2, "close": px, "volume": 1}, index=idx)
    wild = df.copy(); wild[["open", "high", "low", "close"]] = wild[["open", "high", "low", "close"]] * 1.0 + np.sin(np.arange(len(wild)) / 3.0)[:, None] * 2
    out = trendscan.scan({"CALM": df * 0.2, "WILD": wild}, "after lunch", 0.5, 5)
    assert out["window"] == "afterlunch" and out["scanned"] == 2 and out["gains"][0]["symbol"] == "WILD", out
    assert trendscan.window_key("before close") == "close" and trendscan.window_key("morning") == "morning"
    replies = iter(['{"tool": "scan_trends", "args": {"window": "close"}}', '```json\n{"answer": "Here you go"}\n```'])
    seen = []
    class R:
        status_code = 200
        text = ""
        def json(self): return {"content": [{"type": "text", "text": next(replies)}]}
    orig = (aihelper.ai_post, aihelper.ai_key, aihelper._pick_model)
    aihelper.ai_post = lambda t, payload: (seen.append(payload["messages"][-1]["content"][:30]), R())[1]; aihelper.ai_key = lambda: "k"; aihelper._pick_model = lambda k: "m"
    try:
        res = aihelper.chat([{"role": "user", "content": "big drops before close?"}], {"scan_trends": lambda a: {"ok": a}}, "now")
    finally:
        aihelper.ai_post, aihelper.ai_key, aihelper._pick_model = orig
    assert res["answer"] == "Here you go" and res["cards"][0]["tool"] == "scan_trends" and seen[1].startswith("TOOL RESULT scan_trends"), (res, seen)
    src = (ROOT / "server.py").read_text(); body = src.split("def _ai_tools():")[1].split("@app.post(\"/api/ai/chat\")")[0]
    assert "submit_order" not in body and "place" not in body.lower().replace("placement", "") and "/api/limit" not in body


@test("Robinhood ticket: all taps (no typing), values sent in the type Robinhood wants, extra required fields as buttons")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    for k in ("function rhCast", "ty == 'string') return String(v)", "rhPinKey", "rhQtyAdd", "rhOTset", "rhExtraPick", "rhPickSym"):
        assert k in h, k
    for k in ("rhQuoteGet", "rhAcctGet", "rhHoldGet", "rhOrdGet", "rhCancel", "rhTIFset", "rhResultHtml", "function rhDial", "rhKnob", "RH_HIDE"):
        assert k in h, k
    for k in ("const RHW = [", "rhWizCheck", "rhWizInit", "Open the Agentic account"):
        assert k in h, k
    assert 'id="rhSym" type="hidden"' in h and 'id="rhQty" type="hidden"' in h


@test("RSI zone: uptrend dip that holds then turns = BUY, downtrend bounce that fails = SELL, zones are plain, record needs enough cases, endpoint and alert exist")
def _():
    import numpy as np, pandas as pd
    from autobot import rsizone
    r = pd.Series([60.0] * 10 + [48, 46, 47, 52.0]); tr = pd.Series([1] * len(r))
    assert rsizone._signal_at(r, tr, len(r) - 1) == 1
    r2 = pd.Series([40.0] * 10 + [52, 54, 53, 48.0]); tr2 = pd.Series([-1] * len(r2))
    assert rsizone._signal_at(r2, tr2, len(r2) - 1) == -1
    r3 = pd.Series([60.0] * 10 + [30, 32, 35, 52.0])                     # dip below 38 = trend in doubt, no signal
    assert rsizone._signal_at(r3, tr, len(r3) - 1) == 0
    assert rsizone._zone(1, 85)[0] == "stretched" and rsizone._zone(1, 45)[0] == "pullback" and rsizone._zone(-1, 55)[0] == "bounce" and rsizone._zone(0, 50)[0] == "flat"
    assert rsizone._evidence({1: [0.1] * 3}, 1)["ok"] is False
    assert rsizone._evidence({1: [0.2] * 10}, 1)["ok"] is True
    idx = pd.date_range("2026-08-20 09:30", periods=3000, freq="15min", tz="America/New_York"); idx = idx[(idx.hour >= 9) & (idx.hour < 16)]
    c = 100 * np.exp(np.cumsum(np.random.default_rng(3).normal(0.0003, 0.004, len(idx))))
    a = rsizone.analyze("T", pd.DataFrame({"open": c, "high": c, "low": c, "close": c, "volume": 1}, index=idx))
    assert a["ok"] and a["trend"] in ("UP", "DOWN", "FLAT") and "history" in a
    assert "rsizone" in (ROOT / "server.py").read_text() and '"rsizone"' in (ROOT / "autobot" / "alerts.py").read_text()


@test("Predict card projected profit: shares from the bot's own sizing, profit at TP1/TP2, loss at the stop, flags for poor reward/risk")
def _():
    import re
    src = (ROOT / "server.py").read_text()
    ns = {}
    exec(re.search(r"def _wave_plan\(.*?\n    return out\n", src, re.S).group(0), ns)
    r = {"side": "up", "zone": [100.0, 102.0], "stop": 98.0, "tp1": 106.0, "tp2": 110.0, "atr": 4.0}
    p = ns["_wave_plan"](r, 101.0, lambda e, st: (10, ""))
    assert p["qty"] == 10 and p["tp1"] == 50.0 and p["tp2"] == 90.0 and p["stop"] == -30.0 and p["cost"] == 1010.0 and p["rr1"] == 1.67
    z = ns["_wave_plan"](r, 101.0, lambda e, st: (0, "no risk budget left"))
    assert z["qty"] == 0 and z["why"] == "no risk budget left"
    f = ns["_wave_plan"]({"side": "down", "zone": [10.0, 11.0], "stop": 13.0, "tp1": 9.5, "tp2": 8.0, "atr": 1.0}, 10.5, lambda e, st: (10, ""))
    assert f["long"] is False and f["tp1"] == 10.0 and f["stop"] == -25.0 and f["poor"] is True and f["unlikely"] is True
    assert "function mwPlan" in (ROOT / "web" / "dashboard.html").read_text()


@test("sekex ship / update skip a damaged or half-downloaded zip and use the newest complete one")
def _():
    import importlib.util, tempfile, zipfile, os as _os
    spec = importlib.util.spec_from_file_location("sekex_publish_t", ROOT / "bin" / "sekex_publish.py")
    pub = importlib.util.module_from_spec(spec); spec.loader.exec_module(pub)
    d = tempfile.mkdtemp()
    with zipfile.ZipFile(_os.path.join(d, "SekexBot_Android_v2.1.0.zip"), "w") as z:
        z.writestr("SekexBot_Android/VERSION", "2.1.0")
    open(_os.path.join(d, "SekexBot_Android_v2.2.0.zip"), "wb").write(b"not a zip" * 50)
    old = _os.path.expanduser
    _os.path.expanduser = lambda x: d if x == "~/storage/downloads" else "/nonexistent"
    try:
        assert _os.path.basename(pub.find_zip("")) == "SekexBot_Android_v2.1.0.zip"
        try:
            pub.find_zip(_os.path.join(d, "SekexBot_Android_v2.2.0.zip")); assert False
        except SystemExit as e:
            assert "damaged" in str(e)
    finally:
        _os.path.expanduser = old
    assert "zipfile.ZipFile(f)" in (ROOT / "bin" / "sekex").read_text()


@test("wave hit rate only counts the NEXT morning (a flat next morning must not score as a hit)")
def _():
    import numpy as np, pandas as pd
    from autobot import morningwave as mw
    NY = mw.NY; rows = []; prev = 100.0
    for d in pd.bdate_range("2026-08-03", periods=30):
        ds = d.strftime("%Y-%m-%d")
        for t in pd.date_range(ds + " 04:00", periods=22, freq="15min", tz=NY): rows.append((t, prev, prev, prev, prev))
        close = prev * 1.001; path = np.linspace(prev * .97, close, 26); path[20] = close * 1.005
        for t, p in zip(pd.date_range(ds + " 09:30", periods=26, freq="15min", tz=NY), path): rows.append((t, p, p, p, p))
        for t in pd.date_range(ds + " 16:00", periods=16, freq="15min", tz=NY): rows.append((t, close, close, close, close))
        prev = close
    df = pd.DataFrame(rows, columns=["ts", "open", "high", "low", "close"]).set_index("ts").sort_index()
    df = df[~df.index.duplicated(keep="last")]
    assert mw.analyze("T", df, 0.4, "PRE") is None


@test("sekex ship: declining the delete question still publishes")
def _():
    src = (ROOT / "bin" / "sekex_ship.py").read_text()
    assert "Also delete the old files" in src and "--keep-old" in src and "def confirm(msg, yes, default=False)" in src
    assert src.index("Also delete the old files") < src.index("pub.main()")


@test("Learn wizards exist (first trade 11 screens, Radar 8) and the Predict tab is renamed Radar / Setups")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert "const FIRST = [" in h and "const RADAR = [" in h and "id=\"wzCard\"" in h
    assert 'data-go="more" onclick="setView(\'more\')"' not in h and 'id="gearBtn" data-go="more"' in h
    assert "pred: 'Radar'" in h and '<span class="stL">Radar</span>' in h


@test("Learn wizard 'A good setup, start to finish' has 12 steps, buy+short views, calculator and checklist")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    a = h.index("const SETUP = ["); b = h.index("function suTick", a)
    assert "setup: {t:" in h and "function suSvg(" in h and "function suCalc(" in h
    assert "Floor and ceiling" in h[a:b] and "SU.short = true" in h[a:b] and "wzOpen('first')" in h[a:b]


@test("Re-applied phone fixes: Radar Manual list seeds from watchlist; Robinhood numeric args sent as text when the tool wants text")
def _():
    src = (ROOT / "server.py").read_text()
    assert "empty manual list: start from the watchlist" in src
    ns = {}
    a = src.index("def _rh_fit_args"); b = src.index('@app.post("/api/rh/call")')
    exec(src[a:b], ns)
    f = ns["_rh_fit_args"]
    sch = {"properties": {"quantity": {"type": "string"}, "limit": {"type": "number"}, "side": {"type": "string"}}}
    assert f({"quantity": 1, "limit": 2.5, "side": "buy"}, sch) == {"quantity": "1", "limit": 2.5, "side": "buy"}
    assert f({"quantity": 1.5}, sch) == {"quantity": "1.5"} and f({"quantity": True}, sch) == {"quantity": True}


@test("One instance only: second copy on the same data folder exits (code 3); a new LiveFeed closes the old socket first; logging has no duplicate handlers")
def _():
    import subprocess, tempfile, sys as _s, types, threading, time as _t
    d = tempfile.mkdtemp()
    env = dict(os.environ, AUTOBOT_DATA=d)
    env.pop("SEKEX_NO_LOCK", None)
    a = subprocess.Popen([_s.executable, str(ROOT / "server.py"), "--sim", "--port", "8191"], env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, cwd=ROOT)
    try:
        _t.sleep(5)
        b = subprocess.run([_s.executable, str(ROOT / "server.py"), "--sim", "--port", "8192"], env=env, capture_output=True, text=True, cwd=ROOT, timeout=40)
        assert b.returncode == 3 and "already running" in b.stdout, (b.returncode, b.stdout[-300:])
    finally:
        a.terminate(); a.wait(10)
    # stream: stubbed Alpaca websocket that blocks in run() until stop()
    live = types.ModuleType("alpaca.data.live"); enums = types.ModuleType("alpaca.data.enums")
    opened = []
    class DF: SIP = "sip"; IEX = "iex"
    enums.DataFeed = DF
    class SDS:
        def __init__(self, *a, **k): self.ev = threading.Event(); opened.append(self)
        def subscribe_quotes(self, *a): pass
        def subscribe_trades(self, *a): pass
        def run(self): self.ev.wait()
        def stop(self): self.ev.set()
    live.StockDataStream = SDS
    saved = {k: _s.modules.get(k) for k in ("alpaca", "alpaca.data", "alpaca.data.live", "alpaca.data.enums")}
    for k in saved: _s.modules[k] = types.ModuleType(k)
    _s.modules["alpaca.data.live"] = live; _s.modules["alpaca.data.enums"] = enums
    try:
        from autobot import stream
        f1 = stream.LiveFeed("k", "s"); _t.sleep(0.6)
        assert len(opened) == 1 and not opened[0].ev.is_set()
        f2 = stream.LiveFeed("k", "s"); _t.sleep(0.6)
        assert opened[0].ev.is_set() and not f1._t_run.is_alive(), "old socket must be closed before the new one runs"
        assert len(opened) == 2 and not opened[1].ev.is_set()
        f2.stop(); assert not f2._t_run.is_alive()
    finally:
        for k, v in saved.items():
            (_s.modules.__setitem__(k, v) if v is not None else _s.modules.pop(k, None))
    src = (ROOT / "server.py").read_text()
    assert "force=True" in src and "_set_feed(None)" in src and 'if [ "$code" = 3 ]' in (ROOT / "bin" / "sekex").read_text()


@test("Radar card shows a last-updated time and a stale warning (10 min amber, 30 min red)")
def _():
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert 'id="mwStale"' in h and "function mwAge()" in h and "STALE: tap Refresh" in h and "refresh failed, showing old data" in h
    s = (ROOT / "server.py").read_text()
    assert '"ts": round(_tm.time())' in s and "age_s=round(" in s


@test("Radar weekend plan: gap is Fri 8 PM to Sun 8 PM ET, auto-rebuild thread at Sun 6:00 / 7:45 PM with a notification, banner on the card")
def _():
    from datetime import datetime as D
    src = (ROOT / "server.py").read_text()
    a = src.index("def _weekend_gap"); b = src.index("\n\n\n", a)
    ns = {}; exec(src[a:b], ns); g = ns["_weekend_gap"]
    assert not g(D(2026, 10, 9, 19, 59)) and g(D(2026, 10, 9, 20, 0)) and g(D(2026, 10, 10, 12)) and g(D(2026, 10, 11, 19, 59))
    assert not g(D(2026, 10, 11, 20, 0)) and not g(D(2026, 10, 12, 9))
    assert "_weekend_radar_loop" in src and 'slot = "6pm"' in src and 'slot = "745pm"' in src and "Radar weekend plan" in src
    h = (ROOT / "web" / "dashboard.html").read_text()
    assert 'id="mwWk"' in h and "Weekend plan." in h and "j.weekend" in h


@test("v2.5.4: cheap-stock stop floor, Cloudflare Access headers for Ollama, state-aware watchlist button, real-stock checklist screen")
def _():
    import os as _o
    from autobot import morningwave as mw, analyst
    assert mw.min_risk(1.5) == 0.04 and abs(mw.min_risk(200) - 2.0) < 1e-9 and mw.px_round(0.123456, 0.5) == 0.1235 and mw.px_round(3.14159, 3) == 3.14
    assert "min_risk(c)" in (ROOT / "autobot" / "morningwave.py").read_text()
    old = {k: _o.environ.get(k) for k in ("OLLAMA_CF_ID", "OLLAMA_CF_SECRET")}
    try:
        _o.environ.pop("OLLAMA_CF_ID", None); _o.environ.pop("OLLAMA_CF_SECRET", None)
        assert "CF-Access-Client-Id" not in analyst._ollama_headers("")
        _o.environ["OLLAMA_CF_ID"] = "abc.access"; _o.environ["OLLAMA_CF_SECRET"] = "sec"
        hd = analyst._ollama_headers("")
        assert hd["CF-Access-Client-Id"] == "abc.access" and hd["CF-Access-Client-Secret"] == "sec"
    finally:
        for k, v in old.items():
            (_o.environ.__setitem__(k, v) if v is not None else _o.environ.pop(k, None))
    sv = (ROOT / "server.py").read_text(); h = (ROOT / "web" / "dashboard.html").read_text()
    assert "cf_id: str | None" in sv and "ollama_cf_set" in sv and 'id="kCfBox"' in h and "kCfClear" in h
    assert "function wlBtn(" in h and "↩ Cover" in h and "✓ Own " in h and "⏳ Order" in h and "${wlBtn(w)}" in h
    assert "function suRead(" in h and "function suScan(" in h and "Try it on a real stock" in h


@test("Night / extended manual market order is converted to a limit 0.2% through the spread (sim, 9 PM overnight)")
def _():
    import subprocess, tempfile, sys as _s, time as _t, json as _j, urllib.request as _u
    d = tempfile.mkdtemp(); env = dict(os.environ, AUTOBOT_DATA=d, SEKEX_NO_LOCK="1")
    p = subprocess.Popen([_s.executable, str(ROOT / "server.py"), "--sim", "--sim-start", "21:00", "--port", "8193"], env=env,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, cwd=ROOT)
    try:
        for _ in range(40):
            try:
                q = _j.load(_u.urlopen("http://127.0.0.1:8193/api/manual/quote/SPY", timeout=3)); break
            except Exception:
                _t.sleep(0.5)
        def post(body):
            rq = _u.Request("http://127.0.0.1:8193/api/manual/order", _j.dumps(body).encode(), {"content-type": "application/json"})
            return _j.load(_u.urlopen(rq, timeout=10))
        assert q["session"] == "OVERNIGHT"
        r = post({"symbol": "SPY", "side": "buy", "qty": 1, "order_type": "market", "session": "auto", "tif": "day"})
        assert r["ok"] and any("sent as a limit" in n and "above the ask" in n for n in r["notes"]), r
        r2 = post({"symbol": "QQQ", "side": "sell", "qty": 1, "order_type": "market", "session": "auto", "tif": "day", "confirm_short": True})
        assert r2["ok"] and any("below the bid" in n for n in r2["notes"]), r2
    finally:
        p.terminate(); p.wait(10)


@test("Alpaca clients get a bigger HTTP connection pool (no 'Connection pool is full' warnings)")
def _():
    from autobot.broker import _widen_pools
    from alpaca.trading.client import TradingClient
    from alpaca.data.historical import StockHistoricalDataClient
    a = TradingClient("k", "s", paper=True); b = StockHistoricalDataClient("k", "s")
    _widen_pools(a, b)
    for c in (a, b):
        ad = c._session.get_adapter("https://data.alpaca.markets")
        assert ad._pool_maxsize == 40 and ad._pool_connections == 40
    assert "_widen_pools(self.trading, self.data, self.screener)" in (ROOT / "autobot" / "broker.py").read_text()


@test("sekex publish uploads the zip, SekexBot_Setup.sh, the release-notes PDF, then latest.json last (mock GitHub); skips a wrong-version installer")
def _():
    import http.server, threading, json as _j, base64 as _b, tempfile, importlib.util, sys as _s, os as _o, re as _re
    store, order = {}, []
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def _send(self, code, obj):
            b = _j.dumps(obj).encode(); self.send_response(code); self.send_header("Content-Length", str(len(b))); self.end_headers(); self.wfile.write(b)
        def do_GET(self):
            n = self.path.split("/contents/")[-1].split("?")[0]
            self._send(200, {"sha": "x"}) if n in store else self._send(404, {})
        def do_PUT(self):
            n = self.path.split("/contents/")[-1].split("?")[0]
            body = _j.loads(self.rfile.read(int(self.headers["Content-Length"])))
            store[n] = _b.b64decode(body["content"]); order.append(n); self._send(201, {})
    srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    d = tempfile.mkdtemp()
    ver = "9.9.9"
    open(_o.path.join(d, "SekexBot_Setup.sh"), "wb").write(b"#!/bin/bash\n# Version  9.9.9\n__SEKEX_PAYLOAD__\n" + b"A" * 200_000)
    open(_o.path.join(d, f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"), "wb").write(b"%PDF-1.4 test")
    _o.environ["SEKEX_GITHUB_API"] = f"http://127.0.0.1:{srv.server_port}"
    try:
        spec = importlib.util.spec_from_file_location("sekex_publish_t", ROOT / "bin" / "sekex_publish.py")
        pub = importlib.util.module_from_spec(spec); _s.path.insert(0, str(ROOT / "bin")); spec.loader.exec_module(pub)
        cfg = {"repo": "o/r", "token": "t", "branch": "main"}
        comp = pub.companions(_o.path.join(d, "SekexBot_Android_v9.9.9.zip"), ver)
        assert [c[0] for c in comp] == ["SekexBot_Setup.sh", f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"] and all(c[1] for c in comp), comp
        for n, data, _ in comp:
            assert pub.put(cfg, n, data, "m") == "uploaded"
        assert pub.put(cfg, "SekexBot_Setup.sh", store["SekexBot_Setup.sh"], "m") in ("uploaded", "unchanged")
        assert set(store) == {"SekexBot_Setup.sh", f"SekexBot_Android_Release_Notes_and_Install_v{ver}.pdf"}
        bad = pub.companions(_o.path.join(d, "x.zip"), "9.9.8")                     # wrong-version installer is never uploaded
        assert bad[0][1] is None and "not the v9.9.8 installer" in bad[0][2]
    finally:
        srv.shutdown(); _o.environ.pop("SEKEX_GITHUB_API", None)
    shp = (ROOT / "bin" / "sekex_ship.py").read_text()
    assert "Release_Notes_and_Install_v" in shp and '"SekexBot_Setup.sh"' in shp


@test("Stocks-off (options-only) mode: every stock entry path is gated, and the setting defaults to on")
def _():
    from autobot.config import Settings
    import types
    from autobot.engine import Engine
    assert Settings().stocks_on is True
    src = (ROOT / "autobot" / "engine.py").read_text()
    for fn in ("_entries", "_wave_entries", "_pick_entries", "_ext_entries"):
        i = src.index("    def " + fn + "(")
        assert "if self._stocks_off():" in src[i:i + 700], fn
    fake = types.SimpleNamespace(s=types.SimpleNamespace(stocks_on=False), state="")
    assert Engine._stocks_off(fake) is True and "options-only" in fake.state
    fake.s.stocks_on = True
    assert Engine._stocks_off(fake) is False


@test("Options Hub: strike rows (breakeven, flags), payoff, and every order safety rule")
def _():
    from autobot import optionshub as oh
    c = oh.parse_occ("TSLA261121C00400000")
    assert c["underlying"] == "TSLA" and c["kind"] == "call" and c["strike"] == 400.0 and str(c["expiry"]) == "2026-11-21"
    assert oh.parse_occ("TSLA") is None and oh.parse_occ("TSLA261121X00400000") is None
    cons = [{"symbol": f"S{k}", "strike": float(k), "oi": 500 if k != 410 else 10} for k in (380, 390, 400, 410, 420)]
    snaps = {"S400": {"bid": 29.0, "ask": 29.2}, "S410": {"bid": 20.0, "ask": 26.0}}
    rows = {r["strike"]: r for r in oh.rows_for("call", 351.31, cons, snaps)}
    assert rows[400.0]["breakeven"] == 429.2 and rows[400.0]["itm"] is False and rows[400.0]["to_be_pct"] == 22.2
    assert "thin open interest" in rows[410.0]["flags"] and "wide spread" in rows[410.0]["flags"] and "no quote" in rows[380.0]["flags"]
    assert [r["strike"] for r in oh.rows_for("call", 351.31, cons, snaps)] == [420.0, 410.0, 400.0, 390.0, 380.0]
    put = oh.rows_for("put", 351.31, [{"symbol": "P", "strike": 400.0, "oi": 500}], {"P": {"bid": 60.0, "ask": 61.0}})[0]
    assert put["breakeven"] == 339.0 and put["itm"] is True
    pf = oh.payoff("call", 400, 29.2, 351.31)
    assert pf["max_loss"] == 2920.0 and pf["max_profit"] is None and pf["breakeven"] == 429.2
    assert oh.payoff("put", 400, 20, 351.31)["max_profit"] == 38000.0
    ok = dict(side="buy", qty=1, limit=1.5, held_qty=0, bp=5000, level=2, market_open=True, halted=False, live=False, live_unlocked=False,
              pin_given_ok=True, confirm=True, managed_by_bot=False)
    assert oh.check_order(**ok) == ""
    for k, v, word in (("confirm", False, "confirm"), ("qty", 99, "between"), ("limit", 0, "limit"), ("market_open", False, "regular hours"),
                       ("halted", True, "daily loss limit"), ("level", 0, "approved"), ("limit", 60, "buying power"), ("managed_by_bot", True, "bot is managing"),
                       ("side", "sell", "naked")):
        assert word in oh.check_order(**{**ok, k: v}).lower() or word in oh.check_order(**{**ok, k: v}), (k, oh.check_order(**{**ok, k: v}))
    assert "locked" in oh.check_order(**{**ok, "live": True})
    assert "PIN" in oh.check_order(**{**ok, "live": True, "live_unlocked": True, "pin_given_ok": False})
    assert oh.check_order(**{**ok, "live": True, "live_unlocked": True}) == ""
    assert oh.check_order(**{**ok, "side": "sell", "held_qty": 2, "halted": True}) == ""      # you can always close, even after the loss limit


@test("Built-in preset 'Fewer, bigger trades' never touches the loss limit and only uses preset keys")
def _():
    src = (ROOT / "server.py").read_text()
    i = src.index("BUILTIN_PRESETS = {"); blk = src[i:src.index("def _presets", i)]
    ns = {}
    keys = eval(src[src.index("PRESET_KEYS = ["):src.index("]", src.index("PRESET_KEYS = ["))+1].split("=", 1)[1])
    exec(blk, ns)
    p = ns["BUILTIN_PRESETS"]["Fewer, bigger trades"]
    assert set(p) <= set(keys), set(p) - set(keys)
    assert not any("loss" in k for k in p) and "daily_max_loss" not in keys
    assert p["max_positions"] == 2 and p["risk_per_trade_frac"] > 0.2 and p["scalp_mode"] is False and p["reentry"] is False


@test("Support preset offers: only whitelisted keys, clamped, never the loss limit / keys / PIN / live; collector refuses them too")
def _():
    from autobot import offers
    src = (ROOT / "server.py").read_text()
    keys = set(eval(src[src.index("PRESET_KEYS = ["):src.index("]", src.index("PRESET_KEYS = ["))+1].split("=", 1)[1]))
    assert set(offers.RULES) == keys, set(offers.RULES) ^ keys
    c = offers.sanitize({"id": "a1", "name": "<b>Calm</b>", "reason": "x" * 900,
                         "settings": {"daily_max_loss": 5, "live": True, "api_key": "k", "pin": "1", "max_positions": 99,
                                      "risk_per_trade_frac": 5, "scalp_mode": "yes", "reentry": False}})
    assert c and set(c["settings"]) == {"max_positions", "risk_per_trade_frac", "reentry"}, c
    assert c["settings"]["max_positions"] == 8 and c["settings"]["risk_per_trade_frac"] == 0.40 and "<" not in c["name"] and len(c["reason"]) <= 400
    assert offers.sanitize({"id": "a", "name": "n", "settings": {"daily_max_loss": 1}}) is None
    assert offers.sanitize({"id": "", "name": "n", "settings": {"reentry": True}}) is None
    assert offers.diff(c, {"max_positions": 8, "reentry": True})[0]["key"] == "risk_per_trade_frac"
    # the collector's own copy of the whitelist must match
    import re as _re
    cs = (ROOT.parent / "SekexBot_Admin" / "..").resolve()
    for cand in (Path("/tmp/col/sekexbot_collector/collector.py"),):
        if cand.exists():
            m = _re.search(r"OFFER_KEYS = \{(.*?)\}", cand.read_text(), _re.S)
            assert set(_re.findall(r'"(\w+)"', m.group(1))) == keys


@test("Overnight Positions price: real recent trade beats the mid-quote; stale trade falls back to the mid")
def _():
    src = (ROOT / "server.py").read_text()
    assert "last_trades(" in src and '"px_src"' in src and 'px_age_s' in src
    assert "def last_trades" in (ROOT / "autobot" / "broker.py").read_text()
    assert "px_src" in (ROOT / "web" / "dashboard.html").read_text()


@test("24-hour Radar: new setup rules fire on the right shapes; buy/sell windows skip weekends; picks can be armed for a later day")
def _():
    from autobot import radar24 as r24
    from datetime import date, datetime, timedelta
    wk = lambda d: d.weekday() < 5
    assert r24.next_trading(date(2026, 10, 9), wk) == date(2026, 10, 12)                 # Friday -> Monday
    mk = lambda c, h=None, l=None, v=1000.0, o=None: {"c": c, "h": h or c * 1.004, "l": l or c * 0.996, "v": v, "o": o or c * 0.999}
    # steady up-trend with a 2.5% dip off the 5-day high
    rows = [mk(100 + i * 0.5) for i in range(40)]
    hi = rows[-1]["h"]; rows[-1] = mk(rows[-2]["c"] * 0.975, h=hi)
    f = r24._flags(rows, len(rows) - 1)
    assert "TREND_PULLBACK" in f and "RANGE_BREAKOUT" not in f, f
    # three down closes well under the 20-day average
    rows = [mk(100.0) for _ in range(30)] + [mk(97.5), mk(95.0), mk(92.0)]
    assert "OVERSOLD_BOUNCE" in r24._flags(rows, len(rows) - 1)
    # close above the 10-day high on 2x volume with a strong up day
    rows = [mk(100.0 + (i % 3) * 0.2, v=1000.0) for i in range(30)] + [mk(103.0, o=100.0, v=2500.0)]
    f = r24._flags(rows, len(rows) - 1)
    assert "RANGE_BREAKOUT" in f and "VOLUME_SURGE" in f, f
    # classic setups: windows come from the bar date, and a finished window is dropped
    ny = r24.NY
    now = datetime(2026, 10, 9, 21, 0, tzinfo=ny)                                          # Friday 9 PM
    r = {"mode": "PRE", "bar_date": "2026-10-09"}
    sc = r24.schedule_old(r, now, wk)
    assert sc["entry_from"] == datetime(2026, 10, 12, 4, 0, tzinfo=ny) and sc["exit_by"] == datetime(2026, 10, 12, 11, 0, tzinfo=ny), sc
    assert r24.schedule_old({"mode": "AFTER", "bar_date": "2026-10-09"}, now, wk) is None
    on = r24.schedule_old({"mode": "OVERNIGHT", "bar_date": "2026-10-09"}, now, wk)
    assert on["entry_from"] == now and on["exit_by"] == datetime(2026, 10, 12, 4, 0, tzinfo=ny), on
    assert r24.bucket(datetime(2026, 10, 12, 4, 0, tzinfo=ny)) == "PRE" and r24.bucket(datetime(2026, 10, 9, 21, 0, tzinfo=ny)) == "NIGHT"
    assert r24.fmt(datetime(2026, 10, 10, 9, 35, tzinfo=ny), datetime(2026, 10, 9, 21, 0, tzinfo=ny)) == "Tomorrow 9:35 AM"
    src = (ROOT / "autobot" / "engine.py").read_text()
    assert "def picks(self, upcoming=False)" in src and "def set_pick(self, sym, pick, day=None)" in src
    assert '"/api/radar24"' in (ROOT / "server.py").read_text() and "r24Card" in (ROOT / "web" / "dashboard.html").read_text()


@test("Reversal watch: a short that falls then bounces gets a cover alert, a profit-protect alert and a fading alert; alerts are capped")
def _():
    import tempfile
    from autobot.stockwatch import StockWatch
    w = StockWatch(tempfile.mktemp()); out = []
    w.add("X", "short", 35.18, 0.8, None, 35.18); w.w["X"]["qty"] = 1200
    for p in [35.0, 34.6, 34.2, 33.9, 33.78, 33.85, 33.95, 34.05, 34.12, 34.2, 34.1, 33.95]:
        w.tick("X", p, lambda t, b: out.append(t))
    assert any("bounced" in t for t in out) and any("protect" in t for t in out) and any("fading" in t for t in out), out
    n = len(out)
    for k in range(60):                                  # a choppy stock cannot flood the phone
        w.tick("X", 33.0 + (k % 2) * 1.0, lambda t, b: out.append(t))
    assert len(out) - n <= 8
    from autobot import review
    import pandas as pd, numpy as np
    assert review.review("ZZ", pd.DataFrame({"open": [1.0], "high": [1.0], "low": [1.0], "close": [1.0], "volume": [1]}, index=pd.DatetimeIndex(["2026-10-12 10:00"], tz="America/New_York")), review.NY and __import__("datetime").datetime.now(review.NY))["ok"] is False


@test("Open drive: finds a quiet pre-market that breaks out on a volume burst, builds a sane buy zone, and ignores quiet opens")
def _():
    import pandas as pd, numpy as np, datetime as dt, random
    from zoneinfo import ZoneInfo
    from autobot import opendrive as od
    NY=ZoneInfo("America/New_York"); rnd=random.Random(3)
    def day_bars(day, breakout, step, base=100.0):
        rows=[]; px=base
        for k in range(0,64):
            t=dt.datetime.combine(day,dt.time(4,0)).replace(tzinfo=NY)+dt.timedelta(minutes=15*k)
            reg=dt.time(9,30)<=t.time()<dt.time(16,0)
            c=px*(1+rnd.gauss(0,0.0015)); v=rnd.randint(2000,4000)
            if breakout and t.time()==dt.time(9,30): c=px*1.015; v=30000
            if breakout and t.time() in (dt.time(9,45),dt.time(10,0)): c=px*1.02; v=9000
            rows.append((t,px,max(px,c)*1.001,min(px,c)*0.999,c,v)); px=c
        return rows
    rows=[]; d0=dt.date(2026,8,3); n=0
    while n<30:
        d=d0+dt.timedelta(days=n)
        if d.weekday()<5: rows+=day_bars(d, n%3==0, 0)
        n+=1
    d15=pd.DataFrame(rows,columns=["t","open","high","low","close","volume"]).set_index("t")
    rec,base=od.history(d15); (lambda *a: None)("record",rec,"base",{k:round(v) for k,v in base.items()})
    assert rec["n"]>=4, rec
    # today: quiet premarket then spike
    today=dt.date(2026,9,14); r1=[]; px=100.0
    for m in range(0,330+4*60//1):
        pass
    t0=dt.datetime.combine(today,dt.time(4,0)).replace(tzinfo=NY); px=100.0
    for k in range(0,330):                      # 4:00..9:29
        px*=1+rnd.gauss(0,0.0003); r1.append((t0+dt.timedelta(minutes=k),px,px*1.0008,px*0.9992,px,300))
    for k in range(0,4):                        # 9:30..9:33 breakout
        o=px; px*=1.006; r1.append((t0+dt.timedelta(minutes=330+k),o,px*1.001,o*0.999,px,9000))
    d1=pd.DataFrame(r1,columns=["t","open","high","low","close","volume"]).set_index("t")
    now=dt.datetime.combine(today,dt.time(9,34)).replace(tzinfo=NY)
    c=od.detect("TST",d1,now,rec,base); (lambda *a: None)(c)
    assert c and c["rvol"]>=3 and c["zone"][0]<c["zone"][1] and c["stop"]<c["zone"][0] and c["tp1"]>c["zone"][1]
    quiet=d1[d1.index.time<dt.time(9,31)]
    assert od.detect("TST",quiet,now.replace(minute=31),rec,base) is None
    (lambda *a: None)("OK")


@test("Ollama AI provider: model list, chat through ai_post, ping, and provider switching (stub Ollama server)")
def _():
    import http.server, threading, json as _j, os as _o
    seen = {}
    class H(http.server.BaseHTTPRequestHandler):
        def log_message(self, *a): pass
        def do_GET(self):
            b = _j.dumps({"models": [{"name": "llama3.2:latest"}, {"name": "qwen2.5:7b"}]}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0)); seen["body"] = _j.loads(self.rfile.read(n)); seen["path"] = self.path
            b = _j.dumps({"choices": [{"message": {"content": "OK from ollama"}}], "model": seen["body"]["model"], "usage": {"prompt_tokens": 3, "completion_tokens": 4}}).encode()
            self.send_response(200); self.send_header("Content-Type", "application/json"); self.end_headers(); self.wfile.write(b)
    srv = http.server.HTTPServer(("127.0.0.1", 0), H); threading.Thread(target=srv.serve_forever, daemon=True).start()
    from autobot import analyst
    old = {k: _o.environ.get(k) for k in ("OLLAMA_BASE_URL", "OLLAMA_MODEL", "AI_PROVIDER", "ANTHROPIC_API_KEY", "OPENAI_API_KEY")}
    try:
        for k in ("OLLAMA_MODEL", "ANTHROPIC_API_KEY", "OPENAI_API_KEY"): _o.environ.pop(k, None)
        _o.environ["OLLAMA_BASE_URL"] = f"http://127.0.0.1:{srv.server_port}/v1"; _o.environ["AI_PROVIDER"] = "ollama"; analyst._MODEL_CACHE.clear()
        assert analyst.provider() == "ollama" and analyst.ai_key() and analyst.ai_name() == "Ollama"
        assert analyst.ollama_models() == ["llama3.2:latest", "qwen2.5:7b"]
        r = analyst.ai_ping()
        assert r["ok"] and r["model"] == "llama3.2:latest" and r["models"], r
        assert seen["path"] == "/v1/chat/completions" and seen["body"]["messages"][-1]["content"] == "Reply OK"
        resp = analyst.ai_post(20, {"model": "qwen2.5:7b", "max_tokens": 50, "system": "s", "messages": [{"role": "user", "content": "hi"}]})
        assert resp.json()["content"][0]["text"] == "OK from ollama" and seen["body"]["model"] == "qwen2.5:7b" and seen["body"]["messages"][0]["role"] == "system"
        _o.environ["ANTHROPIC_API_KEY"] = "sk-ant-x"; _o.environ["AI_PROVIDER"] = "anthropic"
        assert analyst.provider() == "anthropic"                      # a chosen cloud AI still wins
        _o.environ["AI_PROVIDER"] = "ollama"
        assert analyst.provider() == "ollama"
        _o.environ["OLLAMA_BASE_URL"] = "http://127.0.0.1:9"; analyst._MODEL_CACHE.clear()
        bad = analyst.ai_ping()
        assert not bad["ok"] and "Ollama" in bad["error"]
    finally:
        for k, v in old.items():
            (_o.environ.__setitem__(k, v) if v is not None else _o.environ.pop(k, None))
        analyst._MODEL_CACHE.clear(); srv.shutdown()


@test("v2.12 day drives: lunch buy + mirrored short detect, windows, replay")
def _():
    import pandas as pd, numpy as np, datetime as dt, random
    from zoneinfo import ZoneInfo
    from autobot import daydrive as dd
    NY=ZoneInfo("America/New_York"); rnd=random.Random(5)
    def day15(day, kind):
        rows=[]; px=100.0
        for k in range(0,64):
            t=dt.datetime.combine(day,dt.time(4,0)).replace(tzinfo=NY)+dt.timedelta(minutes=15*k)
            c=px*(1+rnd.gauss(0,0.0012)); v=rnd.randint(3000,5000)
            tt=t.time()
            if kind=="lunch" and tt==dt.time(13,15): c=px*1.012; v=20000
            if kind=="lunch" and tt in (dt.time(13,30),dt.time(13,45)): c=px*1.006; v=9000
            if kind=="close" and tt==dt.time(15,15): c=px*1.012; v=22000
            if kind=="close" and tt in (dt.time(15,30),dt.time(15,45)): c=px*1.004; v=9000
            rows.append((t,px,max(px,c)*1.0005,min(px,c)*0.9995,c,v)); px=c
        return rows
    rows=[]; d0=dt.date(2026,8,3); n=0
    while n<40:
        d=d0+dt.timedelta(days=n)
        if d.weekday()<5: rows+=day15(d, "lunch" if n%4==0 else "close" if n%4==1 else "none")
        n+=1
    d15=pd.DataFrame(rows,columns=["t","open","high","low","close","volume"]).set_index("t")
    recs,slots=dd.records_for(d15)
    # live lunch detect
    today=dt.date(2026,9,15); t0=dt.datetime.combine(today,dt.time(4,0)).replace(tzinfo=NY); px=100.0; r1=[]
    for k in range(0,13*60-4*60+14):               # 4:00..13:13
        t=t0+dt.timedelta(minutes=k); 
        reg=dt.time(9,30)<=t.time()
        px*=1+rnd.gauss(0,0.0003); r1.append((t,px,px*1.0005,px*0.9995,px,rnd.randint(150,300) if reg else 40))
    for k in range(0,8):                           # surge 13:14..13:21 up 1.3%
        t=t0+dt.timedelta(minutes=13*60-4*60+14+k); o=px; px*=1.0017; r1.append((t,o,px*1.0003,o*0.9997,px,2500))
    d1=pd.DataFrame(r1,columns=["t","open","high","low","close","volume"]).set_index("t")
    now=dt.datetime.combine(today,dt.time(13,22)).replace(tzinfo=NY)
    c=dd.detect_lunch("TST",d1,now,recs,slots,3.0,0.8); print(c and {k:c[k] for k in("side","name","price","level","zone","stop","tp1","rvol","score","n","hits")})
    assert c and c["side"]=="up" and c["stop"]<c["zone"][0]<c["zone"][1]<c["tp1"]
    # mirrored down
    r2=[(t,2*100-o,2*100-l,2*100-h,2*100-cl,v) for (t,o,h,l,cl,v) in r1]
    d2=pd.DataFrame(r2,columns=["t","open","high","low","close","volume"]).set_index("t")
    c2=dd.detect_lunch("TST",d2,now,recs,slots,3.0,0.8); print(c2 and (c2["side"],c2["zone"],c2["stop"],c2["tp1"]))
    assert c2 and c2["side"]=="down" and c2["tp1"]<c2["zone"][0]<c2["zone"][1]<c2["stop"]
    assert dd.window_for(now)=="lunch" and dd.window_for(now.replace(hour=15,minute=40))=="close" and dd.window_for(now.replace(hour=22))=="overnight" and dd.window_for(now.replace(hour=11))==""
    
    rp = dd.replay(d15, "lunch")
    assert rp["n"] >= 3 and 0 <= rp["win_rate"] <= 100


@test("v2.12 autopilot rules, log-only default, 4-losers pause")
def _():
    import tempfile, pathlib
    from autobot.autopilot import Autopilot, DEFAULTS
    d = pathlib.Path(tempfile.mkdtemp())
    a = Autopilot(d / "c.json", d / "l.json")
    assert a.cfg["on"] is False and a.cfg["dry"] is True and a.cfg["shorts"] is False and "daily" not in " ".join(a.cfg)
    card = {"symbol": "ZZZ", "window": "open", "side": "up", "score": 80, "has_record": True, "n": 8, "hit_rate": 70}
    ctx = {"now_min": 600, "taken_n": 0, "open_n": 0, "spy_move": 0.2, "theme_open": {}, "held": set(), "shorts_ok": (True, "")}
    assert a.check(card, ctx)[0] is False                     # master switch off
    a.set_cfg({"on": True})
    assert a.check(card, ctx)[0] is True
    assert not a.check(dict(card, score=60), ctx)[0] and not a.check(dict(card, hit_rate=50), ctx)[0] and not a.check(dict(card, n=3), ctx)[0]
    assert not a.check(dict(card, side="down"), ctx)[0]       # shorts off
    assert not a.check(card, dict(ctx, now_min=16 * 60))[0]   # after last entry
    assert not a.check(card, dict(ctx, taken_n=3))[0] and not a.check(card, dict(ctx, open_n=2))[0]
    assert not a.check(card, dict(ctx, held={"ZZZ"}))[0]
    assert not a.check(card, dict(ctx, spy_move=-2.0))[0]
    assert not a.check(dict(card, window="overnight"), ctx)[0]  # overnight stays manual by default
    a.set_cfg({"min_score": 1, "max_day": 999, "spy_stop": 99})
    assert a.cfg["min_score"] >= 40 and a.cfg["max_day"] <= 20     # limits are clamped
    for _ in range(3):
        assert a.note_result("open", -10) is False
    assert a.note_result("open", -10) is True and not a.check(card, ctx)[0]
    a.set_cfg({"win": {"open": True}})
    assert a.check(card, ctx)[0]                              # switching the window on resumes it
    b = Autopilot(d / "c.json", d / "l.json"); assert b.cfg["on"] is True   # persists



@test("v2.14 peak learner picks the level that banks most; fallback; engine uses it; trade note enables re-entry")
def _():
    import tempfile, os
    from autobot import peaklearn
    f = os.path.join(tempfile.mkdtemp(), "pk.json")
    assert peaklearn.suggest(f, "CORD", "REGULAR") is None             # nothing learned yet -> fixed %
    for i in range(10):                                               # trades peak ~0.5% then fade to -0.2%
        peaklearn.record(f, "CORD", "REGULAR", 0.5 + (i % 3) * 0.02, -0.2)
    sg = peaklearn.suggest(f, "cord", "REGULAR")
    assert sg and 0.4 <= sg["pct"] <= 0.52 and sg["gain_avg"] > sg["now_avg"] and sg["n"] == 10, sg
    assert peaklearn.suggest(f, "SPY", "REGULAR") is None             # other stock: too few trips
    # engine: the learned level replaces the fixed one, and never lowers a wide-spread trade's own level
    import autobot.engine as en
    en.PEAK_FILE = type(en.PEAK_FILE)(f)
    from autobot.config import Settings
    class T: symbol = "CORD"; entry = 100.0; dir = 1; session = "REGULAR"; hv_pct = 0.0; peak_pct = 0.0; learn_pct = 0.0; qty = 10
    class E:
        s = Settings(); _slip_pct = lambda self: 0.0
        _learned_pct = lambda self: None
    e = E(); e.s.pct_harvest = True; e.s.harvest_learn = True
    t = T()
    pc = en.Engine._take_pct(e, t, 100.3)
    assert abs(pc - sg["pct"]) < 1e-9 and t.learn_pct == pc and t.peak_pct > 0.29
    e.s.harvest_learn = False
    assert en.Engine._take_pct(e, T(), None) == e.s.pct_harvest_pct
    t2 = T(); t2.hv_pct = 1.2; e.s.harvest_learn = True
    assert en.Engine._take_pct(e, t2, None) == 1.2


@test("v2.14 take-target: fires on exit P&L, bot trade closes with the harvest note, your trade is not re-entered")
def _():
    import server
    calls = []
    class Pos(dict): pass
    class B:
        def positions(self): return {"CORD": {"qty": 10, "avg_entry": 100.0, "price": 101.0, "upl": 10.0},
                                     "ZZZ": {"qty": 5, "avg_entry": 10.0, "price": 11.0, "upl": 5.0}}
    class T: pass
    class E:
        broker = B(); trades = {"CORD": T()}
        def event(self, *a, **k): pass
        def alert(self, *a, **k): pass
        def _slip_pct(self): return 0.0
    server.engine = E()
    server._session_name = lambda e: "REGULAR"
    server._quote = lambda e, s, ss: (100.7, 100.9) if s == "CORD" else (10.8, 10.9)
    server._close_now = lambda e, sym, pct=100, urgent=True, note="manual close": calls.append((sym, note))
    server._TK["targets"] = {"CORD": {"usd": 5.0}, "ZZZ": {"usd": 3.0}}
    server._TK["seen"] = {}
    server._tk_tick()
    assert ("CORD", "harvest") in calls and ("ZZZ", "take-target") in calls, calls
    assert "CORD" not in server._TK["targets"] and "ZZZ" not in server._TK["targets"]
    server._TK["targets"] = {"CORD": {"usd": 50.0}}
    calls.clear(); server._tk_tick()
    assert not calls and server._TK["targets"]["CORD"]["trace"]       # exit P&L (+7) below the target: keeps tracing


@test("v2.15 dashboard layout: cards never nest, merged cards keep their ids, controls grouped, broker.bars guards a future start")
def _():
    import re
    from html.parser import HTMLParser
    html = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "web", "dashboard.html"), encoding="utf-8").read()
    h = re.sub(r"<script.*?</script>", "<script></script>", html, flags=re.S)
    h = re.sub(r"<style.*?</style>", "", h, flags=re.S)
    class P(HTMLParser):
        def __init__(s): super().__init__(); s.st = []; s.bad = []; s.ids = set()
        def handle_starttag(s, t, a):
            d = dict(a)
            if d.get("id"): s.ids.add(d["id"])
            if t in ("div", "details"):
                if "data-v" in d and "card" in (d.get("class") or "") and any(x[1] for x in s.st):
                    s.bad.append(d.get("id") or d.get("class"))
                s.st.append((t, "data-v" in d))
        def handle_endtag(s, t):
            if t in ("div", "details") and s.st: s.st.pop()
    p = P(); p.feed(h[h.index("<body"):])
    assert not p.bad and not p.st, (p.bad, len(p.st))
    for i in ("sessionsCard", "autoCard", "sessBar", "asCard", "sessCard", "preCard", "prepCard", "candCard", "reviewCard", "orderCard", "padCard",
              "ticket", "statsCard", "scoreCard", "tuneCard", "cnCard", "ctlCard", "ctlBody", "chartCard", "ptCard", "posCard", "openCard", "actCard", "whyCard", "lossCard",
              "pctHv", "reEnt", "pctLearn", "short245", "autoTune", "keepOn", "feed"):
        assert i in p.ids, i
    assert html.count('class="cgrp"') >= 6 and "function mgTab" in html and "function ctlToggle" in html
    src = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "autobot", "broker.py")).read()
    assert "if start > now" in src


@test("v2.16 automatic profit-taking on your own trades: arms after steady profit, honors Stop, auto jobs never stop out at a loss, learned level banks")
def _():
    import time as _t
    import server
    from types import SimpleNamespace as NS
    h, e, st, calls = _fake_harvest()
    # auto job: down 3 A -> a normal job would protective-stop; an auto job holds
    h.learn_fn = None
    h.arm("ZZZ", "buy", 10, auto=True)
    j = h.jobs["ZZZ"]; now = _t.time()
    h.step(e, j, e.broker.positions(), "REGULAR", now); assert j["phase"] == "holding"
    st["bid"], st["ask"] = 98.40, 98.42
    h.step(e, j, e.broker.positions(), "REGULAR", now + 5); h.step(e, j, e.broker.positions(), "REGULAR", now + 40)
    assert not calls and j["phase"] == "holding", (calls, j)
    # learned level: +0.2% of entry (=0.2) is below 0.5 A (0.25) but the learned level is 0.15%
    h2, e2, st2, calls2 = _fake_harvest()
    h2.learn_fn = lambda *a: 0.15
    h2.arm("ZZZ", "buy", 10, auto=True); j2 = h2.jobs["ZZZ"]
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", now)
    st2["bid"], st2["ask"] = 100.20, 100.21
    h2.step(e2, j2, e2.broker.positions(), "REGULAR", now + 5)
    assert calls2 and calls2[0][0] == "close", calls2
    # server side auto-watch: green for 30 s arms it, a Stop is respected, options/fractional are left alone
    armed = []
    class Hv:
        jobs = {}
        def arm(self, *a, **k): armed.append((a, k))
    server.harvester, old = Hv(), server.harvester
    try:
        ee = NS(trades={}, risk=NS(halted=False), manual_syms={}, broker=NS(now=lambda: __import__("datetime").datetime.now()), event=lambda *a, **k: None)
        server.settings.auto_harvest_manual = True
        pos = {"qty": 10, "avg_entry": 100.0}
        sn = {}
        server._ah_watch(ee, "AAPL", pos, sn, 0.3, "REGULAR", 1000.0); assert not armed
        server._ah_watch(ee, "AAPL", pos, sn, 0.3, "REGULAR", 1031.0); assert len(armed) == 1 and armed[0][1].get("auto") is True
        server._ah_watch(ee, "AAPL", pos, {"green_since": 0}, 0.05, "REGULAR", 2000.0)       # fell below green: no arm
        server._AH_SKIP.add("MSFT"); server._ah_watch(ee, "MSFT", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "AAPL250117C00200000", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "NVDA", {"qty": 2.5, "avg_entry": 1.0}, {"green_since": 0}, 0.5, "REGULAR", 2000.0)
        server._ah_watch(ee, "TSLA", pos, {"green_since": 0}, 0.5, "OVERNIGHT", 2000.0)
        assert len(armed) == 1, armed
        server.settings.auto_harvest_manual = False
        server._ah_watch(ee, "AMD", pos, {"green_since": 0}, 0.5, "REGULAR", 2000.0); assert len(armed) == 1
    finally:
        server.harvester = old; server.settings.auto_harvest_manual = True


@test("v2.15 sekex_done: Setup.sh and latest.json renamed to .old once a version is installed AND published (admin phone), or just installed (normal phone)")
def _():
    root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    def run(home, what, ver):
        env = dict(os.environ, HOME=home)
        return subprocess.run([sys.executable, os.path.join(root, "bin", "sekex_done.py"), what, ver], env=env, capture_output=True, text=True, timeout=30).stdout
    def mk(home, admin):
        dl = os.path.join(home, "storage", "downloads"); os.makedirs(dl); os.makedirs(os.path.join(home, ".sekexbot"))
        open(os.path.join(dl, "SekexBot_Setup.sh"), "w").write("#!/bin/sh\n# SekexBot one-file installer.  Version 2.15.0\n")
        open(os.path.join(dl, "SekexBot_Setup(1).sh"), "w").write("#!/bin/sh\n# SekexBot one-file installer.  Version 2.16.0\n")
        open(os.path.join(dl, "latest.json"), "w").write(json.dumps({"version": "2.15.0"}))
        if admin: open(os.path.join(home, ".sekexbot", "github.json"), "w").write(json.dumps({"token": "x"}))
        return dl
    h = tempfile.mkdtemp(); dl = mk(h, True)
    run(h, "updated", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json")) and os.path.exists(os.path.join(dl, "SekexBot_Setup.sh"))     # admin phone: not published yet
    out = run(h, "published", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json.old")) and os.path.exists(os.path.join(dl, "SekexBot_Setup.sh.old")), out
    assert os.path.exists(os.path.join(dl, "SekexBot_Setup(1).sh")), "a newer version's installer must be left alone"
    h = tempfile.mkdtemp(); dl = mk(h, False)
    run(h, "updated", "2.15.0")
    assert os.path.exists(os.path.join(dl, "latest.json.old")) and not os.path.exists(os.path.join(dl, "latest.json"))


@test("v2.14.3 jump card builds with the stock's record (regression: price was passed as the record)")
def _():
    import server
    sg = {"kind": "in", "side": "up", "name": "Pullback retest", "why": "x", "t": "10:00", "price": 100.0, "zone": [99.9, 100.1], "stop": 99.5, "tp1": 101, "tp2": 102, "atr": 0.3}
    c = server._jp_card(None, sg, "AAA", {"up": {"n": 10, "hit": 7, "fail": 3}, "down": {"n": 0, "hit": 0, "fail": 0}}, 100.2)
    assert c["n"] == 10 and c["hits"] == 7 and c["has_record"] and c["price"] == 100.2
    c = server._jp_card(None, sg, "AAA", None, 100.2)
    assert not c["has_record"]


@test("v2.13 jump signals: pullback retest buy/short, don't chase, exits, record")
def _():
    import pandas as pd, numpy as np, datetime as dt
    from zoneinfo import ZoneInfo
    from autobot import jump
    NY = ZoneInfo("America/New_York"); rng = np.random.default_rng(3)
    rows = []; d0 = dt.date(2026, 8, 3); n = 0
    while n < 45:
        d = d0 + dt.timedelta(days=n); n += 1
        if d.weekday() >= 5:
            continue
        px = 100 + rng.normal(0, 2); t0 = dt.datetime.combine(d, dt.time(9, 30)).replace(tzinfo=NY)
        for k in range(78):
            c = px * (1 + 0.0006 * np.sin(k / 9) + rng.normal(0, 0.0012)); v = int(abs(rng.normal(5000, 1500)) * (1 + (3 if rng.random() < 0.04 else 0)))
            rows.append((t0 + dt.timedelta(minutes=5 * k), px, max(px, c) * 1.0008, min(px, c) * 0.9992, c, v)); px = c
    d5 = pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
    sg = jump.scan(d5)
    ins = [s for s in sg if s["kind"] == "in"]
    assert any(s["side"] == "up" for s in ins) and any(s["side"] == "down" for s in ins)
    for s in ins:
        if s["side"] == "up":
            assert s["stop"] < s["zone"][0] <= s["zone"][1] < s["tp1"] < s["tp2"]
        else:
            assert s["stop"] > s["zone"][1] >= s["zone"][0] > s["tp1"] > s["tp2"]
    assert any(s["kind"] == "out" for s in sg)
    rec = jump.record(d5)
    for sd in ("up", "down"):
        r = rec[sd]; assert r["n"] == r["hit"] + r["fail"] and r["n"] > 5
    # a vertical burst bar is flagged as "don't chase"
    d6 = d5.iloc[:60].copy(); last = d6.index[-1]; px = float(d6["close"].iloc[-1])
    d6.loc[last, ["high", "close", "volume"]] = [px * 1.03, px * 1.028, 60000]
    assert any(s["kind"] == "chase" and s["i"] == 59 for s in jump.scan(d6))
    assert "jump" in __import__("autobot.alerts", fromlist=["KINDS"]).KINDS



if __name__ == "__main__":
    only_audit = len(sys.argv) > 1 and sys.argv[1] == "audit"
    if only_audit:
        out = {}
        for arg in sys.argv[2:]:
            name, dbp, lim = arg.split(":")
            out[name] = audit_journal(dbp, float(lim), 10000.0, name)
        print(json.dumps(out, indent=1))
        sys.exit(0)
    w = max(len(n) for n, *_ in RESULTS)
    fails = 0
    for n, st, msg, dt in RESULTS:
        print(f"{st:5s} {n:{w}s} ({dt:5.1f}s)")
        if st != "PASS":
            fails += 1
            print("      " + msg.replace("\n", "\n      "))
    print(f"\n{len(RESULTS) - fails}/{len(RESULTS)} passed")
    sys.exit(1 if fails else 0)
