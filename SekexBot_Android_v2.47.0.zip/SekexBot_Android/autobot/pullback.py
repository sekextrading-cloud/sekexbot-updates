"""v2.43: Pullback Buyer (end-of-day swing, PAPER first).

The one setup with a steady record in our 10-year test (daily candles, Nasdaq-100 + watchlist + QQQ/SPY):
  BUY at the close (3:55 PM ET) when the stock is ABOVE its 200-day average (a strong stock) and its 2-day RSI is under 10
  (it just dipped hard for 2-3 days).
  SELL at the first close (3:55 PM) above its 5-day average (the bounce), or after 5 trading days no matter what.
Test: 6,502 trades, 67% winners, +0.53% average, about 4 days held, positive in 8 of 10 years (2018 and 2022 lost).
It uses today's Nasdaq-100 members (survivorship), so real results will be lower. It is not a morning trade, and at
$10k a pick it is tens of dollars a day, not hundreds. Holds overnight, so a bad gap can hurt.
This module has the rules; server.py fetches the candles and sends the orders."""
import json
import threading

from .config import DATA_DIR

FILE = DATA_DIR / "pullback.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": False, "live": False, "per_pick": 10000, "max_pos": 3}
OK = {"per_pick": (5000, 10000, 25000), "max_pos": (1, 2, 3, 4, 5, 6)}
RSI_BUY = 10
RSI_WATCH = 25
MAX_DAYS = 5
RUN_FROM, RUN_TO = 950, 958            # 3:50 - 3:58 PM ET
BACKTEST = {"trades": 6502, "win_pct": 67, "avg_pct": 0.53, "years_up": "8 of 10", "hold": "about 4 days"}

UNIVERSE = ("QQQ SPY AAPL MSFT NVDA AMZN META GOOGL GOOG AVGO TSLA COST NFLX AMD PEP ADBE CSCO TMUS QCOM INTU TXN AMAT ISRG "
            "CMCSA AMGN HON BKNG VRTX PANW ADP SBUX GILD MU ADI LRCX MELI REGN INTC KLAC MDLZ SNPS CDNS PYPL CRWD MAR CTAS "
            "ORLY ASML MRVL CSX ABNB FTNT NXPI PCAR WDAY ROP CPRT MNST CHTR PAYX AEP ROST ODFL KDP FAST DDOG EA CEG VRSK "
            "EXC KHC XEL CTSH GEHC BKR IDXX LULU TTD ON ZS CSGP DXCM ANSS TEAM CDW BIIB MDB GFS WBD ILMN DASH PLTR APP "
            "ARM AZN MSTR SHOP AXON").split()


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "pos": [], "watch": [], "ran": "", "log": [], "history": [], "status": ""}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    for k in ("on", "live"):
        c[k] = bool(c.get(k))
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in ("on", "live"):
            d["cfg"][k] = bool(v)
        elif k in OK and int(v) in OK[k]:
            d["cfg"][k] = int(v)
    save(d)
    return load()


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%a %-I:%M %p"), "msg": msg})
    del d["log"][60:]


def rsi2(closes):
    """2-day RSI (Wilder) of a list of closes, oldest first."""
    if len(closes) < 4:
        return None
    up = dn = 0.0
    a = 1 / 2
    first = True
    for i in range(1, len(closes)):
        ch = closes[i] - closes[i - 1]
        u, w = max(ch, 0.0), max(-ch, 0.0)
        if first:
            up, dn, first = u, w, False
        else:
            up, dn = up + a * (u - up), dn + a * (w - dn)
    if dn == 0:
        return 100.0
    return 100 - 100 / (1 + up / dn)


def read(closes):
    """closes: daily closes, oldest first, the LAST one being today's price now. Returns the numbers the rules use."""
    if len(closes) < 201:
        return None
    sma200 = sum(closes[-200:]) / 200
    sma5 = sum(closes[-5:]) / 5
    r = rsi2(closes[-30:])
    down = 0
    for i in range(len(closes) - 1, 0, -1):
        if closes[i] < closes[i - 1]:
            down += 1
        else:
            break
    px = closes[-1]
    return {"price": round(px, 4), "sma200": round(sma200, 4), "sma5": round(sma5, 4), "rsi2": round(r, 1) if r is not None else None,
            "above200": px > sma200, "down_days": down}


def decide(reads, held, cfg, today):
    """reads: {sym: read()}; held: [{'symbol','bought','days'}]. Returns (sells [(sym, why)], buys [sym], watch [dict]).
    A sale happens at the first close above the 5-day average, or after MAX_DAYS trading days."""
    sells = []
    for h in held:
        r = reads.get(h["symbol"])
        if r and r["price"] > r["sma5"]:
            sells.append((h["symbol"], f"closed above its 5-day average (${r['sma5']:.2f}): the bounce"))
        elif int(h.get("days") or 0) >= MAX_DAYS:
            sells.append((h["symbol"], f"{MAX_DAYS} trading days held: time exit"))
    hs = {h["symbol"] for h in held}
    room = max(0, int(cfg["max_pos"]) - (len(held) - len(sells)))
    cands = sorted(((s, r) for s, r in reads.items() if r and r["above200"] and r["rsi2"] is not None and r["rsi2"] < RSI_BUY and s not in hs),
                   key=lambda x: x[1]["rsi2"])
    buys = [s for s, _ in cands[:room]]
    watch = sorted(({"symbol": s, **r} for s, r in reads.items() if r and r["above200"] and r["rsi2"] is not None
                    and r["rsi2"] < RSI_WATCH and s not in hs and s not in buys), key=lambda x: x["rsi2"])[:8]
    return sells, buys, watch


def size(cfg, ask, bp):
    if not ask or ask <= 0:
        return 0
    return max(0, int(min(float(cfg["per_pick"]), 0.3 * float(bp or 0)) // ask))
