"""v2.46: Armed trades - one tap on the chart arms a trade; the 5-minute candle CLOSE fires it.

"BUY if a candle closes above 633.99" means: nothing is sent now. Every 5 minutes, when a candle closes, the app checks the
close. A close beyond the line sends the order (a limit a few cents through the line, with the stop at the get-out line and the
target at the last top / bottom, as a bracket in regular hours). A wick through the line does not count. If a candle closes
on the wrong side of the stop line first, the setup is off and the arm is cancelled. Arms expire at the end of the day.
Your own trades: the guardrails still apply at fire time (short before 10:30, breather). PAPER arms and fires; LIVE needs the PIN.
Thin sessions (pre-market, after-hours): an arm made then waits for 9:30 unless you chose "trade now in this session"."""
import json
import threading
import uuid
from datetime import datetime

from .config import DATA_DIR

FILE = DATA_DIR / "armed.json"
LOCK = threading.Lock()
THROUGH = 0.0006          # the limit sits this far through the line (0.06%), so it fills like a market order but not at any price
MAX_CHASE = 0.004         # if the close is more than 0.4% past the line, don't chase: cancel the arm and say so


def _blank():
    return {"arms": [], "fired": [], "day": ""}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def new_day(d, today):
    if d.get("day") != str(today):
        for a in d.get("arms", []):
            a["state"] = "expired"
            a["why"] = "day ended"
        d["fired"] = ([a for a in d.get("arms", []) if a.get("state") != "armed"] + d.get("fired", []))[:40]
        d.update(day=str(today), arms=[])
    return d


def arm(d, now, sym, side, line, stop, target, qty, wait_regular=True, harvest=False, note=""):
    """Add an arm. side: 'buy' | 'sell' (sell = short, or sell what you hold). line: fires on a close beyond it."""
    for a in d["arms"]:
        if a["symbol"] == sym and a["state"] == "armed":
            a["state"] = "replaced"
    a = {"id": uuid.uuid4().hex[:10], "symbol": sym, "side": side, "line": round(float(line), 4), "stop": round(float(stop), 4) if stop else None,
         "target": round(float(target), 4) if target else None, "qty": int(qty), "wait_regular": bool(wait_regular), "harvest": bool(harvest),
         "state": "armed", "at": now.isoformat(), "t": now.strftime("%-I:%M %p"), "note": note, "why": "", "checked": ""}
    d["arms"].append(a)
    return a


def cancel(d, arm_id, why="you cancelled it"):
    for a in d["arms"]:
        if a["id"] == arm_id and a["state"] == "armed":
            a["state"] = "cancelled"
            a["why"] = why
            return a
    return None


def check(a, close, bar_t, session):
    """Decide for one closed candle. Returns ('fire', limit) | ('off', why) | ('wait', why) | ('hold', '')."""
    if a["state"] != "armed":
        return "hold", ""
    if a.get("checked") == bar_t:
        return "hold", ""
    a["checked"] = bar_t
    d = 1 if a["side"] == "buy" else -1
    if a.get("stop") and (close - a["stop"]) * d < 0:
        return "off", f"a candle closed {'under' if d > 0 else 'over'} the stop line {a['stop']:.2f} first; setup off"
    if (close - a["line"]) * d <= 0:
        return "hold", ""
    if a.get("wait_regular") and session != "REGULAR":
        return "wait", f"closed {'above' if d > 0 else 'below'} {a['line']:.2f} in {session.lower()} hours; waiting for 9:30 (change it on the card to trade now)"
    if abs(close - a["line"]) / a["line"] > MAX_CHASE:
        return "off", f"the candle closed {abs(close - a['line']) / a['line'] * 100:.1f}% past the line; too far to chase"
    return "fire", round(close * (1 + d * THROUGH), 2 if close >= 1 else 4)


def active(d, sym=None):
    return [a for a in d.get("arms", []) if a["state"] == "armed" and (sym is None or a["symbol"] == sym)]


def stamp(now=None):
    return (now or datetime.now()).isoformat()
