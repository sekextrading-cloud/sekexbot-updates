"""v2.43: Guardrails for YOUR manual trades, from your own journal (848 trades, Sep 28 - Oct 30 2026).

What the journal showed: shorts opened in the first hour (9:30-10:30) lost the most, very quick exits (under 2 minutes)
were mostly noise, and losses tended to come in streaks. So the app asks before:
  * opening a SHORT between 9:30 and 10:30 AM ET,
  * closing a position you opened less than 2 minutes ago (wait for the 5-min close or your exit line),
  * opening a new trade within 15 minutes of a 3rd loss in a row.
These are warnings only: you can always tap "Trade anyway". Nothing here touches the bot's own trades.
It counts warnings, how often you stopped, and what the trades you went ahead with made, so you can see if they help."""
import json
import threading
from datetime import datetime, timedelta

from .config import DATA_DIR

FILE = DATA_DIR / "guardrails.json"
LOCK = threading.Lock()
DEFAULT_CFG = {"on": True, "short_open": True, "quick_exit": True, "cooldown": True}
SHORT_FROM, SHORT_TO = 570, 630          # 9:30 - 10:30 AM ET
MIN_HOLD = 120                           # seconds
STREAK = 3
COOL_MIN = 15

TXT = {"short_open": "⚠️ Short before 10:30?\n\nIn your journal, shorts opened 9:30-10:30 AM lost the most. "
                     "The opening hour usually pushes UP on busy stocks.",
       "quick_exit": "⚠️ Out after under 2 minutes?\n\nIn your journal, very quick exits were mostly noise. "
                     "Wait for the 5-minute candle to close, or for price to cross your exit line.",
       "cooldown": "⚠️ 3 losses in a row\n\nTake a 15-minute breather before the next trade (until {until}). "
                   "Losses in your journal came in streaks."}


def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "warn": [], "opens": {}, "warned_open": {}, "streak": 0, "cool_until": "",
            "ahead": [], "history": []}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update({k: bool(v) for k, v in (b.get("cfg") or {}).items() if k in DEFAULT_CFG})
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if k in DEFAULT_CFG and v is not None:
            d["cfg"][k] = bool(v)
    save(d)
    return d


def _day(d, now):
    if d.get("day") != str(now.date()):
        if d.get("day") and d.get("warn"):
            d["history"] = ([{"day": d["day"], "warn": len(d["warn"]), "stopped": sum(1 for w in d["warn"] if not w.get("went"))}]
                            + d.get("history", []))[:30]
        d.update(day=str(now.date()), warn=[], streak=0, cool_until="")
    return d


def check_order(now, sym, opening, short):
    """Why to ask before this order ('' = fine). opening: it opens or adds to a position; short: it opens a short."""
    d = _day(load(), now)
    c = d["cfg"]
    if not c["on"] or not opening:
        return "", ""
    if c["cooldown"] and d.get("cool_until"):
        try:
            until = datetime.fromisoformat(d["cool_until"])
            if now < until:
                return "cooldown", TXT["cooldown"].format(until=until.strftime("%-I:%M %p"))
        except Exception:
            pass
    m = now.hour * 60 + now.minute
    if c["short_open"] and short and now.weekday() < 5 and SHORT_FROM <= m < SHORT_TO:
        return "short_open", TXT["short_open"]
    return "", ""


def check_close(now, sym, pct=100):
    d = _day(load(), now)
    c = d["cfg"]
    if not c["on"] or not c["quick_exit"] or pct < 100:
        return "", ""
    t = (d.get("opens") or {}).get(sym)
    if not t:
        return "", ""
    try:
        age = (now - datetime.fromisoformat(t)).total_seconds()
    except Exception:
        return "", ""
    if 0 <= age < MIN_HOLD:
        return "quick_exit", TXT["quick_exit"] + f"\n\nYou opened {sym} {int(age)} seconds ago."
    return "", ""


def warned(now, sym, kind, went):
    """Log a warning: went=False when it was shown (and you stopped), True when you tapped Trade anyway."""
    d = _day(load(), now)
    if went:
        for w in reversed(d["warn"]):
            if w["sym"] == sym and w["kind"] == kind and not w.get("went"):
                w["went"] = True
                break
        else:
            d["warn"].append({"t": now.strftime("%-I:%M %p"), "sym": sym, "kind": kind, "went": True})
        if kind != "quick_exit":
            d.setdefault("warned_open", {})[sym] = kind
    else:
        d["warn"].append({"t": now.strftime("%-I:%M %p"), "sym": sym, "kind": kind, "went": False})
    del d["warn"][:-80]
    save(d)


def opened(now, sym):
    d = _day(load(), now)
    d.setdefault("opens", {})[sym] = now.isoformat()
    if len(d["opens"]) > 60:
        d["opens"] = dict(sorted(d["opens"].items(), key=lambda x: x[1])[-60:])
    save(d)


def closed(now, sym, pnl):
    """A full manual close: updates the loss streak (3 in a row -> 15-minute cool-down) and the 'went ahead' results."""
    d = _day(load(), now)
    d.get("opens", {}).pop(sym, None)
    if pnl is not None:
        if pnl < 0:
            d["streak"] = int(d.get("streak") or 0) + 1
            if d["streak"] >= STREAK and d["cfg"]["cooldown"]:
                d["cool_until"] = (now + timedelta(minutes=COOL_MIN)).isoformat()
                d["streak"] = 0
        elif pnl > 0:
            d["streak"] = 0
        k = d.get("warned_open", {}).pop(sym, None)
        if k:
            d.setdefault("ahead", []).insert(0, {"day": str(now.date()), "sym": sym, "kind": k, "pnl": round(float(pnl), 2)})
            del d["ahead"][100:]
    save(d)
    return d


def summary(now):
    d = _day(load(), now)
    w = d["warn"]
    ah = d.get("ahead", [])
    cool = ""
    try:
        if d.get("cool_until") and now < datetime.fromisoformat(d["cool_until"]):
            cool = datetime.fromisoformat(d["cool_until"]).strftime("%-I:%M %p")
    except Exception:
        pass
    return {"cfg": d["cfg"], "today": {"warn": len(w), "stopped": sum(1 for x in w if not x.get("went")),
                                       "went": sum(1 for x in w if x.get("went"))},
            "log": list(reversed(w))[:15], "streak": d.get("streak", 0), "cool_until": cool,
            "ahead": {"n": len(ah), "pnl": round(sum(x["pnl"] for x in ah), 2), "win": sum(1 for x in ah if x["pnl"] > 0)},
            "history": d.get("history", [])[:10]}
