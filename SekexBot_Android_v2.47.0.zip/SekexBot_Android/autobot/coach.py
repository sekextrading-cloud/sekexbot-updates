"""v2.42: Trade coach (Learn tab). Replays a real day candle by candle and explains it in plain words (spoken by the
dashboard), using the same rules as the simple chart and the entry alerts (autobot/structure.py):

  * swing highs / lows become known 2 candles after they happen -> HH / HL / LH / LL
  * DOWNTREND starts when a 5-min candle closes below the last swing low after a lower high (ENTRY short); it ends when a
    candle closes above the last swing high (the EXIT LINE). UPTREND is the mirror.
  * REVERSAL WINDOW: in an uptrend a LOWER HIGH forms (buyers are weakening) - a short entry is now possible if the last
    higher low breaks. In a downtrend a HIGHER LOW forms - the mirror. It closes when the reversal is confirmed (entry) or
    the old trend resumes (a new high / low).
  * GET READY: price is within about one normal 5-min candle of the entry level.

Every step also carries the "right answer" for practice (BUY / SHORT / EXIT / WAIT), judged by the rules, and the result
the next candles gave. Practice only: nothing here places orders."""
import math
from datetime import datetime, timedelta

from .structure import K, swings

LESSONS = [
    {"id": "trend", "title": "1 · Read the trend",
     "text": "Look at the swing points. Higher highs and higher lows mean an uptrend: buy the dips, don't short them. Lower highs and lower lows mean a downtrend: sell the bounces, don't buy them. Mixed means chop: stay out or scalp small."},
    {"id": "entry", "title": "2 · The entry",
     "text": "In a downtrend, wait for a bounce that makes a lower high. The entry is a 5-minute candle CLOSING below the last swing low, not just poking under it. In an uptrend it is the mirror: a close above the last swing high after a higher low."},
    {"id": "exit", "title": "3 · The exit line",
     "text": "Your exit line is the last lower high for a short, or the last higher low for a long. Stay in while price stays on the right side of it, and move it each time a new swing forms. A 5-minute close past it means get out. That line is what keeps you in a big move and gets you out fast when it turns."},
    {"id": "reversal", "title": "4 · The reversal window",
     "text": "A trend usually warns you before it turns. In an uptrend, the first LOWER high opens the reversal window: buyers are getting weaker. The reversal is confirmed only when a candle closes below the last higher low. Until then, don't jump early; get ready."},
    {"id": "opt1", "title": "5 · Options: call or put",
     "text": "Same chart, same entry. An uptrend entry means you buy a CALL: it gains when the stock goes up. A downtrend entry means you buy a PUT: it gains when the stock goes down. One contract controls 100 shares, and the most you can lose is what you paid for it."},
    {"id": "opt2", "title": "6 · Options: strike and expiry",
     "text": "For a day trade, pick the strike nearest the price (at the money) and an expiry a few days out, so time decay doesn't eat you before the move comes. Check the bid-ask spread: if it is more than about 5% of the price, the option costs too much to trade quickly."},
    {"id": "opt3", "title": "7 · Options: getting out",
     "text": "Use the stock's exit line, not the option's price, to decide. When the stock closes past the exit line, sell the option. Options lose value every day you hold them, so don't hold a losing one hoping it comes back; and don't hold one into expiry by accident."},
    {"id": "opt4", "title": "8 · Options: the whole trade, start to finish",
     "text": "1 Read the trend. 2 Wait for the reversal window or the bounce. 3 Get ready when price is near the entry level. 4 The candle closes past it: buy the call (up) or the put (down), at the money, a few days out. 5 Move your exit line with each new swing. 6 Price closes past the exit line, or you reach your goal: sell the option. Practice it here first; real options can lose the whole premium."},
]


def _ncdf(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def _bs(S, K, T, v, kind):
    if T <= 0 or v <= 0:
        return max(S - K, 0.0) if kind == "call" else max(K - S, 0.0)
    d1 = (math.log(S / K) + 0.5 * v * v * T) / (v * math.sqrt(T))
    d2 = d1 - v * math.sqrt(T)
    return S * _ncdf(d1) - K * _ncdf(d2) if kind == "call" else K * _ncdf(-d2) - S * _ncdf(-d1)


def _fmt(x):
    return f"{x:.2f}"


def build(d5, day):
    """d5: closed 5-minute candles (a day or two before `day` for warm-up, then `day`), New-York index.
    Returns {'bars': [...], 'steps': [...], 'first': index of the first candle of `day`}."""
    n = len(d5)
    bars = [{"t": ts.strftime("%H:%M"), "d": str(ts.date()), "o": round(float(r.open), 4), "h": round(float(r.high), 4),
             "l": round(float(r.low), 4), "c": round(float(r.close), 4), "v": int(r.volume or 0)} for ts, r in d5.iterrows()]
    first = next((i for i, ts in enumerate(d5.index) if ts.date() == day), n)
    sw = swings(d5, K)
    conf = {}
    for i, kind, px in sw:
        conf.setdefault(i + K, []).append((i, kind, px))
    c = d5["close"].values
    rng = (d5["high"] - d5["low"]).rolling(12, min_periods=3).mean().values
    H, L = [None, None], [None, None]
    known = []                          # swings known so far, labelled
    state, used = "CHOP", set()
    window = None                       # {'side','from','level','line'}
    ready = None
    steps = []
    for t in range(n):
        notes = []
        for i, kind, px in conf.get(t, []):
            prev = H[1] if kind == "H" else L[1]
            if kind == "H":
                H = [H[1], px]
                lab = "H" if prev is None else ("HH" if px > prev else "LH")
            else:
                L = [L[1], px]
                lab = "L" if prev is None else ("HL" if px > prev else "LL")
            known.append({"i": i, "kind": kind, "price": round(px, 4), "label": lab})
            if t >= first:
                if lab == "LH" and state == "UP" and L[1] is not None:
                    window = {"side": "short", "from": i, "level": L[1], "line": px}
                    notes.append(("reversal", f"Reversal window: a LOWER high formed at {_fmt(px)} while the trend was up. Buyers are getting weaker. "
                                              f"If a candle closes below the last higher low, {_fmt(L[1])}, the trend turns down. Don't short yet; get ready."))
                elif lab == "HL" and state == "DOWN" and H[1] is not None:
                    window = {"side": "long", "from": i, "level": H[1], "line": px}
                    notes.append(("reversal", f"Reversal window: a HIGHER low formed at {_fmt(px)} while the trend was down. Sellers are getting weaker. "
                                              f"If a candle closes above the last lower high, {_fmt(H[1])}, the trend turns up. Don't buy yet; get ready."))
                elif window and ((window["side"] == "short" and lab == "HH") or (window["side"] == "long" and lab == "LL")):
                    notes.append(("trend", f"The reversal window closed: a new {'higher high' if lab == 'HH' else 'lower low'} at {_fmt(px)}. The old trend is back in charge."))
                    window = None
                elif state in ("UP", "DOWN") and lab in ("HL", "LH") and not window:
                    line_word = "higher low" if lab == "HL" else "lower high"
                    notes.append(("exit", f"New {line_word} at {_fmt(px)}: move your exit line there. Stay in while price stays {'above' if lab == 'HL' else 'under'} it."))
        answer, event = "WAIT", None
        if H[1] is not None and L[1] is not None:
            if state == "DOWN" and c[t] > H[1]:
                event = ("exit", "short", H[1])
                state = "CHOP"
            elif state == "UP" and c[t] < L[1]:
                event = ("exit", "long", L[1])
                state = "CHOP"
            lower_high = H[0] is not None and H[1] < H[0]
            higher_low = L[0] is not None and L[1] > L[0]
            go = None
            if c[t] < L[1] and (lower_high or state == "DOWN") and ("s", L[1]) not in used:
                used.add(("s", L[1]))
                go = ("short", L[1], H[1], state != "DOWN")
                state = "DOWN"
            elif c[t] > H[1] and (higher_low or state == "UP") and ("l", H[1]) not in used:
                used.add(("l", H[1]))
                go = ("long", H[1], L[1], state != "UP")
                state = "UP"
            if t >= first:
                if event and not go:
                    side = event[1]
                    answer = "EXIT"
                    notes.append(("exit", f"EXIT: this candle closed {'above' if side == 'short' else 'below'} the exit line {_fmt(event[2])}. "
                                          f"The {'down' if side == 'short' else 'up'}trend is over. Get out; don't hope."))
                if go:
                    side, lvl, line, start = go
                    answer = "SHORT" if side == "short" else "BUY"
                    what = ("The trend just turned down" if side == "short" else "The trend just turned up") if start else \
                           ("The downtrend continues" if side == "short" else "The uptrend continues")
                    notes.append(("entry", f"ENTRY {side.upper()} at {_fmt(c[t])}. {what}: this candle CLOSED {'below the last low' if side == 'short' else 'above the last high'} {_fmt(lvl)}. "
                                           f"Exit line {_fmt(line)}: stay in while price stays {'under' if side == 'short' else 'over'} it."))
                    window, ready = None, None
                else:
                    a = rng[t] if rng[t] == rng[t] else c[t] * 0.002
                    near = max(a, c[t] * 0.0015)
                    want = None
                    if (lower_high and not higher_low and state != "DOWN") or (state == "DOWN" and lower_high):
                        if L[1] < c[t] <= L[1] + near:
                            want = ("short", L[1], H[1])
                    if not want and ((higher_low and not lower_high and state != "UP") or (state == "UP" and higher_low)):
                        if H[1] - near <= c[t] < H[1]:
                            want = ("long", H[1], L[1])
                    if want and ready != (want[0], want[1]):
                        if ("s" if want[0] == "short" else "l", want[1]) not in used:
                            ready = (want[0], want[1])
                            notes.append(("ready", f"GET READY {want[0]}: price is close to the entry. Entry only if a candle closes "
                                                   f"{'below' if want[0] == 'short' else 'above'} {_fmt(want[1])}. Exit line {_fmt(want[2])}."))
        if t >= first and not notes and t == first:
            notes.append(("trend", "The regular session starts. Read the trend from the swing points first."))
        plan_entry = ready[1] if ready else None
        steps.append({"i": t, "state": state, "answer": answer, "notes": [{"kind": k, "text": x} for k, x in notes],
                      "exit_line": (H[1] if state == "DOWN" else L[1] if state == "UP" else None),
                      "ready": plan_entry, "ready_side": ready[0] if ready else None,
                      "window": dict(window) if window else None, "swings": len(known)})
    # the option version of each entry (estimated: Black-Scholes with the day's own movement as volatility)
    import math
    same_day = d5.index.to_series().dt.date.diff().dt.days.fillna(1) == 0
    rets = d5["close"].pct_change()[same_day].dropna().iloc[-200:]          # candle-to-candle moves inside a day (no overnight gaps)
    vol = float(1.4826 * rets.abs().median()) * math.sqrt(252 * 78) if len(rets) > 20 else 0.4   # robust: one huge candle doesn't blow it up
    iv = min(1.5, max(0.2, vol * 1.2))
    for s in steps:
        if s["answer"] in ("BUY", "SHORT") and s["i"] + 1 < n and s["i"] >= first:
            j = min(n - 1, s["i"] + 12)
            ts = d5.index[s["i"]]
            dte = (4 - ts.weekday()) % 7 or 7                     # this week's Friday expiry (next week's on a Friday)
            S0, S1 = float(c[s["i"]]), float(c[j])
            stp = 0.5 if S0 < 50 else 1.0 if S0 < 200 else 5.0
            K_ = round(round(S0 / stp) * stp, 2)
            kind = "call" if s["answer"] == "BUY" else "put"
            T0 = (dte + (16 * 60 - (ts.hour * 60 + ts.minute)) / 390.0) / 365.0
            T1 = max(T0 - (j - s["i"]) * 5 / (390.0 * 365.0), 1e-4)
            p0, p1 = _bs(S0, K_, T0, iv, kind), _bs(S1, K_, T1, iv, kind)
            s["option"] = {"kind": kind, "strike": K_, "expiry": (ts + timedelta(days=dte)).strftime("%a %b %d"), "cost": round(p0 * 100, 2),
                           "later": round(p1 * 100, 2), "pct": round((p1 / p0 - 1) * 100, 1) if p0 > 0 else None, "iv": round(iv, 2)}
            s["notes"].append({"kind": "option", "text": f"With options: buy the {_fmt(K_)} {kind.upper()} expiring {s['option']['expiry']} for about ${s['option']['cost']:.0f} per contract. "
                                                         f"Same exit line: sell the {kind} when price crosses it. The most you can lose is what you paid."})
    # outcome of each answer: where price was 12 candles later (or at the end of the day)
    for s in steps:
        if s["answer"] in ("BUY", "SHORT") and s["i"] + 1 < n:
            j = min(n - 1, s["i"] + 12)
            e = c[s["i"]]
            d = 1 if s["answer"] == "BUY" else -1
            s["result"] = {"later": round(float(c[j]), 4), "move": round(float((c[j] - e) * d), 4), "candles": int(j - s["i"])}
    return {"bars": bars, "steps": steps[first:] if first < n else [], "first": first, "swings": known, "lessons": LESSONS,
            "made": datetime.now().isoformat(timespec="seconds")}


def score(steps, picks):
    """picks: {step index: 'BUY'|'SHORT'|'WAIT'|'EXIT'}. Returns right / asked and the practice P&L per 100 shares."""
    right = asked = 0
    pnl = 0.0
    by = {s["i"]: s for s in steps}
    for i, p in picks.items():
        s = by.get(int(i))
        if not s:
            continue
        asked += 1
        right += int(p == s["answer"])
        if p in ("BUY", "SHORT") and s.get("result"):
            sign = 1 if (p == s["answer"]) else -1
            pnl += sign * s["result"]["move"] * 100
    return {"right": right, "asked": asked, "pnl": round(pnl, 2)}
