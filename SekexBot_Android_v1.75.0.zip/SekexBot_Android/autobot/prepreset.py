"""Pre-market preset (v1.75): works out a safer pre-market setup from YOUR OWN closed bot trades.

It never touches the daily loss limit. It decides four things for pre-market bot entries only:
  1. the best time window (the stretch of 30-minute slots that made the most money; none if no stretch made money),
  2. a size cap so that a typical stop loses about what a typical win makes,
  3. strategies that lost money there on enough trades (switched off in the pre-market only),
  4. the result is written into the settings, together with a plain-English note of why."""
from datetime import datetime

MIN_TRADES = 20
STATIC = {"pre_window": True, "pre_from": 420, "pre_until": 540, "ext_max_notional": 10000.0,
          "pre_entries_off": False, "pre_strategy_off": []}


def _slot(r):
    try:
        t = datetime.fromisoformat(r["opened_at"])
        return t.hour * 2 + (1 if t.minute >= 30 else 0)
    except Exception:
        return None


def build(rows):
    """rows: closed trades (dicts from the journal). Returns {settings: {...}, note: str, trades: n}."""
    pre = [r for r in rows if r.get("bucket") == "PRE" and r.get("status") == "closed" and r.get("pnl") is not None]
    n = len(pre)
    if n < MIN_TRADES:
        return {"settings": dict(STATIC), "trades": n, "source": "recommended",
                "note": f"Only {n} closed pre-market trades so far (need {MIN_TRADES}), so this uses the recommended preset: start trades 7:00 to 9:00, max $10,000 each."}
    slots = {}
    for r in pre:
        s = _slot(r)
        if s is not None and 8 <= s < 19:              # 4:00 to 9:30
            slots.setdefault(s, []).append(float(r["pnl"]))
    tot = {s: sum(v) for s, v in slots.items()}
    best, bs, be, cur, cs = 0.0, None, None, 0.0, None            # best contiguous stretch of slots (max subarray)
    for s in range(8, 19):
        v = tot.get(s, 0.0)
        if cur <= 0:
            cur, cs = v, s
        else:
            cur += v
        if cur > best:
            best, bs, be = cur, cs, s
    wins = [float(r["pnl"]) for r in pre if r["pnl"] > 0]
    loss = [float(r["pnl"]) for r in pre if r["pnl"] < 0]
    aw = sum(wins) / len(wins) if wins else 0.0
    al = -sum(loss) / len(loss) if loss else 0.0
    notl = sorted((r.get("qty") or 0) * (r.get("entry") or 0) for r in pre)
    med = notl[len(notl) // 2] if notl else 10000.0
    cap = med * (aw / al) if al > 0 and aw > 0 else med * 0.5
    cap = max(2000.0, min(15000.0, round(cap / 500.0) * 500.0))
    by = {}
    for r in pre:
        by.setdefault(str(r.get("strategy") or "?").split("@")[0], []).append(float(r["pnl"]))
    off = sorted(k for k, v in by.items() if len(v) >= 6 and sum(v) < -100 and sum(v) / len(v) < 0)
    st = dict(STATIC)
    st["ext_max_notional"] = cap
    st["pre_strategy_off"] = off
    parts = [f"Based on your {n} closed pre-market trades (net ${sum(tot.values()):,.0f})."]
    if bs is None:
        st["pre_entries_off"] = True
        parts.append("No stretch of the pre-market made money, so the bot will not START pre-market trades. Your own manual trades are not affected.")
    else:
        a, b = bs * 30, (be + 1) * 30
        st["pre_from"], st["pre_until"] = a, b
        parts.append(f"Best window: {a // 60}:{a % 60:02d} to {b // 60}:{b % 60:02d} (made ${best:,.0f} there).")
    parts.append(f"Average win ${aw:,.0f}, average loss ${al:,.0f}: size capped at ${cap:,.0f} per trade (was typically ${med:,.0f}).")
    if off:
        parts.append("Off in the pre-market: " + ", ".join(off) + ".")
    return {"settings": st, "trades": n, "source": "your journal", "note": " ".join(parts)}
