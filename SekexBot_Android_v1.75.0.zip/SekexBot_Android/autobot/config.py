"""Settings: API keys come from .env, everything else from settings.json (editable from the dashboard)."""
import json
import os
from dataclasses import dataclass, asdict, field
from pathlib import Path

from .android import IS_ANDROID

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = Path(os.getenv("AUTOBOT_DATA", str(BASE_DIR / "data")))
DATA_DIR.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = DATA_DIR / "settings.json"
OPTIONS_FILE = DATA_DIR / "options_settings.json"     # the options module keeps its own settings here
ENV_FILE = BASE_DIR / ".env"


def load_env():
    """Tiny .env loader (no extra dependency)."""
    if ENV_FILE.exists():
        for line in ENV_FILE.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            k, v = line.split("=", 1)
            os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


load_env()


def write_env(values: dict):
    """Update/insert KEY=value lines in .env (keeps comments and other keys) and apply them now."""
    lines = ENV_FILE.read_text().splitlines() if ENV_FILE.exists() else []
    done = set()
    out = []
    for ln in lines:
        k = ln.split("=", 1)[0].strip() if "=" in ln and not ln.strip().startswith("#") else None
        if k in values:
            out.append(f"{k}={values[k]}")
            done.add(k)
        else:
            out.append(ln)
    for k, v in values.items():
        if k not in done:
            out.append(f"{k}={v}")
    ENV_FILE.write_text("\n".join(out) + "\n")
    for k, v in values.items():
        os.environ[k] = v


def mask(v: str) -> str:
    return (v[:2] + "…" + v[-4:]) if v and len(v) > 8 else ("set" if v else "")


@dataclass
class Settings:
    # ---- The one limit you control ----
    daily_max_loss: float = 200.0          # $ — bot flattens and stops for the day when hit

    # ---- Mode ----
    live: bool = False                      # False = Alpaca paper account
    data_feed: str = "iex"                  # "iex" (free) or "sip" (paid Algo Trader Plus)
    allow_shorts: bool = True               # short whenever the stock/account/session allows it
    level: str = "balanced"                 # conservative / balanced / aggressive / max / custom (see autobot/levels.py)
    level_auto: bool = False                # Auto: learn which level works best in each session and switch by itself
    level_active: str = ""                  # level Auto is using right now
    trade_all_flips: bool = False           # take every fresh ribbon BUY/SELL flip (risk limits still apply)
    shorts_default_v129: bool = False       # internal: one-time switch of old saved settings to shorts ON

    # ---- Extended hours (long-only, limit orders, bot-managed stops) ----
    ext_premarket: bool = True              # 4:00 - 9:30 AM ET (the 9:00-9:30 gap moves are the best of the morning)
    # On Android these start OFF: extended-hours stops are watched by the bot itself, and Android
    # can kill a background app at night. Turn them on from the dashboard if you accept that risk.
    ext_afterhours: bool = True             # 4:00 - 8:00 PM ET (earnings / news movers)
    ext_overnight: bool = False           # 8:00 PM - 4:00 AM ET (Sun-Thu nights)
    ext_risk_mult: float = 0.5              # extended-hours trades risk half as much as regular ones
    ext_max_positions: int = 2
    ext_tick_seconds: int = 15              # faster checks: stops live in the bot, not on the server
    ext_scan_minutes: int = 5               # re-scan for pre-market / after-hours movers this often
    auto_prep: bool = True                  # build the morning / night movers list on a timer, even with the bot stopped
    auto_direction: bool = True             # trade strong early LONG/SHORT direction calls automatically (regular hours)
    reentry: bool = True                    # after a profitable exit, get back in on a pullback OR on continuation (a new extreme), up to 3 times
    guard_manual: str = "alert"            # 🛡 your manual positions: off | alert | close (or flip to the other side) when red AND the trend turns against them
    guard_flip_harvest: bool = True        # flip mode: arm Auto-harvest on the new position
    guard_flip_max: int = 3                # flip mode: at most this many reversals per stock per day, then it only closes
    guard_loss_pct: float = 0.15           # hard loss limit for the guard, % of entry at the real exit price
    pct_harvest: bool = True               # copy a hand-trader: bank a small % gain (below), then the re-entry logic gets back in while the trend holds
    pct_harvest_auto: bool = False         # use the % learned from YOUR manual wins (needs 15+ trips) instead of the fixed one
    pct_harvest_pct: float = 0.10          # that small gain, in percent of the entry price (never less than 3 cents a share)
    shorts_24_5: bool = False              # shorts allowed in every open session (pre-market, regular, after-hours AND overnight), with a fresh borrow check before each one
    short_from_7am: bool = True            # shorting switches on by itself at 7:00 AM ET (until 8 PM) for every setup, pre-market included
    let_run: bool = True                   # give winners room: no scalp banking at +0.15R, wider trail, stop not moved to break-even too early
    auto_tune: bool = True                 # self-fix: bench setups that keep losing, promote the ones that work
    auto_mode: str = "both"                # automatic system direction: both | short | long
    auto_short: bool = False                # Automatic short system: short-only, confirmed 1-minute signals, fresh borrow check, shortlist scanner
    pre_plan: bool = True                   # pre-market checkpoints (4 AM, 7 AM, 8:30, 9:15), short-at-open list and OPEN_SHORT trades
    morning_reversal: bool = False          # short the second rejection of the opening high after a completed 1-min breakdown
    preclose_short: bool = False            # 3:10-3:35 PM scan for overnight shorts with broker-held GTC stop/target (SIP + short-enabled account)
    auto_study: bool = True                 # overnight: replay recent days through every strategy and teach the learner
    share_diagnostics: bool = False        # OFF until the user opts in: send technical health info (no keys, trades or money) to support
    share_trade_logs: bool = False         # separate opt-in (default OFF): upload the trade journal + strategy logs so support can refine strategies
    diag_label: str = ""                    # optional name the user gives so support can tell their phone apart
    diag_asked: bool = False               # the one-time 'share diagnostics?' question has been answered
    collector_url: str = ""                 # support collector address (https). Blank = the built-in default
    harvest_stop: bool = True               # v1.65: when Harvest small % is on, harvest trades get a stop sized to the harvest (not the full ATR stop)
    harvest_stop_mult: float = 3.0          # stop distance = this many times the harvest gain (never tighter than the thin-market floor)
    max_spread_trend_pct: float = 0.40      # trend setups (big targets) may enter at a wider spread than scalps
    trend_harvest_pct: float = 0.50         # trend entries (EXT_CONT) bank at least this % instead of the tiny scalp gain
    options_on: bool = False                 # separate options module (defined-risk only); OFF until you turn it on
    options_live_unlocked: bool = False      # extra lock: options never trade on LIVE until you unlock them with your PIN
    options_style: str = "spread"            # spread (vertical debit spread) | long (single call/put)
    options_daily_budget: float = 300.0      # its OWN daily loss budget (not your stock limit)
    options_max_premium: float = 200.0       # most to pay for one trade
    options_max_contracts: int = 3
    options_max_positions: int = 2
    options_tp_pct: float = 50.0             # take profit at +50% of what was paid
    options_stop_pct: float = 40.0           # stop at -40% of what was paid
    options_min_dte: int = 5
    options_max_dte: int = 21
    options_min_oi: int = 100
    options_flatten_min: int = 15            # close everything this many minutes before the close
    options_fill_wait_s: int = 75
    options_underlyings: list = field(default_factory=lambda: ["SPY", "QQQ", "IWM", "AAPL", "NVDA", "TSLA", "AMD", "META", "MSFT", "AMZN"])
    green_guard: bool = True                 # a trade that keeps going green but never reaches its target: protect / bank it dynamically
    morning_trend: bool = True               # MORN_TREND: ride steady morning trends (gap + above VWAP + rising EMAs), 9:35-11:00
    fractional_on: bool = False              # small accounts: when a whole share is too big for the risk budget, buy a fraction (long only, regular hours)
    regime_filter: bool = True               # size strategies by market regime (trend / chop / volatile / quiet)
    strategy_breaker: bool = True            # shrink then pause a strategy that is losing badly today
    etf_pair_guard: bool = True             # one position at a time per leveraged-ETF family (TQQQ/SQQQ/QQQ...)
    v165_defaults: bool = False
    max_spread_pct: float = 0.15            # the bot skips an entry when bid-ask is wider than this % of the price (0 = off)
    pm_trend: bool = True                   # pre-market / after-hours CONTINUATION entries: stocks 2%+ from the close that keep making new lows (short, from 7 AM) or highs (buy)
    v163_defaults: bool = False             # internal: one-time switch of Harvest small % ON
    v159_defaults: bool = False             # internal: one-time switch of overnight + 24/5 shorts back OFF
    v155_defaults: bool = False             # internal: one-time switch of old saved settings to overnight ON (24/5)
    v130_defaults: bool = False             # internal: one-time switch of old saved settings to pre-market + after-hours ON

    # ---- Resilience ----
    auto_resume: bool = True                # if the app is killed while trading, resume on restart
    stream_prices: bool = True              # real-time websocket prices (falls back to polling)

    # ---- Internal guard rails (sensible defaults, not meant to be tuned daily) ----
    risk_per_trade_frac: float = 0.15       # base $ risk per trade = daily_max_loss * this * strategy weight
    max_positions: int = 4
    max_position_pct_equity: float = 0.25    # max % of your EQUITY in any single position (margin buying power is ~4x equity)
    proven_only: bool = True                # setups with fewer than 20 closed trades trade at reduced size until they prove themselves
    max_position_pct_bp: float = 0.25       # max % of buying power in any single position
    min_price: float = 5.0
    max_price: float = 800.0
    min_prev_volume: int = 1_000_000
    universe_size: int = 30
    tick_seconds: int = 30
    no_new_entries_min_before_close: int = 20
    flatten_min_before_close: int = 8
    time_stop_minutes: int = 75
    confirm_trades: bool = False            # ask "Send this order?" / "Close?" before manual trades (off = one tap)
    cooloff_streak: bool = True             # after 3 losses in a row: pause 20 min, then half size
    cooloff_symbol: bool = True             # wait before re-trading a symbol; drop it after 2 losses in a day
    aggressive_scalp: bool = False          # 🔥 many fast trades: momentum bursts, 1/2 at +0.5R, rest +1R, 8-min max
    scalp_mode: bool = False                # quick in-and-out: 1/2 at +0.6R, rest at +1.2R, max 20 min
    scale_out: bool = True                  # take profit along the way (1/3 at +1R, 1/3 at +2R, trail the rest)
    tod_filter: bool = True                 # skip times of day where YOUR trade history loses money
    tod_min_trades: int = 30                # ...once that time slot has at least this many trades
    pre_window: bool = True               # v1.75: bot enters pre-market trades only inside pre_from..pre_until (minutes after midnight ET)
    pre_from: int = 420                   # 7:00 AM
    pre_until: int = 540                  # 9:00 AM
    ext_max_notional: float = 10000.0     # v1.75: biggest extended-hours (pre / after / overnight) bot position in dollars; 0 = no cap
    pre_entries_off: bool = False         # v1.75 preset: the bot does not START pre-market trades at all
    pre_strategy_off: list = field(default_factory=list)    # strategies off in the pre-market only
    pre_auto: bool = False                # rebuild the pre-market preset from my journal every night
    pre_preset_note: str = ""             # why the preset is what it is
    strategy_off: list = field(default_factory=list)                    # strategies you switched off in the Scorecard
    watch_always: list = field(default_factory=lambda: ["SPY", "QQQ"])   # market-trend reference only
    watchlist: list = field(default_factory=lambda: ["SPCX"])            # your tickers: always scanned & traded

    def save(self):
        d = asdict(self)
        opt = {k: v for k, v in d.items() if k.startswith("options_")}
        main = {k: v for k, v in d.items() if not k.startswith("options_")}
        SETTINGS_FILE.write_text(json.dumps(main, indent=2))
        OPTIONS_FILE.write_text(json.dumps(opt, indent=2))

    @classmethod
    def load(cls) -> "Settings":
        s = cls()
        if SETTINGS_FILE.exists():
            try:
                data = json.loads(SETTINGS_FILE.read_text())
                for k, v in data.items():
                    if hasattr(s, k):
                        setattr(s, k, v)
                if "level" not in data:                      # v1.33: existing setups keep their switches as 'custom'
                    s.level = "custom"
                if not data.get("shorts_default_v129"):      # v1.29: shorts are ON by default, once
                    s.allow_shorts, s.shorts_default_v129 = True, True
                    s.save()
                if not data.get("v155_defaults"):            # v1.55: 24/5 trading, overnight ON, once
                    s.ext_overnight, s.v155_defaults = True, True
                    s.save()
                if not data.get("v159_defaults"):            # v1.59.1: overnight + 24/5 shorts back to OFF, once (thin quotes, wide spreads)
                    s.ext_overnight, s.shorts_24_5, s.v159_defaults = False, False, True
                    s.save()
                if not data.get("v163_defaults"):            # v1.63: Harvest small % ON, once (the hand-trader scalp)
                    s.pct_harvest, s.v163_defaults = True, True
                    s.save()
                if not data.get("v165_defaults"):            # v1.65: smaller bot position cap (25% -> 15% of equity), once
                    if abs(float(s.max_position_pct_equity) - 0.25) < 1e-9:
                        s.max_position_pct_equity = 0.15
                    s.v165_defaults = True
                    s.save()
                if not data.get("v130_defaults"):            # v1.30: pre-market and after-hours ON, once
                    s.ext_premarket, s.ext_afterhours, s.v130_defaults = True, True, True
                    s.save()
            except Exception:
                pass
        try:                                                 # v1.72: options settings live in their own file
            if OPTIONS_FILE.exists():
                for k, v in json.loads(OPTIONS_FILE.read_text()).items():
                    if k.startswith("options_") and hasattr(s, k):
                        setattr(s, k, v)
            else:
                s.save()                                     # first run after the update: move them over
        except Exception:
            pass
        return s


def api_keys(live: bool):
    """Separate key pairs for paper and live so you never mix them up."""
    if live:
        return os.getenv("ALPACA_LIVE_KEY", ""), os.getenv("ALPACA_LIVE_SECRET", "")
    return os.getenv("ALPACA_PAPER_KEY", ""), os.getenv("ALPACA_PAPER_SECRET", "")


def live_pin() -> str:
    return os.getenv("LIVE_PIN", "")
