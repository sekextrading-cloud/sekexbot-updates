"""Offline market simulator with the same interface as AlpacaBroker.

Used to (1) test the whole engine without API keys and (2) demo the dashboard.
Each synthetic trading date runs 8 PM (night before) -> 8 PM: overnight, pre-market,
regular session (trend / chop / gapper days) and after-hours (with occasional
"earnings" jumps). It is NOT a backtest of real markets."""
import random
import time as _time
from datetime import datetime, timedelta, time
from zoneinfo import ZoneInfo

import numpy as np
import pandas as pd

NY = ZoneInfo("America/New_York")
SYMS = ["AAA", "BBB", "CCC", "DDD", "EEE", "FFF", "GGG", "HHH", "III", "JJJ", "KKK", "LLL",
        "MMM", "NNN", "OOO", "PPP", "SPY", "QQQ"]
N_ON, N_PRE, N_REG, N_AH = 480, 330, 390, 240      # minutes per segment (20:00 -> 20:00)


class SimBroker:
    paper = True

    def __init__(self, start: datetime, equity=25_000.0, speed=0.0, seed=7):
        self.t = start.astimezone(NY)
        self.speed = speed               # 0 = as fast as possible; 60 = 1 real sec per sim minute
        self.rng = np.random.default_rng(seed)
        random.seed(seed)
        self.cash = equity
        self.last_equity = equity
        self.pos = {}                    # sym -> {qty, avg}
        self.orders = {}                 # id -> order dict
        self.fills = []                  # (time, sym, side, px)
        self.prev_close = {s: float(self.rng.uniform(20, 300)) for s in SYMS}
        self.last_px = dict(self.prev_close)
        self.day_bars = {}
        self.day_key = None
        self.gaps = {}
        self.reg_close = {}
        self._ensure_day()

    # ---------- synthetic data ----------
    @staticmethod
    def _key(t):
        return (t + timedelta(hours=4)).date()

    def _walk(self, start, n, vol, drift=0.0, end=None):
        r = self.rng.normal(drift, vol, n)
        p = start * np.exp(np.cumsum(r))
        if end is not None:   # Brownian bridge to the target price
            p = p * np.exp(np.linspace(0, 1, n) * np.log(end / p[-1]))
        return p

    def _gen_day(self, d):
        idx = pd.date_range(datetime.combine(d - timedelta(days=1), time(20, 0), NY), periods=1440, freq="1min")
        idx_ret = self.rng.normal(0, 0.0004, N_REG)
        market_trend = self.rng.choice([-1, 0, 1], p=[0.3, 0.3, 0.4]) * 0.00008
        self.day_bars, self.gaps = {}, {}
        for s in SYMS:
            pc, last = self.prev_close[s], self.last_px[s]
            idx_like = s in ("SPY", "QQQ")
            kind = self.rng.choice(["trend", "chop", "random"], p=[0.4, 0.35, 0.25])
            big = self.rng.random() < 0.25 and not idx_like
            gap = self.rng.normal(0, 0.01) + (self.rng.choice([-1, 1]) * self.rng.uniform(0.03, 0.08) if big else 0)
            vol = self.rng.uniform(0.0008, 0.0022) * (0.5 if idx_like else 1)
            o = pc * (1 + gap)
            # overnight + pre-market drift from last night's price to the open
            ext_pre = self._walk(last, N_ON + N_PRE, vol * 0.3, end=o)
            # regular session
            drift = (np.sign(gap) if big else self.rng.choice([-1, 1])) * self.rng.uniform(0.00008, 0.0003)
            prices, p, mom, anchor = [], o, 0.0, o
            for i in range(N_REG):
                e = self.rng.normal(0, vol) + 0.6 * idx_ret[i] + market_trend
                if kind == "trend":
                    mom = 0.25 * mom + e
                    r = drift * (1.5 if i < 90 else 0.6) + mom
                elif kind == "chop":
                    r = e - 0.04 * (p - anchor) / anchor
                else:
                    r = e
                p = max(1.0, p * (1 + r))
                prices.append(p)
            reg = np.array(prices)
            # after-hours: occasional earnings jump followed by momentum
            earn = (not idx_like) and self.rng.random() < 0.2
            if earn:
                jump = self.rng.choice([-1, 1]) * self.rng.uniform(0.04, 0.10)
                pre = self._walk(reg[-1], 5, vol * 0.3)
                post = self._walk(pre[-1] * (1 + jump), N_AH - 5, vol * 0.6,
                                  drift=np.sign(jump) * self.rng.uniform(0.0, 0.0004))
                ah = np.concatenate([pre, post])
            else:
                ah = self._walk(reg[-1], N_AH, vol * 0.3)
            c = np.concatenate([ext_pre, reg, ah])
            op = np.concatenate([[last], c[:-1]])
            op[N_ON + N_PRE] = o
            seg_vol = np.concatenate([np.full(N_ON + N_PRE, vol * 0.3), np.full(N_REG, vol), np.full(N_AH, vol * 0.5)])
            hi = np.maximum(op, c) * (1 + np.abs(self.rng.normal(0, seg_vol / 2)))
            lo = np.minimum(op, c) * (1 - np.abs(self.rng.normal(0, seg_vol / 2)))
            m = np.arange(N_REG)
            ushape = 1 + 2.5 * np.exp(-m / 30) + 1.2 * np.exp(-(N_REG - 1 - m) / 25)
            vreg = ushape * self.rng.lognormal(0, 0.4, N_REG) * (1 + 300 * np.abs(reg / op[N_ON + N_PRE:N_ON + N_PRE + N_REG] - 1)) * 20000 * (3 if big else 1)
            von = self.rng.lognormal(0, 0.6, N_ON) * 200
            vpre = self.rng.lognormal(0, 0.6, N_PRE) * (1500 * (4 if big else 1))
            vah = self.rng.lognormal(0, 0.5, N_AH) * 3000
            if earn:
                vah[5:] *= 1 + 12 * np.exp(-np.arange(N_AH - 5) / 40)
            v = np.concatenate([von, vpre, vreg, vah]).astype(int) + 1
            self.day_bars[s] = pd.DataFrame({"open": op, "high": hi, "low": lo, "close": c, "volume": v}, index=idx)
            self.gaps[s] = round(gap * 100, 2)
            self.reg_close[s] = float(reg[-1])
        self.day_key = d

    def _ensure_day(self):
        k = self._key(self.t)
        if k.weekday() < 5 and k != self.day_key:
            if self.day_key is not None:
                for s, df in self.day_bars.items():
                    self.prev_close[s] = self.reg_close[s]
                    self.last_px[s] = float(df["close"].iloc[-1])
                self.last_equity = self._equity()
            self._gen_day(k)

    def _bar_upto(self, s, start=None):
        df = self.day_bars.get(s)
        if df is None or self.day_key != self._key(self.t):
            return None
        out = df[df.index + timedelta(minutes=1) <= self.t]
        if start is not None:
            out = out[out.index >= start]
        return out

    def _px(self, s):
        df = self.day_bars.get(s)
        if df is None:
            return self.prev_close[s]
        b = df[df.index + timedelta(minutes=1) <= self.t]
        return float(b["close"].iloc[-1]) if len(b) else float(df["open"].iloc[0])

    # ---------- time ----------
    def now(self):
        return self.t

    def sleep(self, seconds):
        if self.speed:
            _time.sleep(seconds / self.speed)
        self.t += timedelta(seconds=seconds)
        self._ensure_day()
        self._process()

    def trading_day(self, d):
        if d.weekday() >= 5:
            return None
        return datetime.combine(d, time(9, 30), NY), datetime.combine(d, time(16, 0), NY)

    def clock(self):
        d = self.t.date()
        op, cl = datetime.combine(d, time(9, 30), NY), datetime.combine(d, time(16, 0), NY)
        is_open = d.weekday() < 5 and op <= self.t < cl
        if self.t < op and d.weekday() < 5:
            nxt = op
        else:
            nd = d + timedelta(days=1)
            while nd.weekday() >= 5:
                nd += timedelta(days=1)
            nxt = datetime.combine(nd, time(9, 30), NY)
        return {"is_open": is_open, "next_open": nxt, "next_close": cl if is_open else nxt.replace(hour=16, minute=0)}

    # ---------- account ----------
    def _equity(self):
        return self.cash + sum(p["qty"] * self._px(s) for s, p in self.pos.items())

    def account(self):
        eq = self._equity()
        return {"equity": eq, "last_equity": self.last_equity, "buying_power": eq * 2, "cash": self.cash,
                "daytrade_count": 0, "pattern_day_trader": False, "blocked": False, "shorting_enabled": True}

    def positions(self):
        return {s: {"qty": p["qty"], "avg_entry": p["avg"], "price": self._px(s),
                    "upl": (self._px(s) - p["avg"]) * p["qty"]} for s, p in self.pos.items() if p["qty"]}

    # ---------- data ----------
    def scan(self, s, acct=None):
        from .scanner import score_candidates
        mine = [w.upper() for w in getattr(s, "watchlist", [])]
        if not hasattr(self, "_stats"):
            r = np.random.default_rng(99)
            self._stats = {sym: {"adv": float(r.uniform(1.5e6, 6e7)), "atr_pct": float(r.uniform(0.012, 0.07))} for sym in SYMS}
        rows = []
        for sym in SYMS:
            if sym in ("SPY", "QQQ"):
                continue
            pc = self.prev_close[sym]
            px = self._px(sym)
            rows.append({"sym": sym, "price": px, "prev_close": pc, "adv": self._stats[sym]["adv"],
                         "atr": pc * self._stats[sym]["atr_pct"], "sma20": pc * 0.99, "hi20": pc * 1.04,
                         "lo20": pc * 0.93, "mover": abs(px / pc - 1) > 0.03, "watch": sym in mine,
                         "spread_pct": 0.05})
        ranked = score_candidates(rows, acct or self.account(), s)
        top = [r for r in ranked if r["watch"]] + [r for r in ranked if not r["watch"]][: s.universe_size]
        self.last_scan_info = top
        return [r["symbol"] for r in top], {r["symbol"]: r["gap"] for r in ranked}

    def bars(self, symbols, start=None):
        if start is None and self.day_key:
            start = datetime.combine(self.day_key, time(9, 29), NY)
        out = {}
        for s in symbols:
            b = self._bar_upto(s, start)
            if b is not None and len(b):
                out[s] = b
        return out

    def chart_bars(self, sym, days=4):
        try:
            return self.analysis_bars(sym)[0]
        except Exception:
            return None

    def analysis_bars(self, sym):
        return self.bars([sym]).get(sym), "live"

    def shortable(self, sym):
        return True

    def quotes(self, symbols, session="AFTER"):
        sp = 0.0004 if session == "REGULAR" else 0.0015
        out = {}
        if self.day_key != self._key(self.t):
            return out
        for s in symbols:
            if s in self.day_bars:
                px = self._px(s)
                out[s] = (px * (1 - sp / 2), px * (1 + sp / 2), self.t)
        return out

    def price_info(self, sym, session="REGULAR"):
        if sym not in self.prev_close:
            return {"bid": None, "ask": None, "last": None, "prev_close": None, "ts": None, "source": ""}
        q = self.quotes([sym], session).get(sym)
        return {"bid": q[0] if q else None, "ask": q[1] if q else None, "last": self._px(sym),
                "prev_close": self.prev_close[sym], "ts": self.t, "source": "simulator"}

    def _daily_stats(self, symbols):
        """Synthetic 20-day stats so the Morning prep card can be shown in the simulator."""
        out = {}
        for s in symbols:
            pc = self.prev_close.get(s)
            if pc:
                out[s] = {"prev_close": pc, "adv": 2_000_000.0, "atr": pc * 0.02, "sma20": pc * 0.99,
                          "hi20": pc * 1.03, "lo20": pc * 0.94, "today_vol": None}
        return out

    def recheck_borrow(self, sym):
        return True, "easy_to_borrow"

    def ext_scan(self, s, session, extra=()):
        moves = {}
        for sym in SYMS:
            if sym in ("SPY", "QQQ"):
                continue
            ref = self.reg_close[sym] if session == "AFTER" else self.prev_close[sym]
            moves[sym] = round((self._px(sym) / ref - 1) * 100, 2)
        rows = sorted(((abs(m), sym) for sym, m in moves.items() if abs(m) >= 1.5), reverse=True)
        return [x for _, x in rows[:15]], moves

    # ---------- orders ----------
    def submit_bracket(self, sym, side, qty, limit_price, stop, target, client_id):
        self.orders[client_id] = {"kind": "bracket", "sym": sym, "side": side, "qty": qty, "limit": limit_price,
                                  "stop": stop, "target": target, "status": "new", "fill": None, "t": self.t}
        return client_id

    def submit_limit_ext(self, sym, side, qty, limit_price, client_id):
        self.orders[client_id] = {"kind": "limit", "sym": sym, "side": side, "qty": qty, "limit": limit_price,
                                  "status": "new", "fill": None, "t": self.t}
        return client_id

    def fractionable(self, sym):
        return True

    def submit_limit_day(self, sym, side, qty, limit_price, client_id):
        return self.submit_limit_ext(sym, side, qty, limit_price, client_id)

    def submit_stop_day(self, sym, exit_side, qty, stop, client_id):
        d = 1 if exit_side == "sell" else -1             # a stop on a fraction = a bracket leg with no target
        self.orders[client_id] = {"kind": "bracket", "sym": sym, "side": "buy" if d > 0 else "sell", "qty": qty, "limit": 0,
                                  "stop": stop, "target": 1e9 if d > 0 else 0.0, "status": "filled", "fill": self._px(sym),
                                  "t": self.t, "seen": self.t}
        return client_id

    # ---------- manual trading ----------
    def manual_order(self, sym, side, qty, order_type="market", limit_price=None, stop=None, target=None,
                     extended=False, client_id=None, stop_price=None, trail_percent=None, trail_price=None,
                     tif="day"):
        client_id = client_id or f"man-{len(self.orders)}"
        if sym not in self.day_bars:
            raise ValueError(f"{sym} isn't in the simulator's market (try AAA-MMM, SPY or QQQ)")
        if order_type in ("stop", "stop_limit", "trailing_stop"):   # simulator: listed as working, not filled
            self.orders[client_id] = {"kind": order_type, "sym": sym, "side": side, "qty": qty,
                                      "limit": limit_price or stop_price, "status": "new", "fill": None, "t": self.t}
            return client_id
        if order_type == "limit" or extended:
            return self.submit_limit_ext(sym, side, qty, limit_price, client_id)
        px = self._px(sym)
        self._trade(sym, side, qty, px)
        if stop and target:     # keep the protective legs working, like Alpaca's bracket
            self.orders[client_id] = {"kind": "bracket", "sym": sym, "side": side, "qty": qty, "limit": px,
                                      "stop": stop, "target": target, "status": "filled", "fill": px, "t": self.t}
        else:
            self.orders[client_id] = {"kind": "limit", "sym": sym, "side": side, "qty": qty, "limit": px,
                                      "status": "filled", "fill": px, "t": self.t}
        return client_id

    def close_qty(self, sym, qty):
        self.cancel_symbol_orders(sym)
        p = self.pos.get(sym)
        if not p:
            raise ValueError(f"No {sym} position")
        self._trade(sym, "sell" if p["qty"] > 0 else "buy", min(qty, abs(p["qty"])), self._px(sym))

    def open_orders(self):
        return [{"id": k, "symbol": o["sym"], "side": o["side"], "qty": o["qty"], "filled": 0, "type": o["kind"],
                 "limit": o.get("limit"), "stop": None, "status": o["status"], "ext": False, "client_id": k,
                 "tif": "day", "trail": "",
                 "at": o["t"].strftime("%m-%d %H:%M")}
                for k, o in self.orders.items() if o["status"] == "new"]

    def _trade(self, sym, side, qty, px):
        d = 1 if side == "buy" else -1
        p = self.pos.setdefault(sym, {"qty": 0.0, "avg": 0.0})
        new = p["qty"] + d * qty
        if p["qty"] == 0 or (p["qty"] > 0) == (d > 0):
            p["avg"] = (p["avg"] * abs(p["qty"]) + px * qty) / abs(new) if new else 0
        p["qty"] = new
        self.cash -= d * qty * px
        self.fills.append((self.t, sym, side, px))
        if abs(p["qty"]) < 1e-9:
            self.pos.pop(sym, None)

    def _process(self):
        """Walk completed bars since the last call and fill orders."""
        for oid, o in list(self.orders.items()):
            if o["status"] in ("canceled", "closed") or (o["kind"] == "limit" and o["status"] == "filled") \
                    or o["kind"] in ("stop", "stop_limit", "trailing_stop"):
                continue
            b = self._bar_upto(o["sym"])
            if b is None or not len(b):
                continue
            b = b[b.index >= o.get("seen", o["t"]).replace(second=0, microsecond=0)]
            d = 1 if o["side"] == "buy" else -1
            for ts, bar in b.iterrows():
                if ts < o["t"].replace(second=0, microsecond=0):
                    continue
                if o["kind"] == "limit":
                    if d > 0 and bar["low"] <= o["limit"]:
                        px = min(bar["open"], o["limit"])
                    elif d < 0 and bar["high"] >= o["limit"]:
                        px = max(bar["open"], o["limit"])
                    else:
                        continue
                    held = self.pos.get(o["sym"], {}).get("qty", 0)
                    if d < 0 and held < o["qty"] - 1e-9:
                        o["status"] = "canceled"   # nothing to sell
                        break
                    self._trade(o["sym"], o["side"], o["qty"], px)
                    o["status"], o["fill"] = "filled", px
                    break
                if o["status"] == "new":
                    px = bar["open"]
                    if (px - o["limit"]) * d <= 0:
                        self._trade(o["sym"], o["side"], o["qty"], px * (1 + d * 0.0003))
                        o["status"], o["fill"] = "filled", px
                    continue
                if o["status"] == "filled":
                    slip = 1 - d * 0.0003
                    stop_hit = bar["low"] <= o["stop"] if d > 0 else bar["high"] >= o["stop"]
                    if stop_hit:
                        px = min(bar["open"], o["stop"]) if d > 0 else max(bar["open"], o["stop"])
                        self._trade(o["sym"], "sell" if d > 0 else "buy", o["qty"], px * slip)
                        o["status"] = "closed"
                        break
                    if (bar["high"] >= o["target"]) if d > 0 else (bar["low"] <= o["target"]):
                        self._trade(o["sym"], "sell" if d > 0 else "buy", o["qty"], o["target"])
                        o["status"] = "closed"
                        break
            o["seen"] = self.t
        # DAY orders: brackets expire at 16:00, extended limits at 20:00
        tod = self.t.time()
        for o in self.orders.values():
            if o["status"] == "new" and ((o["kind"] == "bracket" and tod >= time(16, 0)) or
                                         (o["kind"] == "limit" and time(20, 0) <= tod < time(20, 1)
                                          and o["t"].time() < time(20, 0))):
                o["status"] = "canceled"

    def entry_status(self, order_id):
        o = self.orders[order_id]
        st = {"new": "new", "filled": "filled", "closed": "filled", "canceled": "canceled"}[o["status"]]
        return st, o["fill"], o["qty"] if o["fill"] else 0

    def order_open(self, order_id):
        o = self.orders.get(order_id)
        return bool(o and o["status"] == "new")

    def cancel(self, order_id):
        o = self.orders.get(order_id)
        if o and o["status"] == "new":
            o["status"] = "canceled"
        elif o and o["kind"] == "bracket" and o["status"] == "filled":
            o["status"] = "closed"   # cancels bracket legs

    def cancel_symbol_orders(self, sym):
        for oid, o in self.orders.items():
            if o["sym"] == sym:
                self.cancel(oid)

    def partial_exit(self, sym, qty, side, new_stop, target=None):
        """Sell part of a position, then protect the rest with a stop (+ the old target)."""
        d = 1 if side == "buy" else -1
        for o in self.orders.values():
            if o["sym"] == sym and o["kind"] == "bracket" and o["status"] == "filled" and target is None:
                target = o["target"]
        self.cancel_symbol_orders(sym)
        if not self.pos.get(sym):
            return 0
        self._trade(sym, "sell" if d > 0 else "buy", qty, self._px(sym) * (1 - d * 0.0003))
        rem = abs(self.pos.get(sym, {}).get("qty", 0))
        if rem > 0:
            if target is None:
                target = 1e9 if d > 0 else 0.0
            self.orders[f"sc-{len(self.orders)}"] = {"kind": "bracket", "sym": sym, "side": side, "qty": rem,
                                                     "limit": 0, "stop": new_stop, "target": target, "status": "filled",
                                                     "fill": self._px(sym), "t": self.t, "seen": self.t}
        return rem

    def update_stop(self, sym, new_stop):
        for o in self.orders.values():
            if o["sym"] == sym and o["kind"] == "bracket" and o["status"] == "filled":
                o["stop"] = new_stop
                return True
        return False

    def close_position(self, sym):
        self.cancel_symbol_orders(sym)
        p = self.pos.get(sym)
        if p:
            q = p["qty"]
            self._trade(sym, "sell" if q > 0 else "buy", abs(q), self._px(sym))

    def close_all(self):
        for s in list(self.pos):
            self.close_position(s)

    def last_exit_price(self, sym, since, exit_side):
        f = [px for (t, s, side, px) in self.fills if s == sym and side == exit_side and t >= since]
        return f[-1] if f else None
