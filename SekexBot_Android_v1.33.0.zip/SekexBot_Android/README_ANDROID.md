# SekexBot for Android — setup guide (v1.22.0)

SekexBot runs **entirely on your Android phone**. No PC is needed. It runs inside **Termux**, a free Linux app, and you use it from the same dashboard you know, opened in your phone's browser.

> **Get Termux from F-Droid or GitHub, not the Play Store.** The Play Store version is old and broken.
> You need three apps, all from the same source (all F-Droid, or all GitHub):
> - **Termux** (required)
> - **Termux:API** (battery status, notifications, wake lock)
> - **Termux:Boot** (start SekexBot automatically when the phone turns on)
> - **Termux:Widget** (Start / Stop buttons on your home screen)

---

## 1. Install (one time)

**Automated install: one file, one command.**

1. Install **Termux**, **Termux:API**, **Termux:Boot** and **Termux:Widget** from F-Droid (f-droid.org). Open Termux:Boot once.
2. Save **`SekexBot_Setup.sh`** to the phone's **Download** folder.
3. Optional, for a zero-typing setup: fill in **`sekexbot-setup.conf`** (your Alpaca paper keys, daily limit, and `START_TRADING=yes`) and save it in **Download** too.
4. Open Termux, paste this one line and press Enter:

```
termux-setup-storage; until [ -r /sdcard/Download/SekexBot_Setup.sh ]; do sleep 2; done; bash /sdcard/Download/SekexBot_Setup.sh
```

Tap **Allow** when Android asks about files. The installer then runs by itself with no questions (10–40 minutes; keep the phone plugged in). It:

- installs Python and every library, compiling one if the phone needs it;
- installs SekexBot, the `sekex` command, start-on-boot and the home-screen buttons;
- applies `sekexbot-setup.conf` if present, then **deletes it** (it holds your keys);
- starts SekexBot, and starts the auto-trader on paper if you set `START_TRADING=yes`;
- runs a setup check (`sekex doctor --fix`) that opens the F-Droid page for any missing add-on and Termux's battery page;
- opens the dashboard.

Everything is logged to `~/sekexbot-install.log`.

**Bringing over what the PC bot learned (optional):** before step 4, make a folder named **`SekexBot_data`** in Download and copy the PC's `data` folder and `.env` file into it. The installer imports your keys, learning memory and trade journal (only if the phone has none yet). Delete that folder afterwards, since `.env` holds your keys.

## 2. Tell Android not to kill it (important)

Android closes background apps to save battery. Do all of these:

- **Settings → Apps → Termux → Battery → Unrestricted** (on some phones: "Don't optimize" or "No restrictions").
- Do the same for **Termux:API**.
- **Samsung:** Settings → Battery → Background usage limits → **Never sleeping apps** → add Termux.
- **Xiaomi / Redmi / POCO:** Security app → Permissions → **Autostart** → enable Termux; and set Battery saver → Termux → **No restrictions**.
- **OnePlus / Oppo / Realme:** Battery → App battery management → Termux → **Allow background activity**.
- Keep the **phone plugged in and on Wi-Fi** while it trades.
- Optional: Settings → Developer options → **Stay awake** (screen stays on while charging).

## 3. Start and stop with a tap (no typing)

**Home-screen buttons.** Long-press an empty spot on your home screen → **Widgets** → **Termux:Widget**. Drag the widget onto the screen. It lists four SekexBot buttons:

| Button | What it does |
|---|---|
| ▶ **SekexBot Start** | Starts SekexBot and opens the dashboard |
| ■ **SekexBot Stop** | Stops the auto-trader and closes the app |
| ℹ **SekexBot Status** | Pops up mode, state, today's P&L and battery |
| ▢ **SekexBot Open** | Opens the dashboard |

Want single icons instead? Long-press the **Termux:Widget** app icon → drag **SekexBot Start** and **SekexBot Stop** onto the home screen as their own shortcuts.

**The notification.** While SekexBot runs, its notification has **Open** and **Stop** buttons. After you stop it, the notification shows a **Start** button.

**The dashboard.** **▶ Start Auto-Trader** and **■ Stop** turn trading on and off while the app keeps running. **🔌 Turn off app** closes SekexBot completely; turn it back on with the home-screen Start button or the notification.

## 4. First start

```
sekex start
```

The dashboard opens in your browser at **http://127.0.0.1:8010**.

1. Tap **🔑 Broker keys**, paste your Alpaca **Paper** keys, then tap **Test connection** and **Save & connect**.
2. Set your **Daily max loss** and tap **▶ Start Auto-Trader**.
3. In Chrome, tap **⋮ → Add to Home screen** to get a SekexBot app icon.

A **SekexBot** notification stays in your notification bar. Tap it to open the dashboard.

## Layout and theme (⚙ gear, top right)

- **Tabs** (default on phones): **Auto · Manual · Positions · More** along the bottom. Auto has the big on/off switch, loss limit, controls, stock picker and activity. Manual has the order ticket, chart and AI read. Positions has every position, the journal and daily results. More holds Settings, Broker keys, Remote access, Update and Turn off app.
- **Auto | Manual**: one big switch under the header flips between the two sides; the gear opens Settings.
- **One page**: everything on one scrolling page, as before (default on a computer).
- **Theme**: Dark, Light, or Phone (follows the phone's setting).

A summary strip (equity, today's P&L, loss left, open trades) stays at the top in Tabs and Auto | Manual. Your choices are saved on each device.

## Paper or Live — and knowing which you're in

- **Tap the PAPER / LIVE badge** at the top to switch. Going Live needs your **Live PIN**, a tick on "I understand this trades real money", and working **live keys** (they're tested first). If the auto-trader is running it stops, switches and restarts by itself; open positions keep their stop-loss at Alpaca. 5 wrong PINs lock the switch for 15 minutes.
- **In Live mode you can't miss it:** a red frame around every screen with **● LIVE — REAL MONEY** at the top, a pulsing red badge, **LIVE ·** on every Buy/Sell button, a red phone status bar, and **🔴 LIVE** on alerts.
- **Account bar:** Balance, Today's P&L ($ and %), Open P&L, Buying power and Loss left are pinned under the header on every screen.
- **SIP data:** if your Alpaca account includes SIP, set **Controls → Data feed → SIP**. ⚙ → Help & repair → Run checks confirms it works.

## Manual trading (Buy / Sell / Close)

The dashboard's **Manual trade** ticket works like Alpaca's order screen:

| Field | Choices |
|---|---|
| Side | **Buy**, or **Sell** (shows **Short** when you don't hold the stock) |
| Order type | Market, Limit, Stop, Stop limit, Trailing stop (by % or $) |
| Quantity | Shares with − / + buttons, or a dollar amount |
| Limit / stop price | − / + buttons; tap the Bid or Ask to fill it in |
| Time in force | Good for day, Good 'til canceled, Immediate or cancel, Fill or kill, At the open, At the close |
| Trading session | Market hours (9:30–4), Extended hours (4 AM–8 PM), 24 Hour Market (Sun 8 PM–Fri 8 PM) |

**Interactive chart:** touch or drag on the trend chart for a **crosshair** — the readout shows the time, open/high/low/close, volume, **UPTREND / DOWNTREND**, the fast/slow lines and VWAP. **Tap** to pin a point, then move to measure the trend between the two points ($, %, time and ribbon flips). **Pinch** (or mouse-scroll) to zoom, drag with two fingers (or the mouse) to pan, **double-tap** to reset. Pick **1m / 3m / 5m / 15m** candles. The dashed blue line is VWAP; bars at the bottom are volume.

**Streaming prices:** with **Stream live prices** on (Controls, default), SekexBot keeps a live connection to Alpaca and pushes every price change to the app — the ticket, quick sheet and position P&L move tick by tick (badge: **STREAMING**; summary strip: **● Live**). It follows up to 30 symbols (your positions first, then the ticket, watchlist and top picks). The bot's extended-hours stops react within about a second. Alpaca's free plan allows **one** stream per account: if the PC version is running with the same keys, the phone falls back to polling (and Run checks tells you). Overnight prices always use polling.

**SIP vs IEX:** IEX is free but shows part of the market's trading; SIP (all exchanges) needs Alpaca's paid Algo Trader Plus plan. Switch in Controls → Data feed; **⚙ → Help & repair → Run checks** tells you whether SIP works on your account.

**Live price and cost:** the ticket and quick sheet show the price, the day's change (green/red), bid/ask and a **LIVE** dot, refreshing every 3 seconds, and the estimated cost as shares × price with your buying power. When the market is closed, the last trade or close is shown with its "as of" time, so you can always prepare an order; it fills when its session opens. The trend chart also shows the most recent session while the market is closed.

**Suggested stop-loss / take-profit:** tick **Attach stop-loss / take-profit** and SekexBot proposes three plans — **Scalp** (tight, 1.5R), **Day** (default, 2R) and **Swing** (wide, 2.5R). Stops sit just beyond real support (buy) or resistance (short), sized by the stock's volatility; targets are pulled in ahead of the next level. Each plan shows its R and a size that risks the same amount the bot would (15% of your daily limit) — tap **Use N sh** to apply it. It also says whether you're trading with or against the trend. These are level-based estimates, not predictions.

**Size presets:** the quick sheet has **$1k**, **$5k**, **1R risk** (what the bot risks per trade, with the suggested stop) and **Max** (25% of buying power).

**Double-tap to trade:** double-tap a stock in the Stock picker, the scanner chips or Positions. A quick trade sheet opens with the picker's suggested size (or your position size), − / + buttons, and big **BUY** and **SELL** (or **SHORT**) buttons. In market hours it sends a market order; in pre-market, after-hours or overnight it sends a limit order just past the ask or bid. A single tap still opens the chart, and **Open full order ticket** hands the stock to the full ticket.

The ticket only offers combinations Alpaca accepts. Extended hours and 24 Hour Market take **limit** orders only, Good for day or Good 'til canceled. For a 24 Hour order to keep working overnight, choose **Good 'til canceled**. In Market hours, a market or limit order can carry an optional **stop-loss / take-profit**, held at Alpaca. The ticket shows the estimated cost, your buying power, and when the order will start working if that session is closed now.

In **Positions & orders**, every position in the account is marked **YOU** or **BOT**. **Close** exits the whole position, **½** closes half, and **Cancel** removes an open order. Tap a symbol to load it into the ticket.

Rules:
- Manual positions are yours. The bot never enters a symbol you traded by hand that day, and never flattens your positions at the close.
- The daily loss halt still closes **everything** in the account, including manual positions.
- Extended hours: limit orders only (a market order is sent as a marketable limit), long only, and no stop-loss or take-profit.
- Closing half a position cancels its stop-loss and take-profit; set new ones if you want them.
- In LIVE mode every order and close asks for a confirmation marked LIVE MONEY.

## Alerts (🔔 bell, top right)

SekexBot tells you right away what happened, even with the app closed (needs the Termux:API app):

| Group | Alerts |
|---|---|
| Trades | Bot entries, fills, exits with P&L, stop raised to breakeven, rejected orders, your manual orders |
| Risk | Daily loss halt / profit lock, losing streak pause, broker restriction, stale overnight data, errors |
| Trend | For your watchlist: ribbon flip green/red, new high/low of day, VWAP reclaim/loss, volume spike |
| Price | "Tell me when SPCX goes above 150" — set in ⚙ → Alerts, or 🔔 in the quick trade sheet |
| Summary | End-of-day P&L, win rate and best setup at 4:05 PM ET |

Notifications have **Trade** (opens the quick trade sheet) and **Close** (closes the position) buttons. Turn each type on or off in **⚙ → Alerts**, set **quiet hours** (risk alerts still come through), and optionally copy alerts to the free **ntfy** app or **Telegram** to get them on another device. The 🔔 bell shows the history.

## 🛠 Help & repair (⚙ → Help & repair)

- **Run checks**: Alpaca connection, market data, wake lock, battery, storage, recent errors and rejections, updates.
- **One-tap fixes**: Reconnect Alpaca, Restart app, Repair install (re-installs libraries), Install update.
- **✨ Ask AI**: describe the problem or tap **🛠 Help** next to any order error — Claude explains it in plain steps using the checks and the recent log (keys removed). Needs a Claude API key.
- **Send report**: saves a support report (no keys) to Download and copies it, to send to your developer.

The app never rewrites its own code; real fixes arrive as updates. Some order errors are fixed automatically — for example, a stop-loss rejected while the market is closed is re-anchored on Alpaca's reference price and resent.

## Updating from the app

Tap **⬆ Update** at the top of the dashboard (on the phone itself):

- **Install from a file:** download the new `SekexBot_Android_vX.Y.Z.zip` to the phone, pick it, and tap **Install**.
- **Update link (one tap):** host the zip and `latest.json` (both made by `build_setup.sh`) on your site or a GitHub release, and paste the link to `latest.json` once. SekexBot checks every 6 hours, sends a notification when a new version is out, and installs it with one tap. Every download is checked against the SHA-256 in `latest.json`.
- **Publish in one command:** save the new zip from the chat to Downloads, open Termux and run `sekex publish`. First time it asks for your GitHub repo (public, for example `sekextrading-cloud/sekexbot-updates`) and a fine-grained token with Contents: Read and write on that repo. It stores them only on the phone, writes `latest.json` for you, uploads the zip first and `latest.json` last, and points the app's update link at it.

An update takes about a minute and keeps your keys, settings, learning memory and journal. Trading resumes by itself. Updates can't be started through Remote access.

## 5. Commands (optional; type these in Termux)

| Command | What it does |
|---|---|
| `sekex start` | Starts SekexBot in the background with a wake lock and auto-restart |
| `sekex stop` | Stops the auto-trader, then the app. Regular-hours stops stay at Alpaca. |
| `sekex status` | Shows mode, state, today's P&L, battery and warnings |
| `sekex open` | Opens the dashboard |
| `sekex log` | Shows the live log (Ctrl+C to quit) |
| `sekex restart` | Restarts the app. Trading resumes if it was running. |
| `sekex sim` | Runs the offline simulator (no keys needed) |
| `sekex backup` | Saves keys, learning memory and journal as a zip in Downloads |
| `sekex update <zip>` | Installs a newer SekexBot_Android zip and keeps your data |
| `sekex setup` | Re-runs the installer (repairs missing libraries) |
| `sekex doctor` | Checks the phone setup; `--fix` opens the screens that fix problems |
| `sekex trade-on` | Starts the auto-trader (same as the dashboard's Start button) |

## 6. What's different from the PC version

- **Auto-restart and auto-resume.** If SekexBot crashes or Android kills it, the watchdog restarts it within seconds. If the auto-trader was running, it **resumes by itself**. A Stop from the dashboard or `sekex stop` is remembered, so it won't restart trading you stopped on purpose. You can turn auto-resume off in **Controls**.
- **Nothing resets on a restart.** Open trades, today's loss-limit halt, the profit-lock peak and the losing-streak brakes are saved every tick and restored.
- **Starts when the phone boots**, through Termux:Boot. It waits 20 seconds for the network, then starts. Trading resumes only if it was running before.
- **After-hours and overnight trading start OFF.** Outside regular hours Alpaca holds no stop-loss for you. The app watches the stop itself, so if Android closes the app at night, that position is unprotected. You can switch them on in **Controls** if you accept that risk.
- **Phone status banner.** The dashboard shows battery, charging, temperature and wake lock, and warns you when the phone is on battery or hot.
- **🌐 Remote access** replaces "Phone access". You don't need it on the phone itself; it's only for checking the phone's bot from a laptop or tablet. It uses Termux's own `cloudflared` package.

## 7. Safety notes

- Regular-hours trades are **bracket orders**, so the stop-loss and take-profit sit on Alpaca's servers even if the phone dies.
- Your keys live in `~/sekexbot/.env` on the phone. Anyone who can open Termux on your unlocked phone can read them. Use a screen lock, and treat `sekex backup` zips as private.
- Run on **paper for several weeks** before going live. The simulator only checks the mechanics, not profitability.
- Use a dedicated Alpaca account. Hitting the daily limit closes **every** position in the account.
- Not financial advice. Automated trading can lose money.

## Troubleshooting

| Problem | Fix |
|---|---|
| Dashboard won't open | Run `sekex status`. If it says not running, run `sekex start`. Check `sekex log` for errors. |
| Bot stops overnight or when the screen is off | Recheck step 2 (battery settings), and make sure the banner says **wake lock on**. |
| "Package check failed" during install | Run `pkg update && pkg upgrade`, then `sekex setup` (or `bash install.sh` again). |
| No battery info in the banner | Install the **Termux:API** app from the same source as Termux. |
| Doesn't start after a reboot | Open the **Termux:Boot** app once, and give it Unrestricted battery too. |
| Remote access says cloudflared isn't installed | `pkg install cloudflared` |
| No SekexBot buttons in the widget | Install **Termux:Widget** from the same source as Termux, then run `sekex setup`. Remove and re-add the widget to refresh it. |
| Widget buttons do nothing, or no pop-up appears | Make sure Termux, Termux:API and Termux:Widget all came from the same source (all F-Droid). Give Termux and Termux:API Unrestricted battery, then run `sekex setup`. |


## Safety net setup (v1.21)
1. **Phone-offline alert:** sign up free at healthchecks.io → Add Check → Period **1 minute**, Grace **3 minutes** → Integrations: add email / SMS / ntfy / Telegram → copy the **ping URL** → SekexBot ⚙ → 🛡 Safety net → paste → Save → Test.
2. **Backups:** on by default every night at 8:10 PM ET, saved to Downloads/SekexBot/backups (run `termux-setup-storage` once so the app can write there).
3. **GitHub backups (optional):** GitHub → Settings → Developer settings → Fine-grained tokens → only your private repo → Repository permissions → **Contents: Read and write** → paste the repo (owner/name) and token in ⚙ → 🛡 Safety net.
4. **Restore:** stop the auto-trader, ⚙ → 🛡 Safety net → Restore… → pick a backup zip, then restart the app.

- **Auto-harvest (♻):** on a manual buy or short, the bot banks a small gain and gets back in on a pullback, repeatedly, until you tap Stop. Its own protective stop is 1.2 x the stock's normal 5-minute range. Extended-hours stops are watched by the app, so keep it open.
- **Reopen last close:** one tap under Positions puts back the position you last closed by hand.

## Trading levels
Controls > Trading level: Conservative (long only, regular hours), Balanced (longs + shorts, pre/after at half size), Aggressive (every ribbon flip, scalps), Max (everything on, largest size), Auto (learns the best of the first three per session from your trades), Custom (any change under Advanced). The daily max loss always applies.
