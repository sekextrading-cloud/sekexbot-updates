"""Trading levels: one-tap presets that set the many individual switches at once, plus 'Auto', which learns
which level works best in each session (pre-market / regular / after-hours) from your own trades.

The daily max loss is never touched by a level: it is the one hard limit."""
import json
import random
import threading
from datetime import datetime

from .config import DATA_DIR

ORDER = ["conservative", "balanced", "aggressive", "max"]

# Trading knobs a level sets. `sessions` (pre-market / after-hours on/off) is only applied when you pick a level yourself,
# never by Auto, which only chooses how hard to trade inside the sessions you have enabled.
LEVELS = {
    "conservative": dict(label="Conservative", blurb="Long only, regular hours, fewer and safer trades.",
                         allow_shorts=False, trade_all_flips=False, scalp_mode=False, aggressive_scalp=False, tod_filter=True,
                         cooloff_streak=True, cooloff_symbol=True, scale_out=True, ext_risk_mult=0.35, max_positions=2,
                         risk_per_trade_frac=0.10, sessions=dict(ext_premarket=False, ext_afterhours=False)),
    "balanced": dict(label="Balanced", blurb="Longs and shorts, strategy signals only, pre-market and after-hours at half size.",
                     allow_shorts=True, trade_all_flips=False, scalp_mode=False, aggressive_scalp=False, tod_filter=True,
                     cooloff_streak=True, cooloff_symbol=True, scale_out=True, ext_risk_mult=0.5, max_positions=4,
                     risk_per_trade_frac=0.15, sessions=dict(ext_premarket=True, ext_afterhours=True)),
    "aggressive": dict(label="Aggressive", blurb="Every ribbon flip, quick scalps, bigger extended-hours size.",
                       allow_shorts=True, trade_all_flips=True, scalp_mode=True, aggressive_scalp=False, tod_filter=True,
                       cooloff_streak=True, cooloff_symbol=True, scale_out=True, ext_risk_mult=0.75, max_positions=5,
                       risk_per_trade_frac=0.20, sessions=dict(ext_premarket=True, ext_afterhours=True)),
    "max": dict(label="Max", blurb="Everything on: every flip, fast scalping, no time-of-day filter, largest size. Daily loss limit still stops it.",
                allow_shorts=True, trade_all_flips=True, scalp_mode=False, aggressive_scalp=True, tod_filter=False,
                cooloff_streak=False, cooloff_symbol=True, scale_out=True, ext_risk_mult=1.0, max_positions=6,
                risk_per_trade_frac=0.25, sessions=dict(ext_premarket=True, ext_afterhours=True)),
}
AUTO_CANDIDATES = ["conservative", "balanced", "aggressive"]        # Auto never picks Max on its own
AUTO_DEFAULT = {"PRE": "balanced", "REGULAR": "balanced", "AFTER": "conservative", "OVERNIGHT": "conservative"}
MIN_TRADES = 8                                                      # trades per level per session before Auto trusts the average


def apply_level(settings, name, sessions=True):
    p = LEVELS[name]
    for k, v in p.items():
        if k in ("label", "blurb", "sessions"):
            continue
        setattr(settings, k, v)
    if sessions:
        for k, v in p["sessions"].items():
            setattr(settings, k, v)


class LevelStats:
    """Average R per trade for each (session, level), saved on the phone."""

    def __init__(self, path=None):
        self.path = path or (DATA_DIR / "level_stats.json")
        self.lock = threading.Lock()
        try:
            self.d = json.loads(self.path.read_text())
        except Exception:
            self.d = {}

    def record(self, sess, level, r):
        if level not in LEVELS:
            return
        with self.lock:
            a = self.d.setdefault(sess, {}).setdefault(level, [0, 0.0])
            a[0] += 1
            a[1] += float(r)
            try:
                self.path.write_text(json.dumps(self.d))
            except Exception:
                pass

    def table(self):
        out = {}
        for s, lv in self.d.items():
            out[s] = {k: {"n": v[0], "avg_r": round(v[1] / v[0], 3) if v[0] else 0.0} for k, v in lv.items()}
        return out

    def pick(self, sess, rng=random):
        """Return (level, why)."""
        row = self.d.get(sess, {})
        known = {k: v for k, v in row.items() if k in AUTO_CANDIDATES and v[0] >= MIN_TRADES}
        default = AUTO_DEFAULT.get(sess, "balanced")
        if known:
            best = max(known, key=lambda k: known[k][1] / known[k][0])
            avg = known[best][1] / known[best][0]
            if avg <= 0:
                return "conservative", f"no level is making money in {sess} yet, staying careful"
            untested = [k for k in AUTO_CANDIDATES if k not in known]
            if untested and rng.random() < 0.15:
                k = rng.choice(untested)
                return k, f"trying {k} for {sess} (best so far {best}, {avg:+.2f}R per trade)"
            return best, f"best in {sess}: {best}, {avg:+.2f}R per trade over {known[best][0]} trades"
        i = AUTO_CANDIDATES.index(default)
        near = [AUTO_CANDIDATES[j] for j in (i - 1, i + 1) if 0 <= j < len(AUTO_CANDIDATES)
                and row.get(AUTO_CANDIDATES[j], [0])[0] < MIN_TRADES]
        if near and rng.random() < 0.25:
            k = rng.choice(near)
            return k, f"learning: trying {k} for {sess}"
        return default, f"learning {sess}: starting with {default}"
