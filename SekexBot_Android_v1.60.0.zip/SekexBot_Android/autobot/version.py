"""SekexBot version. Bump this with every release and add an entry to CHANGELOG.md.

MAJOR.MINOR.PATCH:  MAJOR = breaking change (settings/data format), MINOR = new feature, PATCH = fix."""
__version__ = "1.60.0"
RELEASE_DATE = "2026-10-01"
