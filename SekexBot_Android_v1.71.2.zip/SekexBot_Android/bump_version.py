"""Bump SekexBot's version number everywhere at once.

    python bump_version.py patch "Fixed X"          1.8.0 -> 1.8.1
    python bump_version.py minor "Added Y"          1.8.0 -> 1.9.0
    python bump_version.py major "Breaking change"  1.8.0 -> 2.0.0
Updates autobot/version.py, VERSION, the README header and adds a CHANGELOG.md entry."""
import datetime
import re
import sys
from pathlib import Path

ROOT = Path(__file__).parent
part, note = (sys.argv[1] if len(sys.argv) > 1 else "patch"), (sys.argv[2] if len(sys.argv) > 2 else "")
vf = ROOT / "autobot" / "version.py"
src = vf.read_text()
cur = re.search(r'__version__ = "(\d+)\.(\d+)\.(\d+)"', src)
ma, mi, pa = map(int, cur.groups())
old = ".".join(cur.groups())
ma, mi, pa = {"major": (ma + 1, 0, 0), "minor": (ma, mi + 1, 0)}.get(part, (ma, mi, pa + 1))
new, today = f"{ma}.{mi}.{pa}", datetime.date.today().isoformat()
vf.write_text(re.sub(r'__version__ = ".*?"', f'__version__ = "{new}"',
                     re.sub(r'RELEASE_DATE = ".*?"', f'RELEASE_DATE = "{today}"', src)))
(ROOT / "VERSION").write_text(new + "\n")
rd = ROOT / "README.md"
rd.write_text(re.sub(r"\*\*Version [\d.]+\*\* \([\d-]+\)", f"**Version {new}** ({today})", rd.read_text(), count=1))
cl = ROOT / "CHANGELOG.md"
txt = cl.read_text()
i = txt.index("\n## ")
cl.write_text(txt[:i] + f"\n## {new} — {today}\n- {note or 'Changes'}\n" + txt[i:])
print(f"SekexBot {old} -> {new}")
