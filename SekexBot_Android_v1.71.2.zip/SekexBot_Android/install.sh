#!/data/data/com.termux/files/usr/bin/bash
# SekexBot - Android (Termux) installer.
#
#   bash install.sh          first install, or upgrade to a newer zip (keeps keys, settings,
#                            learning memory and trade journal)
#
# Installs the app into ~/sekexbot, the Python libraries into Termux, the `sekex` command,
# and (if Termux:Boot is installed) a script that starts SekexBot when the phone boots.
set -e

SRC="$(cd "$(dirname "$0")" && pwd)"
# where the setup file (and an optional sekexbot-setup.conf) was downloaded to
CONF_DIRS="${SEKEX_SETUP_DIR:-} $SRC $SRC/.. /sdcard/Download $HOME/storage/downloads"
# log everything, so a failed install can be diagnosed from one file
LOGF="$HOME/sekexbot-install.log"
if [ -z "$SEKEX_LOGGING" ]; then export SEKEX_LOGGING=1; bash "$0" "$@" 2>&1 | tee "$LOGF"; exit "${PIPESTATUS[0]}"; fi
APP="$HOME/sekexbot"
BIN="$PREFIX/bin"
VER="$(cat "$SRC/VERSION" 2>/dev/null || echo '?')"

say()  { printf '\n\033[1;32m==>\033[0m %s\n' "$*"; [ -n "$SEKEX_PROGRESS" ] && printf '%s|%s\n' "$(date +%s)" "$*" >> "$SEKEX_PROGRESS"; true; }
warn() { printf '\n\033[1;33m!!\033[0m %s\n' "$*"; }
die()  { printf '\n\033[1;31mXX\033[0m %s\n' "$*"; exit 1; }

[ -n "$PREFIX" ] && [ -d "$PREFIX" ] || die "This installer must run inside Termux on Android."
case "$(uname -m)" in aarch64|arm64|x86_64) ;; *) warn "Untested CPU type $(uname -m). 64-bit ARM phones are recommended." ;; esac

echo
echo "  SekexBot v$VER - Android edition installer"
echo "  App folder: $APP"

# In-app updates (dashboard -> Update) set SEKEX_QUICK=1: when every library is already installed,
# skip the slow package steps and only top up the Python libraries.
# Requirements stamp: a fingerprint of the library list and the package-install lines. An update whose stamp differs from
# the last install runs the FULL install (new Termux packages and libraries), so one update installs everything it needs.
STAMP_FILE="$HOME/.sekexbot/req.stamp"
STAMP_NEW="$( { cat "$SRC/requirements-android.txt"; grep -E '^ *(pkg install|pip install)' "$SRC/install.sh"; } 2>/dev/null | sha256sum | cut -d' ' -f1)"
STAMP_OLD="$(cat "$STAMP_FILE" 2>/dev/null || true)"
QUICK=0
if [ "${SEKEX_QUICK:-0}" = 1 ] && [ -n "$STAMP_OLD" ] && [ "$STAMP_OLD" != "$STAMP_NEW" ]; then
  say "This update needs new requirements: running the full install"
elif [ "${SEKEX_QUICK:-0}" = 1 ] && python -c "import alpaca, fastapi, uvicorn, pandas, numpy, pydantic, requests" 2>/dev/null; then
  QUICK=1
  say "Quick update: libraries already installed"
  PIP_DISABLE_PIP_VERSION_CHECK=1 pip install -q -r "$SRC/requirements-android.txt" || warn "Couldn't top up the libraries (continuing)"
fi
if [ $QUICK = 0 ]; then
# ---------- 1. system packages (fully non-interactive: never stops to ask a question) ----------
export DEBIAN_FRONTEND=noninteractive
mkdir -p "$PREFIX/etc/apt/apt.conf.d"
cat > "$PREFIX/etc/apt/apt.conf.d/99sekexbot-noninteractive" <<'APT'
APT::Get::Assume-Yes "true";
Dpkg::Options { "--force-confdef"; "--force-confold"; };
APT
say "Updating Termux packages (this can take a few minutes the first time)"
yes | pkg update -y >/dev/null 2>&1 || pkg update -y
yes | pkg upgrade -y -o Dpkg::Options::=--force-confold >/dev/null 2>&1 || true

say "Installing Python and tools"
pkg install -y python python-pip build-essential binutils-is-llvm termux-api tur-repo unzip >/dev/null \
  || pkg install -y python python-pip build-essential termux-api tur-repo unzip

say "Installing numpy and pandas (prebuilt Termux packages)"
pkg install -y python-numpy >/dev/null 2>&1 || pkg install -y python-numpy || true
pkg install -y python-pandas >/dev/null 2>&1 || true
if ! python -c "import pandas" 2>/dev/null; then
  warn "No prebuilt pandas package - building it from source (about 15-30 minutes, one time only)."
  pkg install -y cmake ninja libopenblas patchelf
  pip install setuptools wheel packaging pyproject_metadata cython meson-python versioneer
  PYV="$(python -c 'import sys;print(f"{sys.version_info.major}.{sys.version_info.minor}")')"
  python -c "import numpy" 2>/dev/null || MATHLIB=m LDFLAGS="-lpython$PYV" pip install --no-build-isolation --no-cache-dir numpy
  LDFLAGS="-lpython$PYV" pip install --no-build-isolation --no-cache-dir pandas
fi
python -c "import numpy, pandas" || die "numpy/pandas failed to install. Send a screenshot of the lines above."

say "Installing pydantic (the web server's data layer)"
pkg install -y python-pydantic-core >/dev/null 2>&1 || true
if ! pip install pydantic >/dev/null 2>&1; then
  warn "pydantic-core must be compiled on this phone (about 10-25 minutes, one time only). Keep Termux open."
  pkg install -y rust
  export ANDROID_API_LEVEL="$(getprop ro.build.version.sdk)"
  pip install pydantic || die "pydantic failed to build. Send a screenshot of the lines above."
fi

say "Installing SekexBot's libraries"
export PIP_DISABLE_PIP_VERSION_CHECK=1 PIP_NO_INPUT=1
pip install -r "$SRC/requirements-android.txt" || die "Library install failed. Check your internet and run  bash install.sh  again."

say "Installing cloudflared (optional: only for checking the bot from another device)"
pkg install -y cloudflared >/dev/null 2>&1 || warn "cloudflared not available - Remote access will be off. Everything else works."

python -c "import sys, alpaca, fastapi, uvicorn, pandas, numpy, requests, pydantic; print('  OK - Python', sys.version.split()[0], '- pandas', pandas.__version__)" \
  || die "Package check failed. Send a screenshot of this screen."

fi   # end of the full package install

# ---------- 2. app files (keep the user's data) ----------
say "Copying SekexBot into $APP"
mkdir -p "$APP"
if [ "$SRC" != "$APP" ]; then
  for f in autobot web assets bin tools server.py simulate.py bump_version.py requirements.txt requirements-android.txt \
           VERSION CHANGELOG.md README.md README_ANDROID.md .env.example install.sh docs; do
    [ -e "$SRC/$f" ] || continue
    rm -rf "$APP/$f"
    cp -r "$SRC/$f" "$APP/$f"
  done
  # bring over data/.env from a PC copy placed next to this installer (only if the phone has none yet)
  # (next to install.sh, or a "SekexBot_data" folder in Download next to SekexBot_Setup.sh)
  for D in "$SRC" "${SEKEX_SETUP_DIR:-/nonexistent}/SekexBot_data"; do
    [ -d "$D/data" ] && [ ! -d "$APP/data" ] && cp -r "$D/data" "$APP/data" && say "Imported your data folder (learning memory, trade journal)"
    [ -f "$D/.env" ] && [ ! -f "$APP/.env" ] && cp "$D/.env" "$APP/.env" && say "Imported your .env (broker keys)"
  done
fi
find "$APP" -name __pycache__ -type d -prune -exec rm -rf {} + 2>/dev/null || true
mkdir -p "$APP/data" "$HOME/.sekexbot"
[ -f "$APP/.env" ] && chmod 600 "$APP/.env"

# ---------- 2b. optional pre-filled settings: sekexbot-setup.conf ----------
CONF=""
for d in $CONF_DIRS; do [ -f "$d/sekexbot-setup.conf" ] && CONF="$d/sekexbot-setup.conf" && break; done
if [ -n "$CONF" ]; then
  say "Applying your settings from $(basename "$CONF")"
  python "$APP/bin/apply_setup_conf.py" "$CONF" "$APP" || warn "Some settings in $(basename "$CONF") couldn't be applied (see above)."
fi

# ---------- 3. the `sekex` command ----------
install -m 755 "$APP/bin/sekex" "$BIN/sekex"
say "Installed the  sekex  command"

# ---------- 4. start on boot (Termux:Boot app) ----------
mkdir -p "$HOME/.termux/boot"
cat > "$HOME/.termux/boot/10-sekexbot" <<'EOF'
#!/data/data/com.termux/files/usr/bin/sh
# Started by the Termux:Boot app when the phone turns on.
termux-wake-lock
sleep 20                 # let Wi-Fi/mobile data come up
sekex start --no-open
EOF
chmod 755 "$HOME/.termux/boot/10-sekexbot"

# ---------- 5. home-screen buttons (Termux:Widget app) ----------
# Scripts in ~/.shortcuts/tasks run in the background (no terminal window pops up).
mkdir -p "$HOME/.shortcuts/tasks" "$HOME/.shortcuts/icons"
rm -f "$HOME"/.shortcuts/tasks/SekexBot* "$HOME"/.shortcuts/icons/SekexBot*
mk() {   # mk <button name> <sekex args> <icon>
  printf '#!/data/data/com.termux/files/usr/bin/bash\n# SekexBot home-screen button\nsekex %s\n' "$2" > "$HOME/.shortcuts/tasks/$1"
  chmod 700 "$HOME/.shortcuts/tasks/$1"
  cp "$APP/assets/widget/$3.png" "$HOME/.shortcuts/icons/$1.png" 2>/dev/null || true
}
mk "SekexBot"        "start --gui"  launch      # ONE icon: starts the bot if needed, then opens the dashboard
mk "SekexBot Start"  "start --gui"  start
mk "SekexBot Stop"   "stop --gui"   stop
mk "SekexBot Status" "status --gui" status
mk "SekexBot Open"   "open"         open
chmod 700 "$HOME/.shortcuts" "$HOME/.shortcuts/tasks"
say "Added home-screen buttons: SekexBot (one-tap start + open) / Start / Stop / Status / Open (Termux:Widget)"

# ---------- 5b. support admin add-on (only on a phone that holds the admin key; every other phone skips this) ----------
if [ -f "$HOME/.sekexbot/admin.key" ]; then
  say "Updating the support admin add-on"
  python "$APP/bin/sekex_admin.py" sync || warn "Admin add-on update skipped"
fi
mkdir -p "$HOME/.sekexbot"; printf '%s' "$STAMP_NEW" > "$STAMP_FILE"

# ---------- 6. finish: start it, run the checklist, open the dashboard ----------
if [ "${SEKEX_NO_START:-0}" != 1 ]; then
  say "Starting SekexBot"
  bash "$BIN/sekex" restart || true   # restarts a running copy so the new code loads (trading resumes)
  if [ -f "$HOME/.sekexbot/autostart_trading" ]; then
    rm -f "$HOME/.sekexbot/autostart_trading"
    bash "$BIN/sekex" trade-on || true
  fi
  if [ "${SEKEX_QUIET:-0}" != 1 ]; then
    say "Checking the phone setup"
    bash "$BIN/sekex" doctor --fix || true
    bash "$BIN/sekex" open || true
  fi
fi

cat <<EOF

  ============================================================
   SekexBot v$VER is installed and running on this phone.

   Dashboard:   http://127.0.0.1:8010  (opened in your browser)
   Home screen: add the Termux:Widget widget for Start / Stop
   Checklist:   sekex doctor      All commands: sekex help
   Install log: $LOGF
  ============================================================

EOF
