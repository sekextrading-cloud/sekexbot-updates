"""Fast offline simulation: runs the real engine against synthetic market days.

    python simulate.py --days 20 --limit 200

Uses a separate data folder (data_sim/) so it never touches your real learner or journal."""
import argparse
import os
import sys
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

SIM_DIR = Path(__file__).parent / "data_sim"
os.environ["AUTOBOT_DATA"] = str(SIM_DIR)
if "--fresh" in sys.argv:
    for f in ("trades.db", "learner.json"):
        (SIM_DIR / f).unlink(missing_ok=True)

from autobot.config import Settings  # noqa: E402
from autobot.engine import Engine  # noqa: E402
from autobot.learner import Learner  # noqa: E402
from autobot.sim import SimBroker  # noqa: E402
from autobot import db  # noqa: E402

NY = ZoneInfo("America/New_York")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=10)
    ap.add_argument("--limit", type=float, default=200)
    ap.add_argument("--equity", type=float, default=25000)
    ap.add_argument("--shorts", action="store_true")
    ap.add_argument("--seed", type=int, default=7)
    ap.add_argument("--fresh", action="store_true", help="reset the simulated learner first")
    ap.add_argument("--no-ext", action="store_true", help="regular hours only")
    ap.add_argument("--aggro", action="store_true", help="aggressive scalping")
    ap.add_argument("--flips", action="store_true", help="trade every ribbon flip")
    ap.add_argument("--frac", action="store_true", help="small-account fractional mode")
    ap.add_argument("--pre", action="store_true", help="also trade pre-market")
    a = ap.parse_args()

    s = Settings()
    s.daily_max_loss, s.allow_shorts, s.tick_seconds = a.limit, a.shorts, 60
    s.ext_afterhours = s.ext_overnight = not a.no_ext
    s.ext_premarket = "--pre" in sys.argv
    s.ext_tick_seconds = 30
    s.fractional_on = a.frac
    if os.environ.get('SIM_CAP'):
        s.max_position_pct_equity = float(os.environ['SIM_CAP'])
    s.aggressive_scalp = "--aggro" in sys.argv
    s.trade_all_flips = a.flips
    learner = Learner()
    if a.fresh:
        learner.reset()
    start = datetime(2026, 9, 14, 9, 0, tzinfo=NY)  # a Monday
    broker = SimBroker(start, equity=a.equity, seed=a.seed)
    eng = Engine(s, broker, learner)
    eng.running = True
    eng.event("simulation start")

    from autobot.sessions import bot_day
    days_done, cur_day, day_start_eq = 0, bot_day(broker.now()), broker.account()["equity"]
    worst_day = 0.0
    while days_done < a.days:
        w = None
        try:
            w = eng.tick()
        except Exception:
            import traceback
            traceback.print_exc()
            sys.exit(1)
        broker.sleep(w or s.tick_seconds)
        bd = bot_day(broker.now())
        if bd != cur_day:
            eq = broker.account()["equity"]
            if datetime.fromisoformat(cur_day).weekday() < 5:
                pnl = eq - day_start_eq
                worst_day = min(worst_day, pnl)
                days_done += 1
                rows = [r for r in db.recent(5000) if r["status"] == "closed" and r["day"] == cur_day]
                by = {}
                for r in rows:
                    by.setdefault(r["bucket"] if r["bucket"] in ("AFTER", "OVERNIGHT", "PRE") else "REGULAR", []).append(r["pnl"])
                parts = "  ".join(f"{k}:{len(v)}t/{sum(v):+.0f}" for k, v in sorted(by.items()))
                print(f"{cur_day}  day P&L {pnl:+9.2f}  equity {eq:,.2f}  [{parts}]  "
                      f"{'HALTED: ' + eng.risk.halt_reason if eng.risk.halted else ''}")
            cur_day, day_start_eq = bd, eq

    closed = [r for r in db.recent(5000) if r["status"] == "closed"]
    tot = sum(r["pnl"] for r in closed)
    wins = sum(1 for r in closed if r["pnl"] > 0)
    print(f"\nTrades: {len(closed)}  Win rate: {100 * wins / max(1, len(closed)):.1f}%  Total P&L: {tot:+,.2f}")
    print(f"Worst day: {worst_day:+.2f} (daily limit {-a.limit:.2f})")
    sh = [r for r in closed if r["side"] == "sell"]
    print(f"Short trades: {len(sh)}  P&L {sum(r['pnl'] for r in sh):+,.2f}  (extended-hours shorts: {sum(1 for r in sh if r['bucket'] in ('PRE', 'AFTER'))})")
    from collections import Counter
    c = Counter((x["why"].split(" (")[0][:70]) for x in eng.skips)
    print(f"\nWhy-no-trade log: {len(eng.skips)} entries; top reasons:")
    for k, v in c.most_common(8):
        print(f"  {v:4d}  {k}")
    print("\nLeaderboard (what the bot learned):")
    for r in learner.leaderboard():
        print(f"  {r['strategy']:13s} {r['exit']:9s} n={r['trades']:5.1f} win={r['win_rate']:5.1f}% "
              f"avgR={r['avg_r']:+.2f} edge={r['edge']:+.3f} {'BENCHED' if r['benched'] else ''}")


if __name__ == "__main__":
    main()
