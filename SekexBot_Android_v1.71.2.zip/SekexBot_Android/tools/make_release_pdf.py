import re
from reportlab.lib.pagesizes import letter
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image,
                                KeepTogether, Preformatted)
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

import html as _html
import sys as _sys
from pathlib import Path as _P
ROOT = _P(__file__).resolve().parent.parent              # SekexBot_Android/
OUT_DIR = _P(_sys.argv[1]) if len(_sys.argv) > 1 else ROOT.parent
VER = (ROOT / "VERSION").read_text().strip()
_CL = (ROOT / "CHANGELOG.md").read_text(encoding="utf-8")
_ENTRIES = re.findall(r"^## (\d+\.\d+\.\d+)(?: — ([\d-]+))?[^\n]*\n(.*?)(?=^## |\Z)", _CL, re.S | re.M)
import datetime as _dt
_d = next((d for v, d, _ in _ENTRIES if v == VER and d), None)
DATE = _dt.date.fromisoformat(_d).strftime("%B %-d, %Y") if _d else _dt.date.today().strftime("%B %-d, %Y")


def _bullets(body):
    return [b.strip() for b in re.findall(r"^- (.+)$", body, re.M)]


def _vt(v):
    return tuple(int(x) for x in v.split("."))


def _clean(t):
    t = re.sub(r"\*\*(.+?)\*\*", r"<b>\1</b>", _html.escape(t, quote=False))
    for e in ("🤖", "📱", "🔑", "🛠", "✨", "🔔", "⚙", "⬆", "🔌", "⏻"):
        t = t.replace(e, "")
    t = re.sub("[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\uFE0F\u200D]", "", t)   # fonts lack emoji glyphs
    return t.replace("  ", " ").strip()


def _short(body, n=120):
    """One-line headline per release: 'Topic — first clause' for each topic in the entry."""
    text = re.sub(r"\s+", " ", " ".join(_bullets(body)) or body.strip())
    parts = re.split(r"(?<=\.)\s+(?=[A-Z][A-Za-z &/]{2,28}: )", text)
    heads = []
    for part in parts:
        m = re.match(r"^([A-Z][A-Za-z &/]{2,28}): (.*)$", part)
        heads.append(m.group(1) if m else re.split(r"[:;(—]|\. ", part)[0].strip())
    out = "; ".join(h for h in heads if h)
    return out if len(out) <= n else out[: n - 1].rsplit(" ", 1)[0] + "…"


F = "/usr/share/fonts/truetype/dejavu/"
pdfmetrics.registerFont(TTFont("Sans", F + "DejaVuSans.ttf"))
pdfmetrics.registerFont(TTFont("Sans-B", F + "DejaVuSans-Bold.ttf"))
pdfmetrics.registerFont(TTFont("Mono", F + "DejaVuSansMono.ttf"))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("Sans", normal="Sans", bold="Sans-B", italic="Sans", boldItalic="Sans-B")

INK, MUT, GREEN, LINE, CODEBG, WARN = (colors.HexColor(c) for c in
                                      ("#111827", "#4b5563", "#15803d", "#d1d5db", "#f3f4f6", "#fef3c7"))
st = {
    "title": ParagraphStyle("t", fontName="Sans-B", fontSize=20, leading=24, textColor=INK),
    "sub": ParagraphStyle("s", fontName="Sans", fontSize=10, leading=14, textColor=MUT),
    "h2": ParagraphStyle("h2", fontName="Sans-B", fontSize=13.5, leading=17, textColor=INK, spaceBefore=14, spaceAfter=6),
    "body": ParagraphStyle("b", fontName="Sans", fontSize=10, leading=14.5, textColor=INK, spaceAfter=6),
    "lead": ParagraphStyle("l", fontName="Sans", fontSize=11, leading=16, textColor=INK, spaceAfter=4),
    "cell": ParagraphStyle("c", fontName="Sans", fontSize=9.2, leading=12.5, textColor=INK),
    "cellb": ParagraphStyle("cb", fontName="Sans-B", fontSize=9.2, leading=12.5, textColor=INK),
    "code": ParagraphStyle("code", fontName="Mono", fontSize=8.6, leading=11.5, textColor=INK),
}
W = letter[0] - 1.5 * inch
P = lambda t, s="body": Paragraph(t, st[s])
C = lambda t: f'<font name="Mono" size="9">{t}</font>'


def code(text):
    t = Table([[Preformatted(text, st["code"])]], colWidths=[W])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), CODEBG), ("BOX", (0, 0), (-1, -1), 0.5, LINE),
                           ("LEFTPADDING", (0, 0), (-1, -1), 8), ("TOPPADDING", (0, 0), (-1, -1), 6),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
    return t


def steps(items):
    rows = [[P(f"<b>{i}</b>", "cellb"), x if not isinstance(x, str) else P(x, "cell")] for i, x in enumerate(items, 1)]
    t = Table(rows, colWidths=[0.3 * inch, W - 0.3 * inch])
    t.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP"), ("TEXTCOLOR", (0, 0), (0, -1), GREEN),
                           ("BOTTOMPADDING", (0, 0), (-1, -1), 5), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
    return t


def table(head, rows, widths):
    data = [[P(h, "cellb") for h in head]] + [[P(c, "cell") for c in r] for r in rows]
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, 0), CODEBG), ("LINEBELOW", (0, 0), (-1, 0), 0.8, INK),
                           ("LINEBELOW", (0, 1), (-1, -1), 0.4, LINE), ("VALIGN", (0, 0), (-1, -1), "TOP"),
                           ("TOPPADDING", (0, 0), (-1, -1), 5), ("BOTTOMPADDING", (0, 0), (-1, -1), 5)]))
    return t


def note(text, bg=WARN):
    t = Table([[P(text, "cell")]], colWidths=[W])
    t.setStyle(TableStyle([("BACKGROUND", (0, 0), (-1, -1), bg), ("LEFTPADDING", (0, 0), (-1, -1), 9),
                           ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7)]))
    return t


def footer(c, d):
    c.saveState()
    c.setFont("Sans", 8)
    c.setFillColor(MUT)
    c.drawString(0.75 * inch, 0.5 * inch, "SekexBot for Android · Update instructions · v1.10.0 · September 27, 2026")
    c.drawRightString(letter[0] - 0.75 * inch, 0.5 * inch, f"Page {d.page}")
    c.restoreState()



s = []
logo = Image(str(ROOT / "assets" / "icon-192.png"), 0.62 * inch, 0.62 * inch)
head = Table([[logo, [P("SekexBot for Android — Release Notes &amp; Install Guide", "title"),
                      P(f"Version {VER} · {DATE} · Runs entirely on your Android phone", "sub")]]],
             colWidths=[0.8 * inch, W - 0.8 * inch])
head.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("LEFTPADDING", (0, 0), (-1, -1), 0)]))
s += [head, Spacer(1, 12)]
s.append(P("SekexBot trades your Alpaca account automatically, and lets you trade by hand, from one app on your phone. "
           "It installs with one file and one command, restarts itself if Android closes it, and updates from inside the app.", "lead"))

s.append(P(f"What's new in {VER}", "h2"))
_top = next((body for v, d, body in _ENTRIES if v == VER), "")
_items = []
for bl in _bullets(_top) or [_top.strip()]:
    for part in re.split(r"(?<=\.)\s+(?=[A-Z][a-z]+(?: [a-z/&]+)?: )", bl):   # "Alerts: … Faster trading: …"
        _items.append(part)
_rows = []
for it in _items:
    m = re.match(r"^([^:]{2,28}):\s+(.*)$", it)
    _rows.append([_clean(m.group(1)), _clean(m.group(2)[:1].upper() + m.group(2)[1:])] if m else ["", _clean(it)])
s.append(table(["", "Change"], _rows, [1.2 * inch, W - 1.2 * inch]))

s.append(P("Release history (Android edition)", "h2"))
s.append(table(["Version", "Highlights"],
               [[v, _clean(_short(body))] for v, d, body in _ENTRIES if _vt(v) >= (1, 9, 0)],
               [0.9 * inch, W - 0.9 * inch]))

s.append(KeepTogether([P("What you need", "h2"), table(["Item", "Details"], [
    ["Phone", "64-bit Android, about 1.5 GB free, Wi-Fi, and a charger (keep it plugged in while it trades)."],
    ["Alpaca keys", "Paper Key ID and Secret (start with PK). Live keys and a Claude API key are optional."],
    ["4 free apps", "From <b>F-Droid</b> (f-droid.org), all from the same source: <b>Termux</b>, <b>Termux:API</b>, <b>Termux:Boot</b>, <b>Termux:Widget</b>. Don't use the Play Store Termux."],
    ["Files", f"<b>SekexBot_Setup.sh</b> for a new install; <b>SekexBot_Android_v{VER}.zip</b> for updating. Optional: <b>sekexbot-setup.conf</b>."],
], [1.1 * inch, W - 1.1 * inch])]))

s.append(P("New install", "h2"))
s.append(steps([
    "Install the four apps from F-Droid, and open <b>Termux:Boot</b> once.",
    "Save <b>SekexBot_Setup.sh</b> to the phone's <b>Download</b> folder.",
    "Optional, for zero typing: fill in <b>sekexbot-setup.conf</b> (paper keys, daily limit, START_TRADING=yes) and save it in Download too. It's deleted after the install, because it holds your keys.",
    [P("Open <b>Termux</b>, paste this one line, and press Enter:", "cell"), Spacer(1, 4),
     code("termux-setup-storage; until [ -r /sdcard/Download/SekexBot_Setup.sh ]; do sleep 2; done;\\\n  bash /sdcard/Download/SekexBot_Setup.sh")],
    "Tap <b>Allow</b> for file access. The installer then runs by itself (10–40 minutes the first time; keep the phone plugged in). It installs everything, applies your settings file, starts SekexBot, runs a setup check and opens the dashboard.",
]))
s.append(note("<b>Bring over what the PC bot learned (optional):</b> before step 4, make a folder named <b>SekexBot_data</b> in Download and copy the PC's <b>data</b> folder and <b>.env</b> file into it. Delete it afterwards."))

s.append(KeepTogether([P("Stop Android from closing SekexBot (do once)", "h2"), table(["Phone", "Setting"], [
    ["All phones", "Settings → Apps → Termux → Battery → <b>Unrestricted</b>. Same for Termux:API and Termux:Boot."],
    ["Samsung", "Settings → Battery → Background usage limits → <b>Never sleeping apps</b> → add Termux."],
    ["Xiaomi / Redmi / POCO", "Security → Permissions → <b>Autostart</b> → Termux on; Battery saver → Termux → <b>No restrictions</b>."],
    ["OnePlus / Oppo / Realme", "Battery → App battery management → Termux → <b>Allow background activity</b>."],
], [1.7 * inch, W - 1.7 * inch])]))
s.append(P(f"The setup check ({C('sekex doctor --fix')}) opens Termux's battery page for you and the F-Droid page for any missing add-on."))

s.append(P("First start", "h2"))
s.append(steps([
    "The dashboard opens at http://127.0.0.1:8010. In Chrome, tap <b>⋮ → Add to Home screen</b> for a SekexBot icon.",
    "If you didn't use the settings file: tap <b>⚙ → Broker keys</b>, paste your Paper keys, then <b>Test connection</b> and <b>Save &amp; connect</b>.",
    "On the <b>Auto</b> tab, set your <b>Daily max loss</b> and turn on the <b>Auto-trader</b> switch.",
    "For Start / Stop buttons on the home screen: long-press the home screen → Widgets → <b>Termux:Widget</b>.",
]))

s.append(P("Updating an existing install", "h2"))
s.append(table(["Your version", "How to update"], [
    ["1.12.0 or newer", "In the app: <b>⚙ → Update</b>. Pick the new zip from Download and tap Install, or paste your update link once and tap Install when a new version is announced."],
    ["1.11.0 or older", f"In Termux: {C('sekex update ~/storage/downloads/SekexBot_Android_v' + VER + '.zip')} (one time; after that, update from the app)."],
], [1.3 * inch, W - 1.3 * inch]))
s.append(P("An update takes about a minute and keeps your keys, settings, learning memory and journal. Trading resumes by itself. Regular-hours positions keep their stop-loss at Alpaca meanwhile."))

s.append(P("Using the app", "h2"))
s.append(table(["Area", "What it does"], [
    ["⚙ Layout", "<b>Tabs</b>: Auto · Manual · Positions · More at the bottom. <b>Auto | Manual</b>: one big switch under the header. <b>One page</b>: everything on one page."],
    ["⚙ Theme", "Dark, Light, or Phone (follows the phone's setting)."],
    ["Auto", "Auto-trader on/off, daily loss limit, sessions (regular, pre-market, after-hours, overnight), stock picker, bot positions, activity, what the bot learned."],
    ["Manual ticket", "Buy / Sell (Short), Market, Limit, Stop, Stop limit, Trailing stop; quantity in shares or $; Time in force (Day, GTC, IOC, FOK, At the open, At the close); session (Market hours, Extended hours, 24 Hour Market); optional stop-loss / take-profit."],
    ["Chart", "Touch or drag for a crosshair (time, OHLC, volume, trend, VWAP); tap to pin a point and measure the move; pinch to zoom, double-tap to reset; 1m / 3m / 5m / 15m."],
    ["Streaming", "Controls → Stream live prices: prices and P&amp;L update tick by tick (STREAMING badge). Free plan: one stream per account."],
    ["Double-tap", "Double-tap any stock in the picker, chips or positions: a quick sheet with the suggested size and BUY / SELL buttons."],
    ["Alerts", "The bell icon (top right) shows the history; ⚙ → Alerts turns types on/off, quiet hours, ntfy / Telegram, price alerts."],
    ["Help", "⚙ → Help &amp; repair: Run checks, one-tap fixes, Ask AI, Send report. Also Help next to any order error."],
    ["Positions", "Every position marked YOU or BOT, with Close, Close ½ and Cancel for orders; journal and daily results with totals."],
], [1.1 * inch, W - 1.1 * inch]))
s.append(P("Extended hours and 24 Hour Market take limit orders only. For a 24 Hour order to keep working overnight, choose <b>Good 'til canceled</b>. The bot never trades or flattens your manual positions; the daily-loss halt still closes everything in the account."))

s.append(KeepTogether([P("Termux commands (optional)", "h2"), table(["Command", "What it does"], [
    [C("sekex start"), "Start SekexBot (wake lock + auto-restart)"],
    [C("sekex stop"), "Stop the auto-trader, then the app"],
    [C("sekex status"), "Mode, state, today's P&amp;L (green/red), battery"],
    [C("sekex doctor --fix"), "Check the phone setup and open the fix screens"],
    [C("sekex update &lt;zip&gt;"), "Install a newer version, keeping your data"],
    [C("sekex backup"), "Zip keys, learning memory and journal to Download (keep it private)"],
    [C("sekex log"), "Live log (Ctrl+C to quit)"],
    [C("sekex close SYMBOL"), "Close a whole position"],
], [1.7 * inch, W - 1.7 * inch])]))

s.append(KeepTogether([P("Troubleshooting", "h2"), table(["Problem", "Fix"], [
    ["Dashboard won't open", f"Tap <b>SekexBot Start</b>, or run {C('sekex status')} and {C('sekex start')}."],
    ["Stops with the screen off", "Recheck the battery settings; the banner on the Auto tab should say <b>wake lock on</b>."],
    ["Install stops or fails", f"Run the same install line again, or {C('sekex setup')}. The log is {C('~/sekexbot-install.log')}."],
    ["Update seems stuck", f"Wait two minutes, then {C('sekex status')}. The log is {C('~/sekexbot-update.log')}."],
    ["Widget buttons missing", f"Install Termux:Widget from F-Droid, run {C('sekex setup')}, then re-add the widget."],
    ["No notifications", "Install Termux:API from F-Droid, allow its notifications, then ⚙ → Alerts → Send test alert."],
    ["An order error", "Tap <b>Help</b> next to it for a plain-language explanation."],
    ["Anything else", f"⚙ → Help &amp; repair → Run checks. Or send a screenshot of {C('sekex doctor')} and {C('sekex log')}."],
], [1.7 * inch, W - 1.7 * inch])]))

s.append(Spacer(1, 10))
s.append(note("<b>Safety:</b> run on paper for several weeks before going live; the simulator checks mechanics, not profitability. Use a dedicated Alpaca account. Gaps and slippage can push a loss past your limit. Your keys live on the phone; use a screen lock. Not financial advice — automated trading can lose money."))

doc = SimpleDocTemplate(str(OUT_DIR / f"SekexBot_Android_Release_Notes_and_Install_v{VER}.pdf"), pagesize=letter,
                        leftMargin=0.75 * inch, rightMargin=0.75 * inch, topMargin=0.7 * inch, bottomMargin=0.8 * inch,
                        title=f"SekexBot for Android — Release Notes & Install Guide (v{VER})", author="Thai Smith")
def footer2(c, d):
    c.saveState(); c.setFont("Sans", 8); c.setFillColor(MUT)
    c.drawString(0.75 * inch, 0.5 * inch, f"SekexBot for Android · Release notes & install guide · v{VER} · {DATE}")
    c.drawRightString(letter[0] - 0.75 * inch, 0.5 * inch, f"Page {d.page}"); c.restoreState()
doc.build(s, onFirstPage=footer2, onLaterPages=footer2)
print("ok")
