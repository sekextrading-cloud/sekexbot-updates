"""Replay one stock and day through SekexBot's strategies and print when each would have fired.
    python tools/replay.py SPCX 2026-09-28            (or: sekex replay SPCX 2026-09-28)
Uses your Alpaca data (SIP recommended). Only strategies are replayed, no orders are sent."""
import sys
from datetime import date, datetime, time, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from autobot.config import Settings, api_keys  # noqa: E402
from autobot.indicators import enrich, ribbon_state  # noqa: E402
from autobot.strategies import find_signals  # noqa: E402


def main():
    sym = (sys.argv[1] if len(sys.argv) > 1 else "SPCX").upper()
    day = date.fromisoformat(sys.argv[2]) if len(sys.argv) > 2 else date.today()
    s = Settings.load()
    from autobot.broker import AlpacaBroker
    k, sec = api_keys(s.live)
    b = AlpacaBroker(k, sec, paper=not s.live, feed=s.data_feed)
    hist = b.history([sym], days=(date.today() - day).days + 6).get(sym)
    if hist is None or hist.empty:
        print("No data. Check the ticker/date and your data feed.")
        return
    d0 = hist[hist.index.date == day]
    reg = d0[(d0.index.time >= time(9, 30)) & (d0.index.time < time(16, 0))]
    pre = d0[d0.index.time < time(9, 30)]
    prev = hist[(hist.index.date < day) & (hist.index.time >= time(9, 30)) & (hist.index.time < time(16, 0))]
    gap = 100 * (float(reg["open"].iloc[0]) - float(prev["close"].iloc[-1])) / float(prev["close"].iloc[-1]) if len(prev) and len(reg) else 0.0
    e = enrich(reg)
    print(f"{sym} {day}  gap {gap:+.2f}%  open {reg['open'].iloc[0]:.2f}")
    ctx0 = {"aggressive": False, "bias": 0, "shorts": True, "index_symbols": set(), "gap": {sym: gap}, "all_flips": s.trade_all_flips,
            "morning_reversal": True}
    seen = {}
    for i in range(6, len(reg) + 1):
        sl = e.iloc[:i]
        src = reg.iloc[:i] if not len(pre) else __import__("pandas").concat([pre.tail(120), reg.iloc[:i]])
        ctx = dict(ctx0, ribbon={sym: ribbon_state(src)})
        for sg in find_signals({sym: sl}, ctx):
            key = sg.strategy
            t = sl.index[-1]
            if key in seen and (t - seen[key]) < timedelta(minutes=15):
                continue
            seen[key] = t
            print(f"  {t.strftime('%H:%M')}  {sg.strategy:16s} {'SHORT' if sg.side == 'sell' else 'LONG ':5s} entry {sg.entry:.2f}  stop {sg.stop:.2f}")


main()
