"""Cloudflare Tunnel manager - reach the dashboard from your phone without opening router ports.

Two modes:
  quick   - `cloudflared tunnel --url http://127.0.0.1:PORT`: no Cloudflare account needed,
            gives a random https://xxxx.trycloudflare.com address that changes every restart.
  token   - `cloudflared tunnel run --token ...`: a named tunnel from your Cloudflare dashboard
            (Zero Trust -> Networks -> Tunnels) with a permanent hostname on your own domain,
            e.g. https://bot.sekexpro.com.
cloudflared is downloaded automatically into ./tools the first time (about 50 MB)."""
import os
import platform
import re
import shutil
import stat
import subprocess
import threading
from collections import deque

import requests

from .android import IS_ANDROID
from .config import BASE_DIR

TOOLS = BASE_DIR / "tools"
REL = "https://github.com/cloudflare/cloudflared/releases/latest/download/"
URL_RE = re.compile(r"https://[a-z0-9-]+\.trycloudflare\.com")


def _asset():
    sysname, mach = platform.system(), platform.machine().lower()
    arm = mach in ("arm64", "aarch64")
    if sysname == "Windows":
        return "cloudflared-windows-amd64.exe", "cloudflared.exe", False
    if sysname == "Darwin":
        return ("cloudflared-darwin-arm64.tgz" if arm else "cloudflared-darwin-amd64.tgz"), "cloudflared", True
    return ("cloudflared-linux-arm64" if arm else "cloudflared-linux-amd64"), "cloudflared", False


class Tunnel:
    def __init__(self, port: int):
        self.port = port
        self.proc = None
        self.mode = ""
        self.url = ""
        self.state = "off"          # off | downloading | starting | connected | error
        self.error = ""
        self.log = deque(maxlen=60)
        self.lock = threading.Lock()

    # ---------- binary ----------
    def binary(self) -> str | None:
        if IS_ANDROID:     # Termux's packaged cloudflared is built for Android (DNS works); prefer it
            return shutil.which("cloudflared")
        _, local, _ = _asset()
        p = TOOLS / local
        if p.exists():
            return str(p)
        return shutil.which("cloudflared")

    def _download(self):
        if IS_ANDROID:
            raise RuntimeError("cloudflared isn't installed. In Termux run:  pkg install cloudflared  "
                               "(or run  sekex setup  again), then try again.")
        asset, local, tgz = _asset()
        TOOLS.mkdir(exist_ok=True)
        dest = TOOLS / local
        self.state = "downloading"
        tmp = TOOLS / (asset + ".part")
        with requests.get(REL + asset, stream=True, timeout=60) as r:
            r.raise_for_status()
            total = int(r.headers.get("content-length", 0)) or 1
            got = 0
            with open(tmp, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
                    got += len(chunk)
                    self.error = f"downloading cloudflared {got * 100 // total}%"
        if tgz:
            import tarfile
            with tarfile.open(tmp) as t:
                m = next(x for x in t.getmembers() if x.name.endswith("cloudflared"))
                with t.extractfile(m) as src, open(dest, "wb") as out:
                    out.write(src.read())
            tmp.unlink()
        else:
            tmp.replace(dest)
        dest.chmod(dest.stat().st_mode | stat.S_IEXEC)
        self.error = ""
        return str(dest)

    # ---------- control ----------
    def start(self, mode: str, token: str = "", hostname: str = ""):
        with self.lock:
            self.stop()
            self.mode, self.url, self.error = mode, "", ""
            self.log.clear()
            self.state = "starting"
        threading.Thread(target=self._run, args=(mode, token, hostname), daemon=True).start()

    def _run(self, mode, token, hostname):
        try:
            exe = self.binary() or self._download()
            self.state = "starting"
            if mode == "token":
                args = [exe, "tunnel", "--no-autoupdate", "run", "--token", token]
                self.url = ("https://" + hostname.replace("https://", "").strip("/")) if hostname else ""
            else:
                args = [exe, "tunnel", "--no-autoupdate", "--url", f"http://127.0.0.1:{self.port}"]
            flags = 0x08000000 if os.name == "nt" else 0          # CREATE_NO_WINDOW
            self.proc = subprocess.Popen(args, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                         bufsize=1, creationflags=flags)
            for line in self.proc.stdout:
                line = line.strip()
                if not line:
                    continue
                self.log.append(line[-300:])
                m = URL_RE.search(line)
                if m and mode == "quick":
                    self.url = m.group(0)
                if "Registered tunnel connection" in line or ("Connection" in line and "registered" in line):
                    self.state = "connected"
                if mode == "quick" and self.url and self.state != "connected" and "Registered" in line:
                    self.state = "connected"
                if "Unauthorized" in line or "Invalid tunnel secret" in line or "token" in line.lower() and "invalid" in line.lower():
                    self.error = "Cloudflare rejected the tunnel token. Copy it again from Zero Trust → Tunnels."
            code = self.proc.wait()
            if self.state != "off":
                self.state = "error"
                self.error = self.error or f"cloudflared stopped (exit {code}). See the log below."
        except Exception as e:
            self.state = "error"
            self.error = f"Tunnel failed: {str(e)[:200]}"

    def stop(self):
        p, self.proc = self.proc, None
        self.state = "off"
        self.url = "" if self.mode == "quick" else self.url
        if p and p.poll() is None:
            p.terminate()
            try:
                p.wait(5)
            except Exception:
                p.kill()

    def status(self):
        running = bool(self.proc and self.proc.poll() is None)
        if not running and self.state in ("connected", "starting") and self.proc is not None:
            self.state = "error"
        return {"state": self.state, "mode": self.mode, "url": self.url, "error": self.error,
                "installed": bool(self.binary()), "log": list(self.log)[-12:]}
