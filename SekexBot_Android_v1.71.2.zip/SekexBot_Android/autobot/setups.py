"""🎯 Setting up now: find stocks likely to make a fast move SOON, before it happens.

For every scanned stock (top picks + watchlist) on 1-minute bars it measures:
  coil      - how tight the last 20-30 minutes are vs. the stock's normal 1-min range (energy building)
  volume    - is volume building in the last 5 minutes vs. the last 20
  pressure  - which way it leans: side of VWAP, ribbon colour, lower highs / higher lows, distance to the range edge
  range     - how big the stock's daily moves are (ATR %) - a flush in TSLA is worth more than in KO
It predicts the likely direction, the trigger price (range break), the expected move and a 0-100 readiness score.
Scores are a ranking, not a probability of profit."""


def _clip(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def rank_setups(bars: dict, ribbons: dict, scan_info: list, index_symbols=(), top=15) -> list:
    info = {r["symbol"]: r for r in (scan_info or [])}
    out = []
    for sym, d in bars.items():
        if sym in index_symbols or d is None or len(d) < 30:
            continue
        try:
            last = d.iloc[-1]
            a1 = float(last["atr"])
            if a1 <= 0:
                continue
            c = float(last["close"])
            w = d.iloc[-25:-1]
            hi, lo = float(w["high"].max()), float(w["low"].min())
            rng = hi - lo
            coil = _clip(1 - (rng / a1 - 2) / 6)                   # range of ~2 ATR = very coiled, 8+ ATR = none
            v5 = float(d["volume"].iloc[-5:].mean())
            v20 = float(d["volume"].iloc[-25:-5].mean()) or 1.0
            vbuild = _clip((v5 / v20 - 0.8) / 1.7)                  # 2.5x = max
            vwap = float(last["vwap"])
            rb = (ribbons or {}).get(sym) or {}
            rstate = rb.get("state", 0) if rb.get("ready") else 0
            highs = d["high"].iloc[-15:].values
            lows = d["low"].iloc[-15:].values
            lh = sum(highs[i] < highs[i - 5] for i in range(5, 15)) / 10     # lower highs share
            hl = sum(lows[i] > lows[i - 5] for i in range(5, 15)) / 10       # higher lows share
            bear = (c < vwap) * 0.3 + (rstate < 0) * 0.3 + lh * 0.25 + _clip((hi - c) / rng if rng else 0) * 0.15
            bull = (c > vwap) * 0.3 + (rstate > 0) * 0.3 + hl * 0.25 + _clip((c - lo) / rng if rng else 0) * 0.15
            side = "down" if bear > bull else "up"
            lean = abs(bull - bear)
            si = info.get(sym, {})
            atr_pct = si.get("atr_pct") or (a1 * 20 / c * 100)
            s_range = _clip((atr_pct - 1) / 5)
            edge = _clip(1 - (min(c - lo, hi - c) / rng) * 2) if rng else 0   # sitting near an edge of the range
            ready = 100 * (0.30 * coil + 0.22 * vbuild + 0.22 * _clip(lean * 2) + 0.14 * s_range + 0.12 * edge)
            trig = lo - 0.1 * a1 if side == "down" else hi + 0.1 * a1
            exp_move = max(2.5 * a1, rng)
            target = trig - exp_move if side == "down" else trig + exp_move
            why = []
            if coil > 0.6:
                why.append(f"tight {rng / a1:.1f}-ATR range")
            if vbuild > 0.4:
                why.append(f"volume building {v5 / v20:.1f}x")
            why.append("below VWAP" if c < vwap else "above VWAP")
            if rstate:
                why.append("ribbon " + ("red" if rstate < 0 else "green"))
            if side == "down" and lh > 0.5:
                why.append("lower highs")
            if side == "up" and hl > 0.5:
                why.append("higher lows")
            breaking = (c < trig) if side == "down" else (c > trig)
            if breaking:
                ready = min(100, ready + 10)
                trig = c
                target = c - exp_move if side == "down" else c + exp_move
            out.append({"symbol": sym, "status": "breaking" if breaking else "set", "price": round(c, 2), "side": side, "ready": int(round(ready)),
                        "trigger": round(trig, 2), "target": round(target, 2),
                        "move_pct": round(100 * exp_move / c, 2), "dist_pct": round(100 * abs(trig - c) / c, 2),
                        "range_hi": round(hi, 2), "range_lo": round(lo, 2), "watch": bool(si.get("watch")),
                        "why": ", ".join(why)})
        except Exception:
            continue
    out.sort(key=lambda r: r["ready"], reverse=True)
    return out[:top]


def rank_movers(bars: dict, ribbons: dict, moves: dict, index_symbols=(), watch=(), top=25) -> list:
    """Big movers vs the last regular close (pre-market gap, after-hours news, or the morning gap) with a plan:
       GO   - price is on the mover's side of VWAP and the ribbon agrees: ride it (long a gap-up, short a gap-down)
       FADE - price already lost VWAP against the move and the ribbon flipped: the gap is failing (short a gap-up)
       WAIT - mixed: wait for a break of the high or low."""
    watch = {w.upper() for w in (watch or ())}
    out = []
    for sym, mv in (moves or {}).items():
        d = bars.get(sym)
        if sym in index_symbols or d is None or len(d) < 8 or abs(mv) < 1.0:
            continue
        try:
            last = d.iloc[-1]
            a = float(last["atr"])
            if a <= 0:
                continue
            c, vwap = float(last["close"]), float(last["vwap"])
            rb = (ribbons or {}).get(sym) or {}
            rs = rb.get("state", 0) if rb.get("ready") else 0
            hi, lo = float(d["high"].max()), float(d["low"].min())
            up = mv > 0
            on_side = (c > vwap) if up else (c < vwap)
            rib_ok = (rs > 0) if up else (rs < 0)
            rib_against = (rs < 0) if up else (rs > 0)
            if on_side and rib_ok:
                plan, side = "GO", ("long" if up else "short")
            elif (not on_side) and rib_against:
                plan, side = "FADE", ("short" if up else "long")
            else:
                plan, side = "WAIT", ("long" if up else "short")
            long_ = side == "long"
            if plan == "FADE":
                trig = lo - 0.1 * a if side == "short" else hi + 0.1 * a        # the move is failing: trade the break back
            else:
                trig = hi + 0.1 * a if long_ else lo - 0.1 * a
            exp_move = max(3 * a, 0.5 * (hi - lo))
            target = trig + exp_move if long_ else trig - exp_move
            vb = 0.5
            if len(d) >= 25:
                v20 = float(d["volume"].iloc[-25:-5].mean()) or 1.0
                vb = _clip((float(d["volume"].iloc[-5:].mean()) / v20 - 0.8) / 1.7)
            ready = 100 * (0.5 * _clip(abs(mv) / 4) + 0.3 * (1.0 if plan != "WAIT" else 0.3) + 0.2 * vb)
            why = [f"{mv:+.1f}% vs last close", "above VWAP" if c > vwap else "below VWAP"]
            if rs:
                why.append("ribbon " + ("green" if rs > 0 else "red"))
            if plan == "FADE":
                why.append("move is failing")
            trend = ("keeps dropping" if not up else "keeps rising") if plan == "GO" else ("move is failing" if plan == "FADE" else "mixed")
            out.append({"symbol": sym, "move": round(mv, 2), "price": round(c, 2), "plan": plan, "side": side, "trend": trend,
                        "trigger": round(trig, 2), "target": round(target, 2), "hi": round(hi, 2), "lo": round(lo, 2),
                        "vwap": round(vwap, 2), "ready": int(round(ready)), "watch": sym in watch, "why": ", ".join(why)})
        except Exception:
            continue
    out.sort(key=lambda r: (r["watch"], r["ready"]), reverse=True)
    out = sorted(out[:max(top, 1) * 3], key=lambda r: r["ready"], reverse=True)
    return out[:top]
