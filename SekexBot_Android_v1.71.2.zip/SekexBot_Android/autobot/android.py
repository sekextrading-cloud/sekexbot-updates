"""Android (Termux) edition helpers.

SekexBot runs on the phone inside Termux. Android can put apps to sleep or kill them to save
battery, so this module reports what the dashboard needs to warn about: whether we're on
Android, the battery level and charging state, and whether the wake lock is held."""
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

IS_ANDROID = bool(os.getenv("TERMUX_VERSION") or "com.termux" in os.getenv("PREFIX", "")
                  or Path("/system/build.prop").exists())
EDITION = "android" if IS_ANDROID else "desktop"

_batt = {"t": 0.0, "v": None}


def battery():
    """Battery %, charging state and temperature via Termux:API (cached 60 s). None if unavailable."""
    if not IS_ANDROID or not shutil.which("termux-battery-status"):
        return None
    if time.time() - _batt["t"] < 60:
        return _batt["v"]
    _batt["t"] = time.time()
    try:
        out = subprocess.run(["termux-battery-status"], capture_output=True, text=True, timeout=8).stdout
        d = json.loads(out)
        _batt["v"] = {"percent": d.get("percentage"), "plugged": d.get("plugged", "UNPLUGGED") != "UNPLUGGED",
                      "status": d.get("status", ""), "temp_c": d.get("temperature")}
    except Exception:
        _batt["v"] = None
    return _batt["v"]


def wake_lock_held() -> bool | None:
    """The start script writes this marker after `termux-wake-lock` succeeds."""
    if not IS_ANDROID:
        return None
    return Path(os.getenv("SEKEX_WAKELOCK_FILE", Path.home() / ".sekexbot" / "wakelock")).exists()


def health():
    if not IS_ANDROID:
        return None
    b = battery()
    warnings = []
    if wake_lock_held() is False:
        warnings.append("Wake lock is off. Android may pause the bot when the screen turns off. Start it with: sekex start")
    if b and not b["plugged"]:
        warnings.append(f"Phone is on battery ({b['percent']}%). Keep it plugged in while the bot trades.")
    if b and b.get("temp_c") and b["temp_c"] >= 45:
        warnings.append(f"Phone is hot ({b['temp_c']:.0f}°C). Android may throttle or kill background apps.")
    return {"battery": b, "wake_lock": wake_lock_held(), "api": bool(shutil.which("termux-battery-status")),
            "warnings": warnings}
