"""Self-fix: the bot reviews its own closed trades and moves toward what works.

For every setup (strategy, per session for pre/after-market) it looks at the last WINDOW closed trades:
  * losing setups are BENCHED: they may only take one small probe trade a day (half size) until the numbers recover
  * winning setups are PROMOTED: they rank first and get a bit more size (never above MAX_MULT)
Everything is read from the trade database, so it survives restarts. The daily max loss still caps everything."""
import json
import time
from datetime import date

from . import db
from .config import DATA_DIR

EXIT_EPOCH = "exits-1.53"     # bump when exit logic changes: older trades were closed under different rules and are not counted


def _epoch_day():
    """First day this exit logic ran. Trades before it are ignored so a setup isn't benched for the old exits' mistakes."""
    f = DATA_DIR / "tune_epoch.json"
    try:
        d = json.loads(f.read_text())
        if d.get("epoch") == EXIT_EPOCH:
            return d["day"]
    except Exception:
        pass
    day = date.today().isoformat()
    try:
        f.write_text(json.dumps({"epoch": EXIT_EPOCH, "day": day}))
    except Exception:
        pass
    return day

WINDOW, MIN_N = 12, 8
BENCH_AVG_R, BENCH_FAST_N, BENCH_FAST_R, BENCH_FAST_WIN = -0.15, 6, -0.30, 0.25
PROMOTE_AVG_R = 0.15
MAX_MULT, PROBE_MULT = 1.3, 0.25
SKIP = {"MANUAL"}
PROVEN_N, UNPROVEN_MULT, UNPROVEN_PROMOTED_MULT = 20, 0.35, 0.7


class Tuner:
    def __init__(self):
        self.stats, self.at = {}, 0.0
        self.probed = {}            # setup -> day of its last probe trade

    def refresh(self, force=False):
        if not force and time.time() - self.at < 45:
            return
        self.at = time.time()
        try:
            ep = _epoch_day()
            rows = [r for r in db.recent(600) if r.get("status") == "closed" and r.get("mode") != "SIM" and r.get("strategy") not in SKIP
                    and str(r.get("day") or "") >= ep]
        except Exception:
            return
        by = {}
        for r in rows:                                   # recent() is newest first
            by.setdefault(r["strategy"], []).append(r)
        out = {}
        for name, rs in by.items():
            w = rs[:WINDOW]
            n = len(w)
            rr = [float(x.get("r") or 0) for x in w]
            avg = sum(rr) / n
            win = sum(1 for x in rr if x > 0) / n
            state = "ok"
            if n >= MIN_N and avg <= BENCH_AVG_R or (n >= BENCH_FAST_N and avg <= BENCH_FAST_R and win <= BENCH_FAST_WIN):
                state = "benched"
            elif n >= MIN_N and avg >= PROMOTE_AVG_R and win >= 0.5:
                state = "promoted"
            out[name] = {"n": n, "avg_r": round(avg, 3), "win": round(win, 3), "pnl": round(sum(float(x.get("pnl") or 0) for x in w), 2), "state": state}
        self.stats = out

    def gate(self, name, day, proven_only=True):
        """Returns (allowed, size_multiplier, rank_multiplier, why)."""
        self.refresh()
        s = self.stats.get(name)
        n = s["n"] if s else 0
        young = proven_only and n < PROVEN_N          # not enough history yet: trade it small until it proves itself
        if not s or s["state"] == "ok":
            return True, (UNPROVEN_MULT if young else 1.0), 1.0, ""
        if s["state"] == "promoted":
            m = min(MAX_MULT, 1.0 + s["avg_r"])
            if young:
                m = UNPROVEN_PROMOTED_MULT
            return True, m, 1.0 + s["avg_r"], f"promoted ({s['n']} trades, {s['avg_r']:+.2f}R avg, {s['win'] * 100:.0f}% wins)"
        if self.probed.get(name) == day:
            return False, 0.0, 0.0, f"self-fix: benched ({s['n']} recent trades, {s['avg_r']:+.2f}R avg, {s['win'] * 100:.0f}% wins); today's probe trade already used"
        return True, PROBE_MULT, 0.2, f"probe: benched setup gets one half-size test trade today ({s['avg_r']:+.2f}R avg)"

    def used(self, name, day):
        s = self.stats.get(name)
        if s and s["state"] == "benched":
            self.probed[name] = day

    def table(self):
        self.refresh(True)
        order = {"promoted": 0, "ok": 1, "benched": 2}
        return sorted(({"setup": k, **v, "probed_today": False} for k, v in self.stats.items()), key=lambda x: (order[x["state"]], -x["avg_r"]))
