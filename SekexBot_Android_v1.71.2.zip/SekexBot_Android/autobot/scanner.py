"""Stock picker: finds the best candidates for THIS account.

Every candidate gets two scores:

  opportunity  - is something happening? gap, relative volume, a healthy daily range (ATR%),
                 trend / near a 20-day high or low, and whether it is a top mover today.
  fit          - can this account trade it well? With your daily loss limit and buying power,
                 how many shares would a normal-sized trade be, does the full risk budget fit
                 within the position cap, and is the stock liquid enough that your order
                 is a tiny slice of a typical minute's volume?

final score = opportunity x fit. A $2,000 account ends up with cheaper, liquid movers;
a $100,000 account can use high-priced leaders and needs deeper liquidity.
"""
import math

TYPICAL_STOP_ATR = 0.15      # typical intraday stop distance as a fraction of the daily ATR
MIN_SHARES = 3               # below this, position sizing gets too coarse

# Liquid names always checked, so the picker has good choices even on quiet days.
CORE = ["AAPL", "MSFT", "NVDA", "AMD", "TSLA", "META", "AMZN", "GOOGL", "NFLX", "AVGO", "PLTR", "SMCI", "MU",
        "INTC", "COIN", "MSTR", "HOOD", "SOFI", "RIVN", "LCID", "NIO", "F", "BAC", "C", "WFC", "JPM", "XOM", "OXY",
        "UBER", "SHOP", "SNAP", "PINS", "ROKU", "DKNG", "CCL", "AAL", "UAL", "DAL", "RBLX", "U", "AFRM", "UPST",
        "MARA", "RIOT", "CLSK", "ARM", "TSM", "QCOM", "ORCL", "CRM", "ADBE", "PYPL", "SQ", "DIS", "BA", "NKE",
        "WMT", "TGT", "COST", "LLY", "PFE", "MRNA", "CVS", "T", "VZ", "KO", "FCX", "CLF", "X", "AA", "GME", "AMC",
        "TQQQ", "SQQQ", "SOXL", "SOXS", "SPY", "QQQ", "IWM", "TNA", "LABU", "TSLL", "NVDL"]


def price_band(equity: float, buying_power: float, settings) -> tuple[float, float]:
    """Highest price at which the account can still hold MIN_SHARES within the per-position cap."""
    cap = max(buying_power, 0) * settings.max_position_pct_bp
    hi = min(settings.max_price, cap / MIN_SHARES) if cap > 0 else settings.max_price
    lo = settings.min_price
    return lo, max(lo, hi)


def _clip(x, a=0.0, b=1.0):
    return max(a, min(b, x))


def score_candidates(cands: list, acct: dict, settings, day_fraction: float | None = None) -> list:
    """cands: dicts with keys
         sym, price, prev_close, adv (avg daily shares), atr (daily $), sma20, hi20, lo20,
         today_vol (optional), spread_pct (optional), mover (bool), watch (bool)
    returns the scored list (best first) with a human-readable 'why'."""
    eq = float(acct.get("equity") or 0)
    bp = float(acct.get("buying_power") or eq)
    cap = bp * settings.max_position_pct_bp
    risk = float(settings.daily_max_loss) * settings.risk_per_trade_frac
    lo, hi = price_band(eq, bp, settings)
    out = []
    for c in cands:
        p, pc, atr, adv = c.get("price"), c.get("prev_close"), c.get("atr"), c.get("adv")
        if not p or not pc or not atr or not adv or p <= 0:
            continue
        watch = bool(c.get("watch"))
        if not watch and not (lo <= p <= hi):
            continue
        if not watch and adv < settings.min_prev_volume:
            continue
        if not watch and (c.get("spread_pct") or 0) > 0.6:
            continue

        # ---------- fit for this account ----------
        stop = max(TYPICAL_STOP_ATR * atr, 0.002 * p)
        sh_risk = math.floor(risk / stop) if stop > 0 else 0
        sh_cap = math.floor(cap / p) if cap > 0 else sh_risk
        shares = min(sh_risk, sh_cap)
        if shares < 1:
            continue
        use = (shares * stop) / risk if risk > 0 else 1.0           # share of the risk budget we can deploy
        per_min = adv / 390.0
        slice_ = shares / per_min if per_min > 0 else 9
        fit_liq = 1.0 if slice_ <= 0.05 else _clip(1 - (slice_ - 0.05) / 0.45)
        fit_gran = 1.0 if shares >= 10 else (0.8 if shares >= MIN_SHARES else 0.5)
        fit = _clip(0.4 + 0.6 * use) * fit_liq * fit_gran
        if fit < 0.15 and not watch:
            continue                                  # too thin / too big for this account

        # ---------- opportunity ----------
        gap = (p / pc - 1) * 100
        atr_pct = atr / p * 100
        s_gap = _clip(abs(gap) / 4, 0, 1.5)
        s_atr = 1.0 if 2 <= atr_pct <= 7 else (_clip(atr_pct / 2) if atr_pct < 2 else _clip(1 - (atr_pct - 7) / 8, 0.2))
        rvol = None
        if c.get("today_vol") and day_fraction and day_fraction > 0.02:
            rvol = c["today_vol"] / (adv * day_fraction)
        s_rvol = _clip(rvol / 2, 0, 1.5) if rvol is not None else 0.5
        s_trend = 0.0
        notes = []
        if c.get("hi20") and p >= c["hi20"] * 0.97:
            s_trend += 0.6
            notes.append("near 20-day high")
        elif c.get("lo20") and p <= c["lo20"] * 1.03:
            s_trend += 0.3
            notes.append("near 20-day low")
        if c.get("sma20"):
            s_trend += 0.4 if (p > c["sma20"]) == (gap >= 0) else 0.0
        dollar_vol = adv * p
        s_dv = _clip(math.log10(max(dollar_vol, 1)) / 9)          # ~$1B/day -> 1.0
        opp = 0.32 * s_gap + 0.22 * s_atr + 0.2 * s_rvol + 0.14 * _clip(s_trend) + 0.12 * s_dv + (0.15 if c.get("mover") else 0)

        score = opp * fit
        why = [f"gap {gap:+.1f}%", f"ATR {atr_pct:.1f}%"]
        if rvol is not None:
            why.append(f"RVOL {rvol:.1f}x")
        why += notes
        if c.get("mover"):
            why.append("top mover")
        why.append(f"~{shares} sh (${shares * p:,.0f})")
        if use < 0.6:
            why.append("capped by buying power")
        if fit_liq < 1:
            why.append("thin for your size")
        out.append({"symbol": c["sym"], "price": round(p, 2), "gap": round(gap, 2), "atr_pct": round(atr_pct, 2),
                    "rvol": round(rvol, 2) if rvol is not None else None, "shares": shares,
                    "position": round(shares * p, 0), "risk_use": round(use, 2), "fit": round(fit, 2),
                    "opportunity": round(opp, 2), "score": round(score, 3), "watch": watch,
                    "why": ", ".join(why)})
    out.sort(key=lambda r: (r["watch"], r["score"]), reverse=True)
    return out


def volume_day_fraction(minutes_since_open: float) -> float:
    """Rough share of a day's volume done after N minutes (front-loaded U-shape)."""
    if minutes_since_open <= 0:
        return 0.0
    m = min(minutes_since_open, 390) / 390
    return _clip(m ** 0.75)
