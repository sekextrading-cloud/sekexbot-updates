"""Early-warning "BUY?" / "SELL?" predictions for the trend ribbon.

The confirmed BUY/SELL on the chart only appears once the ribbon has changed colour, which is
after the move has started. This module watches the same ribbon for the signs that come BEFORE
a flip, and marks them as a heads-up:

  * the yellow (fast) line is closing in on the white (slow) line, candle after candle,
  * at that pace they would cross within a few candles,
  * price is already on the "wrong" side of the fast line and/or VWAP,
  * the slow line is flattening, and volume is picking up against the trend.

Each warning gets a confidence score (0-100). Every past warning on the chart is graded: a HIT
if the real flip followed within HORIZON candles, a MISS if it didn't. The hit rate is shown, so
you can see how much to trust it for each stock before you rely on it.

Predictions are display-only. The bot never places an order on a "BUY?" or "SELL?".
"""
import numpy as np
import pandas as pd

import json
import os
from pathlib import Path

from .indicators import ribbon, vwap

HORIZON = 6          # a warning counts as a hit if the real flip happens within 6 candles
MIN_CONF = 60        # below this the warnings were right less than half the time in testing, so they are hidden
MAX_ETA = 4.0        # the lines must be on course to cross within ~4 candles
MIN_BARS = 12

# Tuning (📊 Review my signals can change these, within these limits). Saved in data/predict_tune.json.
DEFAULTS = {"min_conf": 60, "max_eta": 4.0, "shrink": 0.65, "ext_penalty": 10}
LIMITS = {"min_conf": (50, 90), "max_eta": (1.5, 6.0), "shrink": (0.4, 0.85), "ext_penalty": (0, 30)}
_TUNE_FILE = Path(os.getenv("AUTOBOT_DATA", str(Path(__file__).resolve().parent.parent / "data"))) / "predict_tune.json"
_tune_cache = [None, 0.0]


def clamp_tune(t: dict) -> dict:
    out = dict(DEFAULTS)
    for k, (lo, hi) in LIMITS.items():
        if k in (t or {}):
            try:
                out[k] = min(hi, max(lo, float(t[k])))
            except (TypeError, ValueError):
                pass
    out["min_conf"] = int(round(out["min_conf"]))
    out["ext_penalty"] = int(round(out["ext_penalty"]))
    return out


def get_tune() -> dict:
    try:
        m = _TUNE_FILE.stat().st_mtime
        if _tune_cache[0] is None or m != _tune_cache[1]:
            _tune_cache[:] = [clamp_tune(json.loads(_TUNE_FILE.read_text())), m]
        return _tune_cache[0]
    except Exception:
        return dict(DEFAULTS)


def save_tune(t: dict) -> dict:
    t = clamp_tune(t)
    _TUNE_FILE.parent.mkdir(parents=True, exist_ok=True)
    _TUNE_FILE.write_text(json.dumps(t, indent=1))
    return t


def _vwap_on(h: pd.DataFrame, df1m: pd.DataFrame, tf_min: int) -> np.ndarray:
    """VWAP as of the end of each ribbon candle."""
    try:
        vw = vwap(df1m)
        ends = h.index + pd.Timedelta(minutes=tf_min) - pd.Timedelta(seconds=1)
        return vw.reindex(vw.index.union(ends)).ffill().reindex(ends).values
    except Exception:
        return np.full(len(h), np.nan)


def _score(side, eta, close, fast, vw, slow_slope, vol_ratio, against_candle, ext_session, ext_penalty=10):
    """side = -1 predicts SELL, +1 predicts BUY."""
    c = 40.0
    c += 20 if eta <= 1 else 14 if eta <= 2 else 8 if eta <= 3 else 3
    if (close - fast) * side > 0:          # price already crossed the fast line the new way
        c += 10
    if vw == vw and (close - vw) * side > 0:   # price on the new side of VWAP
        c += 10
    if slow_slope * side >= 0:             # slow line flattening / turning the new way
        c += 10
    if against_candle and vol_ratio >= 1.2:    # volume picking up against the old trend
        c += 10
    if ext_session:                        # thin pre-market / after-hours: less reliable
        c -= ext_penalty
    return int(max(5, min(95, round(c))))


def _why(side, close, fast, vw, slow_slope, vol_ratio, against_candle, eta):
    new = "up" if side > 0 else "down"
    old = "down" if side > 0 else "up"
    r = [f"The {old}trend is losing strength: the yellow line is closing in on the white line"
         f" and could cross in about {max(1, int(round(eta)))} candle{'s' if round(eta) > 1 else ''}."]
    if (close - fast) * side > 0:
        r.append(f"Price has already moved {'above' if side > 0 else 'below'} the yellow line.")
    if vw == vw:
        r.append(f"Price is {'above' if close >= vw else 'below'} today's average price (VWAP)"
                 + (", which supports the turn." if (close - vw) * side > 0 else ", which argues against the turn."))
    if slow_slope * side >= 0:
        r.append("The white line has stopped " + ("falling." if side > 0 else "rising."))
    if against_candle and vol_ratio >= 1.2:
        r.append(f"Volume is picking up on {'green' if side > 0 else 'red'} candles.")
    r.append(f"If it confirms, the ribbon turns {'green (BUY)' if side > 0 else 'red (SELL)'} and the trend is {new}.")
    return " ".join(r)


def predict(df1m: pd.DataFrame, tf_min: int = 3, h: pd.DataFrame | None = None, tune: dict | None = None) -> dict:
    """Returns {"preds": [...], "outlook": {...} | None, "stats": {...}} for a 1-minute bar frame.
    Each pred: i (candle index in the ribbon frame), t, side ("buy"/"sell"), conf, eta, price,
    outcome ("hit"/"miss"/"pending"), lead (candles early), edge ($ better than the confirmed flip), why."""
    T = clamp_tune(tune) if tune else get_tune()
    if h is None:
        h = ribbon(df1m, lines=False, tf=f"{tf_min}min")
    empty = {"preds": [], "outlook": None, "stats": {"hits": 0, "misses": 0, "pending": 0, "rate": None, "edge": None}}
    if h is None or len(h) < MIN_BARS:
        return empty
    fast, slow, st = h["fast"].values, h["slow"].values, h["state"].values
    a = h["atr"].replace(0, np.nan).bfill().ffill().values
    close, opn, vol = h["close"].values, h["open"].values, h["volume"].values
    vw = _vwap_on(h, df1m, tf_min)
    vavg = pd.Series(vol).rolling(10, min_periods=3).mean().shift(1).values
    gap = (fast - slow) / a                       # normalised distance, + when fast above slow
    n = len(h)
    preds, armed_run = [], None
    for i in range(3, n):
        s = st[i]
        if s == 0 or not (a[i] == a[i]):
            continue
        side = -s                                 # green ribbon -> watch for SELL, red -> BUY
        g0, g1, g2 = gap[i] * s, gap[i - 1] * s, gap[i - 2] * s   # >0 while the trend holds
        if not (g0 > 0 and g0 < g1 < g2):         # must be shrinking two candles in a row
            continue
        peak = np.nanmax(gap[max(0, i - 8):i + 1] * s)
        if not (peak > 0 and g0 <= T["shrink"] * peak):
            continue
        rate = g1 - g0
        eta = g0 / rate if rate > 0 else 99
        if eta > T["max_eta"]:
            continue
        # one warning per ribbon run, re-armed only if the previous one was clearly cancelled
        run_start = i
        while run_start > 0 and st[run_start - 1] == s:
            run_start -= 1
        if armed_run == run_start and preds and preds[-1]["i"] >= run_start:
            last = preds[-1]
            if i - last["i"] < 4 or gap[i] * s < gap[last["i"]] * s * 1.2:
                continue
        slow_slope = slow[i] - slow[i - 1]
        vr = (vol[i] / vavg[i]) if vavg[i] == vavg[i] and vavg[i] > 0 else 1.0
        against = (close[i] - opn[i]) * side > 0
        ts = h.index[i]
        hm = ts.hour * 60 + ts.minute
        ext = not (570 <= hm < 960)
        conf = _score(side, eta, close[i], fast[i], vw[i], slow_slope, vr, against, ext, T["ext_penalty"])
        if conf < T["min_conf"]:
            continue
        armed_run = run_start
        # grade it: did the real flip follow?
        outcome, lead, edge = "pending", None, None
        for k in range(i + 1, min(n, i + HORIZON + 1)):
            if st[k] == side:
                outcome, lead = "hit", k - i
                edge = round((close[k] - close[i]) * side, 4)   # >0 = got a better price than the confirmed flip
                break
            if st[k] == 0:
                continue
        if outcome == "pending" and n - 1 - i >= HORIZON:
            outcome = "miss"
        preds.append({"i": i, "t": ts.strftime("%H:%M"), "d": ts.strftime("%a %b %d"),
                      "side": "buy" if side > 0 else "sell", "conf": conf, "eta": round(float(eta), 1),
                      "price": round(float(close[i]), 4), "outcome": outcome, "lead": lead, "edge": edge,
                      "why": _why(side, close[i], fast[i], vw[i], slow_slope, vr, against, eta)})
    hits = [p for p in preds if p["outcome"] == "hit"]
    misses = sum(1 for p in preds if p["outcome"] == "miss")
    pend = [p for p in preds if p["outcome"] == "pending"]
    done = len(hits) + misses
    stats = {"hits": len(hits), "misses": misses, "pending": len(pend),
             "rate": round(100 * len(hits) / done) if done else None,
             "edge": round(float(np.mean([p["edge"] for p in hits])), 4) if hits else None,
             "lead": round(float(np.mean([p["lead"] for p in hits])), 1) if hits else None}
    outlook = None
    if pend and pend[-1]["i"] >= n - HORIZON and st[-1] != (1 if pend[-1]["side"] == "buy" else -1):
        p = pend[-1]
        outlook = {"side": p["side"], "conf": p["conf"], "eta": p["eta"], "t": p["t"], "why": p["why"],
                   "ago": n - 1 - p["i"]}
    return {"preds": preds, "outlook": outlook, "stats": stats}


def chip_status(df1m: pd.DataFrame, tf_min: int = 3) -> dict:
    """Short status for a watchlist chip: current trend plus any live warning."""
    h = ribbon(df1m, lines=False, tf=f"{tf_min}min")
    if h is None or len(h) < MIN_BARS:
        return {"ready": False, "state": 0, "outlook": None, "rate": None}
    r = predict(df1m, tf_min, h=h)
    return {"ready": True, "state": int(h["state"].iloc[-1]), "outlook": r["outlook"], "rate": r["stats"]["rate"],
            "graded": r["stats"]["hits"] + r["stats"]["misses"], "last": round(float(h["close"].iloc[-1]), 2)}
