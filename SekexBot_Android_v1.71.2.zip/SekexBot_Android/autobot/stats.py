"""📊 Trade stats: every round trip in your Alpaca account (bot AND manual), grouped by time of day.

Fills come from Alpaca's account activities (the source of truth, includes trades placed on the Alpaca
website or other apps). Fills are grouped per symbol from flat -> flat into one round trip. Bot trades
are recognised from the journal and labelled with their strategy."""
import time
from collections import defaultdict
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo

NY = ZoneInfo("America/New_York")

BUCKETS = [  # (name, start minute, end minute) in ET, by the time the trade was OPENED
    ("Overnight", 20 * 60, 24 * 60), ("Overnight", 0, 4 * 60), ("Pre-market", 4 * 60, 9 * 60 + 30),
    ("Morning", 9 * 60 + 30, 11 * 60 + 30), ("Midday", 11 * 60 + 30, 14 * 60),
    ("Afternoon", 14 * 60, 16 * 60), ("After-hours", 16 * 60, 20 * 60)]
ORDER = ["Pre-market", "Morning", "Midday", "Afternoon", "After-hours", "Overnight"]


def bucket(ts: datetime) -> str:
    m = ts.hour * 60 + ts.minute
    for name, a, b in BUCKETS:
        if a <= m < b:
            return name
    return "Overnight"


_cache = {}


def fetch_fills(broker, days=90):
    """All FILL activities for the last `days` days (paged). Cached 60 s."""
    key = (id(broker), days)
    c = _cache.get(key)
    if c and time.time() - c[0] < 60:
        return c[1]
    after = (datetime.now(NY) - timedelta(days=days)).date().isoformat()
    out, token = [], None
    for _ in range(40):
        params = {"after": after, "direction": "asc", "page_size": 100}
        if token:
            params["page_token"] = token
        rows = broker.trading.get("/account/activities/FILL", params) or []
        if not rows:
            break
        out += rows
        if len(rows) < 100:
            break
        token = rows[-1]["id"]
    fills = []
    for r in out:
        try:
            q = float(r["qty"]) * (1 if r["side"] == "buy" else -1)
            ts = datetime.fromisoformat(str(r["transaction_time"]).replace("Z", "+00:00")).astimezone(NY)
            fills.append({"symbol": r["symbol"], "qty": q, "price": float(r["price"]), "t": ts})
        except Exception:
            continue
    fills.sort(key=lambda f: f["t"])
    _cache[key] = (time.time(), fills)
    return fills


def round_trips(fills):
    """Group fills per symbol from flat to flat. Realised P&L uses average cost (like Alpaca)."""
    pos, avg, open_t, buy_t, maxq, pnl, cost = (defaultdict(float) for _ in range(7))
    open_t, trips = {}, []
    for f in fills:
        s, q, px = f["symbol"], f["qty"], f["price"]
        p = pos[s]
        if abs(p) < 1e-9:
            open_t[s], pnl[s], maxq[s], cost[s] = f["t"], 0.0, 0.0, 0.0
            avg[s] = px
        if p == 0 or (p > 0) == (q > 0):                # adding
            newp = p + q
            avg[s] = (avg[s] * abs(p) + px * abs(q)) / abs(newp)
            pos[s] = newp
            maxq[s] = max(maxq[s], abs(newp))
            cost[s] = max(cost[s], abs(newp) * avg[s])
            continue
        closing = min(abs(q), abs(p))                   # reducing / closing / flipping
        d = 1 if p > 0 else -1
        pnl[s] += (px - avg[s]) * closing * d
        pos[s] = p + q
        if abs(pos[s]) < 1e-9 or (pos[s] > 0) != (p > 0):
            trips.append({"symbol": s, "side": "long" if d > 0 else "short", "qty": maxq[s],
                          "entry": round(avg[s], 4), "exit": px, "opened": open_t[s], "closed": f["t"],
                          "pnl": round(pnl[s], 2), "cost": round(cost[s], 2)})
            left = pos[s]
            pos[s] = 0.0
            if abs(left) > 1e-9:                       # flipped: the rest opens a new trip
                pos[s], avg[s], open_t[s], pnl[s], maxq[s], cost[s] = left, px, f["t"], 0.0, abs(left), abs(left) * px
    return trips


def summarize(trips, journal=(), days=90, session=None):
    j = defaultdict(list)
    for r in journal:
        if r.get("status") == "closed" and r.get("opened_at"):
            j[r["symbol"]].append(r)
    for t in trips:
        t["bucket"] = bucket(t["opened"])
        t["hold_min"] = round((t["closed"] - t["opened"]).total_seconds() / 60, 1)
        t["pct"] = round(100 * t["pnl"] / t["cost"], 2) if t["cost"] else 0
        t["source"], t["strategy"] = "manual", ""
        for r in j.get(t["symbol"], []):
            try:
                ot = datetime.fromisoformat(r["opened_at"])
                ot = ot.astimezone(NY) if ot.tzinfo else ot.replace(tzinfo=NY)
            except Exception:
                continue
            if abs((ot - t["opened"]).total_seconds()) < 180:
                t["source"], t["strategy"] = "bot", r.get("strategy") or ""
                break
    sel = [t for t in trips if not session or t["bucket"] == session]

    def agg(rows):
        w = [r for r in rows if r["pnl"] > 0]
        lo = [r for r in rows if r["pnl"] < 0]
        gw, gl = sum(r["pnl"] for r in w), -sum(r["pnl"] for r in lo)
        return {"trades": len(rows), "pnl": round(sum(r["pnl"] for r in rows), 2),
                "win_rate": round(100 * len(w) / len(rows), 1) if rows else 0,
                "avg_win": round(gw / len(w), 2) if w else 0, "avg_loss": round(-gl / len(lo), 2) if lo else 0,
                "profit_factor": round(gw / gl, 2) if gl else (None if not gw else 99)}

    by_b = {b: agg([t for t in trips if t["bucket"] == b]) for b in ORDER}
    by_src = {s: agg([t for t in sel if t["source"] == s]) for s in ("bot", "manual")}
    strat = defaultdict(list)
    for t in sel:
        if t["strategy"]:
            strat[t["strategy"]].append(t)
    days_ = defaultdict(float)
    for t in sel:
        days_[t["closed"].date().isoformat()] += t["pnl"]

    def pub(t):
        return {**{k: v for k, v in t.items() if k not in ("opened", "closed")},
                "opened": t["opened"].strftime("%a %b %d %I:%M %p").replace(" 0", " "),
                "closed": t["closed"].strftime("%I:%M %p").lstrip("0"), "date": t["opened"].date().isoformat()}

    sel_sorted = sorted(sel, key=lambda t: t["pnl"])
    return {"days": days, "session": session or "All", "total": agg(sel), "by_bucket": by_b, "by_source": by_src,
            "by_strategy": {k: agg(v) for k, v in sorted(strat.items())},
            "daily": [{"day": d, "pnl": round(p, 2)} for d, p in sorted(days_.items())],
            "top_wins": [pub(t) for t in reversed(sel_sorted[-5:]) if t["pnl"] > 0],
            "top_losses": [pub(t) for t in sel_sorted[:5] if t["pnl"] < 0],
            "recent": [pub(t) for t in sorted(sel, key=lambda t: t["closed"], reverse=True)[:40]]}
