"""📰 Earnings and news awareness.

* Earnings: the free Nasdaq earnings calendar (no key). The bot skips a stock on the day it reports and,
  in after-hours / overnight, the evening before a pre-market report.
* News: Alpaca's news feed (included with your Alpaca keys). The bot skips a stock for 30 minutes after a
  risky headline (offering, halt, bankruptcy, delisting, investigation, reverse split...).
Both fail open: if a source is unreachable, trading continues and the dashboard says so."""
import re
import threading
import time
from datetime import date, datetime, timedelta
from zoneinfo import ZoneInfo

import requests

NY = ZoneInfo("America/New_York")
RISKY = re.compile(r"\b(offering|priced .*offering|halt(ed)?|bankrupt\w*|chapter 11|delist\w*|investigation|"
                   r"sec (charges|probe|subpoena)|going concern|reverse (stock )?split|dilut\w*|fraud|recall|"
                   r"guidance cut|lowers guidance|downgrade[sd]?|short report)\b", re.I)
UA = {"User-Agent": "Mozilla/5.0 (Linux; Android 14) SekexBot", "Accept": "application/json"}


class Events:
    def __init__(self):
        self.lock = threading.Lock()
        self._earn = {}          # date iso -> {SYM: 'pre'|'after'|'?'}
        self._earn_err = ""
        self._news = {}          # sym -> (fetched_at, [items])
        self.news_client = None
        self.news_err = ""

    def set_keys(self, key, secret):
        try:
            from alpaca.data.historical.news import NewsClient
            self.news_client = NewsClient(key, secret)
        except Exception as e:
            self.news_client, self.news_err = None, str(e)[:120]

    # ---------------- earnings ----------------
    def earnings_on(self, d: date) -> dict:
        k = d.isoformat()
        with self.lock:
            if k in self._earn:
                return self._earn[k]
        out = {}
        try:
            r = requests.get("https://api.nasdaq.com/api/calendar/earnings", params={"date": k}, headers=UA, timeout=12)
            rows = ((r.json().get("data") or {}).get("rows")) or []
            for row in rows:
                t = (row.get("time") or "").lower()
                out[(row.get("symbol") or "").upper()] = "pre" if "pre" in t else "after" if "after" in t else "?"
            self._earn_err = ""
        except Exception as e:
            self._earn_err = f"Earnings calendar unavailable: {str(e)[:100]}"
            return {}                      # don't cache a failure
        with self.lock:
            self._earn[k] = out
            for old in list(self._earn):
                if old < (d - timedelta(days=3)).isoformat():
                    self._earn.pop(old, None)
        return out

    def earnings_info(self, sym, now: datetime):
        """('today', 'pre'|'after'|'?') / ('next', 'pre') / None"""
        today = now.date()
        e = self.earnings_on(today).get(sym)
        if e:
            return ("today", e)
        nxt = today + timedelta(days=1 if today.weekday() < 4 else 7 - today.weekday())
        if now.hour >= 16 or now.hour < 4 or today.weekday() >= 5:
            e2 = self.earnings_on(nxt).get(sym)
            if e2 == "pre":
                return ("next", "pre")
        return None

    def earnings_text(self, sym, now):
        e = self.earnings_info(sym, now)
        if not e:
            return ""
        when = {"pre": "before the open", "after": "after the close", "?": "(time not given)"}[e[1]]
        return f"Earnings {'today' if e[0] == 'today' else 'next session'} {when}"

    # ---------------- news ----------------
    def news(self, sym, max_age=90, hours=24):
        with self.lock:
            c = self._news.get(sym)
        if c and time.time() - c[0] < max_age:
            return c[1]
        items = []
        if self.news_client is not None:
            try:
                from alpaca.data.requests import NewsRequest
                res = self.news_client.get_news(NewsRequest(symbols=sym, start=datetime.now(NY) - timedelta(hours=hours),
                                                            limit=10, include_content=False))
                data = getattr(res, "data", {}) or {}
                arts = data.get("news", []) if isinstance(data, dict) else list(res)
                for a in arts:
                    head = getattr(a, "headline", "") or ""
                    ts = getattr(a, "created_at", None)
                    ts = ts.astimezone(NY) if ts else None
                    items.append({"headline": head, "source": getattr(a, "source", ""), "url": getattr(a, "url", ""),
                                  "t": ts.strftime("%a %I:%M %p").replace(" 0", " ") if ts else "",
                                  "age_min": round((datetime.now(NY) - ts).total_seconds() / 60) if ts else None,
                                  "risky": bool(RISKY.search(head))})
                self.news_err = ""
            except Exception as e:
                self.news_err = f"News unavailable: {str(e)[:100]}"
        with self.lock:
            self._news[sym] = (time.time(), items)
        return items

    # ---------------- the bot's gate ----------------
    def block_reason(self, sym, now: datetime, session="REGULAR"):
        """Why the bot should NOT open a trade in `sym` right now, or ''."""
        try:
            e = self.earnings_info(sym, now)
            if e and e[0] == "today":
                return "earnings today"
            if e and e[0] == "next" and session in ("AFTER", "OVERNIGHT"):
                return "earnings before the next open"
        except Exception:
            pass
        try:
            for n in self.news(sym):
                if n["risky"] and n["age_min"] is not None and n["age_min"] <= 30:
                    return "risky news: " + n["headline"][:80]
        except Exception:
            pass
        return ""

    def info(self):
        return {"earnings_error": self._earn_err, "news_error": self.news_err, "news_on": self.news_client is not None}
