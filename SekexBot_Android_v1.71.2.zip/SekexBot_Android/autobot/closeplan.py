"""⏰ Close later: a plan to close one open position by itself, even with the dashboard closed.

A plan closes the WHOLE position at the first of:
  * a time you pick (e.g. 7:55 PM tonight, 4:00 AM pre-market, 9:30 AM open),
  * the trend turning against you (the 3-minute ribbon flips red for a long / green for a short),
  * price reaching your take-profit or stop price.
If it triggers while the market is shut (for example the weekend) it waits for the next session and
closes then. Outside regular hours it uses the same extended-hours limit orders as the Close button,
and re-prices every minute until the position is gone. Plans are saved to disk, so a restart keeps them.
"""
import json
import logging
import threading
import time
from datetime import datetime

from .indicators import ribbon_state
from .sessions import NY

log = logging.getLogger("autobot")
POLL = 10          # seconds between checks
RETRY = 60         # re-send a close that hasn't filled after this many seconds
MAX_TRIES = 12


class ClosePlans:
    def __init__(self, get_engine, close_fn, session_fn, quote_fn, alert_fn, path):
        self.get_engine, self.close_fn, self.session_fn = get_engine, close_fn, session_fn
        self.quote_fn, self.alert_fn, self.path = quote_fn, alert_fn, path
        self.lock = threading.Lock()
        self.plans = {}
        self._load()
        threading.Thread(target=self._loop, daemon=True, name="close-plans").start()

    # ---------- storage ----------
    def _load(self):
        try:
            self.plans = json.loads(self.path.read_text())
        except Exception:
            self.plans = {}

    def _save(self):
        try:
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self.plans, indent=1))
            tmp.replace(self.path)
        except Exception as e:
            log.warning("Could not save close plans: %s", e)

    # ---------- public ----------
    def set(self, sym, direction, at=None, on_flip=False, tp=None, sl=None):
        if not (at or on_flip or tp or sl):
            raise ValueError("Pick a time, the trend-flip option, or a price")
        if at:
            when = datetime.fromisoformat(at)
            if when.tzinfo is None:
                when = when.replace(tzinfo=NY)
            at = when.astimezone(NY).isoformat()
        for name, px in (("take-profit", tp), ("stop", sl)):
            if px is not None and px <= 0:
                raise ValueError(f"The {name} price must be above 0")
        with self.lock:
            self.plans[sym] = {"symbol": sym, "dir": direction, "at": at, "on_flip": bool(on_flip),
                               "tp": tp, "sl": sl, "created": time.time(), "state": "waiting",
                               "why": "", "sent_t": 0, "tries": 0, "msg": _describe(at, on_flip, tp, sl, direction),
                               "flip_seen": None}
            self._save()
        return self.plans[sym]

    def cancel(self, sym):
        with self.lock:
            p = self.plans.pop(sym, None)
            self._save()
        return p

    def list(self):
        with self.lock:
            return [dict(p) for p in self.plans.values()]

    # ---------- loop ----------
    def _loop(self):
        while True:
            time.sleep(POLL)
            try:
                e = self.get_engine()
                if not e or not self.plans:
                    continue
                pos = e.broker.positions()
                sess = self.session_fn(e)
                for p in self.list():
                    try:
                        self._step(e, p["symbol"], pos, sess)
                    except Exception as ex:
                        log.warning("close plan %s: %s", p["symbol"], ex)
            except Exception as ex:
                log.warning("close plans: %s", ex)

    def _update(self, sym, **kw):
        with self.lock:
            if sym in self.plans:
                self.plans[sym].update(kw)
                self._save()

    def _done(self, sym, msg):
        with self.lock:
            self.plans.pop(sym, None)
            self._save()
        e = self.get_engine()
        if e:
            e.event(f"⏰ {sym}: {msg}")

    def _step(self, e, sym, pos, sess):
        p = self.plans.get(sym)
        if not p:
            return
        held = pos.get(sym)
        d = p["dir"]
        if not held or held["qty"] * d <= 0:
            if p["state"] == "closing":
                self.alert_fn("exit", f"⏰ {sym} closed", f"Scheduled close filled ({p['why']})", sym,
                              f"{' '.join(sym)}. Scheduled close filled.")
                return self._done(sym, f"scheduled close filled ({p['why']})")
            return self._done(sym, "position already closed - plan removed")
        now = time.time()
        if p["state"] == "failed":
            return
        if p["state"] == "closing":
            if now - p["sent_t"] >= RETRY:
                self._send(e, sym, p, sess, retry=True)
            return
        why = self._trigger(e, sym, p, held, sess)
        if why:
            self._update(sym, why=why)
            self._send(e, sym, self.plans[sym], sess)

    def _trigger(self, e, sym, p, held, sess):
        d = p["dir"]
        if p["at"] and datetime.now(NY) >= datetime.fromisoformat(p["at"]):
            return "time " + datetime.fromisoformat(p["at"]).strftime("%a %I:%M %p").replace(" 0", " ")
        if (p["tp"] or p["sl"]) and sess != "CLOSED":
            bid, ask = self.quote_fn(e, sym, sess)
            mark = bid if d > 0 else ask
            if mark:
                if p["tp"] and (mark - p["tp"]) * d >= 0:
                    return f"take-profit {p['tp']:.2f} reached ({mark:.2f})"
                if p["sl"] and (mark - p["sl"]) * d <= 0:
                    return f"stop {p['sl']:.2f} hit ({mark:.2f})"
        if p["on_flip"] and sess != "CLOSED":
            df = (getattr(e, "raw", {}) or {}).get(sym)
            if df is None or len(df) < 60:
                try:
                    now = e.broker.now()
                    df = (e.broker.bars([sym], start=now.replace(hour=4, minute=0, second=0, microsecond=0)) or {}).get(sym)
                except Exception:
                    df = None
            if df is not None and len(df) >= 60:
                rb = ribbon_state(df)
                if rb.get("ready"):
                    against = rb["state"] == -d
                    # only a NEW flip counts: if the trend was already against you when you set the plan,
                    # wait for it to turn your way and back again
                    if p["flip_seen"] is None:
                        self._update(sym, flip_seen=bool(against))
                    elif against and not p["flip_seen"]:
                        return "trend turned " + ("down" if d > 0 else "up")
                    elif not against and p["flip_seen"]:
                        self._update(sym, flip_seen=False)
        return ""

    def _send(self, e, sym, p, sess, retry=False):
        if sess == "CLOSED":
            if p.get("msg") != "triggered - waiting for the market to open":
                self._update(sym, msg="triggered - waiting for the market to open")
            return
        tries = p["tries"] + 1
        try:
            notes = self.close_fn(e, sym)
        except Exception as ex:
            err = str(getattr(ex, "detail", "") or ex)[:200]
            self._update(sym, state="waiting" if tries < MAX_TRIES else "failed", tries=tries,
                         msg=f"close order refused ({err}); trying again", sent_t=time.time())
            if tries == 1 or tries >= MAX_TRIES:
                self.alert_fn("reject", f"⚠ Scheduled close of {sym} refused", err, sym,
                              f"{' '.join(sym)}. Scheduled close was refused.")
            # keep the trigger: next loop tries again (e.g. a short overnight waits for 4 AM pre-market)
            return
        self._update(sym, state="closing", tries=tries, sent_t=time.time(),
                     msg=f"closing ({p['why']})" + (f" · re-priced x{tries - 1}" if tries > 1 else ""))
        if not retry:
            self.alert_fn("exit", f"⏰ Closing {sym}", f"Scheduled close sent: {p['why']}. " + " ".join(notes or []), sym,
                          f"{' '.join(sym)}. Scheduled close sent.")


def _describe(at, on_flip, tp, sl, d):
    parts = []
    if at:
        parts.append("at " + datetime.fromisoformat(at).strftime("%a %I:%M %p").replace(" 0", " "))
    if on_flip:
        parts.append("if the trend turns " + ("down" if d > 0 else "up"))
    if tp:
        parts.append(f"at take-profit {tp:.2f}")
    if sl:
        parts.append(f"at stop {sl:.2f}")
    return "closes " + ", or ".join(parts)
