"""Login for remote (phone) access.

Requests that arrive through Cloudflare (they carry a CF-Connecting-IP header) or from any
non-local address must log in with the dashboard password. Requests from this device
(127.0.0.1) don't need to. The password is stored only as a salted PBKDF2 hash in .env."""
import base64
import hashlib
import hmac
import os
import secrets
import time

from .config import write_env

COOKIE = "sb_session"
SESSION_DAYS = 30
_fails: dict[str, list] = {}


def _secret() -> bytes:
    s = os.getenv("SESSION_SECRET", "")
    if not s:
        s = secrets.token_hex(32)
        write_env({"SESSION_SECRET": s})
    # changing the password invalidates every existing phone session
    return (s + os.getenv("DASH_PASSWORD_HASH", "")).encode()


def password_set() -> bool:
    return bool(os.getenv("DASH_PASSWORD_HASH"))


def set_password(pw: str):
    salt = secrets.token_bytes(16)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), salt, 200_000)
    write_env({"DASH_PASSWORD_HASH": base64.b64encode(salt).decode() + "$" + base64.b64encode(h).decode()})


def check_password(pw: str) -> bool:
    stored = os.getenv("DASH_PASSWORD_HASH", "")
    if "$" not in stored:
        return False
    salt_b64, h_b64 = stored.split("$", 1)
    h = hashlib.pbkdf2_hmac("sha256", pw.encode(), base64.b64decode(salt_b64), 200_000)
    return hmac.compare_digest(h, base64.b64decode(h_b64))


def make_session() -> str:
    exp = str(int(time.time()) + SESSION_DAYS * 86400)
    sig = hmac.new(_secret(), exp.encode(), hashlib.sha256).hexdigest()
    return f"{exp}.{sig}"


def valid_session(tok: str | None) -> bool:
    if not tok or "." not in tok:
        return False
    exp, sig = tok.split(".", 1)
    if not exp.isdigit() or int(exp) < time.time():
        return False
    return hmac.compare_digest(sig, hmac.new(_secret(), exp.encode(), hashlib.sha256).hexdigest())


def rate_limited(ip: str) -> bool:
    now = time.time()
    _fails[ip] = [t for t in _fails.get(ip, []) if now - t < 900]
    return len(_fails[ip]) >= 5


def record_fail(ip: str):
    _fails.setdefault(ip, []).append(time.time())


def is_remote(request) -> bool:
    if request.headers.get("cf-connecting-ip") or request.headers.get("cf-ray"):
        return True
    host = request.client.host if request.client else ""
    return host not in ("127.0.0.1", "::1", "localhost")


def client_ip(request) -> str:
    return request.headers.get("cf-connecting-ip") or (request.client.host if request.client else "?")
