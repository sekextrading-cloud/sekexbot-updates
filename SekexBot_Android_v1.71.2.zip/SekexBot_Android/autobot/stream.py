"""Streaming prices: Alpaca's real-time websocket (quotes + trades) instead of polling.

LiveFeed keeps the latest bid / ask / last trade for up to MAX_SYMBOLS symbols (Alpaca's free IEX
plan allows 30) and re-subscribes as the set of symbols you care about changes: open positions,
bot trades, the ticket you're looking at, your watchlist, the top stock-picker names.

If streaming isn't available (another app already uses the connection, no internet, overnight
session, simulator) everything falls back to the normal polling, so nothing breaks."""
import logging
import threading
import time

log = logging.getLogger("autobot")
MAX_SYMBOLS = 30


class LiveFeed:
    def __init__(self, key, secret, feed="iex"):
        self.key, self.secret, self.feed = key, secret, feed
        self.latest = {}                # sym -> {"bid","ask","last","qt","tt"}  (qt/tt = epoch secs)
        self.subs = set()
        self.want = []
        self.status = "starting"
        self.error = ""
        self.version = 0
        self.updates = 0
        self.lock = threading.Lock()
        self.ws = None
        self._stop = False
        threading.Thread(target=self._run, daemon=True, name="livefeed").start()
        threading.Thread(target=self._sync_loop, daemon=True, name="livefeed-subs").start()

    # ---------- data handlers ----------
    async def _on_quote(self, q):
        if not q.bid_price or not q.ask_price:
            return
        with self.lock:
            d = self.latest.setdefault(q.symbol, {})
            d.update(bid=float(q.bid_price), ask=float(q.ask_price), qt=time.time())
            self.version += 1
            self.updates += 1
        if self.status != "live":
            self.status = "live"

    async def _on_trade(self, t):
        with self.lock:
            d = self.latest.setdefault(t.symbol, {})
            d.update(last=float(t.price), tt=time.time())
            self.version += 1
            self.updates += 1
        if self.status != "live":
            self.status = "live"

    # ---------- connection ----------
    def _run(self):
        from alpaca.data.enums import DataFeed
        from alpaca.data.live import StockDataStream
        backoff = 5
        while not self._stop:
            try:
                self.status = "connecting"
                try:                                # never hold two sockets: Alpaca allows one per account
                    if self.ws:
                        self.ws.stop()
                except Exception:
                    pass
                self.ws = StockDataStream(self.key, self.secret,
                                          feed=DataFeed.SIP if self.feed == "sip" else DataFeed.IEX)
                self.subs = set()
                syms = self.want[:MAX_SYMBOLS] or ["SPY"]
                self.ws.subscribe_quotes(self._on_quote, *syms)
                self.ws.subscribe_trades(self._on_trade, *syms)
                self.subs = set(syms)
                self.status = "connected"
                t0 = time.time()
                self.ws.run()                       # blocks until the socket closes
                if time.time() - t0 > 120:
                    backoff = 5
            except Exception as e:
                msg = str(e)
                self.error = ("Another app is using your Alpaca data stream (the free plan allows one). "
                              "Prices fall back to polling." if "connection limit" in msg.lower() or "406" in msg
                              else msg[:160])
                log.info("Live price stream: %s", self.error)
            if self._stop:
                break
            self.status = "reconnecting"
            time.sleep(backoff)
            backoff = min(backoff * 2, 120)

    def _sync_loop(self):
        """Apply subscription changes every 2 s (adds and removes, capped at MAX_SYMBOLS)."""
        while not self._stop:
            time.sleep(2)
            ws = self.ws
            if not ws or self.status not in ("connected", "live"):
                continue
            want = set(self.want[:MAX_SYMBOLS])
            add, drop = want - self.subs, self.subs - want
            try:
                if drop and len(want):
                    ws.unsubscribe_quotes(*drop)
                    ws.unsubscribe_trades(*drop)
                    self.subs -= drop
                if add:
                    ws.subscribe_quotes(self._on_quote, *add)
                    ws.subscribe_trades(self._on_trade, *add)
                    self.subs |= add
            except Exception as e:
                log.debug("stream subscribe: %s", e)

    def set_symbols(self, ordered):
        """ordered: most important first; duplicates removed; capped at MAX_SYMBOLS."""
        seen, out = set(), []
        for s in ordered:
            s = (s or "").upper()
            if s and s not in seen and s.replace(".", "").isalpha():
                seen.add(s)
                out.append(s)
        self.want = out[:MAX_SYMBOLS]

    def stop(self):
        self._stop = True
        try:
            if self.ws:
                self.ws.stop()
        except Exception:
            pass

    # ---------- reading ----------
    def get(self, sym, max_age=20):
        d = self.latest.get(sym)
        if not d:
            return None
        now = time.time()
        q_ok = d.get("qt") and now - d["qt"] < max_age
        t_ok = d.get("tt") and now - d["tt"] < max(max_age, 120)
        if not q_ok and not t_ok:
            return None
        return {"bid": d.get("bid") if q_ok else None, "ask": d.get("ask") if q_ok else None,
                "last": d.get("last") or ((d["bid"] + d["ask"]) / 2 if q_ok else None),
                "age": round(now - max(d.get("qt") or 0, d.get("tt") or 0), 1)}

    def info(self):
        return {"status": self.status, "error": self.error if self.status != "live" else "",
                "symbols": len(self.subs), "updates": self.updates}


class SimFeed:
    """Simulator stand-in: 'streams' the simulated market by sampling it once a second."""
    def __init__(self, broker):
        self.broker, self.latest, self.want, self.version, self.updates = broker, {}, [], 0, 0
        self.status, self.error, self.subs = "live", "", set()
        threading.Thread(target=self._run, daemon=True, name="simfeed").start()

    def _run(self):
        while True:
            time.sleep(1)
            try:
                syms = self.want[:MAX_SYMBOLS]
                q = self.broker.quotes(syms, "REGULAR")
                now = time.time()
                for s, (b, a, _) in q.items():
                    self.latest[s] = {"bid": b, "ask": a, "last": (b + a) / 2, "qt": now, "tt": now}
                self.subs = set(q)
                self.version += 1
                self.updates += len(q)
            except Exception:
                pass

    set_symbols = LiveFeed.set_symbols
    get = LiveFeed.get
    info = LiveFeed.info

    def stop(self):
        pass
