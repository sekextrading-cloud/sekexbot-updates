"""Learn from YOUR manual trades: pair your filled orders into round trips, then work out what you actually do when you
win (how big a gain you bank, how fast), what your losers look like, and how you get back in. The result suggests a
'harvest %' and a stop size, and can drive the bot's Harvest small % mode automatically.

Only trades YOU opened count (orders the bot placed carry 'ab-' / 'abx-' ids and are skipped)."""
import statistics as st
import time
from zoneinfo import ZoneInfo
from collections import defaultdict, deque
from datetime import timedelta

BOT_PREFIXES = ("ab-", "abx-")
MIN_TRIPS_AUTO = 15
NY = ZoneInfo("America/New_York")


def fetch_fills(broker, days=60):
    """Filled orders from Alpaca, oldest first: dicts sym, side, qty, px, t (aware datetime), cid."""
    from alpaca.trading.enums import QueryOrderStatus
    from alpaca.trading.requests import GetOrdersRequest
    since = broker.now() - timedelta(days=days)
    out, seen = [], set()
    after = since
    for _ in range(12):                                   # up to ~6000 orders
        orders = broker.trading.get_orders(GetOrdersRequest(status=QueryOrderStatus.CLOSED, after=after, nested=True,
                                                            limit=500, direction="asc"))
        if not orders:
            break
        newest = after
        for o in orders:
            for x in [o] + list(o.legs or []):
                if str(x.id) in seen or not x.filled_avg_price or not x.filled_at or float(x.filled_qty or 0) <= 0:
                    continue
                seen.add(str(x.id))
                side = str(x.side.value if hasattr(x.side, "value") else x.side)
                out.append({"sym": x.symbol, "side": side, "qty": float(x.filled_qty), "px": float(x.filled_avg_price),
                            "t": x.filled_at, "cid": str(x.client_order_id or "")})
            if o.submitted_at and o.submitted_at > newest:
                newest = o.submitted_at
        if len(orders) < 500 or newest <= after:
            break
        after = newest
    out.sort(key=lambda f: f["t"])
    return out


def round_trips(fills):
    """FIFO-pair fills per symbol into closed round trips. Keeps only trips whose opening fill was not the bot's."""
    books = defaultdict(deque)          # sym -> deque of [signed_qty, px, t, bot]
    trips = []
    last_close = {}                     # (sym, dir) -> (t, px)
    for f in fills:
        sgn = 1 if f["side"] == "buy" else -1
        qty, bot = f["qty"], str(f.get("cid", "")).startswith(BOT_PREFIXES)
        book = books[f["sym"]]
        while qty > 1e-9 and book and book[0][0] * sgn < 0:       # this fill reduces the open lot(s)
            lot = book[0]
            take = min(qty, abs(lot[0]))
            d = 1 if lot[0] > 0 else -1
            pct = (f["px"] - lot[1]) / lot[1] * d * 100
            if not lot[3]:
                gap = pb = None
                lc = last_close.get((f["sym"], d))
                trips.append({"sym": f["sym"], "dir": d, "qty": take, "entry": lot[1], "exit": f["px"], "pct": pct,
                              "usd": (f["px"] - lot[1]) * d * take, "hold": (f["t"] - lot[2]).total_seconds(),
                              "open_t": lot[2], "close_t": f["t"]})
                last_close[(f["sym"], d)] = (f["t"], f["px"])
            lot[0] -= take * (1 if lot[0] > 0 else -1)
            qty -= take
            if abs(lot[0]) < 1e-9:
                book.popleft()
        if qty > 1e-9:
            book.append([sgn * qty, f["px"], f["t"], bot])
    # re-entry facts: next trip on the same symbol and side that opened shortly after the previous one closed
    by = defaultdict(list)
    for tr in sorted(trips, key=lambda x: x["open_t"]):
        by[(tr["sym"], tr["dir"])].append(tr)
    for lst in by.values():
        for a, b in zip(lst, lst[1:]):
            gap = (b["open_t"] - a["close_t"]).total_seconds()
            if 0 <= gap <= 1800 and a["usd"] > 0:
                b["re_gap"] = gap
                b["re_pb"] = (a["exit"] - b["entry"]) / a["exit"] * b["dir"] * 100   # + = got back in better than the exit
    return trips


def _q(v, p):
    v = sorted(v)
    return v[min(len(v) - 1, int(p * len(v)))] if v else 0.0


def analyze(trips):
    n = len(trips)
    res = {"n": n, "ready": n >= MIN_TRIPS_AUTO}
    if not n:
        return res
    wins = [t["pct"] for t in trips if t["pct"] > 0]
    loss = [-t["pct"] for t in trips if t["pct"] < 0]
    quick = [t["pct"] for t in trips if t["pct"] > 0 and t["hold"] <= 900]
    res.update(win_rate=round(100 * len(wins) / n, 1), net_usd=round(sum(t["usd"] for t in trips), 2),
               avg_win_pct=round(st.mean(wins), 3) if wins else 0, med_win_pct=round(st.median(wins), 3) if wins else 0,
               avg_loss_pct=round(st.mean(loss), 3) if loss else 0, med_loss_pct=round(st.median(loss), 3) if loss else 0,
               med_hold_win_s=round(st.median([t["hold"] for t in trips if t["pct"] > 0]) if wins else 0),
               med_hold_loss_s=round(st.median([t["hold"] for t in trips if t["pct"] < 0]) if loss else 0))
    aw, al = res["avg_win_pct"], res["avg_loss_pct"]
    res["breakeven_win_rate"] = round(100 * al / (aw + al), 1) if (aw + al) > 0 else None
    res["profit_factor"] = round(sum(wins) / sum(loss), 2) if loss and sum(loss) > 0 else None
    # suggested harvest: what a typical quick winner of yours banks (fast wins show the target you really take)
    base = quick if len(quick) >= 8 else wins
    res["suggest_harvest_pct"] = round(min(1.0, max(0.05, st.median(base))), 2) if base else None
    res["suggest_stop_pct"] = round(min(2.0, max(0.05, _q(loss, 0.75))), 2) if loss else None
    res["win_pct_p25_p75"] = [round(_q(wins, .25), 3), round(_q(wins, .75), 3)] if wins else None
    hrs = defaultdict(lambda: [0, 0])
    for t in trips:
        h = t["open_t"].astimezone(NY).hour if t["open_t"].tzinfo else t["open_t"].hour
        hrs[h][0] += 1
        hrs[h][1] += 1 if t["pct"] > 0 else 0
    res["by_hour"] = {str(h): {"n": v[0], "win_rate": round(100 * v[1] / v[0])} for h, v in sorted(hrs.items()) if v[0] >= 5}
    syms = defaultdict(lambda: [0, 0.0])
    for t in trips:
        syms[t["sym"]][0] += 1
        syms[t["sym"]][1] += t["usd"]
    res["top_symbols"] = [{"sym": s, "n": v[0], "usd": round(v[1], 2)} for s, v in sorted(syms.items(), key=lambda kv: -kv[1][1])[:5]]
    re_ = [t for t in trips if "re_gap" in t]
    if re_:
        res["reentry"] = {"n": len(re_), "med_gap_s": round(st.median(t["re_gap"] for t in re_)),
                          "med_better_pct": round(st.median(t["re_pb"] for t in re_), 3),
                          "win_rate": round(100 * sum(1 for t in re_ if t["pct"] > 0) / len(re_), 1)}
    return res


def learn(broker, days=60):
    fills = fetch_fills(broker, days)
    out = analyze(round_trips(fills))
    out["days"], out["at"] = days, time.time()
    return out
