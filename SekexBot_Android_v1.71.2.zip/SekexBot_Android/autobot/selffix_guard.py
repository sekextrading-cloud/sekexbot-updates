"""Boot guard for 🤖 Fix with Claude. Standard library only, so it still runs when a patch broke the app.

Runs at the very top of server.py on every start. If a patch was applied and not yet confirmed healthy:
  * any patched Python file that no longer compiles -> restore the backup straight away,
  * more than MAX_BOOTS starts without the app confirming it is healthy -> restore the backup.
The app confirms a patch after it has run for 90 seconds (see selffix.confirm_after_boot)."""
import json
import os
import py_compile
import shutil
import sys
import time
from pathlib import Path

MAX_BOOTS = 3


def paths(base: Path):
    data = Path(os.getenv("AUTOBOT_DATA", str(base / "data")))
    root = data / "selffix"
    return root, root / "pending.json", root / "rolled_back.json"


def restore(base: Path, st: dict):
    bdir = Path(st["backup"])
    for rel in st.get("files", []):
        src, dst = bdir / rel, base / rel
        if src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)


def run(base: Path):
    root, pend, rolled = paths(base)
    if not pend.exists():
        return
    try:
        st = json.loads(pend.read_text())
    except Exception:
        return
    st["boots"] = int(st.get("boots", 0)) + 1
    reason = ""
    for rel in st.get("files", []):
        if rel.endswith(".py"):
            try:
                py_compile.compile(str(base / rel), doraise=True)
            except Exception as ex:
                reason = f"{rel} no longer compiles: {str(ex)[:200]}"
                break
    if not reason and st["boots"] > MAX_BOOTS:
        reason = f"the app failed to start {MAX_BOOTS} times after the patch"
    if reason:
        restore(base, st)
        pend.unlink(missing_ok=True)
        rolled.write_text(json.dumps({"at": time.strftime("%Y-%m-%d %H:%M"), "reason": reason,
                                      "summary": st.get("summary", ""), "id": st.get("id", "")}, indent=1))
        print(f"[selffix] Patch rolled back: {reason}", file=sys.stderr)
        return
    pend.write_text(json.dumps(st, indent=1))


if __name__ == "__main__":
    run(Path(__file__).resolve().parent.parent)
