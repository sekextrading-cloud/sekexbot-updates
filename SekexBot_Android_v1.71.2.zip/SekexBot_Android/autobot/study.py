"""Overnight study: replay recent trading days minute by minute through every strategy, simulate every exit
profile, and feed the results to the learner at a reduced weight, so the bot walks into the morning knowing which
setups and exits have been working. Each day is studied once (data/study.json remembers which).

Simulated results are an approximation (fills at the signal bar's close, 0.05R cost per trade); they nudge the learner,
your own real trades still count about three times as much."""
import json
import threading
from datetime import time, timedelta

import pandas as pd

from .config import DATA_DIR
from .direction import direction
from .indicators import enrich, ribbon_state
from .learner import EXIT_PROFILES, time_bucket
from .strategies import find_signals

STUDY_FILE = DATA_DIR / "study.json"
WEIGHT = 0.3            # one simulated trade counts as 0.3 real trades
COST_R = 0.05
STEP = 5                # evaluate every 5 minutes
MAX_HOLD = 90           # minutes


def sim_exit(fut: pd.DataFrame, side: str, entry: float, risk: float, atr: float, prof: dict) -> float:
    """Walk 1-minute bars forward from the entry and return the trade's R multiple."""
    long_ = side == "buy"
    d = 1 if long_ else -1
    stop = entry - d * risk
    tgt = entry + d * prof["target_r"] * risk
    be, trail_after, trail_atr = prof.get("be_at_r"), prof.get("trail_after_r"), prof.get("trail_atr")
    scales = list(prof.get("scale") or [])
    hold = prof.get("time_stop") or MAX_HOLD
    realized, left, best = 0.0, 1.0, entry
    for n, (ts, b) in enumerate(fut.iterrows()):
        hi, lo, cl = float(b["high"]), float(b["low"]), float(b["close"])
        adverse = lo if long_ else hi
        if (long_ and adverse <= stop) or ((not long_) and adverse >= stop):      # stop first (conservative)
            return realized + left * d * (stop - entry) / risk
        best = max(best, hi) if long_ else min(best, lo)
        fav = hi if long_ else lo
        r_now = d * (fav - entry) / risk
        while scales and r_now >= scales[0][0]:
            lvl, frac = scales.pop(0)
            sell = left * frac
            realized += sell * lvl
            left -= sell
            stop = entry if d * (stop - entry) < 0 else stop
        if be is not None and r_now >= be and d * (stop - entry) < 0:
            stop = entry
        if trail_after is not None and d * (best - entry) / risk >= trail_after and trail_atr:
            t = best - d * trail_atr * atr
            stop = t if d * (t - stop) > 0 else stop
        if (long_ and fav >= tgt) or ((not long_) and fav <= tgt):
            return realized + left * prof["target_r"]
        if n + 1 >= hold or ts.time() >= time(15, 50):
            return realized + left * d * (cl - entry) / risk
    last = float(fut["close"].iloc[-1]) if len(fut) else entry
    return realized + left * d * (last - entry) / risk


def _load():
    try:
        return json.loads(STUDY_FILE.read_text())
    except Exception:
        return {"days": [], "last": "", "strategies": {}, "symbols": {}, "runs": 0}


def _save(d):
    try:
        STUDY_FILE.write_text(json.dumps(d))
    except Exception:
        pass


def gap_prior(sym):
    """How often this stock's 1%+ gaps kept going (follow) or faded in the first hour, from the overnight study."""
    g = _load().get("gapfollow", {}).get(sym)
    return {"follow": g[0], "fade": g[1]} if g else None


def summary() -> dict:
    d = _load()
    rows = []
    for k, (n, s) in d.get("strategies", {}).items():
        if n >= 3:
            rows.append({"strategy": k, "trades": int(n), "avg_r": round(s / n, 2)})
    rows.sort(key=lambda r: r["avg_r"], reverse=True)
    calls = {k: {"n": v[0], "hit": round(100 * v[1] / v[0]) if v[0] else 0} for k, v in d.get("calls", {}).items() if v[0]}
    return {"calls": calls, "last": d.get("last", ""), "days": len(d.get("days", [])), "top": rows[:6], "bottom": rows[-3:][::-1] if len(rows) > 6 else []}


def study(hist: dict, learner, settings, now, gaps_fn=None, budget_s=900, log=None, min_bars=300) -> dict:
    """hist: {symbol: 1-minute DataFrame (several days, pre-market included)}. Returns a small result dict."""
    import time as _t
    t0 = _t.time()
    state = _load()
    done = set(state.get("days", []))
    ctx0 = {"aggressive": False, "bias": 0, "shorts": bool(settings.allow_shorts or getattr(settings, "short_from_7am", True)), "index_symbols": set(settings.watch_always),
            "all_flips": bool(settings.trade_all_flips), "morning_reversal": True}
    # find the completed days available
    days = set()
    for df in hist.values():
        for dy, g in df.groupby(df.index.date):
            reg = g[(g.index.time >= time(9, 30)) & (g.index.time < time(16, 0))]
            if len(reg) >= min_bars:
                days.add(dy)
    todo = sorted(x for x in days if x.isoformat() not in done)
    if not todo:
        return {"days": 0, "trades": 0, "note": "nothing new to study"}
    todo = todo[-5:]
    n_trades, per_strat = 0, {}
    sym_stats = state.get("symbols", {})
    for dy in todo:
        if _t.time() - t0 > budget_s:
            break
        for sym, df in hist.items():
            if sym in settings.watch_always:
                continue
            day_df = df[df.index.date == dy]
            reg = day_df[(day_df.index.time >= time(9, 30)) & (day_df.index.time < time(16, 0))]
            pre = day_df[day_df.index.time < time(9, 30)]
            if len(reg) < min_bars:
                continue
            prev = df[(df.index.date < dy)]
            prev_reg = prev[(prev.index.time >= time(9, 30)) & (prev.index.time < time(16, 0))]
            gap = 0.0
            if len(prev_reg):
                pc = float(prev_reg["close"].iloc[-1])
                gap = 100 * (float(reg["open"].iloc[0]) - pc) / pc if pc else 0.0
            e = enrich(reg)
            sym_gf = state.get("gapfollow", {}).get(sym)
            try:                                       # score the 9:40 direction call against what the next hour did
                if len(reg) > 75:
                    gf = state.setdefault("gapfollow", {}).setdefault(sym, [0, 0])
                    pr = {"follow": gf[0], "fade": gf[1]}
                    seed = pd.concat([pre.tail(90), reg.iloc[:11]])
                    cr = direction(enrich(seed), gap, ribbon_state(seed), 0, pr)
                    px0, px1 = float(reg["close"].iloc[10]), float(reg["close"].iloc[70])
                    if cr["call"] != "WAIT":
                        ok = (px1 - px0) * (1 if cr["call"] == "LONG" else -1) > 0
                        for key in (cr["call"], "STRONG" if abs(cr["score"]) >= 45 else "LEAN"):
                            cc = state.setdefault("calls", {}).setdefault(key, [0, 0])
                            cc[0] += 1
                            cc[1] += 1 if ok else 0
                    if abs(gap) >= 1.0:
                        moved = (px1 - float(reg["open"].iloc[0])) * (1 if gap > 0 else -1)
                        gf[0 if moved > 0 else 1] += 1
            except Exception:
                pass
            busy_until = None
            seen = set()
            for i in range(8, len(reg) - 10, STEP):
                ts = reg.index[i - 1]
                if ts.time() > time(15, 30):
                    break
                if busy_until is not None and ts < busy_until:
                    continue
                sl = e.iloc[:i]
                rib_src = pd.concat([pre.tail(120), reg.iloc[:i]]) if len(pre) else reg.iloc[:i]
                rb_now = ribbon_state(rib_src)
                try:
                    cl = direction(sl, gap, rb_now, 0, {"follow": sym_gf[0], "fade": sym_gf[1]} if sym_gf else None)
                except Exception:
                    cl = None
                ctx = dict(ctx0, gap={sym: gap}, ribbon={sym: rb_now}, calls=({sym: cl} if cl else {}),
                           plan=({sym: {"move": gap, "side": "long" if gap > 0 else "short", "plan": "GO"}} if abs(gap) >= 1.0 else {}))
                try:
                    sigs = find_signals({sym: sl}, ctx)
                except Exception:
                    sigs = []
                for sg in sigs:
                    if sg.strategy in seen or sg.risk_per_share <= 0:
                        continue
                    seen.add(sg.strategy)
                    fut = reg.iloc[i:]
                    bucket = time_bucket(ts)
                    best_r, best_end = None, None
                    for pn, prof in EXIT_PROFILES.items():
                        r = sim_exit(fut, sg.side, sg.entry, sg.risk_per_share, sg.atr, prof) - COST_R
                        learner.record(sg.strategy, pn, bucket, r, weight=WEIGHT, save=False)
                        if pn == "STANDARD":
                            best_r = r
                    n_trades += 1
                    a = per_strat.setdefault(sg.strategy, [0, 0.0])
                    a[0] += 1
                    a[1] += best_r or 0.0
                    b = sym_stats.setdefault(sym, {}).setdefault(sg.strategy, [0, 0.0])
                    b[0] += 1
                    b[1] += best_r or 0.0
                    busy_until = ts + timedelta(minutes=30)
                    break
        done.add(dy.isoformat())
    learner.save()
    strat = state.get("strategies", {})
    for k, (n, s) in per_strat.items():
        a = strat.setdefault(k, [0, 0.0])
        a[0] += n
        a[1] += s
    state.update(days=sorted(done)[-40:], strategies=strat, symbols=sym_stats, runs=state.get("runs", 0) + 1,
                 last=f"{now.strftime('%a %-I:%M %p')} · {len(todo)} day(s), {n_trades} simulated trades")
    _save(state)
    top = sorted(per_strat.items(), key=lambda kv: kv[1][1] / max(kv[1][0], 1), reverse=True)
    return {"days": len(todo), "trades": n_trades, "note": state["last"],
            "best": [(k, v[0], round(v[1] / v[0], 2)) for k, v in top[:3] if v[0]]}
