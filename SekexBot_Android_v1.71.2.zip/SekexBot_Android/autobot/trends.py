"""🔍 Trend research: study a stock's own minute history.

1. Trend legs: every big up / down run during the regular session (start -> end), what was true when it
   started (opening-range break, above/below VWAP, volume surge) and which exit rule would have kept the
   most of it.
2. Closing-bell overnight test: buy (or short) at 3:55 PM and exit at different times overnight / next
   morning. Shows win rate and average result per exit time, so you can see if your 3:55 trade has an edge."""
from datetime import time as dtime

import numpy as np
import pandas as pd

from .indicators import ribbon

REG_START, REG_END = dtime(9, 30), dtime(16, 0)


def _day_frames(df):
    reg = df[(df.index.time >= REG_START) & (df.index.time < REG_END)]
    return {d: g for d, g in reg.groupby(reg.index.date) if len(g) >= 60}


def _vwap(g):
    tp = (g["high"] + g["low"] + g["close"]) / 3
    v = g["volume"].replace(0, np.nan).fillna(1)
    return (tp * v).cumsum() / v.cumsum()


def _zigzag(closes: pd.Series, rev: float):
    """Swing points (time, price): a swing ends when price reverses `rev` (fraction) from its extreme."""
    if closes.empty:
        return []
    idx, px = list(closes.index), closes.values
    pts = [(idx[0], px[0])]
    hi_i = lo_i = 0
    d = 0
    for k in range(1, len(px)):
        p = px[k]
        if d >= 0 and p > px[hi_i]:
            hi_i = k
        if d <= 0 and p < px[lo_i]:
            lo_i = k
        if d == 0:
            if px[hi_i] >= pts[0][1] * (1 + rev) and p <= px[hi_i] * (1 - rev):
                pts.append((idx[hi_i], px[hi_i])); d, lo_i = -1, k
            elif px[lo_i] <= pts[0][1] * (1 - rev) and p >= px[lo_i] * (1 + rev):
                pts.append((idx[lo_i], px[lo_i])); d, hi_i = 1, k
        elif d == 1 and p <= px[hi_i] * (1 - rev):
            pts.append((idx[hi_i], px[hi_i])); d, lo_i = -1, k
        elif d == -1 and p >= px[lo_i] * (1 + rev):
            pts.append((idx[lo_i], px[lo_i])); d, hi_i = 1, k
    last = hi_i if d == 1 else lo_i if d == -1 else len(px) - 1
    if idx[last] != pts[-1][0]:
        pts.append((idx[last], px[last]))
    return pts


def _bucket(t):
    m = t.hour * 60 + t.minute
    return "Morning" if m < 11 * 60 + 30 else "Midday" if m < 14 * 60 else "Afternoon"


EXIT_RULES = {
    "ribbon flip (3-min)": "ribbon",
    "close back through VWAP": "vwap",
    "2 closes against (5-min)": "two5",
    "trail 1× ATR": "atr1",
    "trail 2× ATR": "atr2",
}


def _exit_capture(g, vw, rb, atr, i0, i1, d):
    """For a leg from i0 to i1 (index positions in g), where each rule would have exited, as % of the leg."""
    px0, px1 = g["close"].iloc[i0], g["close"].iloc[i1]
    move = (px1 - px0) * d
    if move <= 0:
        return {}
    out = {}
    closes = g["close"].values
    n = len(g)
    for name, rule in EXIT_RULES.items():
        best = closes[i0]
        stop = None
        ex = closes[-1]
        for k in range(i0 + 1, n):
            c = closes[k]
            best = max(best, c) if d > 0 else min(best, c)
            hit = False
            if rule == "ribbon":
                s = rb[k]
                hit = s == -d
            elif rule == "vwap":
                hit = (c - vw[k]) * d < 0 and k > i0 + 3
            elif rule == "two5":
                if k >= i0 + 10 and k % 5 == 4:
                    c5 = closes[k - 9:k + 1:5]
                    hit = len(c5) == 2 and (c5[1] - c5[0]) * d < 0 and (c - best) * d < 0
            elif rule in ("atr1", "atr2"):
                m = 1 if rule == "atr1" else 2
                lvl = best - d * m * atr[k]
                stop = lvl if stop is None else (max(stop, lvl) if d > 0 else min(stop, lvl))
                hit = (c - stop) * d <= 0 and k > i0 + 2
            if hit:
                ex = c
                break
        out[name] = round(100 * (ex - px0) * d / move, 1)
    return out


def trend_legs(df1m, min_move=0.015, rev=None):
    """All regular-session legs of at least `min_move` (1.5%) per day."""
    legs = []
    for day, g in _day_frames(df1m).items():
        g = g.copy()
        vw = _vwap(g).values
        tr = pd.concat([g["high"] - g["low"], (g["high"] - g["close"].shift()).abs(),
                        (g["low"] - g["close"].shift()).abs()], axis=1).max(axis=1)
        atr = tr.rolling(14, min_periods=3).mean().bfill().values
        try:
            rbs = ribbon(g, lines=False, tf="3min")
            rb = rbs["state"].reindex(g.index, method="ffill").fillna(0).values if "state" in rbs else np.zeros(len(g))
        except Exception:
            rb = np.zeros(len(g))
        orh, orl = g["high"].iloc[:15].max(), g["low"].iloc[:15].min()
        vol_avg = g["volume"].rolling(30, min_periods=5).mean().bfill().values
        r = rev or max(0.006, float(np.nanmedian(atr) / g["close"].iloc[0]) * 4)
        pts = _zigzag(g["close"], r)
        pos = {ts: k for k, ts in enumerate(g.index)}
        for (t0, p0), (t1, p1) in zip(pts, pts[1:]):
            mv = (p1 - p0) / p0
            if abs(mv) < min_move:
                continue
            d = 1 if mv > 0 else -1
            i0, i1 = pos[t0], pos[t1]
            win = g.iloc[i0:min(i0 + 6, len(g))]
            signals = []
            if d > 0 and win["high"].max() > orh and t0.time() >= dtime(9, 45):
                signals.append("broke opening-range high")
            if d < 0 and win["low"].min() < orl and t0.time() >= dtime(9, 45):
                signals.append("broke opening-range low")
            if t0.time() < dtime(9, 45):
                signals.append("opening drive")
            c6 = g["close"].iloc[min(i0 + 5, len(g) - 1)]
            if (c6 - vw[min(i0 + 5, len(g) - 1)]) * d > 0:
                signals.append("above VWAP" if d > 0 else "below VWAP")
            vr = float(win["volume"].mean() / max(vol_avg[i0], 1))
            if vr >= 1.5:
                signals.append(f"volume {vr:.1f}× normal")
            legs.append({"day": str(day), "dir": "up" if d > 0 else "down",
                         "start": t0.strftime("%I:%M %p").lstrip("0"), "end": t1.strftime("%I:%M %p").lstrip("0"),
                         "start_px": round(p0, 2), "end_px": round(p1, 2), "move_pct": round(100 * mv, 2),
                         "minutes": int((t1 - t0).total_seconds() / 60), "bucket": _bucket(t0),
                         "signals": signals, "capture": _exit_capture(g, vw, rb, atr, i0, i1, d)})
    return legs


def summarize_legs(legs):
    if not legs:
        return {}
    df = pd.DataFrame(legs)
    out = {"count": len(df), "by_bucket": {}, "best_exit": None, "exit_rules": {}}
    for b, g in df.groupby("bucket"):
        out["by_bucket"][b] = {"legs": len(g), "avg_move": round(g["move_pct"].abs().mean(), 2),
                               "avg_minutes": int(g["minutes"].mean()), "up": int((g["dir"] == "up").sum()),
                               "down": int((g["dir"] == "down").sum())}
    caps = pd.DataFrame([l["capture"] for l in legs if l["capture"]])
    if not caps.empty:
        med = caps.median().round(1).to_dict()
        out["exit_rules"] = med
        out["best_exit"] = max(med, key=med.get)
    sig = {}
    for l in legs:
        for s in l["signals"]:
            k = s.split(" ")[0] if s.startswith("volume") else s
            sig[k] = sig.get(k, 0) + 1
    out["signals"] = dict(sorted(sig.items(), key=lambda x: -x[1]))
    starts = df[df["bucket"] == "Morning"]
    if len(starts):
        out["morning_start_typical"] = pd.to_datetime(starts["start"], format="%I:%M %p").sort_values() \
            .iloc[len(starts) // 2].strftime("%I:%M %p").lstrip("0")
    return out


EXITS = [("8:00 PM (overnight open)", dtime(20, 0), 0), ("11:00 PM", dtime(23, 0), 0), ("2:00 AM", dtime(2, 0), 1),
         ("4:00 AM (pre-market)", dtime(4, 0), 1), ("8:00 AM", dtime(8, 0), 1), ("9:25 AM (before open)", dtime(9, 25), 1),
         ("9:35 AM (after open)", dtime(9, 35), 1), ("10:00 AM", dtime(10, 0), 1)]


def _px_at(df, ts):
    s = df[df.index >= ts]
    return (float(s["open"].iloc[0]), s.index[0]) if len(s) and (s.index[0] - ts).total_seconds() < 3 * 3600 else (None, None)


def closing_bell(df1m, entry=dtime(15, 55)):
    """Buy at `entry`, exit at each overnight / next-morning time. Returns per-exit stats (long; short = mirror)."""
    days = sorted({d for d in df1m.index.date})
    rows = []
    for di, d in enumerate(days[:-1]):
        day = df1m[df1m.index.date == d]
        e = day[(day.index.time >= entry) & (day.index.time < REG_END)]
        if e.empty:
            continue
        px0, t0 = float(e["close"].iloc[0]), e.index[0]
        nxt = days[di + 1]
        rec = {"day": str(d), "entry": round(px0, 2), "exits": {}}
        after = df1m[df1m.index > t0]
        for name, t, off in EXITS:
            date = d if off == 0 else nxt
            ts = pd.Timestamp.combine(date, t).tz_localize(df1m.index.tz)
            px, _ = _px_at(after, ts)
            if px:
                rec["exits"][name] = round(100 * (px / px0 - 1), 3)
        win = after[after.index < pd.Timestamp.combine(nxt, dtime(9, 30)).tz_localize(df1m.index.tz)]
        if len(win):
            rec["best_up"] = round(100 * (win["high"].max() / px0 - 1), 2)
            rec["worst_down"] = round(100 * (win["low"].min() / px0 - 1), 2)
            rec["overnight_bars"] = int(((win.index.time >= dtime(20, 0)) | (win.index.time < dtime(4, 0))).sum())
        rows.append(rec)
    stats = {}
    for name, _, _ in EXITS:
        v = [r["exits"][name] for r in rows if name in r["exits"]]
        if not v:
            continue
        a = np.array(v)
        stats[name] = {"n": len(a), "avg": round(float(a.mean()), 3), "median": round(float(np.median(a)), 3),
                       "win_long": round(100 * float((a > 0).mean()), 1), "win_short": round(100 * float((a < 0).mean()), 1),
                       "worst": round(float(a.min()), 2), "best": round(float(a.max()), 2)}
    best = None
    if stats:
        k = max(stats, key=lambda k: abs(stats[k]["avg"]) if stats[k]["n"] >= 5 else 0)
        best = {"exit": k, "side": "long" if stats[k]["avg"] > 0 else "short", **stats[k]}
    have_on = sum(1 for r in rows if r.get("overnight_bars"))
    return {"days": rows[-30:], "stats": stats, "best": best, "overnight_data_days": have_on, "n_days": len(rows)}
