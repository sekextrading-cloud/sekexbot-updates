"""Optional diagnostics sharing ("Help SekexBot support fix problems").

OFF unless the user turns it on. When on, once a minute it sends ONE small technical report to the support
collector: app version, phone/OS model, how much CPU and memory SekexBot itself is using, battery, free storage,
library versions, and the last few error lines (scrubbed). It NEVER sends API keys, passwords, positions, orders,
balances, P&L, symbols or the journal. A SEPARATE opt-in (share_trade_logs, default OFF) also uploads the trade journal and
strategy logs every 3 hours so support can refine strategies; `preview` for that is /api/diag/logs_preview. `preview()` returns exactly what would be sent so the user can read it."""
import json
import os
import platform
import re
import resource
import shutil
import subprocess
import sys
import threading
import time
import uuid
import urllib.request
from pathlib import Path
from urllib.parse import urlparse

from .config import DATA_DIR
from .version import __version__

DEFAULT_COLLECTOR_URL = ""          # set to your hosted collector's https address before shipping a release
INTERVAL = 60
START = time.time()

_cache = {}


def _ttl(key, secs, fn):
    v = _cache.get(key)
    if v and time.time() - v[0] < secs:
        return v[1]
    try:
        r = fn()
    except Exception:
        r = None
    _cache[key] = (time.time(), r)
    return r


def install_id() -> str:
    """A random id for this install (not tied to a person). Kept outside the data folder so copying data to a new phone
    doesn't make two phones look like one."""
    for d in (Path.home() / ".sekexbot", DATA_DIR):
        try:
            f = d / "install_id"
            if f.exists():
                v = f.read_text().strip()
                if re.fullmatch(r"[0-9a-f]{32}", v):
                    return v
        except Exception:
            pass
    v = uuid.uuid4().hex
    for d in (Path.home() / ".sekexbot", DATA_DIR):
        try:
            d.mkdir(parents=True, exist_ok=True)
            (d / "install_id").write_text(v)
            break
        except Exception:
            continue
    return v


def _run(cmd, timeout=5):
    return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout).stdout.strip()


def _android():
    def go():
        g = lambda k: _run(["getprop", k])
        return {"android": g("ro.build.version.release"), "sdk": g("ro.build.version.sdk"), "model": g("ro.product.model"),
                "maker": g("ro.product.manufacturer"), "patch": g("ro.build.version.security_patch"),
                "build": g("ro.build.display.id")[:40]}
    r = _ttl("android", 3600, go)
    return r if r and any(r.values()) else None


def _battery():
    def go():
        d = json.loads(_run(["termux-battery-status"], 6) or "{}")
        return {"pct": d.get("percentage"), "charging": d.get("status") in ("CHARGING", "FULL") or d.get("plugged") not in (None, "UNPLUGGED"),
                "temp_c": d.get("temperature")}
    return _ttl("battery", 55, go)


def _meminfo():
    try:
        m = {}
        for line in open("/proc/meminfo"):
            k, v = line.split(":", 1)
            m[k] = int(v.split()[0]) // 1024
        return {"total_mb": m.get("MemTotal"), "avail_mb": m.get("MemAvailable"), "swap_free_mb": m.get("SwapFree")}
    except Exception:
        return None


def _proc_status():
    out = {}
    try:
        for line in open("/proc/self/status"):
            if line.startswith("VmRSS:"):
                out["rss_mb"] = round(int(line.split()[1]) / 1024, 1)
            elif line.startswith("Threads:"):
                out["threads"] = int(line.split()[1])
    except Exception:
        out["rss_mb"] = round(resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024, 1)
    return out


_last_cpu = [time.time(), time.process_time()]


def _app_cpu_pct():
    """SekexBot's own CPU use since the last report, as % of ONE core (200 = two cores busy)."""
    now, cpu = time.time(), time.process_time()
    dt = now - _last_cpu[0]
    pct = (cpu - _last_cpu[1]) / dt * 100 if dt > 0.5 else None
    _last_cpu[0], _last_cpu[1] = now, cpu
    return round(pct, 1) if pct is not None else None


def _libs():
    def go():
        from importlib.metadata import version
        out = {}
        for p in ("alpaca-py", "fastapi", "uvicorn", "pandas", "numpy", "pydantic", "requests"):
            try:
                out[p] = version(p)
            except Exception:
                pass
        return out
    return _ttl("libs", 3600, go) or {}


_SCRUB = [
    (re.compile(r"\b(PK|AK|CK)[A-Z0-9]{14,}\b"), "‹key›"),
    (re.compile(r"\b[A-Za-z0-9_\-]{28,}\b"), "‹token›"),
    (re.compile(r"[\w.+-]+@[\w-]+\.[\w.]+"), "‹email›"),
    (re.compile(r"\$\s?-?[\d,]+(\.\d+)?"), "$…"),
    (re.compile(r"(?i)(token|password|secret|key)=\S+"), r"\1=‹hidden›"),
]
_ERRISH = re.compile(r"(?i)\b(error|exception|failed|failure|timeout|timed out|refused|rejected|traceback|crash|unreachable)\b")


def _scrub(s: str) -> str:
    for rx, rep in _SCRUB:
        s = rx.sub(rep, s)
    return s[:220]


def _errors():
    """Count and last few error lines from the app log (errors/warnings only, scrubbed)."""
    def go():
        f = DATA_DIR / "autobot.log"
        if not f.exists():
            return {"count_1h": 0, "last": []}
        with open(f, "rb") as fh:
            fh.seek(max(0, f.stat().st_size - 200_000))
            lines = fh.read().decode("utf-8", "replace").splitlines()
        cutoff = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(time.time() - 3600))
        bad = []
        for ln in lines:
            m = re.match(r"(\d{4}-\d\d-\d\d \d\d:\d\d:\d\d),\d+ (ERROR|WARNING|CRITICAL) (.*)", ln)
            if not m:
                continue
            if m.group(2) == "WARNING" and not _ERRISH.search(m.group(3)):
                continue                     # ordinary trading warnings (closes, halts) are not errors and may hold figures
            bad.append((m.group(1), m.group(2), m.group(3)))
        recent = [b for b in bad if b[0] >= cutoff]
        return {"count_1h": len(recent), "last": [f"{t[11:]} {lv} {_scrub(msg)}" for t, lv, msg in bad[-6:]]}
    return _ttl("errors", 50, go) or {"count_1h": 0, "last": []}


def _disk():
    try:
        return round(shutil.disk_usage(DATA_DIR).free / 1e9, 2)
    except Exception:
        return None


def _loadavg():
    try:
        return round(os.getloadavg()[0], 2)
    except Exception:
        try:
            return float(open("/proc/loadavg").read().split()[0])
        except Exception:
            return None


def build(settings, app_state=None) -> dict:
    """The exact report that is sent. app_state: optional dict from the engine (running / halted / mode / session)."""
    ps = _proc_status()
    st = app_state or {}
    return {
        "v": 1, "install_id": install_id(), "label": (getattr(settings, "diag_label", "") or "")[:40],
        "app_version": __version__, "ts": int(time.time()), "uptime_s": int(time.time() - START),
        "app": {"mode": "live" if getattr(settings, "live", False) else "paper", "trading_on": bool(st.get("running")),
                "halted": bool(st.get("halted")), "session": st.get("session"), "streaming": st.get("streaming"),
                "level": getattr(settings, "level", None)},
        "cpu_app_pct": _app_cpu_pct(), "rss_mb": ps.get("rss_mb"), "threads": ps.get("threads"),
        "sys": {**(_meminfo() or {}), "load1": _loadavg(), "cores": os.cpu_count()},
        "disk_free_gb": _disk(), "battery": _battery(),
        "os": {"system": platform.system(), "kernel": platform.release()[:40], "arch": platform.machine(),
               "python": platform.python_version(), **(_android() or {})},
        "libs": _libs(), "errors": _errors(),
    }


def collector_url(settings) -> str:
    u = (getattr(settings, "collector_url", "") or DEFAULT_COLLECTOR_URL or "").strip().rstrip("/")
    return u if valid_url(u) else ""


def valid_url(u: str) -> bool:
    try:
        p = urlparse(u)
    except Exception:
        return False
    if not p.hostname:
        return False
    private = p.hostname in ("localhost", "127.0.0.1", "::1") or p.hostname.startswith(("192.168.", "10."))
    return p.scheme == "https" or (p.scheme == "http" and private)


def _post(url, body: dict, headers=None, timeout=8):
    req = urllib.request.Request(url, data=json.dumps(body).encode(), method="POST",
                                 headers={"Content-Type": "application/json", **(headers or {})})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


def _post_bytes(url, data: bytes, headers, timeout=60):
    req = urllib.request.Request(url, data=data, method="POST", headers=headers)
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.status, r.read()


LOG_EVERY_S = 3 * 3600


class Reporter:
    def __init__(self, settings, app_state_fn):
        self.s, self.app_state_fn = settings, app_state_fn
        self.last_ok = 0.0
        self.last_error = ""
        self.sent = 0
        self.bundle_fn = None
        self._logs_try = 0.0
        self.logs_ok = 0.0
        self.logs_error = ""
        threading.Thread(target=self._loop, daemon=True, name="diag-reporter").start()

    def enabled(self) -> bool:
        return bool(getattr(self.s, "share_diagnostics", False)) and bool(collector_url(self.s))

    def send_now(self):
        url = collector_url(self.s)
        try:
            _post(url + "/v1/heartbeat", build(self.s, self.app_state_fn()))
            self.last_ok, self.last_error, self.sent = time.time(), "", self.sent + 1
        except Exception as e:
            self.last_error = str(e)[:120]

    def logs_enabled(self) -> bool:
        return bool(getattr(self.s, "share_trade_logs", False)) and bool(collector_url(self.s)) and self.bundle_fn is not None

    def send_logs_now(self):
        """Opt-in only: upload the review bundle (journal, strategy stats, skip log, scrubbed settings) as one zip."""
        url = collector_url(self.s)
        if not url or not self.bundle_fn:
            return
        try:
            data = self.bundle_fn()
            if len(data) > 12_000_000:
                self.logs_error = "bundle too large"
                return
            _post_bytes(url + "/v1/logs", data, {"Content-Type": "application/zip", "X-Install-Id": install_id(),
                                                 "X-App-Version": __version__, "X-Label": (getattr(self.s, "diag_label", "") or "")[:40]})
            self.logs_ok, self.logs_error = time.time(), ""
        except Exception as e:
            self.logs_error = str(e)[:120]

    def forget(self):
        """Sharing was switched off: ask the collector to delete what it holds for this install."""
        url = collector_url(self.s)
        if not url:
            return
        try:
            _post(url + "/v1/forget", {"install_id": install_id()})
        except Exception:
            pass

    def _loop(self):
        time.sleep(20)
        while True:
            try:
                if self.enabled():
                    self.send_now()
                if self.logs_enabled() and time.time() - max(self.logs_ok, self._logs_try) > LOG_EVERY_S:
                    self._logs_try = time.time()
                    self.send_logs_now()
            except Exception:
                pass
            time.sleep(INTERVAL)

    def status(self):
        return {"enabled": bool(getattr(self.s, "share_diagnostics", False)), "collector_set": bool(collector_url(self.s)),
                "last_ok_ago_s": int(time.time() - self.last_ok) if self.last_ok else None, "last_error": self.last_error,
                "sent": self.sent, "install_id": install_id()[:8],
                "logs_enabled": bool(getattr(self.s, "share_trade_logs", False)),
                "logs_last_ok_ago_s": int(time.time() - self.logs_ok) if self.logs_ok else None, "logs_error": self.logs_error}
