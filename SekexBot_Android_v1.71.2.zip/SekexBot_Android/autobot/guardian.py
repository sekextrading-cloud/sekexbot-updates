"""🛡 Keep-alive heartbeat and automatic backups.

Heartbeat: every minute the app pings your free healthchecks.io check. If the phone dies, sleeps or loses
internet, the pings stop and healthchecks.io alerts you (email, SMS, ntfy, Telegram...). The ping carries a
short status (LIVE/PAPER, open positions) so you can see what was at stake.

Backups: every night at 8:10 PM ET (and on demand) the journal, learning memory, settings and alert config
are zipped (NO API keys) and kept on the phone: in Downloads/SekexBot/backups when Termux storage is set up,
otherwise in data/backups. Optionally also uploaded to a private GitHub repo with a fine-grained token."""
import base64
import io
import json
import logging
import os
import threading
import time
import zipfile
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo

import requests

from .config import BASE_DIR, DATA_DIR

log = logging.getLogger("autobot")
NY = ZoneInfo("America/New_York")
CFG = DATA_DIR / "guardian.json"
KEEP = 14
SKIP = {"backups", "autobot.log", "autobot.log.1", "run_state.json"}


class Guardian:
    def __init__(self, get_status):
        self.get_status = get_status          # -> (mode, open_positions, running)
        self.cfg = {"hc_url": "", "gh_repo": "", "gh_token": "", "gh_path": "backups", "backup_on": True}
        self.last_ping, self.ping_err = None, ""
        self.last_backup, self.backup_err, self.last_gh = None, "", None
        try:
            self.cfg.update(json.loads(CFG.read_text()))
        except Exception:
            pass
        threading.Thread(target=self._loop, daemon=True, name="guardian").start()

    def save(self):
        try:
            CFG.write_text(json.dumps(self.cfg))
        except Exception as e:
            log.warning("guardian save: %s", e)

    def public(self):
        return {"hc_set": bool(self.cfg["hc_url"]), "gh_repo": self.cfg["gh_repo"], "gh_set": bool(self.cfg["gh_token"]),
                "backup_on": self.cfg["backup_on"], "last_ping": self.last_ping, "ping_err": self.ping_err,
                "last_backup": self.last_backup, "backup_err": self.backup_err, "last_gh": self.last_gh,
                "backup_dir": str(self.backup_dir()), "backups": self.list_backups()[:5]}

    # ---------------- heartbeat ----------------
    def ping(self, fail=False):
        url = self.cfg["hc_url"].strip()
        if not url:
            return False
        try:
            mode, npos, running = self.get_status()
            body = f"{mode} · bot {'on' if running else 'off'} · {npos} open position(s)"
            requests.post(url.rstrip("/") + ("/fail" if fail else ""), data=body.encode(), timeout=10)
            self.last_ping, self.ping_err = datetime.now(NY).strftime("%I:%M:%S %p").lstrip("0"), ""
            return True
        except Exception as e:
            self.ping_err = str(e)[:120]
            return False

    # ---------------- backups ----------------
    def backup_dir(self) -> Path:
        shared = Path.home() / "storage" / "downloads"
        d = (shared / "SekexBot" / "backups") if shared.exists() else DATA_DIR / "backups"
        try:
            d.mkdir(parents=True, exist_ok=True)
        except Exception:
            d = DATA_DIR / "backups"
            d.mkdir(parents=True, exist_ok=True)
        return d

    def list_backups(self):
        try:
            return sorted((p.name for p in self.backup_dir().glob("SekexBot_backup_*.zip")), reverse=True)
        except Exception:
            return []

    def make_zip(self) -> bytes:
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
            for p in DATA_DIR.rglob("*"):
                rel = p.relative_to(DATA_DIR)
                if p.is_dir() or rel.parts[0] in SKIP or p.suffix in (".tmp",) or p.name == "guardian.json":
                    continue
                if p.name == "alerts.json":          # keep settings, drop the Telegram token
                    try:
                        a = json.loads(p.read_text())
                        a.pop("tg_token", None)
                        z.writestr("data/alerts.json", json.dumps(a))
                    except Exception:
                        pass
                    continue
                if "auth" in p.name or "secret" in p.name or "token" in p.name:
                    continue
                z.write(p, "data/" + str(rel))
            z.writestr("README.txt", "SekexBot backup (no API keys). Restore: ⚙ → Backups → Restore, "
                                     "or unzip over the SekexBot folder.\n")
        return buf.getvalue()

    def backup(self, upload=True):
        try:
            data = self.make_zip()
            name = f"SekexBot_backup_{datetime.now(NY).strftime('%Y%m%d_%H%M')}.zip"
            d = self.backup_dir()
            (d / name).write_bytes(data)
            for old in self.list_backups()[KEEP:]:
                try:
                    (d / old).unlink()
                except Exception:
                    pass
            self.last_backup, self.backup_err = name, ""
            if upload and self.cfg["gh_token"] and self.cfg["gh_repo"]:
                self._github(name, data)
            return {"ok": True, "file": name, "dir": str(d), "github": self.last_gh}
        except Exception as e:
            self.backup_err = str(e)[:160]
            return {"ok": False, "error": self.backup_err}

    def _github(self, name, data):
        repo, tok = self.cfg["gh_repo"].strip(), self.cfg["gh_token"].strip()
        path = f"{self.cfg['gh_path'].strip('/') or 'backups'}/{name}"
        r = requests.put(f"https://api.github.com/repos/{repo}/contents/{path}", timeout=60,
                         headers={"Authorization": f"Bearer {tok}", "Accept": "application/vnd.github+json"},
                         json={"message": f"SekexBot backup {name}", "content": base64.b64encode(data).decode()})
        if r.status_code in (200, 201):
            self.last_gh = f"{repo}/{path}"
        else:
            msg = (r.json().get("message") if r.headers.get("content-type", "").startswith("application/json") else r.text)
            self.backup_err = f"GitHub upload failed ({r.status_code}): {str(msg)[:120]}"

    def restore(self, data: bytes):
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            names = [n for n in z.namelist() if n.startswith("data/") and ".." not in n and not n.endswith("/")]
            if not names:
                raise ValueError("That zip isn't a SekexBot backup.")
            for n in names:
                if n.endswith(".env") or n.endswith("guardian.json"):
                    continue
                if n.endswith("alerts.json"):          # keep the Telegram token already on this phone
                    try:
                        new = json.loads(z.read(n))
                        old = json.loads((DATA_DIR / "alerts.json").read_text())
                        if old.get("tg_token"):
                            new["tg_token"] = old["tg_token"]
                        (DATA_DIR / "alerts.json").write_text(json.dumps(new))
                    except Exception:
                        pass
                    continue
                dest = DATA_DIR / n[5:]
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_bytes(z.read(n))
        return len(names)

    # ---------------- loop ----------------
    def _loop(self):
        last_day = None
        while True:
            try:
                self.ping()
                now = datetime.now(NY)
                if self.cfg["backup_on"] and now.hour == 20 and now.minute >= 10 and last_day != now.date():
                    last_day = now.date()
                    self.backup()
            except Exception as e:
                log.debug("guardian: %s", e)
            time.sleep(60)
