"""Builds 1-minute bars from polled bid/ask quotes.

Overnight (8 PM - 4 AM) trade prints are only published with a delay, but real-time
indicative quotes are available, so the bot charts the mid-price itself.
'volume' is the number of quote samples in the minute (a rough activity proxy)."""
import pandas as pd


class QuoteBars:
    def __init__(self, max_minutes=600):
        self.max = max_minutes
        self.data: dict[str, list] = {}

    def reset(self):
        self.data.clear()

    def update(self, sym: str, bid: float, ask: float, ts):
        if not bid or not ask or ask < bid:
            return
        mid = (bid + ask) / 2
        minute = ts.replace(second=0, microsecond=0)
        rows = self.data.setdefault(sym, [])
        if rows and rows[-1][0] == minute:
            r = rows[-1]
            r[2], r[3], r[4], r[5] = max(r[2], mid), min(r[3], mid), mid, r[5] + 1
        else:
            if rows and minute > rows[-1][0] + pd.Timedelta(minutes=1):
                # fill quiet minutes with flat bars so indicators keep time
                last = rows[-1][4]
                t = rows[-1][0] + pd.Timedelta(minutes=1)
                while t < minute and len(rows) < self.max * 2:
                    rows.append([t, last, last, last, last, 0])
                    t += pd.Timedelta(minutes=1)
            rows.append([minute, mid, mid, mid, mid, 1])
        if len(rows) > self.max:
            del rows[: len(rows) - self.max]

    def frame(self, sym: str, completed_only=True):
        rows = self.data.get(sym) or []
        if completed_only:
            rows = rows[:-1]
        if not rows:
            return None
        df = pd.DataFrame(rows, columns=["t", "open", "high", "low", "close", "volume"]).set_index("t")
        return df
