"""Indicator helpers operating on a pandas DataFrame of 1-minute bars
with columns: open, high, low, close, volume (DatetimeIndex, America/New_York)."""
import numpy as np
import pandas as pd


def ema(s: pd.Series, n: int) -> pd.Series:
    return s.ewm(span=n, adjust=False).mean()


def rsi(s: pd.Series, n: int = 14) -> pd.Series:
    d = s.diff()
    up = d.clip(lower=0).ewm(alpha=1 / n, adjust=False).mean()
    dn = (-d.clip(upper=0)).ewm(alpha=1 / n, adjust=False).mean()
    rs = up / dn.replace(0, np.nan)
    return (100 - 100 / (1 + rs)).fillna(50)


def atr(df: pd.DataFrame, n: int = 14) -> pd.Series:
    pc = df["close"].shift()
    h, l = df["high"].values, df["low"].values
    pcv = pc.values
    tr = pd.Series(np.nanmax(np.vstack([h - l, np.abs(h - pcv), np.abs(l - pcv)]), axis=0), index=df.index)
    return tr.ewm(alpha=1 / n, adjust=False).mean()


def vwap(df: pd.DataFrame) -> pd.Series:
    tp = (df["high"] + df["low"] + df["close"]) / 3
    pv = (tp * df["volume"]).cumsum()
    v = df["volume"].cumsum().replace(0, np.nan)
    return (pv / v).bfill()


def enrich(df: pd.DataFrame) -> pd.DataFrame:
    extra = pd.DataFrame({
        "ema9": ema(df["close"], 9), "ema21": ema(df["close"], 21), "rsi": rsi(df["close"], 14),
        "atr": atr(df, 14), "vwap": vwap(df),
        "vol_avg": df["volume"].rolling(20, min_periods=5).mean()}, index=df.index)
    return pd.concat([df, extra], axis=1)


# ---------------- EMA ribbon (trend-flip indicator) ----------------
RIBBON_TF = "3min"            # ribbon runs on 3-minute bars built from 1-minute data
RIBBON_FAST, RIBBON_SLOW = 8, 21
RIBBON_LINES = (8, 10, 12, 14, 16, 18, 21)
RIBBON_MIN_BARS = 10          # ~30 minutes after the open before the ribbon is trusted


def resample(df: pd.DataFrame, tf: str = RIBBON_TF) -> pd.DataFrame:
    r = df[["open", "high", "low", "close", "volume"]].resample(tf, label="left", closed="left").agg(
        {"open": "first", "high": "max", "low": "min", "close": "last", "volume": "sum"}).dropna()
    return r


def ribbon(df1m: pd.DataFrame, lines: bool = False, tf: str = RIBBON_TF) -> pd.DataFrame:
    """Returns higher-timeframe bars with fast (yellow), slow (white), ribbon lines, band and
    state: +1 green (fast above slow and slow rising), -1 red, 0 neutral."""
    h = resample(df1m, tf) if tf != "1min" else df1m[["open", "high", "low", "close", "volume"]].copy()
    if h.empty:
        return h
    # drop the still-forming last bar
    last_ts = df1m.index[-1]
    if tf != "1min" and h.index[-1] + pd.Timedelta(tf) > last_ts + pd.Timedelta("1min"):
        h = h.iloc[:-1]
    if h.empty:
        return h
    cols = {}
    if lines:
        for n in RIBBON_LINES:
            cols[f"e{n}"] = ema(h["close"], n)
    fast, slow = ema(h["close"], RIBBON_FAST), ema(h["close"], RIBBON_SLOW)
    a = atr(h, 10)
    slope = slow.diff().values
    raw = np.where((fast.values > slow.values) & (slope >= 0), 1,
                   np.where((fast.values < slow.values) & (slope <= 0), -1, 0)).astype(float)
    raw[raw == 0] = np.nan  # sticky: neutral bars keep the previous colour (like the chart's ribbon)
    state = pd.Series(raw, index=h.index).ffill().fillna(0).astype(int)
    cols.update(fast=fast, slow=slow, atr=a, band_hi=slow + 0.5 * a, band_lo=slow - 0.5 * a, state=state)
    return pd.concat([h, pd.DataFrame(cols, index=h.index)], axis=1)


def ribbon_state(df1m: pd.DataFrame) -> dict:
    h = ribbon(df1m)
    if len(h) < RIBBON_MIN_BARS:
        return {"ready": False, "state": 0, "flip_ago": None}
    st = h["state"].values
    flip_ago = None
    for i in range(1, min(len(st), 40)):
        if st[-i] != st[-i - 1]:
            flip_ago = i - 1
            break
    l = h.iloc[-1]
    return {"ready": True, "state": int(st[-1]), "flip_ago": flip_ago, "fast": float(l["fast"]),
            "slow": float(l["slow"]), "atr": float(l["atr"]), "swing_low": float(h["low"].iloc[-4:].min()),
            "swing_high": float(h["high"].iloc[-4:].max())}
