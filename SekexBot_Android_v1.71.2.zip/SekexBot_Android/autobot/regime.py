"""Market regime: what kind of day/hour is this? Read from the index ETFs (SPY/QQQ) and used to size
strategies up or down so the bot leans into what the market is paying for right now.

    TREND_UP / TREND_DOWN  clean one-way movement   -> trade with it, shrink counter-trend and fade trades
    CHOP                   going nowhere, whipsaws  -> shrink trend-following, favour reversion
    VOLATILE               ranges far above normal  -> everything smaller (stops are wider)
    QUIET                  ranges far below normal  -> shrink trend-following (little follow-through)
    NORMAL                 nothing special          -> unchanged

It only ever changes position SIZE (never above ~1.2x) and blocks the clearest counter-trend fades.
It never touches the daily loss limit."""
import numpy as np

TREND_FAMILY = ("RIBBON_FLIP", "EMA_PULLBACK", "ORB", "GAP_GO", "PLAN_TREND", "OPEN_DRIVE", "DIR_CALL", "REENTRY",
                "MORN_TREND", "OPEN_SHORT", "EXT_MOMENTUM", "EXT_TREND", "EXT_CONT")
REVERT_FAMILY = ("MEAN_REVERT", "FLUSH_BOUNCE", "FLUSH_FADE", "FLUSH_SHORT", "VWAP_RECLAIM", "GAP_FADE", "MORNING_REVERSAL")
N = 30                      # bars (minutes) for direction / efficiency
ER_TREND, ER_CHOP = 0.35, 0.18
VOL_HI, VOL_LO = 1.7, 0.6


def _one(df):
    d = df.tail(150)
    if len(d) < N + 5:
        return None
    c = d["close"].astype(float).to_numpy()
    seg = c[-N:]
    path = float(np.abs(np.diff(seg)).sum())
    er = abs(seg[-1] - seg[0]) / path if path > 0 else 0.0
    direction = 1 if seg[-1] > seg[0] else -1 if seg[-1] < seg[0] else 0
    rng = (d["high"].astype(float) - d["low"].astype(float)).to_numpy()
    recent, base = float(rng[-10:].mean()), float(rng.mean())
    vol = recent / base if base > 0 else 1.0
    move_pct = (seg[-1] - seg[0]) / seg[0] * 100 if seg[0] else 0.0
    return er, direction, vol, move_pct


def classify(bars, index_symbols=("SPY", "QQQ")):
    parts = []
    for s in index_symbols:
        df = bars.get(s)
        if df is None:
            continue
        try:
            r = _one(df)
        except Exception:
            r = None
        if r:
            parts.append(r)
    if not parts:
        return {"name": "NORMAL", "er": 0.0, "dir": 0, "vol": 1.0, "why": "no index data yet"}
    er = sum(p[0] for p in parts) / len(parts)
    vol = sum(p[2] for p in parts) / len(parts)
    dirs = sum(p[1] for p in parts)
    direction = (dirs > 0) - (dirs < 0)
    move = sum(p[3] for p in parts) / len(parts)
    if vol >= VOL_HI:
        name, why = "VOLATILE", f"index ranges are {vol:.1f}x normal"
    elif er >= ER_TREND and direction != 0 and abs(move) >= 0.12:
        name = "TREND_UP" if direction > 0 else "TREND_DOWN"
        why = f"clean {'up' if direction > 0 else 'down'} move ({move:+.2f}% in {N} min, efficiency {er:.2f})"
    elif er <= ER_CHOP:
        name, why = "CHOP", f"no direction (efficiency {er:.2f})"
    elif vol <= VOL_LO:
        name, why = "QUIET", f"index ranges are only {vol:.1f}x normal"
    else:
        name, why = "NORMAL", f"efficiency {er:.2f}, range {vol:.1f}x"
    return {"name": name, "er": round(er, 3), "dir": direction, "vol": round(vol, 2), "move": round(move, 3), "why": why}


def adjust(reg, strategy, side, index_symbols=()):
    """-> (size multiplier, veto reason or ''). `strategy` may carry an @SESSION suffix."""
    base = (strategy or "").split("@")[0]
    name = (reg or {}).get("name", "NORMAL")
    trend_f, revert_f = base in TREND_FAMILY, base in REVERT_FAMILY
    long_ = side == "buy"
    m = 1.0
    if name in ("TREND_UP", "TREND_DOWN"):
        up = name == "TREND_UP"
        with_trend = long_ == up
        strong = (reg.get("er", 0) >= 0.5)
        if with_trend:
            m = 1.15 if trend_f else 1.0
        else:
            m = 0.6
            if revert_f and base in ("FLUSH_FADE", "FLUSH_SHORT", "GAP_FADE", "MEAN_REVERT") and strong:
                return 0.0, f"market is trending {'up' if up else 'down'} hard — not fading it"
            if strong:
                m = 0.5
    elif name == "CHOP":
        m = 0.6 if trend_f else (1.2 if revert_f else 1.0)
    elif name == "VOLATILE":
        m = 0.65
    elif name == "QUIET":
        m = 0.7 if trend_f else 1.0
    return m, ""
