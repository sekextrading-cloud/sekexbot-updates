"""Suggested stop-loss / take-profit for a manual order.

Not a forecast: it places the stop just beyond the nearest real support (for a buy) or resistance
(for a short), sized by the stock's own volatility (ATR), and sets the target at a reward:risk
multiple, pulled in to the next level when one sits in the way. Three styles:

  Scalp  - tight: intraday stop (0.5–1.2 × 3-min ATR), target 1.5R
  Day    - the bot's default read: stop 0.6–2.5 × 3-min ATR past the level, target 2R or the next level
  Swing  - wide: stop about 1 × daily ATR (or past the 20-day low/high), target 2.5R or the 20-day high/low

It also suggests a size: the same base risk the auto-trader uses (15% of your daily max loss).
"""
import math

from .analyst import _cluster, _pivots
from .indicators import enrich, ribbon


def _levels(df1m, atr3):
    h = ribbon(df1m)
    src = h if len(h) >= 12 else df1m
    res, sup = _pivots(src, 3)
    d = enrich(df1m)
    extra = [float(d["high"].max()), float(d["low"].min()), float(d["vwap"].iloc[-1])]
    return [lv for lv, _ in _cluster(res + sup + extra, tol=0.35 * atr3)]


def suggest(side: str, entry: float, df1m, daily: dict | None, bias: str = "NEUTRAL",
            daily_max_loss: float = 200.0, risk_frac: float = 0.15, buying_power: float = 0.0) -> dict:
    d = 1 if side == "buy" else -1
    enr = enrich(df1m)
    atr1 = float(enr["atr"].iloc[-1]) or entry * 0.002
    atr3 = atr1 * 1.7
    datr = float(daily["atr"]) if daily and daily.get("atr") else atr3 * 6
    lv = sorted(_levels(df1m, atr3))
    behind = [l for l in lv if (l < entry - 0.05 * atr3 if d > 0 else l > entry + 0.05 * atr3)]
    ahead = [l for l in lv if (l > entry + 0.1 * atr3 if d > 0 else l < entry - 0.1 * atr3)]
    near_behind = (max(behind) if d > 0 else min(behind)) if behind else None
    ahead = sorted(ahead, key=lambda l: abs(l - entry))

    def build(name, lo_mult, hi_mult, unit, r_target, why_base, anchor=None, far_target=None):
        base = anchor if anchor is not None else near_behind
        raw = abs(entry - base) + 0.25 * unit if base is not None else 1.5 * unit
        floor = max(lo_mult * unit, entry * {"Scalp": 0.004, "Day": 0.007, "Swing": 0.02}[name], 0.02)
        dist = max(min(max(raw, lo_mult * unit), hi_mult * unit), floor)
        stop = entry - d * dist
        tgt = entry + d * r_target * dist
        note = why_base
        if base is not None and dist < raw - 1e-9 and dist < abs(entry - base):
            note = (f"stop kept tight ({hi_mult:g}× ATR) — the {'support' if d > 0 else 'resistance'} "
                    f"at {base:.2f} is further away")
        elif base is not None and dist > raw + 1e-9:
            note += f" (widened to {lo_mult:g}× ATR so normal noise doesn't hit it)"
        blocker = next((l for l in ahead if 1.2 * dist <= abs(l - entry) < r_target * dist), None)
        if blocker is not None:           # a level sits before the target: take profit just in front of it
            tgt = blocker - d * 0.05 * unit
            note += f"; target pulled in ahead of the level at {blocker:.2f}"
        if far_target is not None and abs(far_target - entry) >= 2 * dist and abs(far_target - entry) < abs(tgt - entry):
            tgt = far_target
        r = abs(tgt - entry) / dist
        return {"name": name, "stop": round(stop, 2), "target": round(tgt, 2), "r": round(r, 2),
                "risk_per_share": round(dist, 2), "why": note}

    lvl_txt = (f"stop just {'below support' if d > 0 else 'above resistance'} at {near_behind:.2f}"
               if near_behind is not None else "no nearby level — stop sized by volatility")
    presets = [
        build("Scalp", 0.5, 1.2, atr3, 1.5, f"tight intraday stop; {lvl_txt}"),
        build("Day", 0.6, 2.5, atr3, 2.0, lvl_txt),
    ]
    swing_anchor, swing_far = None, None
    if daily:
        lo20, hi20 = daily.get("lo20"), daily.get("hi20")
        cand = lo20 if d > 0 else hi20
        if cand and 0 < (entry - cand) * d <= 1.5 * datr:
            swing_anchor = cand
        far = hi20 if d > 0 else lo20
        if far and (far - entry) * d > 0:
            swing_far = far
    presets.append(build("Swing", 0.8, 1.6, datr, 2.5,
                         (f"stop past the 20-day {'low' if d > 0 else 'high'} {swing_anchor:.2f}" if swing_anchor
                          else "stop about one daily ATR away"), anchor=swing_anchor, far_target=swing_far))

    risk_dollars = daily_max_loss * risk_frac
    for p in presets:
        q = math.floor(risk_dollars / p["risk_per_share"]) if p["risk_per_share"] > 0 else 0
        if buying_power and entry > 0:
            q = min(q, math.floor(buying_power * 0.25 / entry))
        p["qty"] = max(q, 0)
        p["risk_at_qty"] = round(p["qty"] * p["risk_per_share"], 2)

    agrees = (bias == "BULLISH" and d > 0) or (bias == "BEARISH" and d < 0)
    against = (bias == "BULLISH" and d < 0) or (bias == "BEARISH" and d > 0)
    return {"side": side, "entry": round(entry, 2), "atr_intraday": round(atr3, 2), "atr_daily": round(datr, 2),
            "bias": bias, "trend": "with the trend" if agrees else "against the trend" if against else "no clear trend",
            "risk_budget": round(risk_dollars, 2), "presets": presets, "default": "Day"}
