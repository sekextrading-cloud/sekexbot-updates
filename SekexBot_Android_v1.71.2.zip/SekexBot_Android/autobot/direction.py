"""Early direction call: LONG, SHORT or WAIT for one stock, from what the chart says right now.

It is a weighted vote of eight things (each scored -1..+1): price vs VWAP, ribbon colour, swing structure (higher highs / lower
lows), 15-minute momentum, up-volume vs down-volume, where price sits in the day's range (a spike that is fading scores
negative), the market (SPY/QQQ), and the stock's own history (how often its gaps follow through or fade, from the overnight
study). It says WAIT when the votes disagree or the price is stretched. It is a lean, not a prediction: the overnight study
keeps score of how often past calls were right, and the dashboard shows that number."""
import math

W = {"vwap": 2.0, "ribbon": 2.0, "structure": 2.0, "momentum": 1.5, "volume": 1.0, "range": 1.5, "market": 0.5, "history": 1.5}
LABEL = {"vwap": "price vs VWAP", "ribbon": "ribbon", "structure": "swing structure", "momentum": "15-min momentum",
         "volume": "buying vs selling volume", "range": "position in the range", "market": "market (SPY/QQQ)", "history": "this stock's gap history"}


def _clip(x, lo=-1.0, hi=1.0):
    return max(lo, min(hi, x))


def direction(d, move_pct=0.0, ribbon=None, bias=0, prior=None, min_bars=15):
    """d: enriched 1-minute DataFrame (open/high/low/close/volume/vwap/atr), oldest first, pre-market included.
    prior: {"follow": n, "fade": n} from the overnight study. Returns a dict."""
    if d is None or len(d) < min_bars:
        return {"call": "WAIT", "score": 0, "agree": 0, "reasons": ["not enough bars yet"], "stretched": False}
    last = d.iloc[-1]
    c, v, a = float(last["close"]), float(last["vwap"]), max(float(last["atr"]), 1e-9)
    hi, lo = float(d["high"].max()), float(d["low"].min())
    comp = {}
    comp["vwap"] = _clip((c - v) / (1.5 * a))
    rs = (ribbon or {}).get("state", 0) if (ribbon or {}).get("ready") else 0
    comp["ribbon"] = float(rs)
    w = d.tail(30)
    if len(w) >= 30:
        b = [w.iloc[i * 10:(i + 1) * 10] for i in range(3)]
        hs = [float(x["high"].max()) for x in b]
        ls = [float(x["low"].min()) for x in b]
        sg = lambda x: 1 if x > 0 else (-1 if x < 0 else 0)
        comp["structure"] = (sg(hs[1] - hs[0]) + sg(hs[2] - hs[1]) + sg(ls[1] - ls[0]) + sg(ls[2] - ls[1])) / 4
    else:
        comp["structure"] = 0.0
    n15 = min(15, len(d) - 1)
    comp["momentum"] = _clip((c - float(d["close"].iloc[-1 - n15])) / (a * math.sqrt(n15) * 1.2))
    t = d.tail(30)
    up = float(t.loc[t["close"] >= t["open"], "volume"].sum())
    dn = float(t.loc[t["close"] < t["open"], "volume"].sum())
    comp["volume"] = _clip((up - dn) / (up + dn)) if up + dn > 0 else 0.0
    rng = hi - lo
    comp["range"] = _clip(2 * (c - lo) / rng - 1) if rng > 0 else 0.0
    comp["market"] = float(_clip(bias))
    pr = prior or {}
    n = pr.get("follow", 0) + pr.get("fade", 0)
    if n >= 3 and abs(move_pct) >= 0.8:
        p = (pr.get("follow", 0) + 2) / (n + 4)
        comp["history"] = _clip((2 * p - 1) * (1 if move_pct > 0 else -1) * 1.5)
    tot_w = sum(W[k] for k in comp)
    score = sum(W[k] * comp[k] for k in comp) / tot_w            # -1..+1
    s100 = int(round(100 * score))
    signs = [1 if comp[k] > 0.15 else (-1 if comp[k] < -0.15 else 0) for k in comp]
    pos, neg = signs.count(1), signs.count(-1)
    stretched = abs(c - v) > 6 * a
    call = "WAIT"
    if s100 >= 25 and neg <= 2:
        call = "LONG"
    elif s100 <= -25 and pos <= 2:
        call = "SHORT"
    why = []
    ordered = sorted(comp, key=lambda k: abs(comp[k]) * W[k], reverse=True)
    for k in ordered[:4]:
        if abs(comp[k]) >= 0.15:
            why.append(f"{LABEL[k]} {'up' if comp[k] > 0 else 'down'}")
    if call == "WAIT":
        why.insert(0, "votes disagree" if pos and neg else "no clear lean")
    if stretched and call != "WAIT":
        why.append("stretched from VWAP: better on a pullback")
    agree = int(round(100 * max(pos, neg) / max(len(comp), 1)))
    return {"call": call, "score": s100, "agree": agree, "reasons": why, "stretched": stretched,
            "parts": {k: round(v_, 2) for k, v_ in comp.items()}}
