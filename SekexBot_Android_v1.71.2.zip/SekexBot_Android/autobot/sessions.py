"""US equity trading sessions (all times America/New_York).

    OVERNIGHT   8:00 PM - 4:00 AM   (Sun night -> Fri morning; the night before each trading day)
    PRE         4:00 AM - 9:30 AM
    REGULAR     9:30 AM - 4:00 PM   (or the early close)
    AFTER       4:00 PM - 8:00 PM   (early-close days: close -> close + 4h)
"""
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from zoneinfo import ZoneInfo

NY = ZoneInfo("America/New_York")
EXT_NAMES = ("PRE", "AFTER", "OVERNIGHT")
LABEL = {"PRE": "Pre-market", "REGULAR": "Regular hours", "AFTER": "After-hours", "OVERNIGHT": "Overnight"}


@dataclass
class Session:
    name: str
    start: datetime
    end: datetime
    trade_date: date

    @property
    def label(self):
        return LABEL[self.name]


def _at(d: date, t: time) -> datetime:
    return datetime.combine(d, t, NY)


def sessions_for(trading_day, d: date):
    """All sessions whose trade date is d (empty list if d isn't a trading day).
    trading_day(d) -> (open_dt, close_dt) or None."""
    td = trading_day(d)
    if not td:
        return []
    op, cl = td
    after_end = min(cl + timedelta(hours=4), _at(d, time(20, 0)))
    return [
        Session("OVERNIGHT", _at(d - timedelta(days=1), time(20, 0)), _at(d, time(4, 0)), d),
        Session("PRE", _at(d, time(4, 0)), op, d),
        Session("REGULAR", op, cl, d),
        Session("AFTER", cl, after_end, d),
    ]


def current_session(trading_day, now: datetime):
    for d in (now.date(), now.date() + timedelta(days=1)):
        for s in sessions_for(trading_day, d):
            if s.start <= now < s.end:
                return s
    return None


def next_session(trading_day, now: datetime, names) -> Session | None:
    """Next session (starting after now) whose name is in `names`."""
    for i in range(0, 8):
        for s in sessions_for(trading_day, now.date() + timedelta(days=i)):
            if s.name in names and s.start > now:
                return s
    return None


def bot_day(now: datetime) -> str:
    """The bot's 'day' for the daily loss limit runs 8:00 PM -> 8:00 PM,
    so an overnight session counts toward the trading day it leads into."""
    return (now + timedelta(hours=4)).date().isoformat()
