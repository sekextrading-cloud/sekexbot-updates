"""BullGPT-style chart read.

1) analyze(): computed from real bars — support/resistance, Fibonacci, RSI, VWAP, EMA ribbon,
   directional bias, and bull/bear trade scenarios with entry/stop/targets.
   The "bias score" is a rules-based score, and the hit rate shown is the bot's MEASURED
   win rate for that setup from its own trade history (not a made-up percentage).
2) vision_read(): optional — send a chart screenshot to Claude (needs ANTHROPIC_API_KEY in .env)
   for a written read of any chart, including ones from TradingView.
"""
import json
import os
import re

import numpy as np
import pandas as pd
import requests

from .indicators import enrich, ribbon, rsi


def _pivots(h: pd.DataFrame, k: int = 3):
    hi, lo = h["high"].values, h["low"].values
    res, sup = [], []
    for i in range(k, len(h) - k):
        if hi[i] == max(hi[i - k:i + k + 1]):
            res.append(hi[i])
        if lo[i] == min(lo[i - k:i + k + 1]):
            sup.append(lo[i])
    return res, sup


def _cluster(levels, tol):
    levels = sorted(levels)
    out = []
    for lv in levels:
        if out and abs(lv - out[-1][0]) <= tol:
            n = out[-1][1] + 1
            out[-1] = ((out[-1][0] * out[-1][1] + lv) / n, n)
        else:
            out.append((lv, 1))
    return out  # (level, touches)


def analyze(symbol: str, df1m: pd.DataFrame, market_bias: int = 0, learner=None) -> dict:
    if df1m is None or len(df1m) < 20:
        return {"symbol": symbol, "error": "Not enough intraday bars yet (need ~20 minutes of data)."}
    d = enrich(df1m)
    h = ribbon(df1m)
    last = d.iloc[-1]
    price, atr1 = float(last["close"]), float(last["atr"])
    atr3 = float(h["atr"].iloc[-1]) if len(h) else atr1 * 1.7
    hod, lod = float(d["high"].max()), float(d["low"].min())

    # support / resistance from 3-min swing pivots + day extremes + VWAP
    src = h if len(h) >= 9 else d
    res, sup = _pivots(src)
    lv = _cluster(res + sup + [hod, lod], tol=0.35 * atr3)
    resist = sorted([(l, t) for l, t in lv if l > price * 1.0005], key=lambda x: x[0])[:3]
    support = sorted([(l, t) for l, t in lv if l < price * 0.9995], key=lambda x: -x[0])[:3]

    # Fibonacci of the day's range, oriented by which extreme came last
    up_leg = d["high"].idxmax() > d["low"].idxmin()
    rng = hod - lod
    fib = {}
    for f in (0.236, 0.382, 0.5, 0.618, 0.786):
        fib[str(f)] = round(hod - f * rng if up_leg else lod + f * rng, 2)

    rsi1 = float(last["rsi"])
    rsi3 = float(rsi(h["close"]).iloc[-1]) if len(h) > 15 else rsi1
    vwap = float(last["vwap"])
    rb_state = int(h["state"].iloc[-1]) if len(h) else 0
    slow = float(h["slow"].iloc[-1]) if len(h) else float(last["ema21"])
    slope_atr = float((h["slow"].iloc[-1] - h["slow"].iloc[-6]) / atr3) if len(h) > 6 and atr3 else 0.0

    # rules-based bias score (-100 .. +100)
    score = 0
    score += 30 * rb_state
    score += 20 if price > vwap else -20
    score += 15 if price > slow else -15
    score += 10 * np.clip(slope_atr, -1, 1)
    score += 10 * market_bias
    if rsi3 > 75:
        score -= 10   # stretched
    if rsi3 < 25:
        score += 10
    score = int(np.clip(score, -100, 100))
    bias = "BULLISH" if score >= 25 else "BEARISH" if score <= -25 else "NEUTRAL"

    r1 = resist[0][0] if resist else price + 2 * atr3
    s1 = support[0][0] if support else price - 2 * atr3

    levels_up = sorted(l for l, _ in lv)
    def scen(side):
        d = 1 if side == "long" else -1
        # trigger: break of the nearest level in the trade direction, or current price if already through
        near = r1 if d > 0 else s1
        entry = near + d * 0.05 * atr3 if abs(near - price) < 1.0 * atr3 else price
        # stop: just beyond the nearest opposite level / slow line, bounded to 0.6–2.5 ATR
        opp = [l for l in levels_up if (l < entry if d > 0 else l > entry)]
        base = (max(opp) if d > 0 else min(opp)) if opp else entry - d * 1.5 * atr3
        stop = base - d * 0.25 * atr3
        dist = min(max(abs(entry - stop), 0.6 * atr3), 2.5 * atr3)
        stop = entry - d * dist
        ahead = [l for l in levels_up if (l > entry + 0.1 * atr3 if d > 0 else l < entry - 0.1 * atr3)]
        ahead = ahead if d > 0 else ahead[::-1]
        near_lv = [abs(l - entry) for l in ahead if abs(l - entry) <= 4 * dist]   # ignore levels > 4R away
        t1 = entry + d * max(near_lv[0] if near_lv else 0, 1.5 * dist)
        t2 = entry + d * max(near_lv[1] if len(near_lv) > 1 else 0, 2.5 * dist)
        return {"entry": round(entry, 2), "stop": round(stop, 2), "target1": round(t1, 2), "target2": round(t2, 2),
                "rr1": round(abs(t1 - entry) / dist, 2), "rr2": round(abs(t2 - entry) / dist, 2)}

    long_s, short_s = scen("long"), scen("short")

    history = None
    if learner:
        rows = [r for r in learner.leaderboard() if r["strategy"] == "RIBBON_FLIP"]
        n = sum(r["trades"] for r in rows)
        if n >= 10:
            wr = sum(r["win_rate"] * r["trades"] for r in rows) / n
            history = {"setup": "RIBBON_FLIP", "trades": round(n), "win_rate": round(wr, 1)}

    ribbon_txt = {1: "green (uptrend)", -1: "red (downtrend)", 0: "not formed yet"}[rb_state]
    notes = [
        f"Ribbon is {ribbon_txt}; price is {'above' if price > slow else 'below'} the slow (white) line "
        f"and {'above' if price > vwap else 'below'} VWAP {vwap:.2f}.",
        f"RSI {rsi1:.0f} (1m) / {rsi3:.0f} (3m)" + (" — stretched, pullback risk." if rsi3 > 70 else
                                                   " — washed out, bounce risk." if rsi3 < 30 else "."),
        f"Nearest resistance {r1:.2f}, support {s1:.2f}. Day range {lod:.2f}–{hod:.2f}.",
    ]
    if bias == "BULLISH":
        notes.append(f"Plan: favor longs on a hold above {max(s1, vwap):.2f}; a close back under {slow:.2f} flips the read.")
    elif bias == "BEARISH":
        notes.append(f"Plan: favor shorts/avoid longs while below {min(r1, vwap):.2f}; reclaim of {slow:.2f} flips the read.")
    else:
        notes.append("Plan: no edge — wait for a ribbon flip or a break of the range.")

    return {
        "symbol": symbol, "price": round(price, 2), "bias": bias, "bias_score": score,
        "ribbon": rb_state, "vwap": round(vwap, 2), "rsi_1m": round(rsi1, 1), "rsi_3m": round(rsi3, 1),
        "resistance": [{"level": round(l, 2), "touches": t} for l, t in resist],
        "support": [{"level": round(l, 2), "touches": t} for l, t in support],
        "fib": fib, "fib_leg": "up" if up_leg else "down",
        "long_scenario": long_s, "short_scenario": short_s, "history": history, "notes": notes,
    }


VISION_PROMPT = """You are a sharp intraday stock/ETF technical analyst (think BullGPT) working alongside an
automated trading bot. Read the attached chart screenshot and produce a concrete trading GAME PLAN.

Rules:
- Read price levels from the chart's price axis. Only give numbers you can actually see or reasonably
  interpolate between axis labels; if the axis isn't readable, set numeric fields to null and describe levels in words.
- Identify the ticker, timeframe/interval and last price if shown in the screenshot.
- Look for: trend structure (higher highs/lows or lower highs/lows), ranges, repeated rejections/bounces
  (count the touches), gaps, where big moves tend to start (e.g. at the open), long wicks / fades, volume spikes,
  and any indicators drawn (moving averages, EMA ribbons, VWAP, RSI, BUY/SELL labels).
- Timing is US Eastern time. Regular session 9:30-4:00; pre-market 4:00-9:30; after-hours 4:00-8:00 PM;
  overnight 8 PM-4 AM.
- Give 2-3 scenarios (bull / range / bear) each with a trigger you can check on a live chart,
  entry, stop and 1-2 targets. Stops must be on the correct side of the entry.
- Never invent win-rate percentages. Confidence is only low/medium/high.
- The user's automated bot (for the bot_view field) trades: Opening Range Breakout of the first 15 min after
  9:45 with volume; Gap-and-Go only on gaps of 3%+ before 10:45; VWAP reclaim; EMA9 pullback in a trend;
  mean-reversion after a 2+ ATR flush below VWAP; and an EMA-ribbon flip (3-min bars, needs ~30 min of data).
  It is long-only by default. After-hours/overnight it trades long-only momentum with limit orders.
  Explain briefly which of those setups (if any) this chart is likely to trigger and at what levels.
- If the user asked a question, answer it directly in "answer".

Reply with ONLY this JSON (no markdown fences):
{"symbol": str|null, "timeframe": str|null, "last_price": number|null,
 "trend": "uptrend"|"downtrend"|"range"|"range, weakening"|"range, strengthening"|"breakout"|"breakdown",
 "trend_summary": str,
 "observations": [str],
 "resistance": [{"level": number|null, "note": str}],
 "support": [{"level": number|null, "note": str}],
 "timing": [{"window": str, "what": str}],
 "scenarios": [{"name": str, "bias": "bull"|"bear"|"neutral", "trigger": str,
                "entry": number|null, "stop": number|null, "targets": [number]}],
 "lean": str, "invalidation": str, "bot_view": str, "answer": str|null,
 "confidence": "low"|"medium"|"high", "caveats": str}"""

_MODEL_CACHE = {}


# ---------------- AI provider: Claude (Anthropic) or ChatGPT (OpenAI) ----------------
# Every AI feature in the app speaks the Anthropic message format. When the provider is ChatGPT, ai_post()
# translates the request to OpenAI's Chat Completions API and the reply back, so callers don't change.
class _Resp:
    def __init__(self, status, text, data=None):
        self.status_code, self.text, self._d = status, text, data

    def json(self):
        return self._d if self._d is not None else json.loads(self.text)


def provider() -> str:
    """'anthropic' or 'openai': the one you chose, or whichever has a key saved."""
    p = os.getenv("AI_PROVIDER", "").strip().lower()
    a, o = bool(os.getenv("ANTHROPIC_API_KEY")), bool(os.getenv("OPENAI_API_KEY"))
    if p == "openai" and (o or not a):
        return "openai"
    if p == "anthropic" and (a or not o):
        return "anthropic"
    return "anthropic" if (a or not o) else "openai"


def ai_key() -> str:
    return os.getenv("OPENAI_API_KEY" if provider() == "openai" else "ANTHROPIC_API_KEY", "")


def ai_name() -> str:
    return "ChatGPT (OpenAI)" if provider() == "openai" else "Claude"


def _openai_base() -> str:
    return os.getenv("OPENAI_BASE_URL", "https://api.openai.com")


def _pick_openai(key: str) -> str:
    env = os.getenv("OPENAI_MODEL", "").strip()
    if env:
        return env
    if "oa" in _MODEL_CACHE:
        return _MODEL_CACHE["oa"]
    try:
        r = requests.get(_openai_base() + "/v1/models", timeout=20, headers={"Authorization": "Bearer " + key})
        best, bv = None, (0.0,)
        for m in r.json().get("data", []):
            mm = re.match(r"^gpt-(\d+(?:\.\d+)?)$", m.get("id", ""))          # plain flagship names only (no -mini, -codex, dated...)
            if mm and (float(mm.group(1)),) > bv:
                best, bv = m["id"], (float(mm.group(1)),)
        if best:
            _MODEL_CACHE["oa"] = best
            return best
    except Exception:
        pass
    return "gpt-4o"


def _pick_model(key: str) -> str:
    """Claude: ANTHROPIC_MODEL if set, else the newest Sonnet the API lists. ChatGPT: OPENAI_MODEL or the newest plain gpt-N."""
    if provider() == "openai":
        return _pick_openai(key)
    env = os.getenv("ANTHROPIC_MODEL", "").strip()
    if env:
        return env
    if "m" in _MODEL_CACHE:
        return _MODEL_CACHE["m"]
    try:
        r = requests.get(os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com") + "/v1/models?limit=100", timeout=20,
                         headers={"x-api-key": key, "anthropic-version": "2023-06-01"})
        ids = [m["id"] for m in r.json().get("data", [])]   # newest first
        pick = next((m for m in ids if "sonnet" in m), None) or next((m for m in ids if "opus" in m), None) or ids[0]
        _MODEL_CACHE["m"] = pick
        return pick
    except Exception:
        return "claude-sonnet-4-5"   # fallback if the model list can't be fetched


def ai_post(timeout, payload):
    """Send an Anthropic-format request ({model, max_tokens, system?, messages}) to the chosen provider.
    Returns an object with .status_code, .text and .json() in the Anthropic shape ({content:[{text}], usage})."""
    key = ai_key()
    if provider() != "openai":
        return requests.post(_base() + "/v1/messages", timeout=timeout, headers={
            "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"}, json=payload)
    msgs = []
    if payload.get("system"):
        msgs.append({"role": "system", "content": payload["system"]})
    for m in payload.get("messages", []):
        c = m["content"]
        if isinstance(c, str):
            msgs.append({"role": m["role"], "content": c})
            continue
        parts = []
        for b in c:
            if b.get("type") == "text":
                parts.append({"type": "text", "text": b["text"]})
            elif b.get("type") == "image":
                src = b["source"]
                parts.append({"type": "image_url", "image_url": {"url": f"data:{src['media_type']};base64,{src['data']}"}})
        msgs.append({"role": m["role"], "content": parts})
    model = payload["model"]
    reasoning = model.startswith(("gpt-5", "o1", "o3", "o4"))
    body = {"model": model, "messages": msgs, "max_completion_tokens": int(payload.get("max_tokens", 1000)) * (4 if reasoning else 1)}
    if model.startswith("gpt-5"):
        body["reasoning_effort"] = "low"
    r = requests.post(_openai_base() + "/v1/chat/completions", timeout=timeout,
                      headers={"Authorization": "Bearer " + key, "Content-Type": "application/json"}, json=body)
    if r.status_code != 200:
        return _Resp(r.status_code, r.text)
    j = r.json()
    text = (((j.get("choices") or [{}])[0].get("message") or {}).get("content")) or ""
    u = j.get("usage") or {}
    return _Resp(200, r.text, {"content": [{"type": "text", "text": text}], "model": j.get("model", model),
                               "usage": {"input_tokens": u.get("prompt_tokens", 0), "output_tokens": u.get("completion_tokens", 0)}})


def _rr(plan: dict):
    """Compute risk:reward ourselves instead of trusting the model's arithmetic; drop invalid stops."""
    for sc in plan.get("scenarios") or []:
        e, st, tg = sc.get("entry"), sc.get("stop"), [t for t in (sc.get("targets") or []) if isinstance(t, (int, float))]
        sc["rr"] = []
        if isinstance(e, (int, float)) and isinstance(st, (int, float)) and e != st:
            risk = abs(e - st)
            d = 1 if sc.get("bias") != "bear" else -1
            if (e - st) * d <= 0:
                sc["warning"] = "stop is on the wrong side of the entry — ignore these numbers"
            sc["rr"] = [round((t - e) * d / risk, 2) for t in tg]
    return plan


def _api_error(status: int, text: str) -> str:
    low = text.lower()
    who = ai_name()
    if provider() == "openai":
        if status == 401 or "invalid_api_key" in low or "incorrect api key" in low:
            return "ChatGPT (OpenAI) rejected the API key. Re-enter it in 🔑 Broker keys → AI."
        if "insufficient_quota" in low or "exceeded your current quota" in low or "billing" in low:
            return ("Your OpenAI API account has no credits. Add credits at platform.openai.com → Billing "
                    "(a ChatGPT Plus/Pro subscription does not include API credits).")
        if status == 404 or "model_not_found" in low or "does not exist" in low:
            _MODEL_CACHE.pop("oa", None)
            return "That ChatGPT model wasn't found. Clear the model name in 🔑 Broker keys → AI so the bot picks one."
        if status == 413 or "too large" in low:
            return "The image is too large. Crop the screenshot to just the chart and try again."
        if status == 429:
            return "OpenAI rate limit hit. Wait a minute and try again."
        if status in (500, 502, 503) or "overloaded" in low:
            return "ChatGPT is busy right now. Try again in a minute."
        return f"{who} API error {status}: {text[:300]}"
    if status == 401 or "authentication" in low or "invalid x-api-key" in low:
        return "Claude rejected the API key. Re-enter it in 🔑 Broker keys → AI."
    if "credit balance" in low or "billing" in low:
        return ("Your Anthropic API account has no credits. Add credits at console.anthropic.com → Plans & Billing "
                "(a Claude.ai Pro/Max subscription does not include API credits).")
    if status == 404 or "model" in low and "not" in low:
        return "The Claude model wasn't found. Clear ANTHROPIC_MODEL in .env so the bot auto-picks one."
    if status == 413 or "too large" in low:
        return "The image is too large. Crop the screenshot to just the chart and try again."
    if status == 429:
        return "Claude API rate limit hit. Wait a minute and try again."
    if status in (500, 502, 503, 529) or "overloaded" in low:
        return "Claude is busy right now. Try again in a minute."
    return f"{who} API error {status}: {text[:300]}"


def _base():
    return os.getenv("ANTHROPIC_BASE_URL", "https://api.anthropic.com")


def ai_ping() -> dict:
    """Tiny request to check the key, credits and model."""
    key = ai_key()
    if not key:
        return {"ok": False, "error": f"No {ai_name()} API key saved yet."}
    model = _pick_model(key)
    try:
        r = ai_post(30, {"model": model, "max_tokens": 5, "messages": [{"role": "user", "content": "Reply OK"}]})
    except Exception as e:
        return {"ok": False, "error": f"Couldn't reach {ai_name()}: {str(e)[:150]}"}
    if r.status_code != 200:
        if r.status_code == 404:
            _MODEL_CACHE.pop("m", None)
            _MODEL_CACHE.pop("oa", None)
        return {"ok": False, "error": _api_error(r.status_code, r.text)}
    return {"ok": True, "model": model, "provider": provider()}


def vision_read(image_b64: str, media_type: str = "image/png", question: str = "") -> dict:
    key = ai_key()
    if not key:
        return {"error": "Add your Claude or ChatGPT API key (🔑 Broker keys → AI) to enable screenshot analysis."}
    model = _pick_model(key)
    content = [{"type": "image", "source": {"type": "base64", "media_type": media_type, "data": image_b64}},
               {"type": "text", "text": VISION_PROMPT + (f"\n\nUser's question: {question.strip()}" if question.strip() else "")}]
    r = ai_post(120, {"model": model, "max_tokens": 3000, "messages": [{"role": "user", "content": content}]})
    if r.status_code == 404 and not os.getenv("ANTHROPIC_MODEL"):
        _MODEL_CACHE.pop("m", None)
        _MODEL_CACHE.pop("oa", None)
    if r.status_code != 200:
        return {"error": _api_error(r.status_code, r.text)}
    text = "".join(b.get("text", "") for b in r.json().get("content", []))
    try:
        s, e = text.index("{"), text.rindex("}") + 1
        plan = json.loads(text[s:e])
    except Exception:
        return {"trend_summary": text, "scenarios": [], "model": model}
    plan["model"] = model
    return _rr(plan)
