"""SQLite trade journal."""
import sqlite3
import threading

from .config import DATA_DIR

DB_FILE = DATA_DIR / "trades.db"
_lock = threading.Lock()

SCHEMA = """
CREATE TABLE IF NOT EXISTS trades (
  id TEXT PRIMARY KEY, day TEXT, mode TEXT, symbol TEXT, side TEXT, strategy TEXT, exit_profile TEXT,
  bucket TEXT, qty REAL, entry REAL, stop REAL, target REAL, risk REAL, opened_at TEXT,
  closed_at TEXT, exit REAL, pnl REAL, r REAL, status TEXT, note TEXT, regime TEXT
);
"""


def _conn():
    c = sqlite3.connect(DB_FILE, check_same_thread=False)
    c.row_factory = sqlite3.Row
    return c


with _lock:
    _c = _conn()
    _c.executescript(SCHEMA)
    try:                                   # older journals: add the regime column
        _c.execute("ALTER TABLE trades ADD COLUMN regime TEXT")
    except Exception:
        pass
    _c.execute("""CREATE TABLE IF NOT EXISTS options_trades (
      id TEXT PRIMARY KEY, day TEXT, mode TEXT, underlying TEXT, direction TEXT, style TEXT, long_sym TEXT, short_sym TEXT,
      qty INTEGER, expiry TEXT, strikes TEXT, entry REAL, exit REAL, pnl REAL, opened_at TEXT, closed_at TEXT,
      status TEXT, reason TEXT, regime TEXT, why TEXT)""")
    _c.commit()
    _c.close()


def upsert(t: dict):
    cols = ["id", "day", "mode", "symbol", "side", "strategy", "exit_profile", "bucket", "qty", "entry", "stop",
            "target", "risk", "opened_at", "closed_at", "exit", "pnl", "r", "status", "note", "regime"]
    vals = [t.get(k) for k in cols]
    with _lock:
        c = _conn()
        c.execute(f"INSERT OR REPLACE INTO trades ({','.join(cols)}) VALUES ({','.join('?' * len(cols))})", vals)
        c.commit()
        c.close()


def recent(limit=100):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute("SELECT * FROM trades ORDER BY opened_at DESC LIMIT ?", (limit,))]
        c.close()
    return rows


def daily_summary(limit=30):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute(
            "SELECT day, mode, COUNT(*) trades, ROUND(SUM(pnl),2) pnl, "
            "ROUND(100.0*SUM(CASE WHEN pnl>0 THEN 1 ELSE 0 END)/COUNT(*),1) win_rate, ROUND(AVG(r),2) avg_r "
            "FROM trades WHERE status='closed' GROUP BY day, mode ORDER BY day DESC LIMIT ?", (limit,))]
        c.close()
    return rows


def closed_today(day, symbol, mode=None):
    """Closed trades for one symbol on one bot day, oldest first (survives app restarts)."""
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute("SELECT * FROM trades WHERE day=? AND symbol=? AND status='closed' ORDER BY opened_at", (day, symbol))]
        c.close()
    return [r for r in rows if not mode or r.get("mode") in (None, mode)]


def close_stale(keep_ids, held_symbols, cutoff_iso):
    """Rows left 'open'/'pending' by a crash, restart or manual close: nothing tracks them any more, so mark
    them stale instead of leaving them in the journal forever. Returns how many were cleaned."""
    n = 0
    with _lock:
        c = _conn()
        rows = c.execute("SELECT id, symbol, status, opened_at FROM trades WHERE status IN ('open','pending')").fetchall()
        for r in rows:
            if r["id"] in keep_ids or r["symbol"] in held_symbols:
                continue
            if r["opened_at"] and str(r["opened_at"])[:19] > cutoff_iso[:19]:
                continue
            c.execute("UPDATE trades SET status='stale', note=COALESCE(NULLIF(note,''),'') || ' [no longer tracked]' WHERE id=?",
                      (r["id"],))
            n += 1
        c.commit()
        c.close()
    return n


def day_strategy_r(day, mode=None):
    """{strategy: (closed trades, net result in R)} for one bot day (feeds the per-strategy daily breaker).
    R is net dollars / the strategy's average risk per trade, so scale-outs and fees can't skew it."""
    with _lock:
        c = _conn()
        rows = c.execute("SELECT strategy, mode, COUNT(*) n, COALESCE(SUM(pnl),0) p, COALESCE(AVG(NULLIF(risk,0)),0) k "
                         "FROM trades WHERE day=? AND status='closed' GROUP BY strategy, mode", (day,)).fetchall()
        c.close()
    agg = {}
    for r in rows:
        if mode and r["mode"] not in (None, mode):
            continue
        n, p, kn = agg.get(r["strategy"], (0, 0.0, 0.0))
        agg[r["strategy"]] = (n + r["n"], p + r["p"], max(kn, r["k"]))
    return {k: (n, round(p / kn, 2) if kn > 0 else 0.0) for k, (n, p, kn) in agg.items()}


OPT_COLS = ["id", "day", "mode", "underlying", "direction", "style", "long_sym", "short_sym", "qty", "expiry", "strikes",
            "entry", "exit", "pnl", "opened_at", "closed_at", "status", "reason", "regime", "why"]


def opt_upsert(t: dict):
    with _lock:
        c = _conn()
        c.execute(f"INSERT OR REPLACE INTO options_trades ({','.join(OPT_COLS)}) VALUES ({','.join('?' * len(OPT_COLS))})",
                  [t.get(k) for k in OPT_COLS])
        c.commit()
        c.close()


def opt_recent(limit=15):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute("SELECT * FROM options_trades WHERE status IN ('closed','cancelled') ORDER BY opened_at DESC LIMIT ?", (limit,))]
        c.close()
    return rows


def opt_today_pnl(day, mode=None):
    with _lock:
        c = _conn()
        rows = c.execute("SELECT mode, COALESCE(SUM(pnl),0) p FROM options_trades WHERE day=? AND status='closed' GROUP BY mode", (day,)).fetchall()
        c.close()
    return float(sum(r["p"] for r in rows if not mode or r["mode"] in (None, mode)))
