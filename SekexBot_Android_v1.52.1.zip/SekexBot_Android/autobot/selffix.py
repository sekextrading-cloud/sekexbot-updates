"""🤖 Fix with Claude: describe a bug in plain words, Claude writes a patch, the app tests it, you approve it.

Flow (one job at a time):
  1. propose   Claude sees an index of the code, the recent log and your description, and picks the files
               it needs (up to 4). Then it reads those files and returns exact find/replace edits with a
               plain-English summary and a risk level.
  2. test      The edits are applied to a COPY of the app. Python files must compile, the dashboard's
               JavaScript must parse, and the copy must boot in simulator mode and serve the dashboard.
  3. apply     Only after you enter your Live PIN: the changed files are backed up, the patch is written,
               and the app restarts (trading resumes if it was running).
  4. safety    If the patched app fails to start 3 times, or a patched file won't compile, the boot guard
               restores the backup by itself. Undo restores the last backup with one tap (PIN).
Never touches your keys, .env or data. Available only on the phone itself, not over the remote link.
Uses your Anthropic API key (each fix costs a few cents to about a dollar of API credits)."""
import difflib
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import uuid
from pathlib import Path

import requests

from .analyst import _api_error, _base, _pick_model
from .config import BASE_DIR, DATA_DIR
from .helpdesk import recent_log, redact

ROOT = DATA_DIR / "selffix"
PENDING = ROOT / "pending.json"
ROLLED = ROOT / "rolled_back.json"
HISTORY = ROOT / "history.json"
EDITABLE = ["server.py", "web/dashboard.html", "web/login.html", "bin/sekex"] + \
           sorted(f"autobot/{p.name}" for p in (BASE_DIR / "autobot").glob("*.py")
                  if p.name not in ("selffix.py", "selffix_guard.py", "config.py"))
MAX_FILES = 4
MAX_BYTES = 420_000

PICK_PROMPT = """You are fixing a bug in SekexBot, a Python (FastAPI) + single-page HTML/JS app that runs on an
Android phone in Termux and trades the user's Alpaca account (paper or LIVE real money).
You get the user's bug report, recent log lines and an index of the source files.
Reply with ONLY a JSON object: {"files": ["path", ...], "why": "one sentence"} naming the 1-4 files you must
read to fix the bug, most important first. Use paths exactly as listed."""

FIX_PROMPT = """You are fixing a bug in SekexBot, a Python (FastAPI) + single-page HTML/JS app that runs on an
Android phone in Termux and trades the user's Alpaca account, possibly with REAL money.
Make the smallest safe change that fixes what the user describes. Rules:
- Never weaken risk controls (daily max loss, Live PIN, position caps, stops) unless the user explicitly asks.
- Never touch API keys, secrets, .env or data files. Do not add new dependencies.
- Keep the existing style. Do not reformat unrelated code.
- If you are not confident you found the cause, or the fix needs more than these files, return no edits and
  explain in "summary" what you would need.
Reply with ONLY a JSON object:
{"summary": "plain-English explanation for a non-programmer: what was wrong and what you changed",
 "cause": "one sentence, technical",
 "risk": "low" | "medium" | "high",
 "touches_trading": true/false,   // true if orders, sizing, stops or exits could behave differently
 "edits": [{"file": "path", "find": "exact text copied from the file, unique in that file, include enough lines",
            "replace": "the new text"}]}
Each "find" must appear EXACTLY ONCE in its file, character for character (including indentation)."""


def _index() -> str:
    out = []
    for rel in EDITABLE:
        p = BASE_DIR / rel
        if not p.exists():
            continue
        txt = p.read_text(errors="replace")
        head = ""
        m = re.search(r'"""(.*?)"""', txt, re.S) if rel.endswith(".py") else None
        if m:
            head = m.group(1).strip().splitlines()[0][:160]
        if rel.endswith(".py"):
            names = re.findall(r"^\s*(?:async )?def (\w+)|^class (\w+)", txt, re.M)
            names = [a or b for a, b in names]
        elif rel.endswith(".html"):
            names = re.findall(r"^(?:async )?function (\w+)", txt, re.M)
        else:
            names = re.findall(r"^(\w+)\(\)", txt, re.M)
        out.append(f"{rel} ({len(txt) // 1000} KB) {head}\n  " + ", ".join(names[:220]))
    return "\n".join(out)


def _ask(key, system, user, max_tokens):
    r = requests.post(_base() + "/v1/messages", timeout=300, headers={
        "x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
        json={"model": _pick_model(key), "max_tokens": max_tokens, "system": system,
              "messages": [{"role": "user", "content": user}]})
    if r.status_code != 200:
        raise RuntimeError(_api_error(r.status_code, r.text))
    j = r.json()
    text = "".join(b.get("text", "") for b in j.get("content", []))
    m = re.search(r"\{.*\}", text, re.S)
    if not m:
        raise RuntimeError("Claude didn't return a usable answer. Try describing the problem differently.")
    try:
        return json.loads(m.group(0)), j.get("usage", {})
    except json.JSONDecodeError as ex:
        raise RuntimeError(f"Claude's answer was cut off or malformed ({ex.msg}). Try again.")


def _free_port():
    s = socket.socket()
    s.bind(("127.0.0.1", 0))
    port = s.getsockname()[1]
    s.close()
    return port


class SelfFix:
    def __init__(self, version: str, get_status=None):
        self.version = version
        self.get_status = get_status or (lambda: {})
        self.lock = threading.Lock()
        self.job = None
        ROOT.mkdir(parents=True, exist_ok=True)

    # ---------- public ----------
    def status(self):
        rolled = None
        if ROLLED.exists():
            try:
                rolled = json.loads(ROLLED.read_text())
            except Exception:
                pass
        pend = None
        if PENDING.exists():
            try:
                pend = json.loads(PENDING.read_text())
            except Exception:
                pass
        return {"job": self._public_job(), "pending": pend, "rolled_back": rolled, "history": self.history()[:10],
                "key_set": bool(os.getenv("ANTHROPIC_API_KEY")), "can_undo": bool(self.history() and self.history()[0].get("backup")
                                                                                  and Path(self.history()[0]["backup"]).exists()
                                                                                  and not self.history()[0].get("undone"))}

    def start(self, problem: str, extra: str = ""):
        if not os.getenv("ANTHROPIC_API_KEY"):
            raise ValueError("Add a Claude API key first: ⚙ → Broker keys → AI chart reader.")
        if len(problem.strip()) < 8:
            raise ValueError("Describe the problem in a sentence or two (what you did, what happened, what you expected).")
        with self.lock:
            if self.job and self.job["state"] in ("reading", "fixing", "testing", "applying"):
                raise ValueError("A fix is already being worked on. Wait for it to finish.")
            self.job = {"id": uuid.uuid4().hex[:8], "state": "reading", "step": "Claude is reading the code index…",
                        "problem": problem.strip()[:2000], "extra": redact(extra)[:2000], "t": time.time()}
        threading.Thread(target=self._run, daemon=True, name="selffix").start()
        return self._public_job()

    def discard(self):
        with self.lock:
            if self.job and self.job["state"] in ("ready", "failed", "no_fix", "test_failed"):
                self.job = None
        return True

    def apply(self):
        j = self.job
        if not j or j["state"] != "ready":
            raise ValueError("There is no tested fix waiting to be applied.")
        j["state"], j["step"] = "applying", "Backing up and writing the fix…"
        stamp = time.strftime("%Y%m%d_%H%M%S")
        bdir = ROOT / f"backup_{stamp}_{j['id']}"
        files = sorted({e["file"] for e in j["edits"]})
        for rel in files:
            (bdir / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(BASE_DIR / rel, bdir / rel)
        for rel, txt in j["new_text"].items():
            tmp = (BASE_DIR / rel).with_suffix((BASE_DIR / rel).suffix + ".selffix")
            tmp.write_text(txt)
            os.replace(tmp, BASE_DIR / rel)
        rec = {"id": j["id"], "at": time.strftime("%Y-%m-%d %H:%M"), "problem": j["problem"][:300],
               "summary": j["summary"], "files": files, "backup": str(bdir), "risk": j["risk"],
               "version": self.version, "boots": 0}
        PENDING.write_text(json.dumps(rec, indent=1))
        ROLLED.unlink(missing_ok=True)
        self._add_history(rec)
        j["state"], j["step"] = "applied", "Fix applied. Restarting the app…"
        return rec

    def undo(self):
        h = self.history()
        if not h or not h[0].get("backup") or h[0].get("undone") or not Path(h[0]["backup"]).exists():
            raise ValueError("Nothing to undo.")
        rec = h[0]
        for rel in rec["files"]:
            src = Path(rec["backup"]) / rel
            if src.exists():
                shutil.copy2(src, BASE_DIR / rel)
        PENDING.unlink(missing_ok=True)
        rec["undone"] = time.strftime("%Y-%m-%d %H:%M")
        h[0] = rec
        HISTORY.write_text(json.dumps(h[:30], indent=1))
        return rec

    def history(self):
        try:
            return json.loads(HISTORY.read_text())
        except Exception:
            return []

    def confirm_after_boot(self, delay=90):
        """Called at startup: if a patch is pending and the app stays up for `delay` s, mark it healthy."""
        def _c():
            time.sleep(delay)
            if PENDING.exists():
                try:
                    st = json.loads(PENDING.read_text())
                except Exception:
                    return
                PENDING.unlink(missing_ok=True)
                h = self.history()
                for r in h:
                    if r.get("id") == st.get("id"):
                        r["confirmed"] = time.strftime("%Y-%m-%d %H:%M")
                HISTORY.write_text(json.dumps(h[:30], indent=1))
        threading.Thread(target=_c, daemon=True, name="selffix-confirm").start()

    # ---------- worker ----------
    def _public_job(self):
        j = self.job
        if not j:
            return None
        return {k: v for k, v in j.items() if k not in ("new_text",)}

    def _set(self, **kw):
        if self.job:
            self.job.update(kw)

    def _run(self):
        j = self.job
        key = os.getenv("ANTHROPIC_API_KEY", "")
        try:
            status = {k: redact(str(v))[:200] for k, v in (self.get_status() or {}).items()}
            ctx = (f"SekexBot version {self.version}.\nUser's bug report: {j['problem']}\n"
                   + (f"Error shown on screen: {j['extra']}\n" if j["extra"] else "")
                   + f"App status: {json.dumps(status)[:1500]}\n\nRecent log (secrets removed):\n"
                   + "\n".join(recent_log(150))[-12000:])
            pick, u1 = _ask(key, PICK_PROMPT, ctx + "\n\nSource index:\n" + _index(), 600)
            files = [f for f in pick.get("files", []) if f in EDITABLE][:MAX_FILES]
            if not files:
                raise RuntimeError("Claude couldn't tell which part of the app to look at. Add more detail and try again.")
            self._set(state="fixing", files=files, step=f"Claude is reading {', '.join(files)} and writing a fix…")
            blobs, total = [], 0
            for rel in files:
                txt = (BASE_DIR / rel).read_text(errors="replace")
                if total + len(txt) > MAX_BYTES:
                    continue
                total += len(txt)
                blobs.append(f"===== FILE: {rel} =====\n{txt}")
            fix, u2 = _ask(key, FIX_PROMPT, ctx + "\n\n" + "\n\n".join(blobs), 12000)
            edits = [e for e in fix.get("edits", []) if isinstance(e, dict) and e.get("file") in EDITABLE]
            self._set(summary=str(fix.get("summary", ""))[:3000], cause=str(fix.get("cause", ""))[:500],
                      risk=str(fix.get("risk", "medium")), touches_trading=bool(fix.get("touches_trading", True)),
                      usage={"in": u1.get("input_tokens", 0) + u2.get("input_tokens", 0),
                             "out": u1.get("output_tokens", 0) + u2.get("output_tokens", 0)})
            if not edits:
                return self._set(state="no_fix", step="Claude didn't propose a code change (see its explanation).")
            new_text, diffs = {}, []
            for e in edits:
                rel = e["file"]
                cur = new_text.get(rel) or (BASE_DIR / rel).read_text()
                n = cur.count(e["find"]) if e.get("find") else 0
                if n != 1:
                    raise RuntimeError(f"Claude's edit for {rel} didn't match the code exactly ({n} matches). Try again.")
                new_text[rel] = cur.replace(e["find"], e["replace"], 1)
            for rel, txt in new_text.items():
                old = (BASE_DIR / rel).read_text()
                diffs.append("".join(difflib.unified_diff(old.splitlines(True), txt.splitlines(True),
                                                          f"a/{rel}", f"b/{rel}", n=2)))
            self._set(state="testing", edits=edits, new_text=new_text, diff="\n".join(diffs)[:60000],
                      step="Testing the fix on a copy of the app…")
            ok, report = self._test(new_text)
            self._set(test=report)
            if not ok:
                return self._set(state="test_failed", step="The fix failed its tests, so it was NOT applied.")
            self._set(state="ready", step="Tested OK. Review it, then enter your PIN to apply.")
        except Exception as ex:
            self._set(state="failed", step=str(ex)[:400])

    def _test(self, new_text):
        report = []
        stage = ROOT / "stage"
        shutil.rmtree(stage, ignore_errors=True)
        shutil.copytree(BASE_DIR, stage, ignore=shutil.ignore_patterns(
            "data", "data_sim", ".git", "__pycache__", "*.zip", "docs", ".env", "node_modules"))
        for rel, txt in new_text.items():
            (stage / rel).write_text(txt)
        # the test copy must never notify, speak, open a tunnel or touch the real account
        (stage / "data_sim").mkdir(exist_ok=True)
        (stage / "data_sim" / "alerts.json").write_text(json.dumps(
            {"phone": False, "beep": False, "voice": False, "ntfy_topic": "", "tg_token": "", "tg_chat": ""}))
        # 1) compile
        for rel in new_text:
            if rel.endswith(".py"):
                r = subprocess.run([sys.executable, "-m", "py_compile", str(stage / rel)], capture_output=True, text=True)
                if r.returncode:
                    report.append(f"✗ {rel} doesn't compile: {r.stderr.strip()[-400:]}")
                    return False, report
                report.append(f"✓ {rel} compiles")
            elif rel.endswith(".html"):
                node = shutil.which("node")
                if node:
                    js = "\n;\n".join(re.findall(r"<script>(.*?)</script>", txt, re.S))
                    f = stage / "_check.js"
                    f.write_text(js)
                    r = subprocess.run([node, "--check", str(f)], capture_output=True, text=True)
                    if r.returncode:
                        report.append(f"✗ {rel} JavaScript error: {r.stderr.strip()[-400:]}")
                        return False, report
                    report.append(f"✓ {rel} JavaScript parses")
                else:
                    report.append(f"• {rel}: no JavaScript checker on this phone (checked by the boot test)")
        # 2) boot the copy in simulator mode
        port = _free_port()
        env = {k: v for k, v in os.environ.items()
               if not re.match(r"(ALPACA|APCA|ANTHROPIC|CF_|REMOTE_|DASH_|UPDATE_URL|TG_|NTFY)", k)}
        env.update(PYTHONDONTWRITEBYTECODE="1")
        logf = open(stage / "boot.log", "w")
        p = subprocess.Popen([sys.executable, "server.py", "--sim", "--port", str(port), "--host", "127.0.0.1"],
                             cwd=stage, env=env, stdout=logf, stderr=subprocess.STDOUT)
        try:
            up = False
            for _ in range(60):
                time.sleep(1)
                if p.poll() is not None:
                    break
                try:
                    with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/version", timeout=3) as r:
                        up = r.status == 200
                    if up:
                        break
                except Exception:
                    continue
            if not up:
                logf.flush()
                tail = (stage / "boot.log").read_text(errors="replace")[-800:]
                report.append("✗ The patched app didn't start:\n" + redact(tail))
                return False, report
            report.append("✓ Patched app starts (simulator)")
            with urllib.request.urlopen(f"http://127.0.0.1:{port}/", timeout=10) as r:
                if r.status != 200:
                    report.append(f"✗ Dashboard page returned {r.status}")
                    return False, report
            report.append("✓ Dashboard page loads")
            time.sleep(8)                               # let the background loops run a little
            logf.flush()
            log = (stage / "boot.log").read_text(errors="replace")
            if "Traceback" in log:
                i = log.find("Traceback")
                report.append("✗ Errors while running:\n" + redact(log[i:i + 800]))
                return False, report
            report.append("✓ Ran 8 s with no errors")
            return True, report
        finally:
            p.terminate()
            try:
                p.wait(10)
            except Exception:
                p.kill()
            logf.close()

    def _add_history(self, rec):
        h = self.history()
        h.insert(0, rec)
        for old in h[8:]:                      # keep the last 8 backups on disk
            if old.get("backup"):
                shutil.rmtree(old["backup"], ignore_errors=True)
        HISTORY.write_text(json.dumps(h[:30], indent=1))
