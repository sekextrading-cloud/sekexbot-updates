"""Entry strategies. Each looks at enriched 1-minute bars for one symbol and returns a Signal or None.

Every signal carries its own protective stop. How far the target sits (and whether the
stop trails) is an *exit profile* chosen by the learner, so the bot learns both
"which setup to take" and "how to get out of it".
"""
from dataclasses import dataclass, field
from datetime import time
from typing import Optional

import pandas as pd


OR_MINUTES = 15  # opening range length


@dataclass
class Signal:
    symbol: str
    strategy: str
    side: str          # "buy" (long) or "sell" (short)
    entry: float
    stop: float
    atr: float
    quality: float     # 0..1 setup quality
    extra: dict = field(default_factory=dict)

    @property
    def risk_per_share(self) -> float:
        return abs(self.entry - self.stop)


def _session(df: pd.DataFrame) -> pd.DataFrame:
    """Regular-hours bars of the latest day only."""
    if df.empty:
        return df
    day = df.index[-1].date()
    d = df[df.index.date == day]
    return d[(d.index.time >= time(9, 30)) & (d.index.time < time(16, 0))]


def _vol_ratio(d):
    va = d["vol_avg"].iloc[-1]
    return float(d["volume"].iloc[-1] / va) if va and va > 0 else 1.0


def _q(*parts):
    return max(0.0, min(1.0, sum(parts)))


def opening_range_breakout(sym, d, ctx) -> Optional[Signal]:
    if len(d) < OR_MINUTES + 2:
        return None
    rng = d.iloc[:OR_MINUTES]
    hi, lo = rng["high"].max(), rng["low"].min()
    mid = (hi + lo) / 2
    c, pc, a = d["close"].iloc[-1], d["close"].iloc[-2], d["atr"].iloc[-1]
    vr = _vol_ratio(d)
    if vr < 1.3 or d.index[-1].time() > time(11, 30):
        return None
    if pc <= hi < c and c > d["vwap"].iloc[-1]:
        stop = max(mid, c - 2 * a)
        return Signal(sym, "ORB", "buy", c, stop, a, _q(0.45, 0.1 * min(vr, 3), 0.15 * (ctx["bias"] > 0)))
    if ctx["shorts"] and pc >= lo > c and c < d["vwap"].iloc[-1]:
        stop = min(mid, c + 2 * a)
        return Signal(sym, "ORB", "sell", c, stop, a, _q(0.45, 0.1 * min(vr, 3), 0.15 * (ctx["bias"] < 0)))
    return None


def vwap_reclaim(sym, d, ctx) -> Optional[Signal]:
    if len(d) < 20:
        return None
    c, pc, v, pv = d["close"].iloc[-1], d["close"].iloc[-2], d["vwap"].iloc[-1], d["vwap"].iloc[-2]
    a, r = d["atr"].iloc[-1], d["rsi"].iloc[-1]
    vr = _vol_ratio(d)
    if pc < pv and c > v and d["ema9"].iloc[-1] > d["ema9"].iloc[-3] and 50 <= r <= 72 and vr >= 1.1:
        stop = min(d["low"].iloc[-5:].min(), c - 0.8 * a) - 0.1 * a
        return Signal(sym, "VWAP_RECLAIM", "buy", c, stop, a, _q(0.4, 0.08 * min(vr, 3), 0.15 * (ctx["bias"] > 0)))
    if ctx["shorts"] and pc > pv and c < v and d["ema9"].iloc[-1] < d["ema9"].iloc[-3] and 28 <= r <= 50 and vr >= 1.1:
        stop = max(d["high"].iloc[-5:].max(), c + 0.8 * a) + 0.1 * a
        return Signal(sym, "VWAP_RECLAIM", "sell", c, stop, a, _q(0.4, 0.08 * min(vr, 3), 0.15 * (ctx["bias"] < 0)))
    return None


def ema_trend_pullback(sym, d, ctx) -> Optional[Signal]:
    if len(d) < 25:
        return None
    last = d.iloc[-1]
    c, a, r = last["close"], last["atr"], last["rsi"]
    up = last["ema9"] > last["ema21"] > last["vwap"] and d["ema21"].iloc[-1] > d["ema21"].iloc[-10]
    dn = last["ema9"] < last["ema21"] < last["vwap"] and d["ema21"].iloc[-1] < d["ema21"].iloc[-10]
    prev = d.iloc[-2]
    fresh_hi = d["high"].iloc[-15:-2].max() >= d["high"].iloc[-40:].max() * 0.998
    fresh_lo = d["low"].iloc[-15:-2].min() <= d["low"].iloc[-40:].min() * 1.002
    if up and fresh_hi and prev["low"] <= prev["ema9"] * 1.001 and c > prev["high"] and c > last["open"] and 45 <= r <= 68:
        stop = min(d["low"].iloc[-6:].min(), c - a) - 0.1 * a
        return Signal(sym, "EMA_PULLBACK", "buy", c, stop, a, _q(0.5, 0.2 * (ctx["bias"] > 0)))
    if ctx["shorts"] and dn and fresh_lo and prev["high"] >= prev["ema9"] * 0.999 and c < prev["low"] and c < last["open"] and 32 <= r <= 55:
        stop = max(d["high"].iloc[-6:].max(), c + a) + 0.1 * a
        return Signal(sym, "EMA_PULLBACK", "sell", c, stop, a, _q(0.5, 0.2 * (ctx["bias"] < 0)))
    return None


def gap_and_go(sym, d, ctx) -> Optional[Signal]:
    gap = ctx.get("gap", {}).get(sym, 0.0)
    if abs(gap) < 2.0 or len(d) < 6 or d.index[-1].time() > time(10, 45):
        return None
    c, a, v = d["close"].iloc[-1], d["atr"].iloc[-1], d["vwap"].iloc[-1]
    hod, lod = d["high"].iloc[:-1].max(), d["low"].iloc[:-1].min()
    vr = _vol_ratio(d)
    if gap > 0 and c > hod and c > v and vr >= 1.5:
        stop = max(v, c - 1.5 * a)
        return Signal(sym, "GAP_GO", "buy", c, stop, a, _q(0.45, 0.03 * min(gap, 10), 0.05 * min(vr, 3)))
    if ctx["shorts"] and gap < 0 and c < lod and c < v and vr >= 1.5:
        stop = min(v, c + 1.5 * a)
        return Signal(sym, "GAP_GO", "sell", c, stop, a, _q(0.45, 0.03 * min(-gap, 10), 0.05 * min(vr, 3)))
    return None


def plan_trend(sym, d, ctx) -> Optional[Signal]:
    """The morning plan: a name the overnight / pre-market scan flagged as a big mover (GO or WAIT, not a failing FADE)
    that breaks its early high (or low) in the direction of the move. Catches the 9:30-10:30 trend early instead of
    waiting for the ribbon to warm up."""
    pl = (ctx.get("plan") or {}).get(sym)
    if not pl or pl.get("plan") == "FADE" or len(d) < 3 or not (time(9, 31) <= d.index[-1].time() <= time(10, 45)):
        return None
    long_ = pl.get("side") == "long"
    if not long_ and not ctx.get("shorts"):
        return None
    c, a, v = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1]), float(d["vwap"].iloc[-1])
    if a <= 0:
        return None
    prior = d.iloc[:-1]
    hod, lod = float(prior["high"].max()), float(prior["low"].min())
    recent = d["close"].iloc[-4:-1]
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    st = rb.get("state", 0) if rb.get("ready") else 0
    vr = _vol_ratio(d)
    if long_ and c > hod and c > v and st >= 0 and vr >= 0.8 and (c - v) <= 3.5 * a and float(recent.min()) >= hod - 1.5 * a:
        stop = max(v - 0.2 * a, c - 2.2 * a)
        if stop < c:
            return Signal(sym, "PLAN_TREND", "buy", c, stop, a, _q(0.5, 0.03 * min(abs(pl.get("move", 0)), 8), 0.05 * min(vr, 3)))
    if (not long_) and c < lod and c < v and st <= 0 and vr >= 0.8 and (v - c) <= 3.5 * a and float(recent.max()) <= lod + 1.5 * a:
        stop = min(v + 0.2 * a, c + 2.2 * a)
        if stop > c:
            return Signal(sym, "PLAN_TREND", "sell", c, stop, a, _q(0.5, 0.03 * min(abs(pl.get("move", 0)), 8), 0.05 * min(vr, 3)))
    return None


def dir_call(sym, d, ctx) -> Optional[Signal]:
    """Trade the early direction call automatically: a mover whose LONG/SHORT call is strong (score 45+, most signals
    agreeing) and not stretched from VWAP, 9:33-11:00."""
    cl = (ctx.get("calls") or {}).get(sym)
    if not cl or cl.get("call") not in ("LONG", "SHORT") or len(d) < 3 or not (time(9, 33) <= d.index[-1].time() <= time(11, 0)):
        return None
    if abs(cl.get("score", 0)) < 45 or cl.get("agree", 0) < 55 or cl.get("stretched"):
        return None
    long_ = cl["call"] == "LONG"
    if not long_ and not ctx.get("shorts"):
        return None
    c, a, v = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1]), float(d["vwap"].iloc[-1])
    if a <= 0 or (long_ and c < v) or ((not long_) and c > v):
        return None
    if long_:
        stop = max(v - 0.2 * a, c - 2.2 * a)
        ok = stop < c
    else:
        stop = min(v + 0.2 * a, c + 2.2 * a)
        ok = stop > c
    if not ok:
        return None
    return Signal(sym, "DIR_CALL", "buy" if long_ else "sell", c, stop, a, _q(0.45, 0.002 * abs(cl["score"]), 0.001 * cl.get("agree", 0)))


def morning_reversal(sym, d, ctx) -> Optional[Signal]:
    """Morning reversal short (off by default). Looks for a SECOND rejection of the opening high (the first 5 minutes'
    high), then waits for a completed 1-minute close below the low of the bars since that second rejection before it
    shorts. A quick 9:35 poke and fake-out does not count: the opening window itself is ignored, price must have pulled
    back from the high first, come back to it within a small tolerance, and failed to close above it."""
    if not ctx.get("morning_reversal") or not ctx.get("shorts"):
        return None
    n = len(d)
    if n < 12 or not (time(9, 40) <= d.index[-1].time() <= time(11, 30)):
        return None
    OR = 5
    a = float(d["atr"].iloc[-1])
    if a <= 0:
        return None
    hi, lo, cl = d["high"].values, d["low"].values, d["close"].values
    oh = float(hi[:OR].max())
    k = int(hi[:OR].argmax())
    tol = max(0.15 * a, 0.0007 * oh)
    dip = max(0.8 * a, 0.003 * oh)
    touches, i = [], OR
    while i < n:
        if hi[i] >= oh - tol:
            j = i
            while j + 1 < n and hi[j + 1] >= oh - tol:
                j += 1
            touches.append((i, j))
            i = j + 1
        else:
            i += 1
    if not touches:
        return None
    i2, j2 = touches[-1]
    if n - 1 <= i2 or n - 1 - j2 > 10:
        return None
    if lo[k:i2].min() > oh - dip:                     # price never really left the high before coming back
        return None
    if cl[i2:j2 + 1].max() > oh + 0.1 * a or cl[i2:].max() > oh + 0.3 * a:    # it broke out instead of failing
        return None
    level = float(lo[i2:n - 1].min())
    if not cl[-1] < level:
        return None
    for m in range(i2 + 1, n - 1):                    # only the FIRST completed breakdown counts
        if cl[m] < float(lo[i2:m].min()):
            return None
    c, e9 = float(cl[-1]), float(d["ema9"].iloc[-1])
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    if c >= e9 or (rb.get("ready") and rb.get("state", 0) > 0):
        return None
    stop = oh + 0.15 * a
    risk = stop - c
    if risk < 0.5 * a or risk > 6 * a:
        return None
    return Signal(sym, "MORNING_REVERSAL", "sell", c, stop, a, _q(0.5, 0.05 * min(len(touches), 3)),
                  {"opening_high": oh, "second_rejection_bar": d.index[i2].strftime("%H:%M")})


def preclose_candidates(bars: dict, ctx: dict) -> list:
    """Overnight-short candidates for 3:10-3:35 PM. Type FAILED_SPIKE: up 3%+ on the day, faded 40%+ of the day's range
    from the high, under VWAP with a red ribbon. Type WEAK_CLOSE: down 3%+, closing in the bottom 12% of the range, under
    VWAP with a red ribbon. Returns dicts with entry, stop, target, atr, score, why (best first)."""
    out = []
    for sym, df in bars.items():
        if sym in ctx.get("index_symbols", ()):
            continue
        d = _session(df)
        if len(d) < 120:
            continue
        try:
            c, v, a = float(d["close"].iloc[-1]), float(d["vwap"].iloc[-1]), float(d["atr"].iloc[-1])
            op = float(d["open"].iloc[0])
            hod, lod = float(d["high"].max()), float(d["low"].min())
            if a <= 0 or hod <= lod or c >= v:
                continue
            rb = (ctx.get("ribbon") or {}).get(sym) or {}
            if not (rb.get("ready") and rb.get("state", 0) < 0):
                continue
            day = ctx.get("gap", {}).get(sym, 0.0) + 100 * (c - op) / op
            rng = hod - lod
            frac_from_low = (c - lod) / rng
            kind = None
            if day >= 3.0 and (hod - c) >= 0.4 * rng:
                kind = "FAILED_SPIKE"
                stop = min(hod + 0.2 * a, c + 5 * a)
                stop = max(stop, c + 1.5 * a)
            elif day <= -3.0 and frac_from_low <= 0.12:
                kind = "WEAK_CLOSE"
                stop = c + 3 * a
            if not kind:
                continue
            target = c - 4.5 * a
            if (c - target) / (stop - c) < 1.2:
                continue
            out.append({"symbol": sym, "kind": kind, "entry": c, "stop": stop, "target": target, "atr": a,
                        "score": abs(day) + 5 * (1 - frac_from_low) if kind == "WEAK_CLOSE" else abs(day) + 8 * (hod - c) / rng,
                        "why": f"{day:+.1f}% on the day, {'faded ' + str(int(100 * (hod - c) / rng)) + '% off the high' if kind == 'FAILED_SPIKE' else 'closing near the low'}, under VWAP, ribbon red",
                        "day": round(day, 1)})
        except Exception:
            continue
    out.sort(key=lambda r: r["score"], reverse=True)
    return out


def reentry(sym, d, ctx) -> Optional[Signal]:
    """Get back in after a profitable exit, on the same side, two ways:
       pullback     - price pulled back at least 0.25 A from its best since the exit and the latest completed bar turned back;
       continuation - price never pulled back: it kept running and the latest completed bar closed at a NEW extreme beyond the
                      best since the exit (at least 0.3 A past the exit price). No pullback needed: jump back in.
    Needs the ribbon and VWAP to agree with the trade's side. A = 2.5 x the 1-minute ATR."""
    st = (ctx.get("reentry") or {}).get(sym)
    if not st or len(d) < 4:
        return None
    dirn = int(st["dir"])
    post = d[d.index > st["t"]]
    if len(post) < 3:
        return None
    c, pc = float(post["close"].iloc[-1]), float(post["close"].iloc[-2])
    a1 = float(d["atr"].iloc[-1])
    if a1 <= 0:
        return None
    A = max(2.5 * a1, 0.0015 * c)
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    if rb.get("ready") and rb.get("state", 0) * dirn <= 0:
        return None
    v = float(d["vwap"].iloc[-1])
    if (c - v) * dirn <= 0:
        return None
    prior = post.iloc[:-1]
    pb_min = max(0.25 * A, 0.0018 * c)                       # a real pullback, not candle-wick noise (measured on closes)
    if dirn > 0:
        best = float(prior["high"].max())
        bi = int(prior["close"].values.argmax())
        retr = float(prior["close"].iloc[bi]) - float(prior["close"].iloc[bi:].min())
        new_extreme = c > best
    else:
        best = float(prior["low"].min())
        bi = int(prior["close"].values.argmin())
        retr = float(prior["close"].iloc[bi:].max()) - float(prior["close"].iloc[bi])
        new_extreme = c < best
    run = (c - st["exit"]) * dirn
    kind = None
    if retr >= pb_min and (c - pc) * dirn > 0 and run > -0.5 * A:
        kind = "pullback"
    elif retr < pb_min and new_extreme and run >= max(0.3 * A, 0.001 * c) and run <= 4 * A:
        kind = "continuation"
    if not kind:
        return None
    risk = max(2.2 * a1, 0.0015 * c)
    stop = c - dirn * risk
    return Signal(sym, "REENTRY", "buy" if dirn > 0 else "sell", c, stop, a1, _q(0.55, 0.04 * min(int(st.get("n", 0)), 2)), {"kind": kind})


def open_short(sym, d, ctx) -> Optional[Signal]:
    """Short the open: names the pre-market timeline flagged (gapped up, then faded off the pre-market high and lost VWAP)
    that break below their trigger in the first 20 minutes of the session, 9:31-9:50."""
    pl = (ctx.get("open_shorts") or {}).get(sym)
    if not pl or not ctx.get("shorts") or len(d) < 2 or not (time(9, 31) <= d.index[-1].time() <= time(9, 50)):
        return None
    c, a, v = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1]), float(d["vwap"].iloc[-1])
    if a <= 0 or c >= v:
        return None
    trig = float(pl.get("trigger") or 0)
    if trig <= 0 or c >= trig or float(d["close"].iloc[:-1].min()) < trig:      # the FIRST close below the pre-market low
        return None
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    if rb.get("ready") and rb.get("state", 0) > 0:
        return None
    stop = max(float(d["high"].iloc[:-1].max()), v) + 0.1 * a
    stop = min(stop, c + 3.5 * a)
    if stop - c < 0.5 * a:
        stop = c + 0.5 * a
    return Signal(sym, "OPEN_SHORT", "sell", c, stop, a, _q(0.5, 0.03 * min(abs(pl.get("move", 0)), 8)))


def gap_fade(sym, d, ctx) -> Optional[Signal]:
    """A gap that FAILS, 9:40-10:45. Gap-up that loses the opening-range low and VWAP -> short (SPCX, Sep 28:
    opened +1.3%, faded all day). Gap-down that reclaims the opening-range high and VWAP -> long bounce."""
    gap = ctx.get("gap", {}).get(sym, 0.0)
    if abs(gap) < 1.0 or len(d) < 8 or not (time(9, 40) <= d.index[-1].time() <= time(10, 45)):
        return None
    first = d.iloc[:5]
    orh, orl = float(first["high"].max()), float(first["low"].min())
    op = float(d["open"].iloc[0])
    c, pc, a, v = float(d["close"].iloc[-1]), float(d["close"].iloc[-2]), float(d["atr"].iloc[-1]), float(d["vwap"].iloc[-1])
    hod, lod = float(d["high"].max()), float(d["low"].min())
    vr = _vol_ratio(d)
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    st = rb.get("state", 0) if rb.get("ready") else 0
    recent = d["close"].iloc[-4:-1]                     # a FRESH break: one of the last 3 closes was still inside the range
    if gap > 0 and ctx.get("shorts") and c < orl and float(recent.max()) >= orl * 0.9995 and c < v and c < op and st <= 0 and vr >= 0.7:
        stop = min(hod + 0.1 * a, c + 2.5 * a)
        if stop > c:
            return Signal(sym, "GAP_FADE", "sell", c, stop, a, _q(0.45, 0.03 * min(gap, 8), 0.05 * min(vr, 3)))
    if gap < 0 and c > orh and float(recent.min()) <= orh * 1.0005 and c > v and c > op and st >= 0 and vr >= 0.7:
        stop = max(lod - 0.1 * a, c - 2.5 * a)
        if stop < c:
            return Signal(sym, "GAP_FADE", "buy", c, stop, a, _q(0.45, 0.03 * min(-gap, 8), 0.05 * min(vr, 3)))
    return None


def mean_reversion(sym, d, ctx) -> Optional[Signal]:
    if len(d) < 30:
        return None
    last, prev = d.iloc[-1], d.iloc[-2]
    c, a = last["close"], last["atr"]
    stretched = (last["vwap"] - c) > 2.2 * a
    if stretched and prev["rsi"] < 25 and c > last["open"] and c > prev["high"]:
        stop = min(last["low"], prev["low"]) - 0.2 * a
        return Signal(sym, "MEAN_REVERT", "buy", c, stop, a, _q(0.35, 0.1 * (ctx["bias"] >= 0)),
                      extra={"vwap": float(last["vwap"])})
    # short mirror: stretched far ABOVE VWAP, overbought, first red bar closing under the prior low
    if ctx.get("shorts") and (c - last["vwap"]) > 2.2 * a and prev["rsi"] > 75 and c < last["open"] and c < prev["low"]:
        stop = max(last["high"], prev["high"]) + 0.2 * a
        return Signal(sym, "MEAN_REVERT", "sell", c, stop, a, _q(0.35, 0.1 * (ctx["bias"] <= 0)),
                      extra={"vwap": float(last["vwap"])})
    return None


def ribbon_flip(sym, d, ctx) -> Optional[Signal]:
    """BUY when the EMA ribbon flips green and price closes above the white (slow) line;
    SELL (short) on a red flip below it. Only acts within 2 bars of the flip."""
    rb = ctx["ribbon"].get(sym)
    allf = bool(ctx.get("all_flips"))
    if not rb or not rb["ready"] or rb["flip_ago"] is None or rb["flip_ago"] > (2 if allf else 1):
        return None
    c, a = d["close"].iloc[-1], d["atr"].iloc[-1]
    vr = _vol_ratio(d)
    vw = d["vwap"].iloc[-1]
    if rb["state"] > 0 and c > rb["slow"] and (allf or c > vw):
        stop = min(rb["slow"] - 0.5 * rb["atr"], rb["swing_low"])
        stop = max(stop, c - 3 * a)
        return Signal(sym, "RIBBON_FLIP", "buy", c, stop, a, _q(0.5, 0.05 * min(vr, 3), 0.15 * (ctx["bias"] > 0)))
    if ctx["shorts"] and rb["state"] < 0 and c < rb["slow"] and (allf or c < vw):
        stop = max(rb["slow"] + 0.5 * rb["atr"], rb["swing_high"])
        stop = min(stop, c + 3 * a)
        return Signal(sym, "RIBBON_FLIP", "sell", c, stop, a, _q(0.5, 0.05 * min(vr, 3), 0.15 * (ctx["bias"] < 0)))
    return None


def ribbon_why(sym, d, ctx) -> Optional[str]:
    """Plain-English reason why a recent ribbon BUY/SELL flip did NOT become a RIBBON_FLIP signal."""
    rb = ctx["ribbon"].get(sym)
    if not rb or not rb.get("ready") or rb.get("flip_ago") is None or rb["flip_ago"] > 6:
        return None
    n, st = rb["flip_ago"], rb["state"]
    lab = "BUY" if st > 0 else "SELL"
    allf = bool(ctx.get("all_flips"))
    if n > (2 if allf else 1):
        return f"{lab} flip was {n} bars ago — too old (bot only enters within {2 if allf else 1} bar of the flip)"
    c, vw = float(d["close"].iloc[-1]), float(d["vwap"].iloc[-1])
    if st < 0 and not ctx.get("shorts"):
        return "SELL flip — shorting is off or not available for this account"
    if st > 0 and c <= rb["slow"]:
        return "BUY flip but price is not above the slow (white) line"
    if st < 0 and c >= rb["slow"]:
        return "SELL flip but price is not below the slow (white) line"
    if not allf and st > 0 and c <= vw:
        return f"BUY flip but price {c:.2f} is below VWAP {vw:.2f}"
    if not allf and st < 0 and c >= vw:
        return f"SELL flip but price {c:.2f} is above VWAP {vw:.2f}"
    return None


def micro_scalp(sym, d, ctx) -> Optional[Signal]:
    """⚡🔥 Aggressive scalp: a 1-minute momentum burst. Close breaks the last 3 bars' high on 2x volume,
    above VWAP, fast EMA over slow, RSI 55-80. Tight stop under the last 2 bars. Only in aggressive mode."""
    if not ctx.get("aggressive") or len(d) < 12:
        return None
    last = d.iloc[-1]
    c, a = float(last["close"]), float(last["atr"])
    vr = _vol_ratio(d) if not ctx.get("quote_bars") else 2.0
    hi3, lo3 = float(d["high"].iloc[-4:-1].max()), float(d["low"].iloc[-4:-1].min())
    r = float(last["rsi"])
    if c > hi3 and c > last["vwap"] and last["ema9"] > last["ema21"] and 55 <= r <= 80 and vr >= 2.0 and c > last["open"]:
        stop = max(float(d["low"].iloc[-2:].min()) - 0.05 * a, c - 1.0 * a)
        if stop < c:
            return Signal(sym, "MICRO_SCALP", "buy", c, stop, a, _q(0.5, 0.05 * min(vr, 4)))
    if ctx.get("shorts") and c < lo3 and c < last["vwap"] and last["ema9"] < last["ema21"] and 20 <= r <= 45 \
            and vr >= 2.0 and c < last["open"]:
        stop = min(float(d["high"].iloc[-2:].max()) + 0.05 * a, c + 1.0 * a)
        if stop > c:
            return Signal(sym, "MICRO_SCALP", "sell", c, stop, a, _q(0.5, 0.05 * min(vr, 4)))
    return None


def flush_short(sym, d, ctx) -> Optional[Signal]:
    """🔻 Flush short: a quiet range breaks down hard (TSLA-style). Close under the last 20 bars' low
    by >0.3 ATR on 2x+ volume, below VWAP. Shorts must be allowed."""
    if not ctx.get("shorts") or len(d) < 25:
        return None
    last = d.iloc[-1]
    c, a = float(last["close"]), float(last["atr"])
    lo20, hi20 = float(d["low"].iloc[-21:-1].min()), float(d["high"].iloc[-21:-1].max())
    rng = hi20 - lo20
    vr = _vol_ratio(d)
    if rng <= 0 or rng > 4 * a:                  # needs a tight range before the break
        return None
    if c < lo20 - 0.3 * a and c < last["vwap"] and vr >= 2.0 and c < last["open"]:
        stop = min(float(last["high"]) + 0.1 * a, c + 1.5 * a)
        return Signal(sym, "FLUSH_SHORT", "sell", c, stop, a, _q(0.55, 0.05 * min(vr, 5)))
    return None


def flush_bounce(sym, d, ctx) -> Optional[Signal]:
    """🔺 Flush bounce: after a fast drop of 2+ ATR within ~7 bars on a volume spike, the first green bar
    that closes over the prior bar's high. Stop under the flush low."""
    if len(d) < 15:
        return None
    last, prev = d.iloc[-1], d.iloc[-2]
    c, a = float(last["close"]), float(last["atr"])
    win = d.iloc[-8:-1]
    drop = float(win["high"].max()) - float(win["low"].min())
    low = float(d["low"].iloc[-6:].min())
    va = float(d["vol_avg"].iloc[-9]) if d["vol_avg"].iloc[-9] == d["vol_avg"].iloc[-9] else 0
    spike = va > 0 and float(win["volume"].max()) >= 3 * va
    if drop >= 2.0 * a and spike and c > float(last["open"]) and c > float(prev["high"]) and (c - low) < 0.6 * drop:
        stop = low - 0.15 * a
        if stop < c:
            return Signal(sym, "FLUSH_BOUNCE", "buy", c, stop, a, _q(0.5, 0.05 * min(drop / a, 5)))
    return None


def flush_fade(sym, d, ctx) -> Optional[Signal]:
    """🔻 Flush fade (the short mirror of FLUSH_BOUNCE): after a fast spike UP of 2+ ATR within ~7 bars on a volume
    spike, the first red bar that closes under the prior bar's low. Stop over the spike high."""
    if not ctx.get("shorts") or len(d) < 15:
        return None
    last, prev = d.iloc[-1], d.iloc[-2]
    c, a = float(last["close"]), float(last["atr"])
    win = d.iloc[-8:-1]
    rise = float(win["high"].max()) - float(win["low"].min())
    high = float(d["high"].iloc[-6:].max())
    va = float(d["vol_avg"].iloc[-9]) if d["vol_avg"].iloc[-9] == d["vol_avg"].iloc[-9] else 0
    spike = va > 0 and float(win["volume"].max()) >= 3 * va
    if rise >= 2.0 * a and spike and c < float(last["open"]) and c < float(prev["low"]) and (high - c) < 0.6 * rise:
        stop = high + 0.15 * a
        if stop > c:
            return Signal(sym, "FLUSH_FADE", "sell", c, stop, a, _q(0.5, 0.05 * min(rise / a, 5)))
    return None


def opening_drive(sym, d, ctx) -> Optional[Signal]:
    """Your best manual trades: a gapper (news/catalyst) driving in the first minutes after the open.
    Long when a +2% or bigger gapper breaks its first-5-minute high above VWAP on a volume surge, 9:35-9:50."""
    gap = ctx.get("gap", {}).get(sym, 0.0)
    if len(d) < 6 or abs(gap) < 2.0:
        return None
    tm = d.index[-1].time()
    if not (time(9, 35) <= tm <= time(9, 50)):
        return None
    first = d.iloc[:5]
    hi, lo = float(first["high"].max()), float(first["low"].min())
    c, pc, a, v = float(d["close"].iloc[-1]), float(d["close"].iloc[-2]), float(d["atr"].iloc[-1]), float(d["vwap"].iloc[-1])
    vr = _vol_ratio(d)
    rb = (ctx.get("ribbon") or {}).get(sym) or {}
    if gap > 0 and pc <= hi < c and c > v and vr >= 1.5 and rb.get("state", 0) >= 0:
        stop = max(lo, v - 0.2 * a, c - 2.0 * a)
        if stop < c:
            return Signal(sym, "OPEN_DRIVE", "buy", c, stop, a, _q(0.55, 0.03 * min(gap, 8), 0.05 * min(vr, 3)))
    if ctx.get("shorts") and gap < 0 and pc >= lo > c and c < v and vr >= 1.5 and rb.get("state", 0) <= 0:
        stop = min(hi, v + 0.2 * a, c + 2.0 * a)
        if stop > c:
            return Signal(sym, "OPEN_DRIVE", "sell", c, stop, a, _q(0.55, 0.03 * min(-gap, 8), 0.05 * min(vr, 3)))
    return None


STRATEGIES = {
    "FLUSH_SHORT": flush_short,
    "FLUSH_BOUNCE": flush_bounce,
    "FLUSH_FADE": flush_fade,
    "MICRO_SCALP": micro_scalp,
    "OPEN_DRIVE": opening_drive,
    "RIBBON_FLIP": ribbon_flip,
    "ORB": opening_range_breakout,
    "VWAP_RECLAIM": vwap_reclaim,
    "EMA_PULLBACK": ema_trend_pullback,
    "GAP_GO": gap_and_go,
    "GAP_FADE": gap_fade,
    "PLAN_TREND": plan_trend,
    "DIR_CALL": dir_call,
    "MORNING_REVERSAL": morning_reversal,
    "OPEN_SHORT": open_short,
    "REENTRY": reentry,
    "MEAN_REVERT": mean_reversion,
}


def find_signals(bars: dict, ctx: dict) -> list:
    """bars: {symbol: enriched DataFrame}. Returns every signal that fired on the latest bar."""
    out = []
    for sym, df in bars.items():
        if sym in ctx.get("index_symbols", ()):
            continue
        d = _session(df)
        if len(d) < 6 or d["atr"].iloc[-1] <= 0:
            continue
        for name, fn in STRATEGIES.items():
            try:
                s = fn(sym, d, ctx)
            except Exception:
                s = None
            if not s or s.risk_per_share <= 0.001 * s.entry:
                continue
            # ribbon trend filter: trade with the ribbon colour (mean reversion exempt)
            rb = ctx.get("ribbon", {}).get(sym)
            if rb and rb["ready"] and name not in ("MEAN_REVERT", "FLUSH_SHORT", "FLUSH_BOUNCE"):
                if (s.side == "buy" and rb["state"] < 0) or (s.side == "sell" and rb["state"] > 0):
                    continue
                if (s.side == "buy" and rb["state"] > 0) or (s.side == "sell" and rb["state"] < 0):
                    s.quality = min(1.0, s.quality + 0.1)
            out.append(s)
    return out


def market_bias(bars: dict, index_symbols=("SPY", "QQQ")) -> int:
    """+1 if the index is trending up (above VWAP & EMA21), -1 if down, 0 otherwise."""
    score = 0
    for sym in index_symbols:
        df = bars.get(sym)
        if df is None:
            continue
        d = _session(df)
        if len(d) < 10:
            continue
        l = d.iloc[-1]
        if l["close"] > l["vwap"] and l["close"] > l["ema21"]:
            score += 1
        elif l["close"] < l["vwap"] and l["close"] < l["ema21"]:
            score -= 1
    return (score > 0) - (score < 0)


# ======================= extended-hours (pre-market / after-hours / overnight) =======================
# Thin liquidity, no server-side brackets: long-only, fewer setups, stricter filters.

def _session_vwap(d: pd.DataFrame) -> float:
    v = d["volume"].clip(lower=1)
    tp = (d["high"] + d["low"] + d["close"]) / 3
    return float((tp * v).sum() / v.sum())


def ext_momentum(sym, d, ctx) -> Optional[Signal]:
    """News/earnings mover: up since the regular close, above session VWAP, breaking the session high."""
    move = ctx["move"].get(sym, 0.0)
    if abs(move) < 2.0 or len(d) < 8:
        return None
    c, a = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1])
    svwap = _session_vwap(d)
    prior_hi = float(d["high"].iloc[:-1].max())
    vr = _vol_ratio(d) if not ctx.get("quote_bars") else 1.5
    rb = ctx["ribbon"].get(sym) or {}
    if move <= -2.0:
        if not ctx.get("shorts"):
            return None
        prior_lo = float(d["low"].iloc[:-1].min())
        if c < prior_lo and c < svwap and vr >= 1.3 and rb.get("state", 0) <= 0:
            stop = min(svwap + 0.2 * a, c + 2.5 * a)
            if stop <= c:
                return None
            return Signal(sym, "EXT_MOMENTUM", "sell", c, stop, a, _q(0.45, 0.03 * min(-move, 10), 0.1 * (rb.get("state") == -1)))
        return None
    if c > prior_hi and c > svwap and vr >= 1.3 and rb.get("state", 0) >= 0:
        stop = max(svwap - 0.2 * a, c - 2.5 * a)
        if stop >= c:
            return None
        return Signal(sym, "EXT_MOMENTUM", "buy", c, stop, a, _q(0.45, 0.03 * min(move, 10), 0.1 * (rb.get("state") == 1)))
    return None


def ext_trend(sym, d, ctx) -> Optional[Signal]:
    """Pre-market / after-hours continuation in the direction of the mover (|move| >= 1.2% vs the regular close):
    ribbon agrees, price is on the right side of VWAP and the slow line, and it breaks the last 6 bars' extreme."""
    move = ctx["move"].get(sym, 0.0)
    rb = ctx["ribbon"].get(sym) or {}
    if abs(move) < 1.2 or len(d) < 10 or ctx.get("quote_bars") or not rb.get("ready"):
        return None
    c, a = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1])
    sv = _session_vwap(d)
    vr = _vol_ratio(d)
    if move > 0 and rb["state"] > 0 and c > rb["slow"] and c > sv and c > float(d["high"].iloc[-7:-1].max()) and vr >= 1.2:
        stop = max(min(rb["slow"] - 0.5 * rb["atr"], rb["swing_low"]), c - 2.5 * a)
        if stop < c:
            return Signal(sym, "EXT_TREND", "buy", c, stop, a, _q(0.45, 0.03 * min(move, 8), 0.05 * min(vr, 3)))
    if move < 0 and ctx.get("shorts") and rb["state"] < 0 and c < rb["slow"] and c < sv \
            and c < float(d["low"].iloc[-7:-1].min()) and vr >= 1.2:
        stop = min(max(rb["slow"] + 0.5 * rb["atr"], rb["swing_high"]), c + 2.5 * a)
        if stop > c:
            return Signal(sym, "EXT_TREND", "sell", c, stop, a, _q(0.45, 0.03 * min(-move, 8), 0.05 * min(vr, 3)))
    return None


def ext_ribbon_flip(sym, d, ctx) -> Optional[Signal]:
    rb = ctx["ribbon"].get(sym)
    allf = bool(ctx.get("all_flips"))
    if not rb or not rb["ready"] or rb["flip_ago"] is None or rb["flip_ago"] > (2 if allf else 1) or rb["state"] == 0:
        return None
    c, a = float(d["close"].iloc[-1]), float(d["atr"].iloc[-1])
    sv = _session_vwap(d)
    if rb["state"] > 0:
        if c <= rb["slow"] or (c <= sv and not allf):
            return None
        stop = max(min(rb["slow"] - 0.5 * rb["atr"], rb["swing_low"]), c - 3 * a)
        return Signal(sym, "RIBBON_FLIP", "buy", c, stop, a, _q(0.45, 0.05 * (ctx["move"].get(sym, 0) > 0)))
    if not ctx.get("shorts") or c >= rb["slow"] or (c >= sv and not allf):
        return None
    stop = min(max(rb["slow"] + 0.5 * rb["atr"], rb["swing_high"]), c + 3 * a)
    return Signal(sym, "RIBBON_FLIP", "sell", c, stop, a, _q(0.45, 0.05 * (ctx["move"].get(sym, 0) < 0)))


def ext_micro_scalp(sym, d, ctx):
    return micro_scalp(sym, d, ctx)                       # both sides (shorts follow the 7 AM switch)


EXT_STRATEGIES = {"EXT_MOMENTUM": ext_momentum, "EXT_TREND": ext_trend, "RIBBON_FLIP": ext_ribbon_flip, "MICRO_SCALP": ext_micro_scalp,
                  "FLUSH_BOUNCE": flush_bounce, "FLUSH_FADE": flush_fade, "REENTRY": reentry}


def find_ext_signals(bars: dict, ctx: dict, session_start) -> list:
    out = []
    for sym, df in bars.items():
        d = df[df.index >= session_start]
        if len(d) < 8 or d["atr"].iloc[-1] <= 0:
            continue
        for name, fn in EXT_STRATEGIES.items():
            try:
                s = fn(sym, d, ctx)
            except Exception:
                s = None
            if s and s.risk_per_share > 0.002 * s.entry:
                out.append(s)
    return out
