"""Self-learning layer.

Each (strategy, exit profile) pair is an "arm". After every closed trade the bot records the
result in R-multiples (profit / initial risk). Thompson sampling then:
  * picks which exit profile to use for a new signal,
  * ranks competing signals so the historically best setups get taken first,
  * scales position size up for arms with a proven edge and down for weak ones,
  * benches arms that keep losing (they still get rare exploration trades).
Stats decay a little every day so the bot adapts when market behaviour changes.
Results are also tracked per time-of-day bucket, so it learns e.g. that ORB works at 9:50
but not after lunch.
"""
import json
import math
import random
import threading
from datetime import datetime

from .config import DATA_DIR

LEARN_FILE = DATA_DIR / "learner.json"

EXIT_PROFILES = {
    # target in R, breakeven trigger in R, trailing stop (ATR multiples) after trail_after R
    "QUICK":    {"target_r": 1.2, "be_at_r": None, "trail_after_r": None, "trail_atr": None},
    "STANDARD": {"target_r": 2.0, "be_at_r": 1.0, "trail_after_r": None, "trail_atr": None},
    "RUNNER":   {"target_r": 3.5, "be_at_r": 1.0, "trail_after_r": 2.0, "trail_atr": 1.5},
    # ride the trend until the EMA ribbon flips against the trade (far target is only a backstop)
    "RIBBON":   {"target_r": 6.0, "be_at_r": 1.5, "trail_after_r": None, "trail_atr": None, "exit_on_flip": True},
    # take profit along the way: sell 1/3 at +1R (stop to break-even), 1/3 at +2R, trail the rest
    # let the runner breathe: 1/4 off at +1R (stop only to -0.5R), 1/3 of the rest at +2R (stop to break-even), then a wide trail
    "SCALE":    {"target_r": 8.0, "be_at_r": 2.0, "trail_after_r": 2.0, "trail_atr": 1.8, "exit_on_flip": True,
                 "scale": [(1.0, 0.25), (2.0, 1 / 3)]},
    # scalp: bank half at +0.6R (stop to break-even), the rest at +1.2R; out within 20 minutes
    "SCALP":    {"target_r": 1.2, "be_at_r": 0.6, "trail_after_r": None, "trail_atr": None,
                 "scale": [(0.6, 0.5)], "time_stop": 20},
    # aggressive scalp: bank half at +0.5R (stop to break-even), the rest at +1R; out within 8 minutes
    "AGGRO":    {"target_r": 1.0, "be_at_r": 0.5, "trail_after_r": None, "trail_atr": None,
                 "scale": [(0.5, 0.5)], "time_stop": 8},
}

PRIOR_N, PRIOR_MEAN, PRIOR_VAR = 4.0, 0.05, 1.0
DAILY_DECAY = 0.985
BENCH_MIN_N, BENCH_MEAN = 12, -0.25
EXPLORE_BENCHED = 0.05


def time_bucket(ts: datetime) -> str:
    t = ts.hour * 60 + ts.minute
    if t < 10 * 60 + 30:
        return "OPEN"
    if t < 14 * 60:
        return "MIDDAY"
    return "POWER"


class _Stat:
    __slots__ = ("n", "s", "ss", "wins")

    def __init__(self, n=0.0, s=0.0, ss=0.0, wins=0.0):
        self.n, self.s, self.ss, self.wins = n, s, ss, wins

    def add(self, r, w=1.0):
        self.n += w
        self.s += w * r
        self.ss += w * r * r
        self.wins += w if r > 0 else 0

    def decay(self, f):
        self.n *= f
        self.s *= f
        self.ss *= f
        self.wins *= f

    def posterior(self):
        n = self.n + PRIOR_N
        mean = (self.s + PRIOR_N * PRIOR_MEAN) / n
        ex2 = (self.ss + PRIOR_N * (PRIOR_VAR + PRIOR_MEAN ** 2)) / n
        var = max(ex2 - mean ** 2, 0.05)
        return mean, math.sqrt(var / n)

    def sample(self):
        m, sd = self.posterior()
        return random.gauss(m, sd)

    def to(self):
        return [self.n, self.s, self.ss, self.wins]


class Learner:
    def __init__(self):
        self.lock = threading.Lock()
        self.arms: dict[str, _Stat] = {}
        self.ctx: dict[str, _Stat] = {}
        self.last_decay_day = ""
        self.load()

    # ---------- persistence ----------
    def load(self):
        if LEARN_FILE.exists():
            try:
                d = json.loads(LEARN_FILE.read_text())
                self.arms = {k: _Stat(*v) for k, v in d.get("arms", {}).items()}
                self.ctx = {k: _Stat(*v) for k, v in d.get("ctx", {}).items()}
                self.last_decay_day = d.get("last_decay_day", "")
            except Exception:
                pass

    def save(self):
        LEARN_FILE.write_text(json.dumps({
            "arms": {k: v.to() for k, v in self.arms.items()},
            "ctx": {k: v.to() for k, v in self.ctx.items()},
            "last_decay_day": self.last_decay_day,
        }, indent=1))

    def reset(self):
        with self.lock:
            self.arms, self.ctx = {}, {}
            self.save()

    # ---------- learning ----------
    def daily_decay(self, day: str):
        with self.lock:
            if self.last_decay_day and self.last_decay_day != day:
                for st in list(self.arms.values()) + list(self.ctx.values()):
                    st.decay(DAILY_DECAY)
            self.last_decay_day = day
            self.save()

    def record(self, strategy: str, exit_profile: str, bucket: str, r_multiple: float, weight: float = 1.0, save: bool = True):
        r = float(max(-3.0, min(6.0, float(r_multiple))))  # clip outliers (gaps, bad fills)
        with self.lock:
            self.arms.setdefault(f"{strategy}|{exit_profile}", _Stat()).add(r, weight)
            self.ctx.setdefault(f"{strategy}|{exit_profile}|{bucket}", _Stat()).add(r, weight)
            if save:
                self.save()

    # ---------- decisions ----------
    def _arm(self, k):
        return self.arms.get(k) or _Stat()

    def benched(self, strategy, exit_profile) -> bool:
        st = self._arm(f"{strategy}|{exit_profile}")
        return bool(st.n >= BENCH_MIN_N and st.posterior()[0] < BENCH_MEAN)

    def choose(self, strategy: str, bucket: str, quality: float):
        """Return (exit_profile, score, size_weight) or None to skip."""
        best = None
        for ep in EXIT_PROFILES:
            key = f"{strategy}|{ep}"
            if self.benched(strategy, ep) and random.random() > EXPLORE_BENCHED:
                continue
            smp = self._arm(key).sample()
            c = self.ctx.get(f"{key}|{bucket}")
            if c and c.n >= 5:
                smp = 0.5 * smp + 0.5 * c.sample()
            if best is None or smp > best[1]:
                best = (ep, smp)
        if best is None:
            return None
        ep, smp = best
        score = smp + 0.3 * quality
        if score < -0.05:
            return None
        mean, _ = self._arm(f"{strategy}|{ep}").posterior()
        weight = max(0.4, min(1.75, 1 + 2 * mean)) * (0.75 + 0.5 * quality)
        return ep, score, round(weight, 3)

    def leaderboard(self):
        rows = []
        with self.lock:
            for k, st in self.arms.items():
                strat, ep = k.split("|")
                m, sd = st.posterior()
                rows.append({
                    "strategy": strat, "exit": ep, "trades": round(st.n, 1),
                    "win_rate": round(100 * st.wins / st.n, 1) if st.n else 0,
                    "avg_r": round(st.s / st.n, 2) if st.n else 0,
                    "edge": round(m, 3), "confidence": round(sd, 3),
                    "benched": self.benched(strat, ep),
                })
        return sorted(rows, key=lambda r: r["edge"], reverse=True)
