"""SekexBot version. Bump this with every release and add an entry to CHANGELOG.md.

MAJOR.MINOR.PATCH:  MAJOR = breaking change (settings/data format), MINOR = new feature, PATCH = fix."""
__version__ = "2.22.1"
RELEASE_DATE = "2026-10-21"
