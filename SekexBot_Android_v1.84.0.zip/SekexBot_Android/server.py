"""Control server + dashboard.

    python server.py            -> real Alpaca (paper by default), dashboard at http://127.0.0.1:8010
    python server.py --sim      -> offline simulated market (no keys needed) to try the dashboard
"""
import argparse
import logging
import os
import sys
from datetime import datetime, timedelta
from logging.handlers import RotatingFileHandler
from pathlib import Path
from zoneinfo import ZoneInfo

ap = argparse.ArgumentParser()
ap.add_argument("--sim", action="store_true", help="use the offline market simulator")
ap.add_argument("--speed", type=float, default=30, help="sim speed (sim seconds per real second)")
ap.add_argument("--sim-start", default="09:20", help="sim start time HH:MM ET (e.g. 16:30 to try after-hours)")
ap.add_argument("--host", default=os.getenv("HOST", "127.0.0.1"))
ap.add_argument("--port", type=int, default=int(os.getenv("PORT", "8010")))
ARGS = ap.parse_args()
if ARGS.sim:
    os.environ["AUTOBOT_DATA"] = str(Path(__file__).parent / "data_sim")
elif not os.getenv("SEKEX_GUARDED"):   # (the sekex watchdog already ran the guard before starting us)
    try:        # 🤖 Fix with Claude: roll back a patch that stops the app from starting (standard library only)
        from autobot import selffix_guard as _sg
        _sg.run(Path(__file__).resolve().parent)
    except Exception as _ex:
        print("selffix guard:", _ex)

import uvicorn  # noqa: E402
import pandas as pd  # noqa: E402
from fastapi import FastAPI, Header, HTTPException, Request  # noqa: E402
import json  # noqa: E402
import threading  # noqa: E402
from fastapi.responses import FileResponse, HTMLResponse, JSONResponse, RedirectResponse, Response  # noqa: E402
from pydantic import BaseModel  # noqa: E402

from autobot import db  # noqa: E402
from autobot.config import DATA_DIR, Settings, api_keys, live_pin, mask, write_env  # noqa: E402
from autobot.engine import Engine, was_running  # noqa: E402
from autobot import android  # noqa: E402
from autobot.alerts import Alerts  # noqa: E402
from autobot.watcher import Watcher  # noqa: E402
import time as time_mod  # noqa: E402
from time import sleep as time_sleep  # noqa: E402
from autobot import telemetry  # noqa: E402
from autobot.harvester import Harvester  # noqa: E402
from autobot.indicators import ribbon  # noqa: E402
from autobot.analyst import analyze, vision_read  # noqa: E402
from autobot.learner import Learner  # noqa: E402
from autobot import auth  # noqa: E402
from autobot.version import RELEASE_DATE, __version__  # noqa: E402
from autobot.tunnel import Tunnel  # noqa: E402

NY = ZoneInfo("America/New_York")
WEB = Path(__file__).parent / "web"
BASE_DIR_ = Path(__file__).parent
ASSETS = Path(__file__).parent / "assets"
TOKEN = os.getenv("DASH_TOKEN", "")

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s",
                    handlers=[logging.StreamHandler(sys.stdout),
                              RotatingFileHandler(DATA_DIR / "autobot.log", maxBytes=2_000_000, backupCount=5)])

settings = Settings.load()
learner = Learner()
alerts = Alerts(ARGS.port)
feed = None                     # streaming prices (autobot.stream)
from autobot.events import Events
events = Events()               # earnings calendar + news
guardian = None                 # heartbeat + backups (autobot.guardian), not in the simulator
_interest = {}                  # sym -> last time a dashboard asked for it
engine: Engine | None = None
setup_error = ""
from autobot.options import OptionsBot
options_bot = OptionsBot(lambda: engine, settings)     # separate module; does nothing until you turn it on


def _sip_ok(k, s):
    try:
        from alpaca.data.enums import DataFeed
        from alpaca.data.historical import StockHistoricalDataClient
        from alpaca.data.requests import StockLatestQuoteRequest
        StockHistoricalDataClient(k, s).get_stock_latest_quote(StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
        return True
    except Exception:
        return False


def build_engine():
    global engine, setup_error
    setup_error = ""
    try:
        if ARGS.sim:
            from autobot.sim import SimBroker
            d = datetime.now(NY).date()
            while d.weekday() >= 5:
                d += timedelta(days=1)
            hh, mm = (int(x) for x in ARGS.sim_start.split(":"))
            broker = SimBroker(datetime(d.year, d.month, d.day, hh, mm, tzinfo=NY), speed=ARGS.speed)
            from autobot.stream import SimFeed
            _set_feed(SimFeed(broker))
        else:
            from autobot.broker import AlpacaBroker
            k, s = api_keys(settings.live)
            if settings.data_feed == "iex" and _sip_ok(k, s):       # you pay for SIP: use it (4 AM - 8 PM data)
                settings.data_feed = "sip"
                settings.save()
                logging.info("SIP data subscription detected: data feed switched to SIP")
            broker = AlpacaBroker(k, s, paper=not settings.live, feed=settings.data_feed)
            broker.account()  # validate keys now
            if settings.stream_prices:
                from autobot.stream import LiveFeed
                _set_feed(LiveFeed(k, s, settings.data_feed))
                broker.live = feed
            else:
                _set_feed(None)
        engine = Engine(settings, broker, learner)
        engine.alerts = alerts
        if not ARGS.sim:
            events.set_keys(k, s)
            engine.evfilter = events
        if ARGS.sim:
            engine.mode = "SIM"
    except Exception as e:
        engine = None
        setup_error = _friendly(e, settings.live)
        logging.error("Setup error: %s", e)


def _set_feed(f):
    global feed
    if feed is not None and feed is not f:
        feed.stop()
    feed = f


def _feed_loop():
    """Every 2 s: choose what to stream (positions first) and run the fast stop guard every 1 s."""
    import time as _t
    n = 0
    while True:
        _t.sleep(1)
        f, e = feed, engine
        if f is None or e is None:
            continue
        try:
            e.fast_guard(f)
        except Exception as ex:
            logging.debug("fast guard: %s", ex)
        n += 1
        if n % 2:
            continue
        now = _t.time()
        want = list(e.trades) + list((e.positions or {}).keys())
        want += [sym for sym, t0 in sorted(_interest.items(), key=lambda x: -x[1]) if now - t0 < 90]
        want += [w.upper() for w in settings.watchlist] + list(e.universe[:12]) + list(settings.watch_always)
        f.set_symbols(want)


def _friendly(e, live):
    acct = "LIVE" if live else "paper"
    m = str(e)
    low = m.lower()
    if "missing alpaca" in low:
        return f"No {acct} API keys yet — click 🔑 Broker keys to connect your Alpaca account."
    if "unauthorized" in low or "forbidden" in low or "401" in m or "403" in m:
        return f"Alpaca rejected the {acct} API keys — re-enter them in 🔑 Broker keys."
    if "connection" in low or "max retries" in low or "timed out" in low:
        return "Can't reach Alpaca — check your internet connection, then click Reconnect in 🔑 Broker keys."
    return m


build_engine()
import threading as _th  # noqa: E402
_th.Thread(target=_feed_loop, daemon=True, name="feed-loop").start()
watcher = Watcher(lambda: engine, alerts, settings)
if engine and not ARGS.sim and settings.auto_resume and was_running():
    logging.info("SekexBot was trading when it last shut down - resuming automatically")
    engine.start(resumed=True)
app = FastAPI(title="SekexBot", version=__version__)


PUBLIC = {"/login", "/api/login", "/api/version", "/manifest.webmanifest", "/icon.svg", "/icon-192.png", "/icon-512.png",
          "/apple-touch-icon.png", "/favicon.ico", "/sw.js"}
LOCAL_ONLY = ("/api/admin/", "/api/selffix/", "/api/support/", "/api/guardian/config", "/api/guardian/restore", "/api/help/fix", "/api/alerts/config", "/api/keys/save", "/api/anthropic_key", "/api/remote/", "/api/reconnect", "/api/app/")


@app.middleware("http")
async def guard(request: Request, call_next):
    path = request.url.path
    if not auth.is_remote(request):
        # Anti-CSRF / DNS-rebinding: a web page open in the phone's browser must not be able to press buttons here.
        hostname = (request.headers.get("host") or "").rsplit(":", 1)[0].strip("[]").lower()
        if hostname not in ("127.0.0.1", "localhost", "::1", ""):
            return JSONResponse({"detail": "blocked: unexpected Host header"}, status_code=403)
        if request.method not in ("GET", "HEAD", "OPTIONS"):
            origin = request.headers.get("origin")
            site = request.headers.get("sec-fetch-site")
            if origin and origin != "null":
                from urllib.parse import urlparse
                if (urlparse(origin).hostname or "").lower() not in ("127.0.0.1", "localhost", "::1"):
                    return JSONResponse({"detail": "blocked: cross-site request"}, status_code=403)
            elif origin == "null" or site in ("cross-site", "same-site"):
                return JSONResponse({"detail": "blocked: cross-site request"}, status_code=403)
    if TOKEN and path.startswith("/api") and path not in PUBLIC and not auth.is_remote(request):
        if request.headers.get("x-token") != TOKEN and request.query_params.get("token") != TOKEN:
            return JSONResponse({"detail": "unauthorized"}, status_code=401)
    if auth.is_remote(request) and path not in PUBLIC:
        if not auth.password_set():
            return HTMLResponse("<h3>Remote access is off: set a dashboard password on the device running SekexBot first.</h3>", 403)
        if not auth.valid_session(request.cookies.get(auth.COOKIE)):
            if path.startswith("/api"):
                return JSONResponse({"detail": "Please log in"}, status_code=401)
            return RedirectResponse("/login")
        if any(path.startswith(x) for x in LOCAL_ONLY):
            return JSONResponse({"detail": "For safety, keys and remote-access settings can only be changed "
                                           "on the device running SekexBot."}, status_code=403)
    resp = await call_next(request)
    resp.headers["X-Frame-Options"] = "DENY"
    resp.headers["Referrer-Policy"] = "no-referrer"
    return resp


def clean(o):
    """Make numpy scalars JSON-safe."""
    import numpy as np
    if isinstance(o, dict):
        return {k: clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [clean(v) for v in o]
    if isinstance(o, np.generic):
        return o.item()
    return o


def need_engine() -> Engine:
    if engine is None:
        raise HTTPException(400, setup_error or "Engine not ready")
    return engine


@app.get("/")
def index():
    return FileResponse(WEB / "dashboard.html", headers={"Cache-Control": "no-store"})


# ---------------- phone / remote access ----------------
tunnel = Tunnel(ARGS.port)


from autobot.signalaudit import Reviewer  # noqa: E402
reviewer = Reviewer()


class ReviewReq(BaseModel):
    question: str = ""
    symbol: str = ""


class TuneReq(BaseModel):
    tune: dict = {}


@app.post("/api/review/start")
def review_start(r: ReviewReq):
    e = need_engine()
    syms = [w.upper() for w in settings.watchlist]
    if r.symbol:
        syms.insert(0, _valid_sym(r.symbol))
    cut = (e.broker.now().date() - timedelta(days=5)).isoformat() if hasattr(e.broker, "now") else ""
    syms += [t["symbol"] for t in db.recent(300) if (t.get("day") or "") >= cut]
    syms = list(dict.fromkeys(s for s in syms if s))
    if not syms:
        raise HTTPException(400, "Add a few stocks to your watchlist first, so there is something to review.")
    try:
        return {"ok": True, "job": reviewer.start(e, r.question, syms)}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.get("/api/review/status")
def review_status():
    from autobot.predict import DEFAULTS, get_tune
    return clean({"job": reviewer.status(), "tune": get_tune(), "defaults": DEFAULTS})


@app.post("/api/review/tune")
def review_tune(r: TuneReq):
    """Apply early-warning settings (only the BUY?/SELL? warnings and their alerts; never how the bot trades)."""
    from autobot.predict import DEFAULTS, save_tune
    t = save_tune(r.tune or DEFAULTS)
    _wl_pred["at"] = 0                      # refresh the watchlist warnings now
    if engine:
        engine.event(f"📊 Early-warning settings: {t}")
    return {"ok": True, "tune": t}


class BannerReq(BaseModel):
    text: str = ""
    color: str = ""
    size: str = "m"
    show: bool = True
    code: str = ""


class BannerLock(BaseModel):
    code: str = ""
    new_code: str = ""


def _banner_read():
    import json
    try:
        return json.loads((DATA_DIR / "banner.json").read_text())
    except Exception:
        return {"text": "", "color": "", "size": "m", "show": True}


def _banner_ok(b, code, request):
    import hashlib
    h = b.get("lock")
    if not h:
        return
    ip = "banner:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong passcodes. Wait 15 minutes.")
    if hashlib.sha256(("sekex-banner:" + (code or "")).encode()).hexdigest() != h:
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong passcode for the header message")


@app.post("/api/banner/lock")
def banner_lock(r: BannerLock, request: Request):
    import hashlib
    import json
    b = _banner_read()
    _banner_ok(b, r.code, request)
    if r.new_code and len(r.new_code) < 4:
        raise HTTPException(400, "Use at least 4 characters")
    if r.new_code:
        b["lock"] = hashlib.sha256(("sekex-banner:" + r.new_code).encode()).hexdigest()
    else:
        b.pop("lock", None)
    (DATA_DIR / "banner.json").write_text(json.dumps(b))
    return {"ok": True, "locked": bool(r.new_code)}


@app.get("/api/banner")
def banner_get():
    b = _banner_read()
    return {k: v for k, v in b.items() if k != "lock"} | {"locked": bool(b.get("lock"))}


@app.post("/api/banner")
def banner_set(r: BannerReq, request: Request):
    """Your own message shown big in the header. Plain text only (shown with textContent, never as HTML)."""
    import json
    import re
    color = r.color.strip() if re.fullmatch(r"#[0-9a-fA-F]{3,8}", r.color.strip() or "") else ""
    old = _banner_read()
    _banner_ok(old, r.code, request)
    b = {"text": r.text.strip()[:120], "color": color, "size": r.size if r.size in ("s", "m", "l") else "m", "show": bool(r.show)}
    if old.get("lock"):
        b["lock"] = old["lock"]
    (DATA_DIR / "banner.json").write_text(json.dumps(b))
    return {k: v for k, v in b.items() if k != "lock"} | {"locked": bool(b.get("lock"))}


@app.get("/api/version")
def version():
    return {"version": __version__, "release_date": RELEASE_DATE}


@app.get("/login")
def login_page():
    return FileResponse(WEB / "login.html")


class LoginReq(BaseModel):
    password: str


@app.post("/api/login")
def login(r: LoginReq, request: Request):
    ip = auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many attempts. Wait 15 minutes.")
    if not auth.password_set() or not auth.check_password(r.password):
        auth.record_fail(ip)
        raise HTTPException(401, "Wrong password")
    logging.info("Remote login from %s", ip)
    resp = JSONResponse({"ok": True})
    resp.set_cookie(auth.COOKIE, auth.make_session(), max_age=auth.SESSION_DAYS * 86400, httponly=True,
                    secure=request.headers.get("x-forwarded-proto", request.url.scheme) == "https"
                    or bool(request.headers.get("cf-ray")), samesite="lax")
    return resp


@app.post("/api/logout")
def logout():
    resp = JSONResponse({"ok": True})
    resp.delete_cookie(auth.COOKIE)
    return resp


@app.get("/manifest.webmanifest")
def manifest():
    return JSONResponse({"name": "SekexBot", "short_name": "SekexBot", "id": "/", "start_url": "/", "scope": "/", "display": "standalone",
                         "description": "SekexBot auto-trader dashboard", "background_color": "#07090c", "theme_color": "#07090c",
                         "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any"},
                                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any"},
                                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "maskable"},
                                   {"src": "/icon.svg", "sizes": "any", "type": "image/svg+xml"}]},
                        media_type="application/manifest+json")


_SW = """self.addEventListener('install', e => self.skipWaiting());
self.addEventListener('activate', e => e.waitUntil(self.clients.claim()));
const OFFLINE = '<!doctype html><meta name=viewport content="width=device-width,initial-scale=1"><body style="background:#07090c;color:#e6edf3;font-family:system-ui;text-align:center;padding:40px 20px"><div style="font-size:48px">🔌</div><h2>SekexBot is off</h2><p style="color:#8b98a5">Start it with the <b>SekexBot</b> icon (Termux:Widget), or open Termux and type <b>sekex start</b>. Then tap Retry.</p><p><button style="font-size:18px;padding:12px 28px;border-radius:10px;border:0;background:#2563eb;color:#fff" onclick="location.reload()">Retry</button></p></body>';
self.addEventListener('fetch', e => {
  if (e.request.mode === 'navigate') e.respondWith(fetch(e.request).catch(() => new Response(OFFLINE, {headers: {'Content-Type': 'text/html; charset=utf-8'}})));
});
"""


@app.get("/sw.js")
def service_worker():
    return Response(_SW, media_type="application/javascript", headers={"Cache-Control": "no-cache", "Service-Worker-Allowed": "/"})


@app.get("/icon.svg")
def icon_svg():
    return FileResponse(ASSETS / "sekexbot-icon.svg", media_type="image/svg+xml")


@app.get("/icon-192.png")
def icon192():
    return FileResponse(ASSETS / "icon-192.png")


@app.get("/icon-512.png")
def icon512():
    return FileResponse(ASSETS / "icon-512.png")


@app.get("/apple-touch-icon.png")
def apple_icon():
    return FileResponse(ASSETS / "icon-180.png")


@app.get("/api/remote/status")
def remote_status():
    st = tunnel.status()
    st.update({"password_set": auth.password_set(), "token_saved": bool(os.getenv("CF_TUNNEL_TOKEN")),
               "hostname": os.getenv("CF_HOSTNAME", ""), "autostart": os.getenv("REMOTE_AUTOSTART", "") == "1"})
    return st


class PwReq(BaseModel):
    password: str


@app.post("/api/remote/password")
def remote_password(r: PwReq):
    if len(r.password) < 8:
        raise HTTPException(400, "Use at least 8 characters")
    auth.set_password(r.password)
    return {"ok": True}


class TunnelReq(BaseModel):
    mode: str = "quick"          # quick | token
    token: str = ""
    hostname: str = ""
    autostart: bool | None = None


@app.post("/api/remote/start")
def remote_start(r: TunnelReq):
    if not auth.password_set():
        raise HTTPException(400, "Set a dashboard password first — anyone with the link would otherwise control your bot.")
    vals = {}
    if r.mode == "token":
        tok = r.token.strip() or os.getenv("CF_TUNNEL_TOKEN", "")
        tok = tok.split("--token")[-1].strip().split()[-1] if tok else ""    # accept the whole install command too
        if len(tok) < 50:
            raise HTTPException(400, "Paste the tunnel token (or the whole 'cloudflared service install ...' command).")
        host = r.hostname.strip().replace("https://", "").strip("/") or os.getenv("CF_HOSTNAME", "")
        vals.update({"CF_TUNNEL_TOKEN": tok, "CF_HOSTNAME": host})
    if r.autostart is not None:
        vals["REMOTE_AUTOSTART"] = "1" if r.autostart else "0"
        vals["REMOTE_MODE"] = r.mode
    if vals:
        write_env(vals)
    tunnel.start(r.mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))
    return {"ok": True}


@app.post("/api/remote/stop")
def remote_stop():
    tunnel.stop()
    return {"ok": True}


@app.get("/api/qr")
def qr(url: str):
    import qrcode
    import qrcode.image.svg
    img = qrcode.make(url, image_factory=qrcode.image.svg.SvgPathImage, box_size=10, border=2)
    return Response(img.to_string(), media_type="image/svg+xml")


@app.on_event("startup")
def _autostart_tunnel():
    if os.getenv("REMOTE_AUTOSTART") == "1" and auth.password_set():
        mode = os.getenv("REMOTE_MODE", "token" if os.getenv("CF_TUNNEL_TOKEN") else "quick")
        tunnel.start(mode, os.getenv("CF_TUNNEL_TOKEN", ""), os.getenv("CF_HOSTNAME", ""))


@app.on_event("shutdown")
def _stop_tunnel():
    tunnel.stop()


@app.get("/api/status")
def status(request: Request):
    base = {"version": __version__, "release_date": RELEASE_DATE, "settings": {"daily_max_loss": settings.daily_max_loss, "live": settings.live,
                         "level": settings.level, "level_auto": settings.level_auto, "level_active": settings.level_active,
                         "allow_shorts": settings.allow_shorts, "short_from_7am": settings.short_from_7am, "shorts_24_5": settings.shorts_24_5, "trade_all_flips": settings.trade_all_flips, "auto_study": settings.auto_study, "max_trade_notional": settings.max_trade_notional, "auto_tune": settings.auto_tune, "session_tune": settings.session_tune, "let_run": settings.let_run, "proven_only": settings.proven_only, "auto_direction": settings.auto_direction, "auto_short": settings.auto_short, "auto_mode": settings.auto_mode, "reentry": settings.reentry, "pct_harvest": settings.pct_harvest, "pm_trend": settings.pm_trend, "harvest_stop": settings.harvest_stop, "etf_pair_guard": settings.etf_pair_guard, "regime_filter": settings.regime_filter, "fractional_on": settings.fractional_on, "green_guard": settings.green_guard, "morning_trend": settings.morning_trend, "options_on": settings.options_on, "options_style": settings.options_style, "options_max_premium": settings.options_max_premium, "options_max_positions": settings.options_max_positions, "options_tp_pct": settings.options_tp_pct, "options_stop_pct": settings.options_stop_pct, "options_underlyings": settings.options_underlyings, "strategy_breaker": settings.strategy_breaker, "max_spread_trend_pct": settings.max_spread_trend_pct, "max_position_pct_equity": settings.max_position_pct_equity, "share_diagnostics": settings.share_diagnostics, "share_trade_logs": settings.share_trade_logs, "diag_label": settings.diag_label, "diag_asked": settings.diag_asked, "collector_set": bool(telemetry.collector_url(settings)), "max_spread_pct": settings.max_spread_pct, "guard_manual": settings.guard_manual, "guard_loss_pct": settings.guard_loss_pct, "guard_flip_max": settings.guard_flip_max, "guard_flip_harvest": settings.guard_flip_harvest, "pct_harvest_auto": settings.pct_harvest_auto, "pct_harvest_pct": settings.pct_harvest_pct, "pre_plan": settings.pre_plan, "morning_reversal": settings.morning_reversal, "preclose_short": settings.preclose_short, "auto_prep": settings.auto_prep, "data_feed": settings.data_feed,
                         "ext_premarket": settings.ext_premarket, "ext_afterhours": settings.ext_afterhours,
                         "ext_overnight": settings.ext_overnight, "watchlist": settings.watchlist,
                         "auto_resume": settings.auto_resume, "stream_prices": settings.stream_prices,
                         "scale_out": settings.scale_out, "tod_filter": settings.tod_filter, "scalp_mode": settings.scalp_mode,
                         "aggressive_scalp": settings.aggressive_scalp,
                         "cooloff_streak": settings.cooloff_streak, "cooloff_symbol": settings.cooloff_symbol,
                         "confirm_trades": settings.confirm_trades},
            "ai_key_set": bool(_ai_key()), "ai_provider": _ai_provider(),
            "remote": auth.is_remote(request), "tunnel": {"state": tunnel.state, "url": tunnel.url},
            "sim": ARGS.sim, "setup_error": setup_error, "edition": android.EDITION,
            "device": android.health(), "update": _upd["info"], "update_prefs": _upd_prefs(),
            "stream": feed.info() if feed else {"status": "off", "error": "", "symbols": 0, "updates": 0}, "live_pin_set": bool(live_pin()),
            "leaderboard": learner.leaderboard()}
    if engine:
        engine.refresh_account(max_age=20)
        base.update(engine.status())
    return clean(base)


@app.post("/api/start")
def start():
    need_engine().start()
    return {"ok": True}


class StopReq(BaseModel):
    flatten: bool = False


@app.post("/api/stop")
def stop(r: StopReq):
    need_engine().stop(flatten=r.flatten)
    return {"ok": True}


@app.post("/api/scan")
def scan_now():
    e = need_engine()
    e._scan()
    try:
        e.refresh_setups()
    except Exception as ex:
        logging.warning("setups: %s", ex)
    return {"ok": True, "count": len(e.scan_info), "setups": len(getattr(e, "setups", []))}


@app.post("/api/cooloff/clear")
def cooloff_clear():
    need_engine().end_cooloff()
    return {"ok": True}


@app.post("/api/flatten")
def flatten():
    e = need_engine()
    e.flatten("manual flatten")
    e.event("Manual flatten of bot positions")
    return {"ok": True}


class LimitReq(BaseModel):
    daily_max_loss: float


@app.post("/api/limit")
def set_limit(r: LimitReq):
    if r.daily_max_loss <= 0:
        raise HTTPException(400, "Daily limit must be > 0")
    settings.daily_max_loss = float(r.daily_max_loss)
    settings.save()
    if engine:
        engine.event(f"Daily max loss set to ${settings.daily_max_loss:,.2f}")
        rk = engine.risk
        if rk.halted and rk.halt_reason.startswith("Daily max loss") and rk.day_pnl > -settings.daily_max_loss:
            rk.halted, rk.halt_reason = False, ""
            engine.event("Halt cleared: today's loss is inside the new daily limit")
    return {"ok": True}


class DayResetReq(BaseModel):
    pin: str = ""


class OptionsCfg(BaseModel):
    on: bool | None = None
    style: str | None = None
    daily_budget: float | None = None
    max_premium: float | None = None
    max_contracts: int | None = None
    max_positions: int | None = None
    tp_pct: float | None = None
    stop_pct: float | None = None
    underlyings: str | None = None
    pin: str = ""


@app.get("/api/options/status")
def options_status():
    return options_bot.status()


@app.post("/api/options/config")
def options_config(r: OptionsCfg, request: Request):
    """Turn the options module on/off and set its own limits. Turning it ON while on a LIVE account needs the PIN."""
    if r.on is True and settings.live:
        if not settings.options_live_unlocked:
            raise HTTPException(403, "Options are locked on LIVE. Unlock them first (Unlock for Live).")
    if r.on is not None:
        settings.options_on = bool(r.on)
        options_bot.halted = "" if r.on else options_bot.halted
        options_bot.ev("options module turned " + ("ON" if r.on else "OFF (open positions are still managed to exit)"), "warning")
    if r.style in ("spread", "long"):
        settings.options_style = r.style
        options_bot.style_override = ""
    for k, lo, hi in (("daily_budget", 10, 100000), ("max_premium", 10, 50000), ("tp_pct", 10, 500), ("stop_pct", 10, 90)):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, "options_" + k, float(min(hi, max(lo, v))))
    if r.max_contracts is not None:
        settings.options_max_contracts = int(min(20, max(1, r.max_contracts)))
    if r.max_positions is not None:
        settings.options_max_positions = int(min(6, max(1, r.max_positions)))
    if r.underlyings is not None:
        syms = [x.strip().upper() for x in r.underlyings.replace(";", ",").split(",") if x.strip().replace(".", "").isalpha()][:15]
        if syms:
            settings.options_underlyings = syms
    settings.save()
    return options_bot.status()


class OptionsUnlock(BaseModel):
    pin: str = ""
    unlock: bool = True


@app.post("/api/options/live_unlock")
def options_live_unlock(r: OptionsUnlock, request: Request):
    """Allow (or forbid) the options module to trade on a LIVE account. Needs the Live PIN."""
    ip = "pin:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    if not live_pin():
        raise HTTPException(403, "Set a Live PIN first (Settings).")
    if r.pin != live_pin():
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong PIN")
    settings.options_live_unlocked = bool(r.unlock)
    if not r.unlock:
        settings.options_on = False
    settings.save()
    options_bot.ev("options " + ("UNLOCKED for LIVE" if r.unlock else "locked for LIVE again"), "warning")
    return options_bot.status()


@app.post("/api/options/close_all")
def options_close_all():
    options_bot.close_all()
    return options_bot.status()


@app.get("/api/options/journal")
def options_journal(limit: int = 200):
    """The options module's own journal (options.db): closed and cancelled trades plus a summary."""
    rows = db.opt_all(min(max(int(limit), 1), 2000))
    return {"rows": rows, "summary": db.opt_summary(rows)}


@app.get("/api/options/journal.csv")
def options_journal_csv():
    import csv as _csv
    import io as _io
    rows = db.opt_all(5000)
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(db.OPT_COLS)
    for r in rows:
        w.writerow([r.get(k, "") for k in db.OPT_COLS])
    return Response(buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=sekexbot_options_journal.csv"})


@app.post("/api/day/reset")
def day_reset(r: DayResetReq, request: Request):
    """Start today's P&L (and the daily loss budget) again from the account's equity right now. LIVE needs the PIN."""
    if not engine:
        raise HTTPException(400, "Engine not running")
    if settings.live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin() or r.pin != live_pin():
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
    try:
        return {"ok": True, **engine.reset_day_baseline()}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.post("/api/halt/clear")
def clear_halt():
    if not engine:
        raise HTTPException(400, "Engine not running")
    rk = engine.risk
    was = rk.halted
    rk.halted, rk.halt_reason = False, ""
    engine.event("Halt cleared manually - will halt again if the daily limit is hit")
    return {"ok": True, "was_halted": was}


class OptsReq(BaseModel):
    allow_shorts: bool | None = None
    short_from_7am: bool | None = None
    shorts_24_5: bool | None = None
    pct_harvest: bool | None = None
    pm_trend: bool | None = None
    harvest_stop: bool | None = None
    etf_pair_guard: bool | None = None
    regime_filter: bool | None = None
    strategy_breaker: bool | None = None
    fractional_on: bool | None = None
    green_guard: bool | None = None
    morning_trend: bool | None = None
    max_spread_trend_pct: float | None = None
    max_position_pct_equity: float | None = None
    max_trade_notional: float | None = None
    max_spread_pct: float | None = None
    guard_manual: str | None = None
    guard_loss_pct: float | None = None
    guard_flip_max: int | None = None
    guard_flip_harvest: bool | None = None
    pct_harvest_auto: bool | None = None
    pct_harvest_pct: float | None = None
    data_feed: str | None = None
    ext_premarket: bool | None = None
    ext_afterhours: bool | None = None
    ext_overnight: bool | None = None
    auto_resume: bool | None = None
    stream_prices: bool | None = None
    scale_out: bool | None = None
    tod_filter: bool | None = None
    scalp_mode: bool | None = None
    aggressive_scalp: bool | None = None
    cooloff_streak: bool | None = None
    cooloff_symbol: bool | None = None
    confirm_trades: bool | None = None
    trade_all_flips: bool | None = None
    auto_prep: bool | None = None
    auto_study: bool | None = None
    auto_tune: bool | None = None
    let_run: bool | None = None
    proven_only: bool | None = None
    auto_direction: bool | None = None
    morning_reversal: bool | None = None
    pre_plan: bool | None = None
    reentry: bool | None = None
    preclose_short: bool | None = None


class LevelReq(BaseModel):
    level: str                      # conservative / balanced / aggressive / max / auto


@app.post("/api/level")
def set_level(r: LevelReq):
    from autobot.levels import LEVELS, apply_level
    name = r.level.lower()
    if name == "auto":
        settings.level, settings.level_auto = "auto", True
        if engine:
            engine._level_key = None                  # choose for the current session on the next tick
    elif name in LEVELS:
        settings.level, settings.level_auto, settings.level_active = name, False, ""
        apply_level(settings, name)
    else:
        raise HTTPException(400, "unknown level")
    settings.save()
    return {"ok": True, "level": settings.level}


@app.get("/api/level/stats")
def level_stats():
    from autobot.levels import LEVELS, LevelStats
    st = engine.levels.table() if engine else LevelStats().table()
    return {"levels": {k: {"label": v["label"], "blurb": v["blurb"]} for k, v in LEVELS.items()}, "stats": st,
            "level": settings.level, "auto": settings.level_auto, "active": settings.level_active}


@app.post("/api/options")
def options(r: OptsReq):
    if r.guard_manual in ("off", "alert", "close", "flip"):
        settings.guard_manual = r.guard_manual
        settings.save()
    if r.guard_flip_harvest is not None:
        settings.guard_flip_harvest = bool(r.guard_flip_harvest)
    if r.guard_flip_max is not None:
        settings.guard_flip_max = min(10, max(0, int(r.guard_flip_max)))
    if r.guard_loss_pct is not None:
        settings.guard_loss_pct = min(2.0, max(0.05, float(r.guard_loss_pct)))
        settings.save()
    if r.max_spread_trend_pct is not None:
        settings.max_spread_trend_pct = min(5.0, max(0.0, float(r.max_spread_trend_pct)))
    if r.max_trade_notional is not None:
        settings.max_trade_notional = max(0.0, float(r.max_trade_notional))
    if r.max_position_pct_equity is not None:
        settings.max_position_pct_equity = min(1.0, max(0.02, float(r.max_position_pct_equity)))
    if r.max_spread_pct is not None:
        settings.max_spread_pct = min(5.0, max(0.0, float(r.max_spread_pct)))
        settings.save()
    if r.pct_harvest_pct is not None:
        settings.pct_harvest_pct = min(1.0, max(0.05, float(r.pct_harvest_pct)))
        settings.save()
    for k in ("scale_out", "tod_filter", "scalp_mode", "aggressive_scalp", "cooloff_streak", "cooloff_symbol", "confirm_trades",
              "trade_all_flips", "allow_shorts", "short_from_7am", "shorts_24_5", "auto_prep", "auto_study", "auto_tune", "let_run", "proven_only", "auto_direction", "morning_reversal", "preclose_short", "pre_plan", "reentry", "pct_harvest", "pct_harvest_auto", "pm_trend", "harvest_stop", "etf_pair_guard", "regime_filter", "strategy_breaker", "fractional_on", "green_guard", "morning_trend"):
        v = getattr(r, k)
        if v is not None:
            if k not in ("auto_prep", "auto_study", "auto_tune", "short_from_7am", "shorts_24_5", "let_run", "proven_only", "morning_reversal", "preclose_short", "reentry", "confirm_trades", "pct_harvest", "pct_harvest_auto", "pm_trend", "harvest_stop", "etf_pair_guard", "regime_filter", "strategy_breaker", "fractional_on", "green_guard", "morning_trend") and getattr(settings, k) != v:
                settings.level, settings.level_auto = "custom", False     # you changed a box by hand: that's your own Custom level
            setattr(settings, k, v)
            if engine and k == "tod_filter" and hasattr(engine, "_tod"):
                del engine._tod
    settings.save()
    if r.allow_shorts is not None:
        settings.allow_shorts = r.allow_shorts
    if r.auto_resume is not None:
        settings.auto_resume = r.auto_resume
    if r.stream_prices is not None and r.stream_prices != settings.stream_prices:
        settings.stream_prices = r.stream_prices
        settings.save()
        if not ARGS.sim and not (engine and engine.running):
            build_engine()
        elif not ARGS.sim:
            if r.stream_prices and engine:
                from autobot.stream import LiveFeed
                k, sec = api_keys(settings.live)
                _set_feed(LiveFeed(k, sec, settings.data_feed))
                engine.broker.live = feed
            elif engine:
                engine.broker.live = None
                _set_feed(None)
    for k in ("ext_premarket", "ext_afterhours", "ext_overnight"):
        v = getattr(r, k)
        if v is not None:
            setattr(settings, k, v)
            if engine:
                engine.event(f"{k.replace('ext_', '').replace('afterhours', 'after-hours')} trading "
                             f"{'ON' if v else 'OFF'}")
    if r.data_feed in ("iex", "sip") and r.data_feed != settings.data_feed:
        if r.data_feed == "sip" and not ARGS.sim:          # make sure the account really has SIP first
            try:
                from alpaca.data.enums import DataFeed
                from alpaca.data.historical import StockHistoricalDataClient
                from alpaca.data.requests import StockLatestQuoteRequest
                k, sec = api_keys(settings.live)
                StockHistoricalDataClient(k, sec).get_stock_latest_quote(
                    StockLatestQuoteRequest(symbol_or_symbols="SPY", feed=DataFeed.SIP))
            except Exception as ex:
                raise HTTPException(400, "Alpaca says this account can't use SIP data yet "
                                         f"({str(ex)[:120]}). It stays on IEX.")
        was = bool(engine and engine.running)
        if was:
            engine.stop()                  # positions keep their server-side stops
        settings.data_feed = r.data_feed
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        if engine:
            engine.event(f"Data feed switched to {r.data_feed.upper()}" + (" (bot restarted)" if was else ""))
    settings.save()
    return {"ok": True}


class ModeReq(BaseModel):
    live: bool
    pin: str = ""
    restart: bool = False


@app.post("/api/mode")
def mode(r: ModeReq, request: Request):
    """Switch PAPER <-> LIVE. Live needs the PIN and working live keys; if the auto-trader is running it is
    stopped (positions keep their server-side stops), switched, and started again in the new mode."""
    if ARGS.sim:
        raise HTTPException(400, "The simulator has no live mode.")
    if r.live == settings.live:
        return {"ok": True, "live": settings.live}
    was_running = bool(engine and engine.running)
    if was_running and not r.restart:
        raise HTTPException(409, "RUNNING")
    if r.live:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(400, "No Live PIN set yet. Add one in ⚙ → Broker keys → Live.")
        if r.pin != live_pin():
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
        k, sec = api_keys(True)
        if not (k and sec):
            raise HTTPException(400, "No LIVE keys saved yet. Add them in ⚙ → Broker keys → Live.")
        test = _test_alpaca(k, sec, paper=False)
        if not test["ok"]:
            raise HTTPException(400, test["error"])
    if was_running:
        engine.stop()
    settings.live = r.live
    settings.save()
    build_engine()
    if engine is None:            # could not connect in the new mode: go back
        err = setup_error
        settings.live = not r.live
        settings.save()
        build_engine()
        raise HTTPException(400, f"Couldn't connect in {'LIVE' if r.live else 'PAPER'} mode: {err}")
    engine.event(f"Switched to {'LIVE — real money' if r.live else 'PAPER'} trading", "warning" if r.live else "info")
    alerts.send("system", "🔴 LIVE trading ON — real money" if r.live else "Back to PAPER trading",
                "Orders now use your real-money account." if r.live else "Orders now use the paper account.")
    if was_running:
        engine.start(resumed=True)
    return {"ok": True, "live": settings.live, "restarted": was_running}


@app.post("/api/reconnect")
def reconnect():
    if engine and engine.running:
        raise HTTPException(400, "Stop the bot first")
    build_engine()
    return {"ok": engine is not None, "error": setup_error}


@app.get("/api/trades")
def trades(limit: int = 200):
    return db.recent(limit)


@app.get("/api/daily")
def daily():
    return db.daily_summary()


@app.post("/api/learner/reset")
def reset_learner():
    learner.reset()
    return {"ok": True}


@app.get("/api/chart/{symbol}")
def chart(symbol: str, tf: int = 3):
    e = need_engine()
    sym = symbol.upper()
    df, as_of = None, "live"
    try:
        df = e.broker.chart_bars(sym)
    except Exception:
        df = None
    if df is None or len(df) < 20:          # fall back to the old sources
        df = e.raw.get(sym)
        if df is None or len(df) < 20:
            try:
                df, as_of = e.broker.analysis_bars(sym)
            except Exception:
                df = None
    if df is not None and len(df):
        age = (e.broker.now() - df.index[-1]).total_seconds()
        if age > 300:
            as_of = "last trade " + df.index[-1].strftime("%a %b %d %I:%M %p").replace(" 0", " ")
    if df is None or df.empty:
        return {"bars": [], "as_of": ""}
    tf = tf if tf in (1, 3, 5, 15) else 3
    from autobot.indicators import vwap as _vwap
    vw = _vwap(df)
    h = ribbon(df, lines=True, tf=f"{tf}min").tail(400)
    cols = ["open", "high", "low", "close", "fast", "slow", "band_hi", "band_lo", "state",
            "e10", "e12", "e14", "e16", "e18"]
    out = []
    for ts, row in h.iterrows():
        d = {"t": ts.strftime("%H:%M"), "d": ts.strftime("%a %b %d")}
        hm = ts.hour * 60 + ts.minute
        d["x"] = 0 if 570 <= hm < 960 else (1 if 240 <= hm < 1200 else 2)   # 0 regular, 1 pre/after, 2 overnight
        d.update({c: (None if row[c] != row[c] else round(float(row[c]), 4)) for c in cols})
        d["v"] = int(row["volume"]) if row["volume"] == row["volume"] else 0
        end = ts + pd.Timedelta(minutes=tf)
        w = vw[vw.index < end]
        d["vwap"] = round(float(w.iloc[-1]), 4) if len(w) else None
        out.append(d)
    trades_ = [t for t in db.recent(300) if t["symbol"] == sym and t["day"] == e.day]
    pred = {"preds": [], "outlook": None, "stats": {}}
    try:
        from autobot.predict import predict as _predict
        off = len(ribbon(df, lines=False, tf=f"{tf}min")) - len(h)      # h is the last 400 candles
        pred = _predict(df, tf)
        pred["preds"] = [dict(p, i=p["i"] - off) for p in pred["preds"] if p["i"] - off >= 0]
    except Exception as ex:
        logging.debug("predict %s: %s", sym, ex)
    return clean({"bars": out, "trades": trades_, "as_of": as_of, "tf": tf, **pred})


_wl_pred = {"at": 0.0, "tf": 0, "items": []}


@app.get("/api/predict/watchlist")
def predict_watchlist(tf: int = 3, snd: int = 0):
    """Early BUY?/SELL? warnings for every watchlist stock (display only, never trades). Cached 30 s."""
    import time as _tm
    from autobot.predict import chip_status
    e = need_engine()
    if snd:                      # an open dashboard is beeping/speaking itself: the phone stays quiet
        alerts.screen_sound_at = _tm.time()
    tf = tf if tf in (1, 3, 5, 15) else 3
    syms = [w.upper() for w in settings.watchlist]
    if _tm.time() - _wl_pred["at"] < 30 and _wl_pred["tf"] == tf and _wl_pred.get("syms") == syms:
        return clean({"items": _wl_pred["items"], "tf": tf})
    frames = {s: e.raw.get(s) for s in syms if e.raw.get(s) is not None and len(e.raw.get(s)) >= 60}
    missing = [s for s in syms if s not in frames]
    if missing:
        try:
            now = e.broker.now()
            got = e.broker.bars(missing, start=now.replace(hour=4, minute=0, second=0, microsecond=0))
            frames.update({k: v for k, v in (got or {}).items() if v is not None and len(v) >= 60})
        except Exception as ex:
            logging.debug("watchlist bars: %s", ex)
    for s in [s for s in syms if s not in frames][:10]:       # market closed / no bars today: last session
        try:
            df = e.broker.chart_bars(s)
            if df is not None and len(df) >= 60:
                frames[s] = df
        except Exception:
            continue
    items = []
    for s in syms:
        df = frames.get(s)
        if df is None:
            items.append({"symbol": s, "ready": False, "state": 0, "outlook": None, "rate": None,
                          "note": "No price data from Alpaca for this ticker"})
            continue
        try:
            items.append(dict(chip_status(df, tf), symbol=s))
        except Exception as ex:
            items.append({"symbol": s, "ready": False, "state": 0, "outlook": None, "rate": None, "note": str(ex)[:80]})
    _wl_pred.update(at=_tm.time(), tf=tf, items=items, syms=syms)
    return clean({"items": items, "tf": tf})


_pos_tr = {"at": 0.0, "items": {}, "syms": ()}


@app.get("/api/position/trends")
def position_trends():
    """Trend prediction for every open position (broker positions + bot trades): ribbon colour, early BUY?/SELL?
    warning with confidence, the direction call, and whether it works for or against the position. Cached 30 s."""
    import time as _tm
    from autobot.predict import chip_status
    from autobot.direction import direction
    from autobot.indicators import enrich, ribbon_state
    e = need_engine()
    pos = e.broker.positions()
    held = {s: (1 if p["qty"] > 0 else -1) for s, p in pos.items()}
    for s, t in list(e.trades.items()):
        held.setdefault(s, t.dir)
    syms = tuple(sorted(held))
    if _tm.time() - _pos_tr["at"] < 30 and _pos_tr["syms"] == syms:
        return clean({"items": _pos_tr["items"]})
    frames = {s: e.raw.get(s) for s in syms if e.raw.get(s) is not None and len(e.raw.get(s)) >= 30}
    miss = [s for s in syms if s not in frames]
    if miss:
        try:
            now = e.broker.now()
            got = e.broker.bars(miss, start=now.replace(hour=4, minute=0, second=0, microsecond=0))
            frames.update({k: v for k, v in (got or {}).items() if v is not None and len(v) >= 30})
        except Exception:
            pass
    for s in [s for s in syms if s not in frames][:6]:
        try:
            df = e.broker.chart_bars(s)
            if df is not None and len(df) >= 30:
                frames[s] = df
        except Exception:
            continue
    items = {}
    for s in syms:
        df, d = frames.get(s), held[s]
        if df is None:
            items[s] = {"ready": False, "note": "no price data"}
            continue
        try:
            cs = chip_status(df, 3)
            it = {"ready": bool(cs.get("ready")), "state": cs.get("state", 0), "rate": cs.get("rate"), "outlook": cs.get("outlook")}
            try:
                dc = direction(enrich(df), 0.0, ribbon_state(df), e.bias, None)
                it.update(call=dc["call"], score=dc["score"], stretched=dc.get("stretched", False))
            except Exception:
                pass
            o = it["outlook"]
            it["against"] = bool(o and ((o["side"] == "sell" and d > 0) or (o["side"] == "buy" and d < 0)))
            it["with"] = bool(o and ((o["side"] == "buy" and d > 0) or (o["side"] == "sell" and d < 0)))
            it["dir"] = d
            it["lean_against"] = bool(it.get("call") in ("LONG", "SHORT") and ((it["call"] == "SHORT") == (d > 0)))
            items[s] = it
        except Exception as ex:
            items[s] = {"ready": False, "note": str(ex)[:80]}
    _pos_tr.update(at=_tm.time(), items=items, syms=syms)
    return clean({"items": items})


@app.get("/api/analyze/{symbol}")
def analyze_symbol(symbol: str):
    if engine is None:
        return {"error": "The live chart read needs your Alpaca connection: " + (setup_error or "not connected") +
                         " (The screenshot reader works without it.)"}
    e = engine
    sym = symbol.upper().strip()
    if not sym.replace(".", "").isalpha():
        return {"error": "Enter a valid ticker, e.g. NVDA"}
    df, as_of = e.raw.get(sym), "live"
    try:
        if df is None or len(df) < 20:
            df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        return {"error": f"Couldn't load bars for {sym}: {str(ex)[:200]}"}
    if df is None or len(df) < 20:
        return {"error": f"No recent 1-minute data for {sym}. Check the ticker is a US stock/ETF on Alpaca."}
    try:
        res = analyze(sym, df, e.bias, learner)
    except Exception as ex:
        logging.exception("analyze failed")
        return {"error": f"Analysis failed for {sym}: {str(ex)[:200]}"}
    res["as_of"] = as_of
    return clean(res)


class VisionReq(BaseModel):
    image_b64: str
    media_type: str = "image/png"
    question: str = ""


@app.post("/api/vision")
def vision(r: VisionReq):
    if len(r.image_b64) > 7_000_000:
        raise HTTPException(400, "Image too large (max ~5 MB)")
    try:
        plan = vision_read(r.image_b64, r.media_type, r.question)
    except Exception as ex:
        logging.exception("vision failed")
        return {"error": f"Couldn't reach Claude: {str(ex)[:200]}"}
    if plan.get("error"):
        return plan
    sym = (plan.get("symbol") or "").upper().strip()
    if sym and engine and sym.replace(".", "").isalpha():
        try:   # add the live price so you can compare with the screenshot
            q = engine.broker.quotes([sym], engine.session.name if engine.session else "REGULAR").get(sym)
            if q:
                plan["live_price"] = round((q[0] + q[1]) / 2, 2)
        except Exception:
            pass
        plan["on_watchlist"] = sym in [w.upper() for w in settings.watchlist]
    return clean(plan)


class KeyReq(BaseModel):
    key: str


from autobot.analyst import ai_key as _ai_key, provider as _ai_provider  # noqa: E402


@app.post("/api/anthropic_key")
def set_key(r: KeyReq):
    k = r.key.strip().strip('"').strip("'")
    if not k.startswith("sk-"):
        raise HTTPException(400, "That doesn't look like a Claude API key (should start with sk-ant-)")
    vals = {"ANTHROPIC_API_KEY": k}
    if not os.getenv("OPENAI_API_KEY"):
        vals["AI_PROVIDER"] = "anthropic"
    write_env(vals)
    return {"ok": True}


class OpenAIKeyReq(BaseModel):
    key: str = ""
    model: str | None = None


@app.post("/api/openai_key")
def set_openai_key(r: OpenAIKeyReq):
    """Save a ChatGPT (OpenAI) API key. It becomes the active AI unless you already chose Claude with a key saved."""
    k = r.key.strip().strip('"').strip("'")
    vals = {}
    if k:
        if not k.startswith("sk-"):
            raise HTTPException(400, "That doesn't look like an OpenAI API key (should start with sk-)")
        vals["OPENAI_API_KEY"] = k
        if not os.getenv("ANTHROPIC_API_KEY"):
            vals["AI_PROVIDER"] = "openai"
    if r.model is not None:
        vals["OPENAI_MODEL"] = r.model.strip()
    if not vals:
        raise HTTPException(400, "Paste your OpenAI API key")
    write_env(vals)
    from autobot import analyst
    analyst._MODEL_CACHE.pop("oa", None)
    return {"ok": True}


class ProviderReq(BaseModel):
    provider: str


@app.post("/api/ai_provider")
def set_ai_provider(r: ProviderReq):
    p = r.provider.strip().lower()
    if p not in ("anthropic", "openai"):
        raise HTTPException(400, "Choose Claude or ChatGPT")
    if not os.getenv("OPENAI_API_KEY" if p == "openai" else "ANTHROPIC_API_KEY"):
        raise HTTPException(400, f"Save a {'ChatGPT (OpenAI)' if p == 'openai' else 'Claude'} API key first")
    write_env({"AI_PROVIDER": p})
    return {"ok": True, "provider": p}


# ---------------- broker keys (GUI setup) ----------------
# Keys are written to the local .env file and never sent back to the browser (only a masked hint).
def _test_alpaca(key: str, secret: str, paper: bool) -> dict:
    from alpaca.trading.client import TradingClient
    try:
        a = TradingClient(key, secret, paper=paper).get_account()
        return {"ok": True, "account": str(a.account_number), "equity": float(a.equity),
                "buying_power": float(a.buying_power), "status": str(getattr(a.status, "value", a.status))}
    except Exception as e:
        msg = _friendly(e, not paper)
        if "rejected" in msg:
            msg = (f"Alpaca rejected these keys. Check you copied the full Key ID and Secret from your "
                   f"{'LIVE' if not paper else 'Paper'} account (regenerate them if the secret was lost).")
        return {"ok": False, "error": msg}


@app.get("/api/keys")
def keys_status():
    pk, ps = api_keys(False)
    lk, ls = api_keys(True)
    return {"paper": {"set": bool(pk and ps), "hint": mask(pk)},
            "live": {"set": bool(lk and ls), "hint": mask(lk)},
            "live_pin_set": bool(live_pin()), "anthropic_set": bool(os.getenv("ANTHROPIC_API_KEY")),
            "anthropic_hint": mask(os.getenv("ANTHROPIC_API_KEY", "")),
            "openai_set": bool(os.getenv("OPENAI_API_KEY")), "openai_hint": mask(os.getenv("OPENAI_API_KEY", "")),
            "openai_model": os.getenv("OPENAI_MODEL", ""), "ai_provider": _ai_provider(),
            "mode": "live" if settings.live else "paper", "connected": engine is not None,
            "error": setup_error, "sim": ARGS.sim}


class KeyTestReq(BaseModel):
    account: str = "paper"      # paper | live
    key: str = ""
    secret: str = ""


def _clean_key(v: str) -> str:
    return v.strip().strip('"').strip("'").replace(" ", "")


@app.post("/api/keys/test")
def keys_test(r: KeyTestReq):
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    if not k or not s_:          # test the saved keys
        k, s_ = api_keys(not paper)
    if not k or not s_:
        raise HTTPException(400, "Enter the API Key ID and Secret first")
    return _test_alpaca(k, s_, paper)


class KeySaveReq(BaseModel):
    account: str = "paper"
    key: str = ""
    secret: str = ""
    live_pin: str = ""


@app.post("/api/keys/save")
def keys_save(r: KeySaveReq):
    if engine and engine.running:
        raise HTTPException(400, "Stop the bot before changing broker keys")
    paper = r.account != "live"
    k, s_ = _clean_key(r.key), _clean_key(r.secret)
    vals = {}
    if k or s_:
        if not (k and s_):
            raise HTTPException(400, "Enter both the API Key ID and the Secret")
        if paper and k.startswith("AK"):
            raise HTTPException(400, "That's a LIVE key (starts with AK). Paper keys start with PK — "
                                     "switch Alpaca's dashboard to Paper Trading and generate keys there.")
        if not paper and k.startswith("PK"):
            raise HTTPException(400, "That's a PAPER key (starts with PK). Live keys start with AK.")
        test = _test_alpaca(k, s_, paper)
        if not test["ok"] and not ARGS.sim:
            return {"ok": False, "error": test["error"]}
        pre = "ALPACA_PAPER" if paper else "ALPACA_LIVE"
        vals[f"{pre}_KEY"], vals[f"{pre}_SECRET"] = k, s_
    if r.live_pin:
        if len(r.live_pin) < 4:
            raise HTTPException(400, "Use a PIN of at least 4 characters")
        vals["LIVE_PIN"] = r.live_pin.strip()
    if not vals:
        raise HTTPException(400, "Nothing to save")
    write_env(vals)
    if not ARGS.sim and (paper != settings.live):   # keys for the active mode changed -> reconnect
        build_engine()
    return {"ok": True, "connected": engine is not None, "error": setup_error}


# ---------------- manual trading: your own Buy / Sell / Close ----------------
# Manual positions are yours: the bot never enters, manages or flattens them at the close.
# (The daily-loss halt closes every LOSING position in the account, manual ones included; winners stay open.)
def _session_name(e):
    from autobot.sessions import current_session
    try:
        sess = current_session(e.broker.trading_day, e.broker.now())
        return sess.name if sess else "CLOSED"
    except Exception:
        return "CLOSED"


def _price(e, sym, sess):
    """Always returns something to price an order with (live quote, last trade, or last close)."""
    try:
        return e.broker.price_info(sym, sess)
    except Exception:
        return {"bid": None, "ask": None, "last": None, "prev_close": None, "ts": None, "source": ""}


def _quote(e, sym, sess):
    p = _price(e, sym, sess)
    bid, ask, last = p.get("bid"), p.get("ask"), p.get("last")
    return (bid or last), (ask or last)


def _valid_sym(sym):
    sym = (sym or "").upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker, e.g. AAPL")
    return sym


@app.get("/api/manual/quote/{symbol}")
def manual_quote(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    sess = _session_name(e)
    pr = _price(e, sym, sess)
    last, pc = pr.get("last"), pr.get("prev_close")
    if last is None and not pr.get("bid"):
        raise HTTPException(404, f"No price found for {sym}. Check the ticker is a US stock or ETF on Alpaca.")
    bid, ask = pr.get("bid") or last, pr.get("ask") or last
    ts = pr.get("ts")
    live = sess != "CLOSED" and bool(pr.get("bid")) and bool(ts) and (e.broker.now() - ts).total_seconds() < 900
    pos = e.broker.positions().get(sym)
    return clean({"symbol": sym, "bid": bid, "ask": ask, "last": last or (bid + ask) / 2, "session": sess,
                  "prev_close": pc, "change": (last - pc) if last and pc else None,
                  "change_pct": ((last / pc - 1) * 100) if last and pc else None,
                  "live": live, "source": pr.get("source", ""), "as_of": ts.strftime("%a %b %d %I:%M %p").replace(" 0", " ") if ts else "",
                  "has_book": bool(pr.get("bid")),
                  "spread_pct": round((ask - bid) / ((ask + bid) / 2) * 100, 3) if bid and ask and ask >= bid else None,
                  "max_spread_pct": settings.max_spread_pct,
                  "position": pos["qty"] if pos else 0, "avg_entry": pos["avg_entry"] if pos else None,
                  "bot": sym in e.trades, "buying_power": (e.acct or e.broker.account()).get("buying_power")})


class PreSet(BaseModel):
    pre_window: bool | None = None
    pre_from: int | None = None
    pre_until: int | None = None
    ext_max_notional: float | None = None
    pre_auto: bool | None = None


def _pre_state():
    return {"pre_window": settings.pre_window, "pre_from": settings.pre_from, "pre_until": settings.pre_until,
            "ext_max_notional": settings.ext_max_notional, "pre_entries_off": settings.pre_entries_off,
            "pre_strategy_off": settings.pre_strategy_off, "pre_only": settings.pre_only, "ext_harvest_spread_mult": settings.ext_harvest_spread_mult, "pre_auto": settings.pre_auto, "note": settings.pre_preset_note}


def apply_pre_preset(source="auto"):
    """Build the pre-market preset from the journal (or the recommended one) and save it. Daily loss limit untouched."""
    from autobot import prepreset
    e = need_engine()
    rows = [r for r in db.recent(20000) if r.get("mode") == e.mode] if source == "auto" else []
    if source == "only":
        res = {"settings": dict(prepreset.STATIC, pre_only=["EXT_TREND", "FLUSH_BOUNCE"], ext_harvest_spread_mult=3.0), "trades": 0, "source": "only",
               "note": "Pre-market only preset: the bot runs just EXT_TREND and FLUSH_BOUNCE in the pre-market (the two that held up in your journal), "
                       "starts trades 7:00 to 9:00, max $10,000 each, and harvests at least 3 times the spread."}
    elif source == "auto":
        res = prepreset.build(rows)
        res["settings"].setdefault("pre_only", [])
        res["settings"].setdefault("ext_harvest_spread_mult", 2.0)
    else:
        res = {"settings": dict(prepreset.STATIC, pre_only=[], ext_harvest_spread_mult=2.0), "trades": 0, "source": "recommended",
               "note": "Recommended preset: start pre-market trades 7:00 to 9:00, max $10,000 per trade, nothing else changed."}
    for k, v in res["settings"].items():
        setattr(settings, k, v)
    settings.pre_preset_note = res["note"]
    settings.save()
    e.event("Pre-market preset applied: " + res["note"], "info")
    return res


def run_autotune():
    """Nightly: switch strategies off per market session when they lose there (own closed trades), retest after a week."""
    from autobot import sessiontune as autotune
    e = need_engine()
    today = e.broker.now().strftime("%Y-%m-%d")
    rows = [r for r in db.recent(20000) if r.get("mode") == e.mode and r.get("status") == "closed"]
    off, since, ev = autotune.evaluate(rows, today, settings.tune_off, settings.tune_since, int(settings.tune_min_trades or 12))
    settings.tune_off, settings.tune_since = off, since
    if ev:
        settings.tune_log = (settings.tune_log + [{"day": today, "text": t} for t in ev])[-60:]
        for t in ev:
            e.event("Session auto-off: " + t, "info")
    settings.save()
    return ev


def _tune_state():
    from autobot import sessiontune as autotune
    items = [{"session": s, "label": autotune.LABEL.get(s, s), "strategy": st, "retest": d}
             for s in autotune.SESSIONS for st, d in sorted((settings.tune_off or {}).get(s, {}).items())]
    return {"on": settings.session_tune, "min_trades": settings.tune_min_trades, "off": items, "log": list(reversed(settings.tune_log or []))[:15]}


class TuneIn(BaseModel):
    on: bool | None = None
    run: bool = False
    clear: bool = False


@app.get("/api/autotune")
def autotune_get():
    return _tune_state()


@app.post("/api/autotune")
def autotune_set(r: TuneIn):
    if r.on is not None:
        settings.session_tune = bool(r.on)
    if r.clear:
        settings.tune_off, settings.tune_since = {}, {}
    settings.save()
    ev = run_autotune() if r.run else []
    return dict(_tune_state(), changes=ev)


class SmartIn(BaseModel):
    on: bool


@app.get("/api/smart")
def smart_get():
    from autobot import smartentry
    return dict(smartentry.stats(), on=settings.smart_entry)


@app.post("/api/smart")
def smart_set(r: SmartIn):
    settings.smart_entry = bool(r.on)
    settings.save()
    return smart_get()


class BootIn(BaseModel):
    on: bool


def _boot_flag():
    return os.path.join(os.path.expanduser("~"), ".sekexbot", "no_autostart")


def _boot_state():
    script = os.path.exists(os.path.join(os.path.expanduser("~"), ".termux", "boot", "10-sekexbot"))
    return {"on": bool(settings.start_on_boot), "script": script, "flag": os.path.exists(_boot_flag())}


def _boot_apply():
    """Mirror the setting to the file the boot script looks at (so the phone's boot script needs no Python)."""
    try:
        f = _boot_flag()
        os.makedirs(os.path.dirname(f), exist_ok=True)
        if settings.start_on_boot:
            if os.path.exists(f):
                os.remove(f)
        else:
            open(f, "w").write("off")
    except Exception as ex:
        logging.warning("start-on-boot flag: %s", ex)


@app.get("/api/boot")
def boot_get():
    return _boot_state()


@app.post("/api/boot")
def boot_set(r: BootIn):
    settings.start_on_boot = bool(r.on)
    settings.save()
    _boot_apply()
    return _boot_state()


class NightIn(BaseModel):
    on: bool | None = None
    dir: str | None = None


@app.get("/api/night")
def night_get():
    e = need_engine()
    now = e.broker.now()
    items = []
    nd = e.night_dir()
    for r in (e.shortlist or []):
        sym = str(r.get("symbol", "")).upper()
        if not sym or (nd == "sell" and "long only" in str(r.get("borrow", ""))):
            continue
        try:
            st = e._mover_bot({"symbol": sym, "side": "short" if nd == "sell" else "buy"}, now)
        except Exception:
            st = ""
        items.append({"symbol": sym, "score": r.get("score"), "tags": r.get("tags") or [], "change": r.get("change"),
                      "borrow": r.get("borrow"), "status": st})
    mine = [{"symbol": t.symbol, "qty": t.qty, "entry": t.entry, "status": t.status, "pnl": round(((t.last_price or t.entry) - t.entry) * t.dir * t.qty, 2)}
            for t in list(e.trades.values()) if t.ext and (t.side == "sell") == (nd == "sell")]
    return clean({"dir": nd, "on": settings.night_short, "active": e.night_window(now), "window": "8:00 PM - 7:00 AM ET", "items": items,
                  "at": e.shortlist_at, "trades": mine, "account_can_short": bool(e.acct.get("shorting_enabled", True))})


@app.post("/api/night")
def night_set(r: NightIn):
    if r.on is not None:
        settings.night_short = bool(r.on)
    if r.dir in ("buy", "sell"):
        settings.night_dir = r.dir
    settings.save()
    return night_get()


@app.get("/api/sesstab")
def sesstab():
    """v1.84: one tab whose content follows the market session: Pre-market / Regular / After-hours / Night / Closed."""
    e = need_engine()
    now = e.broker.now()
    ss = e.session
    name = ss.name if ss else "CLOSED"
    night = e.night_window(now)
    nd = e.night_dir()
    items, title, at = [], "", ""
    if night and name in ("OVERNIGHT", "CLOSED", "PRE"):
        name = "NIGHT"
        title = "Night " + ("buys" if nd == "buy" else "shorts")
        n = night_get()
        items, at = n.get("items", []), n.get("at", "")
    else:
        title = {"PRE": "Pre-market", "REGULAR": "Regular hours", "AFTER": "After-hours", "OVERNIGHT": "Overnight"}.get(name, "Market closed")
        for m in (e._movers_view() or [])[:25]:
            items.append({"symbol": m.get("symbol"), "score": m.get("score"), "tags": [x for x in [m.get("plan"), m.get("call")] if x],
                          "change": m.get("move"), "side": m.get("side"), "status": m.get("bot", "")})
        at = getattr(e, "movers_at", "")
        if not items:
            for r in (e.shortlist or [])[:15]:
                items.append({"symbol": r.get("symbol"), "score": r.get("score"), "tags": r.get("tags") or [], "change": r.get("change"),
                              "status": e._mover_bot({"symbol": str(r.get("symbol", "")).upper(), "side": "buy"}, now)})
            at = e.shortlist_at
    mine = [{"symbol": t.symbol, "side": t.side, "qty": t.qty, "entry": t.entry, "status": t.status,
             "pnl": round(((t.last_price or t.entry) - t.entry) * t.dir * t.qty, 2)}
            for t in list(e.trades.values()) if t.ext or name == "REGULAR"]
    return clean({"session": name, "title": title, "items": items, "at": at, "trades": mine, "night_on": settings.night_short,
                  "night_dir": nd, "night_active": night, "window": "8:00 PM - 7:00 AM ET",
                  "account_can_short": bool(e.acct.get("shorting_enabled", True))})


@app.get("/api/pre/settings")
def pre_settings_get():
    return _pre_state()


@app.post("/api/pre/preset")
def pre_preset(source: str = "auto"):
    res = apply_pre_preset(source if source in ("auto", "only") else "recommended")
    return dict(_pre_state(), applied=res["source"])


@app.post("/api/pre/settings")
def pre_settings_set(r: PreSet):
    """Pre-market guard (v1.75). Never touches the daily loss limit."""
    if r.pre_window is not None:
        settings.pre_window = bool(r.pre_window)
        if settings.pre_window:
            settings.pre_entries_off = False
    if r.pre_from is not None:
        settings.pre_from = max(240, min(int(r.pre_from), 570))
    if r.pre_until is not None:
        settings.pre_until = max(240, min(int(r.pre_until), 570))
    if settings.pre_until <= settings.pre_from:
        settings.pre_until = min(570, settings.pre_from + 30)
    if r.ext_max_notional is not None:
        settings.ext_max_notional = max(0.0, min(float(r.ext_max_notional), 1_000_000.0))
    if r.pre_auto is not None:
        settings.pre_auto = bool(r.pre_auto)
    settings.save()
    return _pre_state()


# ---------- v1.76: Close-now log: every time a position could be closed for a real profit ----------
_cn_file = DATA_DIR / "closenow_log.jsonl"
_cn_events = []
_cn_state = {}
try:
    if _cn_file.exists():
        _cn_events = [json.loads(x) for x in _cn_file.read_text().splitlines()[-3000:] if x.strip()]
except Exception:
    _cn_events = []


def _cn_add(ev):
    _cn_events.append(ev)
    del _cn_events[:-3000]
    try:
        with open(_cn_file, "a") as f:
            f.write(json.dumps(ev) + "\n")
    except Exception:
        pass


def _cn_tick():
    e = engine
    if not e:
        return
    thr = float(getattr(settings, "closenow_min", 10.0) or 10.0)
    pos = e.broker.positions()
    now = e.broker.now()
    sess = _session_name(e)
    qs = {}
    if pos:
        try:
            qs = e.broker.quotes(list(pos.keys()), sess) or {}
        except Exception:
            qs = {}
    stamp = now.strftime("%Y-%m-%d %H:%M:%S")
    for s, p in pos.items():
        q = qs.get(s)
        if not (q and q[0] and q[1]):
            continue
        qty = float(p["qty"])
        xp = q[0] if qty > 0 else q[1]
        avg = float(p["avg_entry"])
        cn = (xp - avg) * qty
        spr = (q[1] - q[0]) / q[1] * 100 if q[1] else 0
        who = "bot" if s in e.trades else ("harvest" if s in harvester.jobs else "you")
        st = _cn_state.get(s)
        base = {"t": stamp, "symbol": s, "who": who, "session": sess, "qty": qty, "avg": round(avg, 4), "exit_px": round(xp, 4),
                "spread_pct": round(spr, 3), "side": "long" if qty > 0 else "short"}
        if cn >= thr and not st:
            _cn_state[s] = {"t0": now, "peak": cn, "last": cn}
            _cn_add(dict(base, event="UP", close_now=round(cn, 2), peak=round(cn, 2), note=f"close-now crossed above ${thr:,.0f}"))
        elif st:
            st["last"] = cn
            st["peak"] = max(st["peak"], cn)
            if cn < thr - 2:
                mins = (now - st["t0"]).total_seconds() / 60
                _cn_add(dict(base, event="FELL", close_now=round(cn, 2), peak=round(st["peak"], 2), mins=round(mins, 1),
                             note=f"fell back under ${thr:,.0f}, was up to ${st['peak']:,.2f}, {mins:.1f} min above"))
                _cn_state.pop(s, None)
    for s in [k for k in _cn_state if k not in pos]:
        st = _cn_state.pop(s)
        mins = (now - st["t0"]).total_seconds() / 60
        _cn_add({"t": stamp, "symbol": s, "who": "", "session": sess, "event": "CLOSED", "close_now": round(st["last"], 2),
                 "peak": round(st["peak"], 2), "mins": round(mins, 1), "qty": 0, "avg": 0, "exit_px": 0, "spread_pct": 0, "side": "",
                 "note": f"position closed; last close-now ${st['last']:,.2f}, peak ${st['peak']:,.2f}, {mins:.1f} min above"})


def _cn_loop():
    import time as _t
    while True:
        _t.sleep(5)
        try:
            _cn_tick()
        except Exception as ex:
            logging.debug("close-now log: %s", ex)


_th.Thread(target=_cn_loop, daemon=True, name="closenow").start()


@app.get("/api/closenow/log")
def closenow_log(limit: int = 300):
    return clean({"items": list(reversed(_cn_events[-max(1, min(int(limit), 3000)):])), "min": settings.closenow_min})


@app.get("/api/closenow/log.csv")
def closenow_csv():
    import csv as _csv
    import io as _io
    cols = ["t", "symbol", "who", "side", "event", "close_now", "peak", "mins", "qty", "avg", "exit_px", "spread_pct", "session", "note"]
    buf = _io.StringIO()
    w = _csv.writer(buf)
    w.writerow(cols)
    for r in _cn_events:
        w.writerow([r.get(k, "") for k in cols])
    return Response(buf.getvalue(), media_type="text/csv", headers={"Content-Disposition": "attachment; filename=sekexbot_closenow_log.csv"})


class CnThr(BaseModel):
    min: float


@app.post("/api/closenow/threshold")
def closenow_thr(r: CnThr):
    settings.closenow_min = max(1.0, min(float(r.min), 100000.0))
    settings.save()
    return {"ok": True, "min": settings.closenow_min}


@app.get("/api/scorecard")
def scorecard(days: int = 30, mode: str = "this", by: str = "strategy"):
    """Your own journal sliced by strategy / session / side / hour / symbol. Display only."""
    e = need_engine()
    days = max(1, min(int(days), 365))
    want = None if mode == "all" else (e.mode if mode in ("this", "") else mode.upper())
    cut = (e.broker.now() - timedelta(days=days)).strftime("%Y-%m-%d")
    rows = [r for r in db.recent(20000) if r.get("status") == "closed" and (r.get("day") or "") >= cut
            and (want is None or r.get("mode") == want)]
    groups = {}
    for r in rows:
        if by == "session":
            k = r.get("bucket") or "?"
        elif by == "side":
            k = "long (buy)" if r.get("side") == "buy" else "short (sell)"
        elif by == "symbol":
            k = r.get("symbol") or "?"
        elif by == "hour":
            try:
                k = f"{datetime.fromisoformat(r['opened_at']).hour:02d}:00"
            except Exception:
                k = "?"
        else:
            by, k = "strategy", (r.get("strategy") or "?").split("@")[0]
        groups.setdefault(k, []).append(float(r.get("pnl") or 0))
    out = []
    off = set(settings.strategy_off or [])
    for k, v in groups.items():
        w = [x for x in v if x > 0]
        l = [x for x in v if x < 0]
        gp, gl = sum(w), -sum(l)
        out.append({"key": k, "n": len(v), "win_rate": round(100 * len(w) / len(v), 1), "avg_win": round(sum(w) / len(w), 2) if w else 0,
                    "avg_loss": round(sum(l) / len(l), 2) if l else 0, "expectancy": round(sum(v) / len(v), 2),
                    "pnl": round(sum(v), 2), "pf": round(gp / gl, 2) if gl else None,
                    "off": by == "strategy" and k in off})
    out.sort(key=lambda r: r["pnl"])
    tot = [float(r.get("pnl") or 0) for r in rows]
    return clean({"items": out, "by": by, "days": days, "mode": want or "ALL", "trades": len(rows), "pnl": round(sum(tot), 2),
                  "off": sorted(off), "note": "" if rows else "No closed trades in this period yet."})


class StratOff(BaseModel):
    name: str
    off: bool = True


@app.post("/api/strategy/off")
def strategy_off(r: StratOff):
    """Switch one strategy off (or back on). The daily loss limit is untouched."""
    e = need_engine()
    name = r.name.split("@")[0].strip().upper()
    if not name.replace("_", "").isalnum():
        raise HTTPException(400, "Bad strategy name")
    cur = [x for x in (settings.strategy_off or []) if x != name]
    if r.off:
        cur.append(name)
    settings.strategy_off = sorted(cur)
    settings.save()
    e.event(f"Strategy {name} switched {'OFF' if r.off else 'back ON'} in the Scorecard", "info")
    return {"ok": True, "off": settings.strategy_off}


_prep_cache = {"at": 0.0, "items": [], "asof": ""}


@app.get("/api/prep/morning")
def prep_morning(force: int = 0):
    """Real-data prep for the open: gap vs the last close, trend vs the 20-day average, distance to the 20-day high,
    ATR and volume for the watchlist + shortlist + movers. Display only, it never trades. Cached 60 s."""
    import time as _tm
    e = need_engine()
    if not force and _tm.time() - _prep_cache["at"] < 60 and _prep_cache["items"]:
        return clean({"items": _prep_cache["items"], "asof": _prep_cache["asof"], "session": _prep_cache.get("sess", "")})
    if not hasattr(e.broker, "_daily_stats"):
        return clean({"items": [], "asof": "", "note": "Real data only (not in the simulator)"})
    syms = list(dict.fromkeys([w.upper() for w in settings.watchlist]
                              + [str(r.get("symbol", "")).upper() for r in (e.shortlist or [])]
                              + [str(m.get("symbol", "")).upper() for m in (e.movers or [])]))
    syms = [s for s in syms if s and s.replace(".", "").isalpha()][:36]
    sess = _session_name(e)
    try:
        st = e.broker._daily_stats(syms)
    except Exception as ex:
        raise HTTPException(502, f"Daily data failed: {str(ex)[:140]}")
    rows = []
    for s in syms:
        d = st.get(s)
        if not d:
            continue
        pr = _price(e, s, sess)
        px = pr.get("last")
        if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or px is None):
            px = (pr["bid"] + pr["ask"]) / 2
        if not px or not d.get("prev_close"):
            continue
        pc, sma, hi, lo, atr = d["prev_close"], d["sma20"], d["hi20"], d["lo20"], d["atr"]
        gap = (px / pc - 1) * 100
        vs_sma = (px / sma - 1) * 100
        to_hi = (px / hi - 1) * 100
        rng = (px - lo) / (hi - lo) * 100 if hi > lo else 50
        atr_pct = atr / px * 100 if px else 0
        score = (1 if px > sma else -1) + (1 if to_hi > -3 else 0) + max(-1.5, min(1.5, gap / 2)) + (0.5 if px > hi else 0)
        tags = []
        if px > hi:
            tags.append("NEW 20D HIGH")
        if px > sma and gap >= 1:
            tags.append("TREND LONG")
        elif px < sma and gap <= -1:
            tags.append("TREND SHORT")
        if px > sma and to_hi > -3 and "NEW 20D HIGH" not in tags:
            tags.append("NEAR HIGH")
        if px > sma and -1 < gap < 1 and "TREND LONG" not in tags:
            tags.append("LONG WATCH")
        if px < sma and gap > 1:
            tags.append("BOUNCE (below avg)")
        rows.append({"symbol": s, "price": round(px, 2), "prev_close": round(pc, 2), "gap": round(gap, 2),
                     "vs_sma20": round(vs_sma, 2), "to_hi20": round(to_hi, 2), "range_pos": round(rng),
                     "atr_pct": round(atr_pct, 2), "adv": int(d.get("adv") or 0), "score": round(score, 2), "tags": tags})
    rows.sort(key=lambda r: -r["score"])
    asof = e.broker.now().strftime("%a %I:%M %p").replace(" 0", " ")
    _prep_cache.update(at=_tm.time(), items=rows, asof=asof, sess=sess)
    return clean({"items": rows, "asof": asof, "session": sess})


_px_cache = {"at": 0.0, "key": "", "items": {}}


@app.get("/api/manual/prices")
def manual_prices(symbols: str = ""):
    """Last price and % change for a handful of tickers (trade pad chips). Cached 4 s."""
    import time as _tm
    e = need_engine()
    syms = []
    for s in symbols.replace(" ", "").upper().split(","):
        if s and s not in syms:
            try:
                syms.append(_valid_sym(s))
            except Exception:
                pass
    syms = syms[:40]
    key = ",".join(syms)
    if _tm.time() - _px_cache["at"] < 4 and _px_cache["key"] == key:
        return clean({"items": _px_cache["items"], "session": _px_cache.get("sess", "")})
    sess = _session_name(e)
    out = {}
    for s in syms:
        try:
            pr = _price(e, s, sess)
            last, pc = pr.get("last"), pr.get("prev_close")
            if pr.get("bid") and pr.get("ask") and (sess != "REGULAR" or last is None):
                last = (pr["bid"] + pr["ask"]) / 2        # nights/extended: the last trade can be hours old
            if last:
                out[s] = {"last": last, "pct": ((last / pc - 1) * 100) if pc else None}
        except Exception:
            continue
    _px_cache.update(at=_tm.time(), key=key, items=out, sess=sess)
    return clean({"items": out, "session": sess})


@app.get("/api/manual/levels/{symbol}")
def manual_levels(symbol: str, side: str = "buy", entry: float | None = None):
    """Suggested stop-loss / take-profit (Scalp / Day / Swing) for a manual order."""
    from autobot.levelsuggest import suggest
    e = need_engine()
    sym = _valid_sym(symbol)
    side = "sell" if side.lower() == "sell" else "buy"
    try:
        df, as_of = e.broker.analysis_bars(sym)
    except Exception as ex:
        raise HTTPException(400, f"Couldn't load bars for {sym}: {str(ex)[:160]}")
    if df is None or len(df) < 20:
        raise HTTPException(400, f"Not enough recent data for {sym} to suggest levels yet.")
    if not entry:
        sess = _session_name(e)
        pr = _price(e, sym, sess)
        if sess == "REGULAR" and pr.get("bid"):
            entry = pr["ask"] if side == "buy" else pr["bid"]
        else:                                   # closed / extended: Alpaca prices brackets off the last trade
            entry = pr.get("last") or float(df["close"].iloc[-1])
    daily = None
    if hasattr(e.broker, "_daily_stats"):
        try:
            daily = e.broker._daily_stats([sym]).get(sym)
        except Exception:
            daily = None
    bias = "NEUTRAL"
    try:
        bias = analyze(sym, df, e.bias, learner).get("bias", "NEUTRAL")
    except Exception:
        pass
    acct = e.acct or {}
    res = suggest(side, float(entry), df, daily, bias, settings.daily_max_loss, settings.risk_per_trade_frac,
                  acct.get("buying_power", 0))
    res.update(symbol=sym, as_of=as_of)
    return clean(res)


def _friendly_reject(msg: str) -> str:
    """Turn Alpaca's JSON errors into plain words (the raw text stays in the log)."""
    import json as _j
    logging.warning("Order rejected: %s", msg)
    d = {}
    try:
        d = _j.loads(msg[msg.index("{"):])
        m = d.get("message", msg)
    except Exception:
        m = msg
    low = m.lower()
    if "stop_loss.stop_price must be" in low:
        return f"Stop-loss is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the stop."
    if "take_profit.limit_price must be" in low:
        return f"Take-profit is on the wrong side of Alpaca's reference price ({d.get('base_price', '?')}). Tap Suggest again or move the target."
    if "insufficient buying power" in low:
        return "Not enough buying power for this order. Lower the quantity."
    if "not shortable" in low or "cannot be sold short" in low:
        return "This stock can't be shorted right now."
    if "extended hours" in low:
        return "This order type isn't allowed in extended hours. Use a limit order."
    if "margin call" in low or "intraday" in low:
        return "Not enough intraday buying power (Alpaca's intraday margin rules). Use a smaller size or close something first."
    if "pattern day" in low or "day trad" in low:
        return "Blocked by a broker trading restriction. (The old $25k day-trade rule ended June 4, 2026; if you still see this, contact Alpaca.)"
    return "Alpaca rejected the order: " + m[:220]


class ManualOrder(BaseModel):
    symbol: str
    side: str                       # buy | sell
    qty: float = 0
    dollars: float = 0              # alternative to qty: spend about this much
    order_type: str = "market"      # market | limit | stop | stop_limit | trailing_stop
    limit_price: float | None = None
    stop_price: float | None = None     # trigger for stop / stop_limit
    trail_percent: float | None = None  # trailing_stop: trail by % ...
    trail_price: float | None = None    # ... or by $
    tif: str = "day"                # day | gtc | ioc | fok | opg | cls
    session: str = "auto"           # regular | extended | 24h | auto (= the session open now)
    stop: float | None = None       # optional stop-loss leg (regular hours, market/limit)
    target: float | None = None     # optional take-profit leg (regular hours, market/limit)
    confirm_short: bool = False
    harvest: bool = False           # ♻ auto-harvest: bank a small gain, then re-enter on a pullback


SESSION_LABEL = {"regular": "Market hours", "extended": "Extended hours", "24h": "24 Hour Market"}
TIF_LABEL = {"day": "Good for day", "gtc": "Good 'til canceled", "ioc": "Immediate or cancel",
             "fok": "Fill or kill", "opg": "At the open", "cls": "At the close"}


@app.post("/api/manual/order")
def manual_order(r: ManualOrder):
    import math
    import uuid
    e = need_engine()
    sym, side = _valid_sym(r.symbol), r.side.lower()
    ot, tif = r.order_type.lower(), r.tif.lower()
    if side not in ("buy", "sell"):
        raise HTTPException(400, "Side must be buy or sell")
    if ot not in ("market", "limit", "stop", "stop_limit", "trailing_stop"):
        raise HTTPException(400, "Unknown order type")
    if tif not in TIF_LABEL:
        raise HTTPException(400, "Unknown time in force")
    if sym in e.trades:
        raise HTTPException(409, f"The bot is managing {sym}. Close it first (Positions → Close) or wait for the bot's exit.")
    now_sess = _session_name(e)
    sess = r.session.lower()
    if sess == "auto":
        sess = {"PRE": "extended", "AFTER": "extended", "OVERNIGHT": "24h"}.get(now_sess, "regular")
    if sess not in SESSION_LABEL:
        raise HTTPException(400, "Unknown trading session")
    ext = sess != "regular"

    # ---- the rules Alpaca applies, checked here first so the message is clear ----
    if ext and ot != "limit":
        raise HTTPException(400, f"{SESSION_LABEL[sess]} accepts limit orders only. Switch the order type to Limit.")
    if ext and tif not in ("day", "gtc"):
        raise HTTPException(400, f"{SESSION_LABEL[sess]} orders must be Good for day or Good 'til canceled.")
    if tif in ("opg", "cls") and ot not in ("market", "limit"):
        raise HTTPException(400, "At the open / At the close work with market or limit orders only.")
    if ot == "trailing_stop" and tif not in ("day", "gtc"):
        raise HTTPException(400, "Trailing stops must be Good for day or Good 'til canceled.")
    legs = bool(r.stop or r.target)
    if legs and (ext or ot not in ("market", "limit") or tif not in ("day", "gtc")):
        raise HTTPException(400, "Stop-loss / take-profit can only be attached to a market or limit order, "
                                 "in Market hours, Good for day or Good 'til canceled.")

    bid, ask = _quote(e, sym, now_sess)
    ref = ask if side == "buy" else bid
    if ot in ("limit", "stop_limit"):
        if not r.limit_price or r.limit_price <= 0:
            raise HTTPException(400, "Enter a limit price")
        ref = r.limit_price
    if ot in ("stop", "stop_limit"):
        if not r.stop_price or r.stop_price <= 0:
            raise HTTPException(400, "Enter a stop price")
        ref = ref if ot == "stop_limit" else r.stop_price
    if ot == "trailing_stop":
        if not (r.trail_percent or r.trail_price) or (r.trail_percent or 0) < 0 or (r.trail_price or 0) < 0:
            raise HTTPException(400, "Enter a trail amount (% or $)")
    if not ref:
        raise HTTPException(400, f"No price available for {sym} right now")
    qty = math.floor(r.qty) if r.qty else (math.floor(r.dollars / ref) if r.dollars else 0)
    if qty < 1:
        raise HTTPException(400, "Enter at least 1 share (or a dollar amount worth at least 1 share)")

    held = (e.broker.positions().get(sym) or {}).get("qty", 0)
    if side == "sell" and held < qty and not r.confirm_short:
        raise HTTPException(409, "SHORT_CONFIRM")
    d = 1 if side == "buy" else -1
    if r.stop and (ref - r.stop) * d <= 0:
        raise HTTPException(400, f"Stop-loss must be {'below' if d > 0 else 'above'} the entry price ({ref:.2f})")
    if r.target and (r.target - ref) * d <= 0:
        raise HTTPException(400, f"Take-profit must be {'above' if d > 0 else 'below'} the entry price ({ref:.2f})")

    notes = []
    open_now = {"regular": now_sess == "REGULAR", "extended": now_sess in ("PRE", "REGULAR", "AFTER"),
                "24h": now_sess != "CLOSED"}[sess]
    if sess == "24h" and tif == "day" and now_sess != "OVERNIGHT":
        notes.append("Good for day ends at 8 PM ET today. Choose Good 'til canceled to keep it working overnight.")
    if not open_now and tif not in ("opg", "cls"):
        notes.append(f"{SESSION_LABEL[sess]} isn't open right now: the order waits and works from the start of the next session.")
    try:
        if (side == "buy" and held >= 0) or (side == "sell" and held <= 0):
            _b, _a = _quote(e, sym, sess)
            if _b and _a and _a > _b and settings.max_spread_pct and (_a - _b) / ((_a + _b) / 2) * 100 > settings.max_spread_pct:
                _sp = (_a - _b) / ((_a + _b) / 2) * 100
                notes.append(f"Heads-up: {sym}'s spread is {_sp:.2f}% (bid {_b:.2f} / ask {_a:.2f}). A market order starts about "
                             f"${(_a - _b) / 2 * qty:,.0f} under water and the exit pays the same again. A limit near the middle does better.")
    except Exception:
        pass
    try:
        _eq = float(getattr(e.risk, "equity", 0) or 0)
        _cap = float(getattr(settings, "max_position_pct_equity", 0.15) or 0.15)
        if _eq > 0 and ref and qty * ref > max(2 * _cap, 0.30) * _eq and ((side == "buy" and held >= 0) or (side == "sell" and held <= 0)):
            notes.append(f"Heads-up: this is ${qty * ref:,.0f}, {qty * ref / _eq * 100:.0f}% of your equity. The bot never puts more than "
                         f"{_cap * 100:.0f}% in one trade. Your biggest losses so far were large hand-sized positions.")
    except Exception:
        pass
    try:
        oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=r.stop or None,
                                    target=r.target or None, extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                    stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                    trail_price=r.trail_price or None, tif=tif)
    except Exception as ex:
        import re
        msg = str(ex)
        m = re.search(r'"base_price"\s*:\s*"?([0-9.]+)', msg)
        if m and (r.stop or r.target):
            # Alpaca checks the stop/target against its reference price (the last trade while closed).
            # Keep the same distances, re-anchor them on that price, and try once more.
            base = float(m.group(1))
            ref = r.limit_price if (ot == "limit" and r.limit_price) else base
            shift = base - (bid if side == "sell" else ask) if ot != "limit" else 0
            new_stop = round(r.stop + shift, 2) if r.stop else None
            new_tgt = round(r.target + shift, 2) if r.target else None
            if new_stop and (ref - new_stop) * (1 if side == "buy" else -1) < 0.01:
                new_stop = round(ref - (0.01 if side == "buy" else -0.01) - abs(r.stop - (ask if side == "buy" else bid)) * (1 if side == "buy" else -1), 2)
            try:
                oid = e.broker.manual_order(sym, side, qty, ot, limit_price=r.limit_price, stop=new_stop, target=new_tgt,
                                            extended=ext, client_id=f"man-{uuid.uuid4().hex[:12]}",
                                            stop_price=r.stop_price, trail_percent=r.trail_percent or None,
                                            trail_price=r.trail_price or None, tif=tif)
                notes.append(f"Auto-fixed: Alpaca prices this order from {base:.2f}, so the stop-loss / take-profit were "
                             f"moved by the same amount to {new_stop or '—'} / {new_tgt or '—'}.")
                r.stop, r.target = new_stop, new_tgt
            except Exception as ex2:
                raise HTTPException(400, _friendly_reject(str(ex2)))
        else:
            raise HTTPException(400, _friendly_reject(msg))
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    px = {"market": "market", "limit": f"limit {r.limit_price:.2f}" if r.limit_price else "limit",
          "stop": f"stop {r.stop_price}", "stop_limit": f"stop {r.stop_price} limit {r.limit_price}",
          "trailing_stop": f"trailing {str(r.trail_percent) + '%' if r.trail_percent else '$' + str(r.trail_price)}"}[ot]
    extra = " ".join(x for x in (f"SL {r.stop:.2f}" if r.stop else "", f"TP {r.target:.2f}" if r.target else "") if x)
    if r.harvest:
        if ot not in ("market", "limit"):
            notes.append("Auto-harvest works with market or limit orders, so it was not turned on for this one.")
        elif (side == "buy" and held >= 0) or (side == "sell" and held <= 0):
            harvester.arm(sym, side, qty)
            notes.append("♻ Auto-harvest is ON: it banks a small gain, then re-enters on a pullback, until you tap Stop."
                         + (" It replaces the stop-loss / take-profit you attached with its own protective stop." if legs else ""))
        else:
            notes.append("Auto-harvest only works on an order that opens a position, not one that closes it.")
    e.event(f"MANUAL {side.upper()} {qty} {sym} {px} · {TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}")
    e.alert("manual", f"You: {side.upper()} {qty} {sym} {px}", f"{TIF_LABEL[tif]} · {SESSION_LABEL[sess]}{' · ' + extra if extra else ''}",
            symbol=sym, close_btn=True)
    return {"ok": True, "order_id": oid, "qty": qty, "notes": notes}


class ManualClose(BaseModel):
    symbol: str
    pct: float = 100
    urgent: bool = False            # True = take the bid/ask right now (no patient ladder)


def _remember_close(e, sym, side, qty, hv):
    """Keep the last manual close so one tap can reopen it."""
    import json
    e.last_close = {"symbol": sym, "side": side, "qty": float(qty), "hv": bool(hv),
                    "at": e.broker.now().strftime("%H:%M")}
    try:
        (DATA_DIR / "last_close.json").write_text(json.dumps(e.last_close))
    except Exception:
        pass


def _last_close(e):
    import json
    lc = getattr(e, "last_close", None)
    if lc is None:
        try:
            lc = json.loads((DATA_DIR / "last_close.json").read_text())
            e.last_close = lc
        except Exception:
            lc = None
    return lc


@app.post("/api/manual/reopen")
def manual_reopen():
    """One tap, no confirmation: put back the position you last closed by hand (same stock, side and size)."""
    import uuid
    e = need_engine()
    lc = _last_close(e)
    if not lc:
        raise HTTPException(404, "Nothing to reopen yet: close a position first.")
    sym, side, qty = lc["symbol"], lc["side"], int(lc["qty"])
    if sym in e.trades:
        raise HTTPException(409, f"The bot is managing {sym} right now.")
    sess = _session_name(e)
    if sess == "CLOSED":
        raise HTTPException(400, "The market is closed. Reopen it when a session is open.")
    bid, ask = _quote(e, sym, sess)
    if not bid or not ask:
        raise HTTPException(400, f"No {sym} quote right now")
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    if sess == "OVERNIGHT" and side == "sell":
        raise HTTPException(400, "Shorting isn't available overnight.")
    held = (e.broker.positions().get(sym) or {}).get("qty", 0)
    if held * (1 if side == "buy" else -1) > 0:
        raise HTTPException(409, f"You already hold {sym}.")
    try:
        if ext:
            px = round(ask * 1.002, 2) if side == "buy" else round(bid * 0.998, 2)
            e.broker.manual_order(sym, side, qty, "limit", limit_price=px, extended=True,
                                  client_id=f"man-{uuid.uuid4().hex[:12]}", tif="day")
        else:
            e.broker.manual_order(sym, side, qty, "market", client_id=f"man-{uuid.uuid4().hex[:12]}")
    except Exception as ex:
        raise HTTPException(400, _friendly_reject(str(ex)))
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    note = ""
    if lc.get("hv"):
        harvester.arm(sym, side, qty)
        note = " · ♻ auto-harvest back ON"
    e.event(f"MANUAL REOPEN {side.upper()} {qty} {sym} (repeat of your {lc['at']} close){note}")
    e.alert("manual", f"You: reopened {side.upper()} {qty} {sym}", "One-tap reopen of your last close" + note, symbol=sym, close_btn=True)
    return {"ok": True, "symbol": sym, "qty": qty, "side": side}


@app.post("/api/manual/close")
def manual_close(r: ManualClose):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    res = _close_now(e, sym, r.pct, urgent=r.urgent)
    if r.pct >= 100:
        closeplans.cancel(sym)               # closed by hand: any ⏰ plan for it is done
    return res


def _close_now(e, sym, pct=100, urgent=True):
    """Close all (pct=100) or part of a position right now, the right way for the session.
    urgent=False (the Close button) uses the patient ladder when the spread is wide, to keep a win a win."""
    import math
    import uuid
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    q = abs(pos["qty"])
    qty = q if pct >= 100 else max(1, math.floor(q * pct / 100))
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    t = e.trades.get(sym)
    if t is not None and t.status != "open":
        t = None                            # a finished bot trade must not hijack a manual close
    if t:                                   # a bot trade: close it the bot's way so the journal/learner stay right
        if qty < q:
            raise HTTPException(400, "Bot trades can only be closed in full")
        t.note = "manual close"
        if ext and t.ext:
            bid, ask = _quote(e, sym, sess)
            ref = ask if t.dir < 0 else bid          # a short is covered at the ask, a long sold at the bid
            again = bool(t.exit_order_id)            # a second tap while the first order is still working = take the market now
            t.exit_order_id = ""                     # a new tap re-prices an exit that hasn't filled
            e._ext_exit(t, "manual close (now)" if again else "manual close", ref or t.last_price or t.entry)
            if again:
                e.event(f"Second tap on {sym}: taking the market price now")
            e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy})")
            return {"ok": True, "qty": qty, "notes": ["Extended hours: sent a limit order to close the bot's trade. "
                                                      "The bot re-prices it every 20 seconds until it fills."]}
        if not ext:
            if e.broker.close_position(sym) is False:
                raise HTTPException(400, "Alpaca rejected the close: " + (getattr(e.broker, "last_close_error", "") or "unknown")[:220])
            e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy})")
            return {"ok": True, "qty": qty, "notes": []}
        # a bot trade opened in regular hours but still open after hours: close it with a limit order below
        e.event(f"MANUAL CLOSE of bot trade {sym} ({t.strategy}) - extended-hours limit")
    notes = []
    if not t:
        w = _walkers.get(sym)
        if w:
            w["urgent"] = True                        # tapping Close again = stop waiting, take the price now
            notes.append("Taking the bid/ask now (second tap).")
            return {"ok": True, "qty": qty, "notes": notes}
        if not urgent:
            walk = _start_smart_close(e, sym, qty, pos["qty"] < 0, sess, ext)
            if walk:
                _remember_close(e, sym, "buy" if pos["qty"] > 0 else "sell", qty, harvester.jobs.get(sym) is not None)
                if qty >= q and sym in harvester.jobs:
                    harvester.stop(sym, "you closed the position")
                e.event(f"MANUAL CLOSE {qty:g} {sym} (patient: " + walk + ")")
                return {"ok": True, "qty": qty, "notes": [
                    "The spread is wide, so the bot is working the order from the better side toward the market over about a minute "
                    "to keep more of your gain. Tap Close again to take the market price right now."]}
    try:
        if ext:
            # Outside regular hours Alpaca only takes LIMIT orders marked extended-hours - for a long
            # (sell) AND for a short (buy to cover). Price a little through the quote so it fills.
            e.broker.cancel_symbol_orders(sym)
            import time as _tm
            _tm.sleep(0.4)
            bid, ask = _quote(e, sym, sess)
            short = pos["qty"] < 0
            ref = ask if short else bid
            if not ref:
                ref = pos.get("price")                   # no live quote: price off the position's last price
            if not ref:
                raise HTTPException(400, f"No {sym} quote right now - try again in a few seconds")
            px = round(ref * (1.003 if short else 0.997), 2)
            e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit", limit_price=px, extended=True,
                                  client_id=f"manx-{uuid.uuid4().hex[:12]}")
            notes.append(f"Extended hours: sent a limit {'buy to cover' if short else 'sell'} of {qty:g} {sym} at {px:.2f}. "
                         "If it hasn't filled in a minute, press Close again (it re-prices at the new quote).")
        else:
            e.broker.close_qty(sym, qty)
            if qty < q:
                notes.append("Any stop-loss / take-profit on this position was cancelled - set new ones if you want them.")
            if sess == "CLOSED":
                notes.append("The market is closed: it will close at the open.")
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(400, f"Alpaca rejected the close: {str(ex)[:220]}")
    _remember_close(e, sym, "buy" if pos["qty"] > 0 else "sell", qty, harvester.jobs.get(sym) is not None)
    if qty >= q and sym in harvester.jobs:   # a full close you asked for: auto-harvest must not buy back in
        harvester.stop(sym, "you closed the position")
        notes.append("♻ Auto-harvest turned off for " + sym + ".")
    e.event(f"MANUAL CLOSE {qty:g} {sym}" + (" (partial)" if qty < q else ""))
    return {"ok": True, "qty": qty, "notes": notes}


_walkers: dict = {}
WALK_MIN_SPREAD_PCT = 0.04          # spreads tighter than this are not worth being patient over
WALK_STEPS = (0.75, 0.5, 0.25)      # start near the favourable side, then walk toward the market, then take it
WALK_SECS_EXT, WALK_SECS_REG = 14, 6


def _start_smart_close(e, sym, qty, short, sess, ext):
    """Patient exit for a manual close. Returns a short description if a walker started, else '' (use the urgent path)."""
    bid, ask = _quote(e, sym, sess)
    if not bid or not ask or ask <= bid:
        return ""
    spr = ask - bid
    if spr / ((bid + ask) / 2) * 100 < WALK_MIN_SPREAD_PCT:
        return ""
    import threading
    import uuid
    w = _walkers[sym] = {"urgent": False}
    step_secs = WALK_SECS_EXT if ext else WALK_SECS_REG

    def flat():
        p = e.broker.positions().get(sym)
        return (not p) or abs(p["qty"]) <= (abs(pos0) - qty) + 1e-6

    pos0 = (e.broker.positions().get(sym) or {"qty": qty})["qty"]

    def run():
        try:
            start_ref = None
            for f in WALK_STEPS:
                if w["urgent"]:
                    break
                b, a = _quote(e, sym, sess)
                if not b or not a or a <= b:
                    break
                ref = a if short else b
                start_ref = start_ref or ref
                if abs(ref - start_ref) > 1.0 * spr and (ref > start_ref if short else ref < start_ref):
                    break                                   # price is running away from us: stop being patient
                px = round(b + f * (a - b), 2) if not short else round(a - f * (a - b), 2)
                px = max(px, b) if not short else min(px, a)
                e.broker.cancel_symbol_orders(sym)
                time_sleep(0.3)
                e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit", limit_price=px, extended=ext,
                                      client_id=f"manw-{uuid.uuid4().hex[:12]}")
                end = time_mod.time() + step_secs
                while time_mod.time() < end and not w["urgent"]:
                    time_sleep(1.0)
                    if flat():
                        e.event(f"Patient close of {sym} filled at about {px:.2f}")
                        return
            if flat():
                return
            e.broker.cancel_symbol_orders(sym)
            time_sleep(0.4)
            b, a = _quote(e, sym, sess)
            if ext:
                ref = (a if short else b) or (e.broker.positions().get(sym) or {}).get("price")
                if ref:
                    e.broker.manual_order(sym, "buy" if short else "sell", qty, "limit",
                                          limit_price=round(ref * (1.003 if short else 0.997), 2), extended=True,
                                          client_id=f"manx-{uuid.uuid4().hex[:12]}")
            else:
                e.broker.close_qty(sym, qty)
        except Exception as ex:
            e.event(f"Patient close of {sym} failed ({str(ex)[:100]}); closing at the market", "warning")
            try:
                e.broker.cancel_symbol_orders(sym)
                if not ext:
                    e.broker.close_qty(sym, qty)
            except Exception:
                pass
        finally:
            _walkers.pop(sym, None)

    threading.Thread(target=run, daemon=True, name=f"walk-{sym}").start()
    return f"spread {spr / ((bid + ask) / 2) * 100:.2f}%"


@app.get("/api/manual/book")
def manual_book():
    """Every position and open order in the account, marked bot or manual."""
    e = need_engine()
    pos = e.broker.positions()
    try:
        orders = e.broker.open_orders()
    except Exception:
        orders = []
    bot_ids = {t.order_id for t in e.trades.values()} | {t.tp_order_id for t in e.trades.values()} | \
              {t.exit_order_id for t in e.trades.values()}
    plans = {p["symbol"]: p for p in closeplans.list()}
    rows = [{"symbol": s, "qty": p["qty"], "avg": p["avg_entry"], "price": p["price"], "upl": p["upl"], "plan": plans.get(s),
             "upl_pct": (p["price"] / p["avg_entry"] - 1) * 100 * (1 if p["qty"] > 0 else -1) if p["avg_entry"] else 0,
             "bot": s in e.trades, "hv": s in harvester.jobs} for s, p in sorted(pos.items())]
    try:                                    # what closing right now would really fill at: bid for longs, ask for shorts
        qs = e.broker.quotes([r["symbol"] for r in rows], _session_name(e)) or {}
        for r in rows:
            q = qs.get(r["symbol"])
            if q and q[0] and q[1]:
                xp = q[0] if r["qty"] > 0 else q[1]
                r["exit_px"] = xp
                r["exit_upl"] = round((xp - r["avg"]) * r["qty"], 2)
    except Exception:
        pass
    for o in orders:
        o["bot"] = o["id"] in bot_ids or o["client_id"].startswith(("ab-", "abx-", "abt-", "abe-")) or o["symbol"] in e.trades
    return clean({"positions": rows, "orders": orders, "session": _session_name(e), "mode": e.mode,
                  "harvest": harvester.status(), "last_close": _last_close(e)})


# ---------------- ♻ auto-harvest (manual trades) ----------------
def _hv_open(e, sym, side, qty, sess, bid, ask, tries):
    import uuid
    cid = f"manh-{uuid.uuid4().hex[:12]}"
    try:                                     # a re-entry must fit today's buying power: shrink instead of being rejected
        bp = float(e.broker.account().get("buying_power", 0) or 0)
        ref = ask if side == "buy" else bid
        if bp > 0 and ref:
            qty = max(1, min(int(qty), int(0.95 * bp / ref)))
    except Exception:
        pass
    if sess in ("PRE", "AFTER", "OVERNIGHT"):
        px = round(ask * (1 + 0.001 * tries), 2) if side == "buy" else round(bid * (1 - 0.001 * tries), 2)
        e.broker.manual_order(sym, side, qty, "limit", limit_price=px, extended=True, client_id=cid, tif="day")
    else:
        e.broker.manual_order(sym, side, qty, "market", client_id=cid)


def _hv_close(e, sym, qty, side, sess, bid, ask, tries):
    import uuid
    if sess in ("PRE", "AFTER", "OVERNIGHT"):
        e.broker.cancel_symbol_orders(sym)
        cid = f"manh-{uuid.uuid4().hex[:12]}"
        if side == "buy":
            e.broker.manual_order(sym, "sell", qty, "limit", limit_price=round(bid * (1 - 0.002 * tries), 2), extended=True, client_id=cid, tif="day")
        else:
            e.broker.manual_order(sym, "buy", qty, "limit", limit_price=round(ask * (1 + 0.002 * tries), 2), extended=True, client_id=cid, tif="day")
    else:
        e.broker.close_qty(sym, qty)


def _plan_alert(kind, title, body, sym, speak):
    try:
        alerts.send(kind, title, body, symbol=sym, speak=speak)
    except Exception:
        pass


def _plan_close(e, sym):
    return _close_now(e, sym, 100).get("notes", [])


from autobot.closeplan import ClosePlans  # noqa: E402
closeplans = ClosePlans(lambda: engine, _plan_close, _session_name, lambda e, sym, sess: _quote(e, sym, sess),
                        _plan_alert, DATA_DIR / "close_plans.json")


def _guard_flip(e, sym, pos, why):
    """Guard 'flip' mode: reverse a manual position in ONE order (sell 2x a long = close it and open a same-size short,
    and the reverse for a short). Raises with the reason when it can't, and the guard then just closes."""
    import math
    import uuid
    from autobot.sessions import bot_day
    q = abs(pos["qty"])
    long_ = pos["qty"] > 0
    side = "sell" if long_ else "buy"
    sess = _session_name(e)
    ext = sess in ("PRE", "AFTER", "OVERNIGHT")
    now = e.broker.now()
    if e.risk.remaining <= 0 or e.risk.halted:
        raise RuntimeError("the daily loss limit is used up, so no new position")
    if long_:                                   # flipping to a short: same gates as the bot's own shorts
        if not (e.shorts_allowed(now) and e.acct.get("shorting_enabled", True)):
            raise RuntimeError("shorts aren't allowed right now (the 7 AM rule or the shorts switch)")
        if sess == "OVERNIGHT" and not getattr(settings, "shorts_24_5", False):
            raise RuntimeError("overnight shorting is off")
        ok, why2 = e._can_short(sym)
        if not ok:
            raise RuntimeError(why2)
    bid, ask = _quote(e, sym, sess)
    ref = bid if long_ else ask
    px = ref or pos.get("price")
    if not px:
        raise RuntimeError("no live price")
    eq = float(getattr(e.risk, "equity", 0) or 0)
    new_qty = q if eq <= 0 else min(q, math.floor(0.30 * eq / px))
    if new_qty < 1:
        raise RuntimeError("too small to flip")
    e.broker.cancel_symbol_orders(sym)
    total = int(q + new_qty)
    cid = f"man-flip-{uuid.uuid4().hex[:10]}"
    if ext:
        lim = round(px * (0.999 if long_ else 1.001), 2)
        e.broker.manual_order(sym, side, total, "limit", limit_price=lim, extended=True, client_id=cid, tif="day")
    else:
        e.broker.manual_order(sym, side, total, "market", client_id=cid, tif="day")
    e.manual_syms[sym] = bot_day(now)
    hv = ""
    if getattr(settings, "guard_flip_harvest", True):
        harvester.arm(sym, "sell" if long_ else "buy", new_qty, note="flipped: waiting for the reversal to fill")
        harvester.jobs[sym]["flip"] = True                  # the guard keeps watching it, so it can flip again
        hv = " Auto-harvest is armed on the new position: it banks quick gains and re-enters while the trend holds."
    return (f"{'Sold' if long_ else 'Bought'} {total:,} to close {q:,.0f} and open a {new_qty:,} "
            f"{'short' if long_ else 'long'}" + (" (limit order, extended hours: it may take a moment to fill)" if ext else "") + "." + hv)


def _guard_close(e, sym):
    harvester.stop(sym, "the guard closed it")
    return _plan_close(e, sym)


def _guard_skip(e, sym):
    j = harvester.jobs.get(sym)
    if j and not (j.get("flip") and j.get("phase") in ("holding", "waiting", "entering")):
        return True                          # a normal harvest job, or a flipped one still waiting to fill, manages itself
    return sym in e.trades or any(p["symbol"] == sym for p in closeplans.list())


from autobot.guard_manual import ManualGuard  # noqa: E402
guard = ManualGuard(lambda: engine, lambda: settings, _session_name, lambda e, sym, sess: _quote(e, sym, sess),
                    _guard_close, _plan_alert,
                    _guard_skip,
                    _guard_flip)


class ClosePlanReq(BaseModel):
    symbol: str
    at: str | None = None          # ISO time in New York, e.g. 2026-09-30T04:00
    on_flip: bool = False
    tp: float | None = None
    sl: float | None = None


@app.get("/api/closeplan")
def closeplan_list():
    return {"plans": closeplans.list()}


@app.post("/api/closeplan")
def closeplan_set(r: ClosePlanReq):
    e = need_engine()
    sym = _valid_sym(r.symbol)
    pos = e.broker.positions().get(sym)
    if not pos:
        raise HTTPException(404, f"No open {sym} position")
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym} and closes it itself. Use Close to take it now.")
    d = 1 if pos["qty"] > 0 else -1
    if r.tp and pos.get("price") and (r.tp - pos["price"]) * d <= 0:
        raise HTTPException(400, f"Take-profit must be {'above' if d > 0 else 'below'} the current price {pos['price']:.2f}")
    if r.sl and pos.get("price") and (r.sl - pos["price"]) * d >= 0:
        raise HTTPException(400, f"Stop must be {'below' if d > 0 else 'above'} the current price {pos['price']:.2f}")
    if r.at:
        from datetime import datetime as _dt
        try:
            when = _dt.fromisoformat(r.at)
        except ValueError:
            raise HTTPException(400, "Pick a valid time")
        when = when if when.tzinfo else when.replace(tzinfo=NY)
        if when <= e.broker.now():
            raise HTTPException(400, "That time has already passed - pick a later time")
    try:
        p = closeplans.set(sym, d, r.at, r.on_flip, r.tp, r.sl)
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if sym in harvester.jobs:
        harvester.stop(sym, "a ⏰ close plan now manages this position")
    e.event(f"⏰ {sym}: {p['msg']}")
    return {"ok": True, "plan": p}


@app.post("/api/closeplan/cancel")
def closeplan_cancel(r: ManualClose):
    sym = _valid_sym(r.symbol)
    closeplans.cancel(sym)
    return {"ok": True}


harvester = Harvester(lambda: engine, lambda e, sym, sess: _quote(e, sym, sess), _session_name, _hv_open, _hv_close,
                      DATA_DIR / "harvest.json")


# ---------------- automatic morning / night setup ----------------
def _prep_loop():
    """Every 5 minutes in pre-market and after-hours, build the movers list even when the auto-trader is stopped.
    (While the bot runs it does this itself.) The list is kept overnight, so the night setup is still there in the morning."""
    import time as _t
    from autobot.sessions import current_session
    last = 0.0
    while True:
        _t.sleep(30)
        try:
            e = engine
            if not e or not settings.auto_prep or e.running or ARGS.sim:
                continue
            if _t.time() - last < 300:
                continue
            now = e.broker.now()
            sess = current_session(e.broker.trading_day, now)
            if not sess or sess.name not in ("PRE", "AFTER"):
                continue
            start, end = e._ext_window(sess)
            if not (start <= now < end):
                continue
            last = _t.time()
            n = e.prep_movers(sess)
            if n:
                logging.info("auto-prep: %d movers (%s)", n, sess.name)
        except Exception as ex:
            logging.warning("auto-prep: %s", ex)


_th.Thread(target=_prep_loop, daemon=True, name="prep").start()


def _study_loop():
    """Once the day is over (after 4:30 PM, overnight, weekends) study any completed trading day we have not studied yet."""
    import time as _t
    last = 0.0
    while True:
        _t.sleep(60)
        try:
            e = engine
            if not e or not settings.auto_study or ARGS.sim or _t.time() - last < 3 * 3600:
                continue
            now = e.broker.now()
            if not (now.hour >= 17 or now.hour < 4 or now.weekday() >= 5):
                continue
            last = _t.time()
            try:
                if settings.auto_prep and not e.evening_at.startswith(now.strftime('%a')):
                    e.evening_review()
            except Exception as ex2:
                logging.warning('evening review: %s', ex2)
            r = e.study_night()
            logging.info("overnight study: %s", r.get("note"))
            if settings.session_tune:
                try:
                    run_autotune()
                except Exception as ex4:
                    logging.warning("auto-tune: %s", ex4)
            if settings.pre_auto:
                try:
                    apply_pre_preset("auto")
                except Exception as ex3:
                    logging.warning("pre-market preset: %s", ex3)
        except Exception as ex:
            logging.warning("overnight study: %s", ex)


_th.Thread(target=_study_loop, daemon=True, name="study").start()


def _shortlist_loop():
    """Overnight homework (after 4:35 PM and before 4 AM, once per night) and the morning refresh (8:00-9:25 AM ET,
    every 15 minutes). Runs even when the bot is stopped."""
    import time as _t
    done_night, last_morning = "", 0.0
    while True:
        _t.sleep(60)
        try:
            e = engine
            if not e or ARGS.sim or not (settings.auto_prep or settings.auto_short):
                continue
            now = e.broker.now()
            hm = now.hour * 60 + now.minute
            if now.weekday() < 5 and 8 * 60 <= hm <= 9 * 60 + 25 and _t.time() - last_morning > 900:
                last_morning = _t.time()
                e.refresh_shortlist("morning refresh")
            elif (hm >= 16 * 60 + 35 or hm < 4 * 60) and done_night != now.strftime("%Y-%m-%d") + str(hm >= 16 * 60):
                done_night = now.strftime("%Y-%m-%d") + str(hm >= 16 * 60)
                e.refresh_shortlist("overnight homework")
        except Exception as ex:
            logging.warning("shortlist: %s", ex)


_th.Thread(target=_shortlist_loop, daemon=True, name="shortlist").start()


@app.get("/api/direction/{symbol}")
def direction_call(symbol: str):
    e = need_engine()
    try:
        return clean(e.direction_for(_valid_sym(symbol)))
    except HTTPException:
        raise
    except Exception as ex:
        raise HTTPException(502, f"Couldn't read {symbol}: {str(ex)[:150]}")


class AutoShortReq(BaseModel):
    pin: str = ""
    mode: str = "both"          # both | short | long


@app.post("/api/autoshort/enable")
def autoshort_enable(r: AutoShortReq, request: Request):
    """One tap: turn on the automatic short system for the CURRENT account (PAPER or LIVE) and start the bot.
    LIVE needs the Live PIN again, because this places real orders by itself."""
    global engine
    if engine is None:
        build_engine()
    e = need_engine()
    if settings.live and not ARGS.sim:
        ip = "pin:" + auth.client_ip(request)
        if auth.rate_limited(ip):
            raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
        if not live_pin():
            raise HTTPException(400, "No Live PIN set yet. Add one in ⚙ → Broker keys → Live.")
        if r.pin != live_pin():
            auth.record_fail(ip)
            raise HTTPException(403, "Wrong PIN")
    notes = []
    settings.auto_short, settings.allow_shorts, settings.pre_plan, settings.morning_reversal = True, True, True, True
    settings.auto_mode = r.mode if r.mode in ("both", "short", "long") else "both"
    settings.level, settings.level_auto = "custom", False
    if settings.data_feed == "sip":
        settings.preclose_short = True
        notes.append("late-day overnight shorts on")
    else:
        settings.preclose_short = False
        notes.append("late-day overnight shorts need the SIP feed, so they stay off")
    settings.ext_premarket = settings.ext_afterhours = True
    settings.save()
    try:
        if not ARGS.sim and hasattr(e.broker, "screener"):
            _th.Thread(target=lambda: e.refresh_shortlist("enable"), daemon=True, name="shortlist-now").start()
    except Exception:
        pass
    e.event(f"Automatic system ENABLED ({settings.auto_mode}) on {'LIVE' if settings.live else 'PAPER'}", "warning" if settings.live else "info")
    alerts.send("system", "Automatic system ON", f"{'LIVE' if settings.live else 'PAPER'} account, {settings.auto_mode}. Waits for confirmed 1-minute signals.")
    if not e.running:
        e.start()
    return {"ok": True, "live": settings.live, "notes": notes}


@app.post("/api/autoshort/disable")
def autoshort_disable():
    settings.auto_short = False
    settings.save()
    if engine:
        engine.event("Automatic system OFF (the bot keeps running with your other settings)")
    return {"ok": True}


class ReleaseReq(BaseModel):
    symbol: str = "*"


@app.get("/api/tune")
def tune_get():
    e = need_engine()
    return clean({"enabled": settings.auto_tune, "items": e.tuner.table()})


@app.get("/api/blocks")
def blocks_get():
    e = need_engine()
    return clean({"items": e.blocked_symbols()})


@app.post("/api/blocks/release")
def blocks_release(r: ReleaseReq):
    e = need_engine()
    return {"ok": True, "released": e.release_block(r.symbol)}


@app.get("/api/shortlist")
def shortlist_get():
    e = need_engine()
    return clean({"items": e.shortlist, "at": e.shortlist_at, "auto_short": settings.auto_short, "auto_mode": settings.auto_mode, "live": settings.live})


@app.post("/api/shortlist/refresh")
def shortlist_refresh():
    e = need_engine()
    try:
        n = e.refresh_shortlist("manual")
    except Exception as ex:
        raise HTTPException(502, f"Shortlist failed: {str(ex)[:150]}")
    return clean({"ok": True, "count": n, "items": e.shortlist, "at": e.shortlist_at})


@app.get("/api/premarket")
def premarket():
    e = need_engine()
    return clean(e.pm_timeline())


@app.get("/api/evening")
def evening_list():
    e = need_engine()
    return clean({"items": e.evening, "at": e.evening_at, "overnight": e.overnight})


@app.post("/api/evening/review")
def evening_review():
    e = need_engine()
    try:
        n = e.evening_review()
    except Exception as ex:
        raise HTTPException(502, f"Review failed: {str(ex)[:150]}")
    return clean({"ok": True, "count": n, "items": e.evening, "at": e.evening_at})


@app.get("/api/study")
def study_status():
    from autobot.study import summary
    return summary()


class StudyReq(BaseModel):
    pass


@app.post("/api/study/run")
def study_run():
    if not engine:
        raise HTTPException(400, "not ready")
    _th.Thread(target=lambda: engine.study_night(), daemon=True, name="study-now").start()
    return {"ok": True}


class HarvestReq(BaseModel):
    symbol: str


# ---------------- diagnostics sharing (opt-in) + hidden admin panel ----------------
def _diag_state():
    e = engine
    try:
        st = e.status() if e else {}
    except Exception:
        st = {}
    return {"running": st.get("running"), "halted": st.get("halted"), "session": st.get("state") and _session_name(e) if e else None,
            "streaming": bool(getattr(getattr(e, "broker", None), "live", None))}


diag = telemetry.Reporter(settings, _diag_state)
diag.bundle_fn = lambda: _support_zip()      # defined further down; resolved when called


class DiagCfg(BaseModel):
    share: bool | None = None
    label: str | None = None
    asked: bool | None = None
    collector_url: str | None = None
    share_logs: bool | None = None


@app.get("/api/diag/status")
def diag_status():
    return {**diag.status(), "label": settings.diag_label, "collector_url": settings.collector_url}


@app.get("/api/diag/preview")
def diag_preview():
    """Exactly what would be sent. Nothing here is a key, a position, an order, or any money figure."""
    return telemetry.build(settings, _diag_state())


@app.post("/api/diag/config")
def diag_config(r: DiagCfg):
    if r.collector_url is not None:
        u = r.collector_url.strip().rstrip("/")
        if u and not telemetry.valid_url(u):
            raise HTTPException(400, "The collector address must start with https:// (http:// is only allowed for localhost or a home network).")
        settings.collector_url = u
    if r.label is not None:
        settings.diag_label = r.label.strip()[:40]
    if r.asked is not None:
        settings.diag_asked = bool(r.asked)
    if r.share is not None:
        was = settings.share_diagnostics
        settings.share_diagnostics = bool(r.share)
        settings.diag_asked = True
        if was and not r.share:
            threading.Thread(target=diag.forget, daemon=True).start()     # switching off also deletes what support holds
        if r.share and not was:
            threading.Thread(target=diag.send_now, daemon=True).start()
    if r.share_logs is not None:
        was_l = settings.share_trade_logs
        settings.share_trade_logs = bool(r.share_logs)
        settings.diag_asked = True
        if was_l and not r.share_logs:
            threading.Thread(target=diag.forget, daemon=True).start()     # off = delete what support holds, logs included
        if r.share_logs and not was_l:
            threading.Thread(target=diag.send_logs_now, daemon=True).start()
    settings.save()
    return {"ok": True, **diag_status()}


# ---------------- optional add-ons (installed outside the app folder; absent on normal phones) ----------------
ADDON_DIR = Path.home() / ".sekexbot" / "admin"


@app.get("/ext.js")
def ext_js():
    """Dashboard extension script. Empty unless an add-on is installed on this phone."""
    f = ADDON_DIR / "ext.js"
    return Response(f.read_text(encoding="utf-8") if f.exists() else "", media_type="application/javascript",
                    headers={"Cache-Control": "no-store"})


def _load_addons():
    f = ADDON_DIR / "admin_ext.py"
    if not f.exists():
        return
    try:
        import importlib.util
        spec = importlib.util.spec_from_file_location("sekex_admin_ext", f)
        mod = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        mod.register(app, settings=settings, telemetry=telemetry)
        logging.getLogger("autobot").info("Add-on loaded: %s", f.name)
    except Exception as ex:
        logging.getLogger("autobot").warning("Add-on failed to load: %s", ex)


@app.get("/api/manual/learn")
def manual_learn(days: int = 60):
    """What your own manual round trips say: win rate, typical winner and loser, quick-win size, re-entry habits."""
    e = need_engine()
    if not hasattr(e.broker, "trading"):
        return {"n": 0, "error": "The simulator has no real order history; connect your Alpaca account to learn from your trades."}
    from autobot import manuallearn
    try:
        r = manuallearn.learn(e.broker, max(7, min(180, int(days))))
    except Exception as ex:
        raise HTTPException(502, f"Couldn't read your order history from Alpaca: {str(ex)[:150]}")
    e.manual_learn = r
    return r


@app.post("/api/manual/learn/apply")
def manual_learn_apply():
    r = getattr(need_engine(), "manual_learn", None) or {}
    pct = r.get("suggest_harvest_pct")
    if not pct:
        raise HTTPException(400, "Analyze your manual trades first (needs some winning round trips).")
    settings.pct_harvest_pct = float(pct)
    settings.save()
    return {"ok": True, "pct": pct}


@app.post("/api/harvest/arm")
def harvest_arm(r: HarvestReq):
    """Turn auto-harvest on for a position you already hold."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym}; auto-harvest is for your own trades.")
    pos = e.broker.positions().get(sym)
    if not pos or not pos["qty"]:
        raise HTTPException(404, f"You don't hold {sym}.")
    from autobot.sessions import bot_day
    e.manual_syms[sym] = bot_day(e.broker.now())
    harvester.arm(sym, "buy" if pos["qty"] > 0 else "sell", abs(pos["qty"]), "watching your position")
    e.event(f"♻ Auto-harvest ON for {sym} ({abs(pos['qty']):g} sh)")
    return {"ok": True}


@app.post("/api/harvest/now")
def harvest_now(r: HarvestReq):
    """Harvest now: sell the position at once and keep the harvest cycle going (re-enter on a pullback); while waiting to re-enter, buy back now."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    if sym in e.trades:
        raise HTTPException(409, f"The auto-trader is managing {sym}; this button is for your own trades.")
    pos = e.broker.positions().get(sym)
    job = [j for j in harvester.status() if j["symbol"] == sym]
    if not job and (not pos or not pos["qty"]):
        raise HTTPException(404, f"You don't hold {sym}.")
    if not job:
        from autobot.sessions import bot_day
        e.manual_syms[sym] = bot_day(e.broker.now())
        msg = harvester.now(sym, "buy" if pos["qty"] > 0 else "sell", abs(pos["qty"]))
    else:
        msg = harvester.now(sym)
    e.event(f"♻ Harvest now tapped for {sym}: {msg}")
    return {"ok": True, "msg": msg}


@app.post("/api/harvest/stop")
def harvest_stop(r: HarvestReq):
    need_engine()
    return {"ok": harvester.stop(_valid_sym(r.symbol))}


@app.get("/api/harvest")
def harvest_list():
    return {"jobs": harvester.status()}


class CancelReq(BaseModel):
    order_id: str


@app.post("/api/manual/cancel")
def manual_cancel(r: CancelReq):
    e = need_engine()
    e.broker.cancel(r.order_id)
    e.event("MANUAL cancel order " + r.order_id[:8])
    return {"ok": True}


class CancelSym(BaseModel):
    symbol: str


@app.post("/api/manual/cancel_symbol")
def manual_cancel_symbol(r: CancelSym):
    """Trade pad CANCEL key: cancel the open (unfilled) orders on one symbol. Refused for a BOT trade, because
    cancelling its bracket would take away its stop and target (use CLOSE for those)."""
    e = need_engine()
    sym = _valid_sym(r.symbol)
    t = e.trades.get(sym)
    if t is not None and t.status == "open":
        raise HTTPException(409, f"{sym} is a BOT trade: cancelling its orders would remove its stop and target. Use CLOSE instead.")
    e.broker.cancel_symbol_orders(sym)
    e.event(f"MANUAL cancel all open orders on {sym}")
    return {"ok": True}


# ---------------- in-app updates (Android edition) ----------------
# Two ways, both from the dashboard on the phone itself (never from Remote access):
#   1. pick a SekexBot_Android_vX.Y.Z.zip file on the phone -> uploaded here -> installed
#   2. an update link (UPDATE_URL in .env) to a latest.json you host -> check -> download -> install
# The zip is checked (it must be a SekexBot Android package, and match the SHA-256 in latest.json)
# before `sekex update` installs it; your keys, settings, learning memory and journal are kept.
UPD_DIR = Path.home() / ".sekexbot"
_upd = {"checked": 0.0, "info": None}


def _zip_version(path: Path) -> str:
    import zipfile
    try:
        z = zipfile.ZipFile(path)
    except zipfile.BadZipFile:
        raise HTTPException(400, "That file isn't a zip.")
    names = z.namelist()
    if any(n.startswith("/") or ".." in n.split("/") for n in names):
        raise HTTPException(400, "That zip has unsafe file paths - not installing it.")
    if "SekexBot_Android/install.sh" not in names or "SekexBot_Android/VERSION" not in names:
        raise HTTPException(400, "That zip isn't a SekexBot Android package (SekexBot_Android_vX.Y.Z.zip).")
    return z.read("SekexBot_Android/VERSION").decode().strip()


def _vtuple(v):
    try:
        return tuple(int(x) for x in v.split("."))
    except ValueError:
        return (0,)


def _run_update(path: Path, new_ver: str):
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "In-app updates are for the Android edition. On a PC, replace the files and restart.")
    log = open(Path.home() / "sekexbot-update.log", "w")
    env = dict(os.environ, SEKEX_QUICK="1", SEKEX_QUIET="1")
    env.pop("SEKEX_LOGGING", None)
    subprocess.Popen(["bash", exe, "update", str(path)], stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                     env=env, start_new_session=True)
    if engine:
        engine.event(f"Updating SekexBot {__version__} -> {new_ver}. Back in about a minute.", "warning")
    return {"ok": True, "from": __version__, "to": new_ver}


REL_DIR = UPD_DIR / "releases"


def _releases():
    out = []
    for f in sorted(REL_DIR.glob("SekexBot_Android_v*.zip"), key=lambda p: p.stat().st_mtime, reverse=True):
        v = f.stem.split("_v")[-1]
        if v != __version__:
            out.append({"version": v, "saved": datetime.fromtimestamp(f.stat().st_mtime, NY).strftime("%b %d %I:%M %p")})
    return out


def _upd_prefs():
    return {"mode": os.getenv("UPDATE_MODE", "ask"), "skip": os.getenv("UPDATE_SKIP", "")}


@app.get("/api/app/update/progress")
def update_progress():
    """Live install progress while an update/rollback runs (the old app keeps serving until the restart)."""
    import time as _t
    steps, t0 = [], None
    f = UPD_DIR / "update_progress.log"
    if f.exists():
        for ln in f.read_text().splitlines():
            ts, _, msg = ln.partition("|")
            if ts.isdigit():
                t0 = t0 or int(ts)
                steps.append({"t": int(ts), "msg": msg})
    tail = []
    lg = Path.home() / "sekexbot-update.log"
    if lg.exists():
        import re as _re
        tail = [_re.sub(r"\x1b\[[0-9;]*m", "", x) for x in lg.read_text(errors="ignore").splitlines()[-8:] if x.strip()]
    expected = 7
    done = any(x["msg"] == "DONE" for x in steps)
    failed = any(x["msg"].startswith("FAILED") for x in steps)
    pct = 100 if done else min(95, int(100 * len(steps) / expected))
    return {"current": __version__, "steps": steps, "pct": pct, "done": done, "failed": failed,
            "elapsed": int(_t.time() - t0) if t0 else 0, "log": tail}


@app.get("/api/app/update/status")
def update_status():
    return {"current": __version__, "edition": android.EDITION, "update_url": os.getenv("UPDATE_URL", ""),
            "info": _upd["info"], "prefs": _upd_prefs(), "releases": _releases()}


class UpdPrefsReq(BaseModel):
    mode: str | None = None          # ask | manual
    skip: str | None = None          # a version to stop asking about ("" = clear)


@app.post("/api/app/update/prefs")
def update_prefs(r: UpdPrefsReq):
    vals = {}
    if r.mode in ("ask", "manual"):
        vals["UPDATE_MODE"] = r.mode
    if r.skip is not None:
        vals["UPDATE_SKIP"] = r.skip.strip()
    if vals:
        write_env(vals)
    return {"ok": True, "prefs": _upd_prefs()}


class RollbackReq(BaseModel):
    version: str


@app.post("/api/app/rollback")
def rollback(r: RollbackReq):
    v = r.version.strip()
    if not all(p.isdigit() for p in v.split(".")):
        raise HTTPException(400, "Pick a version from the list")
    path = REL_DIR / f"SekexBot_Android_v{v}.zip"
    if not path.exists():
        raise HTTPException(404, f"No saved copy of v{v} on this phone")
    if _zip_version(path) != v:
        raise HTTPException(400, "That saved copy looks damaged")
    return _run_update(path, v)


@app.post("/api/app/update/upload")
async def update_upload(request: Request, allow_downgrade: bool = False):
    data = await request.body()
    if not data or len(data) > 60_000_000:
        raise HTTPException(400, "Pick the SekexBot_Android_vX.Y.Z.zip file (up to 60 MB).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    path.write_bytes(data)
    ver = _zip_version(path)
    if _vtuple(ver) < _vtuple(__version__) and not allow_downgrade:
        raise HTTPException(409, f"DOWNGRADE:{ver}")
    return _run_update(path, ver)


class UpdUrlReq(BaseModel):
    url: str


@app.post("/api/app/update/url")
def update_set_url(r: UpdUrlReq):
    u = r.url.strip()
    if u and not u.startswith("https://"):
        raise HTTPException(400, "The update link must start with https://")
    write_env({"UPDATE_URL": u})
    _upd.update(checked=0.0, info=None)
    return {"ok": True}


def _check_manifest():
    import time
    from urllib.parse import urljoin
    import requests
    url = os.getenv("UPDATE_URL", "")
    if not url:
        raise HTTPException(400, "Add your update link first (the address of latest.json).")
    try:
        m = requests.get(url, timeout=20, headers={"Cache-Control": "no-cache"}).json()
    except Exception as ex:
        raise HTTPException(400, f"Couldn't read the update link: {str(ex)[:160]}")
    if not m.get("version") or not m.get("url"):
        raise HTTPException(400, "The update link doesn't look like a SekexBot latest.json")
    info = {"latest": m["version"], "url": urljoin(url, m["url"]), "sha256": m.get("sha256", ""),
            "notes": m.get("notes", ""), "available": _vtuple(m["version"]) > _vtuple(__version__)}
    _upd.update(checked=time.time(), info=info)
    return info


@app.get("/api/app/update/check")
def update_check():
    return {"current": __version__, **_check_manifest()}


@app.post("/api/app/update/install")
def update_install():
    import hashlib
    import requests
    info = _check_manifest()
    if not info["available"]:
        raise HTTPException(400, f"You already have the latest version ({__version__}).")
    UPD_DIR.mkdir(exist_ok=True)
    path = UPD_DIR / "update.zip"
    try:
        with requests.get(info["url"], stream=True, timeout=120) as r:
            r.raise_for_status()
            h = hashlib.sha256()
            with open(path, "wb") as f:
                for chunk in r.iter_content(1 << 16):
                    f.write(chunk)
                    h.update(chunk)
    except Exception as ex:
        raise HTTPException(400, f"Download failed: {str(ex)[:160]}")
    if not info["sha256"] or h.hexdigest().lower() != info["sha256"].lower():
        path.unlink(missing_ok=True)
        raise HTTPException(400, "The download didn't match the checksum in latest.json - not installing it.")
    ver = _zip_version(path)
    return _run_update(path, ver)


@app.on_event("startup")
def _auto_update_check():
    """Every 6 hours, if an update link is set, look for a new version and notify the phone."""
    import shutil
    import subprocess
    import threading
    import time

    def loop():
        told = ""
        while True:
            time.sleep(90)
            if os.getenv("UPDATE_URL"):
                try:
                    info = _check_manifest()
                    pr = _upd_prefs()
                    if info["available"] and info["latest"] != told and pr["mode"] == "ask" \
                            and info["latest"] != pr["skip"] and shutil.which("termux-notification"):
                        told = info["latest"]
                        subprocess.run(["termux-notification", "--id", "sekexbot-update", "--title",
                                        f"SekexBot {info['latest']} is available",
                                        "--content", "Tap to open SekexBot and choose Update now or Later",
                                        "--action", f"termux-open-url http://127.0.0.1:{ARGS.port}"], timeout=10)
                except Exception:
                    pass
            time.sleep(3600)          # look for a new version every hour
    if android.IS_ANDROID:
        threading.Thread(target=loop, daemon=True, name="update-check").start()


# ---------------- streaming prices to the dashboard (Server-Sent Events) ----------------
@app.get("/api/stream")
async def price_stream(request: Request, symbols: str = ""):
    import asyncio
    import json as _j
    import time as _t
    from fastapi.responses import StreamingResponse
    syms = [x.strip().upper() for x in symbols.split(",") if x.strip()][:30]

    async def gen():
        sent, last_ping = {}, 0.0
        while not await request.is_disconnected():
            now = _t.time()
            for x in syms:
                _interest[x] = now
            f = feed
            out = {}
            if f is not None:
                for x in syms:
                    lv = f.get(x, max_age=30)
                    if lv and lv.get("last"):
                        v = (round(lv["bid"] or 0, 4), round(lv["ask"] or 0, 4), round(lv["last"], 4))
                        if sent.get(x) != v:
                            sent[x] = v
                            out[x] = {"bid": v[0] or None, "ask": v[1] or None, "last": v[2]}
            if out:
                yield f"data: {_j.dumps(out)}\n\n"
            elif now - last_ping > 15:
                last_ping = now
                yield f": ping {int(now)}\n\n"
            await asyncio.sleep(0.25)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"})


# ---------------- 🛠 help & repair ----------------
def _diag():
    from autobot import helpdesk
    return helpdesk.diagnose({"engine": engine, "setup_error": setup_error, "settings": settings, "version": __version__,
                              "device": android.health(), "sim": ARGS.sim, "update_info": _upd["info"],
                              "feed": feed})


@app.get("/api/help/diagnose")
def help_diagnose():
    return clean(_diag())


class FixReq(BaseModel):
    action: str


@app.post("/api/help/fix")
def help_fix(r: FixReq):
    import shutil
    import subprocess
    a = r.action
    if a == "reconnect":
        if engine and engine.running:
            engine.stop()
            build_engine()
            if engine:
                engine.start(resumed=True)
        else:
            build_engine()
        return {"ok": engine is not None, "message": "Reconnected." if engine else setup_error}
    if a == "use_iex":
        was = bool(engine and engine.running)
        if engine and engine.running:
            engine.stop()
        settings.data_feed = "iex"
        settings.save()
        build_engine()
        if was and engine:
            engine.start(resumed=True)
        return {"ok": engine is not None, "message": "Switched the data feed to IEX (free)."}
    if a == "trade_on":
        need_engine().start()
        return {"ok": True, "message": "Auto-trader started."}
    if a in ("restart", "repair"):
        exe = shutil.which("sekex")
        if not android.IS_ANDROID or not exe:
            raise HTTPException(400, "Restart / repair from the app works on the Android edition.")
        cmd = ["bash", exe, "restart"] if a == "restart" else \
            ["bash", "-c", f"SEKEX_QUICK=1 SEKEX_QUIET=1 bash {BASE_DIR_}/install.sh > $HOME/sekexbot-repair.log 2>&1; bash {exe} restart"]
        subprocess.Popen(cmd, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        return {"ok": True, "restarting": True,
                "message": "Restarting…" if a == "restart" else "Repairing the install, then restarting (1–3 min)…"}
    if a == "update":
        return update_install()
    raise HTTPException(400, "Unknown repair action")


class AskReq(BaseModel):
    question: str = ""
    error: str = ""


@app.post("/api/help/ask")
def help_ask(r: AskReq):
    from autobot import helpdesk
    return helpdesk.ask(r.question[:800], _diag(), __version__, r.error[:600])


from autobot.selffix import SelfFix  # noqa: E402
selffix = SelfFix(__version__, lambda: {"mode": engine.mode if engine else "-", "running": bool(engine and engine.running),
                                        "session": engine.session.name if engine and engine.session else "-",
                                        "state": engine.state if engine else setup_error, "sim": ARGS.sim})
if not ARGS.sim:
    selffix.confirm_after_boot()


class FixReq(BaseModel):
    problem: str = ""
    error: str = ""


class PinReq(BaseModel):
    pin: str = ""


class FixPinReq(BaseModel):
    id: str
    pin: str = ""


def _need_pin(request, pin):
    ip = "pin:" + auth.client_ip(request)
    if auth.rate_limited(ip):
        raise HTTPException(429, "Too many wrong PINs. Wait 15 minutes.")
    if not live_pin():
        raise HTTPException(400, "Set a Live PIN first (⚙ → Broker keys → Live). Fixes need it to be applied.")
    if pin != live_pin():
        auth.record_fail(ip)
        raise HTTPException(403, "Wrong PIN")


def _restart_soon(why):
    import threading as _thr
    logging.warning("Restarting for %s", why)

    def _go():
        import time as _tm
        _tm.sleep(1.5)
        os._exit(0)            # the sekex watchdog starts it again in ~5 s; trading resumes if it was running
    _thr.Thread(target=_go, daemon=True).start()


@app.get("/api/selffix/status")
def selffix_status():
    return clean(selffix.status())


@app.post("/api/selffix/start")
def selffix_start(r: FixReq):
    try:
        return {"ok": True, "job": selffix.start(r.problem[:2000], r.error[:2000])}
    except ValueError as ex:
        raise HTTPException(400, str(ex))


@app.post("/api/selffix/discard")
def selffix_discard():
    selffix.discard()
    return {"ok": True}


@app.post("/api/selffix/apply")
def selffix_apply(r: PinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        rec = selffix.apply()
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix applied: {rec['summary'][:160]}", "warning")
    _restart_soon("a Claude fix")
    return {"ok": True, "fix": rec}


@app.post("/api/selffix/undo")
def selffix_undo(r: PinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        rec = selffix.undo()
    except ValueError as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix undone: {rec['summary'][:120]}", "warning")
    _restart_soon("undoing a Claude fix")
    return {"ok": True, "fix": rec}


@app.post("/api/selffix/reapply")
def selffix_reapply(r: FixPinReq, request: Request):
    _need_pin(request, r.pin)
    try:
        selffix.prepare_reapply(r.id)
        rec = selffix.apply()
    except (ValueError, SyntaxError) as ex:
        raise HTTPException(400, str(ex))
    if engine:
        engine.event(f"🤖 Claude fix re-applied after an update: {rec['summary'][:140]}", "warning")
    _restart_soon("re-applying a Claude fix")
    return {"ok": True, "fix": rec}


@app.get("/api/selffix/export")
def selffix_export():
    body = json.dumps(selffix.export(), indent=1)
    return Response(body, media_type="application/json",
                    headers={"Content-Disposition": f'attachment; filename="sekexbot_fixes_v{__version__}.json"'})


_SECRET_WORDS = ("key", "secret", "pin", "token", "password", "pass", "webhook", "chat_id", "url")


def _support_files() -> dict:
    """The review bundle (journal, learner, strategy stats, skip log, scrubbed settings, redacted log tail) as
    {file name: bytes}. Used by the Export button and, when the user opted in, by the remote log upload."""
    import csv
    import io
    import sqlite3
    out = {}
    dbf = DATA_DIR / "trades.db"
    if dbf.exists():
        try:
            c = sqlite3.connect(f"file:{dbf}?mode=ro", uri=True)
            cur = c.execute("select * from trades order by opened_at")
            buf = io.StringIO()
            w = csv.writer(buf)
            w.writerow([d[0] for d in cur.description])
            w.writerows(cur.fetchall())
            out["journal_trades.csv"] = buf.getvalue().encode()
            c.close()
        except Exception as ex:
            out["journal_error.txt"] = str(ex).encode()
    for name in ("learner.json", "level_stats.json", "slippage.json", "day_state.json", "premkt.json", "prep.json", "manual_learn.json", "tune_epoch.json"):
        f = DATA_DIR / name
        if f.exists() and f.stat().st_size < 3_000_000:
            out[name] = f.read_bytes()
    try:
        st = json.loads((DATA_DIR / "settings.json").read_text())
        st = {k: v for k, v in st.items() if not any(w in k.lower() for w in _SECRET_WORDS) and k not in ("collector_url", "diag_label")}
        out["settings_scrubbed.json"] = json.dumps(st, indent=1).encode()
    except Exception:
        pass
    lg = DATA_DIR / "autobot.log"
    if lg.exists():
        try:
            from autobot.helpdesk import redact
            lines = lg.read_text(errors="replace").splitlines()[-6000:]
            out["autobot_log_tail.txt"] = redact("\n".join(lines)).encode()
        except Exception:
            pass
    try:
        if engine:
            out["why_no_trade_skips.json"] = json.dumps(list(engine.skips)[:600], indent=1).encode()
            out["recent_events.json"] = json.dumps(list(engine.events)[:300], indent=1).encode()
            out["movers_board.json"] = json.dumps(engine._movers_view(), indent=1).encode()
    except Exception:
        pass
    try:
        out["fixes_on_this_phone.json"] = json.dumps(selffix.export(), indent=1).encode()
    except Exception:
        pass
    out["README.txt"] = (f"SekexBot {__version__} support export, {datetime.now():%Y-%m-%d %H:%M}.\n"
                         "Contains: the trade journal, strategy/learner state, scrubbed settings and the recent engine log.\n"
                         "It does not contain API keys, PINs, tokens, the .env file or the account number.\n").encode()
    return out


def _support_zip() -> bytes:
    import io
    import zipfile
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for n, b in _support_files().items():
            z.writestr(n, b)
    return buf.getvalue()


@app.get("/api/support/export")
def support_export():
    """One zip with the trade journal and the strategy/engine logs, for reviewing why trades lose. Phone only."""
    return Response(_support_zip(), media_type="application/zip",
                    headers={"Content-Disposition": f'attachment; filename="sekexbot_support_export_v{__version__}.zip"'})


@app.get("/api/diag/logs_preview")
def diag_logs_preview():
    """What the remote log upload would send: file names, sizes, and the first journal rows."""
    files = _support_files()
    j = files.get("journal_trades.csv", b"").decode(errors="replace").splitlines()
    return {"files": {n: len(b) for n, b in files.items()}, "journal_rows": max(0, len(j) - 1),
            "journal_header_and_first_rows": j[:4],
            "never_included": "API keys, PINs, tokens, the .env file, your account number, your collector address"}


@app.post("/api/help/report")
def help_report():
    from autobot import helpdesk
    st = {"mode": engine.mode if engine else "-", "state": engine.state if engine else setup_error,
          "running": bool(engine and engine.running), "edition": android.EDITION,
          "session": engine.session.name if engine and engine.session else "-"}
    text = helpdesk.report(_diag(), __version__, st)
    dl = Path.home() / "storage" / "downloads"
    target = (dl if dl.exists() else DATA_DIR) / f"SekexBot_report_{datetime.now(NY).strftime('%Y%m%d_%H%M')}.txt"
    try:
        target.write_text(text)
    except Exception:
        target = None
    return {"ok": True, "path": str(target) if target else "", "text": text[:20000]}


# ---------------- alerts ----------------
@app.get("/api/alerts")
def alerts_get(since: int = 0):
    items = [a for a in list(alerts.history) if a["id"] > since]
    return {"items": items[:60], "cfg": alerts.public_cfg()}


class AlertCfg(BaseModel):
    enabled: dict | None = None
    phone: bool | None = None
    quiet_start: str | None = None
    quiet_end: str | None = None
    quiet_keep_risk: bool | None = None
    ntfy_topic: str | None = None
    ntfy_server: str | None = None
    tg_token: str | None = None
    tg_chat: str | None = None
    beep: bool | None = None
    voice: bool | None = None
    predict_min: int | None = None


class SoundReq(BaseModel):
    on: bool


@app.post("/api/alerts/sound")
def alerts_sound(r: SoundReq):
    """The 🔊 ON / OFF button in the top bar: turns the phone's beep and voice on or off together.
    Allowed from the remote link too (it can only make alerts quieter or louder, nothing else)."""
    alerts.cfg["beep"] = alerts.cfg["voice"] = bool(r.on)
    if not r.on:
        alerts.screen_sound_at = 0.0
    alerts.save()
    return {"ok": True, "on": bool(r.on)}


@app.post("/api/alerts/test_voice")
def alerts_test_voice():
    return {"ok": alerts.test_voice()}


@app.post("/api/alerts/config")
def alerts_config(r: AlertCfg):
    import re
    for k, v in r.model_dump(exclude_none=True).items():
        if k == "enabled":
            alerts.cfg["enabled"].update({a: bool(b) for a, b in v.items() if a in alerts.cfg["enabled"]})
        elif k in ("quiet_start", "quiet_end"):
            if v and not re.fullmatch(r"[0-2]\d:[0-5]\d", v):
                raise HTTPException(400, "Quiet hours must look like 22:00")
            alerts.cfg[k] = v
        elif k == "ntfy_topic":
            if v and not re.fullmatch(r"[A-Za-z0-9_-]{1,64}", v):
                raise HTTPException(400, "ntfy topic: letters, numbers, - and _ only")
            alerts.cfg[k] = v
        else:
            alerts.cfg[k] = v.strip() if isinstance(v, str) else v
    alerts.save()
    return {"ok": True, "cfg": alerts.public_cfg()}


@app.post("/api/alerts/test")
def alerts_test():
    alerts.test()
    return {"ok": True}


class PriceAlertReq(BaseModel):
    symbol: str = ""
    op: str = "above"
    price: float = 0
    note: str = ""
    remove: str = ""


@app.post("/api/alerts/price")
def alerts_price(r: PriceAlertReq):
    if r.remove:
        watcher.remove_price_alert(r.remove)
    else:
        sym = _valid_sym(r.symbol)
        if r.op not in ("above", "below") or r.price <= 0:
            raise HTTPException(400, "Choose above or below and a price")
        if len(alerts.cfg.get("price_alerts", [])) >= 50:
            raise HTTPException(400, "Up to 50 price alerts")
        watcher.add_price_alert(sym, r.op, r.price, r.note[:60])
    return {"ok": True, "price_alerts": alerts.cfg.get("price_alerts", [])}


@app.post("/api/app/shutdown")
def app_shutdown():
    """Android: turn the whole app off (same as the home-screen Stop button / `sekex stop`)."""
    import shutil
    import subprocess
    exe = shutil.which("sekex")
    if not android.IS_ANDROID or not exe:
        raise HTTPException(400, "Turning the app off from the dashboard is only available on the Android edition.")
    subprocess.Popen(["bash", exe, "stop", "--gui"], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                     stderr=subprocess.DEVNULL, start_new_session=True)
    return {"ok": True}


@app.post("/api/ai_test")
def ai_test():
    from autobot.analyst import ai_ping
    return ai_ping()


class WatchReq(BaseModel):
    symbol: str
    action: str = "add"      # add | remove


@app.post("/api/watchlist")
def watchlist(r: WatchReq):
    sym = r.symbol.upper().strip()
    if not sym or not sym.replace(".", "").isalpha() or len(sym) > 8:
        raise HTTPException(400, "Enter a valid ticker")
    if r.action != "remove" and engine and getattr(engine, "mode", "") != "SIM":
        try:                                       # reject names Alpaca doesn't list (e.g. a company name instead of a ticker)
            if not engine.broker._tradable(sym, False):
                raise HTTPException(400, f"{sym} isn't a tradable ticker on Alpaca. Use the stock symbol (e.g. CVX for Chevron).")
        except HTTPException:
            raise
        except Exception:
            pass
    wl = [w.upper() for w in settings.watchlist]
    if r.action == "remove":
        wl = [w for w in wl if w != sym]
    elif sym not in wl:
        wl.append(sym)
    settings.watchlist = wl
    settings.save()
    if engine:
        engine.last_scan = None
        engine.ext_last_scan = None
        engine.event(f"Watchlist {'removed' if r.action == 'remove' else 'added'} {sym} — rescanning")
    return {"ok": True, "watchlist": wl}


# ---------------- 📊 stats · 📰 earnings/news · 🛡 heartbeat & backups ----------------
@app.get("/api/stats")
def stats_api(days: int = 90, session: str = ""):
    from autobot import stats as st
    e = need_engine()
    days = max(1, min(int(days), 365))
    try:
        if ARGS.sim:
            trips = []
            for r in db.recent(2000):
                if r.get("status") != "closed" or not r.get("closed_at"):
                    continue
                o, c = datetime.fromisoformat(r["opened_at"]), datetime.fromisoformat(r["closed_at"])
                trips.append({"symbol": r["symbol"], "side": "long" if r["side"] == "buy" else "short", "qty": r["qty"],
                              "entry": r["entry"], "exit": r["exit"], "opened": o.astimezone(NY), "closed": c.astimezone(NY),
                              "pnl": r["pnl"] or 0, "cost": (r["qty"] or 0) * (r["entry"] or 0)})
        else:
            trips = st.round_trips(st.fetch_fills(e.broker, days))
    except Exception as ex:
        raise HTTPException(502, f"Couldn't load your trade history from Alpaca: {str(ex)[:160]}")
    out = st.summarize(trips, db.recent(3000), days, session if session in st.ORDER else None)
    out["mode"] = e.mode
    return clean(out)


_research_cache = {}


@app.get("/api/research/{symbol}")
def research(symbol: str, days: int = 30, min_move: float = 1.5):
    """🔍 Trend legs + 3:55 PM overnight test from the stock's own minute history (runs on your Alpaca data)."""
    import time as _t
    from autobot import trends
    e = need_engine()
    sym = _valid_sym(symbol)
    days = max(5, min(int(days), 90))
    key = (sym, days, e.mode)
    c = _research_cache.get(key)
    if c and _t.time() - c[0] < 600:
        df = c[1]
    else:
        try:
            df = e.broker.chart_bars(sym, days=days + 3)
        except Exception as ex:
            raise HTTPException(502, f"Couldn't load {sym} history: {str(ex)[:150]}")
        if df is None or len(df) < 200:
            raise HTTPException(404, f"Not enough minute history for {sym} yet.")
        _research_cache[key] = (_t.time(), df)
    legs = trends.trend_legs(df, min_move=max(0.3, min(float(min_move), 20)) / 100)
    cb = trends.closing_bell(df)
    return clean({"symbol": sym, "days": days, "from": str(df.index[0].date()), "to": str(df.index[-1].date()),
                  "legs": legs[-80:], "summary": trends.summarize_legs(legs), "closing_bell": cb})


@app.get("/api/skips")
def skips_api(symbol: str = "", limit: int = 80):
    """'Why no trade?' - recent signals/flips the bot saw but did not take, with the reason."""
    e = need_engine()
    sym = symbol.strip().upper()
    rows = [r for r in list(e.skips) if not sym or r["symbol"] in (sym, "(all)")]
    return {"skips": rows[:max(1, min(int(limit), 300))]}


@app.get("/api/events/{symbol}")
def events_api(symbol: str):
    e = need_engine()
    sym = _valid_sym(symbol)
    now = e.broker.now()
    news = events.news(sym, max_age=60) if not ARGS.sim else []
    return {"symbol": sym, "earnings": events.earnings_text(sym, now) if not ARGS.sim else "",
            "news": news[:6], "bot_block": events.block_reason(sym, now, _session_name(e)) if not ARGS.sim else "",
            **events.info()}


def _guard_status():
    e = engine
    if e is None:
        return ("NOT CONNECTED", 0, False)
    return (e.mode, len(e.positions or {}), bool(e.running))


def _need_guardian():
    if guardian is None:
        raise HTTPException(400, "Heartbeat and backups aren't available in the simulator.")
    return guardian


@app.get("/api/guardian")
def guardian_get():
    return _need_guardian().public()


class GuardCfg(BaseModel):
    hc_url: str | None = None
    gh_repo: str | None = None
    gh_token: str | None = None
    backup_on: bool | None = None


@app.post("/api/guardian/config")
def guardian_cfg(r: GuardCfg):
    g = _need_guardian()
    d = r.model_dump(exclude_none=True)
    if "hc_url" in d and d["hc_url"] and not d["hc_url"].startswith("https://"):
        raise HTTPException(400, "Paste the full ping URL from healthchecks.io (starts with https://hc-ping.com/…).")
    if "gh_repo" in d and d["gh_repo"] and d["gh_repo"].count("/") != 1:
        raise HTTPException(400, "Repo must look like owner/name, e.g. sekextrading-cloud/SekeXBot-Mobile")
    g.cfg.update(d)
    g.save()
    ok = g.ping() if d.get("hc_url") else None
    return {"ok": True, "ping": ok, **g.public()}


@app.post("/api/guardian/test")
def guardian_test():
    g = _need_guardian()
    if not g.cfg["hc_url"]:
        raise HTTPException(400, "Add your healthchecks.io ping URL first.")
    return {"ok": g.ping(), **g.public()}


@app.post("/api/guardian/backup")
def guardian_backup():
    g = _need_guardian()
    r = g.backup()
    return {**r, **g.public()}


@app.post("/api/guardian/restore")
async def guardian_restore(request: Request):
    g = _need_guardian()
    if engine and engine.running:
        raise HTTPException(409, "Stop the auto-trader before restoring a backup.")
    data = await request.body()
    try:
        n = g.restore(data)
    except Exception as ex:
        raise HTTPException(400, str(ex)[:160])
    learner.__init__()
    return {"ok": True, "files": n, "note": "Restored. Restart the app (⚙ → Turn off app, then open it) to reload everything."}


@app.on_event("startup")
def _start_guardian():
    global guardian
    if not ARGS.sim:
        from autobot.guardian import Guardian
        guardian = Guardian(_guard_status)


_load_addons()


if __name__ == "__main__":
    print(f"\n  SekexBot v{__version__} ({RELEASE_DATE}){' - Android edition' if android.IS_ANDROID else ''}")
    print(f"  SekexBot dashboard -> http://{ARGS.host}:{ARGS.port}"
          f"  ({'SIMULATOR' if ARGS.sim else ('LIVE' if settings.live else 'PAPER')})\n")
    uvicorn.run(app, host=ARGS.host, port=ARGS.port, log_level="warning")
