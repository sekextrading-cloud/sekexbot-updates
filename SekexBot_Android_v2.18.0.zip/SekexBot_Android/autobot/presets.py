"""v2.18: custom preset strategies. You describe a setup in words (or show a chart screenshot); the AI turns it into a small, bounded rule set,
which is back-tested on real 5-minute bars, drawn on a chart image, saved, reviewed every day and (PAPER only) can trade by itself.

Pure functions plus a tiny JSON store. No orders are placed here. The AI can only fill in the numbers below; every value is clamped, so a preset can
never touch loss limits, Live mode or position size (size always comes from the risk budget)."""
import json
import re
import threading
import time
from datetime import datetime

import pandas as pd

from . import jump as jp
from .config import DATA_DIR

FILE = DATA_DIR / "presets.json"
LOCK = threading.RLock()
PATTERNS = {
    "pullback": "Pullback to the moving average in a trend, then a confirming candle (the JUMP IN setup)",
    "vwap_reclaim": "Price crosses back over VWAP in the direction of the trend",
    "breakout": "Price breaks the recent high (or low) on stronger volume",
    "gap_go": "A gap at the open that holds and keeps going",
}
LIMITS = {"stop_pct": (0.2, 5.0), "target_r": (0.5, 5.0), "vol_mult": (0.0, 5.0), "lookback": (5, 60), "gap_pct": (0.5, 20.0), "min_price": (0.5, 5000.0)}
DEFAULTS = {"pattern": "pullback", "side": "long", "stop_pct": 1.0, "target_r": 1.5, "vol_mult": 1.0, "above_vwap": True, "lookback": 20,
            "gap_pct": 2.0, "after_hours": True, "min_price": 1.0}


def normalize(r, name=None):
    """Clamp anything the AI (or a user) sent into the allowed ranges. Unknown keys are dropped."""
    r = r if isinstance(r, dict) else {}
    out = dict(DEFAULTS)
    p = str(r.get("pattern", out["pattern"])).lower().strip()
    out["pattern"] = p if p in PATTERNS else "pullback"
    s = str(r.get("side", out["side"])).lower().strip()
    out["side"] = s if s in ("long", "short", "both") else "long"
    for k, (lo, hi) in LIMITS.items():
        try:
            v = float(r.get(k, out[k]))
        except (TypeError, ValueError):
            v = out[k]
        out[k] = round(max(lo, min(hi, v)), 2)
    out["lookback"] = int(out["lookback"])
    out["above_vwap"] = bool(r.get("above_vwap", out["above_vwap"]))
    out["after_hours"] = bool(r.get("after_hours", out["after_hours"]))
    out["name"] = (str(name or r.get("name") or "My preset").strip()[:40]) or "My preset"
    out["notes"] = str(r.get("notes", ""))[:300]
    return out


def describe(r):
    side = {"long": "buy", "short": "short", "both": "buy and short"}[r["side"]]
    t = f"{PATTERNS[r['pattern']]}. I {side}. Stop {r['stop_pct']:g}% away, target {r['target_r']:g}x the risk."
    if r["pattern"] in ("breakout", "vwap_reclaim", "pullback") and r["vol_mult"] > 0:
        t += f" Volume at least {r['vol_mult']:g}x its recent average."
    if r["pattern"] == "breakout":
        t += f" Breaks the last {r['lookback']} candles."
    if r["pattern"] == "gap_go":
        t += f" Needs a gap of {r['gap_pct']:g}% or more."
    t += " Above VWAP for buys, below for shorts." if r["above_vwap"] else ""
    t += " After-hours candles count." if r["after_hours"] else " Regular hours only."
    return t


def scan(rules, d5):
    """Signals for one rule set on 5-minute bars (oldest first): {i, t, d, side('up'|'down'), price, stop, tp1, why}."""
    if d5 is None or len(d5) < 40:
        return []
    d = jp.prep(d5)
    n = len(d)
    o, h, l, c, v = (d[k].values for k in ("open", "high", "low", "close", "volume"))
    e9, e20, atr, va, vw = (d[k].values for k in ("ema9", "ema20", "atr", "vavg", "vwap"))
    idx, days = d.index, d.index.date
    want_up, want_dn = rules["side"] in ("long", "both"), rules["side"] in ("short", "both")
    pat, L = rules["pattern"], int(rules["lookback"])
    vm = rules["vol_mult"]
    raw = []
    if pat == "pullback":
        for s in jp.scan(d5):
            if s["kind"] == "in":
                raw.append((s["i"], s["side"], s["name"], s["why"]))
    else:
        last_gap_day = {}
        for i in range(max(26, L + 1), n):
            if days[i - 6] != days[i] or not (atr[i] == atr[i]) or atr[i] <= 0:
                continue
            volok = vm <= 0 or (va[i] == va[i] and va[i] > 0 and v[i] >= vm * va[i])
            up_tr, dn_tr = e9[i] > e20[i], e9[i] < e20[i]
            if pat == "vwap_reclaim" and vw[i] == vw[i] and vw[i - 1] == vw[i - 1] and volok:
                if c[i] > vw[i] and c[i - 1] <= vw[i - 1] and up_tr:
                    raw.append((i, "up", "VWAP reclaim", "Price crossed back above VWAP with the trend up."))
                elif c[i] < vw[i] and c[i - 1] >= vw[i - 1] and dn_tr:
                    raw.append((i, "down", "VWAP loss", "Price crossed back under VWAP with the trend down."))
            elif pat == "breakout" and volok:
                if c[i] > h[i - L:i].max() and up_tr:
                    raw.append((i, "up", "Breakout", f"Closed above the high of the last {L} candles."))
                elif c[i] < l[i - L:i].min() and dn_tr:
                    raw.append((i, "down", "Breakdown", f"Closed below the low of the last {L} candles."))
            elif pat == "gap_go":
                day = days[i]
                if day in last_gap_day:
                    continue
                prev = [k for k in range(i) if days[k] != day]
                today = [k for k in range(i + 1) if days[k] == day and (idx[k].hour, idx[k].minute) >= (9, 30)]
                if not prev or not today or (idx[i].hour, idx[i].minute) > (11, 0):
                    continue
                pc = [k for k in prev if days[k] == days[prev[-1]] and (idx[k].hour, idx[k].minute) < (16, 0)]
                if not pc:
                    continue
                gap = (o[today[0]] - c[pc[-1]]) / c[pc[-1]] * 100
                if abs(gap) < rules["gap_pct"]:
                    continue
                if gap > 0 and c[i] > o[today[0]] and c[i] > c[i - 1] and volok:
                    raw.append((i, "up", "Gap and go", f"Gapped up {gap:.1f}% and is holding above the open."))
                    last_gap_day[day] = i
                elif gap < 0 and c[i] < o[today[0]] and c[i] < c[i - 1] and volok:
                    raw.append((i, "down", "Gap down and go", f"Gapped down {abs(gap):.1f}% and is staying under the open."))
                    last_gap_day[day] = i
    out, last = [], {"up": -99, "down": -99}
    for i, side, name, why in sorted(raw):
        up = side == "up"
        if (up and not want_up) or ((not up) and not want_dn) or i - last[side] <= 8:
            continue
        if c[i] < rules["min_price"]:
            continue
        hh, mm = idx[i].hour, idx[i].minute
        if not rules["after_hours"] and not ((hh, mm) >= (9, 30) and hh < 16):
            continue
        if rules["above_vwap"] and pat != "vwap_reclaim" and vw[i] == vw[i] and ((up and c[i] <= vw[i]) or ((not up) and c[i] >= vw[i])):
            continue
        px = float(c[i])
        dist = max(px * rules["stop_pct"] / 100.0, 0.01)
        stop = px - dist if up else px + dist
        tp = px + rules["target_r"] * dist if up else px - rules["target_r"] * dist
        out.append({"i": i, "t": idx[i].strftime("%H:%M"), "d": idx[i].strftime("%a %b %d"), "day": str(days[i]), "side": side, "name": name, "why": why,
                    "price": round(px, 2), "stop": round(stop, 2), "tp1": round(tp, 2)})
        last[side] = i
    return out


def backtest(rules, d5, horizon=24, sigs=None):
    """Did price reach the target before the stop, within `horizon` bars (2 hours) on the same day? A bar touching both counts as the stop."""
    res = {"n": 0, "hit": 0, "fail": 0, "exp": 0, "rate": None, "avg_r": None, "avg_pct": None}
    if d5 is None or len(d5) < 40:
        return res
    sigs = scan(rules, d5) if sigs is None else sigs
    hi, lo, cl, days = d5["high"].values, d5["low"].values, d5["close"].values, d5.index.date
    rs, pcts = [], []
    for s in sigs:
        i, up = s["i"], s["side"] == "up"
        risk = abs(s["price"] - s["stop"]) or 0.01
        r = None
        end = min(len(d5) - 1, i + horizon)
        j = i
        for j in range(i + 1, end + 1):
            if days[j] != days[i]:
                j -= 1
                break
            stp = lo[j] <= s["stop"] if up else hi[j] >= s["stop"]
            tgt = hi[j] >= s["tp1"] if up else lo[j] <= s["tp1"]
            if stp:
                r = -1.0
                res["fail"] += 1
                break
            if tgt:
                r = rules["target_r"]
                res["hit"] += 1
                break
        if r is None:
            if j <= i:
                continue                                    # no later bar yet: still open
            r = ((cl[j] - s["price"]) if up else (s["price"] - cl[j])) / risk
            res["exp"] += 1
        res["n"] += 1
        rs.append(float(r))
        pcts.append(float(r * risk / s["price"] * 100))
    done = res["hit"] + res["fail"]
    if done >= 3:
        res["rate"] = round(res["hit"] / done * 100)
    if rs:
        res["avg_r"] = round(sum(rs) / len(rs), 2)
        res["avg_pct"] = round(sum(pcts) / len(pcts), 2)
    return res


def merge_tests(parts):
    t = {"n": 0, "hit": 0, "fail": 0, "exp": 0}
    rs = []
    for p in parts:
        for k in t:
            t[k] += p.get(k, 0)
        if p.get("avg_r") is not None:
            rs.append((p["avg_r"], p["n"]))
    done = t["hit"] + t["fail"]
    t["rate"] = round(t["hit"] / done * 100) if done >= 3 else None
    tot = sum(n for _, n in rs)
    t["avg_r"] = round(sum(r * n for r, n in rs) / tot, 2) if tot else None
    return t


def chart(d5, sigs, bars=80, focus=None):
    """Compact bars + lines + markers for the phone to draw as an image. Window ends just after the focus signal (or the last bar)."""
    if d5 is None or len(d5) < 20:
        return None
    d = jp.prep(d5)
    end = len(d)
    if focus is not None:
        end = min(len(d), focus["i"] + 12)
    a = max(0, end - bars)
    w = d.iloc[a:end]
    rows = [{"t": ix.strftime("%H:%M"), "d": ix.strftime("%b %d"), "o": round(float(r.open), 2), "h": round(float(r.high), 2), "l": round(float(r.low), 2),
             "c": round(float(r.close), 2), "v": int(r.volume), "f": None if r.ema9 != r.ema9 else round(float(r.ema9), 2),
             "s": None if r.ema20 != r.ema20 else round(float(r.ema20), 2), "w": None if r.vwap != r.vwap else round(float(r.vwap), 2)} for ix, r in w.iterrows()]
    marks = [{"j": s["i"] - a, "side": s["side"], "price": s["price"], "stop": s["stop"], "tp1": s["tp1"], "name": s["name"]} for s in sigs if a <= s["i"] < end]
    return {"bars": rows, "marks": marks[-6:]}


# ---------------- AI: words / screenshots -> rules ----------------
SYSTEM = ("You turn a trader's description (and optional chart screenshots) into ONE trading preset for a rule engine. "
          "Reply with ONLY a JSON object with these keys: name (short), pattern (one of pullback, vwap_reclaim, breakout, gap_go), "
          "side (long, short or both), stop_pct (0.2-5, percent distance of the stop), target_r (0.5-5, target as a multiple of the risk), "
          "vol_mult (0-5, volume must be this many times the recent average; 0 = ignore), above_vwap (true/false), lookback (5-60 candles, for breakout), "
          "gap_pct (0.5-20, for gap_go), after_hours (true/false: do extended-hours candles count), notes (one plain sentence: what you saw or assumed). "
          "pullback = trend, pull back to the moving average, confirming candle (the app's JUMP IN). vwap_reclaim = price crosses VWAP with the trend. "
          "breakout = closes beyond the recent high/low. gap_go = gaps at the open and keeps going. If a screenshot shows markers like JUMP IN, BUY, SELL or "
          "BUY? / SELL?, base the preset on the setup those markers point at. Never mention position size, loss limits or Live trading.")


def from_text(text, images=None):
    """Returns (rules, how). Uses the chosen AI provider; without a key falls back to simple keyword rules (text only)."""
    text = (text or "").strip()
    try:
        from .analyst import _api_error, _pick_model, ai_key, ai_post
        key = ai_key()
    except Exception:
        key = ""
    if key:
        content = [{"type": "image", "source": {"type": "base64", "media_type": im["media_type"], "data": im["data"]}} for im in (images or [])]
        content.append({"type": "text", "text": text or "Make a preset from the setup shown in the attached chart."})
        r = ai_post(120, {"model": _pick_model(key), "max_tokens": 700, "system": SYSTEM, "messages": [{"role": "user", "content": content}]})
        if r.status_code != 200:
            raise RuntimeError(_api_error(r.status_code, r.text))
        out = "".join(b.get("text", "") for b in r.json().get("content", []))
        m = re.search(r"\{.*\}", out, re.S)
        if not m:
            raise RuntimeError("The AI did not return a preset. Try describing the setup differently.")
        try:
            raw = json.loads(m.group(0))
        except json.JSONDecodeError:
            raise RuntimeError("The AI's answer was cut off. Try again.")
        return normalize(raw), "ai"
    if images:
        raise RuntimeError("Reading screenshots needs your AI key (Broker keys, AI). Describe the setup in words instead.")
    return keyword_rules(text), "keywords"


def keyword_rules(text):
    t = text.lower()
    r = dict(DEFAULTS)
    r["pattern"] = ("gap_go" if "gap" in t else "breakout" if "break" in t else "vwap_reclaim" if "vwap" in t else "pullback")
    r["side"] = "both" if ("short" in t and ("buy" in t or "long" in t)) else "short" if ("short" in t or "sell" in t) else "long"
    m = re.search(r"(\d+(?:\.\d+)?)\s*%\s*stop|stop\D{0,12}(\d+(?:\.\d+)?)\s*%", t)
    if m:
        r["stop_pct"] = float(m.group(1) or m.group(2))
    m = re.search(r"(\d+(?:\.\d+)?)\s*(?:x|r)\b", t)
    if m:
        r["target_r"] = float(m.group(1))
    r["after_hours"] = not ("regular hours only" in t or "no after" in t)
    r["name"] = (text[:28] or "My preset").strip()
    return normalize(r)


# ---------------- store ----------------
def _blank():
    return {"presets": [], "plans": {"day": "", "items": [], "ran": [], "at": ""}, "auto_log": []}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
            b = _blank()
            b.update({k: d[k] for k in b if k in d})
            return b
        except Exception:
            return _blank()


def save(d):
    with LOCK:
        try:
            FILE.write_text(json.dumps(d))
        except Exception:
            pass


def add(rules, auto_paper=False):
    with LOCK:
        d = load()
        rules = normalize(rules)
        rules.update(id="p" + str(int(time.time() * 1000))[-9:], enabled=True, auto_paper=bool(auto_paper), created=datetime.now().strftime("%Y-%m-%d"))
        d["presets"] = (d["presets"] + [rules])[-12:]
        save(d)
        return rules


def update(pid, **kw):
    with LOCK:
        d = load()
        for p in d["presets"]:
            if p["id"] == pid:
                for k in ("enabled", "auto_paper"):
                    if k in kw and kw[k] is not None:
                        p[k] = bool(kw[k])
                save(d)
                return p
    return None


def delete(pid):
    with LOCK:
        d = load()
        d["presets"] = [p for p in d["presets"] if p["id"] != pid]
        d["plans"]["items"] = [x for x in d["plans"]["items"] if x.get("preset_id") != pid]
        save(d)


def review(fetch5, syms, presets, now):
    """Daily pattern review: which of your presets lined up on the latest session of each stock? fetch5(sym) -> 5-minute bars (45 days).
    Returns plan items sorted by the preset's own record on that stock."""
    items = []
    for sym in syms:
        try:
            d5 = fetch5(sym)
        except Exception:
            d5 = None
        if d5 is None or len(d5) < 60:
            continue
        last_day = str(d5.index[-1].date())
        for p in presets:
            if not p.get("enabled", True):
                continue
            sigs = scan(p, d5)
            today = [s for s in sigs if s["day"] == last_day]
            if not today:
                continue
            s = today[-1]
            t = backtest(p, d5, sigs=sigs)
            items.append({"symbol": sym, "preset_id": p["id"], "preset": p["name"], "side": s["side"], "t": s["t"], "day": last_day, "entry": s["price"], "stop": s["stop"],
                          "target": s["tp1"], "why": s["why"], "rate": t["rate"], "n": t["n"], "avg_r": t["avg_r"], "chart": chart(d5, sigs, focus=s)})
    items.sort(key=lambda x: ((x["rate"] if x["rate"] is not None else -1), x["n"]), reverse=True)
    return items[:12]
