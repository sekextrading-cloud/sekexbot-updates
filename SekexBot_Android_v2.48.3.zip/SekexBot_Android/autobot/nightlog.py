"""v2.48.2: Overnight recorder - saves what the market does 8 PM - 4 AM (the one window the 6-month history never covered), so it can be TESTED before any bot trades it.
It only RECORDS. It never places an order.

Per night (the evening it starts, e.g. 2026-11-12 = the night of Nov 12 -> 13), in  data/overnight/<night>/ :
  quotes_<src>.csv   ts,sym,bid,ask,qts      one snapshot per stock per minute  (the SPREAD is what decides whether a night trade can ever pay)
  bars_<src>.csv     ts,sym,open,high,low,close,volume   1-minute candles, rewritten every 30 min and once more after 4 AM
  <src> is  phone  (this app)  or  pc  (tools/overnight_collector.py on a computer).  The two sources are merged when the data is analysed.
Alpaca trades overnight Sunday-Thursday evenings (24/5), so the recorder runs those nights."""
import io
import json
import threading
import zipfile
from datetime import timedelta

import pandas as pd

from .config import DATA_DIR

DIR = DATA_DIR / "overnight"
LOCK = threading.Lock()
SRC = "phone"
NIGHT_START, NIGHT_END = 1200, 240            # 8:00 PM - 4:00 AM
BARS_EVERY_S = 25 * 60


def night_of(now):
    """The night this moment belongs to (its evening date as text), or None outside the 8 PM - 4 AM window / on nights Alpaca is closed."""
    m = now.hour * 60 + now.minute
    if m >= NIGHT_START and now.weekday() in (6, 0, 1, 2, 3):
        return str(now.date())
    if m < NIGHT_END and (now - timedelta(days=1)).weekday() in (6, 0, 1, 2, 3):
        return str((now - timedelta(days=1)).date())
    return None


def cfg():
    try:
        return {"on": bool(json.loads((DIR / "cfg.json").read_text()).get("on", True))}
    except Exception:
        return {"on": True}


def set_on(on):
    with LOCK:
        DIR.mkdir(parents=True, exist_ok=True)
        (DIR / "cfg.json").write_text(json.dumps({"on": bool(on)}))
    return cfg()


def _ndir(night):
    p = DIR / night
    p.mkdir(parents=True, exist_ok=True)
    return p


def append_quotes(night, rows, src=SRC):
    """rows: [(ts_iso, sym, bid, ask, qts_iso)]"""
    if not rows:
        return 0
    f = _ndir(night) / f"quotes_{src}.csv"
    with LOCK:
        new = not f.exists()
        with open(f, "a", encoding="utf-8") as fh:
            if new:
                fh.write("ts,sym,bid,ask,qts\n")
            for r in rows:
                fh.write(",".join(str(x) for x in r) + "\n")
    return len(rows)


def save_bars(night, frames, src=SRC):
    """frames: {sym: DataFrame(open, high, low, close, volume) indexed by time}.  Merged with what is already saved (no duplicates)."""
    parts = []
    for sym, df in (frames or {}).items():
        if df is None or not len(df):
            continue
        d = df[["open", "high", "low", "close", "volume"]].copy()
        d.insert(0, "sym", sym)
        d.index.name = "ts"
        parts.append(d.reset_index())
    if not parts:
        return 0
    new = pd.concat(parts)
    new["ts"] = pd.to_datetime(new["ts"], utc=True).dt.tz_convert("America/New_York").dt.strftime("%Y-%m-%d %H:%M")
    f = _ndir(night) / f"bars_{src}.csv"
    with LOCK:
        if f.exists():
            try:
                new = pd.concat([pd.read_csv(f, dtype={"ts": str}), new])
            except Exception:
                pass
        new = new.drop_duplicates(["sym", "ts"], keep="last").sort_values(["ts", "sym"])
        tmp = f.with_suffix(".tmp")
        new.to_csv(tmp, index=False)
        tmp.replace(f)
    return len(new)


def status():
    nights = []
    size = 0
    if DIR.exists():
        for p in sorted([x for x in DIR.iterdir() if x.is_dir()], reverse=True)[:30]:
            q = b = 0
            syms, srcs, last = set(), set(), ""
            for f in p.glob("quotes_*.csv"):
                try:
                    df = pd.read_csv(f)
                    q += len(df)
                    syms |= set(df["sym"].unique())
                    srcs.add(f.stem.split("_", 1)[1])
                    if len(df):
                        last = max(last, str(df["ts"].iloc[-1]))
                except Exception:
                    pass
            for f in p.glob("bars_*.csv"):
                try:
                    df = pd.read_csv(f, usecols=["sym"])
                    b += len(df)
                    syms |= set(df["sym"].unique())
                    srcs.add(f.stem.split("_", 1)[1])
                except Exception:
                    pass
            for f in p.iterdir():
                size += f.stat().st_size
            nights.append({"night": p.name, "quotes": q, "bars": b, "symbols": len(syms), "sources": sorted(srcs), "last": last})
    return {"on": cfg()["on"], "nights": nights, "kb": round(size / 1024)}


def export_zip():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        if DIR.exists():
            for p in sorted(DIR.rglob("*.csv")):
                z.write(p, p.relative_to(DIR).as_posix())
    return buf.getvalue()
