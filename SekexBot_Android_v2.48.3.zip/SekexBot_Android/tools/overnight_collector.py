#!/usr/bin/env python3
"""SekexBot overnight collector for a COMPUTER (the backup to the phone's Overnight recorder).

It only RECORDS prices. It never places an order and never touches your account.
Every night (Sun - Thu evenings, 8 PM - 4 AM New York time) it saves, in a folder named  overnight  next to this file:
  overnight/<night>/quotes_pc.csv   one bid / ask snapshot per stock per minute   (the spread)
  overnight/<night>/bars_pc.csv     1-minute candles, refreshed every 25 minutes and once after 4 AM
Same layout as the phone's recorder, so the two are merged for the test.

Setup (once):   pip install alpaca-py pandas
Keys:           a file named  .env  next to this script with   ALPACA_PAPER_KEY=...   and   ALPACA_PAPER_SECRET=...   (data keys only; paper keys are fine)
Stocks:         symbols.txt next to this script (one ticker per line or comma separated). Without it, the default list below is used.
Run:            python overnight_collector.py        (leave it open overnight; plug the computer in and set sleep to "Never")
                python overnight_collector.py --once-now   records one snapshot right now and exits (a quick test that your keys work)
Then each morning, send the  overnight  folder (zip it) together with the phone's export."""
import argparse
import os
import sys
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

NY = ZoneInfo("America/New_York")
HERE = Path(__file__).resolve().parent
OUT = HERE / "overnight"
DEFAULT = "AMZN AVGO BE GOOGL HOOD HPE INTC IREN LMT META MRVL MSFT MU NFLX NKE NU NVDA PANW SPCX ST T TEM TMUS TSLA TSM WMT SPY QQQ AAPL AMD ORCL".split()
NIGHT_START, NIGHT_END, GRACE = 1200, 240, 10
BARS_EVERY = 25 * 60


def load_env():
    f = HERE / ".env"
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))
    key = os.getenv("ALPACA_PAPER_KEY") or os.getenv("ALPACA_LIVE_KEY") or os.getenv("APCA_API_KEY_ID")
    sec = os.getenv("ALPACA_PAPER_SECRET") or os.getenv("ALPACA_LIVE_SECRET") or os.getenv("APCA_API_SECRET_KEY")
    if key and (key.upper().startswith("PASTE") or (sec or "").upper().startswith("PASTE")):
        sys.exit("Open the file named .env in Notepad and replace PASTE_KEY_HERE / PASTE_SECRET_HERE with your Alpaca paper key and secret, then run this again.")
    if not key or not sec:
        sys.exit("No Alpaca keys found. Put ALPACA_PAPER_KEY=... and ALPACA_PAPER_SECRET=... in a file named .env next to this script.")
    return key, sec


def symbols():
    f = HERE / "symbols.txt"
    if f.exists():
        out = [x.strip().upper() for x in f.read_text(encoding="utf-8").replace(",", "\n").split() if x.strip()]
        if out:
            return list(dict.fromkeys(out))
    return DEFAULT


def night_of(now):
    m = now.hour * 60 + now.minute
    if m >= NIGHT_START and now.weekday() in (6, 0, 1, 2, 3):
        return str(now.date())
    if m < NIGHT_END and (now - timedelta(days=1)).weekday() in (6, 0, 1, 2, 3):
        return str((now - timedelta(days=1)).date())
    return None


def keep_awake():
    """Windows: ask the PC not to go to sleep while this runs."""
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    except Exception:
        pass


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--once-now", action="store_true", help="record one quote snapshot right now (any hour) and exit")
    a = ap.parse_args()
    try:
        import pandas as pd
        from alpaca.data.enums import DataFeed
        from alpaca.data.historical import StockHistoricalDataClient
        from alpaca.data.requests import StockBarsRequest, StockLatestQuoteRequest
        from alpaca.data.timeframe import TimeFrame
    except ImportError:
        sys.exit("Missing libraries. Run:  pip install alpaca-py pandas")
    key, sec = load_env()
    client = StockHistoricalDataClient(key, sec)
    syms = symbols()
    feed = DataFeed.OVERNIGHT           # the overnight feed that every Alpaca data plan can read (15-minute delayed bars on the free plan)
    OUT.mkdir(exist_ok=True)
    keep_awake()

    def quotes(night):
        rows = []
        q = client.get_stock_latest_quote(StockLatestQuoteRequest(symbol_or_symbols=syms, feed=feed))
        now = datetime.now(NY).isoformat(timespec="seconds")
        for s, v in q.items():
            if v.bid_price and v.ask_price:
                rows.append(f"{now},{s},{float(v.bid_price)},{float(v.ask_price)},{v.timestamp.astimezone(NY).isoformat(timespec='seconds')}")
        d = OUT / night
        d.mkdir(parents=True, exist_ok=True)
        f = d / "quotes_pc.csv"
        new = not f.exists()
        with open(f, "a", encoding="utf-8") as fh:
            if new:
                fh.write("ts,sym,bid,ask,qts\n")
            fh.write("\n".join(rows) + ("\n" if rows else ""))
        return len(rows)

    def bars(night, now):
        d0 = datetime.fromisoformat(night).replace(tzinfo=NY)
        start, end = d0 + timedelta(hours=20), min(now, d0 + timedelta(days=1, hours=4))
        parts = []
        for i in range(0, len(syms), 15):
            df = None
            for e2 in (end, min(end, now - timedelta(minutes=16))):
                try:
                    df = client.get_stock_bars(StockBarsRequest(symbol_or_symbols=syms[i:i + 15], timeframe=TimeFrame.Minute, start=start, end=e2, feed=feed)).df
                    if df is not None and not df.empty:
                        break
                except Exception:
                    df = None
            if df is not None and not df.empty:
                parts.append(df.reset_index())
        if not parts:
            return 0
        new = pd.concat(parts).rename(columns={"symbol": "sym", "timestamp": "ts"})[["ts", "sym", "open", "high", "low", "close", "volume"]]
        new["ts"] = pd.to_datetime(new["ts"], utc=True).dt.tz_convert("America/New_York").dt.strftime("%Y-%m-%d %H:%M")
        f = OUT / night / "bars_pc.csv"
        if f.exists():
            new = pd.concat([pd.read_csv(f, dtype={"ts": str}), new])
        new = new.drop_duplicates(["sym", "ts"], keep="last").sort_values(["ts", "sym"])
        new.to_csv(f, index=False)
        return len(new)

    if a.once_now:
        n = quotes(str(datetime.now(NY).date()) + "_test")
        print(f"OK: saved {n} quotes for {len(syms)} stocks into {OUT}. (A 0 here at the wrong hour is normal; a key error is not.)")
        return
    print(f"SekexBot overnight collector: {len(syms)} stocks. Records Sun-Thu nights 8 PM - 4 AM New York time. Ctrl+C to stop. Folder: {OUT}")
    bars_at, final = 0.0, ""
    while True:
        try:
            now = datetime.now(NY)
            night = night_of(now) or night_of(now - timedelta(minutes=GRACE))
            if night:
                late = night_of(now) is None
                n = 0 if late else quotes(night)
                if time.time() - bars_at >= BARS_EVERY or (late and final != night):
                    bars_at = time.time()
                    nb = bars(night, now)
                    if late:
                        final = night
                    print(f"{now:%a %I:%M %p}  quotes {n}  candles saved {nb}")
                elif n and now.minute % 10 == 0:
                    print(f"{now:%a %I:%M %p}  quotes {n}")
            elif now.minute == 0:
                print(f"{now:%a %I:%M %p}  waiting for tonight's 8 PM start (Sun-Thu)")
        except KeyboardInterrupt:
            raise
        except Exception as ex:
            print(f"{datetime.now(NY):%a %I:%M %p}  problem (will retry): {str(ex)[:120]}")
        time.sleep(60 - datetime.now().second)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("stopped")
