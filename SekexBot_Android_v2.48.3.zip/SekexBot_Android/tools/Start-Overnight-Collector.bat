@echo off
cd /d "%~dp0"
echo Installing the two small libraries (first time only)...
python -m pip install --quiet alpaca-py pandas
echo.
echo Recording overnight prices (Sun-Thu 8 PM - 4 AM New York). Leave this window open and the PC plugged in.
python overnight_collector.py
pause
