@echo off
cd /d "%~dp0"
python -m pip install --quiet alpaca-py pandas
python overnight_collector.py --once-now
pause
