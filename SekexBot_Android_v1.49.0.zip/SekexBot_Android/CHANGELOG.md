# SekexBot changelog

Version numbers are MAJOR.MINOR.PATCH. MAJOR means a breaking change to settings or data, MINOR means a new feature, and PATCH means a fix.
The running version shows in the dashboard header and in the console window when SekexBot starts.

## 1.49.0 — 2026-09-29
- 🤖 Fix with Claude (⚙ → Help & repair): describe a bug in plain words and Claude reads the relevant code, writes a fix and explains it in plain English with a risk level (and a warning if it changes how orders, stops or exits behave). The app tests every fix on a copy first (Python must compile, the dashboard's JavaScript must parse, the copy must start in simulator mode, load the dashboard and run 8 s without errors); a fix that fails is never applied. You review it (plain summary + the code change) and enter your Live PIN to apply; the changed files are backed up and the app restarts (trading resumes). If a fixed app won't start 3 times, or a patched file won't compile, it rolls back by itself; Undo (PIN) restores the last backup. Never touches keys, .env or data; only on the phone itself, not over the remote link. Uses your Claude API key and credits.

## 1.48.1 — 2026-09-29
- Fixed: auto-harvest (♻) stopped out a position on one bad quote when the overnight session started at 8 PM (TEM, Sep 29). Its protective stop now uses the mid price instead of the bid, ignores the first 3 minutes of each session and any time the spread is too wide, and needs price to stay beyond the stop for 25 seconds (straight away only at twice the stop). Overnight (8 PM - 4 AM) auto-harvest pauses and holds the position as is, then resumes at 4 AM pre-market.

## 1.48.0 — 2026-09-29
- ⏰ Close later: a new button on each of your positions sets a plan that closes the whole position by itself at the first of: a time (presets: tonight 7:55 PM, 4:00 AM pre-market, 9:30 AM open, 3:55 PM, or any time you pick), the trend turning against you (a NEW 3-minute ribbon flip red for a long / green for a short), or a take-profit / stop price. It runs on the phone even with the dashboard closed, is saved across restarts, uses extended-hours limit orders outside 9:30-4:00 and re-prices every minute until filled, and waits for the next session if it triggers while the market is shut. If Alpaca refuses to cover a short overnight it keeps trying and closes at 4 AM pre-market. Alerts with beep + voice when the plan fires and when it fills. Tapping Close yourself removes the plan; setting a plan turns off ♻ auto-harvest for that stock.

## 1.47.2 — 2026-09-29
- More close fixes: closing a BOT short after hours now prices the cover at the ask (was the bid, so it could sit unfilled); tapping Close again re-prices a bot exit that hasn't filled; a bot trade from regular hours that is still open after hours now closes with an extended-hours limit (the market close was being rejected silently); a regular-hours bot close that Alpaca rejects now shows the error instead of 'ok'. A full Close turns off auto-harvest (♻) for that stock so it can't buy back in. Watchlist warnings refresh right away when you add or remove a ticker.

## 1.47.1 — 2026-09-29
- Fixed: Close did nothing for SHORT positions in pre-market / after-hours (it refused with 'Covering a short needs regular hours'). Close now sends an extended-hours limit buy to cover a little above the ask (0.3%), the same way longs are sold; press Close again to re-price if it hasn't filled.

## 1.47.0 — 2026-09-29
- Beep and voice alerts for BUY / SELL on your watchlist, with an ON / OFF speaker button in the top bar (next to the bell) that mutes or unmutes everything in one tap, also from the remote link. Phone (works with the screen off, needs Termux:API): the notification plays a sound and vibrates (BUY = 2 short buzzes, SELL = 1 long, early BUY?/SELL? warning = 3 quick taps), and the phone says it out loud, e.g. 'S P C X. Sell signal. Trend turned down.' or 'M E T A. Buy warning. 74 percent.' Early warnings are a new alert (Settings > Alerts), spoken from 65% confidence by default (Warn me from: 60-80% or Never). Dashboard, while open: a rising two-tone beep for BUY, falling for SELL, three taps for warnings, a spoken alert and a colored banner (tap the screen once so the phone allows sound). While the dashboard is speaking, the phone's own voice stays quiet so you never hear it twice. New Settings switches: Beep on BUY / SELL, Say it out loud (with Test).

## 1.46.0 — 2026-09-29
- Early BUY? / SELL? warnings on the chart, for every watchlist stock. Dashed amber boxes appear when the trend ribbon is about to flip, before the confirmed BUY/SELL (the yellow line closing in on the white line, price crossing the yellow line and VWAP, the white line flattening, volume picking up). Each has a confidence %; past ones are graded ✓ (the flip followed within 6 candles) or ✗ (false alarm), and the chart shows the stock's hit rate, how many candles early, and the average price gained vs waiting. Warnings under 60% are hidden. Display only: the bot never trades on them. Watchlist chips now show each stock's trend dot, an amber ring plus BUY?/SELL? % when a warning is live, and 'no data' when Alpaca sends no prices (e.g. QNT). Tapping a warned chip, the new ⚡ Trade button or 'Open trade popup' opens the quick trade sheet with a live chart (1m/3m/5m/15m) and the warning, and the suggested side is outlined. Plain-English ⓘ popups on every chart term: VWAP, uptrend/downtrend, fast/slow lines, ribbon flips, BUY?/SELL?, O/H/L/C, volume, measure tool, after-hours.

## 1.45.0 — 2026-09-29
- Two safety rails: (1) no single position larger than 25% of your equity (margin buying power is ~4x, so one trade could be the whole account, like the 6,043-share KNDI trade); (2) a setup with fewer than 20 closed trades trades at 35% size (70% if it is already winning), full size only after it proves itself. Switch on the Self-fix card.

## 1.44.0 — 2026-09-29
- Let winners run and pick better: SCALE exit now takes 1/4 at +1R with the stop only to -0.5R (break-even after +2R), wider 1.8 ATR trail, target 8R; scalp profiles no longer bank at +0.15R (switch: Let winners run); ribbon-flip exit needs 3 confirmations. Entry filters: no stocks under $2, no trades against a clear early direction call.

## 1.43.0 — 2026-09-29
- Self-fix: the bot reviews its own last 12 closed trades of every setup. Losing setups are benched (one half-size probe trade a day until they recover); winning setups are promoted (ranked first, up to +30% size). New Self-fix card shows each setup's status; on by default, switchable.

## 1.42.0 — 2026-09-29
- Double-tap any row (pre-market timeline, shortlist, evening candidates, movers, setups) to open the quick BUY / SELL sheet. Single tap still opens the chart. Quantity is remembered from your last quick trade.

## 1.41.3 — 2026-09-29
- Anti-churn block is now only 2 losing closes on the same stock within 30 minutes (replaces the max-trades and wait-time rules). The dashboard shows blocked stocks with a Release button; release also clears the older cooling-off counters.

## 1.41.2 — 2026-09-29
- Stop churning one stock: always-on anti-churn guard read from the trade database (max 4 trades and 2 losses per symbol per day, 8 min between trades, 20 min after a loss). Works across restarts and cannot be switched off.

## 1.41.1 — 2026-09-29
- Pre/after-market trades no longer stop out too early: stop is at least 0.45% (or 1.2 ATR) from entry, price (mid) must stay beyond the stop 25 s before exiting (immediate only at -1.4R), and the ribbon-flip exit waits 6 minutes and never cuts a trade already above +0.9R.

## 1.41.0 — 2026-09-29
- Automatic system now finds and trades BOTH longs and shorts (mode picker: Longs + shorts / Shorts only / Longs only). Borrow check applies to shorts only; hard-to-borrow names stay on the shortlist as long-only candidates.

## 1.40.1 — 2026-09-29
- Fixed pre-market orders being rejected for insufficient buying power (BMNR: needed $5,584, had $5,410). Extended-hours checks did not refresh the account, so sizing used a stale buying-power number. Now the account is re-read before every pre-market or after-hours order, the quantity is capped to 95% of real buying power, and if Alpaca still says insufficient buying power the bot reads the real numbers from the error and retries once with a smaller quantity. Regular-hours orders and the manual auto-harvest re-entry get the same shrink-to-fit.

## 1.40.0 — 2026-09-28
- Auto re-entry that jumps back in. After a profitable exit the bot (all setups, regular hours and pre-market/after-hours) gets back in on the same side in two ways: on a pullback of at least a quarter of the stock's normal range with the latest 1-minute bar turning back, or, if there is no pullback and the stock keeps running, as soon as a completed 1-minute bar closes at a new high (or low, for shorts) at least 0.3 of that range past the exit price, with the ribbon and VWAP agreeing. Up to 3 re-entries per stock in a row, within 90 minutes, never after a loss, a ribbon turn against you, a daily-loss halt or an end-of-day flatten; bought or shorted with the same take-profit-along-the-way exit. The manual auto-harvest (the ♻ button) now does the same: back in on a pullback, or after 45 seconds if it keeps running past the harvest price. Switch: Controls > Advanced > Auto re-entry (on by default). New REENTRY trades show in the journal.

## 1.39.0 — 2026-09-28
- Automatic short system. One tap (Enable automatic short system, on the card near the top) for the selected PAPER or LIVE account: it starts the bot, turns on shorts only, morning reversal, the pre-market plan and (with SIP) late-day overnight shorts, then waits for a fresh, confirmed 1-minute short signal before ordering. LIVE asks for your Live PIN. Before every short it rechecks Alpaca's borrow_status (must be easy_to_borrow and shortable; hard-to-borrow names are skipped). Overnight homework: each night after 4:35 PM the whole market is ranked by volume, trade count and movement (plus your watchlist) into a short shortlist, and from 8:00 AM ET it is rechecked every 15 minutes and added to the live scanner with the new movers. Harvest and re-entry: short-system trades use the exit that takes portions near +1R and +2R and trails the rest, and after a profitable exit the same stock is only traded again on a distinct new signal (a different setup, or a 15-minute pause plus a real bounce). Long signals are ignored while the system is on. Turn it off from the same button.

## 1.38.0 — 2026-09-28
- Pre-market timeline: from 4 AM the bot snapshots the big movers at 4 AM, 7 AM, 8:30 and 9:15 (4 AM needs the SIP feed; you have it) and shows how each one moved (holding, faded, extending) in a new Pre-market timeline card, with a phone alert at the 7 AM and 9:15 checks. Short at open: gappers up 1.5%+ that have faded off their pre-market high and are under VWAP go on a short-at-open list, and the new OPEN_SHORT strategy shorts the first close below the pre-market low between 9:31 and 9:50 (stop above the early high or VWAP). On by default; switch: Controls > Advanced > Pre-market plan. Pre-market and after-hours trading already run from 4 AM once the feed is SIP.

## 1.37.0 — 2026-09-28
- Three new tools, all off by default except the review. (1) Morning reversal (Controls > Advanced): looks for a second rejection of the opening high (the first 5 minutes' high), then waits for a completed 1-minute close below the low since that rejection before it shorts, 9:40-11:30, stop just above the opening high. The opening window is ignored, so a 9:35 poke and fake-out does not count, and a breakout above the high cancels it. (2) Pre-close overnight short (Controls > Advanced): scans 3:10-3:35 PM for a spike that is failing (up 3%+ and faded 40% off the high) or a weak close (down 3%+, near the low), under VWAP with a red ribbon, and shorts shares with a broker-held GTC stop and target placed once filled. Needs the SIP feed and a short-enabled account, skips Fridays and days before holidays, and skips earnings and risky news. The bot covers by 10:15 AM if neither order has hit. A GTC stop can fill far worse if the stock gaps up at the open. Shares only, because Alpaca has no extended-hours options orders. (3) Review evening candidates button and card: lists the prior session's setups; each is a watch item that is scanned the next morning, and no order is placed until a fresh signal confirms. It also runs by itself after 4:30 PM. New command: sekex replay SYMBOL DATE prints when each strategy would have fired on that day using your Alpaca data. Fixed: release zips no longer include the simulator's test data folder.

## 1.36.0 — 2026-09-28
- Automatic direction trading: when a Big mover gets a strong LONG or SHORT call (score 45+, most signals agreeing, not stretched from VWAP), the bot now trades it by itself between 9:33 and 11:00 (new DIR_CALL strategy, ridden with the take-profit-along-the-way exit) and sends one phone alert per stock per day. The call uses pre-market bars, so it works from the opening bell instead of 9:44. It is on in Balanced, Aggressive and Max, and off in Conservative (Controls > Advanced, Trade strong early direction calls). DIR_CALL trades are paused automatically if the overnight study finds that kind of call right less than half the time over 20+ calls. The study also replays DIR_CALL each night so the learner sizes it.

## 1.35.0 — 2026-09-28
- Early direction call: every Big mover and any ticker you type into the manual ticket now shows LONG, SHORT or WAIT with a score and the reasons. It is a weighted vote of price vs VWAP, ribbon, swing structure (higher highs or lower lows), 15-minute momentum, buying vs selling volume, position in the day's range, SPY/QQQ, and how that stock's gaps have behaved (follow through or fade) in the overnight study. It says WAIT when the votes disagree and flags when price is stretched from VWAP. The overnight study scores each 9:40 call against the next hour on past days and shows how often LONG, SHORT and STRONG calls were right.

## 1.34.0 — 2026-09-28
- Catch the morning trend and learn overnight. (1) The ribbon now starts from the pre-market bars, so it is ready at 9:30 instead of about 10:00, which is why early trends were missed. Entries open 2 minutes after the bell (was 5). (2) New PLAN_TREND strategy: a name on the Big movers list that gapped 0.8%+ and breaks its early high (or low, for shorts) with VWAP, ribbon and volume agreeing is bought or shorted right away; PLAN_TREND and GAP_GO trades are ridden with the SCALE exit (take profit along the way, trail the rest) instead of a quick scalp. (3) Overnight study: after 5 PM, overnight and on weekends the bot replays the last few trading days of your stocks minute by minute through every strategy and every exit style and teaches the learner, weighted at 0.3 of a real trade; each day is studied once. New Overnight study card with Study now and an on/off box.

## 1.33.0 — 2026-09-28
- Trading levels: pick Conservative, Balanced, Aggressive or Max in one tap instead of setting many boxes. Auto learns which of the first three works best in each session (pre-market, regular, after-hours) from your own trades, judged by average R per trade once a level has 8 trades in that session, and switches at each session start (it never picks Max on its own, and starts from Balanced/Conservative defaults while it learns). Change any single box under Advanced and the level becomes Custom. Existing setups keep their current switches as Custom. The daily max loss and session on/off boxes are never changed by Auto.

## 1.32.0 — 2026-09-28
- Automatic morning and night setup: the Big movers list now builds itself every 5 minutes in pre-market and after-hours even when the auto-trader is stopped (turn off with Controls > Auto-prep), and the last list stays on screen overnight and after a restart, with an as-of time, so it no longer goes empty. If your Alpaca account has the paid SIP data feed, SekexBot detects it at startup and switches to it, which gives the full 4 AM to 8 PM window (free IEX only covered 8 AM pre-market and after-hours until 5 PM). Positions are still flattened shortly before each session ends.

## 1.31.0 — 2026-09-28
- Auto-harvest: tick the new ♻ box on the manual ticket or quick-trade sheet (or tap ♻ on an open position). It sells for a small quick gain (about half the stock's normal 5-minute range, or when the gain starts to fade), then buys or shorts the same size again on a pullback when the ribbon still agrees. It repeats until you tap Stop, and stops on its own if the ribbon turns against you, the daily loss limit halts trading, or a trade goes 1.2 ranges against you (it closes that one). Works long or short, with the auto-trader on or off.
- Reopen last close: one tap, no confirmation, puts back the position you last closed by hand (same stock, side and size), and turns auto-harvest back on if it was on. Shows under Positions after you close something.

## 1.30.1 — 2026-09-28
- Publish in one command: run `sekex publish` in Termux after saving a new zip to Downloads. It finds the newest zip, writes latest.json (version, checksum, notes), uploads the zip and then latest.json to your GitHub update repo, and sets the app's update link. GitHub repo and token are asked for once and stay on the phone.

## 1.30.0 — 2026-09-28
- Pre-open mode: pre-market and after-hours trading are now ON by default (your existing settings switch on once). The bot scans for movers every 5 minutes, keeps taking pre-market entries until 9:20 instead of stopping at 9:05, and only closes pre-market trades in the last 4 minutes before the open.
- Gap fade: new GAP_FADE strategy for a gap that fails. A gap-up losing the opening-range low and VWAP is shorted (SPCX on Sep 28). A gap-down reclaiming the range high and VWAP is bought. Runs 9:40-10:45. Gap and go now starts at 2% gaps, long or short (META on Sep 28).
- Evening movers: new EXT_TREND strategy trades pre-market and after-hours continuation of 1.2%+ movers, long or short, when the ribbon, VWAP and a fresh break agree.
- Big movers list: new card with the top 10 names moving 1%+ from the last close, each with a plan (GO, FADE or WAIT), side, trigger and target. It works in pre-market, at the open and in after-hours, and sends one alert around 8:55 AM and 4:05 PM.

## 1.29.0 — 2026-09-28
- Shorts on by default: SELL flips and short setups now trade in regular hours, and in pre-market and after-hours when the stock is shortable and your account can short. Overnight stays long-only. Stops, take-profits and exits work for shorts in every session.
- Why no trade?: a new panel lists every signal or ribbon flip the bot saw but skipped, with the exact reason (flip too old, below VWAP, time-of-day filter, cooling off, cannot short, slots full, sizing and more). Filter it by symbol.
- Trade every flip: optional switch that takes each fresh ribbon BUY/SELL flip on your watchlist and picks. It skips the VWAP, learner and time-of-day checks for flips only. The daily loss limit and position sizing still apply.

## 1.28.0 — 2026-09-28
- ✋ One-tap manual trading: no more 'Send this order?', 'Close?' or LIVE-money pop-ups on the order ticket, the quick trade sheet or Close buttons. The order goes straight away. To bring the pop-ups back, tick 'Ask before sending or closing manual trades' in Controls. Opening a short when you don't own the stock still asks once, because losses are unlimited.

## 1.27.0 — 2026-09-28
- 🧊 Cooling off is now optional (Controls). 'Cool off after 3 losses in a row' switches off the 20-minute pause and the half-size penalty. 'Symbol cooldown' switches off the wait before re-trading a stock and the skip after 2 losses in a day. Both are on by default. While the bot is cooling off, a ▶ Resume now button clears the pause, the penalty and today's cooldowns in one tap. The daily loss limit always stays on.

## 1.26.0 — 2026-09-28
- 💰 Quick harvest for scalps (Aggressive and Scalp modes, every session): once a scalp has been green for 2 checks in a row, it doesn't wait for the target. It banks the profit when momentum stalls (0.15R back from its best) or when it's near the target. The stock can be re-entered right away if the setup fires again; otherwise the slot goes to the next best candidate. Bug-check fixes: restoring open trades after a restart or a ↩ Revert no longer fails when versions store different trade fields, and log lines show the size weight rounded.

## 1.25.0 — 2026-09-28
- 🔥 Aggressive scalping (Controls, off by default): many fast trades in every session. It adds a MICRO_SCALP setup (1-minute burst over the last 3 bars on 2× volume, above VWAP) and trades every setup with ½ at +0.5R (the rest moves to break-even) and the rest at +1R, out within 8 minutes. Up to 6 positions at 60% size, checks every 10 s (5 s in extended hours), and shorter cooldowns. The daily loss limit still applies. 🔻 Flush short: a tight range that breaks down hard on 2× volume (like TSLA's drop), when shorting is on. 🔺 Flush bounce: the first strong green bar after a fast 2-ATR drop on a volume spike (in all sessions). Flush setups skip the ribbon wait and the time-of-day filter. 🎯 Setting up now: a live top-15 list of stocks coiling for a fast move before it happens (tight range, volume building, lean from VWAP, ribbon and highs/lows), with the likely direction, trigger price, target, expected move, a 0–100 Ready score and ⚡ breaking now. The stock picker now scans 30 names.

## 1.24.0 — 2026-09-28
- 💰 Profit harvesting in every session. Pre-market, after-hours and overnight trades now take profit along the way like regular hours: ⅓ at +1R (the rest moves to break-even), ⅓ at +2R, then a 1× ATR trail or a ribbon flip. Partial sells are marketable limit orders, the only kind Alpaca allows outside regular hours, and each one sends a 💰 alert. ⚡ New Scalp mode (Controls, off by default): ½ at +0.6R, the rest at +1.2R, out within 20 minutes, in every session. ⬆ Update progress: the update screen shows a progress bar, each install step with a ✓, elapsed time and a details log. The app keeps serving while it installs and only restarts at the end.

## 1.23.0 — 2026-09-27
- 🚀 Opening Drive setup (OPEN_DRIVE), modeled on your best trades (SPCX, VKTX, AMD at 9:30): a +2% gapper that breaks its first-5-minute high above VWAP on a volume surge, 9:35–9:50 (a gap-down short when shorting is on). 💰 Take profit along the way (on by default): the bot sells ⅓ at +1R and moves the stop to break-even, sells another ⅓ at +2R, and rides the rest with a 1× ATR trail or until the ribbon flips. A '💰 Took profit' alert fires each time, and the journal and learner count the whole trade. 🕒 Time-of-day filter from your own history: the bot skips new trades in the time slots where your last 90 days lose money (at least 30 trades; today that's midday, morning after the drive, after-hours and overnight), and still allows opening drives until 9:50. Switches for both are in Controls. ⬆ Updates: SekexBot checks for a new version every hour and, in Ask mode, shows Update now / Later / Skip this version; Manual mode never prompts. Every update saves the version it replaces (the last 3 are kept), and '↩ Revert to vX' in the Update screen (or 'sekex rollback X.Y.Z') goes back while keeping your data.

## 1.22.0 — 2026-09-27
- 🔍 Trend research (Manual tab): type a ticker (for example SPCX), choose 10–90 days and tap Study. It finds every big run up or down in the stock's own minute history. For each run you see the start and end times and prices, the move and how long it lasted, grouped as morning, midday or afternoon. It also shows when morning runs typically start, what was true as runs began (opening drive, opening-range break, above or below VWAP, volume surge) and which exit rule kept the most of each run (ribbon flip, VWAP cross, 2 closes against, 1× or 2× ATR trail). These results will shape the bot's new morning and wave strategies.
- 🔔 3:55 PM overnight test: buy (or short) at 3:55 PM and exit at 8 PM, 11 PM, 2 AM, 4 AM, 8 AM, 9:25, 9:35 or 10 AM. Shows average result, long and short win rates, and worst and best days, and highlights the best combination. It uses real overnight (24-hour session) prices where the stock trades overnight.

## 1.21.0 — 2026-09-27
- 📊 Trading stats (Positions tab): every trade in your Alpaca account, bot and manual, matched from buy to sell. Shows total P&L, win rate, average win and loss, and profit factor. P&L by time of day (pre-market, morning 9:30–11:30, midday, afternoon, after-hours, overnight); tap a time to filter. Your top 5 wins and worst 5 losses, bot vs. manual results, and each bot strategy's results. Covers 7 days to 1 year.
- 📰 Earnings and news: the order ticket shows whether the stock reports earnings today or before the next open, plus the latest headlines, with risky ones flagged (offering, halt, bankruptcy, delisting, investigation, reverse split, downgrade…). The auto-trader skips a stock on its earnings day, doesn't buy after-hours or overnight right before a pre-market report, and waits 30 minutes after a risky headline. It uses the free Nasdaq earnings calendar and Alpaca news. If either is unreachable, trading continues.
- 🛡 Safety net (⚙ Settings): a phone-offline alert through free healthchecks.io. The app pings every minute; if the phone dies, sleeps or loses internet, healthchecks.io alerts you by email, SMS, ntfy or Telegram. Nightly backups at 8:10 PM ET of the journal, learning memory and settings (never API keys or tokens) to Downloads/SekexBot/backups, keeping 14, with optional upload to a private GitHub repo. Back up now and Restore buttons included.

## 1.20.5 — 2026-09-27
- Charts at any hour: the chart now shows the last few days, including pre-market, after-hours and the overnight (24-hour) session, not just 9:30–4:00. Nights and weekends show the most recent real prices, the same as Robinhood's 24 Hour Market chart. It uses Alpaca's overnight feed (BOATS on SIP accounts, Alpaca's overnight feed otherwise). Extended hours are lightly shaded and overnight is shaded blue. When nothing is trading, the header says when the last trade happened.

## 1.20.4 — 2026-09-27
- Take profit after a halt: every winner kept open gets a profit lock, set at break-even or better and then at half of its best gain, rising as the price climbs. If the price falls back to the lock, the position is sold (limit orders in extended hours) and you get a "💰 Took profit" alert. This covers manual positions too. Bot trades also get their stop at Alpaca raised to the lock. Profit locks survive an app restart.

## 1.20.3 — 2026-09-27
- Daily loss limit: when it's hit, the bot now closes only the **losing** positions (bot and manual) and keeps the winners open. Winners keep their stop-loss and the bot keeps trailing them; it just opens no new trades until the next day (8 PM ET). In extended hours the losers are closed with limit orders.

## 1.20.2 — 2026-09-27
- Auto-trade safety fixes: after switching from PAPER to LIVE on the same day, the bot could compare your live balance with the paper account's starting balance, read it as a huge loss, and close all live positions. The start-of-day balance is now kept separately for Paper and Live, and any figure far off your real equity is ignored. Updated for FINRA's retirement of the pattern-day-trader rule (Alpaca's Intraday Margin Framework, since June 4, 2026). No day-trade counting and no $25k minimum: the bot sizes within intraday buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders. The app keeps working after Alpaca removes the old day-trade fields from its API on July 6, 2026. A position the bot can't close now raises an alert instead of failing silently. Saved halts and loss streaks are again restored correctly after a restart (the new always-on balance display could skip them).

## 1.20.1 — 2026-09-27
- Fixes: the account bar and Account card now show your balance, buying power and today's P&L at all times, including nights and weekends (they were blank while the market was closed). Switching the data feed to SIP now works while the auto-trader is running — it checks your account really has SIP, switches, and restarts the bot — instead of silently flipping back to IEX.

## 1.20.0 — 2026-09-27
- Paper / Live switch: tap the PAPER / LIVE badge at the top to switch. Live needs your Live PIN, a real-money confirmation and working live keys (checked first); a running auto-trader stops, switches and restarts by itself. Too many wrong PINs lock the switch for 15 minutes. Live is unmistakable on every screen: a red frame, a '● LIVE — REAL MONEY' bar, a pulsing red badge, 'LIVE ·' on order buttons, a red browser bar and '🔴 LIVE' in the title and alerts. Account bar: balance, today's P&L ($ and %), open P&L, buying power and loss left stay pinned under the header on every screen and layout.

## 1.19.0 — 2026-09-27
- Interactive chart: touch or drag for a crosshair with time, OHLC, volume, trend (uptrend/downtrend), fast/slow lines and VWAP; tap to pin a point and measure the move to the crosshair ($, %, time, ribbon flips); pinch or scroll to zoom, drag to pan, double-tap to reset; 1m / 3m / 5m / 15m timeframes; volume bars and a VWAP line.

## 1.18.0 — 2026-09-27
- Streaming prices: real-time quotes and trades from Alpaca's websocket (up to 30 symbols on the free plan), pushed to the dashboard — the ticket, quick sheet and positions P&L move tick by tick with a STREAMING badge. The bot uses streamed prices too, and its extended-hours stops (watched by the app) now react within about a second instead of 15. Falls back to polling automatically if streaming isn't available. Help & repair now checks whether SIP data works on your account and can switch back to IEX with one tap.

## 1.17.0 — 2026-09-27
- Alerts: phone notifications (with Trade and Close buttons) for bot entries, fills, exits with P&L, stops raised, rejections, daily-loss halt, losing streaks, broker restrictions and stale data; watchlist trend alerts (ribbon flip, new high/low of day, VWAP, volume spike); price alerts; end-of-day summary. Optional copies to ntfy or Telegram, quiet hours, per-type switches, and a bell with the alert history. Faster trading: $1k / $5k / 1R / Max size buttons and a price-alert button in the quick sheet; tapping Trade on a notification opens the quick sheet. Help & repair: run checks, one-tap fixes (reconnect, restart, repair install, update), Ask AI (Claude explains errors in plain steps) and Send report. Fixes: bracket orders rejected while the market is closed are re-anchored on Alpaca's reference price automatically, order errors are explained in plain words, and suggested stops can no longer be unrealistically tight.

## 1.16.0 — 2026-09-26
- Live price everywhere, at any time: the order ticket and quick trade sheet show the price, day change (green/red), bid/ask and a LIVE dot, refreshing every 3 seconds, with the cost worked out as shares × price against your buying power. When the market is closed (nights, weekends, holidays) the price falls back to the last trade or last close, labeled 'as of', so orders can always be prepared. The trend chart shows the most recent session when the market is closed instead of 'Waiting for bars'.

## 1.15.0 — 2026-09-26
- Suggested stop-loss / take-profit: tick Attach stop-loss / take-profit and SekexBot proposes Scalp, Day and Swing levels from real support/resistance and the stock's volatility (ATR), with R multiple, trend check and a size that risks the bot's base amount. The quick trade sheet can protect orders with the Day levels automatically. Fix: prices now work on nights and weekends (last session's close), so orders can be prepared while the market is closed.

## 1.14.1 — 2026-09-26
- Gains show green and losses red everywhere, with a + sign on gains: today's P&L, the summary strip, every position and its %, bot trades (new P&L column), the journal, daily results and averages. Totals for Positions & orders, Open positions and Daily results. sekex status colors the day's P&L too.

## 1.14.0 — 2026-09-26
- New layout with a ⚙ gear: choose Tabs (Auto · Manual · Positions · More at the bottom), an Auto | Manual switch, or the classic one-page layout. Light, dark or follow-the-phone theme. A big Auto-trader on/off switch and an always-visible summary strip (equity, today, loss left, open trades). Your choices are remembered on each device.

## 1.13.0 — 2026-09-26
- Double-tap to trade: double-tap any stock in the picker, the scanner chips or your positions to open a quick trade sheet with the suggested size and big BUY / SELL (or SHORT) buttons. A single tap still opens the chart.

## 1.12.1 — 2026-09-26
- Turn off app button uses an icon every phone font can show.

## 1.12.0 — 2026-09-26
- Full order ticket like Alpaca's: Buy/Sell (Short), Market, Limit, Stop, Stop limit and Trailing stop orders, a quantity stepper, a limit price with tap-to-fill bid/ask, Time in force (Day, GTC, IOC, FOK, At the open, At the close) and Trading session (Market hours, Extended hours, 24 Hour Market). In-app updates: install a new version from the dashboard (⬆ Update) by picking the zip, or from an update link that is checked every 6 hours, with a notification and one-tap install.

## 1.11.0 — 2026-09-26
- Manual trading: a Manual trade ticket with Buy and Sell (market or limit, size in shares or dollars, optional stop-loss and take-profit) and a Positions & orders panel for the whole account with Close, Close ½ and Cancel. The bot stays out of any symbol you trade by hand that day and never flattens your manual positions at the close.

## 1.10.0 — 2026-09-26
- Fully automated install: one-file installer (SekexBot_Setup.sh), optional sekexbot-setup.conf to pre-fill keys and settings and start trading automatically, a non-interactive package install with a log, and 'sekex doctor --fix', which checks the phone and opens the screens that fix problems.

## 1.9.1 — 2026-09-26
- Tap-to-use controls: home-screen Start / Stop / Status / Open buttons (Termux:Widget), Start and Stop buttons in the SekexBot notification, pop-up messages, and a ⏻ Turn off app button on the dashboard.

## 1.9.0 — 2026-09-26 (Android edition)
- 🤖 Runs entirely on an Android phone inside Termux. No PC needed. `install.sh` sets everything up, and the `sekex` command starts, stops and checks the bot.
- Watchdog: if the app crashes or Android kills it, it restarts automatically, and trading **resumes** if it was running (a Stop from the dashboard or `sekex stop` is remembered).
- Open trades, today's halt state, profit-lock peak and losing-streak brakes are saved every tick and restored after a restart, so a restart can't reset your limits.
- Wake lock, start on phone boot (Termux:Boot), and an ongoing notification with an Open button.
- Dashboard shows battery, charging and wake-lock status, with warnings when the phone is on battery or hot.
- After-hours and overnight trading start **off** on Android, because their stops are watched by the app itself.
- "Phone access" becomes "Remote access" for checking the phone's bot from another device (uses Termux's cloudflared).

## 1.8.0 — 2026-09-26
- 📱 Phone access through a Cloudflare Tunnel. You can use a Quick link (no account) or your own domain, with a QR code, and auto-connect on start.
- A login page with a password (hashed), 30-day signed sessions, and a lockout after too many wrong attempts.
- Broker keys and phone-access settings can only be changed on the computer running SekexBot.
- The dashboard fits phone screens and can be installed as an app with the SekexBot icon.
- A version number with this changelog.

## 1.7.2
- Chart read: "Analyze live chart" now uses the most recent session at night, on weekends and before the open.
- Clear error messages for the AI screenshot reader: no API credits, bad key, model not found, image too large, rate limit.
- A "Test AI key" button.

## 1.7.1
- New SekexBot logo, app icon, favicon, Windows .ico, and a desktop-shortcut helper.

## 1.7.0
- Account-size-aware stock picker. It scans about 300 stocks and scores each one for opportunity × fit (daily limit, buying power, liquidity).
- "Scan now" button and a Stock picker table with the reasons for each pick.
- Fix: volume and ATR now come from full-market SIP history instead of IEX-only volume.

## 1.6.0
- 🔑 Broker keys screen: enter, test and save Alpaca paper and live keys, a Live PIN, and a Claude key, all in the dashboard.
- Startup no longer opens Notepad.

## 1.5.1
- Renamed to SekexBot.

## 1.5.0
- BullGPT-style screenshot reader. Drop in or paste a chart and get a game plan: trend, levels, timing, scenarios, lean, and what the bot would do.
- Watchlist of tickers that are always scanned and traded in every session (SPCX added to start).

## 1.4.0
- After-hours (4–8 PM) and overnight (8 PM–4 AM) trading: long-only, limit orders, bot-managed stops, half size.
- The daily loss window runs 8 PM → 8 PM ET. The chart is built from quotes overnight.
- Fixed start_bot.bat when the Python environment was missing pip.

## 1.3.0
- Portable SD card / USB edition with a bundled runtime and self-repairing setup.

## 1.2.0
- AI chart read panel: levels, Fibonacci, RSI, VWAP, bias score, and bull and bear scenarios.

## 1.1.0
- EMA ribbon: RIBBON_FLIP strategy, ride-the-ribbon exit, ribbon trend filter, ribbon chart on the dashboard.

## 1.0.0
- First release: morning scanner, five strategies, a Thompson-sampling learner that picks setups and exits, a daily-max-loss risk manager, bracket orders, the dashboard, and the offline simulator.
