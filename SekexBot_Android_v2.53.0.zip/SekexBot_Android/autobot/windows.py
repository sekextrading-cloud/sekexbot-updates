"""v2.51: Best windows - which half-hours your own watchlist usually rises or falls in (by weekday and by time of day), 4:00 AM - 4:00 PM,
shown both ways (best buys AND best shorts), plus a PAPER-ONLY autopilot that trades the strongest windows and keeps an honest scoreboard.

How a window is measured: for every stock and every half-hour, the move from the first price to the last price of that half-hour, on every
day in the history (about 6 months of 30-minute candles from Alpaca).  For one weekday or for all days:
    n      how many days            up     % of those days it rose          avg    average move in %
    t      average / (spread / sqrt(n)): how unlikely the lean is to be luck
    agree  the first half and the second half of the history lean the same way
Trust:  solid = agree, |t| >= 2.5 and 40+ days      fair = agree and |t| >= 1.8      weak = anything else (could be luck)

HONEST WARNING (tested May 12 - Oct 30 2026, walk-forward, costs included): an autopilot that picks the strongest windows from the past and
trades the next one LOST in every version (-0.09% to -0.24% a trade; before costs about zero; pre-market the worst).  Single-stock windows
that looked strong in May-Aug won 47% of the time in Aug-Oct.  The one lean that held up is the 2:00-3:00 PM dip on the whole list (down on
69% of 120 days).  So: the card is information, the autopilot is a PAPER experiment, and LIVE stays locked until its own scoreboard shows
100+ trades over 14+ days with a positive net."""
import json
import threading
from datetime import datetime, timedelta

import numpy as np
import pandas as pd

from .config import DATA_DIR

FILE = DATA_DIR / "windows.json"
HIST = DATA_DIR / "windows_hist.csv"
LOCK = threading.Lock()
SLOTS = [f"{h:02d}:{m:02d}" for h in range(4, 16) for m in (0, 30)]          # 04:00 ... 15:30 (each is 30 minutes)
EARLY = [s for s in SLOTS if s < "07:00"]                                     # the 4 AM - 7 AM section
PRE = [s for s in SLOTS if s < "09:30"]
REG = [s for s in SLOTS if s >= "09:30"]
KEEP_DAYS = 200
DEFAULT_CFG = {"on": False, "live": False, "size": 10000, "per_window": 2, "trust": "fair", "premarket": False, "day_stop": 200,
               "hv_2pm": True, "sc_2pm": True}
OK = {"size": (5000, 10000, 25000), "per_window": (1, 2, 3), "trust": ("fair", "solid"), "day_stop": (100, 200, 400)}
BOOLS = ("on", "live", "premarket", "hv_2pm", "sc_2pm")
T_MIN = {"fair": 2.5, "solid": 3.0}                                           # what the autopilot needs (the same bars as the test)
STOP_PCT = 1.0                                                                # hard stop inside the half-hour
ENTER_WITHIN_S = 180                                                          # a window is entered only in its first 3 minutes
NEED_TRADES, NEED_DAYS = 100, 14
LEDGER_CAP = 3000
TEST = {"fair": {"trades": 750, "net_pct": -0.12, "win_pct": 38}, "solid": {"trades": 359, "net_pct": -0.09, "win_pct": 44},
        "pre_net_pct": -0.14, "single_repeat_win_pct": 47, "dip": {"days": 120, "down_pct": 69, "avg_pct": -0.10}, "period": "May 12 - Oct 30 2026"}
DIP_FROM, DIP_TO = 840, 900                                                   # 2:00 - 3:00 PM


# ---------------------------------------------------------------- history
def rows_from_bars(bars):
    """{sym: 30-minute candles (open, close) indexed by New York time} -> long table [day, slot, sym, ret %]."""
    parts = []
    for sym, df in (bars or {}).items():
        if df is None or not len(df):
            continue
        d = df[["open", "close"]].copy()
        d = d[(d.index.dayofweek < 5) & (d["open"] > 0)]
        slot = d.index.strftime("%H:%M")
        keep = np.isin(slot, SLOTS)
        if not keep.any():
            continue
        d = d[keep]
        parts.append(pd.DataFrame({"day": d.index.strftime("%Y-%m-%d"), "slot": slot[keep], "sym": sym,
                                   "ret": ((d["close"] / d["open"] - 1) * 100).round(4).values}))
    return pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=["day", "slot", "sym", "ret"])


def load_hist():
    with LOCK:
        try:
            return pd.read_csv(HIST, dtype={"day": str, "slot": str, "sym": str})
        except Exception:
            return pd.DataFrame(columns=["day", "slot", "sym", "ret"])


def merge_hist(new):
    """Add rows to the saved history (newest wins), keep the last KEEP_DAYS days. Returns the merged table."""
    old = load_hist()
    h = pd.concat([old, new], ignore_index=True) if len(old) else new.copy()
    if not len(h):
        return h
    h = h.drop_duplicates(["day", "slot", "sym"], keep="last")
    days = sorted(h["day"].unique())[-KEEP_DAYS:]
    h = h[h["day"] >= days[0]].sort_values(["day", "slot", "sym"])
    with LOCK:
        tmp = HIST.with_suffix(".tmp")
        h.to_csv(tmp, index=False)
        tmp.replace(HIST)
    return h


# ---------------------------------------------------------------- statistics
def trust(n, t, agree):
    if agree and abs(t) >= 2.5 and n >= 40:
        return "solid"
    if agree and abs(t) >= 1.8:
        return "fair"
    return "weak"


def _stat_table(h):
    """h: [day, slot, sym, ret] -> one row per (sym, slot) with n, avg, up, t, agree, rel."""
    if not len(h):
        return pd.DataFrame(columns=["sym", "slot", "n", "avg", "up", "t", "agree", "rel"])
    days = sorted(h["day"].unique())
    mid = days[len(days) // 2]
    g = h.groupby(["sym", "slot"])["ret"]
    s = pd.DataFrame({"n": g.size(), "avg": g.mean(), "sd": g.std(ddof=1), "up": g.apply(lambda v: 100.0 * (v > 0).mean())})
    m1 = h[h["day"] < mid].groupby(["sym", "slot"])["ret"].mean()
    m2 = h[h["day"] >= mid].groupby(["sym", "slot"])["ret"].mean()
    s["m1"], s["m2"] = m1, m2
    s = s.reset_index()
    sd = s["sd"].where(s["sd"] > 0)
    s["t"] = (s["avg"] / (sd / np.sqrt(s["n"].clip(lower=1)))).fillna(0.0)
    s["agree"] = (np.sign(s["m1"].fillna(0)) == np.sign(s["m2"].fillna(0))) & (s["m1"].fillna(0) != 0)
    s["rel"] = [trust(n, t, a) for n, t, a in zip(s["n"], s["t"], s["agree"])]
    return s[["sym", "slot", "n", "avg", "up", "t", "agree", "rel"]]


def with_list(h):
    """Add the whole-list rows: the average move of all stocks for each day and half-hour, as sym 'LIST'."""
    if not len(h):
        return h
    lst = h.groupby(["day", "slot"], as_index=False)["ret"].mean()
    lst["sym"] = "LIST"
    return pd.concat([h, lst], ignore_index=True)


def stats(h, dow=None):
    """Window statistics for one weekday (0 = Monday) or for all days."""
    if dow is not None and len(h):
        h = h[pd.to_datetime(h["day"]).dt.dayofweek == dow]
    return _stat_table(with_list(h))


def _row(r):
    return {"sym": r["sym"], "slot": r["slot"], "n": int(r["n"]), "avg": round(float(r["avg"]), 3), "up": int(round(float(r["up"]))),
            "t": round(float(r["t"]), 2), "rel": r["rel"]}


def _tops(s, slots, k):
    x = s[(s["sym"] != "LIST") & s["slot"].isin(slots) & s["agree"] & (s["n"] >= 10)]
    buys = [_row(r) for _, r in x[x["t"] > 0].sort_values("t", ascending=False).head(k).iterrows()]
    shorts = [_row(r) for _, r in x[x["t"] < 0].sort_values("t").head(k).iterrows()]
    return buys, shorts


def _best(lst, slots):
    x = lst[lst["slot"].isin(slots)]
    if not len(x):
        return None, None
    b, s_ = x.sort_values("t", ascending=False).iloc[0], x.sort_values("t").iloc[0]
    return (_row(b) if b["t"] > 0 else None), (_row(s_) if s_["t"] < 0 else None)


def card(h, today, min_weekday_days=10):
    """Everything the Best windows card shows for one date."""
    if not len(h):
        return {"ready": False, "days": 0}
    wd = today.weekday()
    hw = h[pd.to_datetime(h["day"]).dt.dayofweek == wd] if wd < 5 else h.iloc[0:0]
    use_wd = wd < 5 and hw["day"].nunique() >= min_weekday_days
    s = stats(h, wd if use_wd else None)
    lst = s[s["sym"] == "LIST"]
    by = {r["slot"]: _row(r) for _, r in lst.iterrows()}
    bb, bs = _best(lst, REG)
    buys, shorts = _tops(s, REG, 4)
    pb, ps = _best(lst, EARLY)
    pbuys, pshorts = _tops(s, EARLY, 3)
    al = stats(h, None)
    al = al[al["sym"] == "LIST"]
    # the 2 PM dip, measured on your own list over all days (14:00 + 14:30 together)
    lst_all = h.groupby(["day", "slot"])["ret"].mean().unstack("slot")
    dip = None
    if "14:00" in lst_all and "14:30" in lst_all:
        v = (lst_all["14:00"] + lst_all["14:30"]).dropna()
        if len(v) >= 10:
            dip = {"days": int(len(v)), "down_pct": int(round(100 * (v < 0).mean())), "avg_pct": round(float(v.mean()), 3)}
    return {"ready": True, "days": int(h["day"].nunique()), "symbols": int(h["sym"].nunique()), "scope": "weekday" if use_wd else "all",
            "weekday": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"][wd],
            "scope_days": int(hw["day"].nunique()) if use_wd else int(h["day"].nunique()),
            "day": [by[x] for x in REG if x in by], "best_buy": bb, "best_short": bs, "buys": buys, "shorts": shorts,
            "early": {"day": [by[x] for x in EARLY if x in by], "best_buy": pb, "best_short": ps, "buys": pbuys, "shorts": pshorts},
            "dip": dip, "last_day": str(h["day"].max())}


def picks(h, today, cfg):
    """What the autopilot would trade today: {slot: [{sym, side, t, n, avg, up, scope}]}, strongest first, at most per_window each.
    A window qualifies when both halves of the history agree and |t| reaches the bar (2.5 for 'fair', 3.0 for 'solid'), measured on this
    weekday (10+ days) or on all days (40+ days)."""
    if not len(h) or today.weekday() >= 5:
        return {}
    h = h[h["day"] < str(today)]                                 # only days BEFORE today
    tmin = T_MIN.get(cfg.get("trust"), 2.5)
    slots = SLOTS if cfg.get("premarket") else REG
    cand = {}
    for scope, s, nmin in (("weekday", stats(h, today.weekday()), 10), ("all days", stats(h, None), 40)):
        x = s[(s["sym"] != "LIST") & s["slot"].isin(slots) & s["agree"] & (s["n"] >= nmin) & (s["t"].abs() >= tmin)]
        for _, r in x.iterrows():
            k = (r["slot"], r["sym"])
            if k not in cand or abs(r["t"]) > abs(cand[k]["t"]):
                cand[k] = {"sym": r["sym"], "side": "long" if r["t"] > 0 else "short", "t": round(float(r["t"]), 2), "n": int(r["n"]),
                           "avg": round(float(r["avg"]), 3), "up": int(round(float(r["up"]))), "scope": scope}
    out = {}
    for (slot, _), v in cand.items():
        out.setdefault(slot, []).append(v)
    return {slot: sorted(v, key=lambda r: -abs(r["t"]))[:int(cfg.get("per_window") or 1)] for slot, v in sorted(out.items())}


# ---------------------------------------------------------------- autopilot state
def _blank():
    return {"cfg": dict(DEFAULT_CFG), "day": "", "trades": [], "log": [], "history": [], "done": "", "taken": [], "ledger": []}


def load():
    with LOCK:
        try:
            d = json.loads(FILE.read_text())
        except Exception:
            d = {}
    b = _blank()
    b.update({k: d[k] for k in b if k in d})
    c = dict(DEFAULT_CFG)
    c.update(b.get("cfg") or {})
    for k, ok in OK.items():
        if c.get(k) not in ok:
            c[k] = DEFAULT_CFG[k]
    for k in BOOLS:
        c[k] = bool(c.get(k))
    b["cfg"] = c
    return b


def save(d):
    with LOCK:
        tmp = FILE.with_suffix(".tmp")
        tmp.write_text(json.dumps(d, default=str))
        tmp.replace(FILE)


def set_cfg(**kw):
    d = load()
    for k, v in kw.items():
        if v is None:
            continue
        if k in BOOLS:
            d["cfg"][k] = bool(v)
        elif k in OK:
            if isinstance(OK[k][0], int):
                v = int(v)
            if v in OK[k]:
                d["cfg"][k] = v
    save(d)
    return load()


def day_pnl(d, marks=None):
    tot = 0.0
    for t in d.get("trades", []):
        tot += float(t.get("realized") or 0)
        if t.get("state") == "open" and marks and marks.get(t["symbol"]) and t.get("qty_open") and t.get("entry"):
            tot += (marks[t["symbol"]] - float(t["entry"])) * (1 if t["side"] == "long" else -1) * t["qty_open"]
    return tot


def new_day(d, today):
    if d.get("day") != str(today):
        done = [t for t in d.get("trades", []) if t.get("entry")]
        if done:
            d["history"] = ([{"day": d["day"], "pnl": round(day_pnl(d), 2), "n": len(done)}] + d.get("history", []))[:30]
        d.update(day=str(today), trades=[], log=[], done="", taken=[])
    return d


def log(d, now, msg):
    d.setdefault("log", []).insert(0, {"t": now.strftime("%-I:%M %p"), "msg": msg})
    del d["log"][80:]


def hm(now):
    return now.hour * 60 + now.minute


def slot_of(now):
    """The half-hour this moment is in ('09:30'), and how many seconds into it."""
    m = hm(now)
    s = f"{m // 60:02d}:{(m % 60) // 30 * 30:02d}"
    return (s if s in SLOTS else None), (m % 30) * 60 + now.second


def slot_end(day, slot):
    h_, m_ = (int(x) for x in slot.split(":"))
    return day.replace(hour=h_, minute=m_, second=0, microsecond=0) + timedelta(minutes=30)


def size(cfg, px, bp):
    if not px or px <= 0:
        return 0
    return max(0, int(min(float(cfg["size"]), 0.3 * float(bp or 0)) // px))


def manage(t, bid, ask, now):
    """'' to hold, or why to get out: the half-hour is over, or the 1% hard stop."""
    if t.get("state") != "open":
        return ""
    if now >= datetime.fromisoformat(t["until"]):
        return "window over"
    d_ = 1 if t["side"] == "long" else -1
    mark = bid if d_ > 0 else ask
    if mark and t.get("entry") and (mark / float(t["entry"]) - 1) * 100 * d_ <= -STOP_PCT:
        return f"stop -{STOP_PCT:g}%"
    return ""


def record(d, t, now):
    row = {"day": str(now.date()), "t": now.isoformat(), "sym": t["symbol"], "side": t["side"], "slot": t.get("slot", ""),
           "pnl": round(float(t.get("realized") or 0), 2), "mode": t.get("mode", "PAPER"), "why": t.get("last_why", "")}
    d.setdefault("ledger", []).append(row)
    del d["ledger"][:-LEDGER_CAP]
    return row


def board(d, today=None):
    rows = [r for r in d.get("ledger", []) if r.get("mode", "PAPER") != "LIVE"]
    n = len(rows)
    wins = [r["pnl"] for r in rows if r["pnl"] > 0]
    loss = [r["pnl"] for r in rows if r["pnl"] <= 0]
    net = round(sum(r["pnl"] for r in rows), 2)
    days = 0
    if rows and today is not None:
        try:
            days = (today - datetime.fromisoformat(rows[0]["day"]).date()).days + 1
        except Exception:
            days = 0
    ready = n >= NEED_TRADES and days >= NEED_DAYS
    return {"n": n, "net": net, "win": round(100 * len(wins) / n) if n else None, "avg_win": round(sum(wins) / len(wins), 2) if wins else 0.0,
            "avg_loss": round(sum(loss) / len(loss), 2) if loss else 0.0, "days": days, "need_n": NEED_TRADES, "need_days": NEED_DAYS,
            "ready": ready, "verdict": ("working" if net > 0 else "not working") if ready else "collecting", "unlocked": bool(ready and net > 0)}


def dip_hour(now):
    """True from 2:00 to 3:00 PM New York on a weekday."""
    return now.weekday() < 5 and DIP_FROM <= hm(now) < DIP_TO
