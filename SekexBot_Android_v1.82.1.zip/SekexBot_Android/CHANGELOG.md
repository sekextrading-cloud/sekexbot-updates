# SekexBot changelog

Version numbers are MAJOR.MINOR.PATCH. MAJOR means a breaking change to settings or data, MINOR means a new feature, and PATCH means a fix.
The running version shows in the dashboard header and in the console window when SekexBot starts.

## 1.82.1 — 2026-10-05
- Fix: Harvest now (and Re-enter now) did nothing between 8 PM and 4 AM because the overnight pause of Auto-harvest also ignored your button. Your button now works overnight (limit orders at the bid or ask); only the automatic harvests, stops and re-entries stay paused there.

## 1.82.0 — 2026-10-05
- Night shorts: from 8 PM to 7 AM ET the bot only shorts (no new longs), only stocks on the setup-short list, and closes them for a profit (the protective stop stays; shorts are not force-closed at the overnight to pre-market change). New menu item Night shorts list in the More menu shows the list, what the bot is waiting for on each name and your open night shorts. On by default, with a switch.

## 1.81.0 — 2026-10-05
- Start on boot by default: SekexBot now starts by itself when the phone turns on (it still needs the Termux:Boot app). New switch in Controls, Start SekexBot by itself when the phone turns on, turns it off. sekex doctor shows the state.

## 1.80.0 — 2026-10-05
- Harvest now button: every position of yours has a green Harvest button that sells right away and keeps the harvest cycle going (re-enters on a pullback). It turns Auto-harvest on if it was off. While the cycle is waiting to buy back, the Auto-harvest row shows Re-enter now. Asks first if the position is below your entry.

## 1.79.0 — 2026-10-05
- Simpler Controls: three simple controls at the top of Controls (Exit style, Shorts, Learn from my results) now set the many overlapping switches for you. The individual switches stay under Advanced, and the three loose ones in the Self-fix card moved there too.

## 1.78.0 — 2026-10-05
- Smart entry: in the pre-market, after-hours and overnight the bot starts its entry limit halfway across the spread and steps to the far side every 15 seconds (ending at the old price), so it pays less of the spread. Skipped when the spread is under 2 cents. The Pre-market preset card counts what it saved and how many entries it missed.

## 1.77.0 — 2026-10-05
- Session auto-off: every night a strategy that loses money in one market session (pre-market, open, midday, afternoon, after-hours, overnight) on at least 12 of your own bot trades is switched off in that session only, then retested a week later on new trades. New card on the Auto tab shows what is off, the retest date and a log. It works next to Self-fix and never touches manual trades or the daily loss limit.

## 1.76.1 — 2026-10-05
- Pre-market only preset: one tap limits the bot's pre-market entries to EXT_TREND and FLUSH_BOUNCE and harvests at 3x the spread; positions show the spread cost next to close now.

## 1.76.0 — 2026-10-05
- Close-now log: new card on the Positions tab. Every time a position could be closed right now for a profit above $10 (your line, you can change it), it records the time, stock, who owns it (you, bot or auto-harvest), the close-now amount at the real bid or ask, the peak, how many minutes it stayed above, the spread and the session. UP = crossed above the line, FELL = dropped back under it, CLOSED = the position was closed while above it. Checked every 5 seconds, kept across restarts, with Export CSV. Close-now is after the spread, so it is the profit you could really take.

## 1.75.0 — 2026-10-05
- Pre-market preset: new card on the Auto tab. Auto-create reads your own closed pre-market trades and builds a safer setup: the best 30-minute-slot window for starting bot trades, a size cap so a typical stop loses about what a typical win makes, and strategies that lost money there switched off in the pre-market only. With fewer than 20 pre-market trades it uses the Recommended preset (7:00 to 9:00, max $10,000). Optional nightly rebuild. Applies to the bot's pre-market entries, and the size cap also to after-hours and overnight. It never touches the daily loss limit and never closes your manual trades.
- Scorecard: new card on the Auto tab that slices your own closed trades by strategy, session, long or short, hour or stock, for this account, PAPER, LIVE or all, over 7, 30 or 90 days. It shows win rate, average win and loss, dollars per trade and P&L, and marks strategies that lose money over 15 or more trades. In By strategy, Turn off stops the bot taking that strategy until you turn it back on. The daily loss limit is not touched.
- Trade pad: a visible Auto-harvest tick. It is the same remembered tick as on the Manual ticket, so every pad order inherited it, and the harvester then sold small gains and stopped out your hand trades. Untick it to keep a manual trade exactly as you left it.

## 1.74.1 — 2026-10-05
- Auto-harvest exit fix: found in your support export. After a re-entry that filled a little less than requested (for example 59 of 60 shares), the harvester kept trying to sell the larger number and Alpaca refused it about 190 times (AAPL on Oct 1). It now never asks to sell more than is really held, re-syncs to the quantity Alpaca reports, and repeats the warning only a few times instead of every few seconds.

## 1.74.0 — 2026-10-04
- Morning prep: a new card on the Auto tab that ranks your watchlist, shortlist and movers from real Alpaca data: price now against the last close (gap), against the 20-day average, and distance to the 20-day high, with ATR and setup tags (TREND LONG, TREND SHORT, NEW 20D HIGH, NEAR HIGH, LONG WATCH). Best long setups first. Tap a row to load it on the Trade Pad. Information only, it never trades.
- Trade pad chips: watchlist and position chips are compact again (the price was showing in a huge font), and overnight or pre-market prices now use the live bid and ask midpoint instead of an hours-old last trade.

## 1.73.3 — 2026-10-04
- Trade pad goes live: the quote under the ticker now refreshes by itself every 3 seconds, and the watchlist and open-position chips show the last price and % change for the day, refreshed every 5 seconds, so you no longer have to tap Quote. Open positions also show the current price.

## 1.73.2 — 2026-10-04
- Trade pad layout: on a wide screen (tablet or phone sideways) the pad is now two columns. Your open positions and the whole watchlist sit on the right, and the six keys run in one row underneath, so the whole pad fits on one screen with no scrolling. On a narrow phone the positions and watchlist stay on the same screen and the long hint text is hidden. Open positions are listed first so you can see and close them quickly.

## 1.73.1 — 2026-10-04
- Trade pad: open positions and watchlist chips. Open positions show as chips with size and open P&L (tap to select, the red X closes that position); your watchlist shows below as one-tap ticker chips.

## 1.73.0 — 2026-10-04
- Trade pad: a hardware-style macro pad on the Manual tab with a knob, CANCEL, CLOSE, LIMIT, MARKET, SELL and BUY keys, for fast manual orders from the phone or a PC. Turn (or drag) the knob to change the size, or tap a preset chip for a one-touch amount.
- Preset amounts: choose Shares or Dollars. Defaults are 5, 10, 25, 50, 100 shares or $100, $250, $500, $1000, $2500. Tap the Presets button to set your own, saved on the device.
- Keys: LIMIT places a marketable limit at the ask (buy) or bid (sell); MARKET is only available when the market is open. SELL and BUY go through the same confirmation, PIN and short rules as the regular ticket. CLOSE closes your position in that stock. CANCEL cancels open orders on that stock, and refuses if the stock is an open bot trade so it cannot strip the bot's stop.
- Keyboard shortcuts for a USB or Bluetooth macro pad: B buy, S sell, C close, X cancel, L limit, M market, arrow keys change size, 1 to 6 pick a preset. They work only on the Manual tab and not while typing.

## 1.72.0 — 2026-10-04
- Options settings: the options module now keeps its own settings in options_settings.json (on/off, style, daily options budget, per-trade limit, max open, take-profit %, stop %, DTE range, stocks to trade). Your stock settings in settings.json no longer carry any options values. Existing options settings are moved over automatically on the first start after the update.
- Options journal: the module has its own journal database, options.db, kept apart from your stock trade journal (trades.db). Existing options rows are copied over once. In the Options card, the new Options journal button shows closed trades, win rate, total P&L, average win and loss, and breakdowns by stock, call or put, style and why closed. Export CSV downloads the whole options journal.
- Unchanged: the options module is still OFF by default, defined risk only, regular hours only, paper only until you unlock Live with your PIN, and it uses its own daily options budget (never your stock daily loss limit).

## 1.71.2 — 2026-10-04
- Release notes: the changelog and this install guide now cover every release from 1.68.2 to 1.71.1.
- Install guide: README_ANDROID gained update steps and sections for the home-screen icon, ChatGPT option, regime filter, session focus, options, fractional mode, green guard and the morning trend rider.

## 1.71.1 — 2026-10-04
- Morning trend rider: no longer needs a gap. A steady 0.8%+ move off the 9:30 open (net move at least 35% of the distance travelled over the last 20 bars) also qualifies, long or short. For instance, IREN on Friday Oct 2 had almost no gap but ground up about 4% from the open. Choppy days still do not qualify.

## 1.71.0 — 2026-10-03
- Green guard: for trades that go green two or three times, never reach the target, then lose (Auto > Advanced, ON by default). Green means up enough to cover the spread plus slippage (never under 0.15R, never over 0.5R). On the second clear green the bot banks the trade, unless it already ran past 0.6R (the gain lock handles those). After one small peak that gives back 40% (50% while Let run is on) it banks what is left. After two greens, or a peak of 1.6x the green size, the stop moves to break-even plus costs.
- Morning trend rider: new MORN_TREND strategy (Auto > Advanced, ON by default) for steady morning grinds, long or short, 9:35 to 11:00. Needs a 1%+ gap one way, price above (below) VWAP, the 9 EMA over (under) the 21 EMA with the 21 EMA rising (falling), then enters on a pullback to the 9 EMA or a break of the last 12 bars on 1.2x volume. Stop is capped at 1.5 ATR. Shorts need Allow shorts and an easy-to-borrow stock. It does not trade pre-market because volume is too thin.

## 1.70.0 — 2026-10-03
- Small-account mode: fractional shares (Auto > Advanced, OFF by default). When one whole share is too big for the risk budget or the position cap, the bot buys a fraction (4 decimals, $1 minimum), long only, regular hours, fractionable stocks only.
- Protection: Alpaca does not allow bracket orders on fractions, so the entry is a day limit order, a plain broker stop goes on once it fills, and the bot itself takes the profit target (keep it running). If the broker refuses a stop on a fraction the bot watches the stop itself and says so in the log. Fractions are not scaled out; whole-share trades keep their normal bracket. Your daily loss limit is unchanged.

## 1.69.2 — 2026-10-03
- ChatGPT option: choose Claude or ChatGPT (OpenAI) as the AI. Gear > Broker keys > AI: pick ChatGPT, paste your OpenAI key, Save, Use this AI, Test. The Model box is optional (blank picks the newest GPT your key can use).
- Where it applies: the chart reader, Ask AI, signal review, Fix with AI and the admin helper all follow the AI you pick. Your Claude key stays saved so you can switch back. An OpenAI API key needs its own billing credits; a ChatGPT Plus plan does not cover the API.

## 1.69.1 — 2026-10-03
- **One-tap SekexBot icon for the home screen.** (1) New Termux:Widget shortcut named SekexBot (with the SekexBot logo): one tap starts SekexBot if it is off, then opens the dashboard. It is installed for everyone by the installer and by every update, and appears first in the Termux:Widget list. Long-press the Termux:Widget app icon and drag SekexBot out to get it as its own icon, or add the widget and tap it. (2) New command: sekex home re-creates the icon and prints the steps. (3) Settings (gear) has a new Home-screen icon card with an Add the SekexBot icon button that installs SekexBot as an app icon (Chrome install prompt, or the Add to Home screen menu). (4) The app icon now works when SekexBot is off: it shows a SekexBot is off page with a Retry button instead of a browser error. Trading is unchanged.

## 1.69.0 — 2026-10-03
- **Options auto-trader (separate module, OFF by default).** New card on the Auto page: Options, with its own on/off switch. Defined risk only: bull/bear vertical DEBIT SPREADS (or single long calls/puts if you pick that, or if the Alpaca account is only options level 2), so the most that can be lost on a trade is what it paid. It scans liquid stocks (SPY, QQQ, IWM, AAPL, NVDA, TSLA, AMD, META, MSFT, AMZN, editable) during regular hours (entries 9:45 AM to 3:30 PM), using the stock bot's ribbon, VWAP, EMA, momentum, market bias and the new market regime (it stays out of chop and quiet markets), confirms the idea twice, picks an expiry 5-21 days out and strikes near the money, checks open interest and bid/ask width, prices a limit order between mid and ask, and sizes it to your per-trade maximum and its OWN daily budget (defaults: 300 per day, 200 per trade, 2 open, up to 3 contracts). Exits: take profit +50%, stop -40%, a trailing give-back, 3 checks of the trend turning against it, expiring today, and flat 15 minutes before the close (it never holds overnight). Safety: your stock daily loss limit is untouched; options never trade on LIVE until you tap Unlock for LIVE and enter your Live PIN; turning it off still manages open positions to exit; Close all options now is a kill switch; if Alpaca refuses a one-ticket spread exit it closes the short leg first and then the long. The stock bot no longer sees option contracts as positions and its end-of-day flatten leaves them to this module. Every options trade is journaled (new options_trades table) and shown in the card. NEW and untested against a live broker: run it on PAPER first. Alpaca must have options trading enabled on the account (level 2 for long options, level 3 for spreads).

## 1.68.3 — 2026-10-03
- **Session focus.** The Auto page now has a Session focus card at the top (Auto / Pre-market / Regular / After-hours / Overnight / Show all). In Auto it follows the session you are in and shows only the cards that matter there: Pre-market shows the pre-market timeline, big movers, setting-up-now list, stock picker and Why no trade; Regular hours shows movers, picker, setting-up-now and Why no trade; After-hours shows evening candidates, the overnight study, self-fix and what the bot learned plus movers; Overnight and Market closed show the study and prep cards. Account, loss limit, controls, open positions and activity are always visible, and a one-line playbook says how the bot behaves in the session. Tap Show all to see everything. Display only: trading is unchanged.

## 1.68.2 — 2026-10-03
- **Fixes and market-aware sizing.** (1) Short orders no longer get rejected with take_profit.limit_price must be <= base_price - 0.01: bracket targets and stops are kept at least a tick on the right side of the entry (the bot used to retry the same bad order every minute). (2) After taking partial profit the new protective stop is clamped beyond the current market, so Alpaca no longer refuses it (stop price must be greater than current price). (3) The low buying power warning is logged once, not on every tick (it logged 353 times in one day). (4) Orders whose stop sits on the wrong side of the entry are skipped. (5) Journal rows left open or pending after a crash, restart or manual close are marked stale on start-up. (6) The live price stream closes its old connection before opening a new one (fixes connection limit exceeded and double sockets). (7) Adding a watchlist name Alpaca does not list (like CHEVRON instead of CVX) is refused. (8) NEW **Market regime filter** (Controls): reads SPY/QQQ and sizes each strategy for the market: trending up/down (size up with-trend, smaller counter-trend, no fading a strong trend), chop (smaller trend-following, bigger mean-reversion), volatile (everything smaller), quiet (smaller trend-following). Shown next to Market bias; each journal trade records its regime. (9) NEW **Strategy breaker**: a strategy down 2R or more today (3+ trades) trades at half size, and down 3.5R or more is paused for the day. Both only change position size, never your daily loss limit, and both have an on/off box.

## 1.68.1 — 2026-10-02
- **Easier admin updates.** Admin phone: put SekexBot_Admin_vX.Y.Z.zip in Downloads next to the app zip and run plain **sekex update** (no path needed, it uses the newest SekexBot_Android zip in Downloads) and the admin add-on updates in the same step, with no publish or network needed. New **sekex admin install** installs the newest admin zip from Downloads by itself (or give it a path), and checks it is a valid add-on first, so a bad zip changes nothing. The published encrypted add-on still works for your other phones. Every other phone is unaffected: it has no admin key, so it ignores the add-on.

## 1.68.0 — 2026-10-02
- **Admin dashboard (admin phone only).** The hidden admin page is now a real dashboard with five tabs. **Overview:** tiles (installs online, installs needing the update, installs with problems, group P&L, win rate, payoff ratio), group P&L by day, where the money goes by strategy, average win vs average loss, versions across the fleet, and who needs attention. **Fleet:** the per-install list and detail you had before. **Trading:** combined results by day, strategy, session, long vs short, exit type, time of day, and the top reasons trades were skipped. **Updates:** latest version seen, who is current or behind, and how to publish. **AI & logs:** one tap to have the AI helper analyze everyone, plus each install's logs (Numbers, Analyze with AI, Zip) and Download all (merged). Trading numbers come only from installs whose owners ticked Share my trade logs. Needs the updated collector (sekexbot_collector.zip) and the admin add-on published with this version.

## 1.67.1 — 2026-10-02
- New **Reset today's P&L to $0** button in Settings (⚙) under Daily P&L. Today's P&L and the daily loss budget count from the account's equity at 8:00 PM ET (the start of each trading day), so they reset on their own then; the button starts them again from the account's equity right now and clears a daily-loss halt. Trades stay in the journal and daily results. On LIVE it asks for your PIN. Your daily limit setting is not changed.

## 1.67.0 — 2026-10-02
- **Auto-flip for your manual trades.** Controls, Guard my manual positions, has a new choice: **Auto-flip (close + reverse)**. When a manual trade is red and the trend has clearly turned against it (the direction call 40+ against you, or the ribbon against you with no call backing you, on 3 checks in a row), the guard closes it and opens the same size the other way in ONE order (selling twice a long, buying twice a short), capped at 30% of equity for the new side. The flipped trade gets Auto-harvest armed (box: harvest the flipped trade), and the guard keeps watching it, so it can flip again: up to 3 flips per stock per day by default (setting, 0 to 10), at least 3 minutes apart. A flip to a short follows the bot's short rules (7 AM start, easy-to-borrow check, shorts switch) and needs loss limit left. If a flip isn't possible, or flips for the day are used up, it just closes. Hitting the hard loss cap with no trend turn only closes. Extended hours use a limit order priced through the quote. Set Guard to Auto-flip to use it; nothing changes until you do. Every flip costs spread twice, so check the journal before raising the daily flips.

## 1.66.1 — 2026-10-02
- Fixed a startup crash in 1.66.0: the app stopped at start-up with a NameError (the log-upload hook was wired before the function it calls existed), so it sat on Starting SekexBot and never came up. Install this instead of 1.66.0.

## 1.66.0 — 2026-10-02
- **Remote trade logs, opt-in.** A new box, **Share my trade logs** (separate from diagnostics and OFF by default; also offered, unticked, in the one-time question), uploads the trade journal, learner and strategy stats, skip reasons, scrubbed settings and a redacted engine log every 3 hours to the support collector, so strategies can be refined from real results. Never API keys, PIN, account number, .env or the collector address. Controls has **Show what is sent** (file names, sizes and the first journal rows), and turning the box off deletes what support holds. **Admin page:** new Trade logs from users: per-install Numbers, 🤖 Analyze with AI (the AI helper reads a numbers summary and suggests strategy changes), Zip download, and Download all logs (merged). The collector also writes one merged file with Export-All-Logs.bat for review. Needs the updated collector (in sekexbot_collector.zip) and the support address built into the app.

## 1.65.0 — 2026-10-02
- Fixes for the payoff problem found in the journal (small wins, big losses). **Harvest-sized stops:** with Harvest small % on, quick trades now risk about 3x the harvest gain (never inside the thin-market floor: 0.45% extended hours, 0.25% regular) instead of the full chart stop, so one stop no longer erases six harvests. Trend entries (EXT_CONT) keep their wide stop. Switch: Controls, Harvest-sized stops. **Spread by trade type:** scalps keep your 0.15% spread limit; trend setups (EXT_CONT, EXT_TREND, EXT_MOMENTUM, PLAN_TREND) may enter up to 0.40% (Controls, Max spread for trend setups). A trade now banks at least twice its entry spread (and 0.5% for EXT_CONT) instead of 0.15%, so a wide spread can't eat the harvest. **One position per leveraged-ETF family:** TQQQ/SQQQ/QQQ, SOXL/SOXS, SPY/SPXL/SPXS and others. Long TQQQ plus short SQQQ is the same bet twice, and long both cancels out, so the bot takes only one per family, also within the same scan. Switch in Controls. **Smaller bot positions:** the per-trade cap drops from 25% to 15% of equity, once, on update (Controls, Max bot position). Manual trades are not limited, but the ticket now warns when one is over 30% of equity. Your daily loss limit is untouched.

## 1.64.0 — 2026-10-02
- Pre-market and after-hours trends are now clearly marked and traded. The Big movers board shows a big **▲ BUY** or **▼ SHORT** for each stock (25 rows instead of 10), a summary line (how many to short, how many to buy), and under each one what the bot will do or why it hasn't: IN TRADE, short starts at 7:00 AM ET, or the last skip reason (spread too wide, learner score, cool-off and so on).
- New entry EXT_CONT for continuation: a stock 2%+ from the close that keeps making new lows (short, from 7:00 AM ET) or new highs (buy), with the ribbon, VWAP and the slow line all agreeing and volume not dead. It is looser than the old trend entry, which needed the break on the exact current bar. It skips the cold-strategy score check but still obeys the spread limit, the daily limit, cool-offs, the benched-setup probe rule and the 7 AM short rule. Switch in Controls: Trade pre-market / after-hours trends (on by default).
- Harvest small % is now ON by default (the hand-trader scalp: bank about 0.1%, then re-enter while the trend holds), also switched on once for existing installs. Untick it in Controls to turn it off.
- Export journal & logs now also holds the why-no-trade skip log, recent events and the movers board, so a missed trade can be traced to the exact blocking rule.

## 1.63.0 — 2026-10-02
- Fixes made with Find & fix it now survive updates. Each applied fix saves a small patch file (what changed) on the phone. Before, an update silently overwrote the fixed files while the fix still showed in the list.
- Applied fixes now show their state: in place, already in this version, lost in an update, or can't be re-applied. For a lost fix, Put this fix back re-applies it (Live PIN, backed up first, auto-rollback if the app won't start), unless the code around it changed too much.
- Share my fixes (Controls, Fix with Claude): downloads one file with every fix on this phone and its patch, so fixes found on a phone can be folded into the next release for everybody.
- Export journal & logs: downloads one zip with the trade journal (CSV), learner and level stats, slippage, scrubbed settings and the recent engine log, for reviewing why trades lose. It contains no API keys, PINs, tokens or addresses.

## 1.62.1 — 2026-10-01
- The support-data question (ticked by default; nothing is sent until the user taps Continue) now shows after every install or update even before a support address is built into the app. Controls says plainly when no address is set, so nothing can be sent yet. Once a build carries the address, users who left it ticked start reporting.

## 1.62.0 — 2026-10-01
- The admin panel is no longer part of the app everyone gets. It is now a private, encrypted add-on that installs only on phones you have marked as admin. Other users' phones never download, install or show it; the public app contains no admin screen, passcode or admin address at all.
- To make a phone an admin phone: run `sekex admin enable` once (it prints a secret admin key; keep it private). `sekex admin key` shows it again, for a second phone, or put ADMIN_KEY= (and UPDATE_URL=) in sekexbot-setup.conf before running the setup script. `sekex admin status` and `sekex admin off` also exist.
- Publishing stays one step: `sekex publish`. The first time (and whenever the add-on itself changes) also put SekexBot_Admin_vX.zip in Downloads; the admin phone remembers it, so later publishes of a new app zip need nothing extra. On a phone without the admin key the add-on is silently left out.
- One update does everything. `sekex update` (and the app's update check) now also installs any new requirements: when the list of required packages changes, the full install runs automatically instead of the quick one. On admin phones the same update also fetches the admin add-on and restarts the app when it changed.
- The support-data question now has a checkbox that is ticked by default. It appears once after an install or update (when the build has a support address), nothing is sent until the user taps Continue, and unticking it first means nothing is ever sent. Controls keeps the same checkbox.
- The panel is opened as before: tap the logo 7 times, enter the passcode, and paste the collector address once.

## 1.61.0 — 2026-10-01
- Optional diagnostics sharing, so support can help fix a problem on someone's phone. New in Controls: Share diagnostics with SekexBot support. It is OFF by default, and a one-time question asks once (only when a support address is set in the build). When on, once a minute the app sends one small technical report: app version, phone make/model and Android version, how much CPU and memory SekexBot itself uses, phone free memory, battery and temperature, free storage, library versions, uptime, whether trading is on, and the last few error messages with keys, tokens and dollar amounts removed. It never sends API keys, passwords, positions, orders, balances, P&L, symbols or the journal. Show exactly what is sent displays the real report. Turning sharing off tells the collector to delete everything it holds for that install.
- Hidden support admin panel (for the person running support). Tap the SekexBot logo 7 times, enter the admin passcode, and see every install that is sharing: online or not, version (old ones flagged), phone and Android level, app CPU and memory, phone memory, battery, storage, errors, with a 6-hour history graph and the recent errors per phone. The passcode is checked by the collector, not stored in the app. The panel needs the separate collector program (collector.py), which is not part of the phone app.
- To report anywhere, a build needs the collector's https address (Admin panel, or DEFAULT_COLLECTOR_URL in autobot/telemetry.py for what you ship to users).

## 1.60.1 — 2026-10-01
- The installer now also copies the tools folder to the phone. Before, `sekex replay SYMBOL DATE` (replays a past day through every strategy) could not run on the phone because its script was never installed. No other change; you do not need a new setup script, `sekex publish` / `sekex update` is all you need for updates.

## 1.60.0 — 2026-10-01
- Keep the screen on. New setting in Controls, Keep this screen on while SekexBot is open: Off, Only while charging (default), or Always. It uses the browser's screen wake lock, so the screen stays on only while the SekexBot page is showing, never in other apps, and it follows the charger automatically. If the browser or battery saver refuses, the note under the setting says so. Samsung phones also have a system-wide option: Settings, About phone, Software information, tap Build number 7 times, then Settings, Developer options, turn on Stay awake (screen never sleeps while charging).

## 1.59.3 — 2026-10-01
- Closing a BOT trade in extended hours: the first Close tap works the order from the middle of the spread, and a second tap while that order is still open now takes the market price at once (before, the second tap repeated the gentle first try). Closing your own positions already worked this way.

## 1.59.2 — 2026-10-01
- The learned exit-slippage figure (added to the Harvest small % target) now ignores stop-outs, time stops and end-of-day exits, which slip far more than calm exits and would have inflated the target.

## 1.59.1 — 2026-10-01
- Spread filter. New setting Max spread for bot entries (Controls, default 0.15% of the price, 0 = off). The bot skips an entry when bid-ask is wider than that, in every session, and says so in the skip log. On a wide spread you start the trade that far under water and the exit pays it again, which is how a green position closes red. Your manual ticket does not block you but warns: a red banner on the quote when the spread is over the limit, and a heads-up with the dollar cost when you place the order.
- Safer defaults. Overnight trading and Shorts 24/5 are switched back OFF (one time, for existing installs too; new installs start with them off). Overnight quotes are the thinnest and widest of any session. You can turn either back on in Controls once your journal shows it pays.

## 1.59.0 — 2026-10-01
- Patient close, so a win stays a win. On a wide spread (pre-market and after-hours often 0.3-0.5%), the on-screen gain is measured at the last trade but a close fills at the bid (or the ask for a short), so a green position can close red. The Close button now works the order instead of hitting the far side: when the spread is 0.04% or wider it posts a limit on the favourable side of the spread and walks toward the market in three steps (about 14 s each in extended hours, 6 s in regular hours), then takes the market. Tap Close a second time at any point to take the market price immediately. The walk gives up and takes the market by itself if the price runs away from you by more than one spread. Tight spreads still close at once.
- The bot does the same for exits that bank a win or a manual close of a bot trade in extended hours: the first order is half-way across the spread, and the 20-second retry then goes to the marketable price. Stop-loss exits stay immediate.
- Plan closes (the ⏰ close later feature) and stops are unchanged and still immediate.
- Reminder: the "close now ≈ $X" line on each position is what closing at the market would really give. If it is red while the position looks green, the spread is bigger than your gain.

## 1.58.0 — 2026-10-01
- Catching the win, not the loss. A trade can look green yet close red for three reasons, and all three are addressed: (1) Speed: closing a position used to cancel its stop/target orders, then wait for Alpaca to confirm, then send the close, which cost a second or more while price moved. The close now goes out straight after the cancels and only waits if Alpaca says the shares are still held. (2) Real price: the bot's profit decisions (harvest, profit lock, scalp exits) used the last trade price, but a close fills at the bid for longs and the ask for shorts. They now use the live bid/ask, so a trade only counts as a win if it is a win you can actually get. (3) Learning the cost: after every close the bot compares the price it decided at with the fill and remembers the average slippage; the Harvest small % target adds that cost automatically, and the log tells you when an exit was slow or slipped.
- Positions now show "close now ≈ $X", what closing right this second would really fill at, next to the on-screen P&L, so a +$3 that is really -$2 after the spread is visible before you tap Close.
- Applies to regular hours; extended hours already used the bid/ask for its limit orders.

## 1.57.0 — 2026-10-01
- Learn from your own manual trades. New button Analyze my manual trades (Controls, under Harvest small %): it reads your finished orders from Alpaca (last 60 days), pairs them into round trips (trades the bot opened are left out), and shows your win rate and break-even win rate, what a typical winner banks and how fast, what your losers look like, a suggested harvest % and stop %, how you re-enter after a win (how soon, and how far from your exit), and your best hours. One tap applies the suggested % as your harvest.
- New switch Auto (use the % learned from my manual wins): the bot's Harvest small % follows what you actually do, refreshed every 30 minutes in the background. It needs 15 or more finished manual trades; until then it uses the fixed % you set. The % can be changed any time, live, with no restart.
- Needs your real Alpaca account's order history, so it shows nothing on the simulator.

## 1.56.0 — 2026-10-01
- New switch Harvest small % (Controls, OFF by default) so the bot can trade the way a hand-trader does: it banks a quick gain of about 0.1% (adjustable 0.05-1%, never less than 3 cents a share so the spread can't turn it into a loss), then the existing Auto re-entry gets back in on a pullback or a run to a new extreme while the ribbon and VWAP still agree. Works in regular and extended hours. Needs Auto re-entry on. Turn it on for a day and compare the journal with it off; the stop is still the strategy's normal stop, so the win-size vs loss-size ratio is what to watch.

## 1.55.4 — 2026-10-01
- Auto-harvest fixes. (1) A harvest now has to beat the round-trip cost: it sells at the bid but buys back at the ask, so the gain per share must exceed the spread (a fade exit needs 1.5x), otherwise a "harvest" was a small loss. (2) The "banked" total only counted winning harvests and left out the stop-out loss; stops are now included, so the total is the real net. (3) If the stop's exit order failed, auto-harvest switched itself off and left the position with no stop; it now keeps the job and retries.

## 1.55.3 — 2026-10-01
- Day P&L is now explained, not just shown. The halt banner shows the equity the day started at and the equity now, so you can check the loss yourself (Day P&L = equity now minus equity at the 8 PM ET day start, open positions included).

## 1.55.2 — 2026-10-01
- Daily-max-loss halt can now be cleared. The red halt banner has a Resume trading button (with a confirmation, and a LIVE warning on the real account) and shows today's P&L as it is now, not only the figure at the moment it halted. Raising the daily limit so today's loss is back inside it clears a daily-max-loss halt automatically. The halt still resets by itself at the 8 PM ET day rollover, and the bot halts again if the limit is hit again.

## 1.55.1 — 2026-10-01
- Trend predictions on every open position. Each row in Positions & orders and in the bot's Open positions list now shows the trend (green or red ribbon: Trend up / Trend down), any early BUY? or SELL? warning with its confidence and how many candles away it is, marked "against you" in red or "with you" in green, and the direction lean (LONG, SHORT or WAIT with its score, flagged when it leans against your position). It covers your manual positions as well as the bot's, refreshes about every 20 seconds, and works in every session.

## 1.55.0 — 2026-10-01
- 24/5 trading, set up to Alpaca's rules. Alpaca trades 24 hours a day, 5 days a week (Sunday 8 PM to Friday 8 PM ET), not 24/7; weekends are closed for stocks. Overnight is now ON for everyone (one-time switch; you can turn it off in Controls). New switch Shorts 24/5 (on by default): the bot may short in every open session, overnight included, instead of only 7 AM to 8 PM; every short still needs a fresh easy-to-borrow check right before the order. Rules the app already follows and now explains on the Controls card: outside 9:30 AM to 4 PM Alpaca accepts only limit orders with Day (or GTC) time in force, whole shares only, no market, stop, stop-limit or bracket orders, so the bot sends limit orders and watches its own stops, half size, 2 positions max. Overnight prices need Alpaca's overnight data (free overnight feed, or boats with Algo Trader Plus); if Alpaca returns none the app now says so once per night and alerts you. Android note: the app has to stay running overnight because the stops live in the bot.

## 1.54.1 — 2026-09-30
- Fix: Close on a manual position could fail. The app cancelled the position's stop/target orders and waited a fixed half second; if Alpaca had not released the shares yet, the close was refused ("insufficient qty / held for orders") and nothing happened. Now it cancels the orders, waits until Alpaca shows them gone, retries up to 4 times, and as a last resort sends a plain market order the other way. A finished bot trade on the same symbol can no longer hijack a manual close, and an after-hours close with no live quote prices off the position's last price instead of refusing.

## 1.54.0 — 2026-09-30
- Fixes for the benched setups. Self-fix: Fresh start: trades closed before this version are no longer counted when a setup is judged (they were closed under the old exits), so EMA_PULLBACK, RIBBON_FLIP and the others are re-tested on fair data; a benched setup's daily probe trade is now a quarter-size test instead of half. MICRO_SCALP: risk is capped at about 0.6 ATR (was 1.0 ATR) so a scalp no longer risks far more than it can win. FLUSH_SHORT: needs two closes under the broken range low, no chasing an exhausted drop (over 1.5 ATR under the range), and volume of 1.5x. FLUSH_BOUNCE: needs a higher low, and the bounce bar must close over the EMA9 as well as the prior high. Includes everything from 1.53.0.

## 1.53.0 — 2026-09-30
- Profit protection, the bot now banks gains properly. Profit lock: once a trade has been 0.6R green it can never give back more than 40% of its best gain (50% from 1.2R, 60% from 2R, 70% from 3R); the stop follows and the bot closes the trade if it falls to that level, in regular and extended hours. Earlier partials: sells 1/3 at +0.7R and 40% of the rest at +1.5R, break-even at +1R, tighter trail from +1.5R, and the far take-profit order is cancelled when a partial is taken. Reversal exit: if the app's direction call turns 55%+ against a trade that is 0.5R or more green, the bot sells half; if it is still against you on the next check it closes the rest.

## 1.52.1 — 2026-09-30
- Voice commands understand you better: extra words before the command no longer break it ('SpaceX status', 'hey Sekex, what's my balance'), SpaceX/Tesla/Apple and other company names map to their tickers, spoken numbers like 'twenty five' and 'one hundred' work, and 'SPCX status' reads that position's P&L. 'Close half' on a 1-share position now says so instead of closing it all.

## 1.52.0 — 2026-09-30
- Shorts from 7 AM for every setup. New switch (Controls, on by default): shorting turns on by itself at 7:00 AM ET and stays on until 8 PM, pre-market included, no matter what the manual Allow short selling box says (before 7 AM it stays off). Every setup can now short: MEAN_REVERT gets a short side (stretched above VWAP, overbought), the extended-hours micro-scalp can short, and a new FLUSH_FADE setup (short mirror of FLUSH_BOUNCE: fast spike up on volume, first red bar under the prior low) runs in regular hours and pre/after-market. Borrow checks, the 2-loss block and all risk limits still apply.

## 1.51.1 — 2026-09-30
- Two fixes from a code review. (1) Restored the suggested stop-loss / take-profit for manual orders: it had stopped working in v1.33.0 (Protect and Suggest levels returned an error) because a new file replaced the code behind it. (2) Closed a security hole: a web page open in the phone's browser could press bodyless buttons on the local dashboard (Flatten, Start, Reopen last close...) when no dashboard token is set. Local requests now must come from the dashboard itself (Origin/Host checks); curl and the sekex command are unaffected.

## 1.51.0 — 2026-09-29
- Voice + header patch built in (it no longer gets wiped by updates). 🎤 Voice commands: tap the green mic (bottom right; can move it to the left or hide it in ⚙ → Voice) and say 'Close META', 'Close half META', 'Close all', 'Status', 'Buy 5 META' or 'Short 15 SPCX'. Every command is shown and read back, and nothing is sent until you tap CONFIRM (it cancels itself after 20 s). Voice orders are capped at 500 shares; voice closes use the Close button's own logic, so after-hours shorts get the extended-hours limit order. Needs Chrome on http://127.0.0.1 or your https link. Welcome greeting ('Hello Ty-see-key, let's make some money!') on your first tap after opening, while 🔊 is ON; editable, with a Test button and an off switch. Header message: optional passcode lock (⚙ → Header message → Set a passcode; 5 wrong tries = 15-minute wait), and long messages now shrink to fit on two lines.

## 1.50.1 — 2026-09-29
- Header message moved into ⚙ Settings → Header message: type the text, tap a color (White, Green, Red, Gold, Blue, Purple) and a size (Small, Medium, Large), see a live preview, then Save or Remove. A 'Show in the header' switch hides it without deleting it. Tapping the message in the header opens this section; the empty 'Tap to add your message' box no longer shows in the header.

## 1.50.0 — 2026-09-29
- 📊 Review my signals with Claude (⚙ → Help, or the link under the chart): ask Claude about your BUY / SELL alerts in plain words. The app first grades every signal on your real recent prices (watchlist + stocks you traded): how late each confirmed BUY/SELL came (in normal candle ranges), whether price followed through over the next 5 candles, how often the BUY?/SELL? warnings were right and how many candles early, split by 1/3/5-minute chart, session and stock. It tests other early-warning settings on the same data and reads your trade journal, skipped signals and log errors. Claude then explains what it found and suggests warning settings (confidence cutoff, how soon the lines must cross, how much the ribbon must thin, the after-hours penalty) that you apply with one tap, kept within safe limits, with reset to default. It only changes the early warnings and their alerts, never how the bot trades. If a code change is needed, one tap sends it to Fix with Claude.

## 1.49.1 — 2026-09-29
- Your own message in the header: tap the empty space next to the session status (✎ Tap to add your message) to write a big, bold line such as a trading rule, and pick its color. It's saved on the bot, so every device shows it; tap it again to change or remove it.

## 1.49.0 — 2026-09-29
- 🤖 Fix with Claude (⚙ → Help & repair): describe a bug in plain words and Claude reads the relevant code, writes a fix and explains it in plain English with a risk level (and a warning if it changes how orders, stops or exits behave). The app tests every fix on a copy first (Python must compile, the dashboard's JavaScript must parse, the copy must start in simulator mode, load the dashboard and run 8 s without errors); a fix that fails is never applied. You review it (plain summary + the code change) and enter your Live PIN to apply; the changed files are backed up and the app restarts (trading resumes). If a fixed app won't start 3 times, or a patched file won't compile, it rolls back by itself; Undo (PIN) restores the last backup. Never touches keys, .env or data; only on the phone itself, not over the remote link. Uses your Claude API key and credits.

## 1.48.1 — 2026-09-29
- Fixed: auto-harvest (♻) stopped out a position on one bad quote when the overnight session started at 8 PM (TEM, Sep 29). Its protective stop now uses the mid price instead of the bid, ignores the first 3 minutes of each session and any time the spread is too wide, and needs price to stay beyond the stop for 25 seconds (straight away only at twice the stop). Overnight (8 PM - 4 AM) auto-harvest pauses and holds the position as is, then resumes at 4 AM pre-market.

## 1.48.0 — 2026-09-29
- ⏰ Close later: a new button on each of your positions sets a plan that closes the whole position by itself at the first of: a time (presets: tonight 7:55 PM, 4:00 AM pre-market, 9:30 AM open, 3:55 PM, or any time you pick), the trend turning against you (a NEW 3-minute ribbon flip red for a long / green for a short), or a take-profit / stop price. It runs on the phone even with the dashboard closed, is saved across restarts, uses extended-hours limit orders outside 9:30-4:00 and re-prices every minute until filled, and waits for the next session if it triggers while the market is shut. If Alpaca refuses to cover a short overnight it keeps trying and closes at 4 AM pre-market. Alerts with beep + voice when the plan fires and when it fills. Tapping Close yourself removes the plan; setting a plan turns off ♻ auto-harvest for that stock.

## 1.47.2 — 2026-09-29
- More close fixes: closing a BOT short after hours now prices the cover at the ask (was the bid, so it could sit unfilled); tapping Close again re-prices a bot exit that hasn't filled; a bot trade from regular hours that is still open after hours now closes with an extended-hours limit (the market close was being rejected silently); a regular-hours bot close that Alpaca rejects now shows the error instead of 'ok'. A full Close turns off auto-harvest (♻) for that stock so it can't buy back in. Watchlist warnings refresh right away when you add or remove a ticker.

## 1.47.1 — 2026-09-29
- Fixed: Close did nothing for SHORT positions in pre-market / after-hours (it refused with 'Covering a short needs regular hours'). Close now sends an extended-hours limit buy to cover a little above the ask (0.3%), the same way longs are sold; press Close again to re-price if it hasn't filled.

## 1.47.0 — 2026-09-29
- Beep and voice alerts for BUY / SELL on your watchlist, with an ON / OFF speaker button in the top bar (next to the bell) that mutes or unmutes everything in one tap, also from the remote link. Phone (works with the screen off, needs Termux:API): the notification plays a sound and vibrates (BUY = 2 short buzzes, SELL = 1 long, early BUY?/SELL? warning = 3 quick taps), and the phone says it out loud, e.g. 'S P C X. Sell signal. Trend turned down.' or 'M E T A. Buy warning. 74 percent.' Early warnings are a new alert (Settings > Alerts), spoken from 65% confidence by default (Warn me from: 60-80% or Never). Dashboard, while open: a rising two-tone beep for BUY, falling for SELL, three taps for warnings, a spoken alert and a colored banner (tap the screen once so the phone allows sound). While the dashboard is speaking, the phone's own voice stays quiet so you never hear it twice. New Settings switches: Beep on BUY / SELL, Say it out loud (with Test).

## 1.46.0 — 2026-09-29
- Early BUY? / SELL? warnings on the chart, for every watchlist stock. Dashed amber boxes appear when the trend ribbon is about to flip, before the confirmed BUY/SELL (the yellow line closing in on the white line, price crossing the yellow line and VWAP, the white line flattening, volume picking up). Each has a confidence %; past ones are graded ✓ (the flip followed within 6 candles) or ✗ (false alarm), and the chart shows the stock's hit rate, how many candles early, and the average price gained vs waiting. Warnings under 60% are hidden. Display only: the bot never trades on them. Watchlist chips now show each stock's trend dot, an amber ring plus BUY?/SELL? % when a warning is live, and 'no data' when Alpaca sends no prices (e.g. QNT). Tapping a warned chip, the new ⚡ Trade button or 'Open trade popup' opens the quick trade sheet with a live chart (1m/3m/5m/15m) and the warning, and the suggested side is outlined. Plain-English ⓘ popups on every chart term: VWAP, uptrend/downtrend, fast/slow lines, ribbon flips, BUY?/SELL?, O/H/L/C, volume, measure tool, after-hours.

## 1.45.0 — 2026-09-29
- Two safety rails: (1) no single position larger than 25% of your equity (margin buying power is ~4x, so one trade could be the whole account, like the 6,043-share KNDI trade); (2) a setup with fewer than 20 closed trades trades at 35% size (70% if it is already winning), full size only after it proves itself. Switch on the Self-fix card.

## 1.44.0 — 2026-09-29
- Let winners run and pick better: SCALE exit now takes 1/4 at +1R with the stop only to -0.5R (break-even after +2R), wider 1.8 ATR trail, target 8R; scalp profiles no longer bank at +0.15R (switch: Let winners run); ribbon-flip exit needs 3 confirmations. Entry filters: no stocks under $2, no trades against a clear early direction call.

## 1.43.0 — 2026-09-29
- Self-fix: the bot reviews its own last 12 closed trades of every setup. Losing setups are benched (one half-size probe trade a day until they recover); winning setups are promoted (ranked first, up to +30% size). New Self-fix card shows each setup's status; on by default, switchable.

## 1.42.0 — 2026-09-29
- Double-tap any row (pre-market timeline, shortlist, evening candidates, movers, setups) to open the quick BUY / SELL sheet. Single tap still opens the chart. Quantity is remembered from your last quick trade.

## 1.41.3 — 2026-09-29
- Anti-churn block is now only 2 losing closes on the same stock within 30 minutes (replaces the max-trades and wait-time rules). The dashboard shows blocked stocks with a Release button; release also clears the older cooling-off counters.

## 1.41.2 — 2026-09-29
- Stop churning one stock: always-on anti-churn guard read from the trade database (max 4 trades and 2 losses per symbol per day, 8 min between trades, 20 min after a loss). Works across restarts and cannot be switched off.

## 1.41.1 — 2026-09-29
- Pre/after-market trades no longer stop out too early: stop is at least 0.45% (or 1.2 ATR) from entry, price (mid) must stay beyond the stop 25 s before exiting (immediate only at -1.4R), and the ribbon-flip exit waits 6 minutes and never cuts a trade already above +0.9R.

## 1.41.0 — 2026-09-29
- Automatic system now finds and trades BOTH longs and shorts (mode picker: Longs + shorts / Shorts only / Longs only). Borrow check applies to shorts only; hard-to-borrow names stay on the shortlist as long-only candidates.

## 1.40.1 — 2026-09-29
- Fixed pre-market orders being rejected for insufficient buying power (BMNR: needed $5,584, had $5,410). Extended-hours checks did not refresh the account, so sizing used a stale buying-power number. Now the account is re-read before every pre-market or after-hours order, the quantity is capped to 95% of real buying power, and if Alpaca still says insufficient buying power the bot reads the real numbers from the error and retries once with a smaller quantity. Regular-hours orders and the manual auto-harvest re-entry get the same shrink-to-fit.

## 1.40.0 — 2026-09-28
- Auto re-entry that jumps back in. After a profitable exit the bot (all setups, regular hours and pre-market/after-hours) gets back in on the same side in two ways: on a pullback of at least a quarter of the stock's normal range with the latest 1-minute bar turning back, or, if there is no pullback and the stock keeps running, as soon as a completed 1-minute bar closes at a new high (or low, for shorts) at least 0.3 of that range past the exit price, with the ribbon and VWAP agreeing. Up to 3 re-entries per stock in a row, within 90 minutes, never after a loss, a ribbon turn against you, a daily-loss halt or an end-of-day flatten; bought or shorted with the same take-profit-along-the-way exit. The manual auto-harvest (the ♻ button) now does the same: back in on a pullback, or after 45 seconds if it keeps running past the harvest price. Switch: Controls > Advanced > Auto re-entry (on by default). New REENTRY trades show in the journal.

## 1.39.0 — 2026-09-28
- Automatic short system. One tap (Enable automatic short system, on the card near the top) for the selected PAPER or LIVE account: it starts the bot, turns on shorts only, morning reversal, the pre-market plan and (with SIP) late-day overnight shorts, then waits for a fresh, confirmed 1-minute short signal before ordering. LIVE asks for your Live PIN. Before every short it rechecks Alpaca's borrow_status (must be easy_to_borrow and shortable; hard-to-borrow names are skipped). Overnight homework: each night after 4:35 PM the whole market is ranked by volume, trade count and movement (plus your watchlist) into a short shortlist, and from 8:00 AM ET it is rechecked every 15 minutes and added to the live scanner with the new movers. Harvest and re-entry: short-system trades use the exit that takes portions near +1R and +2R and trails the rest, and after a profitable exit the same stock is only traded again on a distinct new signal (a different setup, or a 15-minute pause plus a real bounce). Long signals are ignored while the system is on. Turn it off from the same button.

## 1.38.0 — 2026-09-28
- Pre-market timeline: from 4 AM the bot snapshots the big movers at 4 AM, 7 AM, 8:30 and 9:15 (4 AM needs the SIP feed; you have it) and shows how each one moved (holding, faded, extending) in a new Pre-market timeline card, with a phone alert at the 7 AM and 9:15 checks. Short at open: gappers up 1.5%+ that have faded off their pre-market high and are under VWAP go on a short-at-open list, and the new OPEN_SHORT strategy shorts the first close below the pre-market low between 9:31 and 9:50 (stop above the early high or VWAP). On by default; switch: Controls > Advanced > Pre-market plan. Pre-market and after-hours trading already run from 4 AM once the feed is SIP.

## 1.37.0 — 2026-09-28
- Three new tools, all off by default except the review. (1) Morning reversal (Controls > Advanced): looks for a second rejection of the opening high (the first 5 minutes' high), then waits for a completed 1-minute close below the low since that rejection before it shorts, 9:40-11:30, stop just above the opening high. The opening window is ignored, so a 9:35 poke and fake-out does not count, and a breakout above the high cancels it. (2) Pre-close overnight short (Controls > Advanced): scans 3:10-3:35 PM for a spike that is failing (up 3%+ and faded 40% off the high) or a weak close (down 3%+, near the low), under VWAP with a red ribbon, and shorts shares with a broker-held GTC stop and target placed once filled. Needs the SIP feed and a short-enabled account, skips Fridays and days before holidays, and skips earnings and risky news. The bot covers by 10:15 AM if neither order has hit. A GTC stop can fill far worse if the stock gaps up at the open. Shares only, because Alpaca has no extended-hours options orders. (3) Review evening candidates button and card: lists the prior session's setups; each is a watch item that is scanned the next morning, and no order is placed until a fresh signal confirms. It also runs by itself after 4:30 PM. New command: sekex replay SYMBOL DATE prints when each strategy would have fired on that day using your Alpaca data. Fixed: release zips no longer include the simulator's test data folder.

## 1.36.0 — 2026-09-28
- Automatic direction trading: when a Big mover gets a strong LONG or SHORT call (score 45+, most signals agreeing, not stretched from VWAP), the bot now trades it by itself between 9:33 and 11:00 (new DIR_CALL strategy, ridden with the take-profit-along-the-way exit) and sends one phone alert per stock per day. The call uses pre-market bars, so it works from the opening bell instead of 9:44. It is on in Balanced, Aggressive and Max, and off in Conservative (Controls > Advanced, Trade strong early direction calls). DIR_CALL trades are paused automatically if the overnight study finds that kind of call right less than half the time over 20+ calls. The study also replays DIR_CALL each night so the learner sizes it.

## 1.35.0 — 2026-09-28
- Early direction call: every Big mover and any ticker you type into the manual ticket now shows LONG, SHORT or WAIT with a score and the reasons. It is a weighted vote of price vs VWAP, ribbon, swing structure (higher highs or lower lows), 15-minute momentum, buying vs selling volume, position in the day's range, SPY/QQQ, and how that stock's gaps have behaved (follow through or fade) in the overnight study. It says WAIT when the votes disagree and flags when price is stretched from VWAP. The overnight study scores each 9:40 call against the next hour on past days and shows how often LONG, SHORT and STRONG calls were right.

## 1.34.0 — 2026-09-28
- Catch the morning trend and learn overnight. (1) The ribbon now starts from the pre-market bars, so it is ready at 9:30 instead of about 10:00, which is why early trends were missed. Entries open 2 minutes after the bell (was 5). (2) New PLAN_TREND strategy: a name on the Big movers list that gapped 0.8%+ and breaks its early high (or low, for shorts) with VWAP, ribbon and volume agreeing is bought or shorted right away; PLAN_TREND and GAP_GO trades are ridden with the SCALE exit (take profit along the way, trail the rest) instead of a quick scalp. (3) Overnight study: after 5 PM, overnight and on weekends the bot replays the last few trading days of your stocks minute by minute through every strategy and every exit style and teaches the learner, weighted at 0.3 of a real trade; each day is studied once. New Overnight study card with Study now and an on/off box.

## 1.33.0 — 2026-09-28
- Trading levels: pick Conservative, Balanced, Aggressive or Max in one tap instead of setting many boxes. Auto learns which of the first three works best in each session (pre-market, regular, after-hours) from your own trades, judged by average R per trade once a level has 8 trades in that session, and switches at each session start (it never picks Max on its own, and starts from Balanced/Conservative defaults while it learns). Change any single box under Advanced and the level becomes Custom. Existing setups keep their current switches as Custom. The daily max loss and session on/off boxes are never changed by Auto.

## 1.32.0 — 2026-09-28
- Automatic morning and night setup: the Big movers list now builds itself every 5 minutes in pre-market and after-hours even when the auto-trader is stopped (turn off with Controls > Auto-prep), and the last list stays on screen overnight and after a restart, with an as-of time, so it no longer goes empty. If your Alpaca account has the paid SIP data feed, SekexBot detects it at startup and switches to it, which gives the full 4 AM to 8 PM window (free IEX only covered 8 AM pre-market and after-hours until 5 PM). Positions are still flattened shortly before each session ends.

## 1.31.0 — 2026-09-28
- Auto-harvest: tick the new ♻ box on the manual ticket or quick-trade sheet (or tap ♻ on an open position). It sells for a small quick gain (about half the stock's normal 5-minute range, or when the gain starts to fade), then buys or shorts the same size again on a pullback when the ribbon still agrees. It repeats until you tap Stop, and stops on its own if the ribbon turns against you, the daily loss limit halts trading, or a trade goes 1.2 ranges against you (it closes that one). Works long or short, with the auto-trader on or off.
- Reopen last close: one tap, no confirmation, puts back the position you last closed by hand (same stock, side and size), and turns auto-harvest back on if it was on. Shows under Positions after you close something.

## 1.30.1 — 2026-09-28
- Publish in one command: run `sekex publish` in Termux after saving a new zip to Downloads. It finds the newest zip, writes latest.json (version, checksum, notes), uploads the zip and then latest.json to your GitHub update repo, and sets the app's update link. GitHub repo and token are asked for once and stay on the phone.

## 1.30.0 — 2026-09-28
- Pre-open mode: pre-market and after-hours trading are now ON by default (your existing settings switch on once). The bot scans for movers every 5 minutes, keeps taking pre-market entries until 9:20 instead of stopping at 9:05, and only closes pre-market trades in the last 4 minutes before the open.
- Gap fade: new GAP_FADE strategy for a gap that fails. A gap-up losing the opening-range low and VWAP is shorted (SPCX on Sep 28). A gap-down reclaiming the range high and VWAP is bought. Runs 9:40-10:45. Gap and go now starts at 2% gaps, long or short (META on Sep 28).
- Evening movers: new EXT_TREND strategy trades pre-market and after-hours continuation of 1.2%+ movers, long or short, when the ribbon, VWAP and a fresh break agree.
- Big movers list: new card with the top 10 names moving 1%+ from the last close, each with a plan (GO, FADE or WAIT), side, trigger and target. It works in pre-market, at the open and in after-hours, and sends one alert around 8:55 AM and 4:05 PM.

## 1.29.0 — 2026-09-28
- Shorts on by default: SELL flips and short setups now trade in regular hours, and in pre-market and after-hours when the stock is shortable and your account can short. Overnight stays long-only. Stops, take-profits and exits work for shorts in every session.
- Why no trade?: a new panel lists every signal or ribbon flip the bot saw but skipped, with the exact reason (flip too old, below VWAP, time-of-day filter, cooling off, cannot short, slots full, sizing and more). Filter it by symbol.
- Trade every flip: optional switch that takes each fresh ribbon BUY/SELL flip on your watchlist and picks. It skips the VWAP, learner and time-of-day checks for flips only. The daily loss limit and position sizing still apply.

## 1.28.0 — 2026-09-28
- ✋ One-tap manual trading: no more 'Send this order?', 'Close?' or LIVE-money pop-ups on the order ticket, the quick trade sheet or Close buttons. The order goes straight away. To bring the pop-ups back, tick 'Ask before sending or closing manual trades' in Controls. Opening a short when you don't own the stock still asks once, because losses are unlimited.

## 1.27.0 — 2026-09-28
- 🧊 Cooling off is now optional (Controls). 'Cool off after 3 losses in a row' switches off the 20-minute pause and the half-size penalty. 'Symbol cooldown' switches off the wait before re-trading a stock and the skip after 2 losses in a day. Both are on by default. While the bot is cooling off, a ▶ Resume now button clears the pause, the penalty and today's cooldowns in one tap. The daily loss limit always stays on.

## 1.26.0 — 2026-09-28
- 💰 Quick harvest for scalps (Aggressive and Scalp modes, every session): once a scalp has been green for 2 checks in a row, it doesn't wait for the target. It banks the profit when momentum stalls (0.15R back from its best) or when it's near the target. The stock can be re-entered right away if the setup fires again; otherwise the slot goes to the next best candidate. Bug-check fixes: restoring open trades after a restart or a ↩ Revert no longer fails when versions store different trade fields, and log lines show the size weight rounded.

## 1.25.0 — 2026-09-28
- 🔥 Aggressive scalping (Controls, off by default): many fast trades in every session. It adds a MICRO_SCALP setup (1-minute burst over the last 3 bars on 2× volume, above VWAP) and trades every setup with ½ at +0.5R (the rest moves to break-even) and the rest at +1R, out within 8 minutes. Up to 6 positions at 60% size, checks every 10 s (5 s in extended hours), and shorter cooldowns. The daily loss limit still applies. 🔻 Flush short: a tight range that breaks down hard on 2× volume (like TSLA's drop), when shorting is on. 🔺 Flush bounce: the first strong green bar after a fast 2-ATR drop on a volume spike (in all sessions). Flush setups skip the ribbon wait and the time-of-day filter. 🎯 Setting up now: a live top-15 list of stocks coiling for a fast move before it happens (tight range, volume building, lean from VWAP, ribbon and highs/lows), with the likely direction, trigger price, target, expected move, a 0–100 Ready score and ⚡ breaking now. The stock picker now scans 30 names.

## 1.24.0 — 2026-09-28
- 💰 Profit harvesting in every session. Pre-market, after-hours and overnight trades now take profit along the way like regular hours: ⅓ at +1R (the rest moves to break-even), ⅓ at +2R, then a 1× ATR trail or a ribbon flip. Partial sells are marketable limit orders, the only kind Alpaca allows outside regular hours, and each one sends a 💰 alert. ⚡ New Scalp mode (Controls, off by default): ½ at +0.6R, the rest at +1.2R, out within 20 minutes, in every session. ⬆ Update progress: the update screen shows a progress bar, each install step with a ✓, elapsed time and a details log. The app keeps serving while it installs and only restarts at the end.

## 1.23.0 — 2026-09-27
- 🚀 Opening Drive setup (OPEN_DRIVE), modeled on your best trades (SPCX, VKTX, AMD at 9:30): a +2% gapper that breaks its first-5-minute high above VWAP on a volume surge, 9:35–9:50 (a gap-down short when shorting is on). 💰 Take profit along the way (on by default): the bot sells ⅓ at +1R and moves the stop to break-even, sells another ⅓ at +2R, and rides the rest with a 1× ATR trail or until the ribbon flips. A '💰 Took profit' alert fires each time, and the journal and learner count the whole trade. 🕒 Time-of-day filter from your own history: the bot skips new trades in the time slots where your last 90 days lose money (at least 30 trades; today that's midday, morning after the drive, after-hours and overnight), and still allows opening drives until 9:50. Switches for both are in Controls. ⬆ Updates: SekexBot checks for a new version every hour and, in Ask mode, shows Update now / Later / Skip this version; Manual mode never prompts. Every update saves the version it replaces (the last 3 are kept), and '↩ Revert to vX' in the Update screen (or 'sekex rollback X.Y.Z') goes back while keeping your data.

## 1.22.0 — 2026-09-27
- 🔍 Trend research (Manual tab): type a ticker (for example SPCX), choose 10–90 days and tap Study. It finds every big run up or down in the stock's own minute history. For each run you see the start and end times and prices, the move and how long it lasted, grouped as morning, midday or afternoon. It also shows when morning runs typically start, what was true as runs began (opening drive, opening-range break, above or below VWAP, volume surge) and which exit rule kept the most of each run (ribbon flip, VWAP cross, 2 closes against, 1× or 2× ATR trail). These results will shape the bot's new morning and wave strategies.
- 🔔 3:55 PM overnight test: buy (or short) at 3:55 PM and exit at 8 PM, 11 PM, 2 AM, 4 AM, 8 AM, 9:25, 9:35 or 10 AM. Shows average result, long and short win rates, and worst and best days, and highlights the best combination. It uses real overnight (24-hour session) prices where the stock trades overnight.

## 1.21.0 — 2026-09-27
- 📊 Trading stats (Positions tab): every trade in your Alpaca account, bot and manual, matched from buy to sell. Shows total P&L, win rate, average win and loss, and profit factor. P&L by time of day (pre-market, morning 9:30–11:30, midday, afternoon, after-hours, overnight); tap a time to filter. Your top 5 wins and worst 5 losses, bot vs. manual results, and each bot strategy's results. Covers 7 days to 1 year.
- 📰 Earnings and news: the order ticket shows whether the stock reports earnings today or before the next open, plus the latest headlines, with risky ones flagged (offering, halt, bankruptcy, delisting, investigation, reverse split, downgrade…). The auto-trader skips a stock on its earnings day, doesn't buy after-hours or overnight right before a pre-market report, and waits 30 minutes after a risky headline. It uses the free Nasdaq earnings calendar and Alpaca news. If either is unreachable, trading continues.
- 🛡 Safety net (⚙ Settings): a phone-offline alert through free healthchecks.io. The app pings every minute; if the phone dies, sleeps or loses internet, healthchecks.io alerts you by email, SMS, ntfy or Telegram. Nightly backups at 8:10 PM ET of the journal, learning memory and settings (never API keys or tokens) to Downloads/SekexBot/backups, keeping 14, with optional upload to a private GitHub repo. Back up now and Restore buttons included.

## 1.20.5 — 2026-09-27
- Charts at any hour: the chart now shows the last few days, including pre-market, after-hours and the overnight (24-hour) session, not just 9:30–4:00. Nights and weekends show the most recent real prices, the same as Robinhood's 24 Hour Market chart. It uses Alpaca's overnight feed (BOATS on SIP accounts, Alpaca's overnight feed otherwise). Extended hours are lightly shaded and overnight is shaded blue. When nothing is trading, the header says when the last trade happened.

## 1.20.4 — 2026-09-27
- Take profit after a halt: every winner kept open gets a profit lock, set at break-even or better and then at half of its best gain, rising as the price climbs. If the price falls back to the lock, the position is sold (limit orders in extended hours) and you get a "💰 Took profit" alert. This covers manual positions too. Bot trades also get their stop at Alpaca raised to the lock. Profit locks survive an app restart.

## 1.20.3 — 2026-09-27
- Daily loss limit: when it's hit, the bot now closes only the **losing** positions (bot and manual) and keeps the winners open. Winners keep their stop-loss and the bot keeps trailing them; it just opens no new trades until the next day (8 PM ET). In extended hours the losers are closed with limit orders.

## 1.20.2 — 2026-09-27
- Auto-trade safety fixes: after switching from PAPER to LIVE on the same day, the bot could compare your live balance with the paper account's starting balance, read it as a huge loss, and close all live positions. The start-of-day balance is now kept separately for Paper and Live, and any figure far off your real equity is ignored. Updated for FINRA's retirement of the pattern-day-trader rule (Alpaca's Intraday Margin Framework, since June 4, 2026). No day-trade counting and no $25k minimum: the bot sizes within intraday buying power, skips new entries when buying power runs low, and pauses for the day if Alpaca restricts orders. The app keeps working after Alpaca removes the old day-trade fields from its API on July 6, 2026. A position the bot can't close now raises an alert instead of failing silently. Saved halts and loss streaks are again restored correctly after a restart (the new always-on balance display could skip them).

## 1.20.1 — 2026-09-27
- Fixes: the account bar and Account card now show your balance, buying power and today's P&L at all times, including nights and weekends (they were blank while the market was closed). Switching the data feed to SIP now works while the auto-trader is running — it checks your account really has SIP, switches, and restarts the bot — instead of silently flipping back to IEX.

## 1.20.0 — 2026-09-27
- Paper / Live switch: tap the PAPER / LIVE badge at the top to switch. Live needs your Live PIN, a real-money confirmation and working live keys (checked first); a running auto-trader stops, switches and restarts by itself. Too many wrong PINs lock the switch for 15 minutes. Live is unmistakable on every screen: a red frame, a '● LIVE — REAL MONEY' bar, a pulsing red badge, 'LIVE ·' on order buttons, a red browser bar and '🔴 LIVE' in the title and alerts. Account bar: balance, today's P&L ($ and %), open P&L, buying power and loss left stay pinned under the header on every screen and layout.

## 1.19.0 — 2026-09-27
- Interactive chart: touch or drag for a crosshair with time, OHLC, volume, trend (uptrend/downtrend), fast/slow lines and VWAP; tap to pin a point and measure the move to the crosshair ($, %, time, ribbon flips); pinch or scroll to zoom, drag to pan, double-tap to reset; 1m / 3m / 5m / 15m timeframes; volume bars and a VWAP line.

## 1.18.0 — 2026-09-27
- Streaming prices: real-time quotes and trades from Alpaca's websocket (up to 30 symbols on the free plan), pushed to the dashboard — the ticket, quick sheet and positions P&L move tick by tick with a STREAMING badge. The bot uses streamed prices too, and its extended-hours stops (watched by the app) now react within about a second instead of 15. Falls back to polling automatically if streaming isn't available. Help & repair now checks whether SIP data works on your account and can switch back to IEX with one tap.

## 1.17.0 — 2026-09-27
- Alerts: phone notifications (with Trade and Close buttons) for bot entries, fills, exits with P&L, stops raised, rejections, daily-loss halt, losing streaks, broker restrictions and stale data; watchlist trend alerts (ribbon flip, new high/low of day, VWAP, volume spike); price alerts; end-of-day summary. Optional copies to ntfy or Telegram, quiet hours, per-type switches, and a bell with the alert history. Faster trading: $1k / $5k / 1R / Max size buttons and a price-alert button in the quick sheet; tapping Trade on a notification opens the quick sheet. Help & repair: run checks, one-tap fixes (reconnect, restart, repair install, update), Ask AI (Claude explains errors in plain steps) and Send report. Fixes: bracket orders rejected while the market is closed are re-anchored on Alpaca's reference price automatically, order errors are explained in plain words, and suggested stops can no longer be unrealistically tight.

## 1.16.0 — 2026-09-26
- Live price everywhere, at any time: the order ticket and quick trade sheet show the price, day change (green/red), bid/ask and a LIVE dot, refreshing every 3 seconds, with the cost worked out as shares × price against your buying power. When the market is closed (nights, weekends, holidays) the price falls back to the last trade or last close, labeled 'as of', so orders can always be prepared. The trend chart shows the most recent session when the market is closed instead of 'Waiting for bars'.

## 1.15.0 — 2026-09-26
- Suggested stop-loss / take-profit: tick Attach stop-loss / take-profit and SekexBot proposes Scalp, Day and Swing levels from real support/resistance and the stock's volatility (ATR), with R multiple, trend check and a size that risks the bot's base amount. The quick trade sheet can protect orders with the Day levels automatically. Fix: prices now work on nights and weekends (last session's close), so orders can be prepared while the market is closed.

## 1.14.1 — 2026-09-26
- Gains show green and losses red everywhere, with a + sign on gains: today's P&L, the summary strip, every position and its %, bot trades (new P&L column), the journal, daily results and averages. Totals for Positions & orders, Open positions and Daily results. sekex status colors the day's P&L too.

## 1.14.0 — 2026-09-26
- New layout with a ⚙ gear: choose Tabs (Auto · Manual · Positions · More at the bottom), an Auto | Manual switch, or the classic one-page layout. Light, dark or follow-the-phone theme. A big Auto-trader on/off switch and an always-visible summary strip (equity, today, loss left, open trades). Your choices are remembered on each device.

## 1.13.0 — 2026-09-26
- Double-tap to trade: double-tap any stock in the picker, the scanner chips or your positions to open a quick trade sheet with the suggested size and big BUY / SELL (or SHORT) buttons. A single tap still opens the chart.

## 1.12.1 — 2026-09-26
- Turn off app button uses an icon every phone font can show.

## 1.12.0 — 2026-09-26
- Full order ticket like Alpaca's: Buy/Sell (Short), Market, Limit, Stop, Stop limit and Trailing stop orders, a quantity stepper, a limit price with tap-to-fill bid/ask, Time in force (Day, GTC, IOC, FOK, At the open, At the close) and Trading session (Market hours, Extended hours, 24 Hour Market). In-app updates: install a new version from the dashboard (⬆ Update) by picking the zip, or from an update link that is checked every 6 hours, with a notification and one-tap install.

## 1.11.0 — 2026-09-26
- Manual trading: a Manual trade ticket with Buy and Sell (market or limit, size in shares or dollars, optional stop-loss and take-profit) and a Positions & orders panel for the whole account with Close, Close ½ and Cancel. The bot stays out of any symbol you trade by hand that day and never flattens your manual positions at the close.

## 1.10.0 — 2026-09-26
- Fully automated install: one-file installer (SekexBot_Setup.sh), optional sekexbot-setup.conf to pre-fill keys and settings and start trading automatically, a non-interactive package install with a log, and 'sekex doctor --fix', which checks the phone and opens the screens that fix problems.

## 1.9.1 — 2026-09-26
- Tap-to-use controls: home-screen Start / Stop / Status / Open buttons (Termux:Widget), Start and Stop buttons in the SekexBot notification, pop-up messages, and a ⏻ Turn off app button on the dashboard.

## 1.9.0 — 2026-09-26 (Android edition)
- 🤖 Runs entirely on an Android phone inside Termux. No PC needed. `install.sh` sets everything up, and the `sekex` command starts, stops and checks the bot.
- Watchdog: if the app crashes or Android kills it, it restarts automatically, and trading **resumes** if it was running (a Stop from the dashboard or `sekex stop` is remembered).
- Open trades, today's halt state, profit-lock peak and losing-streak brakes are saved every tick and restored after a restart, so a restart can't reset your limits.
- Wake lock, start on phone boot (Termux:Boot), and an ongoing notification with an Open button.
- Dashboard shows battery, charging and wake-lock status, with warnings when the phone is on battery or hot.
- After-hours and overnight trading start **off** on Android, because their stops are watched by the app itself.
- "Phone access" becomes "Remote access" for checking the phone's bot from another device (uses Termux's cloudflared).

## 1.8.0 — 2026-09-26
- 📱 Phone access through a Cloudflare Tunnel. You can use a Quick link (no account) or your own domain, with a QR code, and auto-connect on start.
- A login page with a password (hashed), 30-day signed sessions, and a lockout after too many wrong attempts.
- Broker keys and phone-access settings can only be changed on the computer running SekexBot.
- The dashboard fits phone screens and can be installed as an app with the SekexBot icon.
- A version number with this changelog.

## 1.7.2
- Chart read: "Analyze live chart" now uses the most recent session at night, on weekends and before the open.
- Clear error messages for the AI screenshot reader: no API credits, bad key, model not found, image too large, rate limit.
- A "Test AI key" button.

## 1.7.1
- New SekexBot logo, app icon, favicon, Windows .ico, and a desktop-shortcut helper.

## 1.7.0
- Account-size-aware stock picker. It scans about 300 stocks and scores each one for opportunity × fit (daily limit, buying power, liquidity).
- "Scan now" button and a Stock picker table with the reasons for each pick.
- Fix: volume and ATR now come from full-market SIP history instead of IEX-only volume.

## 1.6.0
- 🔑 Broker keys screen: enter, test and save Alpaca paper and live keys, a Live PIN, and a Claude key, all in the dashboard.
- Startup no longer opens Notepad.

## 1.5.1
- Renamed to SekexBot.

## 1.5.0
- BullGPT-style screenshot reader. Drop in or paste a chart and get a game plan: trend, levels, timing, scenarios, lean, and what the bot would do.
- Watchlist of tickers that are always scanned and traded in every session (SPCX added to start).

## 1.4.0
- After-hours (4–8 PM) and overnight (8 PM–4 AM) trading: long-only, limit orders, bot-managed stops, half size.
- The daily loss window runs 8 PM → 8 PM ET. The chart is built from quotes overnight.
- Fixed start_bot.bat when the Python environment was missing pip.

## 1.3.0
- Portable SD card / USB edition with a bundled runtime and self-repairing setup.

## 1.2.0
- AI chart read panel: levels, Fibonacci, RSI, VWAP, bias score, and bull and bear scenarios.

## 1.1.0
- EMA ribbon: RIBBON_FLIP strategy, ride-the-ribbon exit, ribbon trend filter, ribbon chart on the dashboard.

## 1.0.0
- First release: morning scanner, five strategies, a Thompson-sampling learner that picks setups and exits, a daily-max-loss risk manager, bracket orders, the dashboard, and the offline simulator.
